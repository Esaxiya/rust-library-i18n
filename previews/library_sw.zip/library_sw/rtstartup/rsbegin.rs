// rsbegin.o na rsend.o ndio inayoitwa "compiler runtime startup objects".
// Zina vyenye nambari zinazohitajika ili kuanzisha kwa usahihi wakati wa kukimbia wa mkusanyaji.
//
// Wakati picha inayoweza kutekelezwa au dylib imeunganishwa, nambari zote za mtumiaji na maktaba ni "sandwiched" kati ya faili hizi mbili za vitu, kwa hivyo nambari au data kutoka rsbegin.o inakuwa ya kwanza katika sehemu husika za picha, wakati nambari na data kutoka rsend.o huwa za mwisho.
// Athari hii inaweza kutumika kuweka alama mwanzoni au mwisho wa sehemu, na pia kuingiza vichwa au vichwa vyovyote vinavyohitajika.
//
// Kumbuka kuwa sehemu halisi ya kuingia kwa moduli iko katika kitu cha kuanza kwa wakati wa kukimbia C (kawaida huitwa `crtX.o`), ambayo huingiza urejesho wa uanzishaji wa vipengee vingine vya wakati wa kukimbia (iliyosajiliwa kupitia sehemu nyingine maalum ya picha).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Alama zinazoanzia sehemu ya fremu ya kupumzika
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Pata nafasi ya kutunza kitabu ndani.
    // Hii inafafanuliwa kama `struct object` katika $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Unwind infoout registration/deregistration.
    // Tazama hati za libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // sajili habari ya kupumzika juu ya kuanza kwa moduli
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ondoa usajili juu ya kuzima
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Usajili wa kawaida wa MinGW init/uninit
    pub mod mingw_init {
        // Vitu vya kuanza kwa MinGW (crt0.o/dllcrt0.o) vitaomba waundaji wa ulimwengu katika sehemu za .ctors na .dtors wakati wa kuanza na kutoka.
        // Katika kesi ya DLL, hii inafanywa wakati DLL inapakiwa na kupakuliwa.
        //
        // Kiunganishi kitatengeneza sehemu, ambazo zinahakikisha kuwa kurudi nyuma kwetu kunapatikana mwisho wa orodha.
        // Kwa kuwa waundaji huendeshwa kwa mpangilio wa nyuma, hii inahakikisha kuwa kurudi nyuma kwetu ndio kwa kwanza na kwa mwisho kutekelezwa.
        //
        //

        #[link_section = ".ctors.65535"] // . madaktari. *: C uanzishaji wa kurudi nyuma
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C kusitisha kurudi nyuma
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}