//! Kufungua panics kwa Miri.
use alloc::boxed::Box;
use core::any::Any;

// Aina ya malipo ambayo injini ya Miri inaeneza kupitia kutufungulia.
// Lazima iwe ya ukubwa wa kiashiria.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Kazi ya nje iliyotolewa na Miri kuanza kufungua.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Malipo tunayopitisha kwa `miri_start_panic` itakuwa sawa na hoja tunayopata katika `cleanup` hapa chini.
    // Kwa hivyo tunapiga sanduku mara moja, kupata kitu cha ukubwa wa pointer.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Pata msingi wa `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}