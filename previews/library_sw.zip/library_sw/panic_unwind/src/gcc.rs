//! Utekelezaji wa panics unaungwa mkono na libgcc/libunwind (kwa namna fulani).
//!
//! Kwa usuli juu ya utunzaji wa ubaguzi na mpororo wa kufungua tafadhali angalia "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) na hati zilizounganishwa kutoka kwake.
//! Hizi pia ni kusoma vizuri:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Muhtasari mfupi
//!
//! Utunzaji wa ubaguzi hufanyika katika awamu mbili: awamu ya utaftaji na awamu ya kusafisha.
//!
//! Katika awamu zote mbili fremu hutembea kutoka juu hadi chini kwa kutumia habari kutoka kwa fremu ya sehemu za kupumzika za moduli za mchakato wa sasa ("module" hapa inahusu moduli ya OS, yaani, maktaba inayoweza kutekelezwa au yenye nguvu).
//!
//!
//! Kwa kila fremu ya stack, inaomba "personality routine" inayohusiana, ambayo anwani yake pia imehifadhiwa katika sehemu ya habari ya kupumzika.
//!
//! Katika awamu ya utaftaji, kazi ya kawaida ya utu ni kuchunguza kitu kinachotupwa, na kuamua ikiwa inapaswa kunaswa kwenye fremu hiyo ya stack.Mara baada ya sura ya mshughulikiaji kutambuliwa, awamu ya kusafisha huanza.
//!
//! Katika awamu ya kusafisha, kitambulisho huomba kila utaratibu wa utu tena.
//! Wakati huu inaamua ni ipi (ikiwa ipo) nambari ya kusafisha inayohitajika kuendeshwa kwa fremu ya sasa ya stack.Ikiwa ndivyo, udhibiti unahamishiwa kwa branch maalum katika mwili wa kazi, "landing pad", ambayo huingiza waharibu, hutoa kumbukumbu, n.k.
//! Mwisho wa pedi ya kutua, udhibiti huhamishiwa kwenye sehemu ya kupumzika na kupumzika.
//!
//! Mara baada ya kufunguliwa chini kwa kiwango cha fremu ya mshughulikiaji, kupumzika kunasimama na utaratibu wa utu wa mwisho huhamisha udhibiti kwenye eneo la kukamata.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Kitambulisho cha kitengo cha ubaguzi cha Rust.
// Hii hutumiwa na mazoea ya utu kuamua ikiwa ubaguzi ulitupwa na wakati wao wa kukimbia.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-muuzaji, lugha
    0x4d4f5a_00_52555354
}

// Vitambulisho vya sajili viliinuliwa kutoka kwa XLXM ya LLVM na TargetLowering::getExceptionSelectorRegister() kwa kila usanifu, kisha kupangwa kwa nambari za usajili wa DWARF kupitia meza za ufafanuzi wa sajili (kawaida<arch>RegisterInfo.td, tafuta "DwarfRegNum").
//
// Tazama pia http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Nambari ifuatayo inategemea utaratibu wa utu wa GCC's C na C++ .Kwa kumbukumbu, tazama:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Utaratibu wa utu wa EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS hutumia utaratibu chaguomsingi badala yake kwa kuwa hutumia kupumzika kwa SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces kwenye ARM itaita utaratibu wa utu na state==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Katika visa hivyo tunataka kuendelea kufunua stack, vinginevyo athari zetu zote za nyuma zingeishia __kujiamini_kujaribu
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Kitambulisho cha DWARF kinadhani kwamba_Unwind_Context inashikilia vitu kama kazi na viashiria vya LSDA, hata hivyo ARM EHABI inawaweka kwenye kitu cha ubaguzi.
            // Kuhifadhi saini za kazi kama _Unwind_GetLanguageSpecificData(), ambayo huchukua kiashiria tu cha muktadha, utaratibu wa utu wa GCC huweka kiashiria kwa kitu cha kipekee katika muktadha, ikitumia eneo lililohifadhiwa kwa "scratch register" (r12) ya ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Njia iliyo na kanuni zaidi itakuwa kutoa ufafanuzi kamili wa ARM's_Unwind_Context katika vifungo vyetu vya libunwind na kuchukua data inayohitajika kutoka hapo moja kwa moja, kupitisha kazi za utangamano wa DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI inahitaji utaratibu wa utu kusasisha thamani ya SP kwenye kashe ya kizuizi ya kitu cha ubaguzi.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Kwenye ARM EHABI utaratibu wa utu unawajibika kwa kufunua fremu moja kabla ya kurudi (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // hufafanuliwa katika libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Kawaida ya utu, ambayo hutumiwa moja kwa moja kwenye malengo mengi na sio moja kwa moja kwenye Windows x86_64 kupitia SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Kwenye malengo ya x86_64 MinGW, utaratibu wa kupumzika ni SEH hata hivyo data ya kushughulikia (aka LSDA) hutumia usimbuaji unaofaa wa GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Utaratibu wa utu kwa malengo yetu mengi.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Anwani ya kurudi inaonyesha 1 byte iliyopita maagizo ya simu, ambayo inaweza kuwa katika safu inayofuata ya IP katika jedwali la anuwai la LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Fungua usajili wa habari
//
// Picha ya kila moduli ina sehemu ya maelezo ya kupumzika (kawaida ".eh_frame").Wakati moduli ni loaded/unloaded katika mchakato, uninder lazima ijulishwe juu ya eneo la sehemu hii katika kumbukumbu.Njia za kufanikisha ambazo hutofautiana na jukwaa.
// Kwa zingine (kwa mfano, Linux), kitambulisho kinaweza kugundua sehemu za habari peke yake (kwa kuorodhesha kwa nguvu moduli zilizopakiwa hivi sasa kupitia dl_iterate_phdr() API and finding their ".eh_frame" sections); Wengine, kama Windows, wanahitaji moduli kusajili kikamilifu sehemu zao za habari za kupumzika kupitia API isiyofifia.
//
//
// Moduli hii inafafanua alama mbili ambazo zimetajwa na huitwa kutoka rsbegin.rs kusajili habari zetu kwa wakati wa kukimbia wa GCC.
// Utekelezaji wa kufunguliwa kwa stack ni (kwa sasa) umeahirishwa kwa libgcc_eh, hata hivyo Rust crates hutumia sehemu hizi maalum za kuingia za Rust ili kuzuia migongano inayowezekana na wakati wowote wa kukimbia wa GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}