# `rustc-std-workspace-core` crate

crate hii ni shim na crate tupu ambayo inategemea tu `libcore` na kurudisha tena yaliyomo.
crate ni kiini cha kuwezesha maktaba ya kawaida kutegemea crates kutoka crates.io

Crates kwenye crates.io kwamba maktaba ya kawaida hutegemea hitaji la kutegemea `rustc-std-workspace-core` crate kutoka crates.io, ambayo haina kitu.

Tunatumia `[patch]` kuipitisha kwa crate hii katika hazina hii.
Kama matokeo, crates kwenye crates.io itachora utegemezi edge hadi `libcore`, toleo lililofafanuliwa katika hazina hii.
Hiyo inapaswa kuteka kingo zote za utegemezi kuhakikisha Cargo inajenga crates kwa mafanikio!

Kumbuka kuwa crates kwenye crates.io inahitaji kutegemea crate hii iliyo na jina `core` kwa kila kitu kufanya kazi kwa usahihi.Ili kufanya hivyo wanaweza kutumia:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Kupitia utumiaji wa ufunguo wa `package` crate imepewa jina tena kuwa `core`, ikimaanisha itaonekana kama

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

wakati Cargo inamwomba mkusanyaji, ikiridhisha maagizo ya `extern crate core` yaliyowekwa na mkusanyaji.




