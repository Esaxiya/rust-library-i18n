# `rustc-std-workspace-std` crate

Tazama nyaraka za `rustc-std-workspace-core` crate.