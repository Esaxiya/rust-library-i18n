# Kuchangia kwa stdarch

`stdarch` crate iko tayari kukubali michango!Kwanza labda utataka kuangalia hifadhi na uhakikishe kuwa vipimo vinakupitisha:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Ambapo `<your-target-arch>` ni lengo mara tatu kama inavyotumiwa na `rustup`, kwa mfano `x86_x64-unknown-linux-gnu` (bila `nightly-` iliyotangulia au sawa).
Pia kumbuka kuwa hifadhi hii inahitaji kituo cha usiku cha Rust!
Vipimo hapo juu kwa kweli vinahitaji rust ya usiku kuwa chaguomsingi kwenye mfumo wako, kuweka matumizi hayo `rustup default nightly` (na `rustup default stable` kurudisha).

Ikiwa hatua yoyote hapo juu haifanyi kazi, [please let us know][new]!

Ifuatayo unaweza [find an issue][issues] kusaidia, tumechagua chache na lebo za [`help wanted`][help] na [`impl-period`][impl] ambazo zinaweza kutumia msaada fulani. 
Unaweza kupendezwa zaidi na [#40][vendor], ukitekeleza maumbile yote ya muuzaji kwenye x86.Suala hilo lina vidokezo vyema kuhusu wapi kuanza!

Ikiwa una maswali ya jumla jisikie huru kwa [join us on gitter][gitter] na uliza karibu!Jisikie huru kuuliza@BurntSushi au@alexcrichton na maswali.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Jinsi ya kuandika mifano ya stdarch intrinsics

Kuna huduma kadhaa ambazo zinapaswa kuwezeshwa kwa asili iliyopewa kufanya kazi vizuri na mfano lazima uendeshwe tu na `cargo test --doc` wakati huduma hiyo inasaidiwa na CPU.

Kama matokeo, `fn main` chaguo-msingi ambayo hutengenezwa na `rustdoc` haitafanya kazi (mara nyingi).
Fikiria kutumia yafuatayo kama mwongozo ili kuhakikisha mfano wako unafanya kazi kama inavyotarajiwa.

```rust
/// # // Tunahitaji kipengele cha cfg_target_kuhakikisha mfano ni wa pekee
/// # // inayoendeshwa na `cargo test --doc` wakati CPU inasaidia huduma hiyo
/// # #![feature(cfg_target_feature)]
/// # // Tunahitaji kipengele cha kulenga ili asili ifanye kazi
/// # #![feature(target_feature)]
/// #
/// # // rustdoc kwa default hutumia `extern crate stdarch`, lakini tunahitaji
/// # // `#[macro_use]`
/// # # [macro_use] nje stdarch crate;
/// #
/// # // Kazi kuu halisi
/// # fn main() {
/// #     // Endesha hii tu ikiwa `<target feature>` inaungwa mkono
/// #     ikiwa cfg_feature_imewezeshwa! ("<target feature>"){
/// #         // Unda kazi ya `worker` ambayo itaendeshwa tu ikiwa kipengee cha lengo
/// #         // inasaidiwa na kuhakikisha kuwa `target_feature` imewezeshwa kwa mfanyakazi wako
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         salama fn worker() {
/// // Andika mfano wako hapa.Onyesha asili maalum itafanya kazi hapa!Nenda porini!
///
/// #         }
///
/// #         salama { worker(); }
/// #     }
/// # }
```

Ikiwa baadhi ya sintaksia hapo juu haionekani kuwa ya kawaida, sehemu ya [Documentation as tests] ya [Rust Book] inaelezea sintaksia ya `rustdoc` vizuri.
Kama kawaida, jisikie huru kwa [join us on gitter][gitter] na utuulize ikiwa utagonga mwamba wowote, na asante kwa kusaidia kuboresha nyaraka za `stdarch`!

# Maagizo mbadala ya Upimaji

Kwa ujumla inashauriwa utumie `ci/run.sh` kuendesha majaribio.
Walakini hii haiwezi kukufaa, km ikiwa uko kwenye Windows.

Katika kesi hiyo unaweza kurudi kutumia `cargo +nightly test` na `cargo +nightly test --release -p core_arch` kwa kujaribu kizazi cha nambari.
Kumbuka kuwa hizi zinahitaji zana ya vifaa vya usiku kusanikishwa na kwa `rustc` kujua juu ya lengo lako mara tatu na CPU yake.
Hasa unahitaji kuweka anuwai ya mazingira ya `TARGET` kama vile ungefanya kwa `ci/run.sh`.
Kwa kuongeza unahitaji kuweka `RUSTCFLAGS` (unahitaji `C`) kuonyesha sifa za kulenga, kwa mfano `RUSTCFLAGS="-C -target-features=+avx2"`.
Unaweza pia kuweka `-C -target-cpu=native` ikiwa wewe ni "just" inayokuza dhidi ya CPU yako ya sasa.

Tahadharishwa kuwa unapotumia maagizo haya mbadala, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], kwa mfano
majaribio ya kizazi cha mafundisho yanaweza kutofaulu kwa sababu disassembler iliwataja tofauti, kwa mfano
inaweza kutoa `vaesenc` badala ya maagizo ya `aesenc` licha ya wao kuishi sawa.
Pia maagizo haya hufanya vipimo vichache kuliko kawaida ingefanywa, kwa hivyo usishangae kwamba wakati mwishowe utavuta ombi makosa kadhaa yanaweza kujitokeza kwa vipimo ambavyo havijafunikwa hapa.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






