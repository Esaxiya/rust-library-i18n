use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Imetumika kuwaambia ufafanuzi wetu wa `#[assert_instr]` kuwa maumbile yote ya simd yanapatikana kujaribu codegen yao, kwani zingine zimepigwa nyuma ya `-Ctarget-feature=+unimplemented-simd128` ya ziada ambayo haina sawa katika `#[target_feature]` hivi sasa.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}