`core::arch` - Usanifu maalum wa usanifu wa maktaba ya Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Moduli ya `core::arch` hutumia maumbile yanayotegemea usanifu (kwa mfano SIMD).

# Usage 

`core::arch` inapatikana kama sehemu ya `libcore` na husafirishwa tena na `libstd`.Pendelea kuitumia kupitia `core::arch` au `std::arch` kuliko kupitia crate hii.
Vipengele visivyo na utulivu mara nyingi hupatikana katika Rust ya usiku kupitia `feature(stdsimd)`.

Kutumia `core::arch` kupitia crate hii inahitaji Rust ya usiku, na inaweza (na haina) kuvunja mara nyingi.Kesi pekee ambazo unapaswa kuzingatia kuitumia kupitia crate hii ni:

* ikiwa unahitaji kujikusanya tena `core::arch` mwenyewe, kwa mfano, na vipengee maalum vya kuwezeshwa ambavyo vimewezeshwa kwa `libcore`/`libstd`.
Note: ikiwa unahitaji kukusanya tena kwa lengo lisilo la kawaida, tafadhali pendelea kutumia `xargo` na upange upya `libcore`/`libstd` kama inafaa badala ya kutumia crate hii.
  
* kutumia huduma zingine ambazo zinaweza kuwa hazipatikani hata nyuma ya huduma za Rust zisizo na utulivu.Tunajaribu kuweka haya kwa kiwango cha chini.
Ikiwa unahitaji kutumia baadhi ya huduma hizi, tafadhali fungua suala ili tuweze kuziweka katika Rust ya usiku na unaweza kuzitumia kutoka hapo.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` inasambazwa kimsingi chini ya masharti ya leseni ya MIT na Leseni ya Apache (Toleo la 2.0), na sehemu zikiwa zimefunikwa na leseni kama za BSD.

Tazama LICENSE-APACHE, na LICENSE-MIT kwa maelezo.

# Contribution

Isipokuwa ukisema waziwazi vinginevyo, mchango wowote uliowasilishwa kwa makusudi ili ujumuishwe na `core_arch` na wewe, kama inavyoelezwa katika leseni ya Apache-2.0, itakuwa na leseni mbili kama ilivyo hapo juu, bila sheria na masharti yoyote ya ziada.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












