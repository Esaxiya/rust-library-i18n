#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Tazama [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Tazama [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Tazama [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Tazama [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Tazama [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Tazama [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Leta laini ya kashe iliyo na anwani `p` ukitumia `rw` na `locality` uliyopewa.
///
/// `rw` lazima iwe moja ya:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): kitangulizi kinajiandaa kwa kusoma.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): kitangulizi kinaandaa kuandika.
///
/// `locality` lazima iwe moja ya:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Utiririshaji au utangulizi usio wa muda, kwa data ambayo hutumiwa mara moja tu.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Ingiza kwenye kashe ya kiwango cha 3.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Ingiza kwenye kashe ya kiwango cha 2.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Ingiza kwenye kashe ya kiwango cha 1.
///
/// Maagizo ya kumbukumbu ya kumbukumbu ya mfumo wa kumbukumbu ambayo kumbukumbu hufikia kutoka kwa anwani maalum inaweza kutokea karibu na future.
/// Mfumo wa kumbukumbu unaweza kujibu kwa kuchukua hatua ambazo zinatarajiwa kuharakisha ufikiaji wa kumbukumbu wakati zinatokea, kama vile kupakia kwanza anwani maalum kwenye kache moja au zaidi.
///
/// Kwa sababu ishara hizi ni vidokezo tu, ni halali kwa CPU fulani kutibu maagizo yoyote au ya kutanguliza kama NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Tunatumia instrinsic ya `llvm.prefetch` na `cache type` =1 (data cache).
    // `rw` na `strategy` inategemea vigezo vya kazi.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}