//! Vyombo vinavyoweza kubadilika.
//!
//! Usalama wa kumbukumbu ya Rust unategemea sheria hii: Kwa kupewa kitu `T`, inawezekana tu kuwa na moja ya yafuatayo:
//!
//! - Kuwa na marejeleo kadhaa yasiyoweza kubadilika (`&T`) kwa kitu (pia inajulikana kama **aliasing**).
//! - Kuwa na rejeleo moja linaloweza kubadilika (`&mut T`) kwa kitu (pia kinajulikana kama **mutability**).
//!
//! Hii inalazimishwa na mkusanyaji wa Rust.Walakini, kuna hali ambapo sheria hii haiwezi kubadilika vya kutosha.Wakati mwingine inahitajika kuwa na marejeleo kadhaa kwa kitu na bado ubadilishe.
//!
//! Vyombo vinavyoweza kubadilika vipo ili kuruhusu mabadiliko kwa njia inayodhibitiwa, hata mbele ya jina.Zote [`Cell<T>`] na [`RefCell<T>`] huruhusu kufanya hivyo kwa njia moja.
//! Walakini, sio `Cell<T>` wala `RefCell<T>` sio salama ya uzi (hazitekelezi [`Sync`]).
//! Ikiwa unahitaji kufanya upendeleo na mabadiliko kati ya nyuzi nyingi inawezekana kutumia aina za [`Mutex<T>`], [`RwLock<T>`] au [`atomic`].
//!
//! Maadili ya aina ya `Cell<T>` na `RefCell<T>` yanaweza kubadilishwa kupitia marejeleo ya pamoja (yaani
//! aina ya kawaida ya `&T`), wakati aina nyingi za Rust zinaweza kubadilishwa tu kupitia marejeleo ya kipekee (`&mut T`).
//! Tunasema kwamba `Cell<T>` na `RefCell<T>` hutoa 'mabadiliko ya ndani', tofauti na aina za Rust ambazo zinaonyesha 'mabadiliko ya urithi'.
//!
//! Aina za seli huja katika ladha mbili: `Cell<T>` na `RefCell<T>`.`Cell<T>` kutekeleza mabadiliko ya mambo ya ndani kwa kuhamisha maadili ndani na nje ya `Cell<T>`.
//! Ili kutumia marejeleo badala ya maadili, lazima mtu atumie aina ya `RefCell<T>`, kupata kitufe cha kuandika kabla ya kubadilisha.`Cell<T>` hutoa njia za kupata na kubadilisha thamani ya sasa ya mambo ya ndani:
//!
//!  - Kwa aina zinazotekeleza [`Copy`], njia ya [`get`](Cell::get) inapata thamani ya sasa ya mambo ya ndani.
//!  - Kwa aina zinazotekeleza [`Default`], njia ya [`take`](Cell::take) inachukua nafasi ya thamani ya sasa ya mambo ya ndani na [`Default::default()`] na kurudisha thamani iliyobadilishwa.
//!  - Kwa aina zote, njia ya [`replace`](Cell::replace) inachukua nafasi ya dhamana ya sasa ya mambo ya ndani na kurudisha thamani iliyobadilishwa na njia ya [`into_inner`](Cell::into_inner) hutumia `Cell<T>` na kurudisha thamani ya mambo ya ndani.
//!  Kwa kuongezea, njia ya [`set`](Cell::set) inachukua nafasi ya dhamana ya mambo ya ndani, ikiacha dhamana iliyobadilishwa.
//!
//! `RefCell<T>` hutumia maisha ya Rust kutekeleza 'kukopa kwa nguvu', mchakato ambao mtu anaweza kudai ufikiaji wa muda mfupi, wa kipekee, na wa kubadilika kwa thamani ya ndani.
//! Anakopa kwa `RefCell<T>zinafuatiliwa 'wakati wa kukimbia', tofauti na aina za kumbukumbu za asili za Rust ambazo zinafuatiliwa kabisa kwa kitakwimu, wakati wa kukusanya.
//! Kwa sababu kukopa kwa `RefCell<T>` kuna nguvu inawezekana kujaribu kukopa thamani ambayo tayari imekopwa;wakati hii inatokea husababisha uzi panic.
//!
//! # Wakati wa kuchagua mabadiliko ya mambo ya ndani
//!
//! Uwezo wa kawaida wa kurithi, ambapo mtu lazima awe na ufikiaji wa kipekee wa kubadilisha thamani, ni moja wapo ya vitu muhimu vya lugha ambavyo vinawezesha Rust kufikiria kwa nguvu juu ya kujipachika kwa pointer, kuzuia kitambulisho cha mende.
//! Kwa sababu hiyo, mabadiliko ya urithi hupendekezwa, na mabadiliko ya ndani ni jambo la mwisho.
//! Kwa kuwa aina za seli zinawezesha mabadiliko ambapo ingekataliwa, kuna wakati ambapo mabadiliko ya ndani yanaweza kuwa sawa, au hata *lazima* itumiwe, mfano.
//!
//! * Kuanzisha mabadiliko ya 'inside' ya kitu kisichobadilika
//! * Maelezo ya utekelezaji wa njia zisizobadilika.
//! * Kubadilisha utekelezaji wa [`Clone`].
//!
//! ## Kuanzisha mabadiliko ya 'inside' ya kitu kisichobadilika
//!
//! Wengi walishiriki aina za kiashiria cha smart, pamoja na [`Rc<T>`] na [`Arc<T>`], hutoa kontena ambazo zinaweza kusanidiwa na kugawanywa kati ya pande nyingi.
//! Kwa sababu maadili yaliyomo yanaweza kutengwa, yanaweza kukopwa tu na `&`, sio `&mut`.
//! Bila seli haingewezekana kubadilisha data ndani ya viashiria hivi smart hata kidogo.
//!
//! Ni kawaida sana kisha kuweka `RefCell<T>` ndani ya aina za pointer zilizoshirikiwa ili kurudisha mabadiliko:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Unda kizuizi kipya ili kupunguza wigo wa kukopa kwa nguvu
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Kumbuka kuwa ikiwa hatungeruhusu kukopa kwa hapo awali kwa kashe kutoweka wigo basi kukopa baadaye kungeleta uzi wa nguvu panic.
//!     //
//!     // Hii ndio hatari kubwa ya kutumia `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Kumbuka kuwa mfano huu unatumia `Rc<T>` na sio `Arc<T>`.`Refell<T>`ni ya matukio yaliyopigwa moja.Fikiria kutumia [`RwLock<T>`] au [`Mutex<T>`] ikiwa unahitaji ubadilishaji wa pamoja katika hali ya nyuzi nyingi.
//!
//! ## Maelezo ya utekelezaji wa njia zisizobadilika
//!
//! Wakati mwingine inaweza kuhitajika kutofichua katika API kwamba kuna mabadiliko yanayotokea "under the hood".
//! Hii inaweza kuwa kwa sababu kimantiki operesheni haibadiliki, lakini kwa mfano, kuweka akiba kulazimisha utekelezaji kutekeleza mabadiliko;au kwa sababu lazima utumie mabadiliko ili kutekeleza njia ya trait ambayo hapo awali ilifafanuliwa kuchukua `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Hesabu kubwa inaenda hapa
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Kubadilisha utekelezaji wa `Clone`
//!
//! Hii ni kesi maalum tu, lakini ya kawaida, ya hapo awali: kuficha mabadiliko ya shughuli ambazo zinaonekana kutobadilika.
//! Njia ya [`clone`](Clone::clone) inatarajiwa kutobadilisha thamani ya chanzo, na inatangazwa kuchukua `&self`, sio `&mut self`.
//! Kwa hivyo, mabadiliko yoyote yanayotokea kwa njia ya `clone` lazima yatumie aina za seli.
//! Kwa mfano, [`Rc<T>`] ina hesabu za kumbukumbu zake ndani ya `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Eneo la kumbukumbu linaloweza kubadilika.
///
/// # Examples
///
/// Katika mfano huu, unaweza kuona kwamba `Cell<T>` inawezesha mabadiliko ndani ya muundo usioweza kubadilika.
/// Kwa maneno mengine, inawezesha "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // KOSA: `my_struct` haiwezi kubadilika
/// // my_struct.regular_field =mpya_thamani;
///
/// // KAZI: ingawa `my_struct` haibadiliki, `special_field` ni `Cell`,
/// // ambayo inaweza kubadilishwa kila wakati
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Tazama [module-level documentation](self) kwa zaidi.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Inaunda `Cell<T>`, na thamani ya `Default` ya T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Inaunda `Cell` mpya iliyo na dhamana iliyopewa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Huweka thamani iliyomo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Inabadilishana maadili ya Seli mbili.
    /// Tofauti na `std::mem::swap` ni kwamba kazi hii haiitaji kumbukumbu ya `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // USALAMA: Hii inaweza kuwa hatari ikiwa itaitwa kutoka kwa nyuzi tofauti, lakini `Cell`
        // ni `!Sync` kwa hivyo hii haitatokea.
        // Hii pia haitafanya batili yoyote kuwa batili kwani `Cell` inahakikisha hakuna kitu kingine kitakachoelekeza katika mojawapo ya hizi za `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Inabadilisha thamani iliyomo na `val`, na kurudisha thamani ya zamani iliyomo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // USALAMA: Hii inaweza kusababisha mbio za data ikiwa inaitwa kutoka kwa uzi tofauti,
        // lakini `Cell` ni `!Sync` kwa hivyo hii haitatokea.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps thamani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Hurejesha nakala ya thamani iliyomo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // USALAMA: Hii inaweza kusababisha mbio za data ikiwa inaitwa kutoka kwa uzi tofauti,
        // lakini `Cell` ni `!Sync` kwa hivyo hii haitatokea.
        unsafe { *self.value.get() }
    }

    /// Inasasisha thamani iliyomo kwa kutumia kazi na kurudisha thamani mpya.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Hurejesha kielekezi kibichi kwa data ya msingi katika seli hii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Hurejesha marejeleo yanayoweza kubadilika kwa data ya msingi.
    ///
    /// Simu hii inakopa `Cell` kwa kubadilika (wakati wa kukusanya) ambayo inathibitisha kuwa tunayo rejeleo pekee.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Hurejesha `&Cell<T>` kutoka `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // USALAMA: `&mut` inahakikisha ufikiaji wa kipekee.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Inachukua thamani ya seli, na kuacha `Default::default()` mahali pake.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Hurejesha `&[Cell<T>]` kutoka `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // USALAMA: `Cell<T>` ina mpangilio wa kumbukumbu sawa na `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Eneo la kumbukumbu linaloweza kubadilika na sheria za kukopa zilizoangaliwa kwa nguvu
///
/// Tazama [module-level documentation](self) kwa zaidi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Hitilafu imerejeshwa na [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Hitilafu imerejeshwa na [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Thamani nzuri zinawakilisha idadi ya `Ref` inayotumika.Thamani hasi zinaonyesha idadi ya `RefMut` inayotumika.
// Multiple `RefMut`s inaweza kutumika tu kwa wakati ikiwa inarejelea vipengee tofauti, visivyo na alama ya `RefCell` (kwa mfano, safu tofauti za kipande).
//
// `Ref` na `RefMut` ni maneno mawili kwa saizi, na kwa hivyo hakutakuwa na kutosha `Ref`s au`RefMut`s zilizopo kufurika nusu ya safu ya `usize`.
// Kwa hivyo, `BorrowFlag` labda haitafurika au kufurika.
// Walakini, hii sio dhamana, kwani programu ya ugonjwa inaweza kuunda tena na kisha mem::forget `Ref`s au`RefMut`s.
// Kwa hivyo, nambari zote lazima zichunguze wazi kufurika na kufurika ili kuepusha usalama, au angalau kuishi vizuri ikiwa tukio la kufurika au kufurika hufanyika (kwa mfano, angalia BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Inaunda `RefCell` mpya iliyo na `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Inatumia `RefCell`, kurudisha thamani iliyofungwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Kwa kuwa kazi hii inachukua `self` (`RefCell`) kwa thamani, mkusanyaji huthibitisha kuwa haijakopwa kwa sasa.
        //
        self.value.into_inner()
    }

    /// Inachukua nafasi ya thamani iliyofungwa na mpya, kurudisha dhamana ya zamani, bila kukomesha mojawapo.
    ///
    ///
    /// Kazi hii inalingana na [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ikiwa thamani imekopwa kwa sasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Inabadilisha thamani iliyofungwa na mpya iliyohesabiwa kutoka `f`, ikirudisha thamani ya zamani, bila kuondoa mojawapo.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa thamani imekopwa kwa sasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Inabadilisha thamani iliyofungwa ya `self` na thamani iliyofungwa ya `other`, bila kuondoa moja ya moja.
    ///
    ///
    /// Kazi hii inalingana na [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Kwa kweli hukopa thamani iliyofungwa.
    ///
    /// Kukopa hudumu hadi `Ref` iliyorejeshwa itoke kwenye wigo.
    /// Kukopa nyingi zisizobadilika kunaweza kutolewa kwa wakati mmoja.
    ///
    /// # Panics
    ///
    /// Panics ikiwa thamani imekopwa kwa sasa.
    /// Kwa lahaja isiyo ya kutisha, tumia [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Mfano wa panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Kwa kweli hukopa thamani iliyofungwa, kurudisha kosa ikiwa dhamana imekopwa kwa sasa.
    ///
    ///
    /// Kukopa hudumu hadi `Ref` iliyorejeshwa itoke kwenye wigo.
    /// Kukopa nyingi zisizobadilika kunaweza kutolewa kwa wakati mmoja.
    ///
    /// Hii ndio tofauti isiyo ya kutisha ya [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // USALAMA: `BorrowRef` inahakikisha kuwa kuna ufikiaji usiobadilika tu
            // kwa thamani wakati ulikopwa.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Kwa pamoja hukopa thamani iliyofungwa.
    ///
    /// Kukopa hudumu hadi `RefMut` iliyorejeshwa au `RefMut` zote zinazotokana na wigo wa kutoka.
    ///
    /// Thamani haiwezi kukopwa wakati kukopa huku kunatumika.
    ///
    /// # Panics
    ///
    /// Panics ikiwa thamani imekopwa kwa sasa.
    /// Kwa lahaja isiyo ya kutisha, tumia [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Mfano wa panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Kwa pamoja hukopa thamani iliyofungwa, kurudisha kosa ikiwa dhamana imekopwa kwa sasa.
    ///
    ///
    /// Kukopa hudumu hadi `RefMut` iliyorejeshwa au `RefMut` zote zinazotokana na wigo wa kutoka.
    /// Thamani haiwezi kukopwa wakati kukopa huku kunatumika.
    ///
    /// Hii ndio tofauti isiyo ya kutisha ya [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // USALAMA: `BorrowRef` inahakikishia ufikiaji wa kipekee.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Hurejesha kielekezi kibichi kwa data ya msingi katika seli hii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Hurejesha marejeleo yanayoweza kubadilika kwa data ya msingi.
    ///
    /// Simu hii inakopa `RefCell` kwa usawa (wakati wa kukusanya) kwa hivyo hakuna haja ya ukaguzi wa nguvu.
    ///
    /// Walakini kuwa mwangalifu: njia hii inatarajia `self` iweze kubadilika, ambayo kwa ujumla sio hivyo wakati wa kutumia `RefCell`.
    ///
    /// Angalia njia ya [`borrow_mut`] badala yake ikiwa `self` haiwezi kubadilika.
    ///
    /// Pia, tafadhali fahamu kuwa njia hii ni ya hali maalum tu na kawaida sio ile unayotaka.
    /// Ikiwa kuna shaka, tumia [`borrow_mut`] badala yake.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Tendua athari za walinzi waliovuja kwenye hali ya kukopa ya `RefCell`.
    ///
    /// Simu hii ni sawa na [`get_mut`] lakini inajulikana zaidi.
    /// Inakopa `RefCell` kwa usawa kuhakikisha hakuna kukopa na kisha ibadilisha ufuatiliaji wa serikali kukopa pamoja.
    /// Hii ni muhimu ikiwa ukopaji wa `Ref` au `RefMut` umevuja.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Kwa kweli hukopa thamani iliyofungwa, kurudisha kosa ikiwa dhamana imekopwa kwa sasa.
    ///
    /// # Safety
    ///
    /// Tofauti na `RefCell::borrow`, njia hii sio salama kwa sababu hairudishi `Ref`, na hivyo kuacha bendera ya kukopa bila kuguswa.
    /// Kukopa kwa pamoja `RefCell` wakati kumbukumbu imerejeshwa na njia hii iko hai ni tabia isiyojulikana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // USALAMA: Tunaangalia kuwa hakuna mtu anayeandika kikamilifu sasa, lakini ni hivyo
            // jukumu la mpigaji kuhakikisha kuwa hakuna mtu anayeandika hadi rejeleo lililorejeshwa halitumiki tena.
            // Pia, `self.value.get()` inahusu thamani inayomilikiwa na `self` na kwa hivyo imehakikishiwa kuwa halali kwa maisha ya `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Inachukua thamani iliyofungwa, ikiacha `Default::default()` mahali pake.
    ///
    /// # Panics
    ///
    /// Panics ikiwa thamani imekopwa kwa sasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ikiwa thamani imekopwa kwa sasa.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Inaunda `RefCell<T>`, na thamani ya `Default` ya T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ikiwa thamani katika ama `RefCell` imekopwa kwa sasa.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Kuongeza kukopa kunaweza kusababisha thamani isiyosoma (<=0) katika visa hivi:
            // 1. Ilikuwa <0, yaani kuna maandishi ya kukopa, kwa hivyo hatuwezi kuruhusu usomaji ukopeke kwa sababu ya sheria za kumbukumbu za Rust
            // 2.
            // Ilikuwa isize::MAX (kiwango cha juu cha kukopa kusoma) na ilifurika ndani ya isize::MIN (kiwango cha juu cha kukopa kukopa) kwa hivyo hatuwezi kuruhusu kukopa kusoma zaidi kwa sababu isize haiwezi kuwakilisha kukopa nyingi za kusoma (hii inaweza kutokea tu ikiwa wewe mem::forget zaidi ya kiasi kidogo cha mara kwa mara cha `Ref`s, ambayo sio mazoezi mazuri)
            //
            //
            //
            //
            None
        } else {
            // Kuongeza kukopa kunaweza kusababisha thamani ya kusoma (> 0) katika visa hivi:
            // 1. Ilikuwa=0, yaani haikukopwa, na tunachukua kukopa kusoma kwa kwanza
            // 2. Ilikuwa> 0 na <isize::MAX, yaani
            // kulikuwa na kusoma kwa kukopa, na isize ni kubwa ya kutosha kuwakilisha kuwa na kusoma zaidi kukopa
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Kwa kuwa Ref hii ipo, tunajua bendera ya kukopa ni kukopa kusoma.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Zuia kaunta ya kukopa kutoka kwa kufurika hadi kwa kukopa kwa maandishi.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Hufunga rejeleo lililokopwa kwa thamani kwenye kisanduku cha `RefCell`.
/// Aina ya kufunika kwa thamani isiyoweza kubadilishwa kutoka kwa `RefCell<T>`.
///
/// Tazama [module-level documentation](self) kwa zaidi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Nakala `Ref`.
    ///
    /// `RefCell` tayari imekopwa bila kubadilika, kwa hivyo hii haiwezi kushindwa.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `Ref::clone(...)`.
    /// Utekelezaji wa `Clone` au njia itaingiliana na utumiaji mkubwa wa `r.borrow().clone()` kushikilia yaliyomo kwenye `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Inafanya `Ref` mpya kwa sehemu ya data iliyokopwa.
    ///
    /// `RefCell` tayari imekopwa bila kubadilika, kwa hivyo hii haiwezi kushindwa.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `Ref::map(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Inafanya `Ref` mpya kwa sehemu ya hiari ya data iliyokopwa.
    /// Mlinzi wa asili anarudishwa kama `Err(..)` ikiwa kufungwa kunarudi `None`.
    ///
    /// `RefCell` tayari imekopwa bila kubadilika, kwa hivyo hii haiwezi kushindwa.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `Ref::filter_map(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Inagawanya `Ref` kuwa sehemu nyingi za Ref kwa vifaa anuwai vya data iliyokopwa.
    ///
    /// `RefCell` tayari imekopwa bila kubadilika, kwa hivyo hii haiwezi kushindwa.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `Ref::map_split(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Badilisha kuwa kumbukumbu ya data ya msingi.
    ///
    /// Msingi wa `RefCell` hauwezi kamwe kukopwa kutoka tena na itaonekana kuwa tayari imekopwa bila kubadilika.
    ///
    /// Sio wazo nzuri kuvuja zaidi ya idadi ya marejeleo ya mara kwa mara.
    /// `RefCell` inaweza kukopwa bila kubadilika ikiwa idadi ndogo tu ya uvujaji imetokea kwa jumla.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `Ref::leak(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Kwa kusahau Ref hii tunahakikisha kuwa kaunta ya kukopa katika RefCell haiwezi kurudi kwa UNUSED ndani ya `'b` ya maisha.
        // Kuweka upya hali ya ufuatiliaji wa rejea itahitaji rejeleo la kipekee kwa RefCell iliyokopwa.
        // Hakuna marejeo zaidi yanayoweza kubadilika kutoka kwa seli asili.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Hufanya `RefMut` mpya kwa sehemu ya data iliyokopwa, kwa mfano, lahaja ya enum.
    ///
    /// `RefCell` tayari imekopwa kwa usawa, kwa hivyo hii haiwezi kushindwa.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `RefMut::map(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): rekebisha kukopa-angalia
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Inafanya `RefMut` mpya kwa sehemu ya hiari ya data iliyokopwa.
    /// Mlinzi wa asili anarudishwa kama `Err(..)` ikiwa kufungwa kunarudi `None`.
    ///
    /// `RefCell` tayari imekopwa kwa usawa, kwa hivyo hii haiwezi kushindwa.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `RefMut::filter_map(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): rekebisha kukopa-angalia
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // USALAMA: kazi inashikilia rejeleo la kipekee kwa muda wote
        // ya simu yake kupitia `orig`, na kiboreshaji kinatajwa tu ndani ya simu ya kazi kamwe hairuhusu rejeleo la kipekee kutoroka.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // USALAMA: sawa na hapo juu.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Inagawanya `RefMut` kuwa "RefMut" nyingi kwa vifaa anuwai vya data iliyokopwa.
    ///
    /// `RefCell` ya msingi itabaki ikikopeshwa kwa busara hadi pale "RefMut" zote mbili zitakaporudi nje ya wigo.
    ///
    /// `RefCell` tayari imekopwa kwa usawa, kwa hivyo hii haiwezi kushindwa.
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `RefMut::map_split(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Badilisha kuwa rejeleo linaloweza kubadilika kwa data ya msingi.
    ///
    /// Msingi wa `RefCell` hauwezi kukopwa kutoka tena na itaonekana kuwa tayari imekopwa, na kufanya rejeleo lililorejeshwa kuwa la ndani tu.
    ///
    ///
    /// Hii ni kazi inayohusiana ambayo inahitaji kutumiwa kama `RefMut::leak(...)`.
    /// Njia inaweza kuingilia kati na njia za jina moja kwenye yaliyomo ya `RefCell` iliyotumiwa kupitia `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Kwa kusahau hii BorrowRefMut tunahakikisha kuwa kaunta ya kukopa katika RefCell haiwezi kurudi kwa UNUSED ndani ya `'b` ya maisha.
        // Kuweka upya hali ya ufuatiliaji wa rejea itahitaji rejeleo la kipekee kwa RefCell iliyokopwa.
        // Hakuna marejeleo zaidi yanayoweza kuundwa kutoka kwa seli asili ndani ya wakati huo wa maisha, na kufanya sasa kukopa rejeleo pekee kwa maisha yote iliyobaki.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Tofauti na BorrowRefMut::clone, mpya inaitwa kuunda ya kwanza
        // rejea inayoweza kubadilika, na kwa hivyo hakupaswi kuwa na marejeo yaliyopo.
        // Kwa hivyo, wakati kiini kinazidisha hesabu inayoweza kubadilika, hapa tunaruhusu tu kutoka UNUSED kwenda UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones `BorrowRefMut`.
    //
    // Hii ni halali tu ikiwa kila `BorrowRefMut` inatumiwa kufuatilia rejeleo inayoweza kubadilika kwa anuwai tofauti, isiyo na uwazi wa kitu asili.
    //
    // Hii haimo kwenye implone ya Clone ili nambari isiite hii kabisa.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Zuia kaunta ya kukopa kutoka kwa kufurika.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Aina ya kufunika kwa thamani inayoweza kukopwa kutoka kwa `RefCell<T>`.
///
/// Tazama [module-level documentation](self) kwa zaidi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Ya msingi ya msingi kwa mabadiliko ya ndani katika Rust.
///
/// Ikiwa una kumbukumbu ya `&T`, basi kawaida katika Rust mkusanyaji huboresha kwa kuzingatia maarifa ambayo `&T` inaelekeza kwa data isiyoweza kubadilika.Kubadilisha data hiyo, kwa mfano kwa jina au kwa kusambaza `&T` kuwa `&mut T`, inachukuliwa kama tabia isiyojulikana.
/// `UnsafeCell<T>` huondoa dhamana ya kutobadilika kwa `&T`: rejeleo la pamoja `&UnsafeCell<T>` linaweza kuelekeza kwenye data inayobadilishwa.Hii inaitwa "interior mutability".
///
/// Aina zingine zote zinazoruhusu mabadiliko ya ndani, kama vile `Cell<T>` na `RefCell<T>`, hutumia `UnsafeCell` kwa ndani kufunika data zao.
///
/// Kumbuka kuwa dhamana ya kutobadilika tu kwa marejeleo ya pamoja ndiyo inayoathiriwa na `UnsafeCell`.Dhamana ya pekee ya marejeleo yanayoweza kubadilika hayaathiriwi.Hakuna *njia* ya kisheria ya kupata jina la `&mut`, hata na `UnsafeCell<T>`.
///
/// `UnsafeCell` API yenyewe ni rahisi sana: [`.get()`] inakupa pointer mbichi `*mut T` kwa yaliyomo.Ni hadi _you_ kama mbuni wa kuvinjari kutumia kiashiria hicho kibichi kwa usahihi.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Kanuni sahihi za Rust zinazoangazia ziko kwenye mtiririko, lakini hoja kuu sio za ubishani:
///
/// - Ikiwa utaunda rejeleo salama na maisha `'a` (ama kumbukumbu ya `&T` au `&mut T`) inayoweza kupatikana kwa nambari salama (kwa mfano, kwa sababu uliirudisha), basi haupaswi kufikia data kwa njia yoyote inayopingana na kumbukumbu hiyo ya salio ya `'a`.
/// Kwa mfano, hii inamaanisha kwamba ikiwa utachukua `*mut T` kutoka kwa `UnsafeCell<T>` na kuitupa kwa `&T`, basi data katika `T` lazima ibaki isiyobadilika (modulo data yoyote ya `UnsafeCell` iliyopatikana ndani ya `T`, kwa kweli) hadi wakati wa kumbukumbu ya muda huo uishe.
/// Vivyo hivyo, ikiwa utaunda rejeleo la `&mut T` ambalo limetolewa kwa nambari salama, basi haupaswi kufikia data ndani ya `UnsafeCell` hadi kumbukumbu hiyo iishe.
///
/// - Wakati wote, lazima uepuke mbio za data.Ikiwa nyuzi nyingi zina ufikiaji wa `UnsafeCell` hiyo hiyo, basi maandishi yoyote lazima yawe na uhusiano unaofaa kabla ya uhusiano na ufikiaji mwingine wote (au tumia atomiki).
///
/// Ili kusaidia kwa muundo mzuri, hali zifuatazo zimetangazwa wazi kuwa ni halali kwa nambari moja ya nyuzi:
///
/// 1. Rejeleo la `&T` linaweza kutolewa kwa nambari salama na hapo inaweza kushirikiana na marejeo mengine ya `&T`, lakini sio na `&mut T`
///
/// 2. Rejeleo la `&mut T` linaweza kutolewa kwa nambari salama ikiwa `&mut T` nyingine au `&T` hazipo pamoja nayo.`&mut T` lazima iwe ya kipekee kila wakati.
///
/// Kumbuka kuwa wakati unabadilisha yaliyomo kwenye `&UnsafeCell<T>` (hata wakati kumbukumbu zingine za `&UnsafeCell<T>` zinajulikana kama seli) ni sawa (ikiwa utalazimisha wavamizi hapo juu kwa njia nyingine), bado ni tabia isiyojulikana kuwa na majina mengi ya `&mut UnsafeCell<T>`.
/// Hiyo ni, `UnsafeCell` ni kanga iliyoundwa kuwa na mwingiliano maalum na _shared_ accesses (_i.e._, kupitia rejeleo la `&UnsafeCell<_>`);hakuna uchawi wowote wakati wa kushughulika na _exclusive_ accesses (_e.g._, kupitia `&mut UnsafeCell<_>`): si seli wala thamani iliyofungwa inaweza kutengwa kwa muda wa ile kukopa `&mut`.
///
/// Hii imeonyeshwa na [`.get_mut()`] accessor, ambayo ni _safe_ getter ambayo hutoa `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hapa kuna mfano unaonyesha jinsi ya kubadilisha sauti ya `UnsafeCell<_>` ingawa kuna marejeleo mengi yanayopachika seli:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Pata marejeleo mengi/ya wakati mmoja/ya pamoja kwa `x` sawa.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // USALAMA: ndani ya wigo huu hakuna marejeo mengine kwa yaliyomo `x,
///     // kwa hivyo yetu ni ya kipekee.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- kukopa-+
///     *p1_exclusive += 27; // |
/// } // <---------- haiwezi kupita zaidi ya hatua hii -------------------+
///
/// unsafe {
///     // USALAMA: ndani ya wigo huu hakuna mtu anayetarajia kupata ufikiaji wa kipekee wa yaliyomo `x,
///     // kwa hivyo tunaweza kuwa na ufikiaji wa pamoja mara nyingi wakati huo huo.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Mfano ufuatao unaonyesha ukweli kwamba ufikiaji wa kipekee wa `UnsafeCell<T>` unamaanisha ufikiaji wa kipekee wa `T` yake:
///
/// ```rust
/// #![forbid(unsafe_code)] // na ufikiaji wa kipekee,
///                         // `UnsafeCell` ni kifuniko cha uwazi cha wazi, kwa hivyo hakuna haja ya `unsafe` hapa.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Pata rejeleo la kipekee la kukagua-wakati-wa-X-X.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Kwa rejeleo la kipekee, tunaweza kubadilisha yaliyomo bure.
/// *p_unique.get_mut() = 0;
/// // Au, sawa:
/// x = UnsafeCell::new(0);
///
/// // Wakati tunamiliki thamani, tunaweza kutoa yaliyomo bure.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Inaunda mfano mpya wa `UnsafeCell` ambayo itafunga thamani maalum.
    ///
    ///
    /// Ufikiaji wote wa thamani ya ndani kupitia njia ni `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps thamani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Inapata kiboreshaji kinachoweza kubadilika kwa thamani iliyofungwa.
    ///
    /// Hii inaweza kutupwa kwa kiboreshaji cha aina yoyote.
    /// Hakikisha kuwa ufikiaji ni wa kipekee (hakuna marejeleo yanayotumika, yanayoweza kubadilika au la) unapotuma kwa `&mut T`, na uhakikishe kuwa hakuna mabadiliko au majina yanayoweza kubadilika yanayoendelea wakati wa kutuma kwa `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Tunaweza tu kutupa pointer kutoka `UnsafeCell<T>` hadi `T` kwa sababu ya #[repr(transparent)].
        // Hii inanyonya hadhi maalum ya libstd, hakuna dhamana ya nambari ya mtumiaji kwamba hii itafanya kazi katika matoleo ya future ya mkusanyaji!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Hurejesha marejeleo yanayoweza kubadilika kwa data ya msingi.
    ///
    /// Simu hii inakopa `UnsafeCell` kwa njia inayobadilika (wakati wa kukusanya) ambayo inathibitisha kuwa tunayo rejeleo pekee.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Inapata kiboreshaji kinachoweza kubadilika kwa thamani iliyofungwa.
    /// Tofauti ya [`get`] ni kwamba kazi hii inakubali pointer mbichi, ambayo ni muhimu kuzuia uundaji wa marejeleo ya muda mfupi.
    ///
    /// Matokeo yanaweza kutupwa kwa kiboreshaji cha aina yoyote.
    /// Hakikisha kuwa ufikiaji ni wa kipekee (hakuna marejeleo yanayotumika, yanayoweza kubadilika au la) wakati wa kutuma kwa `&mut T`, na uhakikishe kuwa hakuna mabadiliko au majina yanayoweza kubadilika yanayoendelea wakati wa kutuma `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Uanzishaji wa hatua kwa hatua wa `UnsafeCell` unahitaji `raw_get`, kwani kupiga `get` kunahitaji kuunda rejeleo kwa data isiyojulikana:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Tunaweza tu kutupa pointer kutoka `UnsafeCell<T>` hadi `T` kwa sababu ya #[repr(transparent)].
        // Hii inanyonya hadhi maalum ya libstd, hakuna dhamana ya nambari ya mtumiaji kwamba hii itafanya kazi katika matoleo ya future ya mkusanyaji!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Inaunda `UnsafeCell`, na thamani ya `Default` ya T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}