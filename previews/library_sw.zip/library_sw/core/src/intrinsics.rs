//! Mkusanya asili.
//!
//! Ufafanuzi unaofanana uko katika `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Utekelezaji unaofanana wa X ni `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Wa ndani wa Const
//!
//! Note: mabadiliko yoyote kwa ukali wa asili inapaswa kujadiliwa na timu ya lugha.
//! Hii ni pamoja na mabadiliko katika utulivu wa kikosi.
//!
//! Ili kufanya matumizi ya ndani wakati wa kukusanya, mtu anahitaji kunakili utekelezaji kutoka kwa <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> hadi `compiler/rustc_mir/src/interpret/intrinsics.rs` na kuongeza `#[rustc_const_unstable(feature = "foo", issue = "01234")]` kwa asili.
//!
//!
//! Ikiwa kiasili kinatakiwa kutumiwa kutoka kwa `const fn` na sifa ya `rustc_const_stable`, sifa ya ndani lazima iwe `rustc_const_stable`, pia.
//! Mabadiliko kama hayo hayapaswi kufanywa bila kushauriana na T-lang, kwa sababu inaoka huduma katika lugha ambayo haiwezi kuigwa katika nambari ya watumiaji bila msaada wa mkusanyaji.
//!
//! # Volatiles
//!
//! Maumbile tete hutoa shughuli zinazolengwa kuchukua hatua kwenye kumbukumbu ya I/O, ambayo imehakikishiwa kuwa haijapangiliwa tena na mkusanyaji kwa maumbile mengine yasiyofaa.Tazama nyaraka za LLVM kwenye [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Maumbile ya atomiki hutoa shughuli za kawaida za atomiki kwenye maneno ya mashine, na maagizo mengi ya kumbukumbu.Wanatii semantiki sawa na C++ 11.Tazama nyaraka za LLVM kwenye [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Kuburudisha haraka juu ya kuagiza kumbukumbu:
//!
//! * Pata, kizuizi cha kupata kufuli.Usomaji unaofuata na uandishi hufanyika baada ya kizuizi.
//! * Kutolewa, kikwazo cha kutolewa kwa kufuli.Kutangulia kusoma na kuandika hufanyika kabla ya kizuizi.
//! * Shughuli zinazolingana sawia, zenye kufuata mfululizo zinahakikishiwa kutokea kwa mpangilio.Hii ni hali ya kawaida ya kufanya kazi na aina za atomiki na ni sawa na `volatile` ya Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Uagizaji huu hutumiwa kwa kurahisisha viungo vya ndani-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // USALAMA: tazama `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, maumbile haya huchukua viashiria mbichi kwa sababu hubadilisha kumbukumbu iliyotengwa, ambayo sio halali kwa `&` au `&mut`.
    //

    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::SeqCst`] kama vigezo vyote vya `success` na `failure`.
    ///
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::Acquire`] kama vigezo vyote vya `success` na `failure`.
    ///
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::Release`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::AcqRel`] kama `success` na [`Ordering::Acquire`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::Relaxed`] kama vigezo vyote vya `success` na `failure`.
    ///
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::SeqCst`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::SeqCst`] kama `success` na [`Ordering::Acquire`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::Acquire`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange` kwa kupitisha [`Ordering::AcqRel`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::SeqCst`] kama vigezo vyote vya `success` na `failure`.
    ///
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::Acquire`] kama vigezo vyote vya `success` na `failure`.
    ///
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::Release`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::AcqRel`] kama `success` na [`Ordering::Acquire`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::Relaxed`] kama vigezo vyote vya `success` na `failure`.
    ///
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::SeqCst`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::SeqCst`] kama `success` na [`Ordering::Acquire`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::Acquire`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inahifadhi thamani ikiwa thamani ya sasa ni sawa na thamani ya `old`.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `compare_exchange_weak` kwa kupitisha [`Ordering::AcqRel`] kama `success` na [`Ordering::Relaxed`] kama vigezo vya `failure`.
    /// Kwa mfano, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Inapakia thamani ya sasa ya kielekezi.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `load` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Inapakia thamani ya sasa ya kielekezi.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `load` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Inapakia thamani ya sasa ya kielekezi.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `load` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Inahifadhi thamani katika eneo maalum la kumbukumbu.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `store` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Inahifadhi thamani katika eneo maalum la kumbukumbu.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `store` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Inahifadhi thamani katika eneo maalum la kumbukumbu.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `store` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Inahifadhi thamani katika eneo maalum la kumbukumbu, ikirudisha thamani ya zamani.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `swap` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inahifadhi thamani katika eneo maalum la kumbukumbu, ikirudisha thamani ya zamani.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `swap` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inahifadhi thamani katika eneo maalum la kumbukumbu, ikirudisha thamani ya zamani.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `swap` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inahifadhi thamani katika eneo maalum la kumbukumbu, ikirudisha thamani ya zamani.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `swap` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inahifadhi thamani katika eneo maalum la kumbukumbu, ikirudisha thamani ya zamani.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `swap` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Huongezwa kwa thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_add` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huongezwa kwa thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_add` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huongezwa kwa thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_add` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huongezwa kwa thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_add` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huongezwa kwa thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_add` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ondoa kutoka kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_sub` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ondoa kutoka kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_sub` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ondoa kutoka kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_sub` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ondoa kutoka kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_sub` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ondoa kutoka kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_sub` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise na kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_and` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_and` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_and` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_and` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na kwa thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_and` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina ya [`AtomicBool`] kupitia njia ya `fetch_nand` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina ya [`AtomicBool`] kupitia njia ya `fetch_nand` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina ya [`AtomicBool`] kupitia njia ya `fetch_nand` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina ya [`AtomicBool`] kupitia njia ya `fetch_nand` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina ya [`AtomicBool`] kupitia njia ya `fetch_nand` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise au na thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_or` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise au na thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_or` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise au na thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_or` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise au na thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_or` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise au na thamani ya sasa, kurudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_or` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_xor` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_xor` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_xor` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_xor` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na thamani ya sasa, ikirudisha thamani ya awali.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za [`atomic`] kupitia njia ya `fetch_xor` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Upeo na thamani ya sasa ukitumia ulinganishaji uliosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo na thamani ya sasa ukitumia ulinganishaji uliosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo na thamani ya sasa ukitumia ulinganishaji uliosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo na thamani ya sasa ukitumia ulinganishaji uliosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo na thamani ya sasa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kiwango cha chini na thamani ya sasa kwa kutumia kulinganisha iliyosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia kulinganisha iliyosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia kulinganisha iliyosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia kulinganisha iliyosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia kulinganisha iliyosainiwa.
    ///
    /// Toleo la utulivu wa asili hii inapatikana kwenye aina za nambari zilizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kiwango cha chini na thamani ya sasa kwa kutumia ulinganisho ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia ulinganisho ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia ulinganisho ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia ulinganisho ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kiwango cha chini na thamani ya sasa kwa kutumia ulinganisho ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_min` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Upeo wa thamani ya sasa ukitumia ulinganishaji ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo wa thamani ya sasa ukitumia ulinganishaji ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::Acquire`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo wa thamani ya sasa ukitumia ulinganishaji ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::Release`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo wa thamani ya sasa ukitumia ulinganishaji ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Upeo wa thamani ya sasa ukitumia ulinganishaji ambao haujasainiwa.
    ///
    /// Toleo lililotulia la asili hii linapatikana kwenye aina za nambari zisizosainiwa za [`atomic`] kupitia njia ya `fetch_max` kwa kupitisha [`Ordering::Relaxed`] kama `order`.
    /// Kwa mfano, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kiasili cha `prefetch` ni dokezo kwa jenereta ya nambari ili kuingiza maagizo ya kiambatisho ikiwa inasaidiwa;vinginevyo, ni hakuna-op.
    /// Utangulizi hauna athari juu ya tabia ya programu lakini unaweza kubadilisha sifa zake za utendaji.
    ///
    /// Hoja ya `locality` lazima iwe nambari ya mara kwa mara na ni kibainishi cha eneo la muda kutoka (0), hakuna eneo, hadi (3), kuweka ndani sana kwenye kache.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Kiasili cha `prefetch` ni dokezo kwa jenereta ya nambari ili kuingiza maagizo ya kiambatisho ikiwa inasaidiwa;vinginevyo, ni hakuna-op.
    /// Utangulizi hauna athari juu ya tabia ya programu lakini unaweza kubadilisha sifa zake za utendaji.
    ///
    /// Hoja ya `locality` lazima iwe nambari ya mara kwa mara na ni kibainishi cha eneo la muda kutoka (0), hakuna eneo, hadi (3), kuweka ndani sana kwenye kache.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Kiasili cha `prefetch` ni dokezo kwa jenereta ya nambari ili kuingiza maagizo ya kiambatisho ikiwa inasaidiwa;vinginevyo, ni hakuna-op.
    /// Utangulizi hauna athari juu ya tabia ya programu lakini unaweza kubadilisha sifa zake za utendaji.
    ///
    /// Hoja ya `locality` lazima iwe nambari ya mara kwa mara na ni kibainishi cha eneo la muda kutoka (0), hakuna eneo, hadi (3), kuweka ndani sana kwenye kache.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Kiasili cha `prefetch` ni dokezo kwa jenereta ya nambari ili kuingiza maagizo ya kiambatisho ikiwa inasaidiwa;vinginevyo, ni hakuna-op.
    /// Utangulizi hauna athari juu ya tabia ya programu lakini unaweza kubadilisha sifa zake za utendaji.
    ///
    /// Hoja ya `locality` lazima iwe nambari ya mara kwa mara na ni kibainishi cha eneo la muda kutoka (0), hakuna eneo, hadi (3), kuweka ndani sana kwenye kache.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Uzio wa atomiki.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::fence`] kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Uzio wa atomiki.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::fence`] kwa kupitisha [`Ordering::Acquire`] kama `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Uzio wa atomiki.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::fence`] kwa kupitisha [`Ordering::Release`] kama `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Uzio wa atomiki.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::fence`] kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Kizuizi cha kumbukumbu ya mkusanyaji tu.
    ///
    /// Ufikiaji wa kumbukumbu hautapangiliwa tena kwenye kizuizi hiki na mkusanyaji, lakini hakuna maagizo yatakayotolewa.
    /// Hii inafaa kwa shughuli kwenye uzi huo ambao unaweza kutolewa kabla, kama vile wakati wa kushirikiana na washughulikiaji wa ishara.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::compiler_fence`] kwa kupitisha [`Ordering::SeqCst`] kama `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Kizuizi cha kumbukumbu ya mkusanyaji tu.
    ///
    /// Ufikiaji wa kumbukumbu hautapangiliwa tena kwenye kizuizi hiki na mkusanyaji, lakini hakuna maagizo yatakayotolewa.
    /// Hii inafaa kwa shughuli kwenye uzi huo ambao unaweza kutolewa kabla, kama vile wakati wa kushirikiana na washughulikiaji wa ishara.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::compiler_fence`] kwa kupitisha [`Ordering::Acquire`] kama `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Kizuizi cha kumbukumbu ya mkusanyaji tu.
    ///
    /// Ufikiaji wa kumbukumbu hautapangiliwa tena kwenye kizuizi hiki na mkusanyaji, lakini hakuna maagizo yatakayotolewa.
    /// Hii inafaa kwa shughuli kwenye uzi huo ambao unaweza kutolewa kabla, kama vile wakati wa kushirikiana na washughulikiaji wa ishara.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::compiler_fence`] kwa kupitisha [`Ordering::Release`] kama `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Kizuizi cha kumbukumbu ya mkusanyaji tu.
    ///
    /// Ufikiaji wa kumbukumbu hautapangiliwa tena kwenye kizuizi hiki na mkusanyaji, lakini hakuna maagizo yatakayotolewa.
    /// Hii inafaa kwa shughuli kwenye uzi huo ambao unaweza kutolewa kabla, kama vile wakati wa kushirikiana na washughulikiaji wa ishara.
    ///
    /// Toleo la utulivu wa asili hii inapatikana katika [`atomic::compiler_fence`] kwa kupitisha [`Ordering::AcqRel`] kama `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Asili ya uchawi ambayo hupata maana yake kutoka kwa sifa zilizoambatanishwa na kazi hiyo.
    ///
    /// Kwa mfano, mtiririko wa data hutumia hii kuingiza madai ya tuli ili `rustc_peek(potentially_uninitialized)` iangalie mara mbili kuwa utiririshaji wa data kweli ulihesabu kuwa haujafanywa wakati huo katika mtiririko wa kudhibiti.
    ///
    ///
    /// Maumbile haya hayapaswi kutumiwa nje ya mkusanyaji.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Inahamisha utekelezaji wa mchakato.
    ///
    /// Toleo linalofaa zaidi kwa watumiaji na utulivu wa operesheni hii ni [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Inafahamisha optimizer kwamba hatua hii katika nambari haipatikani, na kuwezesha uboreshaji zaidi.
    ///
    /// NB, hii ni tofauti sana na jumla ya `unreachable!()`: Tofauti na jumla, ambayo panics inapotekelezwa, ni tabia isiyojulikana * kufikia nambari iliyowekwa alama na kazi hii.
    ///
    ///
    /// Toleo la utulivu wa asili hii ni [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Inafahamisha optimizer kuwa hali ni kweli kila wakati.
    /// Ikiwa hali ni ya uwongo, tabia hiyo haijafafanuliwa.
    ///
    /// Hakuna nambari inayotengenezwa kwa asili hii, lakini kiboreshaji kitajaribu kuihifadhi (na hali yake) kati ya pasi, ambazo zinaweza kuingiliana na uboreshaji wa nambari inayowazunguka na kupunguza utendaji.
    /// Haipaswi kutumiwa ikiwa kibadilishaji kinaweza kugunduliwa na kiboreshaji peke yake, au ikiwa hakiwezeshi utaftaji wowote muhimu.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Vidokezo kwa mkusanyaji kwamba hali ya branch inaweza kuwa kweli.
    /// Hurejesha thamani iliyopitishwa kwake.
    ///
    /// Matumizi yoyote isipokuwa na taarifa za `if` labda hayatakuwa na athari.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Vidokezo kwa mkusanyaji kwamba hali ya branch inaweza kuwa ya uwongo.
    /// Hurejesha thamani iliyopitishwa kwake.
    ///
    /// Matumizi yoyote isipokuwa na taarifa za `if` labda hayatakuwa na athari.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Inafanya mtego wa kuvunja, kwa ukaguzi na mtatuaji.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn breakpoint();

    /// Ukubwa wa aina katika ka.
    ///
    /// Hasa haswa, hii ndio malipo ya ka kati ya vitu mfululizo vya aina moja, pamoja na pedi ya mpangilio.
    ///
    ///
    /// Toleo la utulivu wa asili hii ni [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Usawazishaji wa chini wa aina.
    ///
    /// Toleo la utulivu wa asili hii ni [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Mpangilio uliopendelewa wa aina.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ukubwa wa thamani iliyorejelewa kwa ka.
    ///
    /// Toleo la utulivu wa asili hii ni [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Usawazishaji unaohitajika wa thamani iliyotajwa.
    ///
    /// Toleo la utulivu wa asili hii ni [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Inapata kipande cha kamba tuli kilicho na jina la aina.
    ///
    /// Toleo la utulivu wa asili hii ni [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Inapata kitambulisho ambacho ni cha kipekee ulimwenguni kwa aina maalum.
    /// Kazi hii itarudisha thamani sawa kwa aina bila kujali crate yoyote inayoombwa.
    ///
    ///
    /// Toleo la utulivu wa asili hii ni [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Mlinzi wa kazi zisizo salama ambazo haziwezi kutekelezwa ikiwa `T` haikaliki:
    /// Hii itakuwa panic, au haifanyi chochote.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Mlinzi wa kazi zisizo salama ambazo haziwezi kutekelezwa ikiwa `T` hairuhusu uanzishaji wa sifuri: Hii itakuwa panic, au haifanyi chochote.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn assert_zero_valid<T>();

    /// Mlinzi wa kazi zisizo salama ambazo haziwezi kutekelezwa ikiwa `T` ina mifumo kidogo ya batili: Hii itakuwa panic, au haitafanya chochote.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn assert_uninit_valid<T>();

    /// Inapata kumbukumbu ya tuli `Location` inayoonyesha ni wapi iliitwa.
    ///
    /// Fikiria kutumia [`core::panic::Location::caller`](crate::panic::Location::caller) badala yake.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Husogeza thamani nje ya wigo bila kutumia gundi ya kushuka.
    ///
    /// Hii inapatikana tu kwa [`mem::forget_unsized`];`forget` kawaida hutumia `ManuallyDrop` badala yake.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Inatafsiri tena vipande vya thamani ya aina moja kama aina nyingine.
    ///
    /// Aina zote mbili lazima ziwe na saizi sawa.
    /// Wala asili, wala matokeo, inaweza kuwa [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` kimantiki ni sawa na hoja kidogo ya aina moja kwenda nyingine.Inakili bits kutoka kwa thamani ya chanzo hadi kwenye thamani ya marudio, halafu inasahau asili.
    /// Ni sawa na C's `memcpy` chini ya hood, kama `transmute_copy`.
    ///
    /// Kwa sababu `transmute` ni operesheni ya thamani, mpangilio wa * maadili yaliyopitishwa yenyewe sio wasiwasi.
    /// Kama ilivyo na kazi nyingine yoyote, mkusanyaji tayari anahakikisha kuwa `T` na `U` zimepangwa vizuri.
    /// Walakini, wakati wa kupitisha maadili ambayo *inaelekeza mahali pengine*(kama vile viashiria, marejeleo, masanduku…), mpigaji simu lazima ahakikishe upatanisho mzuri wa maadili yaliyoelekezwa.
    ///
    /// `transmute` **salama sana** salama.Kuna idadi kubwa ya njia za kusababisha [undefined behavior][ub] na kazi hii.`transmute` inapaswa kuwa suluhisho la mwisho kabisa.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ina nyaraka za ziada.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Kuna mambo kadhaa ambayo `transmute` ni muhimu sana kwa.
    ///
    /// Kugeuza pointer kuwa kiashiria cha kazi.Hii haibebeki kwa mashine ambapo viashiria vya kazi na viashiria vya data vina saizi tofauti.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Kupanua maisha, au kufupisha maisha ya kawaida.Hii ni ya juu, Rust salama sana!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Usikate tamaa: matumizi mengi ya `transmute` yanaweza kupatikana kupitia njia zingine.
    /// Hapo chini kuna matumizi ya kawaida ya `transmute` ambayo inaweza kubadilishwa na ujenzi salama.
    ///
    /// Kugeuza bytes(`&[u8]`) mbichi hadi `u32`, `f64`, nk.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // tumia `u32::from_ne_bytes` badala yake
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // au tumia `u32::from_le_bytes` au `u32::from_be_bytes` kutaja endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Kubadilisha pointer kuwa `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Tumia kutupwa kwa `as` badala yake
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Kugeuza `*mut T` kuwa `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Tumia rehani badala yake
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Kugeuza `&mut T` kuwa `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Sasa, weka pamoja `as` na utoe tena, kumbuka kufungwa kwa `as` `as` sio kwa mpito
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Kugeuza `&str` kuwa `&[u8]`:
    ///
    /// ```
    /// // hii sio njia nzuri ya kufanya hivi.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Unaweza kutumia `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Au, tumia tu kamba ya baiti, ikiwa una udhibiti wa kamba halisi
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Kugeuza `Vec<&T>` kuwa `Vec<Option<&T>>`.
    ///
    /// Kusambaza aina ya ndani ya yaliyomo kwenye kontena, lazima uhakikishe usikiuke vivamizi vyovyote vya kontena.
    /// Kwa `Vec`, hii inamaanisha kuwa saizi *na mpangilio* wa aina za ndani lazima zilingane.
    /// Vyombo vingine vinaweza kutegemea saizi ya aina, mpangilio, au hata `TypeId`, katika hali ambayo kusambaza hakuwezekani kabisa bila kukiuka vivamizi vya kontena.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // onyesha vector kama tutakavyotumia tena baadaye
    /// let v_clone = v_orig.clone();
    ///
    /// // Kutumia transmute: hii inategemea mpangilio wa data ambao haujabainishwa wa `Vec`, ambayo ni wazo mbaya na inaweza kusababisha Tabia Isiyojulikana.
    /////
    /// // Walakini, sio nakala.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Hii ndiyo njia iliyopendekezwa, salama.
    /// // Inakili vector nzima, hata hivyo, katika safu mpya.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Hii ndio njia isiyo sahihi, isiyo salama ya "transmuting" `Vec`, bila kutegemea mpangilio wa data.
    /// // Badala ya kuita `transmute` halisi, tunafanya kutupia pointer, lakini kwa kugeuza aina ya asili ya ndani (`&i32`) kuwa mpya (`Option<&i32>`), hii ina maonyo yote sawa.
    /////
    /// // Mbali na habari iliyotolewa hapo juu, pia wasiliana na nyaraka za [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Sasisha hii wakati vec_into_raw_parts imetulia.
    ///     // Hakikisha vector asili haijaangushwa.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Utekelezaji wa `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Kuna njia nyingi za kufanya hivyo, na kuna shida nyingi kwa njia ifuatayo ya (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // kwanza: transmute sio aina salama;hundi zote ni kwamba T na
    ///         // U zina ukubwa sawa.
    ///         // Pili, hapa hapa, unayo marejeleo mawili yanayoweza kubadilika yanayoashiria kumbukumbu sawa.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Hii inaondoa aina ya shida za usalama;`&mut *`* itakupa tu `&mut T` kutoka `&mut T` au `*mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Walakini, bado unayo marejeleo mawili yanayoweza kubadilika yanayoashiria kumbukumbu sawa.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Hivi ndivyo maktaba ya kawaida inavyofanya.
    /// // Hii ndiyo njia bora, ikiwa unahitaji kufanya kitu kama hiki
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Hii sasa ina marejeleo matatu yanayoweza kubadilika yanayoonyesha kumbukumbu moja.`slice`, rvalue ret.0, na rvalue ret.1.
    ///         // `slice` haitumiwi kamwe baada ya `let ptr = ...`, na kwa hivyo mtu anaweza kuitibu kama "dead", na kwa hivyo, una vipande viwili halisi.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ingawa hii inafanya ujazo wa ndani kuwa thabiti, tuna nambari fulani ya kitamaduni katika const fn
    // hundi zinazozuia matumizi yake ndani ya `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Hurejesha `true` ikiwa aina halisi iliyotolewa kama `T` inahitaji gundi ya kushuka;inarudi `false` ikiwa aina halisi iliyotolewa kwa vifaa vya `T` `Copy`.
    ///
    ///
    /// Ikiwa aina halisi haiitaji gundi ya kushuka wala kutekeleza `Copy`, basi thamani ya kurudi ya kazi hii haijulikani.
    ///
    /// Toleo la utulivu wa asili hii ni [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Hukokotoa malipo kutoka kwa kielekezi.
    ///
    /// Hii inatekelezwa kama kiasili kuzuia kugeuza na kutoka kwa nambari kamili, kwani ubadilishaji utatupa habari za kutangaza.
    ///
    /// # Safety
    ///
    /// Kiashiria cha kuanzia na kusababisha lazima iwe katika mipaka au baiti moja kupita mwisho wa kitu kilichotengwa.
    /// Ikiwa kiashiria chochote kiko nje ya mipaka au kufurika kwa hesabu kunatokea basi matumizi yoyote zaidi ya thamani iliyorudishwa yatasababisha tabia isiyojulikana.
    ///
    ///
    /// Toleo la utulivu wa asili hii ni [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Hukokotoa malipo kutoka kwa kielekezi, kinachoweza kufungika.
    ///
    /// Hii inatekelezwa kama kiasili kuzuia kugeuza kutoka na kwa nambari kamili, kwani ubadilishaji unazuia uboreshaji fulani.
    ///
    /// # Safety
    ///
    /// Tofauti na asili ya `offset`, asili hii haizuii kiashiria kinachosababisha kuelekeza ndani au moja kwa moja kupita mwisho wa kitu kilichotengwa, na inafungwa na hesabu inayosaidia ya mbili.
    /// Thamani inayosababisha sio halali kutumiwa kufikia kumbukumbu.
    ///
    /// Toleo la utulivu wa asili hii ni [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Sawa na asili inayofaa ya `llvm.memcpy.p0i8.0i8.*`, na saizi ya `count`*`size_of::<T>()` na mpangilio wa
    ///
    /// `min_align_of::<T>()`
    ///
    /// Kigezo tete kimewekwa kwa `true`, kwa hivyo haitaboreshwa nje isipokuwa saizi ni sawa na sifuri.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sawa na asili inayofaa ya `llvm.memmove.p0i8.0i8.*`, na saizi ya `count* size_of::<T>()` na mpangilio wa
    ///
    /// `min_align_of::<T>()`
    ///
    /// Kigezo tete kimewekwa kwa `true`, kwa hivyo haitaboreshwa nje isipokuwa saizi ni sawa na sifuri.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sawa na asili sahihi ya `llvm.memset.p0i8.*`, na saizi ya `count* size_of::<T>()` na mpangilio wa `min_align_of::<T>()`.
    ///
    ///
    /// Kigezo tete kimewekwa kwa `true`, kwa hivyo haitaboreshwa nje isipokuwa saizi ni sawa na sifuri.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Inafanya mzigo tete kutoka kwa pointer ya `src`.
    ///
    /// Toleo la utulivu wa asili hii ni [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Inafanya duka tete kwa pointer ya `dst`.
    ///
    /// Toleo la utulivu wa asili hii ni [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Inafanya mzigo tete kutoka kwa kielekezi cha `src` Kielekezi hakihitajiki kuwa kimepangwa.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Inafanya duka tete kwa pointer ya `dst`.
    /// Kiashiria hazihitajiki kuwa kimepangwa.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Hurejesha mzizi wa mraba wa `f32`
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Hurejesha mzizi wa mraba wa `f64`
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Inaleta `f32` kwa nguvu kamili.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Inaleta `f64` kwa nguvu kamili.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Hurejesha sine ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Hurejesha sine ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Hurejesha cosine ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Hurejesha cosine ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Inaleta `f32` kwa nguvu ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Inaleta `f64` kwa nguvu ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Hurejesha ufafanuzi wa `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Hurejesha ufafanuzi wa `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Inarudi 2 iliyoinuliwa kwa nguvu ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Inarudi 2 iliyoinuliwa kwa nguvu ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Hurejesha logarithm ya asili ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Hurejesha logarithm ya asili ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Hurejesha logarithm ya msingi ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Hurejesha logarithm ya msingi ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Hurejesha logarithm ya msingi ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Hurejesha logarithm ya msingi ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Hurejesha `a * b + c` kwa maadili ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Hurejesha `a * b + c` kwa maadili ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Hurejesha thamani kamili ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Hurejesha thamani kamili ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Hurejesha kiwango cha chini cha thamani mbili za `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Hurejesha kiwango cha chini cha thamani mbili za `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Hurejesha upeo wa thamani mbili za `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Hurejesha upeo wa thamani mbili za `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Inakili ishara kutoka `y` hadi `x` kwa maadili ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Inakili ishara kutoka `y` hadi `x` kwa maadili ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Hurejesha nambari kubwa zaidi kuliko au sawa na `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Hurejesha nambari kubwa zaidi kuliko au sawa na `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Hurejesha nambari ndogo zaidi kuliko au sawa na `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Hurejesha nambari ndogo zaidi kuliko au sawa na `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Hurejesha sehemu kamili ya `f32`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Hurejesha sehemu kamili ya `f64`.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Inarudisha nambari kamili karibu na `f32`.
    /// Inaweza kuibua ubaguzi usio na usawa wa hoja ikiwa hoja sio nambari kamili.
    pub fn rintf32(x: f32) -> f32;
    /// Inarudisha nambari kamili karibu na `f64`.
    /// Inaweza kuibua ubaguzi usio na usawa wa hoja ikiwa hoja sio nambari kamili.
    pub fn rintf64(x: f64) -> f64;

    /// Inarudisha nambari kamili karibu na `f32`.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Inarudisha nambari kamili karibu na `f64`.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Inarudisha nambari kamili karibu na `f32`.Huzungusha visa vya nusu-mbali mbali na sifuri.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Inarudisha nambari kamili karibu na `f64`.Huzungusha visa vya nusu-mbali mbali na sifuri.
    ///
    /// Toleo la utulivu wa asili hii ni
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ongeza kwa kuelea ambayo inaruhusu uboreshaji kulingana na sheria za algebraic.
    /// Inaweza kudhani kuwa pembejeo ni ndogo.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Utoaji wa kuelea unaoruhusu uboreshaji kulingana na sheria za algebraic.
    /// Inaweza kudhani kuwa pembejeo ni ndogo.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Kuzidisha kwa kuelea ambayo inaruhusu uboreshaji kulingana na sheria za algebraic.
    /// Inaweza kudhani kuwa pembejeo ni ndogo.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Mgawanyiko wa kuelea unaoruhusu uboreshaji kulingana na sheria za algebraic.
    /// Inaweza kudhani kuwa pembejeo ni ndogo.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Salio la kuelea ambalo linaruhusu uboreshaji kulingana na sheria za algebraic.
    /// Inaweza kudhani kuwa pembejeo ni ndogo.
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Badilisha na XLX ya LLVM, ambayo inaweza kurudi undef kwa maadili nje ya anuwai
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Imetulia kama [`f32::to_int_unchecked`] na [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Hurejesha idadi ya vipande vilivyowekwa katika aina kamili ya `T`
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `count_ones`.
    /// Kwa mfano,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Hurejesha idadi ya bits zinazoongoza zisizowekwa (zeroes) katika idadi kamili ya `T`.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `leading_zeros`.
    /// Kwa mfano,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` yenye thamani ya `0` itarudisha upana kidogo wa `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Kama `ctlz`, lakini sio salama zaidi kwani inarudisha `undef` inapopewa `x` na thamani `0`.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Hurejesha idadi ya kukokotoa kusitisha vipande (zeroes) katika nambari kamili `T`.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `trailing_zeros`.
    /// Kwa mfano,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` yenye thamani ya `0` itarudisha upana wa `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Kama `cttz`, lakini sio salama zaidi kwani inarudisha `undef` inapopewa `x` na thamani `0`.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inabadilisha ka katika aina kamili ya `T`.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `swap_bytes`.
    /// Kwa mfano,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inabadilisha bits katika aina kamili ya `T`.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `reverse_bits`.
    /// Kwa mfano,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Inafanya nyongeza ya nambari iliyoangaliwa.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `overflowing_add`.
    /// Kwa mfano,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Inafanya utoaji wa nambari kamili
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `overflowing_sub`.
    /// Kwa mfano,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Inafanya kuzidisha nambari kamili
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `overflowing_mul`.
    /// Kwa mfano,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Inafanya mgawanyiko halisi, na kusababisha tabia isiyojulikana ambapo `x % y != 0` au `y == 0` au `x == T::MIN && y == -1`
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Inafanya mgawanyiko ambao haujakaguliwa, na kusababisha tabia isiyojulikana ambapo `y == 0` au `x == T::MIN && y == -1`
    ///
    ///
    /// Vifuniko salama vya asili hii vinapatikana kwenye vitambulisho kamili kupitia njia ya `checked_div`.
    /// Kwa mfano,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Hurejesha salio la mgawanyiko ambao haujakaguliwa, na kusababisha tabia isiyojulikana wakati `y == 0` au `x == T::MIN && y == -1`
    ///
    ///
    /// Vifuniko salama vya asili hii vinapatikana kwenye vitambulisho kamili kupitia njia ya `checked_rem`.
    /// Kwa mfano,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Inafanya mabadiliko ya kushoto yasiyochaguliwa, na kusababisha tabia isiyojulikana wakati `y < 0` au `y >= N`, ambapo N ni upana wa T kwa bits.
    ///
    ///
    /// Vifuniko salama vya asili hii vinapatikana kwenye vitambulisho kamili kupitia njia ya `checked_shl`.
    /// Kwa mfano,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Inafanya mabadiliko ya kulia yasiyochaguliwa, na kusababisha tabia isiyojulikana wakati `y < 0` au `y >= N`, ambapo N ni upana wa T kwa bits.
    ///
    ///
    /// Vifuniko salama vya asili hii vinapatikana kwenye vitambulisho kamili kupitia njia ya `checked_shr`.
    /// Kwa mfano,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Hurejesha matokeo ya nyongeza ambayo haijakaguliwa, na kusababisha tabia isiyojulikana wakati `x + y > T::MAX` au `x + y < T::MIN`.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Hurejesha matokeo ya kutoa bila kukaguliwa, na kusababisha tabia isiyojulikana wakati `x - y > T::MAX` au `x - y < T::MIN`.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Hurejesha matokeo ya kuzidisha bila kukaguliwa, na kusababisha tabia isiyojulikana wakati `x *y > T::MAX` au `x* y < T::MIN`.
    ///
    ///
    /// Kiasili hiki hakina mwenzake thabiti.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Inafanya mzunguko kushoto.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `rotate_left`.
    /// Kwa mfano,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Inafanya kuzunguka kulia.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `rotate_right`.
    /// Kwa mfano,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Inarudi (a + b) mod 2 <sup>N</sup>, ambapo N ni upana wa T kwa bits.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `wrapping_add`.
    /// Kwa mfano,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Inarudi (a, b) mod 2 <sup>N</sup>, ambapo N ni upana wa T kwa bits.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `wrapping_sub`.
    /// Kwa mfano,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Inarudi (a * b) mod 2 <sup>N</sup>, ambapo N ni upana wa T kwa bits.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `wrapping_mul`.
    /// Kwa mfano,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Inashughulikia `a + b`, ikijaa kwa mipaka ya nambari.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `saturating_add`.
    /// Kwa mfano,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Inashughulikia `a - b`, ikijaa kwa mipaka ya nambari.
    ///
    /// Matoleo yaliyotuliwa ya asili hii yanapatikana kwenye vitambulisho kamili kupitia njia ya `saturating_sub`.
    /// Kwa mfano,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Hurejesha thamani ya ubaguzi kwa lahaja katika 'v';
    /// ikiwa `T` haina ubaguzi, inarudi `0`.
    ///
    /// Toleo la utulivu wa asili hii ni [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Hurejesha idadi ya lahaja za aina `T` iliyotupwa kwa `usize`;
    /// ikiwa `T` haina lahaja, inarudi `0`.Tofauti zisizokaliwa zitahesabiwa.
    ///
    /// Toleo la utulivu wa asili hii ni [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch" kujenga ambayo inavutia kiashiria cha kazi `try_fn` na kidokezo cha data `data`.
    ///
    /// Hoja ya tatu ni kazi inayoitwa ikiwa panic inatokea.
    /// Kazi hii inachukua pointer ya data na pointer kwa kitu maalum cha lengo ambacho kilikamatwa.
    ///
    /// Kwa habari zaidi angalia chanzo cha mkusanyaji na utekelezaji wa upatikanaji wa std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Inatoa duka la `!nontemporal` kulingana na LLVM (tazama hati zao).
    /// Labda haitawahi kuwa sawa.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Tazama nyaraka za `<*const T>::offset_from` kwa maelezo.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Tazama nyaraka za `<*const T>::guaranteed_eq` kwa maelezo.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Tazama nyaraka za `<*const T>::guaranteed_ne` kwa maelezo.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Tenga wakati wa kukusanya.Haipaswi kuitwa wakati wa kukimbia.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Baadhi ya kazi zimefafanuliwa hapa kwa sababu kwa bahati mbaya zilipatikana katika moduli hii kwa utulivu.
// Tazama <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` pia inaanguka katika kitengo hiki, lakini haiwezi kufungwa kwa sababu ya kuangalia kuwa `T` na `U` zina saizi sawa.)
//

/// Inakagua ikiwa `ptr` imewekwa sawa kulingana na `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Nakala baiti `count *size_of::<T>()` kutoka `src` hadi `dst`.Chanzo na marudio lazima* zisiingiliane.
///
/// Kwa maeneo ya kumbukumbu ambayo yanaweza kuingiliana, tumia [`copy`] badala yake.
///
/// `copy_nonoverlapping` kimantiki ni sawa na X's [`memcpy`], lakini kwa agizo la hoja lilibadilishwa.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `src` lazima iwe [valid] kwa usomaji wa baiti `count * size_of::<T>()`.
///
/// * `dst` lazima iwe [valid] kwa anaandika ya `count * size_of::<T>()` ka.
///
/// * Zote `src` na `dst` lazima zilinganishwe vizuri.
///
/// * Eneo la kumbukumbu linaloanza saa `src` na saizi ya `count *
///   saizi_ya: :<T>() "baiti haipaswi * kuingiliana na eneo la kumbukumbu linaloanza saa `dst` na saizi sawa.
///
/// Kama [`read`], `copy_nonoverlapping` inaunda nakala kidogo ya `T`, bila kujali kama `T` ni [`Copy`].
/// Ikiwa `T` sio [`Copy`], kwa kutumia *zote mbili* maadili katika eneo linaloanzia `*src` na mkoa unaoanzia `* dst` unaweza [violate memory safety][read-ownership].
///
///
/// Kumbuka kuwa hata ikiwa saizi iliyonakiliwa vyema (`count * size_of: :<T>()") ni `0`, viashiria lazima visivyo vya NULL na vikiwa sawa.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Tumia mwenyewe [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Inahamisha vipengee vyote vya `src` kuwa `dst`, na kuacha `src` tupu.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Hakikisha kuwa `dst` ina uwezo wa kutosha kushikilia `src` yote.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Simu ya kukabiliana ni salama kila wakati kwa sababu `Vec` haitatenga zaidi ya kaiti `isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Punguza `src` bila kuacha yaliyomo.
///         // Tunafanya hivi kwanza, ili kuepuka shida ikiwa kuna kitu zaidi chini ya panics.
///         src.set_len(0);
///
///         // Mikoa miwili haiwezi kuingiliana kwa sababu marejeleo yanayoweza kubadilika hayana jina, na vectors mbili tofauti haziwezi kumiliki kumbukumbu sawa.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Arifu `dst` kwamba sasa inashikilia yaliyomo ya `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Fanya ukaguzi huu tu wakati wa kukimbia
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Sio kuhofia kuweka athari ya codegen ndogo.
        abort();
    }*/

    // USALAMA: mkataba wa usalama wa `copy_nonoverlapping` lazima uwe
    // inashikiliwa na mpigaji simu.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Nakala baiti `count * size_of::<T>()` kutoka `src` hadi `dst`.Chanzo na marudio zinaweza kuingiliana.
///
/// Ikiwa chanzo na marudio hazitaingiliana kamwe, [`copy_nonoverlapping`] inaweza kutumika badala yake.
///
/// `copy` kimantiki ni sawa na X's [`memmove`], lakini kwa agizo la hoja lilibadilishwa.
/// Kuiga hufanyika kana kwamba ka zilinakiliwa kutoka kwa `src` kwenda kwa safu ya muda mfupi kisha ikanakiliwa kutoka safu hadi `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `src` lazima iwe [valid] kwa usomaji wa baiti `count * size_of::<T>()`.
///
/// * `dst` lazima iwe [valid] kwa anaandika ya `count * size_of::<T>()` ka.
///
/// * Zote `src` na `dst` lazima zilinganishwe vizuri.
///
/// Kama [`read`], `copy` inaunda nakala kidogo ya `T`, bila kujali kama `T` ni [`Copy`].
/// Ikiwa `T` sio [`Copy`], kwa kutumia maadili yote katika mkoa unaoanzia `*src` na mkoa unaoanzia `* dst` unaweza [violate memory safety][read-ownership].
///
///
/// Kumbuka kuwa hata ikiwa saizi iliyonakiliwa vyema (`count * size_of: :<T>()") ni `0`, viashiria lazima visivyo vya NULL na vikiwa sawa.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Unda vyema Rust vector kutoka bafa isiyo salama:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` lazima zilinganishwe kwa usahihi kwa aina yake na isiyo ya sifuri.
/// /// * `ptr` lazima iwe halali kwa usomaji wa vipengee vyenye mchanganyiko vya `elts` vya aina `T`.
/// /// * Vipengee hivyo havipaswi kutumiwa baada ya kuita kazi hii isipokuwa `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // USALAMA: Sharti yetu inahakikisha chanzo kimesawazishwa na halali,
///     // na `Vec::with_capacity` inahakikisha kuwa tunayo nafasi inayoweza kutumika ya kuziandika.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // USALAMA: Tuliiunda na uwezo huu mapema,
///     // na `copy` iliyotangulia imeanzisha vitu hivi.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Fanya ukaguzi huu tu wakati wa kukimbia
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Sio kuhofia kuweka athari ya codegen ndogo.
        abort();
    }*/

    // USALAMA: mkataba wa usalama wa `copy` lazima uzingatiwe na anayepiga simu.
    unsafe { copy(src, dst, count) }
}

/// Inaweka baiti za kumbukumbu za `count * size_of::<T>()` kuanzia `dst` hadi `val`.
///
/// `write_bytes` ni sawa na X's [`memset`], lakini inaweka baiti za `count * size_of::<T>()` hadi `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `dst` lazima iwe [valid] kwa anaandika ya `count * size_of::<T>()` ka.
///
/// * `dst` lazima iwe iliyokaa sawa.
///
/// Kwa kuongezea, mpigaji lazima ahakikishe kuwa kuandika kaiti za `count * size_of::<T>()` kwa mkoa uliopewa wa matokeo ya kumbukumbu kwa thamani halali ya `T`.
/// Kutumia eneo la kumbukumbu iliyochapishwa kama `T` ambayo ina thamani batili ya `T` ni tabia isiyojulikana.
///
/// Kumbuka kuwa hata ikiwa saizi iliyonakiliwa vyema (`count * size_of: :<T>()") ni `0`, pointer lazima iwe isiyo ya NULL na iliyokaa vizuri.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Kuunda thamani isiyo sahihi:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Inavuja dhamana iliyoshikiliwa hapo awali kwa kuandika `Box<T>` na kiboreshaji batili.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Kwa wakati huu, kutumia au kuacha matokeo ya `v` katika tabia isiyojulikana.
/// // drop(v); // ERROR
///
/// // Hata kuvuja `v` "uses" hiyo, na kwa hivyo ni tabia isiyojulikana.
/// // mem::forget(v); // ERROR
///
/// // Kwa kweli, `v` ni batili kulingana na vivinjari vya msingi vya mpangilio wa aina, kwa hivyo operesheni yoyote * inayoigusa ni tabia isiyojulikana.
/////
/// // hebu v2 =v;//KOSA
///
/// unsafe {
///     // Wacha sisi badala yake tuweke thamani halali
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Sasa sanduku ni sawa
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // USALAMA: mkataba wa usalama wa `write_bytes` lazima uzingatiwe na anayepiga simu.
    unsafe { write_bytes(dst, val, count) }
}