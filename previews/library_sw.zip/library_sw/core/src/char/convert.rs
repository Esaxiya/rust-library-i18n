//! Uongofu wa tabia.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Inabadilisha `u32` kuwa `char`.
///
/// Kumbuka kuwa ["char"] zote ni halali [`u32`] s, na zinaweza kutupwa kwa moja na
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Walakini, kinyume chake sio kweli: sio halali zote [`u32`] s ni halali [`char`] s.
/// `from_u32()` itarudi `None` ikiwa pembejeo sio thamani halali ya [`char`].
///
/// Kwa toleo lisilo salama la kazi hii ambayo inapuuza hundi hizi, tazama [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Kurudisha `None` wakati uingizaji sio [`char`] halali:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Inabadilisha `u32` kuwa `char`, ikipuuza uhalali.
///
/// Kumbuka kuwa ["char"] zote ni halali [`u32`] s, na zinaweza kutupwa kwa moja na
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Walakini, kinyume chake sio kweli: sio halali zote [`u32`] s ni halali [`char`] s.
/// `from_u32_unchecked()` itapuuza hii, na itatupa kwa upofu kwenye [`char`], ikiwezekana kuunda batili.
///
///
/// # Safety
///
/// Kazi hii sio salama, kwani inaweza kuunda nambari batili za `char`.
///
/// Kwa toleo salama la kazi hii, angalia kazi ya [`from_u32`].
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // USALAMA: mpigaji lazima ahakikishe kuwa `i` ni thamani halali ya char.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Inabadilisha [`char`] kuwa [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Inabadilisha [`char`] kuwa [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char imetupwa kwa thamani ya nambari ya nambari, halafu imeongezwa hadi 64 bit.
        // Tazama [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Inabadilisha [`char`] kuwa [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char imetupwa kwa thamani ya nambari ya nambari, halafu imeongezwa hadi 128 bit.
        // Tazama [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Ramani baiti katika 0x00 ..=0xFF hadi `char` ambayo nambari yake ya nambari ina thamani sawa, katika U + 0000 ..=U + 00FF.
///
/// Unicode imeundwa vile kwamba hii hutambua vyema ka na herufi za usimbuaji ambazo IANA inaita ISO-8859-1.
/// Usimbuaji huu unalingana na ASCII.
///
/// Kumbuka kuwa hii ni tofauti na ISO/IEC 8859-1 aka
/// ISO 8859-1 (iliyo na hyphen moja chini), ambayo inaacha "blanks", maadili ya baiti ambayo hayapewi tabia yoyote.
/// ISO-8859-1 (ile ya IANA) inawapa nambari za kudhibiti C0 na C1.
///
/// Kumbuka kuwa hii pia ni tofauti na Windows-1252 aka
/// nambari ya nambari 1252, ambayo ni superset ISO/IEC 8859-1 ambayo inapeana nafasi (sio zote!) kwa alama za uandishi na herufi anuwai za Kilatini.
///
/// Ili kuchanganya mambo zaidi, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, na `windows-1252` zote ni majina ya jina kubwa la Windows-1252 ambayo inajaza nafasi zilizoachwa wazi na nambari zinazofanana za kudhibiti C0 na C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Inabadilisha [`u8`] kuwa [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Hitilafu ambayo inaweza kurudishwa wakati wa kuchambua char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // USALAMA: iliangalia kuwa ni thamani ya unicode ya kisheria
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Aina ya kosa ilirudi wakati ubadilishaji kutoka u32 hadi char unashindwa.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Inabadilisha nambari katika radix iliyopewa kuwa `char`.
///
/// 'radix' hapa wakati mwingine pia huitwa 'base'.
/// Radix ya mbili inaonyesha nambari ya binary, radix ya kumi, decimal, na radix ya kumi na sita, hexadecimal, kutoa maadili kadhaa ya kawaida.
///
/// Radi za kiholela zinaungwa mkono.
///
/// `from_digit()` itarudi `None` ikiwa pembejeo sio tarakimu katika radix iliyopewa.
///
/// # Panics
///
/// Panics ikiwa imepewa radix kubwa kuliko 36.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Desimali 11 ni nambari moja katika msingi 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Kurudisha `None` wakati pembejeo sio tarakimu:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Kupitisha radix kubwa, na kusababisha panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}