//! weka char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Nambari halali zaidi ya `char` inaweza kuwa nayo.
    ///
    /// `char` ni [Unicode Scalar Value], ambayo inamaanisha kuwa ni [Code Point], lakini ni zile tu zilizo katika anuwai fulani.
    /// `MAX` ni nambari halali zaidi ya nambari hiyo ni [Unicode Scalar Value] halali.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () hutumiwa katika Unicode kuwakilisha kosa la kusimba.
    ///
    /// Inaweza kutokea, kwa mfano, wakati wa kupeana baiti za UTF-8 zilizo mbaya kwa [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Toleo la [Unicode](http://www.unicode.org/) ambalo sehemu za Unicode za njia za `char` na `str` zinategemea.
    ///
    /// Matoleo mapya ya Unicode hutolewa mara kwa mara na baadaye njia zote kwenye maktaba ya kawaida kulingana na Unicode inasasishwa.
    /// Kwa hivyo tabia ya njia kadhaa za `char` na `str` na thamani ya mabadiliko haya ya kila wakati kwa wakati.
    /// Hii haichukuliwi kama mabadiliko ya kuvunja.
    ///
    /// Mpango wa nambari ya toleo umeelezewa katika [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Inaunda iterator juu ya alama za nambari zilizosimbwa za UTF-16 katika `iter`, ikirudisha wasaidizi wasiolipiwa kama `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Decoder ya kupoteza inaweza kupatikana kwa kubadilisha matokeo ya `Err` na herufi mbadala:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Inabadilisha `u32` kuwa `char`.
    ///
    /// Kumbuka kuwa `char` zote ni halali [`u32`] s, na zinaweza kutupwa kwa moja na
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Walakini, kinyume chake sio kweli: sio halali zote [`u32`] s ni halali`char`s.
    /// `from_u32()` itarudi `None` ikiwa pembejeo sio thamani halali ya `char`.
    ///
    /// Kwa toleo lisilo salama la kazi hii ambayo inapuuza hundi hizi, tazama [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Kurudisha `None` wakati uingizaji sio `char` halali:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Inabadilisha `u32` kuwa `char`, ikipuuza uhalali.
    ///
    /// Kumbuka kuwa `char` zote ni halali [`u32`] s, na zinaweza kutupwa kwa moja na
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Walakini, kinyume chake sio kweli: sio halali zote [`u32`] s ni halali`char`s.
    /// `from_u32_unchecked()` itapuuza hii, na itatupa kwa upofu kwenye `char`, ikiwezekana kuunda batili.
    ///
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama, kwani inaweza kuunda nambari batili za `char`.
    ///
    /// Kwa toleo salama la kazi hii, angalia kazi ya [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // USALAMA: mkataba wa usalama lazima uzingatiwe na anayepiga simu.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Inabadilisha nambari katika radix iliyopewa kuwa `char`.
    ///
    /// 'radix' hapa wakati mwingine pia huitwa 'base'.
    /// Radix ya mbili inaonyesha nambari ya binary, radix ya kumi, decimal, na radix ya kumi na sita, hexadecimal, kutoa maadili kadhaa ya kawaida.
    ///
    /// Radi za kiholela zinaungwa mkono.
    ///
    /// `from_digit()` itarudi `None` ikiwa pembejeo sio tarakimu katika radix iliyopewa.
    ///
    /// # Panics
    ///
    /// Panics ikiwa imepewa radix kubwa kuliko 36.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Desimali 11 ni nambari moja katika msingi 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Kurudisha `None` wakati pembejeo sio tarakimu:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Kupitisha radix kubwa, na kusababisha panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Hundi ikiwa `char` ni tarakimu katika radix iliyopewa.
    ///
    /// 'radix' hapa wakati mwingine pia huitwa 'base'.
    /// Radix ya mbili inaonyesha nambari ya binary, radix ya kumi, decimal, na radix ya kumi na sita, hexadecimal, kutoa maadili kadhaa ya kawaida.
    ///
    /// Radi za kiholela zinaungwa mkono.
    ///
    /// Ikilinganishwa na [`is_numeric()`], kazi hii inatambua tu wahusika `0-9`, `a-z` na `A-Z`.
    ///
    /// 'Digit' inaelezewa kuwa wahusika wafuatao tu:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Kwa ufahamu kamili wa 'digit', angalia [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics ikiwa imepewa radix kubwa kuliko 36.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Kupitisha radix kubwa, na kusababisha panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Inabadilisha `char` kuwa nambari katika radix iliyopewa.
    ///
    /// 'radix' hapa wakati mwingine pia huitwa 'base'.
    /// Radix ya mbili inaonyesha nambari ya binary, radix ya kumi, decimal, na radix ya kumi na sita, hexadecimal, kutoa maadili kadhaa ya kawaida.
    ///
    /// Radi za kiholela zinaungwa mkono.
    ///
    /// 'Digit' inaelezewa kuwa wahusika wafuatao tu:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Hurejesha `None` ikiwa `char` hairejeshi nambari katika radix iliyopewa.
    ///
    /// # Panics
    ///
    /// Panics ikiwa imepewa radix kubwa kuliko 36.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Kupitisha matokeo yasiyo ya tarakimu kutofaulu:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Kupitisha radix kubwa, na kusababisha panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // nambari imegawanywa hapa ili kuboresha kasi ya utekelezaji kwa kesi ambapo `radix` ni ya kila wakati na 10 au ndogo
        //
        let val = if likely(radix <= 10) {
            // Ikiwa sio nambari, nambari kubwa kuliko radix itaundwa.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Hurejesha iterator ambayo hutoa hexadecimal Unicode kutoroka kwa herufi kama `char`s.
    ///
    /// Hii itaepuka wahusika na syntax ya Rust ya fomu `\u{NNNNNN}` ambapo `NNNNNN` ni uwakilishi wa hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Kama iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kutumia `println!` moja kwa moja:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Zote ni sawa na:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Kutumia `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // au-ing 1 inahakikisha kuwa kwa c==0 nambari huhesabu kwamba nambari moja inapaswa kuchapishwa na (ambayo ni sawa) inaepuka (31, 32) kufurika
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // fahirisi ya nambari muhimu zaidi ya hex
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Toleo lililopanuliwa la `escape_debug` ambayo inaruhusu kwa hiari kutoroka viboreshaji vya Grapheme.
    /// Hii inatuwezesha kuunda wahusika kama alama zisizo na nafasi bora wakati wako mwanzoni mwa kamba.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Hurejesha iterator ambayo hutoa nambari halisi ya kutoroka ya mhusika kama `char`s.
    ///
    /// Hii itaepuka wahusika sawa na utekelezaji wa `Debug` wa `str` au `char`.
    ///
    ///
    /// # Examples
    ///
    /// Kama iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kutumia `println!` moja kwa moja:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Zote ni sawa na:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Kutumia `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Hurejesha iterator ambayo hutoa nambari halisi ya kutoroka ya mhusika kama `char`s.
    ///
    /// Chaguo-msingi huchaguliwa kwa upendeleo kuelekea utengenezaji wa maandishi ambayo ni halali katika lugha anuwai, pamoja na C++ 11 na lugha sawa za C-familia.
    /// Sheria halisi ni:
    ///
    /// * Kichupo kimetoroka kama `\t`.
    /// * Kurudi kwa gari kunatoroka kama `\r`.
    /// * Kulisha laini kunatoroka kama `\n`.
    /// * Nukuu moja imeokoka kama `\'`.
    /// * Nukuu mara mbili imitoroka kama `\"`.
    /// * Kurudi nyuma kunatoroka kama `\\`.
    /// * Tabia yoyote katika fungu la 'kinachoweza kuchapishwa ASCII' `0x20` .. `0x7e` ikijumuishwa haijatoroka.
    /// * Wahusika wengine wote hupewa kutoroka kwa Unicode ya hexadecimal;tazama [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kama iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kutumia `println!` moja kwa moja:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Zote ni sawa na:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Kutumia `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Hurejesha idadi ya kaiti hii `char` itahitaji ikiwa imesimbwa katika UTF-8.
    ///
    /// Idadi hiyo ya kaa kila wakati iko kati ya 1 na 4, ikijumuisha.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Aina ya `&str` inathibitisha kuwa yaliyomo ni UTF-8, na kwa hivyo tunaweza kulinganisha urefu ambao itachukua ikiwa kila nambari ya nambari iliwakilishwa kama `char` vs katika `&str` yenyewe:
    ///
    ///
    /// ```
    /// // kama chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // zote zinaweza kuwakilishwa kama ka tatu
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // kama &str, hizi mbili zimesimbwa katika UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // tunaweza kuona kwamba huchukua kaiti sita jumla ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... kama &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Hurejesha idadi ya vitengo vya nambari 16-bit hii `char` itahitaji ikiwa imesimbwa katika UTF-16.
    ///
    ///
    /// Tazama nyaraka za [`len_utf8()`] kwa ufafanuzi zaidi wa dhana hii.
    /// Kazi hii ni kioo, lakini kwa UTF-16 badala ya UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Husimba mhusika huyu kama UTF-8 kwenye bafa iliyotolewa, halafu arudishe sehemu ndogo ya bafa ambayo ina herufi iliyosimbwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa bafa haitoshi.
    /// Bafa ya urefu wa nne ni kubwa ya kutosha kusimba `char` yoyote.
    ///
    /// # Examples
    ///
    /// Katika mifano hii yote miwili, 'ß' inachukua kaiti mbili kusimba.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bafa ambayo ni ndogo sana:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // USALAMA: `char` sio mbadala, kwa hivyo hii ni UTF-8 halali.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Huweka herufi hii kama UTF-16 kwenye bafa ya `u16` iliyotolewa, na kisha kurudisha sehemu ndogo ya bafa iliyo na herufi iliyosimbwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa bafa haitoshi.
    /// Bafa ya urefu wa 2 ni kubwa ya kutosha kusimba `char` yoyote.
    ///
    /// # Examples
    ///
    /// Katika mifano hii yote miwili, '𝕊' inachukua `u16` mbili kusimba.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bafa ambayo ni ndogo sana:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Hurejesha `true` ikiwa `char` hii ina mali ya `Alphabetic`.
    ///
    /// `Alphabetic` imeelezewa katika Sura ya 4 (Tabia za Tabia) ya [Unicode Standard] na imeainishwa katika [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // mapenzi ni vitu vingi, lakini sio ya herufi
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Hurejesha `true` ikiwa `char` hii ina mali ya `Lowercase`.
    ///
    /// `Lowercase` imeelezewa katika Sura ya 4 (Tabia za Tabia) ya [Unicode Standard] na imeainishwa katika [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Hati na alama za Kichina anuwai hazina kesi, na kwa hivyo:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Hurejesha `true` ikiwa `char` hii ina mali ya `Uppercase`.
    ///
    /// `Uppercase` imeelezewa katika Sura ya 4 (Tabia za Tabia) ya [Unicode Standard] na imeainishwa katika [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Hati na alama za Kichina anuwai hazina kesi, na kwa hivyo:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Hurejesha `true` ikiwa `char` hii ina mali ya `White_Space`.
    ///
    /// `White_Space` imeainishwa katika [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // nafasi isiyo ya kuvunja
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Hurejesha `true` ikiwa `char` hii inatosheleza ama [`is_alphabetic()`] au [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Hurejesha `true` ikiwa `char` hii ina kitengo cha jumla cha nambari za kudhibiti.
    ///
    /// Nambari za kudhibiti (nambari za nambari na jamii ya jumla ya `Cc`) zimeelezewa katika Sura ya 4 (Sifa za Tabia) ya [Unicode Standard] na imeainishwa katika [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// // U + 009C, KIWANGO CHA STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Hurejesha `true` ikiwa `char` hii ina mali ya `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` imeelezewa katika [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] na imeainishwa katika [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Hurejesha `true` ikiwa `char` hii ina moja ya kategoria za jumla za nambari.
    ///
    /// Makundi ya jumla ya nambari (`Nd` kwa nambari za desimali, `Nl` kwa herufi zinazofanana na herufi, na `No` kwa herufi zingine za nambari) zimetajwa katika [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Inarudisha iterator ambayo hutoa ramani ndogo ya `char` kama moja au zaidi
    /// `char`s.
    ///
    /// Ikiwa `char` hii haina ramani ndogo, iterator hutoa `char` sawa.
    ///
    /// Ikiwa `char` hii ina ramani ndogo ya moja-kwa-moja iliyotolewa na [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator hutoa `char` hiyo.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ikiwa `char` hii inahitaji mazingatio maalum (kwa mfano "char`s nyingi"iterator hutoa"char" (s) zilizotolewa na [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operesheni hii hufanya ramani isiyo na masharti bila ushonaji.Hiyo ni, uongofu haujitegemea muktadha na lugha.
    ///
    /// Katika [Unicode Standard], Sura ya 4 (Sifa za Tabia) inajadili ramani ya kesi kwa jumla na Sura ya 3 (Conformance) inajadili algorithm chaguomsingi ya ubadilishaji wa kesi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kama iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kutumia `println!` moja kwa moja:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Zote ni sawa na:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Kutumia `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Wakati mwingine matokeo ni zaidi ya tabia moja:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Wahusika ambao hawana herufi kubwa na ndogo hubadilisha wenyewe.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Inarudisha iterator ambayo hutoa ramani kubwa ya `char` kama moja au zaidi
    /// `char`s.
    ///
    /// Ikiwa `char` hii haina ramani kubwa, iterator hutoa `char` sawa.
    ///
    /// Ikiwa `char` hii ina ramani kubwa ya moja hadi moja iliyotolewa na [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator hutoa `char` hiyo.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ikiwa `char` hii inahitaji mazingatio maalum (kwa mfano "char`s nyingi"iterator hutoa"char" (s) zilizotolewa na [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operesheni hii hufanya ramani isiyo na masharti bila ushonaji.Hiyo ni, uongofu haujitegemea muktadha na lugha.
    ///
    /// Katika [Unicode Standard], Sura ya 4 (Sifa za Tabia) inajadili ramani ya kesi kwa jumla na Sura ya 3 (Conformance) inajadili algorithm chaguomsingi ya ubadilishaji wa kesi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kama iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kutumia `println!` moja kwa moja:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Zote ni sawa na:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Kutumia `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Wakati mwingine matokeo ni zaidi ya tabia moja:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Wahusika ambao hawana herufi kubwa na ndogo hubadilisha wenyewe.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Kumbuka kwenye eneo
    ///
    /// Kwa Kituruki, sawa na 'i' kwa Kilatini ina aina tano badala ya mbili:
    ///
    /// * 'Dotless': I/ı, wakati mwingine imeandikwa ï
    /// * 'Dotted': İ/i
    ///
    /// Kumbuka kuwa herufi ndogo iliyo na 'i' ni sawa na Kilatini.Kwa hivyo:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Thamani ya `upper_i` hapa inategemea lugha ya maandishi: ikiwa tuko `en-US`, inapaswa kuwa `"I"`, lakini ikiwa tuko `tr_TR`, inapaswa kuwa `"İ"`.
    /// `to_uppercase()` haizingatii hii, na kwa hivyo:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// hushikilia katika lugha zote.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Hukagua ikiwa thamani iko ndani ya anuwai ya ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Hutengeneza nakala ya dhamana katika hali ya juu ya ASCII.
    ///
    /// Barua za ASCII 'a' hadi 'z' zimepangwa kwa 'A' hadi 'Z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kuongeza thamani mahali, tumia [`make_ascii_uppercase()`].
    ///
    /// Ili kuongeza herufi kubwa za ASCII pamoja na herufi zisizo za ASCII, tumia [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Hutengeneza nakala ya dhamana katika kesi yake ndogo ya ASCII.
    ///
    /// Barua za ASCII 'A' hadi 'Z' zimepangwa kwa 'a' hadi 'z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kupunguza thamani mahali, tumia [`make_ascii_lowercase()`].
    ///
    /// Ili kupunguza herufi za ASCII pamoja na herufi zisizo za ASCII, tumia [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Hukagua kuwa maadili mawili ni mechi isiyo na hisia ya ASCII.
    ///
    /// Sawa na `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Inabadilisha aina hii kuwa sawa na hali ya juu ya ASCII.
    ///
    /// Barua za ASCII 'a' hadi 'z' zimepangwa kwa 'A' hadi 'Z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kurudisha thamani mpya ya juu bila kurekebisha ile iliyopo, tumia [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Inabadilisha aina hii kuwa sawa na kesi ya chini ya ASCII.
    ///
    /// Barua za ASCII 'A' hadi 'Z' zimepangwa kwa 'a' hadi 'z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Kurudisha thamani mpya iliyopunguzwa bila kurekebisha iliyopo, tumia [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Hukagua ikiwa thamani ni herufi ya herufi ya ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', au
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Hukagua ikiwa thamani ni herufi kubwa ya ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Hukagua ikiwa thamani ni herufi ndogo ya ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Hukagua ikiwa thamani ni herufi ya alphanumeric ya ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', au
    /// - U + 0061 'a' ..=U + 007A 'z', au
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Hukagua ikiwa thamani ni nambari ya desimali ya ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Inakagua ikiwa thamani ni tarakimu ya hexadecimal ya ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', au
    /// - U + 0041 'A' ..=U + 0046 'F', au
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Hukagua ikiwa thamani ni herufi ya uakifishaji wa ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, au
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, au
    /// - U + 005B ..=U + 0060 ""[\] ^ _``, au
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Hukagua ikiwa thamani ni tabia ya picha ya ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Inakagua ikiwa thamani ni tabia ya nafasi nyeupe ya ASCII:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, au U + 000D CARRIAGE RETURN.
    ///
    /// Rust inatumia [definition of ASCII whitespace][infra-aw] ya WhatWG Infra Standard.Kuna ufafanuzi mwingine kadhaa katika matumizi mapana.
    /// Kwa mfano, [the POSIX locale][pct] inajumuisha U + 000B VERTICAL TAB pamoja na herufi zote hapo juu, lakini-kutoka kwa maelezo sawa sawa [[sheria chaguomsingi ya "field splitting" katika Bourne shell][bfs] inazingatia *tu* SPACE, HORIZONTAL TAB, na LINE FEED kama nafasi nyeupe.
    ///
    ///
    /// Ikiwa unaandika programu ambayo itashughulikia muundo wa faili uliopo, angalia ni nini ufafanuzi wa fomati hiyo ya nafasi nyeupe kabla ya kutumia kazi hii.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Inakagua ikiwa thamani ni tabia ya kudhibiti ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARATOR YA UNIT, au U + 007F DELETE.
    /// Kumbuka kuwa wahusika wengi wa nafasi nyeupe ya ASCII ni wahusika wa kudhibiti, lakini SPACE sio.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Huweka nambari mbichi ya u32 kama UTF-8 kwenye bafa iliyotolewa, halafu inarudisha sehemu ndogo ya bafa iliyo na herufi iliyosimbwa.
///
///
/// Tofauti na `char::encode_utf8`, njia hii pia hushughulikia alama za alama katika anuwai ya kupitisha.
/// (Kuunda `char` katika anuwai ya kupitisha ni UB.) Matokeo yake ni [generalized UTF-8] halali lakini sio UTF-8 halali.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ikiwa bafa haitoshi.
/// Bafa ya urefu wa nne ni kubwa ya kutosha kusimba `char` yoyote.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Huweka nambari mbichi ya u32 kama UTF-16 kwenye bafa ya `u16` iliyotolewa, halafu inarudisha sehemu ndogo ya bafa iliyo na herufi iliyosimbwa.
///
///
/// Tofauti na `char::encode_utf16`, njia hii pia hushughulikia alama za alama katika anuwai ya kupitisha.
/// (Kuunda `char` katika anuwai ya kupitisha ni UB.)
///
/// # Panics
///
/// Panics ikiwa bafa haitoshi.
/// Bafa ya urefu wa 2 ni kubwa ya kutosha kusimba `char` yoyote.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // USALAMA: kila mkono unakagua ikiwa kuna bits za kutosha kuandika
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP huanguka kupitia
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ndege za nyongeza zinavunja surrogates.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}