//! `Clone` trait ya aina ambazo haziwezi 'kunakiliwa kabisa'.
//!
//! Katika Rust, aina zingine rahisi ni "implicitly copyable" na unapozipa au kuzipitisha kama hoja, mpokeaji atapata nakala, akiacha dhamana ya asili mahali hapo.
//! Aina hizi hazihitaji mgao kunakili na hazina wahitimishaji (yaani, hazina masanduku yanayomilikiwa au kutekeleza [`Drop`]), kwa hivyo mkusanyaji huziona kuwa za bei rahisi na salama kunakili.
//!
//! Kwa aina zingine nakala lazima zifanywe wazi, kwa kutekeleza mkutano [`Clone`] trait na kuita njia ya [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Mfano wa matumizi ya kimsingi:
//!
//! ```
//! let s = String::new(); // Aina ya kamba hutumia Clone
//! let copy = s.clone(); // kwa hivyo tunaweza kuibadilisha
//! ```
//!
//! Ili kutekeleza kwa urahisi Clone trait, unaweza pia kutumia `#[derive(Clone)]`.Mfano:
//!
//! ```
//! #[derive(Clone)] // tunaongeza Clone trait kwa Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // na sasa tunaweza kuibadilisha!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait ya kawaida kwa uwezo wa kurudia kitu.
///
/// Inatofautiana na [`Copy`] kwa kuwa [`Copy`] ni dhahiri na haina gharama kubwa, wakati `Clone` huwa wazi kila wakati na inaweza kuwa au sio ghali.
/// Ili kutekeleza sifa hizi, Rust hairuhusu utekeleze tena [`Copy`], lakini unaweza kutekeleza tena `Clone` na utumie nambari ya kiholela.
///
/// Kwa kuwa `Clone` ni ya jumla zaidi kuliko [`Copy`], unaweza kufanya kiotomatiki chochote [`Copy`] kuwa `Clone` pia.
///
/// ## Derivable
///
/// trait hii inaweza kutumika na `#[derive]` ikiwa sehemu zote ni `Clone`.Utekelezaji wa `derive`d wa [`Clone`] huita [`clone`] kwenye kila uwanja.
///
/// [`clone`]: Clone::clone
///
/// Kwa muundo wa generic, `#[derive]` hutumia `Clone` kwa masharti kwa kuongeza `Clone` iliyofungwa kwa vigezo vya generic.
///
/// ```
/// // `derive` kutekeleza Clone ya Kusoma<T>wakati T ni Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ninawezaje kutekeleza `Clone`?
///
/// Aina ambazo ni [`Copy`] zinapaswa kuwa na utekelezaji duni wa `Clone`.Rasmi zaidi:
/// ikiwa `T: Copy`, `x: T`, na `y: &T`, basi `let x = y.clone();` ni sawa na `let x = *y;`.
/// Utekelezaji wa mwongozo unapaswa kuwa mwangalifu kumtia mkombozi huyu;Walakini, nambari isiyo salama haifai kutegemea kuhakikisha usalama wa kumbukumbu.
///
/// Mfano ni muundo wa generic ulioshikilia kiashiria cha kazi.Katika kesi hii, utekelezaji wa `Clone` hauwezi `kupata, lakini unaweza kutekelezwa kama:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Watekelezaji wa ziada
///
/// Mbali na [implementors listed below][impls], aina zifuatazo pia hutumia `Clone`:
///
/// * Aina za kipengee cha kazi (yaani, aina tofauti zilizoainishwa kwa kila kazi)
/// * Aina za kiashiria cha kazi (kwa mfano, `fn() -> i32`)
/// * Aina za safu, kwa saizi zote, ikiwa aina ya bidhaa pia hutumia `Clone` (kwa mfano, `[i32; 123456]`)
/// * Aina za turu, ikiwa kila sehemu pia hutumia `Clone` (kwa mfano, `()`, `(i32, bool)`)
/// * Aina za kufungwa, ikiwa hazijachukua thamani kutoka kwa mazingira au ikiwa maadili haya yote yaliyotekwa hutumia `Clone` wenyewe.
///   Kumbuka kuwa vigeuzi vilivyokamatwa na rejeleo iliyoshirikiwa hutumia `Clone` kila wakati (hata kama mrejeshi hafanyi), wakati vigeuzi vilivyokamatwa na rejeleo inayoweza kubadilika haviwezi kutekeleza `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Hurejesha nakala ya thamani.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str vifaa Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Inafanya zoezi la kunakili kutoka `source`.
    ///
    /// `a.clone_from(&b)` ni sawa na `a = b.clone()` katika utendaji, lakini inaweza kuzidiwa kutumia tena rasilimali za `a` ili kuzuia mgawanyo usiohitajika.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Pata jumla ya kuzalisha impl ya trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): structs hizi hutumiwa tu na#[hupata] kusisitiza kwamba kila sehemu ya aina hutumia Clone au Copy.
//
//
// Structs hizi hazipaswi kuonekana kamwe katika nambari ya mtumiaji.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Utekelezaji wa `Clone` kwa aina za zamani.
///
/// Utekelezaji ambao hauwezi kuelezewa katika Rust unatekelezwa katika `traits::SelectionContext::copy_clone_conditions()` katika `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Marejeleo ya pamoja yanaweza kupangwa, lakini marejeleo yanayoweza kubadilika *hayawezi*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Marejeleo ya pamoja yanaweza kupangwa, lakini marejeleo yanayoweza kubadilika *hayawezi*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}