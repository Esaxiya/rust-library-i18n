//! Aina ambazo zinaweka data kwenye eneo lake kwenye kumbukumbu.
//!
//! Wakati mwingine ni muhimu kuwa na vitu ambavyo vimehakikishiwa kutohama, kwa maana kwamba kuwekwa kwao kwenye kumbukumbu hakubadilika, na kwa hivyo inaweza kutegemewa.
//! Mfano bora wa hali kama hiyo itakuwa kujenga ujenzi wa kibinafsi, kwani kusonga kitu kilicho na viashiria kwa yenyewe kutazibadilisha, ambazo zinaweza kusababisha tabia isiyojulikana.
//!
//! Kwa kiwango cha juu, [`Pin<P>`] inahakikisha kuwa pointee ya aina yoyote ya pointer `P` ina eneo thabiti kwenye kumbukumbu, ikimaanisha kuwa haiwezi kuhamishiwa mahali pengine na kumbukumbu yake haiwezi kusambazwa hadi itakaposhuka.Tunasema kuwa pointee ni "pinned".Vitu hupata ujanja zaidi wakati wa kujadili aina ambazo zinachanganya kubandikwa na data isiyobandikwa;[see below](#projections-and-structural-pinning) kwa maelezo zaidi.
//!
//! Kwa chaguo-msingi, aina zote katika Rust zinahamishika.
//! Rust inaruhusu kupitisha kila aina kwa thamani, na aina za kawaida za nambari-smart kama vile [`Box<T>`] na `&mut T` huruhusu kubadilisha na kuhamisha maadili yaliyomo: unaweza kutoka kwa [`Box<T>`], au unaweza kutumia [`mem::swap`].
//! [`Pin<P>`] inafunga aina ya kielekezi `P`, kwa hivyo [`Pin`]`<<[[Box]]`<T>> `hufanya kazi kama kawaida
//!
//! [`Box<T>`]: when [`Pin`]`<<["Box"]`<T>> `huangushwa, vivyo hivyo yaliyomo, na kumbukumbu hupata
//!
//! kusambazwa.Vivyo hivyo, [`Pin`]`<&mut T>`ni mengi kama `&mut T`.Walakini, [`Pin<P>`] hairuhusu wateja kupata [`Box<T>`] au `&mut T` kwa data iliyobandikwa, ambayo inamaanisha kuwa huwezi kutumia shughuli kama vile [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` inahitaji `&mut T`, lakini hatuwezi kuipata.
//!     // Tumekwama, hatuwezi kubadilishana yaliyomo kwenye marejeleo haya.
//!     // Tunaweza kutumia `Pin::get_unchecked_mut`, lakini hiyo sio salama kwa sababu:
//!     // haturuhusiwi kuitumia kuhamisha vitu nje ya `Pin`.
//! }
//! ```
//!
//! Inafaa kurudia kwamba [`Pin<P>`] haibadilishi ukweli kwamba mkusanyaji wa Rust huzingatia aina zote zinazohamishika.[`mem::swap`] bado inastahiki kwa `T` yoyote.Badala yake, [`Pin<P>`] inazuia maadili kadhaa * (iliyoelekezwa na viashiria vilivyofungwa katika [`Pin<P>`]) isisogezwe kwa kuifanya isiwezekane kupiga njia ambazo zinahitaji `&mut T` juu yao (kama [`mem::swap`]).
//!
//! [`Pin<P>`] inaweza kutumika kufunika aina yoyote ya pointer `P`, na kwa hivyo inaingiliana na [`Deref`] na [`DerefMut`].[`Pin<P>`] ambapo `P: Deref` inapaswa kuzingatiwa kama "`P`-style pointer" kwa `P::Target` iliyobanwa-kwa hivyo, [`Pin`]`<<["Box`]`<T>> `ni kiashiria kinachomilikiwa kwa `T` iliyotiwa alama, na [` Pin`]`<<[[Rc`]`<T>> "ni kiashiria kilichohesabiwa kwa kumbukumbu kwa `T` iliyowekwa.
//! Kwa usahihi, [`Pin<P>`] inategemea utekelezaji wa [`Deref`] na [`DerefMut`] ili wasiondoke kwenye parameter yao ya `self`, na tu watarudisha tena pointer kwa data iliyowekwa wakati wanaitwa kwa pointer iliyowekwa.
//!
//! # `Unpin`
//!
//! Aina nyingi huhamishwa kwa uhuru, hata wakati zimebanwa, kwa sababu haitegemei kuwa na anwani thabiti.Hii ni pamoja na aina zote za kimsingi (kama [`bool`], [`i32`], na marejeleo) pamoja na aina zinazojumuisha aina hizi tu.Aina ambazo hazijali kuhusu kubandika kutekeleza [`Unpin`] auto-trait, ambayo inafuta athari ya [`Pin<P>`].
//! Kwa `T: Unpin`, [`Pin`]`<<[`Box`]`<T>> `na [`Box<T>`] hufanya kazi sawasawa, kama vile [` Pin`]`<&mut T>` na `&mut T`.
//!
//! Kumbuka kuwa kubandika na [`Unpin`] kunaathiri tu aina iliyoelekezwa ya `P::Target`, sio aina ya pointer `P` yenyewe ambayo ilifunikwa na [`Pin<P>`].Kwa mfano, ikiwa [`Box<T>`] ni [`Unpin`] au haina athari kwa tabia ya [`Pin`]`<<"["Box`] `<T>>`(hapa, `T` ni aina iliyoelekezwa).
//!
//! # Mfano: muundo wa kujitegemea
//!
//! Kabla ya kuingia kwenye maelezo zaidi kuelezea dhamana na chaguo zinazohusiana na `Pin<T>`, tunazungumzia mifano kadhaa ya jinsi inaweza kutumika.
//! Jisikie huru kwa [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Hii ni muundo wa kujitegemea kwa sababu sehemu ya kipande inaelekeza kwenye uwanja wa data.
//! // Hatuwezi kumjulisha mkusanyaji kuhusu hilo na kumbukumbu ya kawaida, kwani muundo huu hauwezi kuelezewa na sheria za kawaida za kukopa.
//! //
//! // Badala yake tunatumia kiboreshaji kibichi, ingawa moja ambayo inajulikana sio batili, kwani tunajua inaelekeza kwenye kamba.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Ili kuhakikisha kuwa data haitoi wakati kazi inarudi, tunaiweka kwenye lundo ambapo itakaa kwa maisha ya kitu hicho, na njia pekee ya kuipata ingekuwa kupitia kidokezo kwake.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // sisi huunda tu pointer mara tu data iko mahali vinginevyo itakuwa tayari imehamia kabla hata hatujaanza
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // tunajua hii ni salama kwa sababu kurekebisha uwanja hakuhamishi muundo wote
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Kielekezi kinapaswa kuelekeza kwa eneo sahihi, maadamu muundo haujasonga.
//! //
//! // Wakati huo huo, tuko huru kusogeza pointer karibu.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Kwa kuwa aina yetu haitekelezi Unpin, hii itashindwa kukusanya:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Mfano: orodha inayoingiliwa mara mbili inayoingiliana
//!
//! Katika orodha iliyoingiliwa iliyoingiliwa mara mbili, mkusanyiko hautumii kumbukumbu ya vitu vyenyewe.
//! Ugawaji unadhibitiwa na wateja, na vitu vinaweza kuishi kwenye fremu ya stack ambayo inaishi fupi kuliko mkusanyiko.
//!
//! Ili kufanya kazi hii, kila kitu kina vidokezo kwa mtangulizi wake na mrithi katika orodha.Vipengele vinaweza kuongezwa tu vinapobanwa, kwa sababu kusogeza vitu karibu kungefanya batili zisifanye kazi.Kwa kuongezea, utekelezwaji wa [`Drop`] wa kipengee cha orodha kilichounganishwa utapiga viashiria vya mtangulizi wake na mrithi ili kujiondoa kwenye orodha.
//!
//! Kikubwa, lazima tuwe na uwezo wa kutegemea [`drop`] kuitwa.Ikiwa kitu kinaweza kusambazwa au kutekelezwa vingine bila kuita [`drop`], viashiria ndani yake kutoka kwa vitu vyake vya karibu vitakuwa batili, ambavyo vitavunja muundo wa data.
//!
//! Kwa hivyo, kubandika pia kunakuja na dhamana inayohusiana na ["tone"].
//!
//! # `Drop` guarantee
//!
//! Kusudi la kubandika ni kuweza kutegemea kuwekwa kwa data kadhaa kwenye kumbukumbu.
//! Ili kufanya kazi hii, sio kusonga tu data imezuiliwa;kusambaza, kurudisha tena, au vinginevyo kubatilisha kumbukumbu inayotumiwa kuhifadhi data ni vikwazo pia.
//! Kwa kweli, kwa data iliyopachikwa lazima utumie kibadilishaji kwamba *kumbukumbu yake haitabatilika au kutolewa tena kutoka wakati inapobanwa hadi wakati [`drop`] inaitwa*.Mara tu [`drop`] inarudi au panics, kumbukumbu inaweza kutumika tena.
//!
//! Kumbukumbu inaweza kuwa "invalidated" kwa uhamishaji, lakini pia kwa kuchukua nafasi ya [`Some(v)`] na [`None`], au kupiga [`Vec::set_len`] kwa "kill" vitu kadhaa kutoka kwa vector.Inaweza kurudiwa tena kwa kutumia [`ptr::write`] kuibadilisha tena bila kumwita mwangamizi kwanza.Hakuna hii inaruhusiwa kwa data iliyowekwa bila kupiga [`drop`].
//!
//! Hii ndio haswa aina ya dhamana kwamba orodha inayoingiliwa inayoingiliana kutoka sehemu iliyotangulia inahitaji kufanya kazi kwa usahihi.
//!
//! Ona kwamba dhamana hii haimaanishi kuwa kumbukumbu haivujiki!Bado ni sawa kabisa kutokupigia simu [`drop`] kwenye kipengee kilichopachikwa (kwa mfano, bado unaweza kupiga [`mem::forget`] kwenye [`Pin`]`<<[[Box]]`<T>> `).Katika mfano wa orodha iliyounganishwa mara mbili, kipengee hicho kitakaa tu kwenye orodha.Walakini unaweza usiwe huru au utumie kuhifadhi tena bila kupiga simu"` drop`] *.
//!
//! # `Drop` implementation
//!
//! Ikiwa aina yako hutumia kubandika (kama vile mifano miwili hapo juu), lazima uwe mwangalifu wakati wa kutekeleza [`Drop`].Kazi ya [`drop`] inachukua `&mut self`, lakini hii inaitwa *hata kama aina yako hapo awali ilibanwa*!Ni kana kwamba mkusanyaji huitwa moja kwa moja [`Pin::get_unchecked_mut`].
//!
//! Hii haiwezi kusababisha shida katika nambari salama kwa sababu kutekeleza aina ambayo inategemea kubandika inahitaji nambari isiyo salama, lakini fahamu kuwa kuamua kutumia kubandika katika aina yako (kwa mfano kwa kutekeleza operesheni fulani kwenye [`Pin`]`<<Self>`au [`Pin`] `<&mut Self>` `) ina athari kwa utekelezaji wako wa [`Drop`] vile vile: ikiwa kipengee cha aina yako kingebandikwa, lazima uchukue [`Drop`] kama inachukua kabisa [` Pin`]`<<&mut Kujitegemea>.
//!
//!
//! Kwa mfano, unaweza kutekeleza `Drop` kama ifuatavyo:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ni sawa kwa sababu tunajua thamani hii haitumiki tena baada ya kudondoshwa.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Nambari halisi ya kushuka huenda hapa.
//!         }
//!     }
//! }
//! ```
//!
//! Kazi `inner_drop` ina aina ambayo [`drop`] * inapaswa kuwa nayo, kwa hivyo hii inahakikisha kuwa hutumii `self`/`this` kwa bahati mbaya kwa njia ambayo inakinzana na kubandika.
//!
//! Kwa kuongezea, ikiwa aina yako ni `#[repr(packed)]`, mkusanyaji atahamisha shamba kiotomatiki kuzunguka ili kuweza kuzitupa.Inaweza hata kufanya hivyo kwa uwanja ambao hufanyika kuwa umepangiliwa vya kutosha.Kama matokeo, huwezi kutumia kubandika na aina ya `#[repr(packed)]`.
//!
//! # Makadirio na Kubandika Miundo
//!
//! Wakati wa kufanya kazi na vibanda vilivyobandikwa, swali linaibuka ni jinsi gani mtu anaweza kufikia uwanja wa muundo huo kwa njia ambayo inachukua tu [`Pin`]`<&mut Struct>`.
//! Njia ya kawaida ni kuandika njia za msaidizi (zinazoitwa *makadirio*) ambazo zinageuza [`Pin`]`<&mut Struct>`kuwa kumbukumbu ya uwanja, lakini kumbukumbu hiyo inapaswa kuwa na aina gani?Je! Ni [`Pin`]`<&mut Field>`au `&mut Field`?
//! Swali sawa linaibuka na uwanja wa `enum`, na pia wakati wa kuzingatia aina za container/wrapper kama [`Vec<T>`], [`Box<T>`], au [`RefCell<T>`].
//! (Swali hili linatumika kwa marejeleo yanayoweza kubadilika na ya pamoja, tunatumia tu kesi ya kawaida ya marejeleo yanayoweza kubadilika hapa kwa mfano.)
//!
//! Inabadilika kuwa ni juu ya mwandishi wa muundo wa data kuamua ikiwa makadirio yaliyopachikwa kwa uwanja fulani yanageuka [`Pin`]`<&mut Struct>`into [[Pin`]` <&mut Field> `` or `&mut Field`.Kuna vikwazo hata hivyo, na kikwazo muhimu zaidi ni *uthabiti*:
//! kila uwanja unaweza kuwa *ama* makadirio ya rejeleo lililobandikwa,*au* kuondolewa kwa kubandika kama sehemu ya makadirio.
//! Ikiwa zote zimefanywa kwa uwanja mmoja, hiyo inaweza kuwa mbaya!
//!
//! Kama mwandishi wa muundo wa data unaamua kwa kila uwanja ikiwa unabana "propagates" kwenye uwanja huu au la.
//! Kubandika ambayo inaeneza pia huitwa "structural", kwa sababu inafuata muundo wa aina.
//! Katika vifungu vifuatavyo, tunaelezea maoni ambayo yanapaswa kufanywa kwa chaguo lolote.
//!
//! ## Kubandika * sio muundo wa `field`
//!
//! Inaweza kuonekana kuwa ya kupingana kwamba uwanja wa muundo uliobandikwa unaweza usibanwe, lakini hiyo ndio chaguo rahisi zaidi: ikiwa [`Pin`]`<&mut Field>`haijaundwa kamwe, hakuna kitu kinachoweza kuharibika!Kwa hivyo, ikiwa unaamua kuwa uwanja fulani hauna pinning ya kimuundo, unachohitaji kuhakikisha ni kwamba haujawahi kutaja kumbukumbu ya uwanja huo.
//!
//! Mashamba bila kubana muundo yanaweza kuwa na njia ya makadirio ambayo inageuka [`Pin`]`<&mut Struct>`kuwa `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Hii ni sawa kwa sababu `field` haifikiriwi kamwe kuwa imetumwa.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Unaweza pia `impl Unpin for Struct`*hata kama* aina ya `field` sio [`Unpin`].Nini aina hiyo inafikiria juu ya kubandika sio muhimu wakati hakuna [`Pin`]`<&mut Field>`` imewahi kuumbwa.
//!
//! ## Kubandika * ni muundo wa `field`
//!
//! Chaguo jingine ni kuamua kuwa kubandika ni "structural" kwa `field`, ikimaanisha kwamba ikiwa muundo umepigwa basi shamba pia.
//!
//! Hii inaruhusu kuandika makadirio ambayo huunda [`Pin`]`<&mut Field>``, na hivyo kushuhudia kwamba uwanja umebandikwa:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Hii ni sawa kwa sababu `field` imepachikwa wakati `self` iko.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Walakini, kubandika miundo kunakuja na mahitaji kadhaa ya ziada:
//!
//! 1. Muundo lazima uwe [`Unpin`] tu ikiwa sehemu zote za muundo ni [`Unpin`].Hii ndio chaguo-msingi, lakini [`Unpin`] ni salama trait, kwa hivyo kama mwandishi wa muundo ni jukumu lako *sio* kuongeza kitu kama `impl<T> Unpin for Struct<T>`.
//! (Kumbuka kuwa kuongeza operesheni ya makadirio inahitaji nambari isiyo salama, kwa hivyo ukweli kwamba [`Unpin`] ni trait salama haivunja kanuni kwamba inakubidi tu kuwa na wasiwasi juu ya hii ikiwa utatumia "salama".)
//! 2. Mwangamizi wa muundo lazima asiondoe uwanja wa kimuundo nje ya hoja yake.Hii ndio hatua haswa ambayo ililelewa katika [previous section][drop-impl]: `drop` inachukua `&mut self`, lakini muundo (na kwa hivyo uwanja wake) unaweza kuwa ulibandikwa hapo awali.
//!     Lazima uhakikishe kuwa hausogezi uwanja ndani ya utekelezaji wako wa [`Drop`].
//!     Hasa, kama ilivyoelezewa hapo awali, hii inamaanisha kuwa muundo wako lazima *usiwe*`#[repr(packed)]`.
//!     Tazama sehemu hiyo ya jinsi ya kuandika [`drop`] kwa njia ambayo mkusanyaji anaweza kukusaidia usivunje pinning kwa bahati mbaya.
//! 3. Lazima uhakikishe kuwa unashikilia [`Drop` guarantee][drop-guarantee]:
//!     mara muundo wako ukibanwa, kumbukumbu iliyo na yaliyomo haibatilwi au kusambazwa bila kuwaita waharibu wa yaliyomo.
//!     Hii inaweza kuwa ngumu, kama inavyoshuhudiwa na [`VecDeque<T>`]: mwangamizi wa [`VecDeque<T>`] anaweza kushindwa kuita [`drop`] kwenye vitu vyote ikiwa mmoja wa waharibifu panics.Hii inakiuka dhamana ya [`Drop`], kwa sababu inaweza kusababisha vitu kusambazwa bila mwangamizi wao kuitwa.([`VecDeque<T>`] haina makadirio ya kubandika, kwa hivyo hii haisababishi ujinga.)
//! 4. Haupaswi kutoa shughuli zingine zozote ambazo zinaweza kusababisha data kuhamishwa nje ya uwanja wa muundo wakati aina yako imepachikwa.Kwa mfano, ikiwa muundo una [`Option<T>`] na kuna operesheni kama ya "kuchukua" na aina `fn(Pin<&mut Struct<T>>) -> Option<T>`, operesheni hiyo inaweza kutumika kuhamisha `T` kutoka kwa `Struct<T>` iliyotiwa alama-ambayo inamaanisha kubandika haiwezi kuwa muundo wa uwanja unaoshikilia hii data.
//!
//!     Kwa mfano mgumu zaidi wa kuhamisha data kutoka kwa aina iliyowekwa, fikiria ikiwa [`RefCell<T>`] ilikuwa na njia `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Kisha tunaweza kufanya yafuatayo:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Hili ni janga, inamaanisha tunaweza kubandika kwanza yaliyomo kwenye [`RefCell<T>`] (kwa kutumia `RefCell::get_pin_mut`) kisha tuhamishe yaliyomo kwa kutumia rejeleo inayoweza kubadilika tuliyopata baadaye.
//!
//! ## Examples
//!
//! Kwa aina kama [`Vec<T>`], uwezekano wote (kubana miundo au la) hufanya akili.
//! [`Vec<T>`] iliyo na muundo wa kubandika inaweza kuwa na njia za `get_pin`/`get_pin_mut` kupata marejeleo yaliyowekwa kwenye vitu.Walakini, haingeweza * kuruhusu kupiga simu [`pop`][Vec::pop] kwenye [`Vec<T>`] iliyowekwa kwa sababu hiyo ingeweza kusonga yaliyomo (yaliyopachikwa kimuundo)!Wala haingeruhusu [`push`][Vec::push], ambayo inaweza kuhamia tena na kwa hivyo pia kusonga yaliyomo.
//!
//! [`Vec<T>`] bila kubandika miundo inaweza `impl<T> Unpin for Vec<T>`, kwa sababu yaliyomo hayajawahi kubandikwa na [`Vec<T>`] yenyewe ni sawa na kuhamishwa pia.
//! Wakati huo kubandika hakuna athari kwa vector hata.
//!
//! Katika maktaba ya kawaida, aina za pointer kwa ujumla hazina ubano wa muundo, na kwa hivyo haitoi makadirio ya kubandika.Hii ndio sababu `Box<T>: Unpin` inashikilia kwa `T` yote.
//! Ni jambo la busara kufanya hivi kwa aina za pointer, kwa sababu kuhamisha `Box<T>` sio hoja `T`: [`Box<T>`] inaweza kuhamishwa kwa uhuru (aka `Unpin`) hata kama `T` sio.Kwa kweli, hata [`Pin`]`<<["Box"]`<T>> `na [` Pin`]`<&mut T>` huwa [`Unpin`] wenyewe, kwa sababu hiyo hiyo: yaliyomo (`T`) yamebandikwa, lakini vidokezo vyenyewe vinaweza kuhamishwa bila kuhamisha data iliyowekwa.
//! Kwa [`Box<T>`] na [`Pin`]`<<[[Box"]`<T>>, ikiwa yaliyomo yamebandikwa ni huru kabisa ikiwa kiashiria kimebandikwa, ikimaanisha kubandika * sio muundo.
//!
//! Wakati wa kutekeleza kontena la [`Future`], kawaida utahitaji kubanwa kwa muundo wa futures iliyohifadhiwa, kwani unahitaji kupata rejea zilizobanwa kwao kupiga [`poll`].
//! Lakini ikiwa kiunganishi chako kina data nyingine ambayo haiitaji kubandikwa, unaweza kufanya sehemu hizo sio za kimuundo na kwa hivyo kuzifikia kwa uhuru na rejeleo inayoweza kubadilika hata wakati unayo tu [`Pin`]`<&mut Self>`` (kama kama katika utekelezaji wako wa [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Kiashiria kilichopigwa.
///
/// Hii ni kifuniko karibu na aina ya kiboreshaji ambacho hufanya kiashiria hicho kuwa x01X thamani yake mahali, kuzuia dhamana iliyotajwa na pointer hiyo kuhamishwa isipokuwa itekeleze [`Unpin`].
///
///
/// *Tazama nyaraka za [`pin` module] kwa maelezo ya kubandika.*
///
/// [`pin` module]: self
///
// Note: `Clone` inayopatikana hapo chini husababisha kutokuwa na akili kwani inawezekana kutekeleza
// `Clone` kwa marejeleo yanayoweza kubadilika.
// Tazama <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> kwa maelezo zaidi.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Utekelezaji ufuatao hautokani ili kuepusha maswala ya sauti.
// `&self.pointer` haipaswi kupatikana kwa utekelezaji wa trait isiyoaminika.
//
// Tazama <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> kwa maelezo zaidi.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Jenga `Pin<P>` mpya karibu na kielekezi kwa data fulani ya aina inayotumia [`Unpin`].
    ///
    /// Tofauti na `Pin::new_unchecked`, njia hii ni salama kwa sababu viashiria vya pointer `P` kwa aina ya [`Unpin`], ambayo inafuta dhamana ya pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // USALAMA: Thamani iliyoelekezwa ni `Unpin`, na kwa hivyo haina mahitaji
        // karibu na kubandika.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps `Pin<P>` hii kurudisha pointer ya msingi.
    ///
    /// Hii inahitaji kwamba data iliyo ndani ya `Pin` hii ni [`Unpin`] ili tuweze kupuuza vivamizi vya kubandika wakati wa kuifungua.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Jenga `Pin<P>` mpya karibu na kumbukumbu ya data fulani ya aina ambayo inaweza au haiwezi kutekeleza `Unpin`.
    ///
    /// Ikiwa onyesho la `pointer` kwa aina ya `Unpin`, `Pin::new` inapaswa kutumiwa badala yake.
    ///
    /// # Safety
    ///
    /// Mjenzi huyu sio salama kwa sababu hatuwezi kuhakikisha kuwa data iliyoelekezwa na `pointer` imebandikwa, ikimaanisha kuwa data hiyo haitahamishwa au kuhifadhiwa kwake kutafutwa hadi itakapoangushwa.
    /// Ikiwa `Pin<P>` iliyojengwa haihakikishi kwamba data `P` inaelekezwa imebandikwa, huo ni ukiukaji wa mkataba wa API na inaweza kusababisha tabia isiyojulikana katika shughuli za (safe) baadaye.
    ///
    /// Kwa kutumia njia hii, unafanya promise juu ya utekelezaji wa `P::Deref` na `P::DerefMut`, ikiwa zipo.
    /// Jambo la muhimu zaidi, hawapaswi kuondoka kwenye hoja zao za `self`: `Pin::as_mut` na `Pin::as_ref` wataita `DerefMut::deref_mut` na `Deref::deref`*kwenye kiboreshaji kilichopachikwa* na watarajie njia hizi kushikilia wavamizi wanaobandika.
    /// Kwa kuongezea, kwa kuita njia hii wewe promise kwamba marejeleo ya `P` hayataondolewa tena;haswa, lazima isiwezekane kupata `&mut P::Target` kisha utoke nje ya kumbukumbu hiyo (ukitumia, kwa mfano [`mem::swap`]).
    ///
    ///
    /// Kwa mfano, kupiga `Pin::new_unchecked` kwenye `&'a mut T` sio salama kwa sababu wakati una uwezo wa kuibandika kwa maisha uliyopewa `'a`, hauna uwezo wa kudhibiti ikiwa inabanwa ikibanwa mara tu `'a` inaisha:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Hii inamaanisha pointee `a` haiwezi kusonga tena.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Anwani ya `a` ilibadilishwa kuwa mpangilio wa stack ya "b", kwa hivyo `a` ilihamishwa ingawa hapo awali tulibandika!Tumekiuka mkataba wa kubandika API.
    /////
    /// }
    /// ```
    ///
    /// Thamani, ikishabanwa, lazima ibaki kubanwa milele (isipokuwa aina yake itekeleze `Unpin`).
    ///
    /// Vivyo hivyo, kupiga `Pin::new_unchecked` kwenye `Rc<T>` sio salama kwa sababu kunaweza kuwa na majina kwa data ile ile ambayo haiko chini ya vizuizi vya kubandika:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Hii inamaanisha kwamba mtu anayeelekeza hawezi kusonga tena.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Sasa, ikiwa `x` ilikuwa rejea pekee, tuna rejeleo linaloweza kubadilika kwa data ambayo tulibandika hapo juu, ambayo tunaweza kutumia kuihamisha kama tulivyoona katika mfano uliopita.
    ///     // Tumekiuka mkataba wa kubandika API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Inapata rejeleo lililoshirikiwa lililoshirikiwa kutoka kwa kiashiria hiki kilichobanwa
    ///
    /// Hii ni njia ya kawaida kutoka `&Pin<Pointer<T>>` hadi `Pin<&T>`.
    /// Ni salama kwa sababu, kama sehemu ya mkataba wa `Pin::new_unchecked`, pointee haiwezi kusonga baada ya `Pin<Pointer<T>>` kuundwa.
    ///
    /// "Malicious" Utekelezaji wa `Pointer::Deref` vile vile umeondolewa na mkataba wa `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // USALAMA: angalia nyaraka juu ya kazi hii
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps `Pin<P>` hii kurudisha pointer ya msingi.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama.Lazima uhakikishe kuwa utaendelea kutibu pointer `P` kama ilivyobandikwa baada ya kuita kazi hii, ili wavamizi wa aina ya `Pin` waweze kutunzwa.
    /// Ikiwa nambari inayotumia `P` inayosababisha haiendelei kudumisha vivinjari ambavyo ni ukiukaji wa mkataba wa API na inaweza kusababisha tabia isiyojulikana katika shughuli za (safe) baadaye.
    ///
    ///
    /// Ikiwa data ya msingi ni [`Unpin`], [`Pin::into_inner`] inapaswa kutumika badala yake.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Inapata rejeleo linaloweza kubadilishwa kutoka kwa kiashiria hiki kilichobanwa.
    ///
    /// Hii ni njia ya kawaida kutoka `&mut Pin<Pointer<T>>` hadi `Pin<&mut T>`.
    /// Ni salama kwa sababu, kama sehemu ya mkataba wa `Pin::new_unchecked`, pointee haiwezi kusonga baada ya `Pin<Pointer<T>>` kuundwa.
    ///
    /// "Malicious" Utekelezaji wa `Pointer::DerefMut` vile vile umeondolewa na mkataba wa `Pin::new_unchecked`.
    ///
    /// Njia hii ni muhimu wakati unapiga simu nyingi kwa kazi zinazotumia aina iliyowekwa.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // fanya kitu
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` hutumia `self`, kwa hivyo rejesha tena `Pin<&mut Self>` kupitia `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // USALAMA: angalia nyaraka juu ya kazi hii
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Hupeana thamani mpya kwenye kumbukumbu nyuma ya rejeleo lililobandikwa.
    ///
    /// Hii inaandika data iliyobandikwa, lakini hiyo ni sawa: mwangamizi wake anaendeshwa kabla ya kuandikwa tena, kwa hivyo hakuna dhamana ya kubandika inayokiukwa.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Inaunda pini mpya kwa kuchora ramani ya mambo ya ndani.
    ///
    /// Kwa mfano, ikiwa ungependa kupata `Pin` ya uwanja wa kitu, unaweza kutumia hii kupata ufikiaji wa uwanja huo katika mstari mmoja wa nambari.
    /// Walakini, kuna habari kadhaa na hizi "pinning projections";
    /// tazama nyaraka za [`pin` module] kwa maelezo zaidi juu ya mada hiyo.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama.
    /// Lazima uhakikishe kuwa data unayorudisha haitahama kwa muda mrefu ikiwa dhamana ya hoja haitoi (kwa mfano, kwa sababu ni moja ya uwanja wa thamani hiyo), na pia kwamba hautoi hoja unayoipokea kazi ya mambo ya ndani.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // USALAMA: mkataba wa usalama wa `new_unchecked` lazima uwe
        // inashikiliwa na mpigaji simu.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Hupata rejeleo la pamoja nje ya pini.
    ///
    /// Hii ni salama kwa sababu haiwezekani kutoka kwa kumbukumbu ya pamoja.
    /// Inaweza kuonekana kama kuna suala hapa na mabadiliko ya ndani: kwa kweli,*inawezekana* kuhamisha `T` kutoka `&RefCell<T>`.
    /// Walakini, hii sio shida maadamu hakuna pia `Pin<&T>` inayoelekeza kwa data ile ile, na `RefCell<T>` hairuhusu uunda rejeleo lililobandikwa kwa yaliyomo.
    ///
    /// Tazama majadiliano kwenye ["pinning projections"] kwa maelezo zaidi.
    ///
    /// Note: `Pin` pia hutumia `Deref` kwa lengo, ambayo inaweza kutumika kupata thamani ya ndani.
    /// Walakini, `Deref` hutoa tu kumbukumbu inayoishi kwa muda mrefu kama kukopa kwa `Pin`, sio maisha ya `Pin` yenyewe.
    /// Njia hii inaruhusu kugeuza `Pin` kuwa kumbukumbu na wakati sawa wa maisha kama `Pin` asili.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Inabadilisha `Pin<&mut T>` hii kuwa `Pin<&T>` na maisha sawa.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Inapata rejeleo linaloweza kubadilika kwa data iliyo ndani ya `Pin` hii.
    ///
    /// Hii inahitaji kwamba data iliyo ndani ya `Pin` hii ni `Unpin`.
    ///
    /// Note: `Pin` pia hutumia `DerefMut` kwa data, ambayo inaweza kutumika kupata thamani ya ndani.
    /// Walakini, `DerefMut` hutoa tu kumbukumbu inayoishi kwa muda mrefu kama kukopa kwa `Pin`, sio maisha ya `Pin` yenyewe.
    ///
    /// Njia hii inaruhusu kugeuza `Pin` kuwa kumbukumbu na wakati sawa wa maisha kama `Pin` asili.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Inapata rejeleo linaloweza kubadilika kwa data iliyo ndani ya `Pin` hii.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama.
    /// Lazima uhakikishe kwamba hautawahi kuhamisha data kutoka kwa rejeleo inayoweza kubadilika unayopokea wakati wa kuita kazi hii, ili wavamizi wa aina ya `Pin` waweze kutunzwa.
    ///
    ///
    /// Ikiwa data ya msingi ni `Unpin`, `Pin::get_mut` inapaswa kutumika badala yake.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Jenga pini mpya kwa kuchora ramani ya mambo ya ndani.
    ///
    /// Kwa mfano, ikiwa ungependa kupata `Pin` ya uwanja wa kitu, unaweza kutumia hii kupata ufikiaji wa uwanja huo katika mstari mmoja wa nambari.
    /// Walakini, kuna habari kadhaa na hizi "pinning projections";
    /// tazama nyaraka za [`pin` module] kwa maelezo zaidi juu ya mada hiyo.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama.
    /// Lazima uhakikishe kuwa data unayorudisha haitahama kwa muda mrefu ikiwa dhamana ya hoja haitoi (kwa mfano, kwa sababu ni moja ya uwanja wa thamani hiyo), na pia kwamba hautoi hoja unayoipokea kazi ya mambo ya ndani.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // USALAMA: mpigaji anahusika na kutosonga
        // Thamani kutoka kwa kumbukumbu hii.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // USALAMA: kwani dhamana ya `this` imehakikishiwa kutokuwa nayo
        // imehamishwa, simu hii ya `new_unchecked` iko salama.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Pata kumbukumbu iliyobandikwa kutoka kwa kumbukumbu ya tuli.
    ///
    /// Hii ni salama, kwa sababu `T` imekopwa kwa maisha ya `'static`, ambayo hayaishi kamwe.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // USALAMA: 'tuli kukopa huhakikishia data haitakuwa
        // moved/invalidated mpaka itashuka (ambayo kamwe).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Pata rejeleo linaloweza kubadilishwa kwa kumbukumbu kutoka kwa rejea ya tuli inayoweza kubadilika.
    ///
    /// Hii ni salama, kwa sababu `T` imekopwa kwa maisha ya `'static`, ambayo hayaishi kamwe.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // USALAMA: 'tuli kukopa huhakikishia data haitakuwa
        // moved/invalidated mpaka itashuka (ambayo kamwe).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: hii inamaanisha kuwa impl ya `CoerceUnsized` ambayo inaruhusu kulazimisha kutoka
// aina ambayo huingiza `Deref<Target=impl !Unpin>` kwa aina inayoweka `Deref<Target=Unpin>` haijulikani.
// Uingizaji wowote kama huo labda hauwezi kuwa na sababu kwa sababu zingine, hata hivyo, kwa hivyo tunahitaji tu kutunza kutoruhusu impls kama hizo kutua std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}