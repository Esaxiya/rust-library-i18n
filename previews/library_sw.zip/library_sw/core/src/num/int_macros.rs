macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Thamani ndogo zaidi ambayo inaweza kuwakilishwa na aina hii kamili.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Thamani kubwa zaidi ambayo inaweza kuwakilishwa na aina hii kamili.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Ukubwa wa aina hii kamili kwa vipande.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Hubadilisha kipande cha kamba katika msingi uliopewa kuwa nambari kamili.
        ///
        /// Kamba hiyo inatarajiwa kuwa ishara ya hiari ya `+` au `-` ikifuatiwa na nambari.
        /// Nyeupe inayoongoza na inayofuatilia inawakilisha kosa.
        /// Nambari ni seti ndogo ya wahusika, kulingana na `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Kazi hii panics ikiwa `radix` haiko katika masafa kutoka 2 hadi 36.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Hurejesha idadi ya zile zilizo katika uwakilishi wa binary wa `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Hurejesha idadi ya sifuri katika uwakilishi wa binary wa `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Hurejesha idadi ya sifuri zinazoongoza katika uwakilishi wa binary wa `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Hurejesha idadi ya sifuri zinazofuatilia katika uwakilishi wa binary wa `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Hurejesha idadi ya zile zinazoongoza katika uwakilishi wa binary wa `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Hurejesha idadi ya zile zinazofuatilia katika uwakilishi wa binary wa `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Huhamisha bits kushoto na kiasi maalum, `n`, ikifunga vipande vilivyokatwa hadi mwisho wa nambari inayosababisha.
        ///
        ///
        /// Tafadhali kumbuka hii sio operesheni sawa na ile ya kuhama `<<`!
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Huhamisha bits kulia na kiasi maalum, `n`, ikifunga vipande vilivyokatwa mwanzoni mwa nambari inayosababisha.
        ///
        ///
        /// Tafadhali kumbuka hii sio operesheni sawa na ile ya kuhama `>>`!
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Inabadilisha agizo la baiti la nambari.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// hebu m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Inabadilisha mpangilio wa bits katika nambari kamili.
        /// Kidogo muhimu huwa kidogo muhimu zaidi, pili kidogo-muhimu inakuwa ya pili muhimu zaidi, nk.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// hebu m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Inabadilisha nambari kutoka kwa endian kubwa kwenda kwa umakini wa walengwa.
        ///
        /// Kwenye endian kubwa hii haifai.Kwenye endian kidogo ka hubadilishwa.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ikiwa cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } mwingine {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Inabadilisha nambari kutoka kwa endian kidogo kwenda kwa ulengaji wa lengo.
        ///
        /// Kwenye endian kidogo hii sio ya op.Kwenye endian kubwa ka hubadilishana.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ikiwa cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } mwingine {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Inabadilisha `self` kuwa endian kubwa kutoka kwa umakini wa walengwa.
        ///
        /// Kwenye endian kubwa hii haifai.Kwenye endian kidogo ka hubadilishwa.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ikiwa cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } mwingine { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // au isiwe?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Inabadilisha `self` kuwa endian kidogo kutoka kwa lengo la lengo.
        ///
        /// Kwenye endian kidogo hii sio ya op.Kwenye endian kubwa ka hubadilishana.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ikiwa cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } mwingine { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Ukiongeza nambari kamili.
        /// Inashughulikia `self + rhs`, inarudi `None` ikiwa kufurika kulitokea.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kuongeza nambari isiyofuatiliwa.Inashughulikia `self + rhs`, kudhani kufurika hakuwezi kutokea.
        /// Hii inasababisha tabia isiyojulikana wakati
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kuchunguzwa kwa nambari kamili.
        /// Inashughulikia `self - rhs`, inarudi `None` ikiwa kufurika kulitokea.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Uondoaji wa nambari kamili ambao haujakaguliwa.Inashughulikia `self - rhs`, kudhani kufurika hakuwezi kutokea.
        /// Hii inasababisha tabia isiyojulikana wakati
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Imezingatia kuzidisha idadi kamili.
        /// Inashughulikia `self * rhs`, inarudi `None` ikiwa kufurika kulitokea.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kuzidishwa kwa nambari kamili.Inashughulikia `self * rhs`, kudhani kufurika hakuwezi kutokea.
        /// Hii inasababisha tabia isiyojulikana wakati
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Imegawanya nambari kamili.
        /// Inashughulikia `self / rhs`, inarudi `None` ikiwa `rhs == 0` au mgawanyiko unasababisha kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // USALAMA: div kwa sifuri na kwa INT_MIN zimeangaliwa hapo juu
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Imegawanyika mgawanyiko wa Euclidean.
        /// Inashughulikia `self.div_euclid(rhs)`, inarudi `None` ikiwa `rhs == 0` au mgawanyiko unasababisha kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Salio la nambari iliyokaguliwa.
        /// Inashughulikia `self % rhs`, inarudi `None` ikiwa `rhs == 0` au mgawanyiko unasababisha kufurika.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // USALAMA: div kwa sifuri na kwa INT_MIN zimeangaliwa hapo juu
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Zilizosalia za Euclidean zilizosalia.
        /// Inashughulikia `self.rem_euclid(rhs)`, inarudi `None` ikiwa `rhs == 0` au mgawanyiko unasababisha kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Kukanusha kukaguliwa.
        /// Inashughulikia `-self`, inarudi `None` ikiwa `self == MIN`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Umekagua zamu kushoto.
        /// Inashughulikia `self << rhs`, inarudi `None` ikiwa `rhs` ni kubwa kuliko au sawa na idadi ya bits katika `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Imebaki zamu ya kulia.
        /// Inashughulikia `self >> rhs`, inarudi `None` ikiwa `rhs` ni kubwa kuliko au sawa na idadi ya bits katika `self`.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Iliangalia thamani kamili.
        /// Inashughulikia `self.abs()`, inarudi `None` ikiwa `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Uhakiki wa ukaguzi.
        /// Inashughulikia `self.pow(exp)`, inarudi `None` ikiwa kufurika kulitokea.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // kwani exp!=0, mwishowe exp lazima iwe 1.
            // Shughulika na kipeo cha mwisho cha kionyeshi kando, kwani kutengeneza msingi baadaye sio lazima na inaweza kusababisha kufurika bila lazima.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Kuongeza nambari kamili.
        /// Inashughulikia `self + rhs`, ikijaa kwenye mipaka ya nambari badala ya kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Utoaji wa nambari kamili.
        /// Inashughulikia `self - rhs`, ikijaa kwenye mipaka ya nambari badala ya kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Kueneza nambari kamili.
        /// Inashughulikia `-self`, inarudi `MAX` ikiwa `self == MIN` badala ya kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Kueneza thamani kamili.
        /// Inashughulikia `self.abs()`, inarudi `MAX` ikiwa `self == MIN` badala ya kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Kueneza kuzidisha nambari.
        /// Inashughulikia `self * rhs`, ikijaa kwenye mipaka ya nambari badala ya kufurika.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Kueneza kwa idadi kamili.
        /// Inashughulikia `self.pow(exp)`, ikijaa kwenye mipaka ya nambari badala ya kufurika.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Kufunga nyongeza ya (modular).
        /// Inashughulikia `self + rhs`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Kufunga utoaji wa (modular).
        /// Inashughulikia `self - rhs`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Kufunga kuzidisha (modular).
        /// Inashughulikia `self * rhs`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Kufunga mgawanyiko wa (modular).Inashughulikia `self / rhs`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// Kesi pekee ambapo kufunika kama kunaweza kutokea ni wakati mtu hugawanya `MIN / -1` kwa aina iliyosainiwa (ambapo `MIN` ni thamani hasi ya aina hiyo);hii ni sawa na `-MIN`, dhamana nzuri ambayo ni kubwa sana kuweza kuwakilisha katika aina hiyo.
        /// Katika hali kama hiyo, kazi hii inarudi `MIN` yenyewe.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Kufunga mgawanyiko wa Euclidean.
        /// Inashughulikia `self.div_euclid(rhs)`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// Kufunga kutatokea tu kwa `MIN / -1` kwa aina iliyosainiwa (ambapo `MIN` ni thamani hasi ndogo ya aina hiyo).
        /// Hii ni sawa na `-MIN`, thamani nzuri ambayo ni kubwa sana kuweza kuwakilisha katika aina hiyo.
        /// Katika kesi hii, njia hii inarudi `MIN` yenyewe.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Kufunga salio la (modular).Inashughulikia `self % rhs`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// Kufunga-karibu vile kamwe hakutokea kihesabu;mabaki ya utekelezaji hufanya `x % y` kuwa batili kwa `MIN / -1` kwa aina iliyosainiwa (ambapo `MIN` ni thamani hasi ndogo).
        ///
        /// Katika hali kama hiyo, kazi hii inarudi `0`.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Kufunga salio la Euclidean.Inashughulikia `self.rem_euclid(rhs)`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// Kufunga kutatokea tu kwa `MIN % -1` kwa aina iliyosainiwa (ambapo `MIN` ni thamani hasi ndogo ya aina hiyo).
        /// Katika kesi hii, njia hii inarudi 0.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Kufunga ukanushaji wa (modular).Inashughulikia `-self`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// Kesi pekee ambapo kufunika kama kunaweza kutokea ni wakati mtu anapuuza `MIN` kwa aina iliyosainiwa (ambapo `MIN` ni thamani hasi ya aina hiyo);hii ni thamani chanya ambayo ni kubwa mno kuweza kuwakilisha katika aina hiyo.
        /// Katika hali kama hiyo, kazi hii inarudi `MIN` yenyewe.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-bure kidogo kuhama kushoto;hutoa `self << mask(rhs)`, ambapo `mask` huondoa bits yoyote ya juu ya `rhs` ambayo itasababisha mabadiliko kuzidi upana wa aina hiyo.
        ///
        /// Kumbuka kuwa hii sio * sawa na mzunguko-kushoto;RHS ya kuhama-kushoto kushoto inazuiliwa kwa anuwai ya aina, badala ya bits kuhamishwa kutoka kwa LHS ikirudishwa upande mwingine.
        ///
        /// Aina za nambari za zamani zote hutekeleza kazi ya [`rotate_left`](Self::rotate_left), ambayo inaweza kuwa kile unachotaka badala yake.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // USALAMA: kujificha na bitsize ya aina huhakikisha kuwa hatuhama
            // nje ya mipaka
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-bure kuhama-kulia;hutoa `self >> mask(rhs)`, ambapo `mask` huondoa bits yoyote ya juu ya `rhs` ambayo itasababisha mabadiliko kuzidi upana wa aina hiyo.
        ///
        /// Kumbuka kuwa hii sio sawa na mzunguko-kulia;RHS ya kulia-kuhama-kulia imezuiliwa kwa anuwai ya aina, badala ya bits kuhamishwa kutoka kwa LHS kurudishwa hadi mwisho mwingine.
        ///
        /// Aina za nambari za zamani zote hutekeleza kazi ya [`rotate_right`](Self::rotate_right), ambayo inaweza kuwa kile unachotaka badala yake.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // USALAMA: kujificha na bitsize ya aina huhakikisha kuwa hatuhama
            // nje ya mipaka
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Kufunga thamani kamili ya (modular).Inashughulikia `self.abs()`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// Kesi pekee ambapo kufunika kama kunaweza kutokea ni wakati mtu anachukua dhamana kamili ya thamani hasi ndogo ya aina;hii ni thamani chanya ambayo ni kubwa mno kuweza kuwakilisha katika aina hiyo.
        /// Katika hali kama hiyo, kazi hii inarudi `MIN` yenyewe.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Hukadiria thamani kamili ya `self` bila kufunga au kuhofia yoyote.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Kufunga ufafanuzi wa (modular).
        /// Inashughulikia `self.pow(exp)`, ikizunguka kwenye mpaka wa aina hiyo.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // kwani exp!=0, mwishowe exp lazima iwe 1.
            // Shughulika na kipeo cha mwisho cha kionyeshi kando, kwani kutengeneza msingi baadaye sio lazima na inaweza kusababisha kufurika bila lazima.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Huhesabu `self` + `rhs`
        ///
        /// Hurejesha Tuple ya nyongeza pamoja na boolean inayoonyesha ikiwa kufurika kwa hesabu kungetokea.
        /// Ikiwa kufurika kungefanyika basi thamani iliyofungwa inarudishwa.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Huhesabu `self`, `rhs`
        ///
        /// Hurejesha turuba ya kutoa pamoja na boolean inayoonyesha ikiwa kufurika kwa hesabu kungetokea.
        /// Ikiwa kufurika kungefanyika basi thamani iliyofungwa inarudishwa.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Huhesabu kuzidisha kwa `self` na `rhs`.
        ///
        /// Hurejesha turuba ya kuzidisha pamoja na boolean inayoonyesha ikiwa kufurika kwa hesabu kungetokea.
        /// Ikiwa kufurika kungefanyika basi thamani iliyofungwa inarudishwa.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, kweli));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Hukokotoa msuluhishi wakati `self` imegawanywa na `rhs`.
        ///
        /// Hurejesha Tuple ya msuluhishi pamoja na boolean inayoonyesha ikiwa kufurika kwa hesabu kungetokea.
        /// Ikiwa kufurika kungetokea basi ubinafsi unarudishwa.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Huhesabu mgawo wa mgawanyiko wa Euclidean `self.div_euclid(rhs)`.
        ///
        /// Hurejesha Tuple ya msuluhishi pamoja na boolean inayoonyesha ikiwa kufurika kwa hesabu kungetokea.
        /// Ikiwa kufurika kungetokea basi `self` inarejeshwa.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Huhesabu salio wakati `self` imegawanywa na `rhs`.
        ///
        /// Hurejesha Tuple ya salio baada ya kugawanya pamoja na boolean inayoonyesha ikiwa kufurika kwa hesabu kungetokea.
        /// Ikiwa kufurika kungetokea basi 0 inarudishwa.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Mabaki ya Euclidean yaliyofurika.Huhesabu `self.rem_euclid(rhs)`.
        ///
        /// Hurejesha Tuple ya salio baada ya kugawanya pamoja na boolean inayoonyesha ikiwa kufurika kwa hesabu kungetokea.
        /// Ikiwa kufurika kungetokea basi 0 inarudishwa.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Inabadilisha ubinafsi, kufurika ikiwa hii ni sawa na thamani ya chini.
        ///
        /// Hurejesha Tuple ya toleo lililopuuzwa la kibinafsi pamoja na boolean inayoonyesha ikiwa kufurika kulitokea.
        /// Ikiwa `self` ndio thamani ya chini (kwa mfano, `i32::MIN` kwa maadili ya aina `i32`), basi kiwango cha chini kitarudishwa tena na `true` itarejeshwa kwa kufurika kutokea.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Huhama kibinafsi iliyoachwa na bits `rhs`.
        ///
        /// Hurejesha Tuple ya toleo lililobadilishwa la kibinafsi pamoja na boolean inayoonyesha ikiwa thamani ya kuhama ilikuwa kubwa kuliko au sawa na idadi ya bits.
        /// Ikiwa thamani ya kuhama ni kubwa sana, basi thamani imefungwa (N-1) ambapo N ni idadi ya bits, na dhamana hii hutumiwa kutekeleza mabadiliko.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, kweli));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Huhamia kwa kulia kwa bits `rhs`.
        ///
        /// Hurejesha Tuple ya toleo lililobadilishwa la kibinafsi pamoja na boolean inayoonyesha ikiwa thamani ya kuhama ilikuwa kubwa kuliko au sawa na idadi ya bits.
        /// Ikiwa thamani ya kuhama ni kubwa sana, basi thamani imefungwa (N-1) ambapo N ni idadi ya bits, na dhamana hii hutumiwa kutekeleza mabadiliko.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, kweli));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Inashughulikia thamani kamili ya `self`.
        ///
        /// Hurejesha Tuple ya toleo kamili la ubinafsi pamoja na boolean inayoonyesha ikiwa kufurika kulitokea.
        /// Ikiwa ubinafsi ndio thamani ya chini
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// basi thamani ya chini itarudishwa tena na kweli itarudishwa kwa utaftaji unaotokea.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Inainua ubinafsi kwa nguvu ya `exp`, ikitumia ufafanuzi kwa mraba.
        ///
        /// Hurejesha Tuple ya ufafanuzi pamoja na bool inayoonyesha ikiwa kufurika kulitokea.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, kweli));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Sehemu ya mwanzo ya kuhifadhi matokeo ya kufurika_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // kwani exp!=0, mwishowe exp lazima iwe 1.
            // Shughulika na kipeo cha mwisho cha kionyeshi kando, kwani kutengeneza msingi baadaye sio lazima na inaweza kusababisha kufurika bila lazima.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Inainua ubinafsi kwa nguvu ya `exp`, ikitumia ufafanuzi kwa mraba.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // kwani exp!=0, mwishowe exp lazima iwe 1.
            // Shughulika na kipeo cha mwisho cha kionyeshi kando, kwani kutengeneza msingi baadaye sio lazima na inaweza kusababisha kufurika bila lazima.
            //
            //
            acc * base
        }

        /// Hukokotoa mgawo wa mgawanyiko wa Euclidean wa `self` na `rhs`.
        ///
        /// Hii inashughulikia nambari kamili ya `n` kama hiyo `self = n * rhs + self.rem_euclid(rhs)`, na `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Kwa maneno mengine, matokeo ni `self / rhs` iliyozungushwa kwa nambari kamili `n` kama hiyo `self >= n * rhs`.
        /// Ikiwa `self > 0`, hii ni sawa na pande zote kuelekea sifuri (chaguomsingi katika Rust);
        /// ikiwa `self < 0`, hii ni sawa na pande zote kuelekea +/-infinity.
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0 au mgawanyiko unasababisha kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// wacha b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Hukokotoa salio lisilo la ubaya la `self (mod rhs)`.
        ///
        /// Hii imefanywa kana kwamba ni kwa algorithm ya mgawanyiko wa Euclidean-iliyopewa `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, na `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Kazi hii itakuwa panic ikiwa `rhs` ni 0 au mgawanyiko unasababisha kufurika.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// wacha b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Inashughulikia thamani kamili ya `self`.
        ///
        /// # Tabia ya kufurika
        ///
        /// Thamani kamili ya
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// haiwezi kuwakilishwa kama
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// na kujaribu kuhesabu itasababisha kufurika.
        /// Hii inamaanisha kuwa nambari katika hali ya utatuzi itasababisha panic kwenye kesi hii na nambari iliyoboreshwa itarudi
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// bila panic.
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Kumbuka kuwa#[inline] hapo juu inamaanisha kuwa semantiki za kufurika za kutoa hutegemea crate tunayoingizwa ndani.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Hurejesha nambari inayowakilisha ishara ya `self`.
        ///
        ///  - `0` ikiwa nambari ni sifuri
        ///  - `1` ikiwa nambari ni chanya
        ///  - `-1` ikiwa nambari ni hasi
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Hurejesha `true` ikiwa `self` ni chanya na `false` ikiwa nambari ni sifuri au hasi.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Hurejesha `true` ikiwa `self` ni hasi na `false` ikiwa nambari ni sifuri au chanya.
        ///
        ///
        /// # Examples
        ///
        /// Matumizi ya kimsingi:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Rudisha uwakilishi wa kumbukumbu ya nambari hii kama safu ya ka katika mpangilio mkubwa wa Xian X byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Rudisha uwakilishi wa kumbukumbu ya nambari hii kama safu ya ka katika mpangilio wa kaiti kidogo.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Rudisha uwakilishi wa kumbukumbu ya nambari hii kama safu ya ka katika mpangilio wa baiti ya asili.
        ///
        /// Kama endianness ya jukwaa lengwa inavyotumiwa, nambari inayoweza kubeba inapaswa kutumia [`to_be_bytes`] au [`to_le_bytes`], kama inafaa, badala yake.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     ka, ikiwa cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } mwingine {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // USALAMA: sauti ya const kwa sababu nambari ni hifadhidata za zamani za zamani ili tuweze daima
        // kuwasambaza kwa safu za ka
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // USALAMA: nambari kamili ni hifadhidata za zamani za zamani ili tuweze kuzisambaza kila wakati
            // safu ya ka
            unsafe { mem::transmute(self) }
        }

        /// Rudisha uwakilishi wa kumbukumbu ya nambari hii kama safu ya ka katika mpangilio wa baiti ya asili.
        ///
        ///
        /// [`to_ne_bytes`] inapaswa kupendelewa kuliko hii kila inapowezekana.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     ka, ikiwa cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } mwingine {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // USALAMA: nambari kamili ni hifadhidata za zamani za zamani ili tuweze kuzisambaza kila wakati
            // safu ya ka
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Unda nambari kamili kutoka kwa uwakilishi wake kama safu ya baiti katika endian kubwa.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// tumia std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * pembejeo=kupumzika;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Unda nambari kamili kutoka kwa uwakilishi wake kama safu ya ka katika endian kidogo.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// tumia std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * pembejeo=kupumzika;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Unda nambari kamili kutoka kwa uwakilishi wake wa kumbukumbu kama safu ya baiti katika ustadi wa asili.
        ///
        /// Kama endianness ya jukwaa lengwa inavyotumiwa, nambari inayoweza kusonga huenda inataka kutumia [`from_be_bytes`] au [`from_le_bytes`], inavyofaa badala yake.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } mwingine {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// tumia std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * pembejeo=kupumzika;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // USALAMA: sauti ya const kwa sababu nambari ni hifadhidata za zamani za zamani ili tuweze daima
        // kusambaza kwao
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // USALAMA: idadi kamili ni hifadhidata za zamani za zamani ili tuweze kuzipitia kila wakati
            unsafe { mem::transmute(bytes) }
        }

        /// Nambari mpya inapaswa kupendelea kutumia
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Hurejesha thamani ndogo zaidi ambayo inaweza kuwakilishwa na aina hii kamili.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Nambari mpya inapaswa kupendelea kutumia
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Hurejesha thamani kubwa zaidi ambayo inaweza kuwakilishwa na aina hii kamili.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}