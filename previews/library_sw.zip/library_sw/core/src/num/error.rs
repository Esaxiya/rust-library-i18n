//! Aina za makosa ya ubadilishaji kuwa aina muhimu.

use crate::convert::Infallible;
use crate::fmt;

/// Aina ya hitilafu ilirudi wakati ubadilishaji wa aina iliyoangaliwa unashindwa.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Mechi badala ya kulazimisha kuhakikisha kuwa nambari kama `From<Infallible> for TryFromIntError` hapo juu itaendelea kufanya kazi wakati `Infallible` inakuwa jina la `!`.
        //
        //
        match never {}
    }
}

/// Hitilafu ambayo inaweza kurudishwa wakati wa kuchanganua nambari.
///
/// Kosa hili hutumiwa kama aina ya makosa ya kazi za `from_str_radix()` kwenye aina za nambari za zamani, kama vile [`i8::from_str_radix`].
///
/// # Sababu zinazowezekana
///
/// Miongoni mwa sababu zingine, `ParseIntError` inaweza kutupwa kwa sababu ya nafasi nyeupe inayoongoza au inayofuatilia kwenye kamba mfano, inapopatikana kutoka kwa pembejeo ya kawaida.
///
/// Kutumia njia ya [`str::trim()`] inahakikisha kwamba hakuna nafasi nyeupe kabla ya kuchanganua.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum kuhifadhi aina anuwai ya makosa ambayo yanaweza kusababisha kuchanganua nambari kushindwa.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Thamani inayotenganishwa haina kitu.
    ///
    /// Miongoni mwa sababu zingine, tofauti hii itajengwa wakati wa kuchambua kamba tupu.
    Empty,
    /// Inayo tarakimu isiyo sahihi katika muktadha wake.
    ///
    /// Miongoni mwa sababu zingine, tofauti hii itajengwa wakati wa kuchambua kamba ambayo ina char isiyo ya ASCII.
    ///
    /// Tofauti hii pia hujengwa wakati `+` au `-` imewekwa vibaya ndani ya kamba iwe peke yake au katikati ya nambari.
    ///
    ///
    InvalidDigit,
    /// Nambari ni kubwa mno kuweza kuhifadhiwa katika aina ya nambari kamili.
    PosOverflow,
    /// Namba ni ndogo sana kuhifadhi katika aina ya idadi kamili.
    NegOverflow,
    /// Thamani ilikuwa Sifuri
    ///
    /// Tofauti hii itatolewa wakati kamba ya kuchanganua ina thamani ya sifuri, ambayo itakuwa kinyume cha sheria kwa aina zisizo za sifuri.
    ///
    Zero,
}

impl ParseIntError {
    /// Matokeo ya sababu ya kina ya kuchambua nambari kushindwa.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}