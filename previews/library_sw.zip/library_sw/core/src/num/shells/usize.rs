//! Mara kwa mara ya aina ya nambari isiyo na saini isiyosainiwa.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Nambari mpya inapaswa kutumia vizuizi vinavyohusiana moja kwa moja kwenye aina ya zamani.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }