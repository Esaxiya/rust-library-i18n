//! Mara kwa mara ya aina ya nambari 8 isiyosainiwa.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Nambari mpya inapaswa kutumia vizuizi vinavyohusiana moja kwa moja kwenye aina ya zamani.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }