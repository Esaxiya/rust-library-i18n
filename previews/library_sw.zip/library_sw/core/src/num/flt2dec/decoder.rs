//! Inasimbua thamani ya kiwango kinachoelea katika sehemu za kibinafsi na safu za makosa.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Thamani isiyo na saini isiyo na saini, kama kwamba:
///
/// - Thamani ya asili ni sawa na `mant * 2^exp`.
///
/// - Nambari yoyote kutoka `(mant - minus)*2^exp` hadi `(mant + plus)* 2^exp` itazunguka kwa thamani ya asili.
/// Masafa yanajumuisha tu wakati `inclusive` ni `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa iliyopanuliwa.
    pub mant: u64,
    /// Masafa ya chini ya hitilafu.
    pub minus: u64,
    /// Masafa ya juu zaidi.
    pub plus: u64,
    /// Kionyeshi cha pamoja katika msingi 2.
    pub exp: i16,
    /// Kweli wakati upeo wa makosa umejumuisha.
    ///
    /// Katika IEEE 754, hii ni kweli wakati mantissa ya asili ilikuwa hata.
    pub inclusive: bool,
}

/// Thamani ambayo haijasainiwa.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, iwe chanya au hasi.
    Infinite,
    /// Sifuri, iwe chanya au hasi.
    Zero,
    /// Nambari za mwisho na sehemu zaidi zilizotengwa.
    Finite(Decoded),
}

/// Aina ya hatua inayoelea ambayo inaweza `kusimbua`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Thamani ya chini chanya iliyosimamishwa.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Hurejesha ishara (ya kweli ikiwa hasi) na thamani ya `FullDecoded` kutoka kwa nambari ya nambari iliyoelea.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // majirani: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode Daima huhifadhi kiboreshaji, kwa hivyo mantissa hupunguzwa kwa hali isiyo ya kawaida.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // majirani: (maxmant, exp, 1)-(isiyo ya kawaida, exp)-(isiyo ya kawaida + 1, exp)
                // ambapo maxmant=isiyo ya kawaida * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // majirani: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}