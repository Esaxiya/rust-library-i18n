//! Marekebisho ya Rust ya hesabu ya Grisu3 ilivyoelezewa katika "Uchapishaji wa Nambari za Nambari za Kuelea kwa haraka na kwa usahihi na nambari" [^ 1].
//! Inatumia karibu 1KB ya jedwali lililowekwa, na kwa upande wake, ni haraka sana kwa pembejeo nyingi.
//!
//! [^1]: Florian Loitsch.2010. Kuchapa nambari za kuelea-haraka na
//!   kwa usahihi na nambari.SIGPLAN Sio.45, 6 (Juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// tazama maoni katika `format_shortest_opt` kwa mantiki.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Ikipewa `x > 0`, inarudi `(k, 10^k)` kama vile `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Utekelezaji wa hali fupi zaidi kwa Grisu.
///
/// Inarudi `None` wakati itarudisha uwakilishi wa inexact vinginevyo.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // tunahitaji angalau bits tatu za usahihi wa ziada

    // anza na maadili ya kawaida na kionyeshi cha pamoja
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // pata `cached = 10^minusk` yoyote ile ambayo `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // kwa kuwa `plus` imewekwa kawaida, hii inamaanisha `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // kutokana na uchaguzi wetu wa `ALPHA` na `GAMMA`, hii inaweka `plus * cached` kwenye `[4, 2^32)`.
    //
    // ni dhahiri kuhitajika kuongeza `GAMMA - ALPHA`, ili hatuhitaji nguvu nyingi zilizohifadhiwa za 10, lakini kuna maoni kadhaa:
    //
    //
    // 1. tunataka kuweka `floor(plus * cached)` ndani ya `u32` kwani inahitaji mgawanyiko wa gharama kubwa.
    //    (hii haiepukiki kweli, salio inahitajika kwa makadirio ya usahihi.)
    // 2.
    // salio la `floor(plus * cached)` linazidishwa mara 10, na haipaswi kufurika.
    //
    // ya kwanza inatoa `64 + GAMMA <= 32`, wakati ya pili inatoa `10 * 2^-ALPHA <= 2^64`;
    // -60 na -32 ni kiwango cha juu kabisa na kikwazo hiki, na V8 pia huzitumia.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // fps ya kiwango.hii inatoa kosa kubwa la 1 ulp (imethibitishwa kutoka kwa Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-anuwai halisi ya minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // juu ya `minus`, `v` na `plus` ni *hesabu* zilizohesabiwa (kosa <1 ulp).
    // kwani hatujui kosa ni chanya au hasi, tunatumia takriban mbili zilizokadiriwa sawa na tuna hitilafu kubwa ya vidonda 2.
    //
    // "unsafe region" ni muda wa huria ambao mwanzoni tunazalisha.
    // "safe region" ni muda wa kihafidhina ambao tunakubali tu.
    // tunaanza na repr sahihi ndani ya eneo lisilo salama, na jaribu kupata repr ya karibu zaidi ya `v` ambayo pia iko ndani ya mkoa salama.
    // ikiwa hatuwezi, tunakata tamaa.
    //
    let plus1 = plus.f + 1;
    // hebu plus0 = plus.f, 1;//tu kwa ufafanuzi basi minus0 = minus.f + 1;//tu kwa maelezo
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // kionyeshi cha pamoja

    // gawanya `plus1` katika sehemu muhimu na za sehemu.
    // sehemu muhimu zinahakikishiwa kutoshea u32, kwani nguvu iliyohifadhiwa inathibitisha `plus < 2^32` na `plus.f` iliyowekwa kawaida huwa chini ya `2^64 - 2^4` kwa sababu ya hitaji la usahihi.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // hesabu `10^max_kappa` kubwa zaidi ya `plus1` (kwa hivyo `plus1 < 10^(max_kappa+1)`).
    // hii ni kifungo cha juu cha `kappa` hapa chini.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: ikiwa `k` ni nambari kubwa zaidi st
    // `0 <= y mod 10^k <= y - x`,              basi `V = floor(y / 10^k) * 10^k` iko katika `[x, y]` na mojawapo ya uwakilishi mfupi zaidi (na idadi ndogo ya nambari muhimu) katika anuwai hiyo.
    //
    //
    // pata urefu wa tarakimu `kappa` kati ya `(minus1, plus1)` kulingana na Theorem 6.2.
    // Theorem 6.2 inaweza kupitishwa kuwatenga `x` kwa kuhitaji `y mod 10^k < y - x` badala yake.
    // (kwa mfano, `x` =32000, `y` =32777; `kappa` =2 tangu `y mod 10 ^ 3=777 <y, x=777`.) algorithm inategemea awamu ya uthibitisho wa baadaye kuwatenga `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) kama usize;//tu kwa maelezo
    let delta1frac = delta1 & ((1 << e) - 1);

    // toa sehemu muhimu, wakati unatafuta usahihi katika kila hatua.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // nambari ambazo hazijatolewa
    loop {
        // daima tunayo angalau tarakimu moja ya kutoa, kama vivamizi vya `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (inafuata hiyo `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // gawanya `remainder` na `10^kappa`.zote mbili zimepunguzwa na `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; tumepata `kappa` sahihi.
            let ten_kappa = (ten_kappa as u64) << e; // kiwango cha 10 ^ kappa kurudi kwa kionyeshi cha pamoja
            return round_and_weed(
                // USALAMA: tulianzisha kumbukumbu hiyo hapo juu.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // kuvunja kitanzi wakati tumetoa nambari zote muhimu.
        // idadi halisi ya nambari ni `max_kappa + 1` kama `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // rejesha vivamizi
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // toa sehemu za sehemu, wakati unatafuta usahihi katika kila hatua.
    // wakati huu tunategemea kuzidisha mara kwa mara, kwani mgawanyiko utapoteza usahihi.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // nambari inayofuata inapaswa kuwa muhimu kwani tumejaribu hiyo kabla ya kuvunja vizuizi, ambapo `m = max_kappa + 1` (#ya tarakimu katika sehemu muhimu):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // haitafurika, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // gawanya `remainder` na `10^kappa`.
        // zote mbili zimepunguzwa na `2^e / 10^kappa`, kwa hivyo hii ya mwisho iko wazi hapa.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // msuluhishi dhahiri
            return round_and_weed(
                // USALAMA: tulianzisha kumbukumbu hiyo hapo juu.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // rejesha vivamizi
        kappa -= 1;
        remainder = r;
    }

    // tumezalisha nambari zote muhimu za `plus1`, lakini sio hakika ikiwa ndio mojawapo.
    // kwa mfano, ikiwa `minus1` ni 3.14153 ... na `plus1` ni 3.14158 ..., kuna uwakilishi 5 tofauti mfupi zaidi kutoka 3.14154 hadi 3.14158 lakini tuna moja kubwa tu.
    // tunapaswa kupunguza nambari ya mwisho mfululizo na kuangalia ikiwa hii ndio repr mojawapo.
    // kuna zaidi ya wagombea 9 (. 1 hadi ..9), kwa hivyo hii ni haraka sana.(Awamu ya "rounding")
    //
    // kazi huangalia ikiwa repr hii ya "optimal" iko ndani ya safu za ulp, na pia, inawezekana kwamba repr ya "second-to-optimal" inaweza kuwa sawa kabisa kwa sababu ya kosa la kuzungusha.
    // katika hali yoyote hii inarudi `None`.
    // (Awamu ya "weeding")
    //
    // hoja zote hapa zimepunguzwa na thamani ya kawaida (lakini isiyo wazi) `k`, ili:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (na pia, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (na pia, `threshold > plus1v` kutoka kwa wavamizi wa hapo awali)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // toa takriban mbili kwa `v` (kweli `plus1 - v`) ndani ya vidonda vya 1.5.
        // uwakilishi unaotokana unapaswa kuwa uwakilishi wa karibu zaidi kwa wote wawili.
        //
        // hapa `plus1 - v` hutumiwa kwani mahesabu hufanywa kwa heshima ya `plus1` ili kuepusha overflow/underflow (kwa hivyo majina yanayoonekana kubadilishwa).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (Mst 1)
        let plus1v_up = plus1v - ulp; // plus1 - (mstari + 1 ulp)

        // punguza nambari ya mwisho na simama kwenye uwakilishi wa karibu zaidi wa `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // tunafanya kazi na nambari zinazokadiriwa `w(n)`, ambayo hapo awali ni sawa na `plus1 - plus1 % 10^kappa`.baada ya kuendesha mwili wa kitanzi mara `n`, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // tunaweka `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (kwa hivyo "salio= plus1w(0)`) ili kurahisisha ukaguzi.
            // kumbuka kuwa `plus1w(n)` inaongezeka kila wakati.
            //
            // tuna masharti matatu ya kukomesha.yoyote kati yao itafanya kitanzi kishindwe kuendelea, lakini basi tuna angalau uwakilishi halali unaojulikana kuwa karibu na `v + 1 ulp` hata hivyo.
            // tutawataja kama TC1 kupitia TC3 kwa ufupi.
            //
            // TC1: `w(n) <= v + 1 ulp`, yaani, hii ni repr ya mwisho ambayo inaweza kuwa ya karibu zaidi.
            // hii ni sawa na `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // pamoja na TC2 (ambayo huangalia ikiwa `w(n+1)` is valid), hii inazuia kufurika iwezekanavyo kwenye hesabu ya `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, yaani, repr ijayo hakika haizunguki hadi `v`.
            // hii ni sawa na `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // upande wa kushoto unaweza kufurika, lakini tunajua `threshold > plus1v`, kwa hivyo ikiwa TC1 ni ya uwongo, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` na tunaweza kujaribu salama ikiwa `threshold - plus1w(n) < 10^kappa` badala yake.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, yaani, repr inayofuata ni
            // hakuna karibu na `v + 1 ulp` kuliko repr ya sasa.
            // kupewa `z(n) = plus1v_up - plus1w(n)`, hii inakuwa `abs(z(n)) <= abs(z(n+1))`.tena kudhani kuwa TC1 ni ya uwongo, tuna `z(n) > 0`.tuna kesi mbili za kuzingatia:
            //
            // - wakati `z(n+1) >= 0`: TC3 inakuwa `z(n) <= z(n+1)`.
            // kama `plus1w(n)` inavyoongezeka, `z(n)` inapaswa kupungua na hii ni wazi kuwa uwongo.
            // - wakati `z(n+1) < 0`:
            //   - TC3a: sharti ni `plus1v_up < plus1w(n) + 10^kappa`.kudhani TC2 ni ya uwongo, `threshold >= plus1w(n) + 10^kappa` kwa hivyo haiwezi kufurika.
            //   - TC3b: TC3 inakuwa `z(n) <= -z(n+1)`, yaani, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 iliyopuuzwa inatoa `plus1v_up > plus1w(n)`, kwa hivyo haiwezi kufurika au kufurika ikichanganywa na TC3a.
            //
            // kwa hivyo, tunapaswa kusimama wakati `TC1 || TC2 || (TC3a && TC3b)`.zifuatazo ni sawa na inverse yake, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr fupi haiwezi kumaliza na `0`
                plus1w += ten_kappa;
            }
        }

        // angalia ikiwa uwakilishi huu pia ni uwakilishi wa karibu zaidi wa `v - 1 ulp`.
        //
        // hii ni sawa tu na hali ya kukomesha `v + 1 ulp`, na `plus1v_up` zote zikibadilishwa na `plus1v_down` badala yake.
        // uchambuzi wa mafuriko unashikilia sawa.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // sasa tuna uwakilishi wa karibu zaidi kwa `v` kati ya `plus1` na `minus1`.
        // hii ni ya huria sana, ingawa, kwa hivyo tunakataa `w(n)` yoyote sio kati ya `plus0` na `minus0`, yaani, `plus1 - plus1w(n) <= minus0` au `plus1 - plus1w(n) >= plus0`.
        // tunatumia ukweli kwamba `threshold = plus1 - minus1` na `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Utekelezaji mfupi zaidi wa hali ya Grisu na kurudi nyuma kwa Joka.
///
/// Hii inapaswa kutumika kwa visa vingi.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // USALAMA: Kikaguaji cha kukopa sio akili ya kutosha kuturuhusu tutumie `buf`
    // katika branch ya pili, kwa hivyo tunafungua maisha hapa.
    // Lakini tunatumia tena `buf` ikiwa `format_shortest_opt` imerudisha `None` kwa hivyo hii ni sawa.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Utekelezaji halisi na uliowekwa wa Grisu.
///
/// Inarudi `None` wakati itarudisha uwakilishi wa inexact vinginevyo.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // tunahitaji angalau bits tatu za usahihi wa ziada
    assert!(!buf.is_empty());

    // rekebisha na pima `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // gawanya `v` katika sehemu muhimu na za sehemu.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // zote za zamani `v` na `v` mpya (iliyopigwa na `10^-k`) ina hitilafu ya <1 ulp (Theorem 5.1).
    // kwani hatujui kosa ni chanya au hasi, tunatumia makadirio mawili yaliyowekwa sawa na tuna hitilafu kubwa ya vidonda 2 (sawa na kesi fupi).
    //
    //
    // lengo ni kupata safu kamili za nambari ambazo ni kawaida kwa `v - 1 ulp` na `v + 1 ulp`, ili tuwe na ujasiri kabisa.
    // ikiwa hii haiwezekani, hatujui ni ipi pato sahihi kwa `v`, kwa hivyo tunakata tamaa na kurudi nyuma.
    //
    // `err` hufafanuliwa kama `1 ulp * 2^e` hapa (sawa na ulp katika `vfrac`), na tutaipima wakati wowote `v` inapopunguzwa.
    //
    //
    //
    let mut err = 1;

    // hesabu `10^max_kappa` kubwa zaidi ya `v` (kwa hivyo `v < 10^(max_kappa+1)`).
    // hii ni kifungo cha juu cha `kappa` hapa chini.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ikiwa tunafanya kazi na kiwango cha juu cha nambari za mwisho, tunahitaji kufupisha bafa kabla ya utoaji halisi ili kuepusha kuzungushwa mara mbili.
    //
    // kumbuka kuwa lazima tupanue bafa tena wakati kuzungusha kunatokea!
    let len = if exp <= limit {
        // lo, hatuwezi hata kutoa tarakimu * moja.
        // hii inawezekana wakati, tuseme, tunayo kitu kama 9.5 na inazungushwa hadi 10.
        //
        // kwa kanuni tunaweza kupiga `possibly_round` mara moja na bafa tupu, lakini kuongeza `max_ten_kappa << e` ifikapo 10 inaweza kusababisha kufurika.
        //
        // kwa hivyo tunakuwa wazembe hapa na kupanua anuwai ya makosa kwa sababu ya 10.
        // hii itaongeza kiwango hasi cha uwongo, lakini tu,*sana* kidogo;
        // inaweza tu kujulikana wakati mantissa ni kubwa kuliko bits 60.
        //
        // USALAMA: `len=0`, kwa hivyo jukumu la kuanzisha kumbukumbu hii ni ndogo.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // toa sehemu muhimu.
    // kosa ni sehemu ndogo kabisa, kwa hivyo hatuitaji kuiangalia katika sehemu hii.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // nambari ambazo hazijatolewa
    loop {
        // kila wakati tuna angalau nambari moja ya kutoa viboreshaji:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (inafuata hiyo `remainder = vint % 10^(kappa+1)`)
        //
        //

        // gawanya `remainder` na `10^kappa`.zote mbili zimepunguzwa na `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bafa imejaa?endesha kupitisha kuzunguka na salio.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // USALAMA: tumeanzisha `len` ka nyingi.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // kuvunja kitanzi wakati tumetoa nambari zote muhimu.
        // idadi halisi ya nambari ni `max_kappa + 1` kama `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // rejesha vivamizi
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // toa sehemu za sehemu.
    //
    // kwa kanuni tunaweza kuendelea na nambari ya mwisho inayopatikana na kuangalia usahihi.
    // kwa bahati mbaya tunafanya kazi na idadi kamili ya ukubwa, kwa hivyo tunahitaji kigezo fulani cha kugundua kufurika.
    // V8 hutumia `remainder > err`, ambayo inakuwa ya uwongo wakati nambari muhimu za kwanza za `i` za `v - 1 ulp` na `v` zinatofautiana.
    // hata hivyo hii inakataa pembejeo nyingi zaidi halali.
    //
    // kwa kuwa awamu ya baadaye ina ugunduzi sahihi wa kufurika, badala yake tunatumia kigezo kikali:
    // tunaendelea hadi `err` inazidi `10^kappa / 2`, ili masafa kati ya `v - 1 ulp` na `v + 1 ulp` dhahiri iwe na viwakilishi viwili au zaidi vya mviringo.
    //
    // hii ni sawa na kulinganisha mbili za kwanza kutoka `possibly_round`, kwa kumbukumbu.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // vivamizi, ambapo `m = max_kappa + 1` (#ya nambari katika sehemu muhimu):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // haitafurika, `2^e * 10 < 2^64`
        err *= 10; // haitafurika, `err * 10 < 2^e * 5 < 2^64`

        // gawanya `remainder` na `10^kappa`.
        // zote mbili zimepunguzwa na `2^e / 10^kappa`, kwa hivyo hii ya mwisho iko wazi hapa.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bafa imejaa?endesha kupitisha kuzunguka na salio.
        if i == len {
            // USALAMA: tumeanzisha `len` ka nyingi.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // rejesha vivamizi
        remainder = r;
    }

    // hesabu zaidi haina maana (`possibly_round` inashindwa dhahiri), kwa hivyo tunaacha.
    return None;

    // tumezalisha nambari zote zilizoombwa za `v`, ambazo zinapaswa kuwa sawa na nambari zinazolingana za `v - 1 ulp`.
    // sasa tunaangalia ikiwa kuna uwakilishi wa kipekee ulioshirikiwa na wote `v - 1 ulp` na `v + 1 ulp`;hii inaweza kuwa sawa na nambari zilizozalishwa, au kwa toleo lililokamilishwa la nambari hizo.
    //
    // ikiwa masafa yana viwakilishi vingi vya urefu sawa, hatuwezi kuwa na hakika na badala yake tunapaswa kurudisha `None`.
    //
    // hoja zote hapa zimepunguzwa na thamani ya kawaida (lakini isiyo wazi) `k`, ili:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // USALAMA: baiti za kwanza za `len` za `buf` lazima zianzishwe.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (kwa rejeleo, laini iliyotiwa alama inaonyesha dhamana halisi ya uwakilishi unaowezekana kwa nambari fulani ya nambari.)
        //
        //
        // kosa ni kubwa sana kwamba kuna angalau uwakilishi unaowezekana kati ya `v - 1 ulp` na `v + 1 ulp`.
        // hatuwezi kuamua ni ipi sahihi.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // kwa kweli, 1/2 ulp inatosha kuanzisha vielelezo viwili vinavyowezekana.
        // (kumbuka kuwa tunahitaji uwakilishi wa kipekee kwa `v - 1 ulp` na `v + 1 ulp`.) hii haitafurika, kama `ulp < ten_kappa` kutoka kwa hundi ya kwanza.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ikiwa `v + 1 ulp` iko karibu na uwakilishi uliokamilishwa chini (ambao tayari uko katika `buf`), basi tunaweza kurudi salama.
        // kumbuka kuwa `v - 1 ulp` * inaweza kuwa chini ya uwakilishi wa sasa, lakini kama `1 ulp < 10^kappa / 2`, hali hii inatosha:
        // umbali kati ya `v - 1 ulp` na uwakilishi wa sasa hauwezi kuzidi `10^kappa / 2`.
        //
        // hali hiyo ni sawa na `remainder + ulp < 10^kappa / 2`.
        // kwa kuwa hii inaweza kufurika kwa urahisi, angalia kwanza ikiwa `remainder < 10^kappa / 2`.
        // tayari tumethibitisha kwamba `ulp < 10^kappa / 2`, ilimradi `10^kappa` isizidi baada ya yote, hundi ya pili ni sawa.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // USALAMA: mpigaji simu wetu alianzisha kumbukumbu hiyo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------salio------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // kwa upande mwingine, ikiwa `v - 1 ulp` iko karibu na uwakilishi uliokamilishwa, tunapaswa kuzunguka na kurudi.
        // kwa sababu hiyo hiyo hatuitaji kuangalia `v + 1 ulp`.
        //
        // hali hiyo ni sawa na `remainder - ulp >= 10^kappa / 2`.
        // tena tunaangalia kwanza ikiwa `remainder > ulp` (kumbuka kuwa hii sio `remainder >= ulp`, kwani `10^kappa` sio sifuri kamwe).
        //
        // kumbuka pia kuwa `remainder - ulp <= 10^kappa`, kwa hivyo hundi ya pili haizidi.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // USALAMA: mpigaji wetu lazima awe ameanzisha kumbukumbu hiyo.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // ongeza tu nambari ya ziada wakati tumeombwa usahihi uliowekwa.
                // tunahitaji pia kuangalia kwamba, ikiwa bafa asili ilikuwa tupu, nambari ya ziada inaweza kuongezwa tu wakati `exp == limit` (kesi ya edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // USALAMA: sisi na mpigaji simu tulianzisha kumbukumbu hiyo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // vinginevyo tumehukumiwa (yaani, maadili kadhaa kati ya `v - 1 ulp` na `v + 1 ulp` yanazunguka na mengine yanazunguka) na kukata tamaa.
        //
        None
    }
}

/// Utekelezaji halisi na uliowekwa wa hali ya Grisu na kurudi nyuma kwa Joka.
///
/// Hii inapaswa kutumika kwa visa vingi.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // USALAMA: Kikaguaji cha kukopa sio akili ya kutosha kuturuhusu tutumie `buf`
    // katika branch ya pili, kwa hivyo tunafungua maisha hapa.
    // Lakini tunatumia tena `buf` ikiwa `format_exact_opt` imerudisha `None` kwa hivyo hii ni sawa.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}