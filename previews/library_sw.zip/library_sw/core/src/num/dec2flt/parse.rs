//! Inathibitisha na kuoza kamba ya desimali ya fomu:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Kwa maneno mengine, sintaksia ya kawaida ya kuelea, isipokuwa mbili: Hakuna ishara, na hakuna utunzaji wa "inf" na "NaN".Hizi zinashughulikiwa na kazi ya dereva (super::dec2flt).
//!
//! Ingawa kutambua pembejeo halali ni rahisi, moduli hii pia inapaswa kukataa tofauti nyingi zisizo sawa, kamwe panic, na kufanya ukaguzi kadhaa ambao moduli zingine hutegemea sio panic (au kufurika) kwa zamu.
//!
//! Kufanya mambo kuwa mabaya zaidi, yote yanayotokea kwa kupitisha moja juu ya pembejeo.
//! Kwa hivyo, kuwa mwangalifu unapobadilisha chochote, na angalia mara mbili na moduli zingine.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Sehemu za kupendeza za kamba ya desimali.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Kionyeshi cha desimali, kilichohakikishiwa kuwa na tarakimu chini ya 18 za desimali.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Hukagua ikiwa kamba ya kuingiza ni nambari halali ya kuelea na ikiwa ni hivyo, tafuta sehemu muhimu, sehemu ya sehemu, na kielelezo ndani yake.
/// Haishughulikii ishara.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Hakuna nambari kabla ya 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Tunahitaji angalau nambari moja kabla au baada ya uhakika.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Takataka inayofuatia baada ya sehemu ya sehemu
            }
        }
        _ => Invalid, // Takataka inayofuatia baada ya kamba ya nambari ya kwanza
    }
}

/// Huchonga nambari za desimali hadi herufi ya kwanza isiyo ya tarakimu.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Uchimbaji wa nje na ukaguzi wa makosa.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Takataka inayofuatia baada ya kielelezo
    }
    if number.is_empty() {
        return Invalid; // Kionyeshi tupu
    }
    // Kwa wakati huu, hakika tuna safu halali ya nambari.Inaweza kuwa ndefu sana kuweka kwenye `i64`, lakini ikiwa ni kubwa sana, pembejeo hakika ni sifuri au infinity.
    // Kwa kuwa kila sifuri katika nambari za desimali hurekebisha kiboreshaji tu kwa +/-1, kwa exp=10 ^ 18 pembejeo italazimika kuwa 17 exabyte (!) ya zeros ili kupata karibu sana kuwa dhaifu.
    //
    // Hii sio kesi ya matumizi tunayohitaji kuhudumia.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}