//! Kupigania kidogo juu ya kuelea nzuri IEEE 754.Nambari hasi sio na hazihitaji kubebwa.
//! Nambari za kawaida za kuelea zina uwakilishi wa kikanoni kama (frac, exp) kama kwamba thamani ni 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) ambapo N ni idadi ya bits.
//!
//! Uboreshaji ni tofauti kidogo na ya kushangaza, lakini kanuni hiyo hiyo inatumika.
//!
//! Hapa, hata hivyo, tunawawakilisha kama (sig, k) na f chanya, kwamba thamani ni f *
//! 2 <sup>e</sup> .Licha ya kuifanya "hidden bit" iwe wazi, hii inabadilisha kielelezo na kile kinachoitwa mabadiliko ya mantissa.
//!
//! Weka njia nyingine, kwa kawaida huelea huandikwa kama (1) lakini hapa zimeandikwa kama (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Tunaita (1) the **uwakilishi wa sehemu** na (2) the **uwakilishi muhimu**.
//!
//! Kazi nyingi katika moduli hii hushughulikia nambari za kawaida tu.Taratibu za dec2flt huchukua njia ya polepole iliyo sawa ulimwenguni (Algorithm M) kwa idadi ndogo na kubwa sana.
//! Algorithm hiyo inahitaji tu next_float() ambayo inashughulikia hali isiyo ya kawaida na zero.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Msaidizi trait kuzuia kuiga kimsingi nambari yote ya ubadilishaji ya `f32` na `f64`.
///
/// Tazama maoni ya moduli ya mzazi kwa nini hii ni muhimu.
///
/// Haipaswi kamwe ** kutekelezwa kwa aina zingine au kutumiwa nje ya moduli ya dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Aina inayotumiwa na `to_bits` na `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Inafanya uhamisho mbichi kwa nambari kamili.
    fn to_bits(self) -> Self::Bits;

    /// Inafanya uhamisho mbichi kutoka kwa nambari kamili.
    fn from_bits(v: Self::Bits) -> Self;

    /// Hurejesha kategoria ambayo nambari hii inaangukia.
    fn classify(self) -> FpCategory;

    /// Hurejesha mantissa, kionyeshi na saini kama nambari.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Hutambua kuelea.
    fn unpack(self) -> Unpacked;

    /// Inatoa kutoka kwa nambari ndogo ambayo inaweza kuwakilishwa haswa.
    /// Panic ikiwa nambari haiwezi kuwakilishwa, nambari nyingine kwenye moduli hii inahakikisha kamwe isiiruhusu hiyo kutokea.
    fn from_int(x: u64) -> Self;

    /// Inapata thamani 10 <sup>e</sup> kutoka kwa jedwali lililokadiriwa awali.
    /// Panics kwa `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Jina linasema nini.
    /// Ni rahisi kwa nambari ngumu kuliko mauzauza ya ndani na kutumaini LLVM inaikunja mara kwa mara.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Sehemu ya kihafidhina kwenye nambari za decimal za pembejeo ambazo haziwezi kutoa kufurika au sifuri au
    /// isiyo ya kawaida.Labda kionyeshi cha desimali cha kiwango cha juu cha kawaida, kwa hivyo jina.
    const MAX_NORMAL_DIGITS: usize;

    /// Wakati nambari muhimu zaidi ya desimali ina dhamana ya mahali kubwa zaidi ya hii, nambari hakika imezungukwa kuwa isiyo na mwisho.
    ///
    const INF_CUTOFF: i64;

    /// Wakati nambari muhimu zaidi ya desimali ina thamani ya mahali chini ya hii, nambari hakika imezungukwa hadi sifuri.
    ///
    const ZERO_CUTOFF: i64;

    /// Idadi ya vipande kwenye kionyeshi.
    const EXP_BITS: u8;

    /// Idadi ya bits katika umuhimu,*pamoja na* kitufe kilichofichwa.
    const SIG_BITS: u8;

    /// Idadi ya bits katika umuhimu,*ukiondoa* kipengee kilichofichwa.
    const EXPLICIT_SIG_BITS: u8;

    /// Kielelezo cha juu cha kisheria katika uwakilishi wa sehemu.
    const MAX_EXP: i16;

    /// Kielelezo cha chini cha kisheria katika uwakilishi wa sehemu, ukiondoa hali isiyo ya kawaida.
    const MIN_EXP: i16;

    /// `MAX_EXP` kwa uwakilishi muhimu, yaani, na mabadiliko yaliyotumika.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` iliyosimbwa (yaani, na upendeleo wa kukabiliana)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` kwa uwakilishi muhimu, yaani, na mabadiliko yaliyotumika.
    const MIN_EXP_INT: i16;

    /// Kiwango cha juu kabisa cha kawaida katika uwakilishi muhimu.
    const MAX_SIG: u64;

    /// Umuhimu wa kawaida ulio sawa katika uwakilishi muhimu.
    const MIN_SIG: u64;
}

// Zaidi ya kazi kwa #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Hurejesha mantissa, kionyeshi na saini kama nambari.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Upendeleo wa mpatanishi + mabadiliko ya mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe haijulikani ikiwa `as` inazunguka kwa usahihi kwenye majukwaa yote.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Hurejesha mantissa, kionyeshi na saini kama nambari.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Upendeleo wa mpatanishi + mabadiliko ya mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe haijulikani ikiwa `as` inazunguka kwa usahihi kwenye majukwaa yote.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Inabadilisha `Fp` kuwa aina ya mashine ya kuelea ya karibu zaidi.
/// Haishughulikii matokeo yasiyo ya kawaida.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ni 64 kidogo, kwa hivyo xe ina mabadiliko ya mantissa ya 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Zunguka maana ya 64-bit hadi T::SIG_BITS bits na nusu-hata.
/// Haishughulikii kufurika kwa upeo.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Rekebisha mabadiliko ya mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverse ya `RawFloat::unpack()` kwa nambari za kawaida.
/// Panics ikiwa umuhimu au kionyeshi sio halali kwa nambari za kawaida.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Ondoa kidogo kilichofichwa
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Rekebisha kiboreshaji kwa upendeleo wa nje na mabadiliko ya mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Acha ishara kidogo kwa 0 ("+"), nambari zetu zote ni nzuri
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Jenga hali isiyo ya kawaida.Mantissa ya 0 inaruhusiwa na inaunda sifuri.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kielelezo kilichosimbwa ni 0, alama kidogo ni 0, kwa hivyo lazima tu tafsiri tena bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Takriban bignum na Fp.Inazunguka ndani ya 0.5 ULP na nusu-hata.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Tulikata bits zote kabla ya faharisi ya `start`, kwa hivyo, tunabadilika kwa haki kwa kiasi cha `start`, kwa hivyo hii pia ni kielelezo tunachohitaji.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Mzunguko (half-to-even) kulingana na vipande vilivyokatwa.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Inapata nambari kubwa zaidi ya kuelea ikiwa ndogo kuliko hoja.
/// Haishughulikii hali isiyo ya kawaida, sifuri, au ufafanuzi wa chini.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Pata nambari ndogo kabisa ya kuelea kabisa kuliko hoja.
// Operesheni hii inajaa, yaani, next_float(inf) ==inf.
// Tofauti na nambari nyingi kwenye moduli hii, kazi hii inashughulikia sifuri, hali isiyo ya kawaida, na infinities.
// Walakini, kama nambari zingine zote hapa, haishughuliki na NaN na nambari hasi.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Hii inaonekana kuwa nzuri sana kuwa kweli, lakini inafanya kazi.
        // 0.0 imefungwa kama neno la sifuri.Kawaida ni 0x000m ... m ambapo m ni mantissa.
        // Hasa, ndogo ndogo isiyo ya kawaida ni 0x0 ... 01 na kubwa zaidi ni 0x000F ... F.
        // Nambari ndogo kabisa ya kawaida ni 0x0010 ... 0, kwa hivyo kesi hii ya kona inafanya kazi pia.
        // Ikiwa nyongeza inafurika mantissa, kubeba huongeza kidokezo kama tunavyotaka, na bits za mantissa zinakuwa sifuri.
        // Kwa sababu ya mkutano mdogo uliofichwa, hii pia ndio tunataka!
        // Mwishowe, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}