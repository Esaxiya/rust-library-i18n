//! Taratibu kadhaa kutoka kwa karatasi.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Idadi ya vipande muhimu katika Fp
const P: u32 = 64;

// Tunahifadhi tu kukadiria bora kwa vionyeshi * vyote, kwa hivyo "h" inayobadilika na hali zinazohusiana zinaweza kuachwa.
// Hii inafanya kazi kwa kilobytes kadhaa za nafasi.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Katika usanifu mwingi, shughuli za kuelea zina ukubwa wazi kidogo, kwa hivyo usahihi wa hesabu huamuliwa kwa msingi wa kila shughuli.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Kwenye x86, x87 FPU hutumiwa kwa shughuli za kuelea ikiwa viendelezi vya SSE/SSE2 havipatikani.
// FPU ya x87 inafanya kazi na bits 80 za usahihi kwa chaguo-msingi, ambayo inamaanisha kuwa shughuli zitazunguka hadi bits 80 na kusababisha kuzunguka mara mbili kutokea wakati maadili yatawakilishwa kama
//
// 32/64 maadili ya kuelea kidogo.Ili kushinda hii, neno la kudhibiti FPU linaweza kuwekwa ili hesabu zifanyike kwa usahihi unaotaka.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Muundo uliotumika kuhifadhi dhamana ya asili ya neno la kudhibiti FPU, ili iweze kurejeshwa wakati muundo umeshuka.
    ///
    ///
    /// x87 FPU ni rejista ya bits 16 ambayo uwanja wake ni kama ifuatavyo:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Nyaraka za uwanja wote zinapatikana katika Mwongozo wa Msanidi Programu wa IA-32 (Juzuu 1).
    ///
    /// Shamba pekee ambalo linafaa kwa nambari ifuatayo ni PC, Precision Control.
    /// Sehemu hii huamua usahihi wa shughuli zinazofanywa na FPU.
    /// Inaweza kuweka kwa:
    ///  - 0b00, usahihi mmoja, 32-bits
    ///  - 0b10, usahihi mara mbili, 64-bits
    ///  - 0b11, usahihi uliopanuliwa mara mbili yaani, 80-bits (hali chaguomsingi) Thamani ya 0b01 imehifadhiwa na haipaswi kutumiwa.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // USALAMA: maagizo ya `fldcw` yamekaguliwa ili kuweza kufanya kazi kwa usahihi na
        // `u16` yoyote
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Tunatumia sintaksia ya ATT kusaidia LLVM 8 na LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Inaweka uwanja wa usahihi wa FPU hadi `T` na kurudisha `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Hesabu thamani ya uwanja wa Udhibiti wa Usahihi ambao unafaa kwa `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // Biti 32
            8 => 0x0200, // Biti 64
            _ => 0x0300, // chaguo-msingi, biti 80
        };

        // Pata thamani ya asili ya neno la kudhibiti ili kuirejesha baadaye, wakati muundo wa `FPUControlWord` umeondolewa USALAMA: maagizo ya `fnstcw` yamekaguliwa ili kuweza kufanya kazi kwa usahihi na `u16` yoyote
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Tunatumia sintaksia ya ATT kusaidia LLVM 8 na LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Weka neno la kudhibiti kwa usahihi unaotaka.
        // Hii inafanikiwa kwa kuficha usahihi wa zamani (bits 8 na 9, 0x300) na kuibadilisha na bendera ya usahihi iliyohesabiwa hapo juu.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Njia ya haraka ya Bellerophon kutumia nambari na ukubwa wa mashine.
///
/// Hii hutolewa kwa kazi tofauti ili iweze kujaribu kabla ya kujenga bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Tunalinganisha thamani halisi na MAX_SIG karibu na mwisho, hii ni kukataa haraka, na kwa bei rahisi (na pia huachilia nambari yote iliyobaki kutoka kuwa na wasiwasi juu ya kufurika).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Njia ya haraka inategemea hesabu kuzungushwa kwa idadi sahihi ya bits bila kuzunguka kwa kati.
    // Kwenye x86 (bila SSE au SSE2) hii inahitaji usahihi wa stack ya x87 FPU ibadilishwe ili iweze kuzunguka moja kwa moja hadi 64/32 kidogo.
    // Kazi ya `set_precision` inachukua huduma ya kuweka usahihi juu ya usanifu ambao unahitaji kuiweka kwa kubadilisha hali ya ulimwengu (kama neno la kudhibiti la x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Kesi e <0 haiwezi kukunjwa kwenye branch nyingine.
    // Nguvu hasi husababisha sehemu inayorudia ya sehemu ndogo katika binary, ambayo imezungukwa, ambayo husababisha makosa ya kweli (na mara kwa mara muhimu sana!) Katika matokeo ya mwisho.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon ni nambari isiyo na maana inayohesabiwa haki na uchambuzi wa nambari zisizo za maana.
///
/// Inazunguka "f" kwa kuelea na maana ya 64 na kuizidisha kwa ukadiriaji bora wa `10^e` (kwa muundo ule ule wa kuelea).Hii mara nyingi inatosha kupata matokeo sahihi.
/// Walakini, wakati matokeo yanakaribia nusu katikati ya kuelea karibu kwa (ordinary), kosa la kuzungusha kiwanja kutoka kuzidisha kukadiriwa mbili inamaanisha kuwa matokeo yanaweza kuzimwa na vipande kadhaa.
/// Wakati hii inatokea, Algorithm R iterative hurekebisha mambo.
///
/// X-X ya wavy ya mkono imefanywa sahihi na uchambuzi wa nambari kwenye karatasi.
/// Kwa maneno ya Clinger:
///
/// > Mteremko, ulioonyeshwa kwa vitengo vya kitu kidogo, ni kifungo kilichojumuishwa kwa kosa
/// > kusanyiko wakati wa hesabu ya hatua inayoelea ya takriban kwa f * 10 ^ e.(Mteremko ni
/// > sio kifungo kwa kosa la kweli, lakini inapakana tofauti kati ya takriban z na
/// > takriban inayowezekana inayotumia vipande vya maana.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Kesi abs(e) <log5(2^N) ziko fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Je! Mteremko ni mkubwa wa kutosha kuleta mabadiliko wakati unazunguka kwa bits n?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algorithm ya iterative ambayo inaboresha makadirio ya hatua inayoelea ya `f * 10^e`.
///
/// Kila iteration hupata kitengo kimoja mahali pa mwisho karibu, ambayo kwa kweli inachukua muda mrefu sana kuungana ikiwa `z0` imezimwa kidogo.
/// Kwa bahati nzuri, wakati inatumiwa kama kurudi nyuma kwa Bellerophon, ukadiriaji wa kuanzia umezimwa na angalau ULP moja.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Pata nambari chanya `x`, `y` kama kwamba `x / y` ni `(f *10^e) / (m* 2^k)` haswa.
        // Hii sio tu inaepuka kushughulikia ishara za `e` na `k`, pia tunaondoa nguvu ya mbili za kawaida kwa `10^e` na `2^k` kufanya nambari ziwe ndogo.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Hii imeandikwa kidogo machoni kwa sababu bignums zetu haziungi mkono nambari hasi, kwa hivyo tunatumia habari kamili ya ishara +.
        // Kuzidisha na m_digits hakuwezi kufurika.
        // Ikiwa `x` au `y` ni kubwa vya kutosha kwamba tunahitaji kuwa na wasiwasi juu ya kufurika, basi pia ni kubwa kwa kutosha kwamba `make_ratio` imepunguza sehemu hiyo kwa sababu ya 2 ^ 64 au zaidi.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Usihitaji x tena, ila clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Bado unahitaji y, fanya nakala.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Ikipewa `x = f` na `y = m` ambapo `f` inawakilisha nambari za nambari za pembejeo kama kawaida na `m` ndio maana ya makadirio ya hatua inayoelea, fanya uwiano wa `x / y` kuwa sawa na `(f *10^e) / (m* 2^k)`, ikiwezekana kupunguzwa kwa nguvu ya wote wawili wanafanana.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, isipokuwa kwamba tunapunguza sehemu hiyo kwa nguvu kadhaa.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Hii haiwezi kufurika kwa sababu inahitaji chanya `e` na hasi `k`, ambayo inaweza kutokea tu kwa maadili karibu sana na 1, ambayo inamaanisha kuwa `e` na `k` zitakuwa ndogo sana.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Hii pia haiwezi kufurika, tazama hapo juu.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), tena ikipunguza kwa nguvu ya kawaida ya mbili.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Kwa kweli, Algorithm M ndio njia rahisi zaidi ya kubadilisha decimal kuwa kuelea.
///
/// Tunaunda uwiano ambao ni sawa na `f * 10^e`, kisha tunatupa nguvu za mbili mpaka itoe maana ya kuelea halali.
/// Kielelezo cha binary `k` ni idadi ya nyakati ambazo tulizidisha nambari au dhehebu kwa mbili, yaani, wakati wote `f *10^e` ni sawa na `(u / v)* 2^k`.
/// Wakati tumegundua umuhimu, tunahitaji tu kuzunguka kwa kukagua sehemu iliyobaki ya mgawanyiko, ambayo hufanywa katika kazi za msaidizi zaidi hapa chini.
///
///
/// Algorithm hii ni polepole sana, hata na uboreshaji ulioelezewa katika `quick_start()`.
/// Walakini, ni njia rahisi zaidi ya kuzoea kufurika, kufurika, na matokeo yasiyo ya kawaida.
/// Utekelezaji huu unachukua wakati Bellerophon na Algorithm R wamezidiwa.
/// Kugundua kufurika na kufurika ni rahisi: Uwiano bado sio maana ya anuwai, lakini ufikiaji wa minimum/maximum umefikiwa.
/// Katika kesi ya kufurika, tunarudi tu infinity.
///
/// Kushughulikia mafuriko na hali isiyo ya kawaida ni ngumu zaidi.
/// Shida moja kubwa ni kwamba, na kiboreshaji cha chini, uwiano bado unaweza kuwa mkubwa sana kwa maana.
/// Tazama underflow() kwa maelezo.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Uboreshaji unaowezekana wa FIXME: tengeneza kubwa_to_fp ili tuweze kufanya sawa na fp_to_float(big_to_fp(u)) hapa, tu bila kuzungusha mara mbili.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Lazima tuache kwa kiwango cha chini, ikiwa tutasubiri hadi `k < T::MIN_EXP_INT`, basi tutakuwa mbali na sababu ya mbili.
            // Kwa bahati mbaya hii inamaanisha lazima tuwe na nambari maalum za kawaida na kiboreshaji cha chini.
            // FIXME pata uundaji wa kifahari zaidi, lakini jaribu jaribio la `tiny-pow10` kuhakikisha kuwa ni kweli!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Ruka juu ya mahesabu mengi ya Algorithm M kwa kuangalia urefu kidogo.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Urefu kidogo ni makadirio ya msingi logarithm mbili, na log(u / v) = log(u), log(v).
    // Makadirio yamezimwa kwa zaidi ya 1, lakini siku zote makadirio ya chini, kwa hivyo kosa kwenye log(u) na log(v) ni ishara moja na kufuta (ikiwa zote mbili ni kubwa).
    // Kwa hivyo kosa la log(u / v) ni moja pia.
    // Uwiano wa lengo ni moja ambapo u/v iko katika umuhimu wa masafa.Kwa hivyo hali yetu ya kukomesha ni log2(u / v) kuwa vipande vya maana, plus/minus moja.
    // FIXME Kuangalia kidogo ya pili kunaweza kuboresha makadirio na kuzuia mgawanyiko zaidi.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Kufurika au isiyo ya kawaida.Acha kwa kazi kuu.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Kufurika.Acha kwa kazi kuu.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Uwiano sio maana ya anuwai na kiboreshaji cha chini, kwa hivyo tunahitaji kuzungusha vipande vya ziada na kurekebisha upeo ipasavyo.
    // Thamani halisi sasa inaonekana kama hii:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(inawakilishwa na rem)
    //
    // Kwa hivyo, wakati bits zilizozungukwa ziko!= 0.5 ULP, wanaamua kuzunguka peke yao.
    // Wakati zinalingana na salio sio sifuri, thamani bado inahitaji kuzungushwa.
    // Ni wakati tu vipande vilivyozungukwa ni 1/2 na salio ni sifuri, tuna hali ya nusu-hata.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Kawaida ya pande zote-hadi-hata, iliyofunikwa kwa kuzunguka kwa kuzingatia sehemu iliyobaki ya mgawanyiko.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}