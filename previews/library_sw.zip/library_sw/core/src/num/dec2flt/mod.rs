//! Kubadilisha masharti ya desimali kuwa nambari za uhakika zinazoelea za IEEE 754.
//!
//! # Taarifa ya shida
//!
//! Tunapewa kamba ya desimali kama vile `12.34e56`.
//! Kamba hii inajumuisha (`12`) muhimu, sehemu ya (`34`), na sehemu za (`56`).Sehemu zote ni za hiari na zinatafsiriwa kama sifuri wakati zinakosekana.
//!
//! Tunatafuta nambari ya uhakika inayoelea ya IEEE 754 ambayo iko karibu zaidi na dhamana halisi ya kamba ya desimali.
//! Inajulikana kuwa nyuzi nyingi za desimali hazina uwakilishi wa kumaliza katika msingi wa pili, kwa hivyo tunazunguka kwa vitengo vya 0.5 mahali pa mwisho (kwa maneno mengine, na pia iwezekanavyo).
//! Vifungo, maadili ya desimali haswa nusu ya njia kati ya kuelea mbili mfululizo, hutatuliwa na mkakati wa nusu-hata, unaojulikana pia kama kuzunguka kwa benki.
//!
//! Bila kusema, hii ni ngumu sana, kwa suala la ugumu wa utekelezaji na kwa mizunguko ya CPU iliyochukuliwa.
//!
//! # Implementation
//!
//! Kwanza, tunapuuza ishara.Au tuseme, tunaiondoa mwanzoni mwa mchakato wa uongofu na kuitumia tena mwishowe.
//! Hii ni sahihi katika visa vyote vya edge kwani kuelea kwa IEEE ni ulinganifu karibu na sifuri, ukipuuza moja hupindua kidogo kwanza.
//!
//! Kisha tunaondoa hatua ya desimali kwa kurekebisha kiboreshaji: Kwa kweli, `12.34e56` inageuka kuwa `1234e54`, ambayo tunaelezea na nambari chanya `f = 1234` na nambari kamili ya `e = 54`.
//! Uwakilishi wa `(f, e)` hutumiwa na karibu nambari zote zilizopita hatua ya kuchambua.
//!
//! Kisha tunajaribu mlolongo mrefu wa kesi maalum zinazoendelea zaidi na za bei ghali kwa kutumia nambari za ukubwa wa mashine na nambari ndogo, zenye ukubwa wa kuelea (`f32`/`f64` ya kwanza, kisha aina iliyo na maana ya 64, `Fp`).
//!
//! Wakati haya yote yanashindwa, tunauma risasi na tunatumia algorithm rahisi lakini polepole sana ambayo ilijumuisha kuhesabu `f * 10^e` kikamilifu na kufanya utaftaji wa kurudia wa kukadiria bora.
//!
//! Kimsingi, moduli hii na watoto wake hufanya algorithms zilizoelezewa katika:
//! "How to Read Floating Point Numbers Accurately" na William D.
//! Clinger, inapatikana mtandaoni: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Kwa kuongeza, kuna kazi nyingi za wasaidizi ambazo hutumiwa kwenye karatasi lakini hazipatikani katika Rust (au angalau kwa msingi).
//! Toleo letu ni ngumu zaidi na hitaji la kushughulikia kufurika na kufurika na hamu ya kushughulikia nambari zisizo za kawaida.
//! Bellerophon na Algorithm R wana shida na kufurika, kawaida, na kufurika.
//! Tunabadilisha kwa usawa Algorithm M (na marekebisho yaliyoelezewa katika sehemu ya 8 ya karatasi) vizuri kabla ya pembejeo kuingia katika mkoa muhimu.
//!
//! Jambo lingine ambalo linahitaji umakini ni "RawFloat" trait ambayo karibu kazi zote zinawekwa.Mtu anaweza kufikiria kuwa ni ya kutosha kuchanganua kwa `f64` na kutupa matokeo kwa `f32`.
//! Kwa bahati mbaya hii sio dunia tunayoishi, na hii haihusiani na kutumia msingi wa mbili au nusu-hata-kuzungusha.
//!
//! Fikiria kwa mfano aina mbili `d2` na `d4` inayowakilisha aina ya decimal na tarakimu mbili za desimali na nambari nne za decimal kila moja na uchukue "0.01499" kama pembejeo.Wacha tutumie kuzungusha nusu-up.
//! Kuenda moja kwa moja kwa nambari mbili za desimali kunatoa `0.01`, lakini ikiwa tunazunguka hadi nambari nne kwanza, tunapata `0.0150`, ambayo imezungukwa hadi `0.02`.
//! Kanuni hiyo hiyo inatumika kwa shughuli zingine pia, ikiwa unataka usahihi wa 0.5 ULP unahitaji kufanya *kila kitu* kwa usahihi kamili na pande zote *mara moja, mwishoni*, kwa kuzingatia bits zote zilizokatwa mara moja.
//!
//! FIXME: Ingawa urudiaji wa nambari ni muhimu, labda sehemu za nambari zinaweza kuzungushwa kuzunguka kwa sababu nambari ndogo imerudiwa.
//! Sehemu kubwa za algorithms hazijitegemea aina ya kuelea kwa pato, au inahitaji tu ufikiaji wa vichaka kadhaa, ambavyo vinaweza kupitishwa kama vigezo.
//!
//! # Other
//!
//! Uongofu haupaswi * panic.
//! Kuna madai na panics wazi katika nambari, lakini hazipaswi kusababishwa na zinatumika kama ukaguzi wa ndani wa akili.panics yoyote inapaswa kuzingatiwa kama mdudu.
//!
//! Kuna majaribio ya kitengo lakini hayatoshi kwa kuhakikisha usahihi, yanashughulikia tu asilimia ndogo ya makosa yanayowezekana.
//! Vipimo vya kina zaidi viko kwenye saraka `src/etc/test-float-parse` kama hati ya Python.
//!
//! Ujumbe juu ya kufurika kwa nambari: Sehemu nyingi za faili hii hufanya hesabu na kidokezo cha decimal `e`.
//! Kimsingi, tunabadilisha hatua ya decimal karibu: Kabla ya nambari ya kwanza ya decimal, baada ya nambari ya mwisho ya decimal, na kadhalika.Hii inaweza kufurika ikiwa itafanywa ovyo.
//! Tunategemea kijitabu kidogo cha kuchanganua kutoa vionyeshi vidogo vya kutosha, ambapo "sufficient" inamaanisha "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Vionyeshi vikubwa vinakubaliwa, lakini hatuwezi kufanya hesabu nao, hubadilishwa mara moja kuwa {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Hawa wawili wana vipimo vyao.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Inabadilisha kamba katika msingi wa 10 kuelea.
            /// Hukubali kionyeshi cha hiari cha hiari.
            ///
            /// Kazi hii inakubali masharti kama vile
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', au vile vile, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', au, sawa, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Nyeupe inayoongoza na inayofuatilia inawakilisha kosa.
            ///
            /// # Grammar
            ///
            /// Kamba zote zinazofuata sarufi ifuatayo ya [EBNF] zitasababisha [`Ok`] kurudishwa:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Mende inayojulikana
            ///
            /// Katika hali zingine, kamba zingine ambazo zinapaswa kuunda kuelea halali badala yake hurudisha kosa.
            /// Tazama [issue #31407] kwa maelezo.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Kamba
            ///
            /// # Rudisha thamani
            ///
            /// `Err(ParseFloatError)` ikiwa kamba haikuwakilisha nambari halali.
            /// Vinginevyo, `Ok(n)` ambapo `n` ni nambari ya kuelea-inayowakilishwa na `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Hitilafu ambayo inaweza kurudishwa wakati wa kuchanganua kuelea.
///
/// Kosa hili hutumiwa kama aina ya kosa kwa utekelezaji wa [`FromStr`] kwa [`f32`] na [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Inagawanya kamba ya desimali kuwa ishara na iliyobaki, bila kukagua au kuidhinisha iliyobaki.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Ikiwa kamba ni batili, kamwe hatutumii ishara, kwa hivyo hatuhitaji kudhibitisha hapa.
        _ => (Sign::Positive, s),
    }
}

/// Hubadilisha kamba ya desimali kuwa nambari ya kuelea.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Kazi kuu ya ubadilishaji wa decimal-kwa-kuelea: Panga utaftaji wote na ujue ni algorithm gani inayofaa kufanya ubadilishaji halisi.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift nje hatua ya decimal.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 imepunguzwa kwa bits 1280, ambayo inatafsiriwa kwa nambari zipatazo 385.
    // Ikiwa tutazidi hii, tutaanguka, kwa hivyo tunakosea kabla ya kukaribia sana (ndani ya 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Sasa kielekezi hakika inafaa kwa 16 kidogo, ambayo hutumiwa katika algorithms kuu.
    let e = e as i16;
    // FIXME Mipaka hii ni badala ya kihafidhina.
    // Uchambuzi wa uangalifu zaidi wa njia za kutofaulu za Bellerophon inaweza kuruhusu kuitumia katika hali zaidi kwa kasi kubwa.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Kama ilivyoandikwa, hii inaboresha vibaya (tazama #27130, ingawa inahusu toleo la zamani la nambari).
// `inline(always)` ni kazi kwa hiyo.
// Kuna tovuti mbili tu za simu kwa jumla na haifanyi ukubwa wa msimbo kuwa mbaya zaidi.

/// Ukanda ziro inapowezekana, hata wakati hii inahitaji kubadilisha kiboreshaji
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Kukata sifuri hizi hakubadilishi chochote lakini kunaweza kuwezesha njia ya haraka (<tarakimu 15).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Kurahisisha nambari za fomu 0.0 ... x na x ... 0.0, kurekebisha kiboreshaji ipasavyo.
    // Hii inaweza kuwa sio ushindi kila wakati (labda inasukuma nambari kadhaa kutoka kwa njia ya haraka), lakini inarahisisha sehemu zingine kwa kiasi kikubwa (haswa, kukadiria ukubwa wa thamani).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Hurejesha kifungo cha juu-chafu juu juu ya saizi ya (log10) ya thamani kubwa zaidi ambayo Algorithm R na Algorithm M itahesabu wakati wa kufanya kazi kwa desimali iliyopewa.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Hatuna haja ya kuwa na wasiwasi sana juu ya kufurika hapa kwa shukrani kwa trivial_cases() na msuluhishi, ambayo huchuja pembejeo kali zaidi kwetu.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Katika kesi e>=0, algorithms zote mbili zinahesabu kuhusu `f * 10^e`.
        // Algorithm R inaendelea kufanya mahesabu magumu na hii lakini tunaweza kuipuuza hiyo kwa walio juu kwa sababu pia hupunguza sehemu kabla, kwa hivyo tuna bafa nyingi hapo.
        //
        f_len + (e as u64)
    } else {
        // Ikiwa e <0, Algorithm R inafanya kitu sawa, lakini Algorithm M inatofautiana:
        // Inajaribu kupata nambari nzuri k kama vile `f << k / 10^e` ni ya maana ya anuwai.
        // Hii itasababisha karibu `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Uingizaji mmoja unaosababisha hii ni 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Inagundua kufurika dhahiri na mafuriko bila hata kuangalia nambari za desimali.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Kulikuwa na zero lakini zilivuliwa na simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Huu ni ukadiriaji mbaya wa ceil(log10(the real value)).
    // Hatuna haja ya kuwa na wasiwasi sana juu ya kufurika hapa kwa sababu urefu wa pembejeo ni mdogo (angalau ikilinganishwa na 2 ^ 64) na mtangulizi tayari anashughulikia vielelezo ambavyo dhamana yake ni kubwa kuliko 10 ^ 18 (ambayo bado ni 10 ^ 19 fupi ya 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}