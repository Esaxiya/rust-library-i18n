//! Kazi za matumizi kwa bignums ambazo hazina maana sana kugeuza kuwa njia.

// FIXME Jina la moduli hii ni bahati mbaya, kwani moduli zingine pia huingiza `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Jaribu ikiwa kukata vipande vyote chini ya `ones_place` huleta kosa la jamaa chini, sawa, au kubwa kuliko 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ikiwa bits zote zilizobaki ni sifuri, ni= 0.5 ULP, vinginevyo> 0.5 Ikiwa hakuna bits zaidi (half_bit==0), chini pia inarudi Sawa sawa.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Hubadilisha kamba ya ASCII iliyo na tarakimu tu za desimali kuwa `u64`.
///
/// Haifanyi ukaguzi wa herufi za kufurika au batili, kwa hivyo ikiwa mpigaji hayuko mwangalifu, matokeo yake ni ya uwongo na inaweza panic (ingawa haitakuwa `unsafe`).
/// Kwa kuongeza, kamba tupu zinachukuliwa kama sifuri.
/// Kazi hii ipo kwa sababu
///
/// 1. kutumia `FromStr` kwenye `&[u8]` inahitaji `from_utf8_unchecked`, ambayo ni mbaya, na
/// 2. kukusanya pamoja matokeo ya `integral.parse()` na `fractional.parse()` ni ngumu zaidi kuliko kazi hii yote.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Inabadilisha kamba ya nambari za ASCII kuwa bignum.
///
/// Kama `from_str_unchecked`, kazi hii inategemea msuluhishi kupalilia nambari zisizo za kawaida.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Unwraps bignum kwa nambari 64 kidogo.Panics ikiwa nambari ni kubwa mno.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Inatoa vipande kadhaa.

/// Kielelezo 0 ni kidogo muhimu na masafa ni wazi kama kawaida.
/// Panics ikiulizwa kutoa bits zaidi ya fit katika aina ya kurudi.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}