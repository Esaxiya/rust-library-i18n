//! Mara kwa mara maalum kwa aina ya uhakika ya `f64` yenye usahihi mara mbili.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Nambari muhimu za hesabu hutolewa katika moduli ndogo ya `consts`.
//!
//! Kwa vifungu vilivyofafanuliwa moja kwa moja katika moduli hii (kama tofauti na ilivyoainishwa katika moduli ndogo ya `consts`), nambari mpya inapaswa badala yake kutumia vizuizi vinavyohusiana vilivyoelezewa moja kwa moja kwenye aina ya `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix au msingi wa uwakilishi wa ndani wa `f64`.
/// Tumia [`f64::RADIX`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // njia iliyokusudiwa
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Idadi ya nambari muhimu katika msingi 2.
/// Tumia [`f64::MANTISSA_DIGITS`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // njia iliyokusudiwa
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Idadi ya nambari muhimu katika msingi 10.
/// Tumia [`f64::DIGITS`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // njia iliyokusudiwa
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] thamani ya `f64`.
/// Tumia [`f64::EPSILON`] badala yake.
///
/// Hii ndio tofauti kati ya `1.0` na nambari inayofuata inayowakilisha kubwa.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // njia iliyokusudiwa
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Thamani ndogo ndogo ya `f64`.
/// Tumia [`f64::MIN`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // njia iliyokusudiwa
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Thamani ndogo ndogo ya kawaida ya `f64`.
/// Tumia [`f64::MIN_POSITIVE`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // njia iliyokusudiwa
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Thamani kubwa zaidi ya `f64`.
/// Tumia [`f64::MAX`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // njia iliyokusudiwa
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Moja kubwa kuliko nguvu ya kawaida inayowezekana ya 2 exponent.
/// Tumia [`f64::MIN_EXP`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // njia iliyokusudiwa
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Upeo wa nguvu inayowezekana ya 2 exponent.
/// Tumia [`f64::MAX_EXP`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // njia iliyokusudiwa
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Nguvu ndogo ya kawaida inayowezekana ya 10 exponent.
/// Tumia [`f64::MIN_10_EXP`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // njia iliyokusudiwa
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Upeo wa nguvu inayowezekana ya 10 exponent.
/// Tumia [`f64::MAX_10_EXP`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // njia iliyokusudiwa
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Sio Nambari (NaN).
/// Tumia [`f64::NAN`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // njia iliyokusudiwa
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Tumia [`f64::INFINITY`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // njia iliyokusudiwa
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Ukosefu duni wa (−∞).
/// Tumia [`f64::NEG_INFINITY`] badala yake.
///
/// # Examples
///
/// ```rust
/// // njia iliyopunguzwa
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // njia iliyokusudiwa
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Msingi wa msingi wa hesabu.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: badilisha nafasi za hesabu kutoka cmath.

    /// Archimedes (π) mara kwa mara
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Mzunguko kamili (τ)
    ///
    /// Sawa na 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Nambari ya Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Radix au msingi wa uwakilishi wa ndani wa `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Idadi ya nambari muhimu katika msingi 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Idadi ya nambari muhimu katika msingi 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] thamani ya `f64`.
    ///
    /// Hii ndio tofauti kati ya `1.0` na nambari inayofuata inayowakilisha kubwa.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Thamani ndogo ndogo ya `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Thamani ndogo ndogo ya kawaida ya `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Thamani kubwa zaidi ya `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Moja kubwa kuliko nguvu ya kawaida inayowezekana ya 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Upeo wa nguvu inayowezekana ya 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Nguvu ndogo ya kawaida inayowezekana ya 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Upeo wa nguvu inayowezekana ya 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Sio Nambari (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Ukosefu duni wa (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Hurejesha `true` ikiwa thamani hii ni `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` haipatikani hadharani kwa idadi kubwa ya watu kwa sababu ya wasiwasi juu ya ubebekaji, kwa hivyo utekelezaji huu ni wa matumizi ya kibinafsi ndani.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Hurejesha `true` ikiwa thamani hii ni infinity nzuri au infinity hasi, na `false` vinginevyo.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Hurejesha `true` ikiwa nambari hii haina kipimo wala `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Hakuna haja ya kushughulikia NaN kando: ikiwa ubinafsi ni NaN, kulinganisha sio kweli, haswa kama inavyotakiwa.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Hurejesha `true` ikiwa nambari ni [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Maadili kati ya `0` na `min` sio kawaida.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Hurejesha `true` ikiwa nambari sio sifuri, haina mwisho, [subnormal], au `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Maadili kati ya `0` na `min` sio kawaida.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Hurejesha kategoria ya nambari iliyoelea.
    /// Ikiwa mali moja tu itajaribiwa, kwa ujumla ni haraka zaidi kutumia kiarifu maalum badala yake.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Hurejesha `true` ikiwa `self` ina ishara chanya, pamoja na `+0.0`, NaN iliyo na ishara nzuri na infinity nzuri.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Hurejesha `true` ikiwa `self` ina ishara hasi, pamoja na `-0.0`, `NaN iliyo na ishara hasi kidogo na infinity hasi.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Inachukua nambari ya kurudisha (inverse) ya nambari, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Inabadilisha radians kuwa digrii.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Mgawanyiko hapa umezungukwa kwa usahihi kulingana na thamani ya kweli ya 180/π.
        // (Hii ni tofauti na f32, ambapo lazima kila wakati itumike kuhakikisha matokeo yaliyozungushwa kwa usahihi.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Inabadilisha digrii kuwa mionzi.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Hurejesha upeo wa nambari mbili.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ikiwa moja ya hoja ni NaN, basi hoja nyingine inarudishwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Hurejesha kiwango cha chini cha nambari mbili.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ikiwa moja ya hoja ni NaN, basi hoja nyingine inarudishwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Huzungusha kuelekea sifuri na hubadilika kuwa aina yoyote ya nambari ya zamani, kwa kudhani kuwa thamani ni ya mwisho na inafaa katika aina hiyo.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Thamani lazima:
    ///
    /// * Usiwe `NaN`
    /// * Isiwe isiyo na mwisho
    /// * Kuwa mwakilishi katika aina ya kurudi `Int`, baada ya kukata sehemu yake ya sehemu
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Usafirishaji mbichi kwa `u64`.
    ///
    /// Hii kwa sasa inafanana na `transmute::<f64, u64>(self)` kwenye majukwaa yote.
    ///
    /// Tazama `from_bits` kwa majadiliano kadhaa ya uwezekano wa operesheni hii (karibu hakuna maswala).
    ///
    /// Kumbuka kuwa kazi hii ni tofauti na utaftaji wa `as`, ambao unajaribu kuhifadhi thamani ya * nambari, na sio thamani kidogo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() sio kutupa!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // USALAMA: `u64` ni orodha ya zamani ya wazi ili tuweze kuipitia kila wakati
        unsafe { mem::transmute(self) }
    }

    /// Transutation mbichi kutoka `u64`.
    ///
    /// Hii kwa sasa inafanana na `transmute::<u64, f64>(v)` kwenye majukwaa yote.
    /// Inageuka kuwa hii ni rahisi kusonga, kwa sababu mbili:
    ///
    /// * Floats na Ints zina uvumilivu sawa kwenye majukwaa yote yanayoungwa mkono.
    /// * IEEE-754 inabainisha kwa usahihi mpangilio wa kuelea.
    ///
    /// Walakini kuna pango moja: kabla ya toleo la 2008 la IEEE-754, jinsi ya kutafsiri kidogo ishara ya NaN haikuainishwa haswa.
    /// Majukwaa mengi (haswa x86 na ARM) yalichukua tafsiri ambayo mwishowe ilisimamishwa mnamo 2008, lakini zingine hazikufanya (haswa MIP).
    /// Kama matokeo, ishara zote za NaNs kwenye MIPS ni NaN za utulivu kwenye x86, na kinyume chake.
    ///
    /// Badala ya kujaribu kuhifadhi ishara-jukwa la msalaba, utekelezaji huu unapendelea kuhifadhi bits halisi.
    /// Hii inamaanisha kuwa malipo yoyote yaliyowekwa kwenye NaN yatahifadhiwa hata kama matokeo ya njia hii yatumwa juu ya mtandao kutoka kwa mashine ya x86 hadi MIPS moja.
    ///
    ///
    /// Ikiwa matokeo ya njia hii yanadanganywa tu na usanifu uleule uliowazalisha, basi hakuna wasiwasi wa kubeba.
    ///
    /// Ikiwa pembejeo sio NaN, basi hakuna wasiwasi wa kubeba.
    ///
    /// Ikiwa haujali juu ya kuashiria-ishara (uwezekano mkubwa), basi hakuna wasiwasi wa kuambukizwa.
    ///
    /// Kumbuka kuwa kazi hii ni tofauti na utaftaji wa `as`, ambao unajaribu kuhifadhi thamani ya * nambari, na sio thamani kidogo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // USALAMA: `u64` ni orodha ya zamani ya wazi ili tuweze kusambaza kutoka kwake kila wakati
        // Inageuka kuwa maswala ya usalama na sNaN yalizidiwa!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Rudisha uwakilishi wa kumbukumbu ya nambari hii ya kuelea kama safu ya ka katika mpangilio wa baiti kubwa ya Xian X00.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Rudisha uwakilishi wa kumbukumbu ya nambari hii ya kuelea kama safu ya baiti kwa mpangilio wa kaiti kidogo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Rudisha uwakilishi wa kumbukumbu ya nambari hii ya kuelea kama safu ya ka katika mpangilio wa baiti ya asili.
    ///
    /// Kama endianness ya jukwaa lengwa inavyotumiwa, nambari inayoweza kubeba inapaswa kutumia [`to_be_bytes`] au [`to_le_bytes`], kama inafaa, badala yake.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Rudisha uwakilishi wa kumbukumbu ya nambari hii ya kuelea kama safu ya ka katika mpangilio wa baiti ya asili.
    ///
    ///
    /// [`to_ne_bytes`] inapaswa kupendelewa kuliko hii kila inapowezekana.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // USALAMA: `f64` ni orodha ya zamani ya wazi ili tuweze kuipitia kila wakati
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Unda nambari ya kuelea kutoka kwa uwakilishi wake kama safu ya kaa katika endian kubwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Unda nambari ya kuelea kutoka kwa uwakilishi wake kama safu ya ka katika endian kidogo.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Unda thamani ya hatua inayoelea kutoka kwa uwakilishi wake kama safu ya ka katika endian asili.
    ///
    /// Kama endianness ya jukwaa lengwa inavyotumiwa, nambari inayoweza kusonga huenda inataka kutumia [`from_be_bytes`] au [`from_le_bytes`], inavyofaa badala yake.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Hurejesha kuagiza kati ya maadili ya kibinafsi na mengine.
    /// Tofauti na kulinganisha kwa kiwango kati ya nambari za kuelea, kulinganisha hii kila wakati kunatoa kuagiza kwa mujibu wa mtabiri wa jumla wa Order kama inavyoelezwa katika IEEE 754 (marekebisho ya 2008) ya kiwango cha kuelea.
    /// Thamani zimeamriwa kwa kufuata:
    /// - Heri ya utulivu NaN
    /// - Kuashiria hasi NaN
    /// - Ukosefu mdogo
    /// - Nambari hasi
    /// - Nambari mbaya zisizo za kawaida
    /// - Zero hasi
    /// - Sifuri nzuri
    /// - Nambari nzuri zisizo za kawaida
    /// - Nambari chanya
    /// - Ukomo mzuri
    /// - Ishara nzuri NaN
    /// - Chanya utulivu NaN
    ///
    /// Kumbuka kuwa kazi hii haikubaliani kila wakati na utekelezaji wa [`PartialOrd`] na [`PartialEq`] wa `f64`.Hasa, wanaona sifuri hasi na chanya sawa, wakati `total_cmp` haifanyi hivyo.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Kwa hali mbaya, geuza bits zote isipokuwa ishara ili kufikia mpangilio sawa kama nambari mbili za kukamilisha
        //
        // Kwa nini hii inafanya kazi?Kuelea kwa IEEE 754 kuna sehemu tatu:
        // Ishara kidogo, kionyeshi na mantissa.Seti ya sehemu za nje na za mantissa kwa jumla zina mali ambayo mpangilio wao kidogo ni sawa na ukubwa wa nambari ambapo ukubwa hufafanuliwa.
        // Ukubwa hauelezeki kawaida kwa maadili ya NaN, lakini IEEE 754 jumlaOrder hufafanua maadili ya NaN pia kufuata mpangilio wa busara.Hii inasababisha mpangilio ulioelezewa katika maoni ya hati.
        // Walakini, uwakilishi wa ukubwa ni sawa kwa nambari hasi na chanya-ishara kidogo tu ni tofauti.
        // Ili kulinganisha kwa urahisi kuelea kama nambari kamili zilizosainiwa, tunahitaji kupindua vijiti na alama za mantissa ikiwa nambari hasi.
        // Tunabadilisha nambari kuwa fomu ya "two's complement".
        //
        // Ili kufanya kubonyeza, tunaunda kinyago na XOR dhidi yake.
        // Sisi bila hesabu tunahesabu kinyago cha "all-ones except for the sign bit" kutoka kwa nambari zilizosainiwa hasi: ishara ya kuhamisha kulia-inapanua nambari, kwa hivyo sisi "fill" kinyago na alama za ishara, kisha tunabadilisha kuwa saini kushinikiza sifuri kidogo.
        //
        // Kwa maadili mazuri, kinyago ni zero zote, kwa hivyo sio op-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Zuia thamani kwa muda fulani isipokuwa ni NaN.
    ///
    /// Hurejesha `max` ikiwa `self` ni kubwa kuliko `max`, na `min` ikiwa `self` ni chini ya `min`.
    /// Vinginevyo hii inarudi `self`.
    ///
    /// Kumbuka kuwa kazi hii inarudi NaN ikiwa thamani ya awali ilikuwa NaN pia.
    ///
    /// # Panics
    ///
    /// Panics ikiwa `min > max`, `min` ni NaN, au `max` ni NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}