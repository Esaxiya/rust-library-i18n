//! Iteration inayofanana ya asynchronous.
//!
//! Ikiwa futures ni maadili ya kupendeza, basi mito ni iterators asynchronous.
//! Ikiwa umejikuta na mkusanyiko wa aina fulani, na inahitajika kufanya operesheni kwenye vitu vya mkusanyiko uliosema, utaingia 'streams' haraka.
//! Mito hutumika sana katika nambari ya Rust ya ujinga, kwa hivyo inafaa kufahamiana nayo.
//!
//! Kabla ya kuelezea zaidi, wacha tuzungumze juu ya jinsi moduli hii imeundwa:
//!
//! # Organization
//!
//! Moduli hii kwa kiasi kikubwa imepangwa na aina:
//!
//! * [Traits] ni sehemu ya msingi: hizi traits hufafanua ni aina gani ya mito iliyopo na nini unaweza kufanya nayo.Njia za traits hizi zinafaa kuweka wakati wa ziada wa kusoma ndani.
//! * Kazi hutoa njia kadhaa za kusaidia kuunda mito ya kimsingi.
//! * Structs mara nyingi ni aina za kurudi kwa njia anuwai kwenye traits ya moduli hii.Kawaida utataka kuangalia njia ambayo inaunda `struct`, badala ya `struct` yenyewe.
//! Kwa undani zaidi juu ya kwanini, tazama '[Utekelezaji wa Mkondo](#utekelezaji-mkondo)'.
//!
//! [Traits]: #traits
//!
//! Hiyo ndio!Wacha tuchimbe kwenye vijito.
//!
//! # Stream
//!
//! Moyo na roho ya moduli hii ni [`Stream`] trait.Kiini cha [`Stream`] kinaonekana kama hii:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Tofauti na `Iterator`, `Stream` hufanya tofauti kati ya njia ya [`poll_next`] ambayo hutumiwa wakati wa kutekeleza `Stream`, na njia ya (to-be-implemented) `next` ambayo hutumiwa wakati unatumia mkondo.
//!
//! Watumiaji wa `Stream` wanahitaji tu kuzingatia `next`, ambayo ikiitwa, inarudisha future ambayo inatoa `Option<Stream::Item>`.
//!
//! future iliyorudishwa na `next` itatoa `Some(Item)` maadamu kuna vitu, na mara tu vikiwa vimechoka, itatoa `None` kuonyesha kwamba iteration imekamilika.
//! Ikiwa tunasubiri kitu cha kusuluhisha kusuluhisha, future itasubiri hadi mkondo uwe tayari kutoa tena.
//!
//! Mito ya mtu binafsi inaweza kuchagua kuanza tena iteration, na hivyo kupiga simu `next` tena inaweza au haiwezi kutoa `Some(Item)` tena wakati fulani.
//!
//! Ufafanuzi kamili wa "Mkondo" unajumuisha njia zingine kadhaa pia, lakini ni njia chaguomsingi, zilizojengwa juu ya [`poll_next`], na kwa hivyo unazipata bure.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Utekelezaji wa Mkondo
//!
//! Kuunda mkondo wako mwenyewe kunajumuisha hatua mbili: kuunda `struct` kushikilia hali ya mkondo, na kisha kutekeleza [`Stream`] kwa `struct` hiyo.
//!
//! Wacha tufanye mkondo uitwao `Counter` ambao unahesabu kutoka `1` hadi `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Kwanza, muundo:
//!
//! /// Mto ambao unahesabu kutoka moja hadi tano
//! struct Counter {
//!     count: usize,
//! }
//!
//! // tunataka hesabu yetu ianze kwa moja, kwa hivyo wacha tuongeze njia ya new() kusaidia.
//! // Hii sio lazima sana, lakini ni rahisi.
//! // Kumbuka kuwa tunaanza `count` kwa sifuri, tutaona ni kwanini katika utekelezaji wa `poll_next()`'s hapa chini.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Halafu, tunatekeleza `Stream` kwa `Counter` yetu:
//!
//! impl Stream for Counter {
//!     // tutakuwa tunahesabu na usize
//!     type Item = usize;
//!
//!     // poll_next() ni njia pekee inayohitajika
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Kuongeza hesabu yetu.Hii ndio sababu tulianza sifuri.
//!         self.count += 1;
//!
//!         // Angalia kuona ikiwa tumemaliza kuhesabu au la.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Mito ni *wavivu*.Hii inamaanisha kuwa kuunda mkondo sio _do_ kabisa.Hakuna kinachotokea hadi upigie simu `next`.
//! Hii wakati mwingine ni chanzo cha mkanganyiko wakati wa kuunda mkondo tu kwa athari zake.
//! Mkusanyaji atatuonya juu ya tabia ya aina hii:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;