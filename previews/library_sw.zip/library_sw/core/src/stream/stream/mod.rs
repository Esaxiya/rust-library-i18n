use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Kiolesura cha kushughulika na iterators asynchronous.
///
/// Huu ndio mkondo mkuu trait.
/// Kwa habari zaidi juu ya dhana ya mito kwa ujumla, tafadhali angalia [module-level documentation].
/// Hasa, unaweza kutaka kujua jinsi ya [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Aina ya vitu vilivyotolewa na mkondo.
    type Item;

    /// Jaribu kuvuta thamani inayofuata ya mkondo huu, kusajili kazi ya sasa ya kuamka ikiwa thamani bado haipatikani, na kurudisha `None` ikiwa mkondo umeisha.
    ///
    /// # Rudisha thamani
    ///
    /// Kuna maadili kadhaa ya kurudi, kila moja inaonyesha hali tofauti ya mkondo:
    ///
    /// - `Poll::Pending` inamaanisha kuwa thamani inayofuata ya mkondo huu bado iko tayari.Utekelezaji utahakikisha kwamba kazi ya sasa itaarifiwa wakati thamani inayofuata inaweza kuwa tayari.
    ///
    /// - `Poll::Ready(Some(val))` inamaanisha kuwa mtiririko umefanikiwa kutoa thamani, `val`, na inaweza kutoa maadili zaidi kwa simu zinazofuata za `poll_next`.
    ///
    /// - `Poll::Ready(None)` inamaanisha kuwa mkondo umekoma, na `poll_next` haipaswi kutumiwa tena.
    ///
    /// # Panics
    ///
    /// Mkondo ukimaliza (kurudisha `Ready(None)` from `poll_next`), ikiita njia yake ya `poll_next` tena inaweza panic, kuzuia milele, au kusababisha shida zingine; `Stream` trait haitoi mahitaji yoyote juu ya athari za simu kama hiyo.
    ///
    /// Walakini, kwa kuwa njia ya `poll_next` haijawekwa alama `unsafe`, sheria za kawaida za Rust zinatumika: simu hazipaswi kusababisha tabia isiyojulikana (ufisadi wa kumbukumbu, utumiaji mbaya wa kazi za `unsafe`, au zingine kama hizo), bila kujali hali ya mkondo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Hurejesha mipaka kwenye urefu uliobaki wa mkondo.
    ///
    /// Hasa, `size_hint()` inarudisha Tuple ambapo kipengee cha kwanza ni kifungo cha chini, na kipengee cha pili ni kifungo cha juu.
    ///
    /// Nusu ya pili ya Tuple ambayo imerudishwa ni [`Chaguo`]`<<[[usize`] `>`.
    /// [`None`] hapa inamaanisha kuwa ama hakuna mipaka ya juu inayojulikana, au ya juu ni kubwa kuliko [`usize`].
    ///
    /// # Maelezo ya utekelezaji
    ///
    /// Haitekelezwi kuwa utekelezaji wa mkondo unatoa idadi iliyotangazwa ya vitu.Mtiririko wa gari unaweza kutoa chini ya iliyofungwa chini au zaidi ya mipaka ya juu ya vitu.
    ///
    /// `size_hint()` kimsingi inakusudiwa kutumiwa kwa uboreshaji kama vile kuhifadhi nafasi ya vipengee vya mkondo, lakini haipaswi kuaminiwa kwa mfano, sua ukaguzi wa mipaka katika nambari isiyo salama.
    /// Utekelezaji usio sahihi wa `size_hint()` haupaswi kusababisha ukiukaji wa usalama wa kumbukumbu.
    ///
    /// Hiyo ilisema, utekelezaji unapaswa kutoa makadirio sahihi, kwa sababu vinginevyo itakuwa ukiukaji wa itifaki ya trait.
    ///
    /// Utekelezaji chaguo-msingi unarudi `(0,` [`None`]`)`ambayo ni sahihi kwa mtiririko wowote.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}