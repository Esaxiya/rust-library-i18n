use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Wakati kazi hii inatumiwa katika sehemu moja na utekelezaji wake unaweza kuwekwa ndani, majaribio ya hapo awali ya kufanya hivyo yalifanya rustc polepole:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Mpangilio wa block ya kumbukumbu.
///
/// Mfano wa `Layout` inaelezea mpangilio fulani wa kumbukumbu.
/// Unaunda `Layout` kama pembejeo ya kumpa mtengaji.
///
/// Mipangilio yote ina saizi inayohusiana na mpangilio wa nguvu-mbili.
///
/// (Kumbuka kuwa mpangilio * hauhitajiki kuwa na saizi isiyo ya sifuri, ingawa `GlobalAlloc` inahitaji kwamba maombi yote ya kumbukumbu yawe yasiyo ya sifuri kwa saizi.
/// Anayepiga simu lazima ahakikishe kuwa hali kama hii imetimizwa, tumia watengaji maalum na mahitaji dhaifu, au utumie kiolesura laini zaidi cha `Allocator`.
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // saizi ya kizuizi cha kumbukumbu iliyoombwa, iliyopimwa kwa ka.
    size_: usize,

    // mpangilio wa kizuizi cha kumbukumbu kilichoombwa, kilichopimwa kwa ka.
    // tunahakikisha kuwa hii daima ni nguvu-ya-mbili, kwa sababu API kama `posix_memalign` inahitaji na ni kikwazo cha busara kulazimisha wajenzi wa Mpangilio.
    //
    //
    // (Walakini, hatuitaji kwa usawa `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Huunda `Layout` kutoka kwa `size` na `align`, au inarudi `LayoutError` ikiwa hali yoyote ifuatayo haijatimizwa:
    ///
    /// * `align` lazima isiwe sifuri,
    ///
    /// * `align` lazima iwe nguvu ya mbili,
    ///
    /// * `size`, ikikamilishwa kwa nambari ya karibu ya `align`, haipaswi kufurika (yaani, thamani iliyozungukwa lazima iwe chini au sawa na `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (nguvu-ya-mbili inamaanisha kujipanga!=0.)

        // Ukubwa uliokamilishwa ni:
        //   size_rounded_up=(saizi + pangilia, 1)&! (pangilia, 1);
        //
        // Tunajua kutoka hapo juu kuwa sawa!=0.
        // Ikiwa kuongeza (pangilia, 1) hakifuriki, basi kuzungusha itakuwa sawa.
        //
        // Kinyume chake,&-masking na! (Align, 1) itaondoa tu-oda-chini-bits.
        // Kwa hivyo ikiwa kufurika kunatokea kwa jumla,&-mask haiwezi kutoa ya kutosha kuondoa kufurika huko.
        //
        //
        // Hapo juu inamaanisha kuwa kuangalia kufurika kwa muhtasari ni muhimu na kwa kutosha.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // USALAMA: masharti ya `from_size_align_unchecked` yamekuwa
        // kuchunguzwa hapo juu.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Inaunda mpangilio, ikipita hundi zote.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama kwani haithibitishi masharti kutoka [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // USALAMA: mpigaji lazima ahakikishe kuwa `align` ni kubwa kuliko sifuri.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ukubwa wa chini wa ka kwa kizuizi cha kumbukumbu cha mpangilio huu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Upangiliaji mdogo wa baiti ya kizuizi cha kumbukumbu cha mpangilio huu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Inaunda `Layout` inayofaa kushikilia dhamana ya aina `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // USALAMA: mpangilio umehakikishiwa na Rust kuwa nguvu ya mbili na
        // saizi + ya kupangilia combo imehakikishiwa kutoshea katika nafasi yetu ya anwani.
        // Kama matokeo tumia mjenzi ambaye hajachunguzwa hapa ili kuzuia kuingiza nambari ambayo panics ikiwa haijaboreshwa vya kutosha.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Inazalisha mpangilio unaoelezea rekodi ambayo inaweza kutumiwa kutenga muundo wa kuunga mkono kwa `T` (ambayo inaweza kuwa trait au aina nyingine isiyo na ukubwa kama kipande).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // USALAMA: angalia mantiki katika `new` kwa nini hii inatumia tofauti isiyo salama
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Inazalisha mpangilio unaoelezea rekodi ambayo inaweza kutumiwa kutenga muundo wa kuunga mkono kwa `T` (ambayo inaweza kuwa trait au aina nyingine isiyo na ukubwa kama kipande).
    ///
    /// # Safety
    ///
    /// Kazi hii ni salama kupiga simu ikiwa hali zifuatazo zinashikilia:
    ///
    /// - Ikiwa `T` ni `Sized`, kazi hii ni salama kupiga simu kila wakati.
    /// - Ikiwa mkia usio na ukubwa wa `T` ni:
    ///     - [slice], basi urefu wa mkia wa kipande lazima iwe nambari kamili, na saizi ya *thamani nzima*(urefu wa mkia wenye nguvu + kiambishi cha ukubwa wa kitabaka) lazima iwe sawa na `isize`.
    ///     - [trait object], basi sehemu inayofaa ya kiboreshaji lazima ielekeze kwa vtable halali ya aina `T` iliyopatikana na coersion isiyo na ukubwa, na saizi ya *thamani nzima*(urefu wa mkia wenye nguvu + kiambishi cha ukubwa wa takwimu) lazima iwe sawa na `isize`.
    ///
    ///     - (unstable) [extern type], basi kazi hii ni salama kupiga simu kila wakati, lakini panic au vinginevyo irudishe thamani isiyofaa, kwani mpangilio wa aina ya nje haujulikani.
    ///     Hii ni tabia sawa na [`Layout::for_value`] kwenye kumbukumbu ya mkia wa aina ya nje.
    ///     - vinginevyo, hairuhusiwi kihalisi kuita kazi hii.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // USALAMA: tunapitisha mahitaji ya kazi hizi kwa mpigaji
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // USALAMA: angalia mantiki katika `new` kwa nini hii inatumia tofauti isiyo salama
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Inaunda `NonNull` ambayo inaning'inia, lakini iliyokaa vizuri kwa Mpangilio huu.
    ///
    /// Kumbuka kuwa thamani ya pointer inaweza kuwakilisha kiashiria halali, ambayo inamaanisha hii haipaswi kutumiwa kama thamani ya senti ya "not yet initialized".
    /// Aina ambazo hutenga kwa uvivu lazima zifuatilie uanzishaji kwa njia zingine.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // USALAMA: mpangilio umehakikishiwa kuwa sio sifuri
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Inaunda mpangilio unaoelezea rekodi ambayo inaweza kushikilia thamani ya mpangilio sawa na `self`, lakini hiyo pia imewekwa sawa na mpangilio wa `align` (kipimo kwa ka).
    ///
    ///
    /// Ikiwa `self` tayari inakidhi mpangilio uliowekwa, basi inarudi `self`.
    ///
    /// Kumbuka kuwa njia hii haiongezi padding yoyote kwa saizi ya jumla, bila kujali kama mpangilio uliorejeshwa una mpangilio tofauti.
    /// Kwa maneno mengine, ikiwa `K` ina saizi 16, `K.align_to(32)` itakuwa *bado* ina saizi 16.
    ///
    /// Hurejesha kosa ikiwa mchanganyiko wa `self.size()` na `align` uliyopewa inakiuka masharti yaliyoorodheshwa katika [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Hurejesha kiwango cha utaftaji lazima tuingize baada ya `self` ili kuhakikisha kuwa anwani ifuatayo itaridhisha `align` (imepimwa kwa baiti).
    ///
    /// km, ikiwa `self.size()` ni 9, basi `self.padding_needed_for(4)` inarudi 3, kwa sababu hiyo ndiyo idadi ndogo ya kaa za padding zinazohitajika kupata anwani iliyokaa 4 (kwa kudhani kuwa kizuizi cha kumbukumbu kinacholingana kinaanza kwa anwani iliyokaa-4).
    ///
    ///
    /// Thamani ya kurudi ya kazi hii haina maana ikiwa `align` sio nguvu-ya-mbili.
    ///
    /// Kumbuka kuwa matumizi ya dhamana iliyorudishwa inahitaji `align` kuwa chini au sawa na mpangilio wa anwani ya kuanzia kwa kizuizi cha kumbukumbu kilichotengwa.Njia moja ya kukidhi kikwazo hiki ni kuhakikisha `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Thamani iliyokamilishwa ni:
        //   len_rounded_up=(len + pangilia, 1)&! (pangilia, 1);
        // na kisha tunarudisha tofauti ya padding: `len_rounded_up - len`.
        //
        // Tunatumia hesabu za kawaida wakati wote:
        //
        // 1. align imehakikishiwa kuwa> 0, kwa hivyo pangilia, 1 ni halali kila wakati.
        //
        // 2.
        // `len + align - 1` inaweza kufurika kwa zaidi ya `align - 1`, kwa hivyo&-mask na `!(align - 1)` itahakikisha kuwa katika kesi ya kufurika, `len_rounded_up` yenyewe itakuwa 0.
        //
        //    Kwa hivyo utaftaji uliorejeshwa, ukiongezwa kwa `len`, hutoa 0, ambayo hutosheleza kidogo mpangilio wa `align`.
        //
        // (Kwa kweli, majaribio ya kutenga vizuizi vya kumbukumbu ambazo saizi na upandaji hufurika kwa njia ya hapo juu inapaswa kusababisha mgawaji kutoa kosa hata hivyo.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Huunda mpangilio kwa kuzungusha saizi ya mpangilio huu hadi mpangilio wa mpangilio mwingi.
    ///
    ///
    /// Hii ni sawa na kuongeza matokeo ya `padding_needed_for` kwa saizi ya mpangilio wa sasa.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Hii haiwezi kufurika.Kunukuu kutoka kwa ubadilishaji wa Mpangilio:
        // > `size`, ikikamilishwa kwa nambari ya karibu ya `align`,
        // > haipaswi kufurika (yaani, thamani iliyozungukwa lazima iwe chini ya
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Inaunda mpangilio unaoelezea rekodi ya matukio ya `n` ya `self`, na kiwango kinachofaa cha padding kati ya kila mmoja ili kuhakikisha kuwa kila tukio limepewa saizi na usawa ulioombwa.
    /// Kwa mafanikio, inarudi `(k, offs)` ambapo `k` ni mpangilio wa safu na `offs` ni umbali kati ya kuanza kwa kila kitu katika safu.
    ///
    /// Kwenye kufurika kwa hesabu, inarudi `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Hii haiwezi kufurika.Kunukuu kutoka kwa ubadilishaji wa Mpangilio:
        // > `size`, ikikamilishwa kwa nambari ya karibu ya `align`,
        // > haipaswi kufurika (yaani, thamani iliyozungukwa lazima iwe chini ya
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // USALAMA: self.align tayari inajulikana kuwa halali na alloc_size imekuwa
        // imefungwa tayari.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Inaunda mpangilio unaoelezea rekodi ya `self` ikifuatiwa na `next`, pamoja na utaftaji wowote muhimu ili kuhakikisha kuwa `next` itapangwa vizuri, lakini *hakuna pedi inayofuatia*.
    ///
    /// Ili kulinganisha mpangilio wa uwakilishi C `repr(C)`, unapaswa kupiga simu `pad_to_align` baada ya kupanua mpangilio na nyanja zote.
    /// (Hakuna njia ya kulinganisha mpangilio wa uwakilishi wa Rust chaguo-msingi `repr(Rust)`, as it is unspecified.)
    ///
    /// Kumbuka kuwa mpangilio wa mpangilio unaosababishwa utakuwa upeo wa zile za `self` na `next`, ili kuhakikisha usawa wa sehemu zote mbili.
    ///
    /// Hurejesha `Ok((k, offset))`, ambapo `k` ni mpangilio wa rekodi iliyofungwa na `offset` ni eneo la jamaa, kwa ka, za mwanzo wa `next` iliyoingia ndani ya rekodi iliyofungwa (kwa kudhani kuwa rekodi yenyewe huanza kwa kukabiliana na 0).
    ///
    ///
    /// Kwenye kufurika kwa hesabu, inarudi `LayoutError`.
    ///
    /// # Examples
    ///
    /// Kuhesabu mpangilio wa muundo wa `#[repr(C)]` na matokeo ya uwanja kutoka kwa mipangilio ya uwanja wake:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Kumbuka kumaliza na `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // jaribu kuwa inafanya kazi
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Inaunda mpangilio unaoelezea rekodi ya matukio ya `n` ya `self`, bila padding kati ya kila tukio.
    ///
    /// Kumbuka kuwa, tofauti na `repeat`, `repeat_packed` haihakikishi kuwa hali zinazorudiwa za `self` zitawekwa sawa, hata ikiwa mfano wa `self` umepangiliwa vizuri.
    /// Kwa maneno mengine, ikiwa mpangilio uliorudishwa na `repeat_packed` unatumiwa kutenga safu, haihakikishiwi kuwa vitu vyote katika safu hiyo vitawekwa sawa.
    ///
    /// Kwenye kufurika kwa hesabu, inarudi `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Inaunda mpangilio unaoelezea rekodi ya `self` ikifuatiwa na `next` bila pedi ya ziada kati ya hizo mbili.
    /// Kwa kuwa hakuna padding iliyoingizwa, mpangilio wa `next` hauna maana, na haujaingizwa *kabisa* katika mpangilio unaosababishwa.
    ///
    ///
    /// Kwenye kufurika kwa hesabu, inarudi `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Inaunda mpangilio unaoelezea rekodi ya `[T; n]`.
    ///
    /// Kwenye kufurika kwa hesabu, inarudi `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Vigezo vilivyopewa `Layout::from_size_align` au mjenzi mwingine wa `Layout` haviridhishi vizuizi vyake vilivyoandikwa.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (tunahitaji hii kwa kuingiza mkondo wa trait Kosa)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}