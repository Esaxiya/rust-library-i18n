use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Mgawanyiko wa kumbukumbu ambao unaweza kusajiliwa kama chaguo-msingi cha maktaba kupitia sifa ya `#[global_allocator]`.
///
/// Njia zingine zinahitaji kwamba kizuizi cha kumbukumbu kitatengwa * hivi sasa kupitia mtoaji.Hii inamaanisha kuwa:
///
/// * anwani ya kuanza kwa kizuizi hicho cha kumbukumbu hapo awali ilirudishwa na simu ya awali kwa njia ya ugawaji kama `alloc`, na
///
/// * kizuizi cha kumbukumbu hakijasambazwa baadaye, ambapo vizuizi vinasambazwa ama kwa kupitishwa kwa njia ya uhamishaji kama `dealloc` au kwa kupitishwa kwa njia ya ugawaji ambayo inarudi kiboreshaji kisicho cha null.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait ni `unsafe` trait kwa sababu kadhaa, na watekelezaji lazima wahakikishe wanazingatia mikataba hii:
///
/// * Ni tabia isiyoeleweka ikiwa wagawaji wa ulimwengu watafunguliwa.Kizuizi hiki kinaweza kuinuliwa katika future, lakini kwa sasa panic kutoka kwa moja ya kazi hizi zinaweza kusababisha kutokumbuka kwa kumbukumbu.
///
/// * `Layout` maswali na mahesabu kwa jumla lazima iwe sahihi.Wapiga simu wa trait hii wanaruhusiwa kutegemea mikataba iliyoainishwa kwa kila njia, na watekelezaji lazima wahakikishe mikataba kama hiyo inabaki kweli.
///
/// * Labda hautegemei mgao unaotokea, hata ikiwa kuna mgawanyo wa lundo wazi katika chanzo.
/// Kiboreshaji kinaweza kugundua mgao ambao haukutumiwa ambao unaweza kuondoa kabisa au kuhamia kwenye ghala na kwa hivyo hautaomba mtengaji kamwe.
/// Kiboreshaji kinaweza kudhani zaidi kuwa mgao hauwezi kukosea, kwa hivyo nambari iliyokuwa ikishindwa kwa sababu ya kutofaulu kwa mgawaji sasa inaweza kufanya kazi kwa ghafla kwa sababu optimizer ilifanya kazi karibu na hitaji la mgawanyo.
/// Kwa hakika zaidi, mfano wa nambari ifuatayo haueleweki, bila kujali kama mgawaji wako wa kawaida anaruhusu kuhesabu mgao wangapi umetokea.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Kumbuka kuwa uboreshaji uliotajwa hapo juu sio uboreshaji pekee ambao unaweza kutumika.Kwa ujumla hauwezi kutegemea mgao wa chungu unaotokea ikiwa unaweza kuondolewa bila kubadilisha tabia ya programu.
///   Ikiwa mgao unatokea au la sio sehemu ya tabia ya programu, hata ikiwa inaweza kugunduliwa kupitia mtengaji ambaye hufuatilia mgawanyo kwa kuchapisha au vinginevyo kuwa na athari mbaya.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Tenga kumbukumbu kama ilivyoelezewa na `layout` iliyotolewa.
    ///
    /// Hurejesha pointer kwenye kumbukumbu mpya iliyotengwa, au batili kuonyesha kutofaulu kwa mgawanyo.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama kwa sababu tabia isiyojulikana inaweza kusababisha ikiwa mpigaji hahakikishi kuwa `layout` ina saizi isiyo ya sifuri.
    ///
    /// (Vifungu vya ugani vinaweza kutoa mipaka maalum juu ya tabia, kwa mfano, kuhakikisha anwani ya sentinel au pointer tupu kujibu ombi la mgawanyo wa saizi.)
    ///
    /// Kizuizi cha kumbukumbu kilichotengwa kinaweza au hakiwezi kuanzishwa.
    ///
    /// # Errors
    ///
    /// Kurudisha pointer tupu kunaonyesha kuwa kumbukumbu yoyote imechoka au `layout` haikidhi ukubwa wa mgawaji au vikwazo vya mpangilio.
    ///
    /// Utekelezaji unahimizwa kurudi uchovu wa kumbukumbu badala ya kutoa mimba, lakini hii sio sharti kali.
    /// (Hasa: ni *halali* kutekeleza hii trait iliyo juu ya maktaba ya msingi ya ugawaji ambayo hutumia uchovu wa kumbukumbu.)
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya mgao wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kutumia moja kwa moja `panic!` au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Shirikisha kizuizi cha kumbukumbu kwenye kiashiria kilichopewa `ptr` na `layout` uliyopewa.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama kwa sababu tabia isiyojulikana inaweza kusababisha ikiwa mpigaji hahakikishi yote yafuatayo:
    ///
    ///
    /// * `ptr` lazima iashiria kizuizi cha kumbukumbu iliyotengwa sasa kupitia mtengaji huu,
    ///
    /// * `layout` lazima iwe mpangilio ule ule ambao ulitumika kutenga kizuizi hicho cha kumbukumbu.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Ina tabia kama `alloc`, lakini pia inahakikisha kuwa yaliyomo yamewekwa sifuri kabla ya kurudishwa.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama kwa sababu zile zile ambazo `alloc` ni.
    /// Walakini, kumbukumbu iliyotengwa imehakikishiwa kuanza.
    ///
    /// # Errors
    ///
    /// Kurudisha pointer tupu kunaonyesha kuwa kumbukumbu yoyote imechoka au `layout` haikidhi ukubwa wa mgawaji au vizuizi vya mpangilio, kama ilivyo kwa `alloc`.
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya mgao wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kutumia moja kwa moja `panic!` au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // USALAMA: mkataba wa usalama wa `alloc` lazima uzingatiwe na anayepiga simu.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // USALAMA: kama mgao ulifanikiwa, mkoa kutoka `ptr`
            // ya saizi `size` imehakikishiwa kuwa halali kwa maandishi.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Punguza au kukuza kizuizi cha kumbukumbu kwa `new_size` uliyopewa.
    /// Kizuizi kinaelezewa na pointer iliyotolewa ya `ptr` na `layout`.
    ///
    /// Ikiwa hii inarudi kiboreshaji kisichobatilisha, basi umiliki wa kizuizi cha kumbukumbu kinachotajwa na `ptr` kimehamishiwa kwa mtengaji huu.
    /// Kumbukumbu inaweza kuwa au haijawahi kusambazwa, na inapaswa kuzingatiwa kuwa haiwezi kutumika (isipokuwa kwa kweli ilihamishiwa kwa mpigaji tena kupitia dhamana ya kurudi kwa njia hii).
    /// Kizuizi kipya cha kumbukumbu kimetengwa na `layout`, lakini na `size` imesasishwa hadi `new_size`.
    /// Mpangilio huu mpya unapaswa kutumiwa wakati wa kuhamisha kizuizi kipya cha kumbukumbu na `dealloc`.
    /// Masafa `0..min(layout.size(), new_size) ya kizuizi kipya cha kumbukumbu imehakikishiwa kuwa na maadili sawa na kizuizi cha asili.
    ///
    /// Ikiwa njia hii inarudi tupu, basi umiliki wa kizuizi cha kumbukumbu haujahamishiwa kwa mtengaji huu, na yaliyomo kwenye kizuizi cha kumbukumbu hayajabadilishwa.
    ///
    /// # Safety
    ///
    /// Kazi hii sio salama kwa sababu tabia isiyojulikana inaweza kusababisha ikiwa mpigaji hahakikishi yote yafuatayo:
    ///
    /// * `ptr` lazima iwe imetengwa kwa sasa kupitia mtengaji huyu,
    ///
    /// * `layout` lazima iwe mpangilio ule ule ambao ulitumiwa kutenga kumbukumbu hiyo,
    ///
    /// * `new_size` lazima iwe kubwa kuliko sifuri.
    ///
    /// * `new_size`, ikikamilishwa kwa nambari ya karibu ya `layout.align()`, haipaswi kufurika (yaani, thamani iliyozungukwa lazima iwe chini ya `usize::MAX`).
    ///
    /// (Vifungu vya ugani vinaweza kutoa mipaka maalum juu ya tabia, kwa mfano, kuhakikisha anwani ya sentinel au pointer tupu kujibu ombi la mgawanyo wa saizi.)
    ///
    /// # Errors
    ///
    /// Hurejesha utupu ikiwa mpangilio mpya hautimizi ukubwa na vikwazo vya mpangilio wa mtengaji, au ikiwa ugawaji mwingine utashindwa.
    ///
    /// Utekelezaji unahimizwa kurudi uchovu wa kumbukumbu badala ya kuhofia au kutoa mimba, lakini hii sio sharti kali.
    /// (Hasa: ni *halali* kutekeleza hii trait iliyo juu ya maktaba ya msingi ya ugawaji ambayo hutumia uchovu wa kumbukumbu.)
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya uhamishaji wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kuomba `panic!` moja kwa moja au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // USALAMA: mpigaji lazima ahakikishe kwamba `new_size` haifuriki.
        // `layout.align()` hutoka kwa `Layout` na kwa hivyo imehakikishiwa kuwa halali.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // USALAMA: mpigaji lazima ahakikishe kuwa `new_layout` ni kubwa kuliko sifuri.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // USALAMA: kizuizi kilichotengwa hapo awali hakiwezi kuingiliana na kizuizi kipya kilichotengwa.
            // Mkataba wa usalama wa `dealloc` lazima uzingatiwe na mpiga simu.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}