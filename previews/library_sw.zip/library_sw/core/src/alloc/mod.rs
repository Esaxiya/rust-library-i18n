//! Ugawaji wa kumbukumbu APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Kosa la `AllocError` linaonyesha kutofaulu kwa ugawaji ambayo inaweza kuwa ni kwa sababu ya uchovu wa rasilimali au kwa kitu kibaya wakati unachanganya hoja za pembejeo na mtengaji huyu.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (tunahitaji hii kwa kuingiza mkondo wa trait Kosa)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Utekelezaji wa `Allocator` unaweza kutenga, kukua, kupungua, na kusambaza vizuizi vya data vilivyoelezewa kupitia [`Layout`][].
///
/// `Allocator` imeundwa kutekelezwa kwenye ZSTs, marejeleo, au viashiria vya busara kwa sababu kuwa na mgawaji kama `MyAlloc([u8; N])` haiwezi kuhamishwa, bila kusasisha viashiria kwenye kumbukumbu iliyotengwa.
///
/// Tofauti na [`GlobalAlloc`][], mgao wa saizi huruhusiwa katika `Allocator`.
/// Ikiwa mtengaji wa msingi haungi mkono hii (kama jemalloc) au arudishe kiboreshaji batili (kama vile `libc::malloc`), hii lazima ichukuliwe na utekelezaji.
///
/// ### Kumbukumbu iliyotengwa sasa
///
/// Njia zingine zinahitaji kwamba kizuizi cha kumbukumbu kitatengwa * hivi sasa kupitia mtoaji.Hii inamaanisha kuwa:
///
/// * anwani ya kuanza kwa kizuizi hicho cha kumbukumbu ilirudishwa hapo awali na [`allocate`], [`grow`], au [`shrink`], na
///
/// * kizuizi cha kumbukumbu hakijasambazwa baadaye, ambapo vizuizi vinasambazwa moja kwa moja kwa kupitishwa kwa [`deallocate`] au zilibadilishwa kwa kupitishwa kwa [`grow`] au [`shrink`] ambayo inarudi `Ok`.
///
/// Ikiwa `grow` au `shrink` wamerudisha `Err`, pointer iliyopitishwa inabaki halali.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Kumbukumbu kufaa
///
/// Baadhi ya njia zinahitaji kwamba mpangilio *utoshee* kizuizi cha kumbukumbu.
/// Inamaanisha nini kwa mpangilio wa "fit" njia ya kumbukumbu inamaanisha (au vivyo hivyo, kwa kizuizi cha kumbukumbu hadi mpangilio wa "fit") ni kwamba hali zifuatazo lazima zishike:
///
/// * Kizuizi lazima kitengwe na usawa sawa na [`layout.align()`], na
///
/// * [`layout.size()`] iliyotolewa lazima iangalie katika anuwai ya `min ..= max`, ambapo:
///   - `min` saizi ya mpangilio uliotumika hivi karibuni kutenga block, na
///   - `max` saizi halisi ya hivi karibuni imerudishwa kutoka [`allocate`], [`grow`], au [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Vitalu vya kumbukumbu vilivyorejeshwa kutoka kwa mgawaji lazima vionyeshe kumbukumbu halali na kuhifadhi uhalali wao mpaka mfano na vielelezo vyake vyote vimeachwa,
///
/// * Kuunganisha au kuhamisha mtengaji lazima isiharibu vizuizi vya kumbukumbu vilivyorudishwa kutoka kwa mtengaji huu.Mtengaji aliyepangwa lazima aishi kama mtengaji huyo huyo, na
///
/// * pointer yoyote kwa block block ambayo ni [*currently allocated*] inaweza kupitishwa kwa njia nyingine yoyote ya mtengaji.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Jaribio la kutenga kumbukumbu ya kumbukumbu.
    ///
    /// Kwa mafanikio, inarudisha mkutano wa [`NonNull<[u8]>`][NonNull] ukubwa na dhamana ya mpangilio wa `layout`.
    ///
    /// Kizuizi kilichorudishwa kinaweza kuwa na saizi kubwa kuliko ilivyoainishwa na `layout.size()`, na inaweza kuwa na yaliyomo au yasipate kuanza.
    ///
    /// # Errors
    ///
    /// Kurudisha `Err` kunaonyesha kuwa kumbukumbu yoyote imechoka au `layout` haikidhi ukubwa wa mgawaji au vikwazo vya mpangilio.
    ///
    /// Utekelezaji unahimizwa kurudi `Err` kwenye uchovu wa kumbukumbu badala ya kuhofia au kutoa mimba, lakini hii sio sharti kali.
    /// (Hasa: ni *halali* kutekeleza hii trait iliyo juu ya maktaba ya msingi ya ugawaji ambayo hutumia uchovu wa kumbukumbu.)
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya mgao wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kutumia moja kwa moja `panic!` au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Ina tabia kama `allocate`, lakini pia inahakikisha kwamba kumbukumbu iliyorudishwa imeanzishwa sifuri.
    ///
    /// # Errors
    ///
    /// Kurudisha `Err` kunaonyesha kuwa kumbukumbu yoyote imechoka au `layout` haikidhi ukubwa wa mgawaji au vikwazo vya mpangilio.
    ///
    /// Utekelezaji unahimizwa kurudi `Err` kwenye uchovu wa kumbukumbu badala ya kuhofia au kutoa mimba, lakini hii sio sharti kali.
    /// (Hasa: ni *halali* kutekeleza hii trait iliyo juu ya maktaba ya msingi ya ugawaji ambayo hutumia uchovu wa kumbukumbu.)
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya mgao wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kutumia moja kwa moja `panic!` au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // USALAMA: `alloc` inarudi kizuizi cha kumbukumbu halali
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Hutenga kumbukumbu iliyotajwa na `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` lazima iashiria kizuizi cha kumbukumbu [*currently allocated*] kupitia kigawi hiki, na
    /// * `layout` lazima [*fit*] hiyo block ya kumbukumbu.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Jaribio la kupanua kizuizi cha kumbukumbu.
    ///
    /// Hurejesha [`NonNull<[u8]>`][NonNull] mpya iliyo na kiboreshaji na saizi halisi ya kumbukumbu iliyotengwa.Kielekezi kinafaa kwa kushikilia data iliyoelezewa na `new_layout`.
    /// Ili kufanikisha hili, mtengaji anaweza kupanua mgawo uliorejelewa na `ptr` ili kutoshea mpangilio mpya.
    ///
    /// Ikiwa hii itarudisha `Ok`, basi umiliki wa kizuizi cha kumbukumbu kinachotajwa na `ptr` kimehamishiwa kwa mtengaji huu.
    /// Kumbukumbu inaweza kuwa au haijawahi kutolewa, na inapaswa kuzingatiwa kuwa haiwezi kutumiwa isipokuwa ikihamishiwa kwa mpigaji tena kupitia dhamana ya kurudi kwa njia hii.
    ///
    /// Ikiwa njia hii inarudi `Err`, basi umiliki wa kizuizi cha kumbukumbu haujahamishiwa kwa mtengaji huu, na yaliyomo kwenye block block hayajabadilishwa.
    ///
    /// # Safety
    ///
    /// * `ptr` lazima iashiria kizuizi cha kumbukumbu [*currently allocated*] kupitia kitenga hiki.
    /// * `old_layout` lazima [*fit*] hiyo block ya kumbukumbu (Hoja ya `new_layout` haifai kuitosha.).
    /// * `new_layout.size()` lazima iwe kubwa kuliko au sawa na `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Hurejesha `Err` ikiwa mpangilio mpya hautoshelezi ukubwa wa mtengaji na vizuizi vya mpangilio wa mtengaji, au ikiwa kukua vinginevyo hakufaulu.
    ///
    /// Utekelezaji unahimizwa kurudi `Err` kwenye uchovu wa kumbukumbu badala ya kuhofia au kutoa mimba, lakini hii sio sharti kali.
    /// (Hasa: ni *halali* kutekeleza hii trait iliyo juu ya maktaba ya msingi ya ugawaji ambayo hutumia uchovu wa kumbukumbu.)
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya mgao wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kutumia moja kwa moja `panic!` au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // USALAMA: kwa sababu `new_layout.size()` lazima iwe kubwa kuliko au sawa na
        // `old_layout.size()`, mgao wa kumbukumbu ya zamani na mpya ni halali kwa kusoma na huandika kwa baiti za `old_layout.size()`.
        // Pia, kwa sababu mgao wa zamani ulikuwa haujashughulikiwa, hauwezi kuingiliana na `new_ptr`.
        // Kwa hivyo, simu kwa `copy_nonoverlapping` ni salama.
        // Mkataba wa usalama wa `dealloc` lazima uzingatiwe na mpiga simu.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ina tabia kama `grow`, lakini pia inahakikisha kuwa yaliyomo mapya yamewekwa sifuri kabla ya kurudishwa.
    ///
    /// Kizuizi cha kumbukumbu kitakuwa na yaliyomo baada ya simu iliyofanikiwa kwenda
    /// `grow_zeroed`:
    ///   * Byte `0..old_layout.size()` zimehifadhiwa kutoka kwa mgao wa asili.
    ///   * Baiti `old_layout.size()..old_size` zinaweza kuhifadhiwa au kutengwa, kulingana na utekelezaji wa mtengaji.
    ///   `old_size` inahusu saizi ya kizuizi cha kumbukumbu kabla ya simu ya `grow_zeroed`, ambayo inaweza kuwa kubwa kuliko saizi ambayo iliombwa mwanzoni wakati ilitengwa.
    ///   * Baiti `old_size..new_size` zimepigwa zero.`new_size` inahusu saizi ya kizuizi cha kumbukumbu kilichorudishwa na simu ya `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` lazima iashiria kizuizi cha kumbukumbu [*currently allocated*] kupitia kitenga hiki.
    /// * `old_layout` lazima [*fit*] hiyo block ya kumbukumbu (Hoja ya `new_layout` haifai kuitosha.).
    /// * `new_layout.size()` lazima iwe kubwa kuliko au sawa na `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Hurejesha `Err` ikiwa mpangilio mpya hautoshelezi ukubwa wa mtengaji na vizuizi vya mpangilio wa mtengaji, au ikiwa kukua vinginevyo hakufaulu.
    ///
    /// Utekelezaji unahimizwa kurudi `Err` kwenye uchovu wa kumbukumbu badala ya kuhofia au kutoa mimba, lakini hii sio sharti kali.
    /// (Hasa: ni *halali* kutekeleza hii trait iliyo juu ya maktaba ya msingi ya ugawaji ambayo hutumia uchovu wa kumbukumbu.)
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya mgao wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kutumia moja kwa moja `panic!` au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // USALAMA: kwa sababu `new_layout.size()` lazima iwe kubwa kuliko au sawa na
        // `old_layout.size()`, mgao wa kumbukumbu ya zamani na mpya ni halali kwa kusoma na huandika kwa baiti za `old_layout.size()`.
        // Pia, kwa sababu mgao wa zamani ulikuwa haujashughulikiwa, hauwezi kuingiliana na `new_ptr`.
        // Kwa hivyo, simu kwa `copy_nonoverlapping` ni salama.
        // Mkataba wa usalama wa `dealloc` lazima uzingatiwe na mpiga simu.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Jaribio la kupunguza kizuizi cha kumbukumbu.
    ///
    /// Hurejesha [`NonNull<[u8]>`][NonNull] mpya iliyo na kiboreshaji na saizi halisi ya kumbukumbu iliyotengwa.Kielekezi kinafaa kwa kushikilia data iliyoelezewa na `new_layout`.
    /// Ili kufanikisha hili, mtengaji anaweza kupunguza mgawo uliorejelewa na `ptr` ili kutoshea mpangilio mpya.
    ///
    /// Ikiwa hii itarudisha `Ok`, basi umiliki wa kizuizi cha kumbukumbu kinachotajwa na `ptr` kimehamishiwa kwa mtengaji huu.
    /// Kumbukumbu inaweza kuwa au haijawahi kutolewa, na inapaswa kuzingatiwa kuwa haiwezi kutumiwa isipokuwa ikihamishiwa kwa mpigaji tena kupitia dhamana ya kurudi kwa njia hii.
    ///
    /// Ikiwa njia hii inarudi `Err`, basi umiliki wa kizuizi cha kumbukumbu haujahamishiwa kwa mtengaji huu, na yaliyomo kwenye block block hayajabadilishwa.
    ///
    /// # Safety
    ///
    /// * `ptr` lazima iashiria kizuizi cha kumbukumbu [*currently allocated*] kupitia kitenga hiki.
    /// * `old_layout` lazima [*fit*] hiyo block ya kumbukumbu (Hoja ya `new_layout` haifai kuitosha.).
    /// * `new_layout.size()` lazima iwe ndogo kuliko au sawa na `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Hurejesha `Err` ikiwa mpangilio mpya hautimizi ukubwa wa mgawaji na vizuizi vya mpangilio wa mtengaji, au ikiwa kupungua kwa njia nyingine hakufaulu.
    ///
    /// Utekelezaji unahimizwa kurudi `Err` kwenye uchovu wa kumbukumbu badala ya kuhofia au kutoa mimba, lakini hii sio sharti kali.
    /// (Hasa: ni *halali* kutekeleza hii trait iliyo juu ya maktaba ya msingi ya ugawaji ambayo hutumia uchovu wa kumbukumbu.)
    ///
    /// Wateja wanaotaka kutoa hesabu kwa kujibu hitilafu ya mgao wanahimizwa kupiga kazi ya [`handle_alloc_error`], badala ya kutumia moja kwa moja `panic!` au sawa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // USALAMA: kwa sababu `new_layout.size()` lazima iwe chini kuliko au sawa na
        // `old_layout.size()`, mgao wa kumbukumbu ya zamani na mpya ni halali kwa kusoma na huandika kwa baiti za `new_layout.size()`.
        // Pia, kwa sababu mgao wa zamani ulikuwa haujashughulikiwa, hauwezi kuingiliana na `new_ptr`.
        // Kwa hivyo, simu kwa `copy_nonoverlapping` ni salama.
        // Mkataba wa usalama wa `dealloc` lazima uzingatiwe na mpiga simu.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Inaunda adapta ya "by reference" kwa mfano huu wa `Allocator`.
    ///
    /// Adapta iliyorejeshwa pia hutumia `Allocator` na itakopa hii tu.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // USALAMA: mkataba wa usalama lazima uzingatiwe na anayepiga simu
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // USALAMA: mkataba wa usalama lazima uzingatiwe na anayepiga simu
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // USALAMA: mkataba wa usalama lazima uzingatiwe na anayepiga simu
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // USALAMA: mkataba wa usalama lazima uzingatiwe na anayepiga simu
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}