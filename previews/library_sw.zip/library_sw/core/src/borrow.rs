//! Moduli ya kufanya kazi na data iliyokopwa.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait ya data ya kukopa.
///
/// Katika Rust, ni kawaida kutoa viwakilishi tofauti vya aina kwa visa tofauti vya utumiaji.
/// Kwa mfano, eneo la uhifadhi na usimamizi wa thamani inaweza kuchaguliwa haswa kama inafaa kwa matumizi fulani kupitia aina za pointer kama [`Box<T>`] au [`Rc<T>`].
/// Zaidi ya vifuniko vya generic ambavyo vinaweza kutumiwa na aina yoyote, aina zingine hutoa sehemu za hiari zinazotoa utendaji wenye gharama kubwa.
/// Mfano wa aina kama hiyo ni [`String`] ambayo inaongeza uwezo wa kupanua kamba kwa [`str`] ya msingi.
/// Hii inahitaji kuweka habari ya ziada isiyo ya lazima kwa kamba rahisi, isiyoweza kubadilika.
///
/// Aina hizi hutoa ufikiaji wa data ya msingi kupitia marejeleo ya aina ya data hiyo.Wanasemekana 'kukopwa kama' aina hiyo.
/// Kwa mfano, [`Box<T>`] inaweza kukopwa kama `T` wakati [`String`] inaweza kukopwa kama `str`.
///
/// Aina zinaonyesha kuwa zinaweza kukopwa kama aina fulani ya `T` kwa kutekeleza `Borrow<T>`, ikitoa rejeleo la `T` katika njia ya trait ya [`borrow`].Aina ni bure kukopa kama aina kadhaa tofauti.
/// Ikiwa inataka kukopa kwa usawa kama aina-ikiruhusu data ya msingi ibadilishwe, inaweza pia kutekeleza [`BorrowMut<T>`].
///
/// Kwa kuongezea, wakati wa kutoa utekelezaji wa traits ya ziada, inahitaji kuzingatiwa ikiwa wanapaswa kuishi sawa na wale wa aina ya msingi kama matokeo ya kufanya kama uwakilishi wa aina hiyo ya msingi.
/// Nambari ya kawaida hutumia `Borrow<T>` wakati inategemea tabia inayofanana ya utekelezaji huu wa ziada wa trait.
/// traits hizi zinaweza kuonekana kama trait bound za ziada.
///
/// Hasa `Eq`, `Ord` na `Hash` lazima zilingane na maadili yaliyokopwa na yanayomilikiwa: `x.borrow() == y.borrow()` inapaswa kutoa matokeo sawa na `x == y`.
///
/// Ikiwa nambari ya generic inahitaji tu kufanya kazi kwa aina zote ambazo zinaweza kutoa rejeleo kwa aina inayohusiana ya `T`, mara nyingi ni bora kutumia [`AsRef<T>`] kwani aina zaidi zinaweza kuitumia salama.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Kama mkusanyiko wa data, [`HashMap<K, V>`] inamiliki funguo na maadili.Ikiwa data halisi ya ufunguo imefungwa katika aina ya usimamizi wa aina fulani, inapaswa, hata hivyo, bado inawezekana kutafuta thamani kwa kutumia rejeleo la data ya ufunguo.
/// Kwa mfano, ikiwa ufunguo ni kamba, basi inawezekana imehifadhiwa na ramani ya hashi kama [`String`], wakati inapaswa kutafuta kwa kutumia [`&str`][`str`].
/// Kwa hivyo, `insert` inahitaji kufanya kazi kwa `String` wakati `get` inahitaji kuweza kutumia `&str`.
///
/// Kilichorahisishwa kidogo, sehemu husika za `HashMap<K, V>` zinaonekana kama hii:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // Mashamba yameachwa
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Ramani nzima ya hashi ni generic juu ya aina muhimu `K`.Kwa sababu funguo hizi zinahifadhiwa na ramani ya hashi, aina hii inapaswa kumiliki data ya ufunguo.
/// Wakati wa kuingiza jozi ya thamani muhimu, ramani inapewa `K` kama hiyo na inahitaji kupata ndoo sahihi ya hashi na uangalie ikiwa ufunguo tayari upo kulingana na `K` hiyo.Kwa hivyo inahitaji `K: Hash + Eq`.
///
/// Unapotafuta thamani kwenye ramani, hata hivyo, kulazimika kutoa rejeleo la `K` kama ufunguo wa kutafuta itahitaji kuunda kila wakati thamani inayomilikiwa.
/// Kwa funguo za kamba, hii itamaanisha thamani ya `String` inahitaji kuundwa tu kwa utaftaji wa kesi ambapo `str` tu inapatikana.
///
/// Badala yake, njia ya `get` ni generic juu ya aina ya data muhimu, inayoitwa `Q` katika saini ya njia hapo juu.Inasema kuwa `K` inakopa kama `Q` kwa kuhitaji hiyo `K: Borrow<Q>`.
/// Kwa kuongeza kuhitaji `Q: Hash + Eq`, inaashiria mahitaji kwamba `K` na `Q` ziwe na utekelezaji wa `Hash` na `Eq` traits ambazo hutoa matokeo yanayofanana.
///
/// Utekelezaji wa `get` hutegemea haswa utekelezaji sawa wa `Hash` kwa kuamua ndoo ya hashi ya ufunguo kwa kupiga `Hash::hash` kwa thamani ya `Q` ingawa imeingiza ufunguo kulingana na thamani ya hash iliyohesabiwa kutoka kwa thamani ya `K`.
///
///
/// Kama matokeo, ramani ya hashi huvunjika ikiwa `K` inayofunga thamani ya `Q` hutoa hash tofauti na `Q`.Kwa mfano, fikiria una aina inayofunga kamba lakini inalinganisha herufi ASCII kupuuza kesi zao:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Kwa sababu maadili mawili sawa yanahitaji kutoa thamani sawa ya hash, utekelezaji wa `Hash` unahitaji kupuuza kesi ya ASCII, pia:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Je, `CaseInsensitiveString` inaweza kutekeleza `Borrow<str>`?Kwa kweli inaweza kutoa rejeleo kwa kipande cha kamba kupitia kamba yake inayomilikiwa.
/// Lakini kwa sababu utekelezaji wake wa `Hash` unatofautiana, ina tabia tofauti na `str` na kwa hivyo haipaswi, kwa kweli, kutekeleza `Borrow<str>`.
/// Ikiwa inataka kuruhusu wengine kufikia `str` ya msingi, inaweza kufanya hivyo kupitia `AsRef<str>` ambayo haina mahitaji yoyote ya ziada.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Kwa kweli hukopa kutoka kwa thamani inayomilikiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait ya data ya kukopa kwa kubadilika.
///
/// Kama rafiki wa [`Borrow<T>`] hii trait inaruhusu aina kukopa kama aina ya msingi kwa kutoa rejeleo inayoweza kubadilika.
/// Tazama [`Borrow<T>`] kwa habari zaidi juu ya kukopa kama aina nyingine.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Kwa jumla hukopa kutoka kwa thamani inayomilikiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}