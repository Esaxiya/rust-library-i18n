// Utekelezaji wa asili uliochukuliwa kutoka kwa rust-memchr.
// Hakimiliki 2015 Andrew Gallant, bluss na Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Tumia ukataji.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Hurejesha `true` ikiwa `x` ina baiti yoyote ya sifuri.
///
/// Kutoka kwa "Mambo ya Usomaji", J. Arndt:
///
/// "Wazo ni kuondoa moja kutoka kwa kila ka na kisha utafute ka ambapo kukopa kulienea hadi muhimu zaidi.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Hurejesha faharisi ya kwanza inayolingana na baiti `x` katika `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Njia ya haraka ya vipande vidogo
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Changanua thamani moja ya ka kwa kusoma maneno mawili ya `usize` kwa wakati mmoja.
    //
    // Gawanya `text` katika sehemu tatu
    // - sehemu isiyo ya kawaida iliyowekwa sawa, kabla ya anwani ya neno la kwanza iliyokaa kwa maandishi
    // - mwili, changanua kwa maneno 2 kwa wakati mmoja
    // - sehemu ya mwisho iliyobaki, <2 saizi ya neno

    // tafuta hadi mpaka uliopangwa
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // tafuta mwili wa maandishi
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // USALAMA: mtabiri wa wakati huhakikishia umbali wa angalau 2 * usize_bytes
        // kati ya kukabiliana na mwisho wa kipande.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // kuvunja ikiwa kuna baiti inayofanana
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Pata baiti baada ya kumalizika kwa kitanzi cha mwili.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Hurejesha faharisi ya mwisho inayolingana na baiti `x` katika `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Changanua thamani moja ya ka kwa kusoma maneno mawili ya `usize` kwa wakati mmoja.
    //
    // Gawanya `text` katika sehemu tatu:
    // - mkia usiofungamana, baada ya anwani ya neno la mwisho iliyokaa sawa katika maandishi,
    // - mwili, iliyoangaliwa na maneno 2 kwa wakati,
    // - ka iliyobaki ya kwanza, <saizi ya neno 2.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Tunaita hii tu kupata urefu wa kiambishi awali na kiambishi.
        // Katikati sisi hutengeneza vipande viwili mara moja.
        // USALAMA: kusambaza `[u8]` hadi `[usize]` ni salama isipokuwa tofauti za saizi ambazo zinashughulikiwa na `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Tafuta mwili wa maandishi, hakikisha hativuki min_aligned_offset.
    // kukabiliana daima ni iliyokaa, kwa hivyo kujaribu `>` ni ya kutosha na inepuka uwezekano wa kufurika.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // USALAMA: kukabiliana huanza kwa len, suffix.len(), maadamu ni kubwa kuliko
        // min_aligned_offset (prefix.len()) umbali uliobaki ni angalau 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Kuvunja ikiwa kuna baiti inayofanana.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Pata baiti kabla ya hatua kitanzi cha mwili kimesimama.
    text[..offset].iter().rposition(|elt| *elt == x)
}