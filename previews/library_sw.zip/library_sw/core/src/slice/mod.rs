// ignore-tidy-filelength

//! Usimamizi wa kipande na ghiliba.
//!
//! Kwa maelezo zaidi angalia [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Utekelezaji safi wa kumbukumbu ya rust, iliyochukuliwa kutoka kwa rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Kazi hii ni ya umma tu kwa sababu hakuna njia nyingine ya heapsort ya jaribio la kitengo.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Hurejesha idadi ya vipengee kwenye kipande.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // USALAMA: sauti ya const kwa sababu tunasambaza uwanja wa urefu kama usize (ambayo lazima iwe)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // USALAMA: hii ni salama kwa sababu `&[T]` na `FatPtr<T>` zina mpangilio sawa.
            // Ni `std` tu inayoweza kutoa dhamana hii.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Badilisha na `crate::ptr::metadata(self)` wakati hiyo ni thabiti.
            // Kuanzia wakati wa kuandika hii inasababisha kosa la "Const-stable functions can only call other const-stable functions".
            //

            // USALAMA: Kupata thamani kutoka kwa umoja wa `PtrRepr` ni salama kwani * const T
            // na PtrComponents<T>kuwa na mipangilio sawa ya kumbukumbu.
            // std tu ndio inaweza kufanya dhamana hii.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Hurejesha `true` ikiwa kipande kina urefu wa 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hurejesha kipengee cha kwanza cha kipande, au `None` ikiwa haina kitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Hurejesha kiboreshaji kinachoweza kubadilika kwa kipengee cha kwanza cha kipande, au `None` ikiwa haina kitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Hurejesha kwanza na vitu vingine vyote vya kipande, au `None` ikiwa haina kitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Hurejesha kwanza na vitu vingine vyote vya kipande, au `None` ikiwa haina kitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Hurejesha mwisho na vitu vingine vyote vya kipande, au `None` ikiwa haina kitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Hurejesha mwisho na vitu vingine vyote vya kipande, au `None` ikiwa haina kitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Hurejesha kipengee cha mwisho cha kipande, au `None` ikiwa haina kitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Hurejesha kielekezi kinachoweza kubadilika kwa kipengee cha mwisho kwenye kipande.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Hurejesha rejeleo kwa kipengee au sehemu ndogo kulingana na aina ya faharisi.
    ///
    /// - Ikiwa imepewa nafasi, inarudisha kumbukumbu ya kipengee kwenye nafasi hiyo au `None` ikiwa nje ya mipaka.
    ///
    /// - Ikiwa imepewa masafa, inarudisha sehemu ndogo inayolingana na masafa hayo, au `None` ikiwa nje ya mipaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Hurejesha rejeleo linaloweza kubadilika kwa kipengee au sehemu ndogo kulingana na aina ya faharisi (tazama [`get`]) au `None` ikiwa faharisi haiko na mipaka.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Hurejesha rejeleo kwa kipengee au sehemu ndogo, bila kuangalia mipaka.
    ///
    /// Kwa mbadala salama angalia [`get`].
    ///
    /// # Safety
    ///
    /// Kuita njia hii na faharisi isiyo nje ya mipaka ni *[tabia isiyojulikana]* hata kama rejeleo linalosababishwa halitumiki.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // USALAMA: mpigaji lazima azingatie mahitaji mengi ya usalama kwa `get_unchecked`;
        // kipande hakiwezi kutolewa kwa sababu `self` ni kumbukumbu salama.
        // Kiashiria kilichorejeshwa ni salama kwa sababu impls za `SliceIndex` zinapaswa kuhakikisha kuwa ni.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Hurejesha rejeleo linaloweza kubadilika kwa kipengee au sehemu ndogo, bila kuangalia mipaka.
    ///
    /// Kwa mbadala salama angalia [`get_mut`].
    ///
    /// # Safety
    ///
    /// Kuita njia hii na faharisi isiyo nje ya mipaka ni *[tabia isiyojulikana]* hata kama rejeleo linalosababishwa halitumiki.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // USALAMA: mpigaji lazima azingatie mahitaji ya usalama kwa `get_unchecked_mut`;
        // kipande hakiwezi kutolewa kwa sababu `self` ni kumbukumbu salama.
        // Kiashiria kilichorejeshwa ni salama kwa sababu impls za `SliceIndex` zinapaswa kuhakikisha kuwa ni.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Hurejesha kielekezi kibichi kwenye bafa ya kipande.
    ///
    /// Mpigaji lazima ahakikishe kwamba kipande kinapita muda wa kiboreshaji kazi hii inarudi, la sivyo itaishia kuelekeza kwenye takataka.
    ///
    /// Anayepiga simu lazima pia ahakikishe kumbukumbu ya pointer (non-transitively) inayoelekezwa haiandikiwi kamwe (isipokuwa ndani ya `UnsafeCell`) kwa kutumia kichocheo hiki au kitambulisho chochote kinachotokana nayo.
    /// Ikiwa unahitaji kubadilisha yaliyomo kwenye kipande, tumia [`as_mut_ptr`].
    ///
    /// Kubadilisha kontena lililorejelewa na kipande hiki kunaweza kusababisha bafa yake kugawanywa tena, ambayo pia itafanya viashiria vyovyote kuwa batili.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Hurejesha kielekezi kisicho salama kinachoweza kubadilika kwa bafa ya kipande.
    ///
    /// Mpigaji lazima ahakikishe kwamba kipande kinapita muda wa kiboreshaji kazi hii inarudi, la sivyo itaishia kuelekeza kwenye takataka.
    ///
    /// Kubadilisha kontena lililorejelewa na kipande hiki kunaweza kusababisha bafa yake kugawanywa tena, ambayo pia itafanya viashiria vyovyote kuwa batili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Hurejesha kuyatumia mabichi mabichi yaliyotanda kipande.
    ///
    /// Masafa yaliyorejeshwa yamefunguliwa nusu, ambayo inamaanisha kuwa pointer ya mwisho inaelekeza *moja nyuma* kipengee cha mwisho cha kipande.
    /// Kwa njia hii, kipande tupu kinawakilishwa na viashiria viwili sawa, na tofauti kati ya viashiria hivyo inawakilisha saizi ya kipande.
    ///
    /// Tazama [`as_ptr`] kwa maonyo juu ya kutumia viashiria hivi.Kiashiria cha mwisho kinahitaji tahadhari zaidi, kwani haionyeshi kipengee halali kwenye kipande.
    ///
    /// Kazi hii ni muhimu kwa kuingiliana na maingiliano ya kigeni ambayo hutumia viashiria viwili kurejelea anuwai ya vitu kwenye kumbukumbu, kama kawaida katika C++ .
    ///
    ///
    /// Inaweza pia kuwa muhimu kuangalia ikiwa kiashiria kwa kitu kinamaanisha kipengee cha kipande hiki:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // USALAMA: `add` hapa ni salama, kwa sababu:
        //
        //   - Vidokezo vyote viwili ni sehemu ya kitu kimoja, kwani kuashiria moja kwa moja kupita kitu pia ni muhimu.
        //
        //   - Ukubwa wa kipande hicho kamwe sio kubwa kuliko baiti za isize::MAX, kama ilivyoonyeshwa hapa:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Hakuna kuzungushia inayohusika, kwani vipande havizidi mwisho wa nafasi ya anwani.
        //
        // Tazama nyaraka za pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Hurejesha viashiria viwili visivyo salama vinavyoweza kubadilika kwa kutumia kipande.
    ///
    /// Masafa yaliyorejeshwa yamefunguliwa nusu, ambayo inamaanisha kuwa pointer ya mwisho inaelekeza *moja nyuma* kipengee cha mwisho cha kipande.
    /// Kwa njia hii, kipande tupu kinawakilishwa na viashiria viwili sawa, na tofauti kati ya viashiria hivyo inawakilisha saizi ya kipande.
    ///
    /// Tazama [`as_mut_ptr`] kwa maonyo juu ya kutumia viashiria hivi.
    /// Kiashiria cha mwisho kinahitaji tahadhari zaidi, kwani haionyeshi kipengee halali kwenye kipande.
    ///
    /// Kazi hii ni muhimu kwa kuingiliana na maingiliano ya kigeni ambayo hutumia viashiria viwili kurejelea anuwai ya vitu kwenye kumbukumbu, kama kawaida katika C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // USALAMA: Tazama as_ptr_range() hapo juu kwa nini `add` hapa ni salama.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Inabadilisha vitu viwili kwenye kipande.
    ///
    /// # Arguments
    ///
    /// * a, Faharisi ya kipengee cha kwanza
    /// * b, Faharisi ya kipengee cha pili
    ///
    /// # Panics
    ///
    /// Panics ikiwa `a` au `b` hazipo kwenye mipaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Haiwezi kuchukua mikopo miwili inayoweza kubadilika kutoka kwa vector moja, kwa hivyo badala yake tumia viashiria mbichi.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // USALAMA: `pa` na `pb` vimeundwa kutoka kwa marejeo salama yanayoweza kubadilika na rejelea
        // kwa vipengee kwenye kipande na kwa hivyo imehakikishiwa kuwa halali na iliyokaa.
        // Kumbuka kuwa kufikia vitu nyuma ya `a` na `b` kunakaguliwa na panic itatoka nje ya mipaka.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Inabadilisha mpangilio wa vitu kwenye kipande, mahali.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Kwa aina ndogo sana, kila mtu anayesoma katika njia ya kawaida hufanya vibaya.
        // Tunaweza kufanya vizuri zaidi, tukipewa load/store isiyo na usawa, kwa kupakia chunk kubwa na kugeuza rejista.
        //

        // Kwa kweli LLVM ingetufanyia hivi, kwani inajua vizuri kuliko sisi ikiwa usomaji uliosainiwa ni mzuri (kwani mabadiliko hayo kati ya matoleo tofauti ya ARM, kwa mfano) na saizi bora ya chunk itakuwa nini.
        // Kwa bahati mbaya, kama ya LLVM 4.0 (2017-05) inafungua tu kitanzi, kwa hivyo tunahitaji kufanya hivyo sisi wenyewe.
        // (Hypothesis: reverse ni shida kwa sababu pande zinaweza kusawazishwa tofauti-zitakuwa, wakati urefu ni wa kawaida-kwa hivyo hakuna njia ya kutoa pre-na postludes kutumia SIMD iliyokaa kikamilifu katikati.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Tumia asili ya llvm.bswap kubadilisha u8 katika usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // USALAMA: Kuna mambo kadhaa ya kuangalia hapa:
                //
                // - Kumbuka kuwa `chunk` ni 4 au 8 kwa sababu ya hundi ya cfg hapo juu.Kwa hivyo `chunk - 1` ni chanya.
                // - Kuorodhesha na index `i` ni sawa kwani hundi ya kitanzi inahakikishia
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Kuorodhesha na index `ln - i - chunk = ln - (i + chunk)` ni sawa:
                //   - `i + chunk > 0` ni kweli kidogo.
                //   - Uhakiki wa kitanzi unahakikishia:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, kwa hivyo kutoa hakufurika.
                // - Simu za `read_unaligned` na `write_unaligned` ni sawa:
                //   - `pa` inaelekeza kwa faharisi `i` ambapo `i < ln / 2 - (chunk - 1)` (tazama hapo juu) na `pb` inaashiria index `ln - i - chunk`, kwa hivyo zote mbili ni angalau `chunk` ka nyingi mbali na mwisho wa `self`.
                //
                //   - Kumbukumbu yoyote iliyoanzishwa ni `usize` halali.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Tumia mzunguko-na-16 kugeuza u16 katika u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // USALAMA: u32 ambayo haijasanifiwa inaweza kusomwa kutoka `i` ikiwa `i + 1 < ln`
                // (na ni wazi `i < ln`), kwa sababu kila kitu ni ka 2 na tunasoma 4.
                //
                // `i + chunk - 1 < ln / 2` # wakati hali
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Kwa kuwa ni chini ya urefu uliogawanywa na 2, basi lazima iwe katika mipaka.
                //
                // Hii inamaanisha pia kuwa hali `0 < i + chunk <= ln` inaheshimiwa kila wakati, kuhakikisha pointer ya `pb` inaweza kutumika salama.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // USALAMA: `i` ni duni kwa nusu ya urefu wa kipande hivyo
            // kufikia `i` na `ln - i - 1` ni salama (`i` huanza saa 0 na haitaenda zaidi ya `ln / 2 - 1`).
            // Madokezo yanayosababishwa `pa` na `pb` kwa hivyo ni halali na yamepangwa, na yanaweza kusomwa kutoka na kuandikiwa.
            //
            //
            unsafe {
                // Kubadilishana salama ili kuepuka mipaka kuangalia kwa kubadilishana salama.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Inarudisha iterator juu ya kipande.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Hurejesha iterator ambayo inaruhusu kurekebisha kila thamani.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Inarudisha iterator juu ya windows yote ya urefu wa `size`.
    /// Uingiliano wa windows.
    /// Ikiwa kipande ni kifupi kuliko `size`, iterator hairudishi maadili.
    ///
    /// # Panics
    ///
    /// Panics ikiwa `size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ikiwa kipande ni kifupi kuliko `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Hurejesha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwanzoni mwa kipande.
    ///
    /// Vipande ni vipande na haviingiliani.Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi chunk ya mwisho haitakuwa na urefu wa `chunk_size`.
    ///
    /// Tazama [`chunks_exact`] kwa lahaja ya iterator hii ambayo inarudisha vipande vya vitu vya `chunk_size` kila wakati, na [`rchunks`] kwa iterator sawa lakini kuanzia mwisho wa kipande.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Hurejesha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwanzoni mwa kipande.
    ///
    /// Vipande ni vipande vinavyoweza kubadilika, na havishirikiani.Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi chunk ya mwisho haitakuwa na urefu wa `chunk_size`.
    ///
    /// Tazama [`chunks_exact_mut`] kwa lahaja ya iterator hii ambayo inarudisha vipande vya vitu vya `chunk_size` kila wakati, na [`rchunks_mut`] kwa iterator sawa lakini kuanzia mwisho wa kipande.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Hurejesha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwanzoni mwa kipande.
    ///
    /// Vipande ni vipande na haviingiliani.
    /// Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi vitu vya mwisho hadi `chunk_size-1` vitaachwa na vinaweza kupatikana kutoka kwa kazi ya `remainder` ya iterator.
    ///
    ///
    /// Kwa sababu ya kila chunk iliyo na vitu vya `chunk_size` haswa, mkusanyaji anaweza kuboresha nambari inayosababisha bora kuliko kesi ya [`chunks`].
    ///
    /// Tazama [`chunks`] kwa lahaja ya iterator hii ambayo pia inarudisha salio kama chunk ndogo, na [`rchunks_exact`] kwa iterator sawa lakini kuanzia mwisho wa kipande.
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Hurejesha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwanzoni mwa kipande.
    ///
    /// Vipande ni vipande vinavyoweza kubadilika, na havishirikiani.
    /// Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi vitu vya mwisho hadi `chunk_size-1` vitaachwa na vinaweza kupatikana kutoka kwa kazi ya `into_remainder` ya iterator.
    ///
    ///
    /// Kwa sababu ya kila chunk iliyo na vitu vya `chunk_size` haswa, mkusanyaji anaweza kuboresha nambari inayosababisha bora kuliko kesi ya [`chunks_mut`].
    ///
    /// Tazama [`chunks_mut`] kwa lahaja ya iterator hii ambayo pia inarudisha salio kama chunk ndogo, na [`rchunks_exact_mut`] kwa iterator sawa lakini kuanzia mwisho wa kipande.
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Inagawanya kipande kwenye kipande cha safu ya `N`-element, ikidhani kuwa hakuna salio.
    ///
    ///
    /// # Safety
    ///
    /// Hii inaweza kuitwa tu wakati
    /// - Kipande hugawanyika haswa ndani ya `N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // USALAMA: Sehemu za kipengee 1 hazina salio
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // USALAMA: Urefu wa kipande (6) ni nyingi ya 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Hizi hazitakuwa za busara:
    /// // wacha vijiti: &[[_ _;5]]= slice.as_chunks_unchecked()//Urefu wa kipande sio anuwai ya vijisenti 5:&[[_;0]]= slice.as_chunks_unchecked()//Vipande vyenye urefu wa sifuri haviruhusiwi kamwe
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // USALAMA: Sharti yetu ndio hasa inahitajika kuita hii
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // USALAMA: Tunatupa kipande cha vitu vya `new_len * N` ndani
        // kipande cha `new_len` vipande vingi vya `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Kugawanya kipande kwenye kipande cha safu ya `N`-element, kuanzia mwanzoni mwa kipande, na kipande kilichobaki na urefu chini ya `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `N` ni 0. Hundi hii labda itabadilishwa kuwa hitilafu ya wakati wa kukusanya kabla njia hii haijatulia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // USALAMA: Tayari tuliogopa kwa sifuri, na tukahakikisha na ujenzi
        // kwamba urefu wa subslice ni anuwai ya N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Inagawanya kipande kwenye kipande cha safu ya `N`-element, kuanzia mwisho wa kipande, na kipande kilichobaki na urefu chini ya `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `N` ni 0. Hundi hii labda itabadilishwa kuwa hitilafu ya wakati wa kukusanya kabla njia hii haijatulia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // USALAMA: Tayari tuliogopa kwa sifuri, na tukahakikisha na ujenzi
        // kwamba urefu wa subslice ni anuwai ya N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Hurejesha iterator juu ya vipengee vya `N` vya kipande kwa wakati mmoja, kuanzia mwanzoni mwa kipande.
    ///
    /// Vipande ni marejeleo ya safu na hayaingiliani.
    /// Ikiwa `N` haigawanyi urefu wa kipande, basi vitu vya mwisho hadi `N-1` vitaachwa na vinaweza kupatikana kutoka kwa kazi ya `remainder` ya iterator.
    ///
    ///
    /// Njia hii ni sawa na gen gen ya [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics ikiwa `N` ni 0. Hundi hii labda itabadilishwa kuwa hitilafu ya wakati wa kukusanya kabla njia hii haijatulia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Inagawanya kipande kwenye kipande cha safu ya `N`-element, ikidhani kuwa hakuna salio.
    ///
    ///
    /// # Safety
    ///
    /// Hii inaweza kuitwa tu wakati
    /// - Kipande hugawanyika haswa ndani ya `N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // USALAMA: Sehemu za kipengee 1 hazina salio
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // USALAMA: Urefu wa kipande (6) ni nyingi ya 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Hizi hazitakuwa za busara:
    /// // wacha vijiti: &[[_ _;5]]= slice.as_chunks_unchecked_mut()//Urefu wa kipande sio anuwai ya vijisenti 5:&[[_;0]]= slice.as_chunks_unchecked_mut()//Vipande vyenye urefu wa sifuri haviruhusiwi kamwe
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // USALAMA: Sharti yetu ndio hasa inahitajika kuita hii
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // USALAMA: Tunatupa kipande cha vitu vya `new_len * N` ndani
        // kipande cha `new_len` vipande vingi vya `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Kugawanya kipande kwenye kipande cha safu ya `N`-element, kuanzia mwanzoni mwa kipande, na kipande kilichobaki na urefu chini ya `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `N` ni 0. Hundi hii labda itabadilishwa kuwa hitilafu ya wakati wa kukusanya kabla njia hii haijatulia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // USALAMA: Tayari tuliogopa kwa sifuri, na tukahakikisha na ujenzi
        // kwamba urefu wa subslice ni anuwai ya N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Inagawanya kipande kwenye kipande cha safu ya `N`-element, kuanzia mwisho wa kipande, na kipande kilichobaki na urefu chini ya `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `N` ni 0. Hundi hii labda itabadilishwa kuwa hitilafu ya wakati wa kukusanya kabla njia hii haijatulia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // USALAMA: Tayari tuliogopa kwa sifuri, na tukahakikisha na ujenzi
        // kwamba urefu wa subslice ni anuwai ya N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Hurejesha iterator juu ya vipengee vya `N` vya kipande kwa wakati mmoja, kuanzia mwanzoni mwa kipande.
    ///
    /// Vipande ni marejeleo ya safu inayoweza kubadilika na hayaingiliani.
    /// Ikiwa `N` haigawanyi urefu wa kipande, basi vitu vya mwisho hadi `N-1` vitaachwa na vinaweza kupatikana kutoka kwa kazi ya `into_remainder` ya iterator.
    ///
    ///
    /// Njia hii ni sawa na gen gen ya [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics ikiwa `N` ni 0. Hundi hii labda itabadilishwa kuwa hitilafu ya wakati wa kukusanya kabla njia hii haijatulia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Hurejesha iterator ikipishana na windows ya `N` ya kipande, kuanzia mwanzo wa kipande.
    ///
    ///
    /// Hii ni sawa na gen gen sawa na [`windows`].
    ///
    /// Ikiwa `N` ni kubwa kuliko saizi ya kipande, haitarudi windows.
    ///
    /// # Panics
    ///
    /// Panics ikiwa `N` ni 0.
    /// Hundi hii labda itabadilishwa kuwa kosa la kukusanya wakati kabla njia hii haijatulizwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Inarudisha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwisho wa kipande.
    ///
    /// Vipande ni vipande na haviingiliani.Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi chunk ya mwisho haitakuwa na urefu wa `chunk_size`.
    ///
    /// Tazama [`rchunks_exact`] kwa lahaja ya iterator hii ambayo inarudisha vipande vya vitu vya `chunk_size` kila wakati, na [`chunks`] kwa iterator sawa lakini kuanzia mwanzoni mwa kipande.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Inarudisha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwisho wa kipande.
    ///
    /// Vipande ni vipande vinavyoweza kubadilika, na havishirikiani.Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi chunk ya mwisho haitakuwa na urefu wa `chunk_size`.
    ///
    /// Tazama [`rchunks_exact_mut`] kwa lahaja ya iterator hii ambayo inarudisha vipande vya vitu vya `chunk_size` kila wakati, na [`chunks_mut`] kwa iterator sawa lakini kuanzia mwanzoni mwa kipande.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Inarudisha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwisho wa kipande.
    ///
    /// Vipande ni vipande na haviingiliani.
    /// Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi vitu vya mwisho hadi `chunk_size-1` vitaachwa na vinaweza kupatikana kutoka kwa kazi ya `remainder` ya iterator.
    ///
    /// Kwa sababu ya kila chunk iliyo na vitu vya `chunk_size` haswa, mkusanyaji anaweza kuboresha nambari inayosababisha bora kuliko kesi ya [`chunks`].
    ///
    /// Tazama [`rchunks`] kwa lahaja ya iterator hii ambayo pia inarudisha salio kama chunk ndogo, na [`chunks_exact`] kwa iterator sawa lakini kuanzia mwanzoni mwa kipande.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Inarudisha iterator juu ya vipengee vya `chunk_size` vya kipande kwa wakati mmoja, kuanzia mwisho wa kipande.
    ///
    /// Vipande ni vipande vinavyoweza kubadilika, na havishirikiani.
    /// Ikiwa `chunk_size` haigawanyi urefu wa kipande, basi vitu vya mwisho hadi `chunk_size-1` vitaachwa na vinaweza kupatikana kutoka kwa kazi ya `into_remainder` ya iterator.
    ///
    /// Kwa sababu ya kila chunk iliyo na vitu vya `chunk_size` haswa, mkusanyaji anaweza kuboresha nambari inayosababisha bora kuliko kesi ya [`chunks_mut`].
    ///
    /// Tazama [`rchunks_mut`] kwa lahaja ya iterator hii ambayo pia inarudisha salio kama chunk ndogo, na [`chunks_exact_mut`] kwa iterator sawa lakini kuanzia mwanzoni mwa kipande.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `chunk_size` ni 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Hurejesha iterator juu ya kipande kinachozalisha vipengee visivyoingiliana vya vitu kwa kutumia kielekezi kuwatenganisha.
    ///
    /// Kiarifu kinaitwa kwa vitu viwili vinavyofuata wenyewe, inamaanisha mtabiri anaitwa `slice[0]` na `slice[1]` kisha kwenye `slice[1]` na `slice[2]` na kadhalika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Njia hii inaweza kutumika kutoa manukuu yaliyopangwa:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Hurejesha iterator juu ya kipande kinachozalisha vipengee vya vitu visivyoingiliana vinavyoweza kutumia vitu kutumia kiarifu kutenganisha.
    ///
    /// Kiarifu kinaitwa kwa vitu viwili vinavyofuata wenyewe, inamaanisha mtabiri anaitwa `slice[0]` na `slice[1]` kisha kwenye `slice[1]` na `slice[2]` na kadhalika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Njia hii inaweza kutumika kutoa manukuu yaliyopangwa:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Inagawanya kipande kimoja kuwa mbili kwenye faharisi.
    ///
    /// Ya kwanza itakuwa na fahirisi zote kutoka kwa `[0, mid)` (ukiondoa faharisi `mid` yenyewe) na ya pili itakuwa na fahirisi zote kutoka kwa `[mid, len)` (ukiondoa faharisi ya `len` yenyewe).
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // USALAMA: `[ptr; mid]` na `[mid; len]` ziko ndani ya `self`, ambayo
        // inatimiza mahitaji ya `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Inagawanya kipande kimoja kinachoweza kubadilika kuwa mbili kwenye faharisi.
    ///
    /// Ya kwanza itakuwa na fahirisi zote kutoka kwa `[0, mid)` (ukiondoa faharisi `mid` yenyewe) na ya pili itakuwa na fahirisi zote kutoka kwa `[mid, len)` (ukiondoa faharisi ya `len` yenyewe).
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // USALAMA: `[ptr; mid]` na `[mid; len]` ziko ndani ya `self`, ambayo
        // inatimiza mahitaji ya `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Inagawanya kipande kimoja hadi viwili kwenye faharisi, bila kuangalia mipaka.
    ///
    /// Ya kwanza itakuwa na fahirisi zote kutoka kwa `[0, mid)` (ukiondoa faharisi `mid` yenyewe) na ya pili itakuwa na fahirisi zote kutoka kwa `[mid, len)` (ukiondoa faharisi ya `len` yenyewe).
    ///
    ///
    /// Kwa mbadala salama angalia [`split_at`].
    ///
    /// # Safety
    ///
    /// Kuita njia hii na faharisi isiyo nje ya mipaka ni *[tabia isiyojulikana]* hata kama rejeleo linalosababishwa halitumiki.Mpigaji lazima ahakikishe kuwa `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // USALAMA: Mpigaji simu lazima aangalie hiyo `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Inagawanya kipande kimoja kinachoweza kubadilika kuwa mbili katika faharisi, bila kuangalia mipaka.
    ///
    /// Ya kwanza itakuwa na fahirisi zote kutoka kwa `[0, mid)` (ukiondoa faharisi `mid` yenyewe) na ya pili itakuwa na fahirisi zote kutoka kwa `[mid, len)` (ukiondoa faharisi ya `len` yenyewe).
    ///
    ///
    /// Kwa mbadala salama angalia [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Kuita njia hii na faharisi isiyo nje ya mipaka ni *[tabia isiyojulikana]* hata kama rejeleo linalosababishwa halitumiki.Mpigaji lazima ahakikishe kuwa `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // USALAMA: Mpigaji simu lazima aangalie hiyo `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` na `[mid; len]` haziingiliani, kwa hivyo kurudisha rejeleo linaloweza kubadilika ni sawa.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Hurejesha iterator juu ya nakala zilizotengwa na vitu vinavyolingana na `pred`.
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ikiwa kipengee cha kwanza kimefananishwa, kipande tupu kitakuwa kitu cha kwanza kurudishwa na iterator.
    /// Vivyo hivyo, ikiwa kipengee cha mwisho kwenye kipande kimefananishwa, kipande tupu kitakuwa kitu cha mwisho kurudishwa na mtunzi:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ikiwa vitu viwili vinavyolingana viko karibu moja kwa moja, kipande tupu kitakuwepo kati yao:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Hurejesha iterator juu ya nakala zinazoweza kubadilika zilizotengwa na vitu vinavyolingana na `pred`.
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Hurejesha iterator juu ya nakala zilizotengwa na vitu vinavyolingana na `pred`.
    /// Kipengele kinacholingana kiko katika mwisho wa sehemu ndogo ya awali kama kimaliza.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ikiwa kipengee cha mwisho cha kipande kimefananishwa, kipengee hicho kitazingatiwa kama msimamishaji wa kipande kilichotangulia.
    ///
    /// Kipande hicho kitakuwa kitu cha mwisho kurudishwa na iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Hurejesha iterator juu ya nakala zinazoweza kubadilika zilizotengwa na vitu vinavyolingana na `pred`.
    /// Kipengee kinacholingana kiko katika kifurushi kilichopita kama kimaliza.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Hurejesha iterator juu ya nakala zilizotengwa na vitu vinavyolingana na `pred`, kuanzia mwisho wa kipande na kufanya kazi nyuma.
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kama ilivyo kwa `split()`, ikiwa kipengee cha kwanza au cha mwisho kimefananishwa, kipande tupu kitakuwa kitu cha kwanza (au cha mwisho) kinachorudishwa na iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Hurejesha iterator juu ya nakala zinazoweza kubadilika zilizotengwa na vitu vinavyolingana na `pred`, kuanzia mwisho wa kipande na kufanya kazi nyuma.
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Hurejesha iterator juu ya manukuu yaliyotengwa na vipengee vinavyolingana na `pred`, vimepunguzwa kwa kurudi kwa vitu vingi vya `n`
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// Kipengee cha mwisho kilirudishwa, ikiwa kipo, kitakuwa na kipande kilichobaki.
    ///
    /// # Examples
    ///
    /// Chapisha kipande kilichogawanyika mara moja kwa nambari zinazogawanyika na 3 (yaani, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Hurejesha iterator juu ya manukuu yaliyotengwa na vipengee vinavyolingana na `pred`, vimepunguzwa kwa kurudi kwa vitu vingi vya `n`
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// Kipengee cha mwisho kilirudishwa, ikiwa kipo, kitakuwa na kipande kilichobaki.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Hurejesha iterator juu ya manukato yaliyotengwa na vitu vinavyolingana na `pred` iliyo na kipimo cha kurudisha vitu vingi vya `n`.
    /// Hii huanza mwishoni mwa kipande na inafanya kazi nyuma.
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// Kipengee cha mwisho kilirudishwa, ikiwa kipo, kitakuwa na kipande kilichobaki.
    ///
    /// # Examples
    ///
    /// Chapisha kipande kilichogawanyika mara moja, kuanzia mwisho, kwa nambari zinazogawanywa na 3 (yaani, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Hurejesha iterator juu ya manukato yaliyotengwa na vitu vinavyolingana na `pred` iliyo na kipimo cha kurudisha vitu vingi vya `n`.
    /// Hii huanza mwishoni mwa kipande na inafanya kazi nyuma.
    /// Kipengele kinacholingana hakimo kwenye manukuu.
    ///
    /// Kipengee cha mwisho kilirudishwa, ikiwa kipo, kitakuwa na kipande kilichobaki.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Hurejesha `true` ikiwa kipande kina kipengee na thamani iliyopewa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ikiwa huna `&T`, lakini tu `&U` kama hiyo `T: Borrow<U>` (kwa mfano
    /// Kamba: Kopa<str>"), unaweza kutumia `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // kipande cha `String`
    /// assert!(v.iter().any(|e| e == "hello")); // tafuta na `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Hurejesha `true` ikiwa `needle` ni kiambishi awali cha kipande.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Daima inarudi `true` ikiwa `needle` ni kipande tupu:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Hurejesha `true` ikiwa `needle` ni kiambishi cha kipande.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Daima inarudi `true` ikiwa `needle` ni kipande tupu:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Hurejesha riba na kiambishi awali kimeondolewa.
    ///
    /// Ikiwa kipande kikianza na `prefix`, kinarudisha kipande kidogo baada ya kiambishi awali, kimefungwa `Some`.
    /// Ikiwa `prefix` haina kitu, inarudisha tu kipande cha asili.
    ///
    /// Ikiwa kipande hakianzi na `prefix`, inarudisha `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Kazi hii itahitaji kuandika tena ikiwa na wakati SlicePattern inakuwa ya kisasa zaidi.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Hurejesha riba na kiambishi kimeondolewa.
    ///
    /// Ikiwa kipande kinaisha na `suffix`, inarudisha kipande kidogo kabla ya kiambishi, kimefungwa `Some`.
    /// Ikiwa `suffix` haina kitu, inarudisha tu kipande cha asili.
    ///
    /// Ikiwa kipande hakiishi na `suffix`, inarudisha `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Kazi hii itahitaji kuandika tena ikiwa na wakati SlicePattern inakuwa ya kisasa zaidi.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary hutafuta kipande hiki kilichopangwa kwa kipengee fulani.
    ///
    /// Ikiwa dhamana inapatikana basi [`Result::Ok`] inarejeshwa, iliyo na faharisi ya kitu kinacholingana.
    /// Ikiwa kuna mechi nyingi, basi mechi yoyote inaweza kurudishwa.
    /// Ikiwa thamani haipatikani basi [`Result::Err`] inarejeshwa, ikiwa na faharisi ambapo kipengee kinacholingana kinaweza kuingizwa wakati wa kudumisha mpangilio uliopangwa.
    ///
    ///
    /// Tazama pia [`binary_search_by`], [`binary_search_by_key`], na [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Inatafuta safu ya vitu vinne.
    /// Ya kwanza inapatikana, ikiwa na msimamo wa kipekee;ya pili na ya tatu haipatikani;ya nne inaweza kulinganisha nafasi yoyote katika `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ikiwa unataka kuingiza kipengee kwa vector iliyopangwa, wakati unadumisha mpangilio wa aina:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary hutafuta kipande hiki kilichopangwa na kazi ya kulinganisha.
    ///
    /// Kazi ya kulinganisha inapaswa kutekeleza agizo linalolingana na mpangilio wa aina ya kipande cha msingi, ikirudisha nambari ya agizo ambayo inaonyesha ikiwa hoja yake ni `Less`, `Equal` au `Greater` lengo linalohitajika.
    ///
    ///
    /// Ikiwa dhamana inapatikana basi [`Result::Ok`] inarejeshwa, iliyo na faharisi ya kitu kinacholingana.Ikiwa kuna mechi nyingi, basi mechi yoyote inaweza kurudishwa.
    /// Ikiwa thamani haipatikani basi [`Result::Err`] inarejeshwa, ikiwa na faharisi ambapo kipengee kinacholingana kinaweza kuingizwa wakati wa kudumisha mpangilio uliopangwa.
    ///
    /// Tazama pia [`binary_search`], [`binary_search_by_key`], na [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Inatafuta safu ya vitu vinne.Ya kwanza inapatikana, ikiwa na msimamo wa kipekee;ya pili na ya tatu haipatikani;ya nne inaweza kulinganisha nafasi yoyote katika `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // USALAMA: wito unafanywa salama na wavamizi wafuatao:
            // - `mid >= 0`
            // - `mid < size`: `mid` imepunguzwa na `[left; right)` imefungwa.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Sababu kwa nini tunatumia mtiririko wa kudhibiti if/else badala ya mechi ni kwa sababu shughuli za kulinganisha mpangilio wa mechi, ambayo ni nyeti ya manukato.
            //
            // Hii ni x86 asm kwa u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary hutafuta kipande hiki kilichopangwa na kazi muhimu ya uchimbaji.
    ///
    /// Inadhaniwa kuwa kipande kimepangwa kwa ufunguo, kwa mfano na [`sort_by_key`] ikitumia kazi sawa ya uchimbaji.
    ///
    /// Ikiwa dhamana inapatikana basi [`Result::Ok`] inarejeshwa, iliyo na faharisi ya kitu kinacholingana.
    /// Ikiwa kuna mechi nyingi, basi mechi yoyote inaweza kurudishwa.
    /// Ikiwa thamani haipatikani basi [`Result::Err`] inarejeshwa, ikiwa na faharisi ambapo kipengee kinacholingana kinaweza kuingizwa wakati wa kudumisha mpangilio uliopangwa.
    ///
    ///
    /// Tazama pia [`binary_search`], [`binary_search_by`], na [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Inatafuta safu ya vitu vinne kwenye kipande cha jozi zilizopangwa na vitu vyao vya pili.
    /// Ya kwanza inapatikana, ikiwa na msimamo wa kipekee;ya pili na ya tatu haipatikani;ya nne inaweza kulinganisha nafasi yoyote katika `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links inaruhusiwa kama `slice::sort_by_key` iko katika crate `alloc`, na kwa hivyo haipo wakati wa kujenga `core`.
    //
    // viungo kwa mto crate: #74481.Kwa kuwa mali ya kwanza imeandikwa tu katika libstd (#73423), hii kamwe haisababishi viungo vilivyovunjika katika mazoezi.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Aina ya kipande, lakini haiwezi kuhifadhi mpangilio wa vitu sawa.
    ///
    /// Aina hii haina utulivu (kwa mfano, inaweza kupanga tena vitu sawa), mahali (yaani, haigawanyi), na *O*(*n*\*log(* n*)) kesi mbaya.
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa inategemea [pattern-defeating quicksort][pdqsort] na Orson Peters, ambayo inachanganya kesi ya wastani ya haraka ya bahati nasibu na kesi mbaya zaidi ya heapsort, wakati inafikia wakati wa laini kwenye vipande na mifumo fulani.
    /// Inatumia ujanibishaji fulani kuzuia kesi zinazoharibika, lakini kwa seed iliyowekwa ili kutoa tabia ya kuamua kila wakati.
    ///
    /// Ni kawaida haraka kuliko upangaji thabiti, isipokuwa katika visa kadhaa maalum, kwa mfano, wakati kipande kinajumuisha mfuatano kadhaa uliopangwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Aina ya kipande na kazi ya kulinganisha, lakini haiwezi kuhifadhi mpangilio wa vitu sawa.
    ///
    /// Aina hii haina utulivu (kwa mfano, inaweza kupanga tena vitu sawa), mahali (yaani, haigawanyi), na *O*(*n*\*log(* n*)) kesi mbaya.
    ///
    /// Kazi ya kulinganisha lazima ifafanue kuagiza kwa jumla kwa vitu kwenye kipande.Ikiwa kuagiza sio jumla, mpangilio wa vitu haujabainishwa.Agizo ni agizo la jumla ikiwa ni (kwa wote `a`, `b` na `c`):
    ///
    /// * jumla na antisymmetric: moja ya `a < b`, `a == b` au `a > b` ni kweli, na
    /// * transitive, `a < b` na `b < c` inamaanisha `a < c`.Vile vile lazima viwe na `==` na `>`.
    ///
    /// Kwa mfano, wakati [`f64`] haitekelezi [`Ord`] kwa sababu `NaN != NaN`, tunaweza kutumia `partial_cmp` kama kazi yetu ya aina wakati tunajua kipande hakina `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa inategemea [pattern-defeating quicksort][pdqsort] na Orson Peters, ambayo inachanganya kesi ya wastani ya haraka ya bahati nasibu na kesi mbaya zaidi ya heapsort, wakati inafikia wakati wa laini kwenye vipande na mifumo fulani.
    /// Inatumia ujanibishaji fulani kuzuia kesi zinazoharibika, lakini kwa seed iliyowekwa ili kutoa tabia ya kuamua kila wakati.
    ///
    /// Ni kawaida haraka kuliko upangaji thabiti, isipokuwa katika visa kadhaa maalum, kwa mfano, wakati kipande kinajumuisha mfuatano kadhaa uliopangwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // kuchagua nyuma
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Hupanga kipande na kazi muhimu ya uchimbaji, lakini haiwezi kuhifadhi mpangilio wa vitu sawa.
    ///
    /// Aina hii haina utulivu (kwa mfano, inaweza kupanga tena vitu sawa), mahali (yaani, haigawanyi), na *O*(m\* * n *\* log(*n*)) kesi mbaya, ambapo kazi muhimu ni *O*(*m*).
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa inategemea [pattern-defeating quicksort][pdqsort] na Orson Peters, ambayo inachanganya kesi ya wastani ya haraka ya bahati nasibu na kesi mbaya zaidi ya heapsort, wakati inafikia wakati wa laini kwenye vipande na mifumo fulani.
    /// Inatumia ujanibishaji fulani kuzuia kesi zinazoharibika, lakini kwa seed iliyowekwa ili kutoa tabia ya kuamua kila wakati.
    ///
    /// Kwa sababu ya mkakati wake muhimu wa kupiga simu, [`sort_unstable_by_key`](#method.sort_unstable_by_key) inaweza kuwa polepole kuliko [`sort_by_cached_key`](#method.sort_by_cached_key) katika hali ambapo kazi muhimu ni ghali.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Panga tena kipande ili kipengee kwenye `index` kiko katika nafasi yake ya mwisho iliyopangwa.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Panga tena kipande na kazi ya kulinganisha ili kwamba kipengele katika `index` kiko katika nafasi yake ya mwisho iliyopangwa.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Panga tena kipande na kazi muhimu ya uchimbaji ili kipengee kwenye `index` kiko katika nafasi yake ya mwisho iliyopangwa.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Panga tena kipande ili kipengee kwenye `index` kiko katika nafasi yake ya mwisho iliyopangwa.
    ///
    /// Upangaji huu una mali ya ziada ambayo thamani yoyote katika nafasi ya `i < index` itakuwa chini ya au sawa na thamani yoyote katika nafasi ya `j > index`.
    /// Kwa kuongezea, upangaji huu tena ni thabiti (yaani
    /// idadi yoyote ya vitu sawa inaweza kuishia katika nafasi `index`), mahali-mahali (yaani
    /// hagawi), na *O*(*n*) kesi mbaya zaidi.
    /// Kazi hii pia inajulikana kama "kth element" katika maktaba zingine.
    /// Inarudisha mara tatu ya maadili yafuatayo: vitu vyote chini ya ile iliyo kwenye faharisi iliyopewa, thamani kwenye faharisi iliyopewa, na vitu vyote vikubwa kuliko ile iliyo kwenye faharisi iliyopewa.
    ///
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa inategemea sehemu ya kuchagua haraka ya algorithm ile ile ya haraka inayotumika kwa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics wakati `index >= len()`, ikimaanisha kila mara panics kwenye vipande tupu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Pata wastani
    /// v.select_nth_unstable(2);
    ///
    /// // Tumehakikishiwa tu kwamba kipande kitakuwa moja ya yafuatayo, kulingana na njia tunayopanga kuhusu faharisi iliyoainishwa.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Panga tena kipande na kazi ya kulinganisha ili kwamba kipengele katika `index` kiko katika nafasi yake ya mwisho iliyopangwa.
    ///
    /// Upangaji huu una mali ya ziada ambayo thamani yoyote katika nafasi ya `i < index` itakuwa chini ya au sawa na thamani yoyote katika nafasi `j > index` ikitumia kazi ya kulinganisha.
    /// Kwa kuongezea, upangaji huu tena ni thabiti (kwa mfano, idadi yoyote ya vitu sawa inaweza kuishia katika nafasi ya `index`), mahali (yaani haigawanyi), na hali mbaya zaidi ya *O*(*n*).
    /// Kazi hii pia inajulikana kama "kth element" katika maktaba zingine.
    /// Inarudisha mara tatu ya maadili yafuatayo: vitu vyote chini ya ile iliyo kwenye faharisi iliyopewa, thamani kwenye faharisi iliyopewa, na vitu vyote vikubwa kuliko ile iliyo kwenye faharisi iliyopewa, kwa kutumia kazi ya kulinganisha iliyotolewa.
    ///
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa inategemea sehemu ya kuchagua haraka ya algorithm ile ile ya haraka inayotumika kwa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics wakati `index >= len()`, ikimaanisha kila mara panics kwenye vipande tupu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Pata wastani kama kipande kilipangwa kwa utaratibu wa kushuka.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Tumehakikishiwa tu kwamba kipande kitakuwa moja ya yafuatayo, kulingana na njia tunayopanga kuhusu faharisi iliyoainishwa.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Panga tena kipande na kazi muhimu ya uchimbaji ili kipengee kwenye `index` kiko katika nafasi yake ya mwisho iliyopangwa.
    ///
    /// Upangaji huu una mali ya ziada ambayo thamani yoyote katika nafasi ya `i < index` itakuwa chini ya au sawa na thamani yoyote katika nafasi `j > index` ikitumia kazi muhimu ya uchimbaji.
    /// Kwa kuongezea, upangaji huu tena ni thabiti (kwa mfano, idadi yoyote ya vitu sawa inaweza kuishia katika nafasi ya `index`), mahali (yaani haigawanyi), na hali mbaya zaidi ya *O*(*n*).
    /// Kazi hii pia inajulikana kama "kth element" katika maktaba zingine.
    /// Inarudisha mara tatu ya maadili yafuatayo: vitu vyote chini ya ile iliyo kwenye faharisi iliyopewa, thamani kwenye faharisi iliyopewa, na vitu vyote vikubwa kuliko ile iliyo kwenye faharisi iliyopewa, kwa kutumia kazi iliyotolewa ya ufunguo.
    ///
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa inategemea sehemu ya kuchagua haraka ya algorithm ile ile ya haraka inayotumika kwa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics wakati `index >= len()`, ikimaanisha kila mara panics kwenye vipande tupu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Rudisha wastani kama safu ilivyopangwa kulingana na thamani kamili.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Tumehakikishiwa tu kwamba kipande kitakuwa moja ya yafuatayo, kulingana na njia tunayopanga kuhusu faharisi iliyoainishwa.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Husogeza vitu vyote mfululizo mfululizo hadi mwisho wa kipande kulingana na utekelezaji wa [`PartialEq`] trait.
    ///
    ///
    /// Hurejesha vipande viwili.Ya kwanza haina vitu vyenye kurudia mfululizo.
    /// Ya pili ina marudio yote bila mpangilio maalum.
    ///
    /// Ikiwa kipande kimepangwa, kipande cha kwanza kilichorudishwa hakina nakala.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Husogeza yote isipokuwa ya kwanza ya vitu mfululizo hadi mwisho wa kipande kinachoridhisha uhusiano wa usawa uliopewa.
    ///
    /// Hurejesha vipande viwili.Ya kwanza haina vitu vyenye kurudia mfululizo.
    /// Ya pili ina marudio yote bila mpangilio maalum.
    ///
    /// Kazi ya `same_bucket` imepitisha marejeleo ya vitu viwili kutoka kwa kipande na lazima iamue ikiwa vitu vinalinganisha sawa.
    /// Vipengee hupitishwa kwa mpangilio tofauti kutoka kwa mpangilio wao kwenye kipande, kwa hivyo ikiwa `same_bucket(a, b)` inarudi `true`, `a` imehamishwa mwishoni mwa kipande.
    ///
    ///
    /// Ikiwa kipande kimepangwa, kipande cha kwanza kilichorudishwa hakina nakala.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Ingawa tuna rejeleo linaloweza kubadilika kwa `self`, hatuwezi kufanya mabadiliko ya kiholela.Simu za `same_bucket` zinaweza panic, kwa hivyo lazima tuhakikishe kuwa kipande kiko katika hali halali wakati wote.
        //
        // Njia ambayo tunashughulikia hii ni kwa kutumia swaps;tunapindukia juu ya vitu vyote, tukibadilishana tunapoenda ili mwishowe vitu tunavyotaka kuweka viko mbele, na wale ambao tunataka kukataa wako nyuma.
        // Tunaweza kisha kugawanya kipande.
        // Operesheni hii bado ni `O(n)`.
        //
        // Mfano: Tunaanza katika jimbo hili, ambapo `r` inawakilisha "ijayo
        // soma "na `w` inawakilisha" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Kulinganisha self[r] dhidi ya ubinafsi [w-1], hii sio dufu, kwa hivyo tunabadilishana self[r] na self[w] (hakuna athari kama r==w) na kisha kuongeza r na w, na kutuacha na:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ukilinganisha self[r] dhidi ya ubinafsi [w-1], thamani hii ni nakala, kwa hivyo tunaongeza `r` lakini tunaacha kila kitu bila kubadilika:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Kulinganisha self[r] dhidi ya ubinafsi [w-1], hii sio nakala, kwa hivyo badilisha self[r] na self[w] na usonge r na w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Sio rudufu, rudia:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Nakala, advance r. End ya kipande.Kugawanyika kwa w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // USALAMA: hali ya `while` inathibitisha `next_read` na `next_write`
        // ni chini ya `len`, kwa hivyo ziko ndani ya `self`.
        // `prev_ptr_write` inaelekeza kwa kitu kimoja kabla ya `ptr_write`, lakini `next_write` huanza saa 1, kwa hivyo `prev_ptr_write` sio chini ya 0 na iko ndani ya kipande.
        // Hii inatimiza mahitaji ya kutofautisha `ptr_read`, `prev_ptr_write` na `ptr_write`, na kwa kutumia `ptr.add(next_read)`, `ptr.add(next_write - 1)` na `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` pia huongezwa mara moja kwa kitanzi kwa maana zaidi hakuna kitu kinachorukwa wakati inaweza kuhitaji kubadilishwa.
        //
        // `ptr_read` na `prev_ptr_write` haionyeshi kitu kimoja.Hii inahitajika kwa `&mut *ptr_read`, `&mut* prev_ptr_write` kuwa salama.
        // Maelezo ni kwamba `next_read >= next_write` ni kweli kila wakati, kwa hivyo `next_read > next_write - 1` pia ni hivyo.
        //
        //
        //
        //
        //
        unsafe {
            // Epuka ukaguzi wa mipaka kwa kutumia viashiria mbichi.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Inahamisha yote isipokuwa ya kwanza ya vitu mfululizo hadi mwisho wa kipande ambacho huamua kwa ufunguo mmoja.
    ///
    ///
    /// Hurejesha vipande viwili.Ya kwanza haina vitu vyenye kurudia mfululizo.
    /// Ya pili ina marudio yote bila mpangilio maalum.
    ///
    /// Ikiwa kipande kimepangwa, kipande cha kwanza kilichorudishwa hakina nakala.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Inazungusha kipande mahali ambapo vitu vya kwanza vya `mid` vinaendelea hadi mwisho wakati vitu vya mwisho vya `self.len() - mid` vinaelekea mbele.
    /// Baada ya kupiga `rotate_left`, kipengee hapo awali kwenye faharisi `mid` kitakuwa kitu cha kwanza kwenye kipande.
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa `mid` ni kubwa kuliko urefu wa kipande.Kumbuka kuwa `mid == self.len()` inafanya _not_ panic na ni mzunguko usiofaa.
    ///
    /// # Complexity
    ///
    /// Inachukua laini (kwa saa `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Inazunguka subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // USALAMA: Masafa ya `[p.add(mid) - mid, p.add(mid) + k)` hayafai
        // halali kwa kusoma na kuandika, kama inavyotakiwa na `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Inazungusha kipande mahali ambapo vitu vya kwanza vya `self.len() - k` vinaendelea hadi mwisho wakati vitu vya mwisho vya `k` vinaelekea mbele.
    /// Baada ya kupiga `rotate_right`, kipengee hapo awali kwenye faharisi `self.len() - k` kitakuwa kitu cha kwanza kwenye kipande.
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa `k` ni kubwa kuliko urefu wa kipande.Kumbuka kuwa `k == self.len()` inafanya _not_ panic na ni mzunguko usiofaa.
    ///
    /// # Complexity
    ///
    /// Inachukua laini (kwa saa `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Zungusha njia ndogo:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // USALAMA: Masafa ya `[p.add(mid) - mid, p.add(mid) + k)` hayafai
        // halali kwa kusoma na kuandika, kama inavyotakiwa na `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Inajaza `self` na vitu kwa kuunda `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Hujaza `self` na vitu vimerudishwa kwa kupiga kufungwa mara kwa mara.
    ///
    /// Njia hii hutumia kufungwa ili kuunda maadili mpya.Ikiwa ungependa [`Clone`] thamani uliyopewa, tumia [`fill`].
    /// Ikiwa unataka kutumia [`Default`] trait kutengeneza maadili, unaweza kupitisha [`Default::default`] kama hoja.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Inakili vitu kutoka `src` hadi `self`.
    ///
    /// Urefu wa `src` lazima iwe sawa na `self`.
    ///
    /// Ikiwa `T` itatumia `Copy`, inaweza kuwa bora zaidi kutumia [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa vipande viwili vina urefu tofauti.
    ///
    /// # Examples
    ///
    /// Kuunganisha vitu viwili kutoka kwa kipande hadi kingine:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kwa sababu vipande vinapaswa kuwa na urefu sawa, tunakata kipande cha chanzo kutoka kwa vitu vinne hadi mbili.
    /// // Itakuwa panic ikiwa hatufanyi hivi.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust inasisitiza kuwa kunaweza kuwa na rejeleo moja tu inayoweza kubadilika bila marejeleo yasiyoweza kubadilika kwa kipande cha data katika upeo fulani.
    /// Kwa sababu ya hii, kujaribu kutumia `clone_from_slice` kwenye kipande kimoja kutasababisha kutofaulu kwa kukusanya:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ili kufanya kazi karibu na hii, tunaweza kutumia [`split_at_mut`] kuunda vipande viwili tofauti kutoka kwa kipande:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Inakili vitu vyote kutoka `src` hadi `self`, ukitumia memcpy.
    ///
    /// Urefu wa `src` lazima iwe sawa na `self`.
    ///
    /// Ikiwa `T` haitekelezi `Copy`, tumia [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa vipande viwili vina urefu tofauti.
    ///
    /// # Examples
    ///
    /// Kuiga vitu viwili kutoka kwa kipande hadi kingine:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kwa sababu vipande vinapaswa kuwa na urefu sawa, tunakata kipande cha chanzo kutoka kwa vitu vinne hadi mbili.
    /// // Itakuwa panic ikiwa hatufanyi hivi.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust inasisitiza kuwa kunaweza kuwa na rejeleo moja tu inayoweza kubadilika bila marejeleo yasiyoweza kubadilika kwa kipande cha data katika upeo fulani.
    /// Kwa sababu ya hii, kujaribu kutumia `copy_from_slice` kwenye kipande kimoja kutasababisha kutofaulu kwa kukusanya:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ili kufanya kazi karibu na hii, tunaweza kutumia [`split_at_mut`] kuunda vipande viwili tofauti kutoka kwa kipande:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Njia ya nambari ya panic iliwekwa katika kazi baridi ili isizuie tovuti ya simu.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // USALAMA: `self` ni halali kwa vitu `self.len()` kwa ufafanuzi, na `src` ilikuwa
        // kuchunguzwa kuwa na urefu sawa.
        // Vipande haviwezi kuingiliana kwa sababu marejeleo yanayoweza kubadilika ni ya kipekee.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Inakili vitu kutoka sehemu moja ya kipande hadi sehemu nyingine yenyewe, kwa kutumia memmove.
    ///
    /// `src` ni masafa ndani ya `self` kunakili kutoka.
    /// `dest` ni faharisi ya kuanzia ya masafa ndani ya `self` kunakiliwa, ambayo itakuwa na urefu sawa na `src`.
    /// Masafa mawili yanaweza kuingiliana.
    /// Mwisho wa masafa mawili lazima iwe chini au sawa na `self.len()`.
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa anuwai inaweza kuzidi mwisho wa kipande, au ikiwa mwisho wa `src` ni kabla ya kuanza.
    ///
    ///
    /// # Examples
    ///
    /// Kuiga ka nne ndani ya kipande:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // USALAMA: masharti ya `ptr::copy` yote yameangaliwa hapo juu,
        // kama hizo za `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Inabadilisha vitu vyote katika `self` na zile zilizo kwenye `other`.
    ///
    /// Urefu wa `other` lazima iwe sawa na `self`.
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa vipande viwili vina urefu tofauti.
    ///
    /// # Example
    ///
    /// Kubadilisha vitu viwili kwenye vipande:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust inasisitiza kuwa kunaweza kuwa na kumbukumbu moja tu inayoweza kubadilika kwa kipande cha data katika upeo fulani.
    ///
    /// Kwa sababu ya hii, kujaribu kutumia `swap_with_slice` kwenye kipande kimoja kutasababisha kutofaulu kwa kukusanya:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Ili kufanya kazi karibu na hii, tunaweza kutumia [`split_at_mut`] kuunda vipande viwili tofauti vinavyoweza kubadilika kutoka kwa kipande:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // USALAMA: `self` ni halali kwa vitu `self.len()` kwa ufafanuzi, na `src` ilikuwa
        // kuchunguzwa kuwa na urefu sawa.
        // Vipande haviwezi kuingiliana kwa sababu marejeleo yanayoweza kubadilika ni ya kipekee.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Kazi ya kuhesabu urefu wa kipande cha kati na kinachofuatia kwa `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Tunachofanya kuhusu `rest` ni kubaini ni nini nyingi za `U` ambazo tunaweza kuweka katika idadi ya chini kabisa ya`T`s.
        //
        // Na tunahitaji T ngapi kwa kila "multiple" kama hiyo.
        //
        // Fikiria kwa mfano T=u8 U=u16.Kisha tunaweza kuweka 1 U katika 2 Ts.Rahisi.
        // Sasa, fikiria kwa mfano kesi ambapo size_of: :<T>=16, ukubwa_wa::<U>=24.</u>
        // Tunaweza kuweka 2 Us badala ya kila Ts 3 katika kipande cha `rest`.
        // Ngumu zaidi.
        //
        // Mfumo wa kuhesabu hii ni:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Iliyopanuliwa na iliyorahisishwa:
        //
        // Nasi=saizi_ya: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=saizi_ya::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Kwa bahati nzuri kwa kuwa yote haya yanatathminiwa kila wakati ... utendaji hapa haujalishi!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // itrative stein's algorithm Bado tunapaswa kuifanya hii `const fn` (na kurudi kwenye algorithm ya kurudia ikiwa tutafanya) kwa sababu kutegemea llvm kutimiza yote haya ni…vizuri, inanifanya nisiwe na wasiwasi.
            //
            //

            // USALAMA: `a` na `b` hukaguliwa kuwa maadili yasiyo ya sifuri.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ondoa sababu zote za 2 kutoka b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // USALAMA: `b` inachunguzwa kuwa isiyo ya sifuri.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Silaha na maarifa haya, tunaweza kupata ngapi `U`s tunaweza kutoshea!
        let us_len = self.len() / ts * us;
        // Na `T`s ngapi zitakuwa kwenye kipande kinachofuatilia!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Sambaza kipande kwa kipande cha aina nyingine, kuhakikisha upatanisho wa aina hizo unadumishwa.
    ///
    /// Njia hii hugawanya kipande katika vipande vitatu tofauti: kiambishi awali, kipande cha katikati kilichokaa sawa cha aina mpya, na kipande cha kiambishi.
    /// Njia inaweza kufanya kipande cha kati urefu bora zaidi kwa aina fulani na kipande cha pembejeo, lakini tu utendaji wa algorithm yako unapaswa kutegemea hiyo, sio usahihi wake.
    ///
    /// Inaruhusiwa kwa data yote ya ingizo kurudishwa kama kiambishi awali au kipande cha kiambishi.
    ///
    /// Njia hii haina kusudi wakati kipengee chochote cha kuingiza `T` au kipengee cha pato `U` kina ukubwa wa sifuri na itarudisha kipande cha asili bila kugawanya chochote.
    ///
    /// # Safety
    ///
    /// Njia hii kimsingi ni `transmute` kwa kuzingatia vipengee kwenye kipande cha katikati kilichorudishwa, kwa hivyo mapango yote ya kawaida yanayohusu `transmute::<T, U>` pia yanatumika hapa.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Kumbuka kuwa nyingi ya kazi hii itakaguliwa kila wakati,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // shughulikia ZSTs haswa, ambayo-usishughulikie hata kidogo.
            return (self, &[], &[]);
        }

        // Kwanza, tafuta wakati gani tunagawanyika kati ya kipande cha kwanza na cha 2.
        // Rahisi na ptr.align_offset.
        let ptr = self.as_ptr();
        // USALAMA: Tazama njia ya `align_to_mut` kwa maoni ya kina ya usalama.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // USALAMA: sasa `rest` imewekwa sawa, kwa hivyo `from_raw_parts` hapa chini iko sawa,
            // kwani mpigaji anahakikishia kwamba tunaweza kusambaza `T` hadi `U` salama.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Sambaza kipande kwa kipande cha aina nyingine, kuhakikisha upatanisho wa aina hizo unadumishwa.
    ///
    /// Njia hii hugawanya kipande katika vipande vitatu tofauti: kiambishi awali, kipande cha katikati kilichokaa sawa cha aina mpya, na kipande cha kiambishi.
    /// Njia inaweza kufanya kipande cha kati urefu bora zaidi kwa aina fulani na kipande cha pembejeo, lakini tu utendaji wa algorithm yako unapaswa kutegemea hiyo, sio usahihi wake.
    ///
    /// Inaruhusiwa kwa data yote ya ingizo kurudishwa kama kiambishi awali au kipande cha kiambishi.
    ///
    /// Njia hii haina kusudi wakati kipengee chochote cha kuingiza `T` au kipengee cha pato `U` kina ukubwa wa sifuri na itarudisha kipande cha asili bila kugawanya chochote.
    ///
    /// # Safety
    ///
    /// Njia hii kimsingi ni `transmute` kwa kuzingatia vipengee kwenye kipande cha katikati kilichorudishwa, kwa hivyo mapango yote ya kawaida yanayohusu `transmute::<T, U>` pia yanatumika hapa.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Kumbuka kuwa nyingi ya kazi hii itakaguliwa kila wakati,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // shughulikia ZSTs haswa, ambayo-usishughulikie hata kidogo.
            return (self, &mut [], &mut []);
        }

        // Kwanza, tafuta wakati gani tunagawanyika kati ya kipande cha kwanza na cha 2.
        // Rahisi na ptr.align_offset.
        let ptr = self.as_ptr();
        // USALAMA: Hapa tunahakikisha tutatumia viashiria vilivyofanana kwa U kwa U
        // njia iliyobaki.Hii imefanywa kwa kupitisha pointer kwa&[T] na mpangilio unaolengwa kwa U.
        // `crate::ptr::align_offset` inaitwa na pointer iliyokaa sawa na halali `ptr` (inatoka kwa rejeleo la `self`) na kwa saizi ambayo ni nguvu ya mbili (kwani inatoka kwa mpangilio wa U), kukidhi vikwazo vyake vya usalama.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Hatuwezi kutumia `rest` tena baada ya hii, ambayo inaweza kubatilisha jina lake `mut_ptr`!USALAMA: angalia maoni ya `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Hundi ikiwa vipengee vya kipande hiki vimepangwa.
    ///
    /// Hiyo ni, kwa kila kipengee `a` na kipengee chake kinachofuata `b`, `a <= b` lazima ishikilie.Ikiwa kipande kinatoa sifuri au kitu kimoja, `true` inarejeshwa.
    ///
    /// Kumbuka kuwa ikiwa `Self::Item` ni `PartialOrd` tu, lakini sio `Ord`, ufafanuzi hapo juu unamaanisha kuwa kazi hii inarudi `false` ikiwa vitu vifuatavyo viwili havilinganishwi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Hundi ikiwa vipengee vya kipande hiki vimepangwa kwa kutumia kazi ya kulinganisha iliyopewa.
    ///
    /// Badala ya kutumia `PartialOrd::partial_cmp`, kazi hii hutumia kazi iliyopewa `compare` kuamua kuagiza kwa vitu viwili.
    /// Mbali na hayo, ni sawa na [`is_sorted`];tazama nyaraka zake kwa habari zaidi.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Hundi ikiwa vipengee vya kipande hiki vimepangwa kwa kutumia kazi iliyopewa ya uchimbaji.
    ///
    /// Badala ya kulinganisha vitu vya kipande moja kwa moja, kazi hii inalinganisha funguo za vitu, kama ilivyoamuliwa na `f`.
    /// Mbali na hayo, ni sawa na [`is_sorted`];tazama nyaraka zake kwa habari zaidi.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Hurejesha fahirisi ya sehemu ya kizigeu kulingana na kiarifu kilichopewa (faharisi ya kipengee cha kwanza cha kizigeu cha pili).
    ///
    /// Kipande kinadhaniwa kugawanywa kulingana na kiarifu kilichopewa.
    /// Hii inamaanisha kuwa vitu vyote ambavyo kiarifu kinarudi kweli ni mwanzoni mwa kipande na vitu vyote ambavyo kiarifu hurudisha uwongo mwisho.
    ///
    /// Kwa mfano, [7, 15, 3, 5, 4, 12, 6] imegawanywa chini ya kiarifu x% 2!=0 (nambari zote zisizo za kawaida ziko mwanzoni, zote hata mwishoni).
    ///
    /// Ikiwa kipande hiki hakijagawanywa, matokeo yaliyorudishwa hayajabainishwa na hayana maana, kwani njia hii hufanya aina ya utaftaji wa kibinadamu.
    ///
    /// Tazama pia [`binary_search`], [`binary_search_by`], na [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // USALAMA: Wakati `left < right`, `left <= mid < right`.
            // Kwa hivyo `left` huongezeka kila wakati na `right` hupungua kila wakati, na yeyote kati yao huchaguliwa.Katika visa vyote `left <= right` imeridhika.Kwa hivyo ikiwa `left < right` kwa hatua, `left <= right` imeridhika katika hatua inayofuata.
            //
            // Kwa hivyo ilimradi `left != right`, `0 <= left < right <= len` imeridhika na ikiwa kesi hii `0 <= mid < len` imeridhika pia.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Tunahitaji kuzipaka wazi kwa urefu sawa
        // kurahisisha uboreshaji kwa mipaka ya muda kuangalia.
        // Lakini kwa kuwa haiwezi kutegemewa pia tuna utaalam wazi wa T: Nakili.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Inaunda kipande tupu.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Inaunda kipande tupu kinachoweza kubadilika.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Sampuli katika vipande, kwa sasa, hutumiwa tu na `strip_prefix` na `strip_suffix`.
/// Katika hatua ya future, tunatarajia kuongeza jumla ya `core::str::Pattern` (ambayo wakati wa kuandika ni mdogo kwa `str`) kwa vipande, na kisha trait hii itabadilishwa au kufutwa.
///
pub trait SlicePattern {
    /// Aina ya kipande cha kipande kinacholingana.
    type Item;

    /// Hivi sasa, watumiaji wa `SlicePattern` wanahitaji kipande.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}