//! Macros zinazotumiwa na iterators ya kipande.

// Inlining is_empty na len hufanya tofauti kubwa ya utendaji
macro_rules! is_empty {
    // Njia tunayosimba urefu wa iterator ya ZST, hii inafanya kazi kwa ZST na isiyo ya ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ili kuondoa hundi kadhaa za mipaka (tazama `position`), tunahesabu urefu kwa njia isiyotarajiwa.
// (Imejaribiwa na `codegen/kipande-nafasi-mipaka-angalia`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // wakati mwingine tunatumiwa ndani ya kizuizi kisicho salama

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ hii hutumia `unchecked_sub` kwa sababu tunategemea kufunika kufunika urefu wa iterators ndefu za kipande cha ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Tunajua kuwa `start <= end`, kwa hivyo inaweza kufanya vizuri kuliko `offset_from`, ambayo inahitaji kushughulika na saini.
            // Kwa kuweka bendera zinazofaa hapa tunaweza kuwaambia LLVM hii, ambayo inasaidia kuondoa ukaguzi wa mipaka.
            // USALAMA: Na aina isiyobadilika, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Kwa kuambia LLVM pia kuwa vidokezo vimetenganishwa na anuwai ya saizi ya aina, inaweza kuboresha `len() == 0` hadi `start == end` badala ya `(end - start) < size`.
            //
            // USALAMA: Kwa aina isiyobadilika, vidokezo vimewekwa sawa
            //         umbali kati yao lazima iwe nyingi ya saizi ya pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Ufafanuzi wa pamoja wa watayarishaji wa `Iter` na `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Hurejesha kipengee cha kwanza na kusogeza mwanzo wa iterator mbele kwa 1.
        // Inaboresha sana utendaji ikilinganishwa na kazi iliyopangwa.
        // Iterator lazima isiwe tupu.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Inarudisha kipengee cha mwisho na kusogeza mwisho wa iterator nyuma na 1.
        // Inaboresha sana utendaji ikilinganishwa na kazi iliyopangwa.
        // Iterator lazima isiwe tupu.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Inapunguza iterator wakati T ni ZST, kwa kusogeza mwisho wa iterator nyuma na `n`.
        // `n` haipaswi kuzidi `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Kazi ya msaidizi wa kuunda kipande kutoka kwa iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // USALAMA: iterator iliundwa kutoka kwa kipande na pointer
                // `self.ptr` na urefu `len!(self)`.
                // Hii inahakikishia kuwa mahitaji yote ya `from_raw_parts` yametimizwa.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Kazi ya msaidizi wa kusonga mwanzo wa iterator mbele na vitu vya `offset`, kurudisha mwanzo wa zamani.
            //
            // Sio salama kwa sababu malipo hayapaswi kuzidi `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // USALAMA: mpigaji anahakikisha kuwa `offset` haizidi `self.len()`,
                    // kwa hivyo hii pointer mpya iko ndani ya `self` na kwa hivyo imehakikishiwa kuwa isiyo ya kweli.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Kazi ya msaidizi ya kusonga mwisho wa iterator nyuma na vitu vya `offset`, kurudisha mwisho mpya.
            //
            // Sio salama kwa sababu malipo hayapaswi kuzidi `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // USALAMA: mpigaji anahakikisha kuwa `offset` haizidi `self.len()`,
                    // ambayo imehakikishiwa kutofurika `isize`.
                    // Pia, pointer inayosababishwa iko katika mipaka ya `slice`, ambayo inatimiza mahitaji mengine ya `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // inaweza kutekelezwa na vipande, lakini hii inepuka ukaguzi wa mipaka

                // USALAMA: Simu za `assume` ziko salama kwani kiashiria cha kuanza kwa kipande
                // lazima isiwe batili, na vipande juu ya visivyo vya ZST lazima pia viwe na kiashiria cha mwisho kisichobadilika.
                // Simu kwa `next_unchecked!` ni salama kwani tunaangalia ikiwa iterator haina kitu kwanza.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Kitambulisho hiki sasa hakina kitu.
                    if mem::size_of::<T>() == 0 {
                        // Lazima tuifanye hivi kwani `ptr` inaweza kuwa 0, lakini `end` inaweza kuwa (kwa sababu ya kufunga).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // USALAMA: mwisho hauwezi kuwa 0 ikiwa T sio ZST kwa sababu ptr sio 0 na mwisho>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // USALAMA: Tuko katika mipaka.`post_inc_start` hufanya jambo sahihi hata kwa ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Tunabatilisha utekelezaji wa msingi, ambao hutumia `try_fold`, kwa sababu utekelezaji huu rahisi hutengeneza chini ya LLVM IR na ni haraka kukusanya.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Tunabatilisha utekelezaji wa msingi, ambao hutumia `try_fold`, kwa sababu utekelezaji huu rahisi hutengeneza chini ya LLVM IR na ni haraka kukusanya.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Tunabatilisha utekelezaji wa msingi, ambao hutumia `try_fold`, kwa sababu utekelezaji huu rahisi hutengeneza chini ya LLVM IR na ni haraka kukusanya.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Tunabatilisha utekelezaji wa msingi, ambao hutumia `try_fold`, kwa sababu utekelezaji huu rahisi hutengeneza chini ya LLVM IR na ni haraka kukusanya.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Tunabatilisha utekelezaji wa msingi, ambao hutumia `try_fold`, kwa sababu utekelezaji huu rahisi hutengeneza chini ya LLVM IR na ni haraka kukusanya.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Tunabatilisha utekelezaji wa msingi, ambao hutumia `try_fold`, kwa sababu utekelezaji huu rahisi hutengeneza chini ya LLVM IR na ni haraka kukusanya.
            // Pia, `assume` inaepuka kuangalia mipaka.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // USALAMA: tunahakikishiwa kuwa katika mipaka na mvumbuzi wa kitanzi:
                        // wakati `i >= n`, `self.next()` inarudi `None` na mapumziko ya kitanzi.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Tunabatilisha utekelezaji wa msingi, ambao hutumia `try_fold`, kwa sababu utekelezaji huu rahisi hutengeneza chini ya LLVM IR na ni haraka kukusanya.
            // Pia, `assume` inaepuka kuangalia mipaka.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // USALAMA: `i` lazima iwe chini kuliko `n` kwani huanza saa `n`
                        // na inapungua tu.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // USALAMA: mpigaji lazima ahakikishe kuwa `i` iko katika mipaka ya
                // kipande cha msingi, kwa hivyo `i` haiwezi kufurika `isize`, na marejeleo yaliyorudishwa yanahakikishiwa kurejelea kipengee cha kipande na kwa hivyo imehakikishwa kuwa halali.
                //
                // Pia kumbuka kuwa mpigaji simu pia anahakikishia kuwa hatujaitwa tena na faharisi sawa tena, na kwamba hakuna njia zingine ambazo zitaweza kufikia riba hii inayoitwa, kwa hivyo ni halali kwa rejeleo lililorejeshwa kuweza kubadilika katika kesi ya
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // inaweza kutekelezwa na vipande, lakini hii inepuka ukaguzi wa mipaka

                // USALAMA: Simu za `assume` ni salama kwani kipeo cha kuanza kipande lazima kiwe batili,
                // na vipande juu ya zisizo za ZST lazima pia ziwe na kiashiria cha mwisho kisicho cha ubatili.
                // Simu kwa `next_back_unchecked!` ni salama kwani tunaangalia ikiwa iterator haina kitu kwanza.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Kitambulisho hiki sasa hakina kitu.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // USALAMA: Tuko katika mipaka.`pre_dec_end` hufanya jambo sahihi hata kwa ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}