// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Huzungusha fungu la `[mid-left, mid+right)` hivi kwamba kipengee katika `mid` kinakuwa kipengee cha kwanza.Vivyo hivyo, huzungusha vipengee anuwai vya `left` kushoto au vipengee vya `right` kulia.
///
/// # Safety
///
/// Masafa yaliyotajwa lazima yawe halali kwa kusoma na kuandika.
///
/// # Algorithm
///
/// Algorithm 1 hutumiwa kwa maadili madogo ya `left + right` au kwa `T` kubwa.
/// Vipengee vinahamishwa katika nafasi zao za mwisho moja kwa moja kuanzia `mid - left` na kuendelea na hatua za `right` modulo `left + right`, kama kwamba inahitajika muda mmoja tu.
/// Hatimaye, tunarudi kwa `mid - left`.
/// Walakini, ikiwa `gcd(left + right, right)` sio 1, hatua zilizo hapo juu ziliruka vitu.
/// Kwa mfano:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Kwa bahati nzuri, idadi ya vitu vilivyorukwa kati ya vitu vilivyokamilishwa daima ni sawa, kwa hivyo tunaweza tu kumaliza nafasi yetu ya kuanza na kufanya raundi zaidi (jumla ya raundi ni `gcd(left + right, right)` value).
///
/// Matokeo ya mwisho ni kwamba vitu vyote hukamilishwa mara moja na mara moja tu.
///
/// Algorithm 2 hutumiwa ikiwa `left + right` ni kubwa lakini `min(left, right)` ni ndogo ya kutosha kutoshea kwenye bafa ya stack.
/// Vipengee vya `min(left, right)` vinakiliwa kwenye bafa, `memmove` hutumiwa kwa zingine, na zile zilizo kwenye bafa hurejeshwa kwenye shimo upande wa pili wa zilikotokea.
///
/// Algorithms ambayo inaweza kuwa vectorized inazidi hapo juu mara `left + right` inakuwa kubwa ya kutosha.
/// Algorithm 1 inaweza kuwa vectorized kwa kukatiza na kufanya raundi nyingi mara moja, lakini kuna raundi chache sana kwa wastani hadi `left + right` iwe kubwa, na kesi mbaya ya duru moja iko kila wakati.
/// Badala yake, algorithm 3 hutumia ubadilishaji unaorudiwa wa vitu vya `min(left, right)` hadi shida ndogo ya kuzunguka iachwe.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// wakati `left < right` ubadilishaji unatokea kutoka kushoto badala yake.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algorithms zilizo hapa chini zinaweza kushindwa ikiwa kesi hizi hazitaangaliwa
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks zinaonyesha kuwa utendaji wastani wa mabadiliko ya nasibu ni bora njia yote hadi karibu `left + right == 32`, lakini utendaji mbaya kabisa huvunja hata karibu 16.
            // 24 ilichaguliwa kama uwanja wa kati.
            // Ikiwa saizi ya `T` ni kubwa kuliko 4 `usize`s, algorithm hii pia inazidi algorithms zingine.
            //
            //
            let x = unsafe { mid.sub(left) };
            // mwanzo wa raundi ya kwanza
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` inaweza kupatikana kabla ya mkono kwa kuhesabu `gcd(left + right, right)`, lakini ni haraka kufanya kitanzi kimoja ambacho huhesabu gcd kama athari ya kando, kisha kufanya sehemu iliyobaki
            //
            //
            let mut gcd = right;
            // vielelezo vinafunua kuwa ni haraka kubadilishana kwa muda mrefu badala ya kusoma kwa muda mfupi mara moja, kunakili nyuma, na kisha kuandika muda huo mwisho.
            // Hii labda ni kutokana na ukweli kwamba kubadilisha au kubadilisha temporari hutumia anwani moja tu ya kumbukumbu kwenye kitanzi badala ya kuhitaji kusimamia mbili.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // badala ya kuongeza `i` na kisha kuangalia ikiwa iko nje ya mipaka, tunaangalia ikiwa `i` itaenda nje ya mipaka kwenye nyongeza inayofuata.
                // Hii inazuia kufunikwa kwa viashiria au `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // mwisho wa raundi ya kwanza
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // masharti haya lazima yawe hapa ikiwa `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // maliza chunk na raundi zaidi
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` sio aina ya saizi, kwa hivyo ni sawa kugawanya kwa saizi yake.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 `[T; 0]` hapa ni kuhakikisha kuwa hii imewekwa sawa kwa T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Kuna njia mbadala ya kubadilishana ambayo inajumuisha kutafuta mahali ambapo ubadilishaji wa mwisho wa algorithm hii itakuwa, na kubadilisha kwa kutumia sehemu hiyo ya mwisho badala ya kubadilisha vipande vya karibu kama vile algorithm hii inafanya, lakini njia hii bado ni haraka.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}