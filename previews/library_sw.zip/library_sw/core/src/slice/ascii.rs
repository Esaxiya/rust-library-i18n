//! Uendeshaji wa ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Hukagua kama ka zote kwenye kipande hiki ziko ndani ya anuwai ya ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Hukagua kuwa vipande viwili ni mechi isiyo na hisia ya ASCII.
    ///
    /// Sawa na `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, lakini bila kutenga na kunakili temporari.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Inabadilisha kipande hiki kuwa kesi yake ya hali ya juu ya ASCII.
    ///
    /// Barua za ASCII 'a' hadi 'z' zimepangwa kwa 'A' hadi 'Z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kurudisha thamani mpya ya juu bila kurekebisha ile iliyopo, tumia [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Inabadilisha kipande hiki kuwa sawa na kesi yake ndogo ya ASCII.
    ///
    /// Barua za ASCII 'A' hadi 'Z' zimepangwa kwa 'a' hadi 'z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Kurudisha thamani mpya iliyopunguzwa bila kurekebisha iliyopo, tumia [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Hurejesha `true` ikiwa baiti yoyote katika neno `v` ni nonascii (>=128).
/// Snarfed kutoka `../str/mod.rs`, ambayo hufanya kitu sawa na uthibitishaji wa utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Mtihani ulioboreshwa wa ASCII ambao utatumia shughuli za kutumia-kwa-wakati badala ya shughuli za wakati-wa-wakati (inapowezekana).
///
/// Algorithm tunayotumia hapa ni rahisi sana.Ikiwa `s` ni fupi sana, tunaangalia tu kila kitu na tufanye nayo.Vinginevyo:
///
/// - Soma neno la kwanza na mzigo ambao haujasawazishwa.
/// - Panga pointer, soma maneno yafuatayo hadi mwisho na mizigo iliyokaa.
/// - Soma `usize` ya mwisho kutoka `s` na mzigo ambao haujasawazishwa.
///
/// Ikiwa yoyote ya mizigo hii inazalisha kitu ambacho `contains_nonascii` (above) inarudi kweli, basi tunajua jibu ni la uwongo.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ikiwa hatungepata chochote kutoka kwa utekelezaji wa neno kwa wakati, rudi kwenye kitanzi cha scalar.
    //
    // Tunafanya pia hii kwa usanifu ambapo `size_of::<usize>()` haitoshi mpangilio wa `usize`, kwa sababu ni kesi ya ajabu ya edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Tunasoma kila wakati neno la kwanza lisilo na saini, ambayo inamaanisha `align_offset` ni
    // 0, tungesoma tena thamani ile ile kwa kusoma iliyokaa sawa.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // USALAMA: Tunathibitisha `len < USIZE_SIZE` hapo juu.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Tuliangalia hii hapo juu, kabisa.
    // Kumbuka kuwa `offset_to_aligned` ni `align_offset` au `USIZE_SIZE`, zote mbili zimeangaziwa wazi hapo juu.
    //
    debug_assert!(offset_to_aligned <= len);

    // USALAMA: word_ptr ni (iliyokaa vizuri) usize ptr tunayotumia kusoma
    // kipande cha kati cha kipande.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ni faharisi ya baiti ya `word_ptr`, inayotumika kwa hundi za mwisho wa kitanzi.
    let mut byte_pos = offset_to_aligned;

    // Paranoia angalia juu ya mpangilio, kwani tunakaribia kufanya rundo la mizigo isiyo na usawa.
    // Kwa mazoezi hii haiwezekani kuzuia mdudu katika `align_offset` ingawa.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Soma maneno yafuatayo mpaka neno la mwisho lililopangiliwa, ukiondoa neno la mwisho lililopangiliwa yenyewe kufanywa katika kuangalia mkia baadaye, kuhakikisha kuwa mkia daima ni `usize` zaidi kwa branch `byte_pos == len` ya ziada.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Usafi angalia kwamba usomaji uko katika mipaka
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Na kwamba mawazo yetu kuhusu `byte_pos` yanashikilia.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // USALAMA: Tunajua `word_ptr` imewekwa sawa (kwa sababu ya
        // `align_offset`), na tunajua kuwa tuna kaa za kutosha kati ya `word_ptr` na mwisho
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // USALAMA: Tunajua hiyo `byte_pos <= len - USIZE_SIZE`, ambayo inamaanisha hiyo
        // baada ya hii `add`, `word_ptr` itakuwa zaidi ya moja-iliyopita-mwisho.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Ukaguzi wa usafi ili kuhakikisha kuna `usize` moja tu iliyobaki.
    // Hii inapaswa kuhakikishiwa na hali yetu ya kitanzi.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // USALAMA: Hii inategemea `len >= USIZE_SIZE`, ambayo tunaangalia mwanzoni.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}