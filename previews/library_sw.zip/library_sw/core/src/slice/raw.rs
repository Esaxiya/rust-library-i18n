//! Kazi za bure kuunda `&[T]` na `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Inaunda kipande kutoka kwa pointer na urefu.
///
/// Hoja ya `len` ni idadi ya vitu **, sio idadi ya ka.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `data` lazima iwe [valid] kwa kusoma kwa `len * mem::size_of::<T>()` ka nyingi, na lazima iwe iliyokaa sawa.Hii inamaanisha haswa:
///
///     * Upeo mzima wa kumbukumbu ya kipande hiki lazima iwe ndani ya kitu kimoja kilichotengwa!
///       Vipande haviwezi kupita kwenye vitu vingi vilivyotengwa.Tazama [below](#incorrect-usage) kwa mfano bila kuzingatia hii.
///     * `data` lazima ziwe batili na zilinganishwe hata kwa vipande vya urefu wa sifuri.
///     Sababu moja ya hii ni kwamba uboreshaji wa mpangilio wa enum unaweza kutegemea marejeleo (pamoja na vipande vya urefu wowote) zikiwa zimepangiliwa na zisizo za kutofautisha kuzitofautisha na data zingine.
///     Unaweza kupata pointer inayoweza kutumika kama `data` kwa vipande vya urefu wa sifuri ukitumia [`NonNull::dangling()`].
///
/// * `data` lazima ielekeze kwa `len` mfululizo zilizoorodheshwa vyema za aina ya `T`.
///
/// * Kumbukumbu iliyorejelewa na kipande kilichorudishwa haipaswi kugeuzwa kwa muda wa maisha `'a`, isipokuwa ndani ya `UnsafeCell`.
///
/// * Ukubwa wa jumla ya kipande `len * mem::size_of::<T>()` lazima isiwe kubwa kuliko `isize::MAX`.
///   Tazama nyaraka za usalama za [`pointer::offset`].
///
/// # Caveat
///
/// Maisha ya kipande kilichorudishwa yanatokana na matumizi yake.
/// Ili kuzuia matumizi mabaya ya bahati mbaya, inashauriwa kufunga maisha kwa chanzo chochote cha maisha kilicho salama katika muktadha, kama vile kwa kutoa kazi ya msaidizi kuchukua maisha ya thamani ya mwenyeji kwa kipande, au kwa ufafanuzi wazi.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // onyesha kipande kwa kipengee kimoja
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Matumizi yasiyo sahihi
///
/// Kazi ifuatayo ya `join_slices` ni **haijulikani** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Madai hapo juu inahakikisha `fst` na `snd` zinahusiana, lakini bado zinaweza kuwa ndani ya _different allocated objects_, kwa hali hiyo kuunda kipande hiki sio tabia isiyojulikana.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` na `b` ni vitu tofauti vilivyotengwa ...
///     let a = 42;
///     let b = 27;
///     // ... ambayo hata hivyo inaweza kuwekwa kwa kushangaza kwa kumbukumbu: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Inafanya utendaji sawa na [`from_raw_parts`], isipokuwa kwamba kipande kinachoweza kubadilishwa kinarudishwa.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `data` lazima iwe [valid] kwa wasomaji wote na inaandika kwa `len * mem::size_of::<T>()` ka nyingi, na lazima iwe iliyokaa sawa.Hii inamaanisha haswa:
///
///     * Upeo mzima wa kumbukumbu ya kipande hiki lazima iwe ndani ya kitu kimoja kilichotengwa!
///       Vipande haviwezi kupita kwenye vitu vingi vilivyotengwa.
///     * `data` lazima ziwe batili na zilinganishwe hata kwa vipande vya urefu wa sifuri.
///     Sababu moja ya hii ni kwamba uboreshaji wa mpangilio wa enum unaweza kutegemea marejeleo (pamoja na vipande vya urefu wowote) zikiwa zimepangiliwa na zisizo za kutofautisha kuzitofautisha na data zingine.
///
///     Unaweza kupata pointer inayoweza kutumika kama `data` kwa vipande vya urefu wa sifuri ukitumia [`NonNull::dangling()`].
///
/// * `data` lazima ielekeze kwa `len` mfululizo zilizoorodheshwa vyema za aina ya `T`.
///
/// * Kumbukumbu iliyorejelewa na kipande kilichorudishwa haipaswi kupatikana kupitia kiashiria kingine chochote (kisichotokana na thamani ya kurudi) kwa muda wa maisha ya `'a`.
///   Ufikiaji wote wa kusoma na kuandika ni marufuku.
///
/// * Ukubwa wa jumla ya kipande `len * mem::size_of::<T>()` lazima isiwe kubwa kuliko `isize::MAX`.
///   Tazama nyaraka za usalama za [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Inabadilisha rejeleo la T kuwa kipande cha urefu 1 (bila kunakili).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Inabadilisha rejeleo la T kuwa kipande cha urefu 1 (bila kunakili).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}