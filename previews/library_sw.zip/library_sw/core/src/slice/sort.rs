//! Kupanga kipande
//!
//! Moduli hii ina upangaji wa hesabu kulingana na muundo wa haraka wa Orson Peters, iliyochapishwa kwa: <https://github.com/orlp/pdqsort>
//!
//!
//! Upangaji thabiti unaambatana na libcore kwa sababu haitoi kumbukumbu, tofauti na utekelezaji wetu thabiti wa upangaji.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Wakati imeshuka, nakala kutoka `src` hadi `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // USALAMA: Hili ni darasa la wasaidizi.
        //          Tafadhali rejelea matumizi yake kwa usahihi.
        //          Kwa hivyo, mtu lazima ahakikishe kuwa `src` na `dst` haziingiliani kama inavyotakiwa na `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Huhamisha kipengee cha kwanza kulia hadi kitakapopata kitu kikubwa au sawa.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // USALAMA: Shughuli zisizo salama hapa chini zinajumuisha kuorodhesha bila hundi iliyofungwa (`get_unchecked` na `get_unchecked_mut`)
    // na kunakili kumbukumbu (`ptr::copy_nonoverlapping`).
    //
    // a.Kuorodhesha:
    //  1. Tuliangalia saizi ya safu hadi>=2.
    //  2. Uorodheshaji wote ambao tutafanya ni kati ya {0 <= index < len} wakati wote.
    //
    // b.Kuiga kumbukumbu
    //  1. Tunapata viashiria vya marejeleo ambayo yamehakikishiwa kuwa halali.
    //  2. Hawawezi kuingiliana kwa sababu tunapata viashiria kwa fahirisi tofauti za kipande.
    //     Yaani, `i` na `i-1`.
    //  3. Ikiwa kipande kimewekwa sawa, vitu vimewekwa sawa.
    //     Ni jukumu la mpigaji kuhakikisha kipande kimesawazishwa vizuri.
    //
    // Tazama maoni hapa chini kwa undani zaidi.
    unsafe {
        // Ikiwa vitu viwili vya kwanza vimepitwa na wakati ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Soma kipengee cha kwanza katika ubadilishaji uliotengwa wa stack.
            // Ikiwa operesheni ifuatayo ya kulinganisha panics, `hole` itashuka na kuandika kiotomatiki kipengee hicho kwenye kipande.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Sogeza `i`-th sehemu moja kwenda kushoto, na hivyo kuhama shimo kulia.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` inashuka na hivyo kunakili `tmp` kwenye shimo lililobaki katika `v`.
        }
    }
}

/// Huhamisha kipengee cha mwisho kushoto hadi kitakapopata kitu kidogo au sawa.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // USALAMA: Shughuli zisizo salama hapa chini zinajumuisha kuorodhesha bila hundi iliyofungwa (`get_unchecked` na `get_unchecked_mut`)
    // na kunakili kumbukumbu (`ptr::copy_nonoverlapping`).
    //
    // a.Kuorodhesha:
    //  1. Tuliangalia saizi ya safu hadi>=2.
    //  2. Uorodheshaji wote ambao tutafanya ni kati ya `0 <= index < len-1` wakati wote.
    //
    // b.Kuiga kumbukumbu
    //  1. Tunapata viashiria vya marejeleo ambayo yamehakikishiwa kuwa halali.
    //  2. Hawawezi kuingiliana kwa sababu tunapata viashiria kwa fahirisi tofauti za kipande.
    //     Yaani, `i` na `i+1`.
    //  3. Ikiwa kipande kimewekwa sawa, vitu vimewekwa sawa.
    //     Ni jukumu la mpigaji kuhakikisha kipande kimesawazishwa vizuri.
    //
    // Tazama maoni hapa chini kwa undani zaidi.
    unsafe {
        // Ikiwa vitu viwili vya mwisho viko nje ya mpangilio ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Soma kipengee cha mwisho katika ubadilishaji uliotengwa wa stack.
            // Ikiwa operesheni ifuatayo ya kulinganisha panics, `hole` itashuka na kuandika kiotomatiki kipengee hicho kwenye kipande.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Sogeza `i`-th sehemu moja kwenda kulia, na hivyo kuhamisha shimo kushoto.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` inashuka na hivyo kunakili `tmp` kwenye shimo lililobaki katika `v`.
        }
    }
}

/// Panga sehemu kidogo kwa kuhamisha vitu kadhaa vya kuagiza nje.
///
/// Hurejesha `true` ikiwa kipande kimepangwa mwishoni.Kazi hii ni mbaya zaidi *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Idadi ya juu ya jozi za nje za mpangilio ambazo zitabadilishwa.
    const MAX_STEPS: usize = 5;
    // Ikiwa kipande ni kifupi kuliko hiki, usibadilishe vitu vyovyote.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // USALAMA: Tayari tulifanya uchunguzi wazi na `i < len`.
        // Uorodheshaji wetu wote unaofuata uko katika anuwai ya `0 <= index < len` tu
        unsafe {
            // Pata jozi inayofuata ya vitu vya nje vya agizo.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Tumeisha?
        if i == len {
            return true;
        }

        // Usibadilishe vitu kwa safu fupi, ambayo ina gharama ya utendaji.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Badilisha vitu vilivyopatikana.Hii inawaweka kwa mpangilio sahihi.
        v.swap(i - 1, i);

        // Hamisha kipengee kidogo kushoto.
        shift_tail(&mut v[..i], is_less);
        // Hamisha kipengee kikubwa kulia.
        shift_head(&mut v[i..], is_less);
    }

    // Haikufanikiwa kupanga kipande katika idadi ndogo ya hatua.
    false
}

/// Hupanga kipande kwa kutumia aina ya kuingizwa, ambayo ni mbaya zaidi *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Aina ya `v` kutumia heapsort, ambayo inahakikishia hali mbaya ya O *(* n *\* log(*n*)).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lundo hili la binary linaheshimu `parent >= child` isiyobadilika.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Watoto wa `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Chagua mtoto mkubwa.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Acha ikiwa mvamizi anashikilia saa `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Badilisha `node` na mtoto mkubwa, songa hatua moja chini, na uendelee kuchuja.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Jenga chungu kwa wakati unaofaa.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Tengeneza vitu vya juu kutoka kwa lundo.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Vizuizi `v` kuwa vitu vidogo kuliko `pivot`, ikifuatiwa na vitu vikubwa kuliko au sawa na `pivot`.
///
///
/// Hurejesha idadi ya vipengee vidogo kuliko `pivot`.
///
/// Kugawanya hufanywa block-by-block ili kupunguza gharama za shughuli za matawi.
/// Wazo hili linawasilishwa kwenye karatasi ya [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Idadi ya vitu kwenye kizuizi cha kawaida.
    const BLOCK: usize = 128;

    // Algorithm ya kugawanya inarudia hatua zifuatazo hadi kukamilika:
    //
    // 1. Fuatilia kizuizi kutoka upande wa kushoto ili utambue vitu kubwa kuliko au sawa na pivot.
    // 2. Fuatilia kizuizi kutoka upande wa kulia ili utambue vitu vidogo kuliko kiini.
    // 3. Badilisha vitu vilivyotambuliwa kati ya upande wa kushoto na kulia.
    //
    // Tunaweka vigezo vifuatavyo kwa kizuizi cha vitu:
    //
    // 1. `block` - Idadi ya vitu kwenye block.
    // 2. `start` - Anza pointer katika safu ya `offsets`.
    // 3. `end` - Ender pointer katika safu ya `offsets`.
    // 4. `ofa, fahirisi za vitu vya nje vya agizo ndani ya kizuizi.

    // Kizuizi cha sasa upande wa kushoto (kutoka `l` hadi `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Kizuizi cha sasa upande wa kulia (kutoka `r.sub(block_r)` to `r`).
    // USALAMA: Hati za .add() zinataja haswa kuwa `vec.as_ptr().add(vec.len())` ni salama kila wakati`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Tunapopata VLAs, jaribu kuunda safu moja ya urefu `min(v.len(), 2 * BLOCK) `badala
    // kuliko safu mbili za saizi ya urefu wa `BLOCK`.VLA zinaweza kuwa na ufanisi zaidi wa cache.

    // Hurejesha idadi ya vipengee kati ya viashiria `l` (inclusive) na `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Tumemaliza kwa kugawanya block-by-block wakati `l` na `r` wanapokaribia sana.
        // Kisha tunafanya kazi ya kiraka ili kugawanya vitu vilivyobaki katikati.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Idadi ya vipengee vilivyobaki (bado havijalinganishwa na kiunzi).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Rekebisha ukubwa wa vizuizi ili kizuizi cha kushoto na kulia kisipishana, lakini sanjari kikamilifu kufunika pengo lote lililobaki.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Fuatilia vitu vya `block_l` kutoka upande wa kushoto.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // USALAMA: Shughuli zisizo za usalama hapa chini zinahusisha utumiaji wa `offset`.
                //         Kulingana na hali zinazohitajika na kazi hiyo, tunawaridhisha kwa sababu:
                //         1. `offsets_l` imetengwa kwa stack, na kwa hivyo inachukuliwa kuwa kitu kilichotengwa tofauti.
                //         2. Kazi `is_less` inarudi `bool`.
                //            Kutupa `bool` hakutawahi kufurika `isize`.
                //         3. Tumehakikishia kuwa `block_l` itakuwa `<= BLOCK`.
                //            Pamoja, `end_l` hapo awali iliwekwa kwa pointer ya kuanza ya `offsets_` ambayo ilitangazwa kwenye stack.
                //            Kwa hivyo, tunajua kwamba hata katika hali mbaya zaidi (dua zote za `is_less` zinarudi kwa uwongo) tutakuwa tu kwa byte 1 kupita mwisho.
                //        Operesheni nyingine isiyo salama hapa ni kutofautisha `elem`.
                //        Walakini, `elem` mwanzoni ilikuwa kiashiria cha kuanza kwa kipande ambacho ni halali kila wakati.
                unsafe {
                    // Ulinganisho usio na tawi.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Fuatilia vitu vya `block_r` kutoka upande wa kulia.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // USALAMA: Shughuli zisizo za usalama hapa chini zinahusisha utumiaji wa `offset`.
                //         Kulingana na hali zinazohitajika na kazi hiyo, tunawaridhisha kwa sababu:
                //         1. `offsets_r` imetengwa kwa stack, na kwa hivyo inachukuliwa kuwa kitu kilichotengwa tofauti.
                //         2. Kazi `is_less` inarudi `bool`.
                //            Kutupa `bool` hakutawahi kufurika `isize`.
                //         3. Tumehakikishia kuwa `block_r` itakuwa `<= BLOCK`.
                //            Pamoja, `end_r` hapo awali iliwekwa kwa pointer ya kuanza ya `offsets_` ambayo ilitangazwa kwenye stack.
                //            Kwa hivyo, tunajua kwamba hata katika hali mbaya zaidi (dua zote za `is_less` zinarudi kweli) tutakuwa tu byte 1 tu tutapita mwisho.
                //        Operesheni nyingine isiyo salama hapa ni kutofautisha `elem`.
                //        Walakini, `elem` mwanzoni ilikuwa `1 *sizeof(T)` kupita mwisho na tunaipunguza kwa `1* sizeof(T)` kabla ya kuipata.
                //        Pamoja, `block_r` ilisisitizwa kuwa chini ya `BLOCK` na `elem` kwa hivyo itakuwa ikiashiria mwanzo wa kipande.
                unsafe {
                    // Ulinganisho usio na tawi.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Idadi ya vipengee vya nje vya mpangilio vya kubadilishana kati ya upande wa kushoto na kulia.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Badala ya kubadilisha jozi moja kwa wakati, ni bora kufanya ruhusa ya mzunguko.
            // Hii sio sawa na ubadilishaji, lakini hutoa matokeo sawa kwa kutumia shughuli chache za kumbukumbu.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Vipengee vyote vya nje vya mpangilio kwenye kizuizi cha kushoto vilihamishwa.Nenda kwenye kizuizi kinachofuata.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Vipengee vyote vya nje ya mpangilio kwenye kizuizi cha kulia vilihamishwa.Nenda kwenye kizuizi kilichopita.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Kilichobaki sasa ni kwenye kizuizi kimoja (ama kushoto au kulia) na vitu vya nje vya mpangilio ambavyo vinahitaji kuhamishwa.
    // Vipengee vile vilivyobaki vinaweza kuhamishwa hadi mwisho ndani ya kizuizi chao.
    //

    if start_l < end_l {
        // Kizuizi cha kushoto kinabaki.
        // Sogeza vipengee vyake vilivyobaki nje ya agizo kulia zaidi.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Kizuizi cha kulia kinabaki.
        // Sogeza vipengee vyake vya nje vya mpangilio kushoto kushoto.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Hakuna kitu kingine cha kufanya, tumemaliza.
        width(v.as_mut_ptr(), l)
    }
}

/// Vizuizi `v` kuwa vitu vidogo kuliko `v[pivot]`, ikifuatiwa na vitu vikubwa kuliko au sawa na `v[pivot]`.
///
///
/// Hurejesha Tuple ya:
///
/// 1. Idadi ya vitu vidogo kuliko `v[pivot]`.
/// 2. Kweli ikiwa `v` ilikuwa tayari imegawanywa.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Weka pivot mwanzoni mwa kipande.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Soma pivot katika ubadilishaji uliotengwa kwa stack kwa ufanisi.
        // Ikiwa operesheni ifuatayo ya kulinganisha panics, pivot itaandikwa moja kwa moja kwenye kipande.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Pata jozi ya kwanza ya vitu vya nje vya agizo.
        let mut l = 0;
        let mut r = v.len();

        // USALAMA: Ukosefu wa usalama hapa chini unajumuisha kuorodhesha safu.
        // Kwa ya kwanza: Tayari tunafanya mipaka kuangalia hapa na `l < r`.
        // Kwa moja ya pili: Mwanzoni tuna `l == 0` na `r == v.len()` na tuliangalia hiyo `l < r` katika kila operesheni ya kuorodhesha.
        //                     Kutoka hapa tunajua kwamba `r` lazima iwe angalau `r == l` ambayo ilionyeshwa kuwa halali kutoka kwa ile ya kwanza.
        unsafe {
            // Pata kipengee cha kwanza kuliko au pivot sawa.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Pata kipengee cha mwisho kidogo kuwa kiini.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` huenda nje ya wigo na anaandika pivot (ambayo ni tofauti iliyotengwa kwa stack) kurudi kwenye kipande ambapo hapo awali ilikuwa.
        // Hatua hii ni muhimu katika kuhakikisha usalama!
        //
    };

    // Weka kitovu kati ya sehemu mbili.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Vizuizi `v` kuwa vitu sawa na `v[pivot]` ikifuatiwa na vitu vikubwa kuliko `v[pivot]`.
///
/// Hurejesha idadi ya vipengee sawa na kiunzi.
/// Inachukuliwa kuwa `v` haina vitu vidogo kuliko pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Weka pivot mwanzoni mwa kipande.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Soma pivot katika ubadilishaji uliotengwa kwa stack kwa ufanisi.
    // Ikiwa operesheni ifuatayo ya kulinganisha panics, pivot itaandikwa moja kwa moja kwenye kipande.
    // USALAMA: Kiashiria hapa ni halali kwa sababu kinapatikana kutoka kwa kumbukumbu ya kipande.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Sasa kizigeu kipande.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // USALAMA: Ukosefu wa usalama hapa chini unajumuisha kuorodhesha safu.
        // Kwa ya kwanza: Tayari tunafanya mipaka kuangalia hapa na `l < r`.
        // Kwa moja ya pili: Mwanzoni tuna `l == 0` na `r == v.len()` na tuliangalia hiyo `l < r` katika kila operesheni ya kuorodhesha.
        //                     Kutoka hapa tunajua kwamba `r` lazima iwe angalau `r == l` ambayo ilionyeshwa kuwa halali kutoka kwa ile ya kwanza.
        unsafe {
            // Pata kipengee cha kwanza kikubwa kuliko kiini.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Pata kipengee cha mwisho sawa na pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Tumeisha?
            if l >= r {
                break;
            }

            // Badili jozi zilizopatikana za vitu vya nje vya agizo.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Tulipata vitu `l` sawa na pivot.Ongeza 1 kwa akaunti ya pivot yenyewe.
    l + 1

    // `_pivot_guard` huenda nje ya wigo na anaandika pivot (ambayo ni tofauti iliyotengwa kwa stack) kurudi kwenye kipande ambapo hapo awali ilikuwa.
    // Hatua hii ni muhimu katika kuhakikisha usalama!
}

/// Inatawanya vitu kadhaa kuzunguka kwa jaribio la kuvunja mifumo ambayo inaweza kusababisha vizuizi visivyo na usawa katika upesi wa haraka.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Jenereta ya nambari bandia kutoka kwa karatasi ya "Xorshift RNGs" na George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Chukua nambari za nasibu modulo nambari hii.
        // Nambari inatoshea `usize` kwa sababu `len` sio kubwa kuliko `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Wagombea wengine wa pivot watakuwa karibu na faharisi hii.Wacha tuwape bahati mbaya.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Tengeneza moduli ya nambari isiyo ya kawaida moduli `len`.
            // Walakini, ili kuepusha shughuli za gharama kubwa kwanza tunachukua modulo nguvu ya mbili, halafu hupungua kwa `len` hadi itoshe kwenye masafa ya `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` imehakikishiwa kuwa chini ya `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Inachagua pivot katika `v` na kurudisha faharisi na `true` ikiwa kipande tayari kimeshapangwa.
///
/// Vipengele katika `v` vinaweza kujipanga upya katika mchakato.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Urefu wa chini kuchagua njia ya wastani ya kati.
    // Vipande vifupi hutumia njia rahisi ya wastani ya tatu.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Idadi kubwa ya ubadilishaji ambao unaweza kufanywa katika kazi hii.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Fahirisi tatu karibu na ambazo tutachagua kitovu.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Huhesabu jumla ya swaps ambazo tunakaribia kutekeleza wakati wa kupanga fahirisi.
    let mut swaps = 0;

    if len >= 8 {
        // Badilishana fahirisi ili `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Badilishana fahirisi ili `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Inapata wastani wa `v[a - 1], v[a], v[a + 1]` na huhifadhi faharisi kwenye `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Pata wapatanishi katika vitongoji vya `a`, `b`, na `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Pata wastani kati ya `a`, `b`, na `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Idadi kubwa ya swaps ilifanywa.
        // Nafasi ni kwamba kipande kinashuka au kinashuka zaidi, kwa hivyo kurudisha nyuma labda itasaidia kuipanga haraka.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Aina ya `v` mara kwa mara.
///
/// Ikiwa kipande kilikuwa na mtangulizi katika safu ya asili, imeainishwa kama `pred`.
///
/// `limit` ni idadi ya vizuizi visivyo na usawa kabla ya kubadili `heapsort`.
/// Ikiwa sifuri, kazi hii itabadilika kuwa heapsort mara moja.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Vipande vya hadi urefu huu hupangwa kwa kutumia aina ya kuingizwa.
    const MAX_INSERTION: usize = 20;

    // Ukweli ikiwa sehemu ya mwisho ilikuwa sawa.
    let mut was_balanced = true;
    // Ukweli ikiwa sehemu ya mwisho haikuchanganya vitu (kipande kilikuwa kimegawanywa tayari).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Vipande vifupi sana hupangwa kwa kutumia aina ya kuingizwa.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ikiwa chaguzi nyingi mbaya za pivot zilifanywa, rudi kwa kifurushi ili kuhakikisha kesi mbaya ya `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ikiwa ugawaji wa mwisho haukuwa na usawa, jaribu kuvunja mifumo kwenye kipande kwa kuchanganya vitu kadhaa karibu.
        // Tunatumahi kuwa tutachagua pivot bora wakati huu.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Chagua kitovu na jaribu kubahatisha ikiwa kipande tayari kimepangwa.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ikiwa ugawaji wa mwisho ulikuwa na usawa mzuri na haukubadilisha vitu, na ikiwa uteuzi wa pivot unatabiri kipande hicho tayari tayari kimepangwa ..
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Jaribu kutambua vipengee kadhaa vya nje ya mpangilio na kuzibadilisha kurekebisha nafasi.
            // Ikiwa kipande kinaishia kupangwa kabisa, tumemaliza.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ikiwa pivot iliyochaguliwa ni sawa na mtangulizi, basi ndio kipengee kidogo kabisa kwenye kipande.
        // Gawanya kipande katika vitu sawa na vipengee vikubwa kuliko kiini.
        // Kesi hii kawaida hupigwa wakati kipande kina vitu vingi vya nakala.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Endelea kupanga vipengee vikubwa kuliko kiini.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Kugawanya kipande.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Gawanya kipande ndani ya `left`, `pivot`, na `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Rejea kwa upande mfupi tu ili kupunguza idadi ya simu zinazojirudia na utumie nafasi ndogo ya kuweka.
        // Halafu endelea na upande mrefu zaidi (hii ni sawa na kurudia mkia).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Aina ya `v` kwa kutumia muundo wa haraka-kushinda, ambayo ni *O*(*n*\*log(* n*)) kesi mbaya.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kupanga hakuna tabia ya maana kwa aina za saizi.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Punguza idadi ya sehemu zisizo na usawa hadi `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kwa vipande vya hadi urefu huu labda ni haraka zaidi kuzipanga.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Chagua kitovu
        let (pivot, _) = choose_pivot(v, is_less);

        // Ikiwa pivot iliyochaguliwa ni sawa na mtangulizi, basi ndio kipengee kidogo kabisa kwenye kipande.
        // Gawanya kipande katika vitu sawa na vipengee vikubwa kuliko kiini.
        // Kesi hii kawaida hupigwa wakati kipande kina vitu vingi vya nakala.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ikiwa tumepitisha faharisi yetu, basi sisi ni wazuri.
                if mid > index {
                    return;
                }

                // Vinginevyo, endelea kuchagua vitu vikubwa kuliko kiini.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Gawanya kipande ndani ya `left`, `pivot`, na `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ikiwa mid==index, basi tumemaliza, kwani partition() imehakikisha kuwa vitu vyote baada ya katikati ni kubwa kuliko au sawa na katikati.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Kupanga hakuna tabia ya maana kwa aina za saizi.Usifanye chochote.
    } else if index == v.len() - 1 {
        // Pata kipengee cha juu na uweke katika nafasi ya mwisho ya safu.
        // Tuko huru kutumia `unwrap()` hapa kwa sababu tunajua v haipaswi kuwa tupu.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Pata kitu cha min na uiweke katika nafasi ya kwanza ya safu.
        // Tuko huru kutumia `unwrap()` hapa kwa sababu tunajua v haipaswi kuwa tupu.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}