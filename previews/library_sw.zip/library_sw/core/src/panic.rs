//! Panic inasaidia katika maktaba ya kawaida.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Muundo unaotoa habari kuhusu panic.
///
/// `PanicInfo` muundo hupitishwa kwa panic hook iliyowekwa na kazi ya [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Hurejesha mzigo unaolipwa unaohusishwa na panic.
    ///
    /// Hii kawaida, lakini sio kila wakati, itakuwa `&'static str` au [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Ikiwa jumla ya `panic!` kutoka `core` crate (sio kutoka `std`) ilitumika na fomati ya muundo na hoja zingine za ziada, inarudisha ujumbe huo tayari kutumika kwa mfano na [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Hurejesha habari kuhusu eneo ambalo panic ilitokea, ikiwa inapatikana.
    ///
    /// Njia hii kwa sasa itarudisha [`Some`], lakini hii inaweza kubadilika katika matoleo ya future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Ikiwa hii imebadilishwa na wakati mwingine kurudi Hakuna,
        // shughulikia kesi hiyo katika std::panicking::default_hook na std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: hatuwezi kutumia downcast_ref: :<String>() hapa
        // kwani Kamba haipatikani kwa libcore!
        // Mshahara ni Kamba wakati `std::panic!` inaitwa na hoja nyingi, lakini kwa hali hiyo ujumbe pia unapatikana.
        //

        self.location.fmt(formatter)
    }
}

/// Muundo ulio na habari kuhusu eneo la panic.
///
/// Muundo huu umeundwa na [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Ulinganisho wa usawa na kuagiza hufanywa katika faili, laini, halafu kipaumbele cha safu.
/// Faili zinalinganishwa kama nyuzi, sio `Path`, ambayo inaweza kuwa isiyotarajiwa.
/// Tazama nyaraka za [`Location: : file`] kwa majadiliano zaidi.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Hurejesha eneo la chanzo la anayepiga kazi hii.
    /// Ikiwa mpigaji wa kazi hiyo ameelezewa basi eneo lake la simu litarudishwa, na kadhalika juu ya mkusanyiko hadi simu ya kwanza ndani ya mwili wa kazi ambao haufuatiliwi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Hurejesha [`Location`] ambayo inaitwa.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Hurejesha [`Location`] kutoka ndani ya ufafanuzi wa kazi hii.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // kuendesha kazi sawa isiyofunguliwa katika eneo tofauti hutupa matokeo sawa
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // kuendesha kazi inayofuatiliwa katika eneo tofauti hutoa thamani tofauti
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Hurejesha jina la faili chanzo ambayo panic ilitokea.
    ///
    /// # `&str`, sio `&Path`
    ///
    /// Jina lililorejeshwa linarejelea njia chanzo kwenye mfumo wa kukusanya, lakini sio halali kuwakilisha hii moja kwa moja kama `&Path`.
    /// Nambari iliyokusanywa inaweza kutumika kwenye mfumo tofauti na utekelezaji tofauti wa `Path` kuliko mfumo unaotoa yaliyomo na maktaba hii kwa sasa haina aina tofauti ya "host path".
    ///
    /// Tabia ya kushangaza zaidi hufanyika wakati faili ya "the same" inapatikana kupitia njia nyingi kwenye mfumo wa moduli (kawaida hutumia sifa ya `#[path = "..."]` au sawa), ambayo inaweza kusababisha kile kinachoonekana kuwa nambari inayofanana kurudisha maadili tofauti kutoka kwa kazi hii.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Thamani hii haifai kupitisha `Path::new` au waundaji sawa wakati jukwaa la mwenyeji na jukwaa lengwa linatofautiana.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Hurejesha nambari ya laini ambayo panic ilitokea.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Hurejesha safu wima ambayo panic ilitokea.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait ya ndani inayotumiwa na libstd kupitisha data kutoka libstd hadi `panic_unwind` na wakati mwingine wa kukimbia wa panic.
/// Haikusudiwi kutuliza wakati wowote hivi karibuni, usitumie.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Chukua umiliki kamili wa yaliyomo.
    /// Aina ya kurudi ni `Box<dyn Any + Send>`, lakini hatuwezi kutumia `Box` kwa libcore.
    ///
    /// Baada ya njia hii kuitwa, ni idadi ndogo tu ya dummy iliyobaki katika `self`.
    /// Kuita njia hii mara mbili, au kupiga simu `get` baada ya kuita njia hii, ni kosa.
    ///
    /// Hoja imekopwa kwa sababu wakati wa kukimbia wa panic (`__rust_start_panic`) hupata tu `dyn BoxMeUp` iliyokopwa.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Tu kukopa yaliyomo.
    fn get(&mut self) -> &(dyn Any + Send);
}