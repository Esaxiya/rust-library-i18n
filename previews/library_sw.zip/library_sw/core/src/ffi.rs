#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Huduma zinazohusiana na kiunga cha kazi ya kigeni vifungo vya (FFI).

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Sawa na aina ya C ya `void` wakati inatumiwa kama [pointer].
///
/// Kwa asili, `*const c_void` ni sawa na C's `const void*` na `*mut c_void` ni sawa na X's `void*`.
/// Hiyo ilisema, hii sio * sawa na aina ya C ya `void` ya kurudi, ambayo ni aina ya Rust ya `()`.
///
/// Ili kuonyesha viashiria kwa aina za opaque kwenye FFI, hadi `extern type` itakapotengezwa, inashauriwa kutumia kanga ya newtype karibu na safu tupu ya baiti.
///
/// Tazama [Nomicon] kwa maelezo.
///
/// Mtu anaweza kutumia `std::os::raw::c_void` ikiwa wanataka kuunga mkono mkusanyaji wa zamani wa Rust hadi 1.1.0.
/// Baada ya Rust 1.30.0, ilisafirishwa tena na ufafanuzi huu.
/// Kwa habari zaidi, tafadhali soma [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, kwa LLVM kutambua aina ya pointer batili na kwa kazi za ugani kama malloc(), tunahitaji kuwa na uwakilishi kama i8 * katika bitcode ya LLVM.
// Enum iliyotumiwa hapa inahakikisha hii na kuzuia matumizi mabaya ya aina ya "raw" kwa kuwa na anuwai za kibinafsi tu.
// Tunahitaji anuwai mbili, kwa sababu mkusanyaji analalamika juu ya sifa ya repr vinginevyo na tunahitaji angalau lahaja moja kwani vinginevyo enum haitakuwa na watu na angalau kutofautisha viashiria vile itakuwa UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Utekelezaji wa kimsingi wa `va_list`.
// Jina ni WIP, kwa kutumia `VaListImpl` kwa sasa.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant juu ya `'f`, kwa hivyo kila kitu cha `VaListImpl<'f>` kimefungwa kwa mkoa wa kazi ambayo inaelezewa ndani
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Utekelezaji wa ABI wa `va_list`.
/// Tazama [AArch64 Procedure Call Standard] kwa maelezo zaidi.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Utekelezaji wa ABI wa `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Utekelezaji wa ABI wa `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Kifuniko cha `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Badilisha `VaListImpl` kuwa `VaList` ambayo inaambatana na binary ya X's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Badilisha `VaListImpl` kuwa `VaList` ambayo inaambatana na binary ya X's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait inahitaji kutumika katika njia za umma, hata hivyo, trait yenyewe haipaswi kuruhusiwa kutumika nje ya moduli hii.
// Kuruhusu watumiaji kutekeleza trait kwa aina mpya (na hivyo kuruhusu asili ya va_arg kutumika kwa aina mpya) kunaweza kusababisha tabia isiyojulikana.
//
// FIXME(dlrobertson): Ili kutumia VaArgSafe trait katika kiolesura cha umma lakini pia uhakikishe kuwa haiwezi kutumika mahali pengine, trait inahitaji kuwa ya umma ndani ya moduli ya faragha.
// Mara baada ya RFC 2145 kutekelezwa angalia katika kuboresha hii.
//
//
//
//
mod sealed_trait {
    /// Trait ambayo inaruhusu aina zinazoruhusiwa kutumiwa na [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Mapema kwa hoja inayofuata.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Inakili `va_list` katika eneo la sasa.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // USALAMA: tunaandika kwa `MaybeUninit`, kwa hivyo imeanzishwa na `assume_init` ni halali
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: hii inapaswa kupiga `va_end`, lakini hakuna njia safi ya
        // hakikisha kwamba `drop` kila wakati huingizwa ndani ya mpigaji wake, kwa hivyo `va_end` itaitwa moja kwa moja kutoka kwa kazi sawa na `va_copy` inayofanana.
        // `man va_end` inasema kwamba C inahitaji hii, na LLVM kimsingi inafuata semantiki ya C, kwa hivyo tunahitaji kuhakikisha kuwa `va_end` inaitwa kila wakati kutoka kwa kazi sawa na `va_copy`.
        //
        // Kwa maelezo zaidi, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Hii inafanya kazi kwa sasa, kwani `va_end` haifanyi kazi kwenye malengo yote ya sasa ya LLVM.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Bomoa orodha ya hoja `ap` baada ya uanzishaji na `va_start` au `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Inakili eneo la sasa la orodha ya hoja `src` kwa orodha ya hoja `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Inapakia hoja ya aina `T` kutoka `va_list` `ap` na kuongeza hoja ya `ap` hadi.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}