#![stable(feature = "core_hint", since = "1.27.0")]

//! Vidokezo kwa mkusanyaji vinavyoathiri jinsi nambari inapaswa kutolewa au kuboreshwa.
//! Vidokezo vinaweza kuwa wakati wa kukusanya au wakati wa kukimbia.

use crate::intrinsics;

/// Inamjulisha mkusanyaji kwamba hatua hii katika nambari haipatikani, na kuwezesha uboreshaji zaidi.
///
/// # Safety
///
/// Kufikia kazi hii ni tabia isiyojulikana kabisa * (UB).Hasa, mkusanyaji anafikiria kuwa UB zote hazipaswi kutokea, na kwa hivyo itaondoa matawi yote ambayo hufikia simu kwa `unreachable_unchecked()`.
///
/// Kama visa vyote vya UB, ikiwa dhana hii inageuka kuwa mbaya, kwa mfano, simu ya `unreachable_unchecked()` inaweza kupatikana kati ya mtiririko wote wa kudhibiti, mkusanyaji atatumia mkakati wa utumiaji mbaya, na wakati mwingine inaweza hata kuharibu nambari inayoonekana haihusiani, na kusababisha ugumu-kusuluhisha shida.
///
///
/// Tumia kazi hii tu wakati unaweza kudhibitisha kuwa nambari hiyo haitaiita kamwe.
/// Vinginevyo, fikiria kutumia jumla ya [`unreachable!`], ambayo hairuhusu uboreshaji lakini itafanya panic inapotekelezwa.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` daima ni chanya (sio sifuri), kwa hivyo `checked_div` haitarudi `None` kamwe.
/////
///     // Kwa hivyo, branch nyingine haipatikani.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // USALAMA: mkataba wa usalama wa `intrinsics::unreachable` lazima
    // kushikiliwa na anayepiga.
    unsafe { intrinsics::unreachable() }
}

/// Inatoa maagizo ya mashine kuashiria processor kuwa inaendesha kitanzi cha kusubiri cha kusubiri ("spin lock").
///
/// Baada ya kupokea ishara ya kitanzi, processor inaweza kuboresha tabia yake kwa, kwa mfano, kuokoa nguvu au kubadili nyuzi za hyper.
///
/// Kazi hii ni tofauti na [`thread::yield_now`] ambayo hutoa moja kwa moja kwa mpangilio wa mfumo, wakati `spin_loop` haiingiliani na mfumo wa uendeshaji.
///
/// Kesi ya kawaida ya matumizi ya `spin_loop` inatekeleza kuzunguka kwa matumaini katika kitanzi cha CAS katika vitambulisho vya usawazishaji.
/// Ili kuepusha shida kama inversion ya kipaumbele, inashauriwa sana kwamba kitanzi cha spin kinakomeshwa baada ya idadi ndogo ya kurudiwa na syscall inayofaa ya kuzuia kufanywa.
///
///
/// **Kumbuka**: Kwenye majukwaa ambayo hayaungi mkono kupokea vidokezo vya kitanzi, kazi hii haifanyi chochote.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Thamani ya pamoja ya atomiki ambayo nyuzi zitatumia kuratibu
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Katika uzi wa nyuma tutakua tumeweka thamani
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Fanya kazi fulani, kisha fanya thamani iwe moja kwa moja
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Rudi kwenye uzi wetu wa sasa, tunasubiri thamani iwekwe
/// while !live.load(Ordering::Acquire) {
///     // Kitanzi cha kuzunguka ni dokezo kwa CPU ambayo tunasubiri, lakini labda sio kwa muda mrefu sana
/////
///     hint::spin_loop();
/// }
///
/// // Thamani sasa imewekwa
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // USALAMA: msaidizi wa `cfg` anahakikisha kwamba tunatekeleza hii tu kwa malengo ya x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // USALAMA: msaidizi wa `cfg` anahakikisha kwamba tunatekeleza hii tu kwa malengo ya x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // USALAMA: msaidizi wa `cfg` anahakikisha kwamba tunatekeleza hii tu kwa malengo ya aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // USALAMA: mvuto wa `cfg` anahakikisha kwamba tunatekeleza hii tu kwa malengo ya mkono
            // na msaada wa huduma ya v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Kazi ya kitambulisho ambayo *__ inadokeza __* kwa mkusanyaji kuwa na tumaini kubwa juu ya kile `black_box` inaweza kufanya.
///
/// Tofauti na [`std::convert::identity`], mkusanyaji wa Rust anahimizwa kudhani kuwa `black_box` inaweza kutumia `dummy` kwa njia yoyote halali inayowezekana kuwa nambari ya Rust bila kuanzisha tabia isiyojulikana katika nambari ya kupiga simu.
///
/// Mali hii hufanya `black_box` kuwa muhimu kwa kuandika nambari ambayo uboreshaji fulani hautakiwi, kama vile viashiria.
///
/// Kumbuka hata hivyo, kwamba `black_box` imetolewa tu (na inaweza kutolewa tu) kwa msingi wa "best-effort".Kiwango ambacho kinaweza kuzuia uboreshaji kinaweza kutofautiana kulingana na jukwaa na backend ya kanuni-gen iliyotumiwa.
/// Programu haziwezi kutegemea `black_box` kwa *usahihi* kwa njia yoyote.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Tunahitaji "use" hoja kwa njia fulani LLVM haiwezi kutazama, na kwa malengo yanayounga mkono tunaweza kupata mkutano wa ndani ili kufanya hivyo.
    // Tafsiri ya LLVM ya mkutano uliowekwa ndani ni kwamba, vizuri, sanduku jeusi.
    // Huu sio utekelezaji bora kwani labda inachukua zaidi ya tunavyotaka, lakini ni nzuri kwa sasa.
    //
    //

    #[cfg(not(miri))] // Hii ni dokezo tu, kwa hivyo ni vizuri kuruka huko Miri.
    // USALAMA: mkutano uliowekwa ndani haufanyi kazi.
    unsafe {
        // FIXME: Haiwezi kutumia `asm!` kwa sababu haitumii MIPS na usanifu mwingine.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}