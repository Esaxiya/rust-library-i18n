//! traits za zamani na aina zinazowakilisha mali ya msingi ya aina.
//!
//! Aina za Rust zinaweza kugawanywa kwa njia tofauti muhimu kulingana na mali zao za ndani.
//! Uainishaji huu unawakilishwa kama traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Aina ambazo zinaweza kuhamishiwa kwenye mipaka ya uzi.
///
/// trait hii inatekelezwa kiatomati wakati mkusanyaji anaamua inafaa.
///
/// Mfano wa aina isiyo ya `Tuma` ni kiashiria cha kuhesabu kumbukumbu [`rc::Rc`][`Rc`].
/// Ikiwa nyuzi mbili zinajaribu kushikilia [`Rc`] ambazo zinaelekeza kwa thamani ile ile iliyohesabiwa ya rejeleo, zinaweza kujaribu kusasisha hesabu ya kumbukumbu wakati huo huo, ambayo ni [undefined behavior][ub] kwa sababu [`Rc`] haitumii shughuli za atomiki.
///
/// Binamu yake [`sync::Arc`][arc] hutumia shughuli za atomiki (zinazoongoza juu) na kwa hivyo ni `Send`.
///
/// Tazama [the Nomicon](../../nomicon/send-and-sync.html) kwa maelezo zaidi.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Aina zilizo na saizi ya kawaida inayojulikana wakati wa kukusanya.
///
/// Vigezo vyote vya aina vina kifungo wazi cha `Sized`.Syntax maalum `?Sized` inaweza kutumika kuondoa kifungo hiki ikiwa haifai.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // muundo FooUse(Foo<[i32]>);//kosa: Ukubwa haujatekelezwa kwa [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Isipokuwa moja ni aina dhahiri ya `Self` ya trait.
/// trait haina `Sized` iliyofungwa kwani hii haiendani na [trait object] s ambapo, kwa ufafanuzi, trait inahitaji kufanya kazi na watekelezaji wote wanaowezekana, na kwa hivyo inaweza kuwa saizi yoyote.
///
///
/// Ingawa Rust itakuruhusu kumfunga `Sized` kwenye trait, hautaweza kuitumia kuunda kitu cha trait baadaye:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // hebu y: &dyn Bar= &Impl;//kosa: trait `Bar` haiwezi kufanywa kuwa kitu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // kwa chaguo-msingi, kwa mfano, ambayo inahitaji `[T]: !Default` itathminiwe
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Aina ambazo zinaweza kuwa "unsized" kwa aina ya ukubwa wa nguvu.
///
/// Kwa mfano, aina ya safu ya ukubwa `[i8; 2]` hutumia `Unsize<[i8]>` na `Unsize<dyn fmt::Debug>`.
///
/// Utekelezaji wote wa `Unsize` hutolewa moja kwa moja na mkusanyaji.
///
/// `Unsize` inatekelezwa kwa:
///
/// - `[T; N]` ni `Unsize<[T]>`
/// - `T` ni `Unsize<dyn Trait>` wakati `T: Trait`
/// - `Foo<..., T, ...>` ni `Unsize<Foo<..., U, ...>>` ikiwa:
///   - `T: Unsize<U>`
///   - Foo ni muundo
///   - Sehemu tu ya mwisho ya `Foo` ina aina inayojumuisha `T`
///   - `T` sio sehemu ya aina ya sehemu zingine zozote
///   - `Bar<T>: Unsize<Bar<U>>`, ikiwa uwanja wa mwisho wa `Foo` una aina `Bar<T>`
///
/// `Unsize` inatumika pamoja na [`ops::CoerceUnsized`] kuruhusu vyombo vya "user-defined" kama vile [`Rc`] kuwa na aina zenye ukubwa wa nguvu.
/// Tazama [DST coercion RFC][RFC982] na [the nomicon entry on coercion][nomicon-coerce] kwa maelezo zaidi.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Inahitajika trait kwa viboreshaji vinavyotumiwa katika mechi za muundo.
///
/// Aina yoyote ambayo hupata `PartialEq` hutumia moja kwa moja trait, * bila kujali ikiwa aina zake za vigezo zinatekeleza `Eq`.
///
/// Ikiwa kipengee cha `const` kina aina fulani ambayo haitekelezi trait, basi aina hiyo ama (1.) haitekelezi `PartialEq` (ambayo inamaanisha kuwa mara kwa mara haitatoa njia hiyo ya kulinganisha, ambayo kizazi cha nambari hufikiria inapatikana), au (2.) inatumia *yake* Toleo la `PartialEq` (ambalo tunachukulia halilingani na ulinganifu wa usawa wa kimuundo).
///
///
/// Katika mojawapo ya matukio mawili hapo juu, tunakataa utumiaji wa mara kwa mara kwenye mechi ya muundo.
///
/// Tazama pia [structural match RFC][RFC1445], na [issue 63438] ambayo ilichochea kuhamia kutoka kwa muundo wa msingi wa sifa kwenda kwa trait hii.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Inahitajika trait kwa viboreshaji vinavyotumiwa katika mechi za muundo.
///
/// Aina yoyote inayopata `Eq` hutumia moja kwa moja trait, * bila kujali ikiwa vigezo vya aina yake vinatumia `Eq`.
///
/// Huu ni utapeli wa kufanya kazi karibu na kiwango cha juu katika mfumo wa aina yetu.
///
/// # Background
///
/// Tunataka kuhitaji kwamba aina za consts zinazotumiwa katika mechi za muundo zina sifa `#[derive(PartialEq, Eq)]`.
///
/// Katika ulimwengu bora zaidi, tunaweza kuangalia hitaji hilo kwa kuangalia tu kwamba aina iliyopewa hutumia zote `StructuralPartialEq` trait *na*`Eq` trait.
/// Walakini, unaweza kuwa na ADTs ambazo *hufanya*`derive(PartialEq, Eq)`, na uwe kesi ambayo tunataka mkusanyaji akubali, na bado aina ya mara kwa mara inashindwa kutekeleza `Eq`.
///
/// Yaani, kesi kama hii:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Tatizo katika nambari hapo juu ni kwamba `Wrap<fn(&())>` haitekelezi `PartialEq`, wala `Eq`, kwa sababu "kwa <'a> fn(&'a _)` does not implement those traits.)
///
/// Kwa hivyo, hatuwezi kutegemea kuangalia kwa ujinga kwa `StructuralPartialEq` na `Eq` tu.
///
/// Kama ujanja wa kufanya kazi karibu na hii, tunatumia traits mbili zilizoingizwa na kila moja ya mbili hupata (`#[derive(PartialEq)]` na `#[derive(Eq)]`) na uangalie kwamba zote mbili ziko kama sehemu ya ukaguzi wa mechi.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Aina ambazo maadili yake yanaweza kuigwa tu kwa kunakili bits.
///
/// Kwa chaguo-msingi, vifungo vya kutofautisha vina 'semantics ya kusonga.'Kwa maneno mengine:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` imehamia `y`, na kwa hivyo haiwezi kutumika
///
/// // println! ("{: ?}", x);//kosa: matumizi ya thamani iliyohamishwa
/// ```
///
/// Walakini, ikiwa aina hutumia `Copy`, badala yake ina 'semantics ya nakala':
///
/// ```
/// // Tunaweza kupata utekelezaji wa `Copy`.
/// // `Clone` inahitajika pia, kwani ni ishara kubwa ya `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ni nakala ya `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Ni muhimu kutambua kwamba katika mifano hii miwili, tofauti pekee ni ikiwa unaruhusiwa kufikia `x` baada ya zoezi hilo.
/// Chini ya hood, nakala na hoja zinaweza kusababisha bits kunakiliwa kwa kumbukumbu, ingawa wakati mwingine huboreshwa mbali.
///
/// ## Ninawezaje kutekeleza `Copy`?
///
/// Kuna njia mbili za kutekeleza `Copy` kwenye aina yako.Rahisi zaidi ni kutumia `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Unaweza pia kutekeleza `Copy` na `Clone` kwa mikono:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Kuna tofauti ndogo kati ya hizi mbili: mkakati wa `derive` pia utaweka `Copy` iliyofungwa kwa vigezo vya aina, ambayo haitakiwi kila wakati.
///
/// ## Ni tofauti gani kati ya `Copy` na `Clone`?
///
/// Nakala hufanyika kabisa, kwa mfano kama sehemu ya mgawo `y = x`.Tabia ya `Copy` haiwezi kupakia;daima ni nakala rahisi yenye busara kidogo.
///
/// Cloning ni hatua wazi, `x.clone()`.Utekelezaji wa [`Clone`] unaweza kutoa tabia yoyote maalum inayohitajika kurudia maadili salama.
/// Kwa mfano, utekelezaji wa [`Clone`] kwa [`String`] unahitaji kunakili bafa ya kamba iliyoelekezwa kwenye chungu.
/// Nakala rahisi kidogo ya maadili ya [`String`] ingeweza kunakili tu kiashiria, na kusababisha bure mara mbili chini ya mstari.
/// Kwa sababu hii, [`String`] ni [`Clone`] lakini sio `Copy`.
///
/// [`Clone`] ni ishara kubwa ya `Copy`, kwa hivyo kila kitu ambacho ni `Copy` lazima pia kitekeleze [`Clone`].
/// Ikiwa aina ni `Copy` basi utekelezaji wake wa [`Clone`] unahitaji tu kurudisha `*self` (angalia mfano hapo juu).
///
/// ## Aina yangu inaweza kuwa `Copy` lini?
///
/// Aina inaweza kutekeleza `Copy` ikiwa vifaa vyake vyote vinatekeleza `Copy`.Kwa mfano, muundo huu unaweza kuwa `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Muundo unaweza kuwa `Copy`, na [`i32`] ni `Copy`, kwa hivyo `Point` inastahili kuwa `Copy`.
/// Kwa upande mwingine, fikiria
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Muundo `PointList` hauwezi kutekeleza `Copy`, kwa sababu [`Vec<T>`] sio `Copy`.Ikiwa tunajaribu kupata utekelezaji wa `Copy`, tutapata hitilafu:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Marejeleo ya pamoja (`&T`) pia ni `Copy`, kwa hivyo aina inaweza kuwa `Copy`, hata wakati inashikilia marejeleo ya pamoja ya aina `T` ambazo sio * `Copy`.
/// Fikiria muundo ufuatao, ambao unaweza kutekeleza `Copy`, kwa sababu inashikilia tu rejeleo la pamoja * kwa aina yetu ya-Copy` `PointList` kutoka hapo juu:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Je! * Aina yangu haiwezi kuwa `Copy`?
///
/// Aina zingine haziwezi kunakiliwa salama.Kwa mfano, kunakili `&mut T` kutaunda rejeleo linaloweza kubadilika.
/// Kuiga [`String`] kunaweza kuiga jukumu la kusimamia bafa ya ["Kamba"], na kusababisha bure mara mbili.
///
/// Kukamilisha kesi ya mwisho, aina yoyote inayotekeleza [`Drop`] haiwezi kuwa `Copy`, kwa sababu inasimamia rasilimali zingine kando na kaiti zake za [`size_of::<T>`].
///
/// Ukijaribu kutekeleza `Copy` kwenye muundo au enum iliyo na data isiyo-Copy`, utapata kosa [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Je! * Aina yangu inapaswa kuwa `Copy`?
///
/// Kwa ujumla, ikiwa aina yako _can_ inatekeleza `Copy`, inapaswa.
/// Kumbuka, hata hivyo, kwamba kutekeleza `Copy` ni sehemu ya API ya umma ya aina yako.
/// Ikiwa aina inaweza kuwa isiyo ya "Nakili" katika future, inaweza kuwa busara kuacha utekelezaji wa `Copy` sasa, ili kuepuka mabadiliko ya API inayovunjika.
///
/// ## Watekelezaji wa ziada
///
/// Mbali na [implementors listed below][impls], aina zifuatazo pia hutumia `Copy`:
///
/// * Aina za kipengee cha kazi (yaani, aina tofauti zilizoainishwa kwa kila kazi)
/// * Aina za kiashiria cha kazi (kwa mfano, `fn() -> i32`)
/// * Aina za safu, kwa saizi zote, ikiwa aina ya bidhaa pia hutumia `Copy` (kwa mfano, `[i32; 123456]`)
/// * Aina za turu, ikiwa kila sehemu pia hutumia `Copy` (kwa mfano, `()`, `(i32, bool)`)
/// * Aina za kufungwa, ikiwa hazijachukua thamani kutoka kwa mazingira au ikiwa maadili haya yote yaliyotekwa hutumia `Copy` wenyewe.
///   Kumbuka kuwa vigeuzi vilivyokamatwa na rejeleo iliyoshirikiwa hutumia `Copy` kila wakati (hata kama mrejeshi hafanyi), wakati vigeuzi vilivyokamatwa na rejeleo inayoweza kubadilika haviwezi kutekeleza `Copy`
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Hii inaruhusu kunakili aina ambayo haitekelezi `Copy` kwa sababu ya mipaka ya maisha isiyoridhika (kunakili `A<'_>` wakati tu ni `A<'static>: Copy` na `A<'_>: Clone`).
// Tuna sifa hii hapa kwa sasa kwa sababu kuna utaalam kadhaa uliopo kwenye `Copy` ambao tayari upo katika maktaba ya kawaida, na hakuna njia ya kuwa na tabia hii kwa usalama hivi sasa.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Pata jumla ya kuzalisha impl ya trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Aina ambazo ni salama kushiriki marejeleo kati ya nyuzi.
///
/// trait hii inatekelezwa kiatomati wakati mkusanyaji anaamua inafaa.
///
/// Ufafanuzi sahihi ni: aina `T` ni [`Sync`] ikiwa na ikiwa tu `&T` ni [`Send`].
/// Kwa maneno mengine, ikiwa hakuna uwezekano wa [undefined behavior][ub] (pamoja na mbio za data) wakati wa kupitisha marejeleo ya `&T` kati ya nyuzi.
///
/// Kama vile mtu anavyotarajia, aina za zamani kama [`u8`] na [`f64`] zote ni [`Sync`], na kwa hivyo ni aina rahisi za jumla zilizo nazo, kama tuples, structs na enums.
/// Mifano zaidi ya aina za msingi za [`Sync`] ni pamoja na aina za "immutable" kama `&T`, na zile zilizo na mabadiliko rahisi ya kurithi, kama vile [`Box<T>`][box], [`Vec<T>`][vec] na aina nyingine nyingi za mkusanyiko.
///
/// (Vigezo vya jumla vinahitaji kuwa [`Sync`] ili kontena lao liwe [`Sawazisha`].)
///
/// Matokeo ya kushangaza ya ufafanuzi ni kwamba `&mut T` ni `Sync` (ikiwa `T` ni `Sync`) ingawa inaonekana kama hiyo inaweza kutoa mabadiliko yasiyolingana.
/// Ujanja ni kwamba rejea inayoweza kubadilika nyuma ya rejeleo iliyoshirikiwa (ambayo ni, `& &mut T`) inakuwa ya kusoma tu, kana kwamba ni `& &T`.
/// Kwa hivyo hakuna hatari ya mbio ya data.
///
/// Aina ambazo sio `Sync` ni zile ambazo zina "interior mutability" katika fomu isiyo salama-thread, kama [`Cell`][cell] na [`RefCell`][refcell].
/// Aina hizi huruhusu mabadiliko ya yaliyomo hata kupitia rejea isiyobadilika, iliyoshirikiwa.
/// Kwa mfano njia ya `set` kwenye [`Cell<T>`][cell] inachukua `&self`, kwa hivyo inahitaji rejeleo la pamoja [`&Cell<T>`][cell].
/// Njia hiyo haifanyi usawazishaji, kwa hivyo [`Cell`][cell] haiwezi kuwa `Sync`.
///
/// Mfano mwingine wa aina isiyo ya `Sync` ni kiashiria cha kuhesabu kumbukumbu [`Rc`][rc].
/// Kwa kuzingatia kumbukumbu yoyote [`&Rc<T>`][rc], unaweza kushikilia [`Rc<T>`][rc] mpya, ukibadilisha hesabu za kumbukumbu kwa njia isiyo ya atomiki.
///
/// Kwa kesi wakati mtu anahitaji ubadilishaji wa mambo ya ndani salama-salama, Rust hutoa [atomic data types], na vile vile kufungia wazi kupitia [`sync::Mutex`][mutex] na [`sync::RwLock`][rwlock].
/// Aina hizi zinahakikisha kuwa mabadiliko yoyote hayawezi kusababisha mbio za data, kwa hivyo aina hizo ni `Sync`.
/// Vivyo hivyo, [`sync::Arc`][arc] hutoa analog salama ya [`Rc`][rc].
///
/// Aina yoyote iliyo na mabadiliko ya ndani lazima pia itumie kanga ya [`cell::UnsafeCell`][unsafecell] karibu na value(s) ambayo inaweza kubadilishwa kupitia rejeleo la pamoja.
/// Kushindwa kufanya hivyo ni [undefined behavior][ub].
/// Kwa mfano, [`transmute`][transmute]-ing kutoka `&T` hadi `&mut T` ni batili.
///
/// Tazama [the Nomicon][nomicon-send-and-sync] kwa maelezo zaidi kuhusu `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): mara moja msaada wa kuongeza vidokezo katika ardhi ya `rustc_on_unimplemented` kwenye beta, na imeongezwa ili kuangalia ikiwa kufungwa ni mahali popote kwenye mnyororo wa mahitaji, panua kama (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Aina ya ukubwa wa sifuri kutumika kuashiria mambo ambayo "act like" wanamiliki `T`.
///
/// Kuongeza uwanja wa `PhantomData<T>` kwa aina yako kumwambia mkusanyaji kuwa aina yako hufanya kana kwamba inahifadhi thamani ya aina `T`, ingawa sio kweli.
/// Habari hii hutumiwa wakati wa kuhesabu mali fulani za usalama.
///
/// Kwa maelezo zaidi ya jinsi ya kutumia `PhantomData<T>`, tafadhali angalia [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Ujumbe mkali
///
/// Ingawa zote zina majina ya kutisha, `PhantomData` na 'aina za phantom' zinahusiana, lakini hazifanani.Kigezo cha aina ya phantom ni parameta ya aina ambayo haitumiki kamwe.
/// Katika Rust, hii mara nyingi husababisha mkusanyaji kulalamika, na suluhisho ni kuongeza matumizi ya "dummy" kupitia `PhantomData`.
///
/// # Examples
///
/// ## Vigezo vya maisha visivyotumika
///
/// Labda kesi ya kawaida ya matumizi ya `PhantomData` ni muundo ambao una kigezo cha maisha kisichotumiwa, kawaida kama sehemu ya nambari isiyo salama.
/// Kwa mfano, hapa kuna muundo `Slice` ambao una viashiria viwili vya aina `*const T`, labda ikielekeza kwenye safu mahali pengine:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Kusudi ni kwamba data ya msingi ni halali tu kwa maisha ya `'a`, kwa hivyo `Slice` haipaswi kuishi `'a`.
/// Walakini, kusudi hili halijaonyeshwa kwenye nambari, kwani hakuna matumizi ya `'a` ya maisha na kwa hivyo haijulikani ni data gani inayotumika.
/// Tunaweza kusahihisha hii kwa kumwambia mkusanyaji afanye *kana kwamba* muundo wa `Slice` ulikuwa na kumbukumbu ya `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Hii pia inahitaji ufafanuzi `T: 'a`, kuonyesha kwamba marejeo yoyote katika `T` ni halali juu ya `'a` ya maisha.
///
/// Wakati wa kuanzisha `Slice` unapeana tu thamani `PhantomData` kwa uwanja `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Vigezo vya aina ambavyo havitumiki
///
/// Wakati mwingine hufanyika kuwa una vigezo vya aina ambavyo havijatumiwa ambavyo vinaonyesha ni aina gani ya data ya muundo ni "tied", ingawa data hiyo haipatikani katika muundo yenyewe.
/// Hapa kuna mfano ambapo hii inatokea na [FFI].
/// Muonekano wa kigeni hutumia vipini vya aina `*mut ()` kurejelea maadili ya Rust ya aina tofauti.
/// Tunafuatilia aina ya Rust kwa kutumia parameter ya aina ya phantom kwenye `ExternalResource` ya muundo ambayo inafunga kushughulikia.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Umiliki na hundi ya kushuka
///
/// Kuongeza uwanja wa aina `PhantomData<T>` inaonyesha kuwa aina yako inamiliki data ya aina `T`.Hii inamaanisha kuwa wakati aina yako imeshuka, inaweza kuacha tukio moja au zaidi ya aina `T`.
/// Hii inahusiana na uchambuzi wa mkusanyiko wa [drop check] wa Rust.
///
/// Ikiwa muundo wako kwa kweli haumiliki *data ya aina `T`, ni bora kutumia aina ya kumbukumbu, kama `PhantomData<&'a T>` (ideally) au `PhantomData<* const T>` (ikiwa hakuna wakati wa maisha unatumika), ili usionyeshe umiliki.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Mkusanya-ndani trait ilitumika kuonyesha aina ya wabaguzi wa enum.
///
/// trait hii inatekelezwa kiatomati kwa kila aina na haiongezi dhamana yoyote kwa [`mem::Discriminant`].
/// Ni **tabia isiyojulikana** kusambaza kati ya `DiscriminantKind::Discriminant` na `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Aina ya ubaguzi, ambayo inapaswa kukidhi trait bound zinazohitajika na `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Mkusanya-ndani trait ilitumika kuamua ikiwa aina ina `UnsafeCell` yoyote ndani, lakini sio kupitia mwongozo.
///
/// Hii huathiri, kwa mfano, ikiwa `static` ya aina hiyo imewekwa kwenye kumbukumbu ya kusoma tu au kumbukumbu ya tuli inayoweza kuandikwa.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Aina ambazo zinaweza kuhamishwa salama baada ya kubanwa.
///
/// Rust yenyewe haina maoni ya aina zisizohamishika, na inazingatia hatua (kwa mfano, kupitia mgawo au [`mem::replace`]) kuwa salama kila wakati.
///
/// Aina ya [`Pin`][Pin] hutumiwa badala yake kuzuia kusonga kupitia mfumo wa aina.Viashiria `P<T>` vilivyofungwa kwenye kanga ya [`Pin<P<T>>`][Pin] haziwezi kutolewa nje.
/// Tazama nyaraka za [`pin` module] kwa habari zaidi juu ya kubandika.
///
/// Utekelezaji wa `Unpin` trait kwa `T` huondoa vizuizi vya kubandika aina hiyo, ambayo inaruhusu kuhamisha `T` kutoka [`Pin<P<T>>`][Pin] na kazi kama [`mem::replace`].
///
///
/// `Unpin` haina matokeo kabisa kwa data isiyobandikwa.
/// Hasa, [`mem::replace`] inasonga kwa furaha data ya `!Unpin` (inafanya kazi kwa `&mut T` yoyote, sio tu wakati `T: Unpin`).
/// Walakini, huwezi kutumia [`mem::replace`] kwenye data iliyofungwa ndani ya [`Pin<P<T>>`][Pin] kwa sababu huwezi kupata `&mut T` unayohitaji kwa hiyo, na * hiyo ndiyo inayofanya mfumo huu ufanye kazi.
///
/// Kwa hivyo hii, kwa mfano, inaweza kufanywa tu kwa aina zinazotekeleza `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Tunahitaji rejea inayoweza kubadilika kupiga `mem::replace`.
/// // Tunaweza kupata rejeleo kama hilo na (implicitly) ikiingiza `Pin::deref_mut`, lakini hiyo inawezekana tu kwa sababu `String` inatumia `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait hii inatekelezwa kiatomati kwa karibu kila aina.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Aina ya alama ambayo haitekelezi `Unpin`.
///
/// Ikiwa aina ina `PhantomPinned`, haitatumia `Unpin` kwa chaguo-msingi.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Utekelezaji wa `Copy` kwa aina za zamani.
///
/// Utekelezaji ambao hauwezi kuelezewa katika Rust unatekelezwa katika `traits::SelectionContext::copy_clone_conditions()` katika `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Marejeleo ya pamoja yanaweza kunakiliwa, lakini marejeleo yanayoweza kubadilika *hayawezi*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}