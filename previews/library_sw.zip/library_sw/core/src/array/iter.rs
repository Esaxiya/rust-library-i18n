//! Inafafanua iterator inayomilikiwa na `IntoIter` kwa safu.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Kitambulisho cha thamani cha [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Hii ndio safu tunayojishughulisha nayo.
    ///
    /// Vipengele vilivyo na faharisi `i` ambapo `alive.start <= i < alive.end` bado haijatolewa na ni viingilio halali vya safu.
    /// Vipengele vyenye fahirisi `i < alive.start` au `i >= alive.end` vimetolewa tayari na haipaswi kupatikana tena!Vipengee hivyo vilivyokufa vinaweza hata kuwa katika hali isiyoanzishwa kabisa!
    ///
    ///
    /// Kwa hivyo wavamizi ni:
    /// - `data[alive]` yuko hai (yaani ina vitu halali)
    /// - `data[..alive.start]` na `data[alive.end..]` wamekufa (yaani vitu vilikuwa vimesomwa tayari na haipaswi kuguswa tena!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Vipengele katika `data` ambazo hazijatolewa bado.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Inaunda iterator mpya juu ya `array` iliyopewa.
    ///
    /// *Kumbuka*: njia hii inaweza kupunguzwa katika future, baada ya [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Aina ya `value` ni `i32` hapa, badala ya `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // USALAMA: Transute hapa ni salama kweli.Hati za `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` imehakikishiwa kuwa na saizi sawa na mpangilio
        // > kama `T`.
        //
        // Hati hata zinaonyesha kupitisha kutoka kwa safu ya `MaybeUninit<T>` hadi safu ya `T`.
        //
        //
        // Pamoja na hayo, uanzishaji huu unaridhisha wavamizi.

        // FIXME(LukasKalbertodt): kwa kweli tumia `mem::transmute` hapa, mara tu inapo fanya kazi na gen geni:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Hadi wakati huo, tunaweza kutumia `mem::transmute_copy` kuunda nakala kidogo kama aina tofauti, kisha usahau `array` ili isianguke.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Hurejesha kipande kisichobadilika cha vitu vyote ambavyo bado havijatolewa.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // USALAMA: Tunajua kwamba vitu vyote ndani ya `alive` vimeanzishwa vizuri.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Hurejesha kipande kinachoweza kubadilika cha vitu vyote ambavyo bado havijatolewa.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // USALAMA: Tunajua kwamba vitu vyote ndani ya `alive` vimeanzishwa vizuri.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Pata faharisi inayofuata kutoka mbele.
        //
        // Kuongeza `alive.start` kwa 1 inadumisha isiyobadilika kuhusu `alive`.
        // Walakini, kwa sababu ya mabadiliko haya, kwa muda mfupi, eneo lililo hai sio `data[alive]` tena, lakini `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Soma kipengee kutoka kwa safu.
            // USALAMA: `idx` ni faharisi katika eneo la zamani la "alive" la
            // safu.Kusoma kipengele hiki kunamaanisha kuwa `data[idx]` inachukuliwa kuwa imekufa sasa (yaani usiguse).
            // Kwa kuwa `idx` ilikuwa mwanzo wa eneo lenye uhai, eneo lililo hai sasa ni `data[alive]` tena, ikirudisha wavamizi wote.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Pata faharisi inayofuata kutoka nyuma.
        //
        // Kupungua kwa `alive.end` na 1 kunadumisha isiyobadilika kuhusu `alive`.
        // Walakini, kwa sababu ya mabadiliko haya, kwa muda mfupi, eneo lililo hai sio `data[alive]` tena, lakini `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Soma kipengee kutoka kwa safu.
            // USALAMA: `idx` ni faharisi katika eneo la zamani la "alive" la
            // safu.Kusoma kipengele hiki kunamaanisha kuwa `data[idx]` inachukuliwa kuwa imekufa sasa (yaani usiguse).
            // Kama `idx` ilikuwa mwisho wa eneo lililo hai, eneo lililo hai sasa ni `data[alive]` tena, ikirudisha wavamizi wote.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // USALAMA: Hii ni salama: `as_mut_slice` inarudisha kipande kidogo
        // ya vitu ambavyo havijahamishwa bado na ambavyo vinasalia kuachwa.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Haitawahi kufurika kwa sababu ya "hai. Anza. Kuanza <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Msimamizi kweli anaripoti urefu sahihi.
// Idadi ya vipengee vya "alive" (ambayo bado itatolewa) ni urefu wa masafa `alive`.
// Masafa haya yamepunguzwa kwa urefu katika `next` au `next_back`.
// Daima hupunguzwa na 1 katika njia hizo, lakini ikiwa `Some(_)` inarejeshwa.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Kumbuka, hatuhitaji kabisa kulinganisha safu sawa sawa hai, kwa hivyo tunaweza tu kushikilia kwa kukabiliana na 0 bila kujali `self` iko wapi.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Fanya vitu vyote vilivyo hai.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Andika koni kwenye safu mpya, kisha usasishe safu yake hai.
            // Ikiwa tunaunganisha panics, tutaacha vitu vya awali kwa usahihi.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Chapisha tu vitu ambavyo havijatolewa bado: hatuwezi kupata vitu vilivyozaa tena.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}