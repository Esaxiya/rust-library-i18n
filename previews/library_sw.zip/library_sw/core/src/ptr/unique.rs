use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Kifuniko karibu na `*mut T` mbichi isiyo ya nuru ambayo inaonyesha kuwa mwenye kifuniko hiki anamiliki rejeleo.
/// Muhimu kwa kujenga vifupisho kama `Box<T>`, `Vec<T>`, `String`, na `HashMap<K, V>`.
///
/// Tofauti na `*mut T`, `Unique<T>` hufanya "as if" ilikuwa mfano wa `T`.
/// Inatumia `Send`/`Sync` ikiwa `T` ni `Send`/`Sync`.
/// Inamaanisha pia aina ya dhamana kali ya dhamana mfano wa `T` unaweza kutarajia:
/// referent ya pointer haipaswi kubadilishwa bila njia ya kipekee ya kumiliki yake ya kipekee.
///
/// Ikiwa haujui ikiwa ni sahihi kutumia `Unique` kwa madhumuni yako, fikiria kutumia `NonNull`, ambayo ina semantiki dhaifu.
///
///
/// Tofauti na `*mut T`, pointer lazima iwe sio batili kila wakati, hata kama pointer haijaonyeshwa tena.
/// Hii ni ili enum zitumie thamani hii iliyokatazwa kama ubaguzi-`Option<Unique<T>>` ina saizi sawa na `Unique<T>`.
/// Walakini, pointer bado inaweza kung'aa ikiwa haionyeshwi.
///
/// Tofauti na `*mut T`, `Unique<T>` ni ya juu zaidi ya `T`.
/// Hii inapaswa kuwa sahihi kila wakati kwa aina yoyote ambayo inashikilia mahitaji ya upendeleo wa kipekee.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: alama hii haina athari kwa tofauti, lakini ni muhimu
    // kwa kuacha kuelewa kwamba tunamiliki `T`.
    //
    // Kwa maelezo, angalia:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` vidokezo ni `Send` ikiwa `T` ni `Send` kwa sababu data wanayorejelea imewashwa.
/// Kumbuka kuwa kibadilishaji hiki cha kutangaza hakilazimishwi na mfumo wa aina;kujiondoa kwa kutumia `Unique` lazima kuitekeleze.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` vidokezo ni `Sync` ikiwa `T` ni `Sync` kwa sababu data wanayorejelea imewashwa.
/// Kumbuka kuwa kibadilishaji hiki cha kutangaza hakilazimishwi na mfumo wa aina;kujiondoa kwa kutumia `Unique` lazima kuitekeleze.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Inaunda `Unique` mpya ambayo inaning'iniza, lakini iliyokaa vizuri.
    ///
    /// Hii ni muhimu kwa kuanzisha aina ambazo hutenga kwa uvivu, kama `Vec::new` inavyofanya.
    ///
    /// Kumbuka kuwa thamani ya pointer inaweza kuwakilisha kiashiria halali kwa `T`, ambayo inamaanisha hii haipaswi kutumiwa kama thamani ya senti ya "not yet initialized".
    /// Aina ambazo hutenga kwa uvivu lazima zifuatilie uanzishaji kwa njia zingine.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // USALAMA: mem::align_of() inarudi pointer halali, isiyo ya batili.The
        // hali ya kupiga new_unchecked() inaheshimiwa.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Inaunda `Unique` mpya.
    ///
    /// # Safety
    ///
    /// `ptr` lazima isiwe batili.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // USALAMA: mpigaji lazima ahakikishe kuwa `ptr` sio ya bure.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Inaunda `Unique` mpya ikiwa `ptr` sio ya bure.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // USALAMA: Kielekezi tayari kimekaguliwa na sio batili.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Inapata kiashiria cha msingi cha `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Inachagua yaliyomo.
    ///
    /// Maisha yanayotokana yanahusiana na kibinafsi kwa hivyo hii hufanya "as if" kwa kweli ilikuwa mfano wa T ambayo inakopwa.
    /// Ikiwa maisha ya (unbound) yanahitajika, tumia `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu.
        unsafe { &*self.as_ptr() }
    }

    /// Kwa pamoja hurejelea yaliyomo.
    ///
    /// Maisha yanayotokana yanahusiana na kibinafsi kwa hivyo hii hufanya "as if" kwa kweli ilikuwa mfano wa T ambayo inakopwa.
    /// Ikiwa maisha ya (unbound) yanahitajika, tumia `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu inayoweza kubadilika.
        unsafe { &mut *self.as_ptr() }
    }

    /// Inatupa kwa kiashiria cha aina nyingine.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // USALAMA: Unique::new_unchecked() inaunda mpya ya kipekee na mahitaji
        // pointer uliyopewa isiwe batili.
        // Kwa kuwa tunajipitisha kama pointer, haiwezi kuwa batili.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // USALAMA: Rejea inayoweza kubadilika haiwezi kuwa batili
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}