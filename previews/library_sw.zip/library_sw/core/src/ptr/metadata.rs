#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Hutoa aina ya metadata ya kiashiria ya aina yoyote iliyoelekezwa.
///
/// # Metadata ya kiashiria
///
/// Aina za pointer mbichi na aina za rejeleo katika Rust zinaweza kuzingatiwa kuwa zimetengenezwa na sehemu mbili:
/// pointer ya data ambayo ina anwani ya kumbukumbu ya thamani, na metadata zingine.
///
/// Kwa aina zenye ukubwa wa kitakwimu (ambazo hutumia `Sized` traits) na pia kwa aina ya `extern`, viashiria vinasemekana kuwa "nyembamba": metadata ina ukubwa wa sifuri na aina yake ni `()`.
///
///
/// Viashiria kwa [dynamically-sized types][dst] vinasemekana kuwa "pana" au "mafuta", vina metadata isiyo ya ukubwa wa sifuri:
///
/// * Kwa ujenzi ambao uwanja wa mwisho ni DST, metadata ni metadata ya uwanja wa mwisho
/// * Kwa aina ya `str`, metadata ni urefu katika ka kama `usize`
/// * Kwa aina za kipande kama `[T]`, metadata ni urefu wa vitu kama `usize`
/// * Kwa vitu vya trait kama `dyn SomeTrait`, metadata ni [`DynMetadata<Self>`][DynMetadata] (kwa mfano `DynMetadata<dyn SomeTrait>`)
///
/// Katika future, lugha ya Rust inaweza kupata aina mpya za aina ambazo zina metadata tofauti ya kielekezi.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Hoja ya trait hii ni aina yake inayohusiana na `Metadata`, ambayo ni `()` au `usize` au `DynMetadata<_>` kama ilivyoelezwa hapo juu.
/// Inatekelezwa kiatomati kwa kila aina.
/// Inaweza kudhaniwa kutekelezwa katika muktadha wa generic, hata bila kifungo kinacholingana.
///
/// # Usage
///
/// Viashiria mbichi vinaweza kufutwa katika anwani ya data na vifaa vya metadata na njia yao ya [`to_raw_parts`].
///
/// Vinginevyo, metadata peke yake inaweza kutolewa na kazi ya [`metadata`].
/// Rejea inaweza kupitishwa kwa [`metadata`] na kushurutishwa kabisa.
///
/// Pointer ya (possibly-wide) inaweza kuwekwa tena kutoka kwa anwani yake na metadata na [`from_raw_parts`] au [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Aina ya metadata katika viashiria na marejeleo ya `Self`.
    #[lang = "metadata_type"]
    // NOTE: Weka trait bound katika `static_assert_expected_bounds_for_metadata`
    //
    // katika `library/core/src/ptr/metadata.rs` kwa usawazishaji na hizi hapa:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Viashiria kwa aina zinazotumia jina hili la trait ni "nyembamba".
///
/// Hii ni pamoja na aina za "ukubwa" na aina za `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: usitulie utulivu huu kabla jina la trait halijatulia katika lugha?
pub trait Thin = Pointee<Metadata = ()>;

/// Toa sehemu ya metadata ya kielekezi.
///
/// Maadili ya aina `*mut T`, `&T`, au `&mut T` yanaweza kupitishwa moja kwa moja kwa kazi hii kwani inashurutisha kabisa kwa `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // USALAMA: Kupata thamani kutoka kwa umoja wa `PtrRepr` ni salama kwani * const T
    // na PtrComponents<T>kuwa na mipangilio sawa ya kumbukumbu.
    // std tu ndio inaweza kufanya dhamana hii.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Inaunda pointer mbichi ya (possibly-wide) kutoka kwa anwani ya data na metadata.
///
/// Kazi hii ni salama lakini pointer iliyorudishwa sio lazima iwe salama kwa kumbukumbu.
/// Kwa vipande, angalia nyaraka za [`slice::from_raw_parts`] kwa mahitaji ya usalama.
/// Kwa vitu vya trait, metadata lazima ije kutoka kwa kiboreshaji kwenda kwa aina ile ile ya msingi iliyopunguzwa.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // USALAMA: Kupata thamani kutoka kwa umoja wa `PtrRepr` ni salama kwani * const T
    // na PtrComponents<T>kuwa na mipangilio sawa ya kumbukumbu.
    // std tu ndio inaweza kufanya dhamana hii.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Inafanya utendaji sawa na [`from_raw_parts`], isipokuwa kwamba pointer ya `*mut` mbichi inarejeshwa, tofauti na pointer ya `* const` mbichi.
///
///
/// Tazama nyaraka za [`from_raw_parts`] kwa maelezo zaidi.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // USALAMA: Kupata thamani kutoka kwa umoja wa `PtrRepr` ni salama kwani * const T
    // na PtrComponents<T>kuwa na mipangilio sawa ya kumbukumbu.
    // std tu ndio inaweza kufanya dhamana hii.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Uingizaji wa mwongozo unahitajika ili kuepuka kufungwa kwa `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Uingizaji wa mwongozo unahitajika ili kuepuka kufungwa kwa `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata ya aina ya kitu `Dyn = dyn SomeTrait` trait.
///
/// Ni kiboreshaji cha vtable (meza ya simu inayoweka) ambayo inawakilisha habari zote muhimu kudhibiti aina halisi iliyohifadhiwa ndani ya kitu cha trait.
/// Vtable haswa ina:
///
/// * saizi ya aina
/// * mpangilio wa aina
/// * kidokezo kwa aina ya `drop_in_place` impl (inaweza kuwa hakuna op kwa data ya zamani-ya zamani)
/// * inaelekeza kwa njia zote za utekelezaji wa aina ya trait
///
/// Kumbuka kuwa tatu za kwanza ni maalum kwa sababu ni muhimu kutenga, kuacha, na kusambaza kitu chochote cha trait.
///
/// Inawezekana kutaja muundo huu na parameta ya aina ambayo sio `dyn` trait kitu (kwa mfano `DynMetadata<u64>`) lakini sio kupata thamani ya maana ya muundo huo.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Kiambishi awali cha vtables zote.Inafuatwa na viashiria vya kazi kwa njia za trait.
///
/// Maelezo ya utekelezaji wa kibinafsi ya `DynMetadata::size_of` nk.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Hurejesha saizi ya aina inayohusishwa na wtable hii.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Hurejesha mpangilio wa aina inayohusishwa na vtable hii.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Hurejesha ukubwa na mpangilio pamoja kama `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // USALAMA: mkusanyaji alitoa vtable hii kwa aina halisi ya Rust ambayo
        // inajulikana kuwa na mpangilio halali.Sababu sawa na ile ya `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Uingizaji wa mwongozo unahitajika ili kuepuka mipaka ya `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}