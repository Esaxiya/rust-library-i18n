use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` lakini sio sifuri na covariant.
///
/// Mara nyingi hii ni kitu sahihi kutumia wakati wa kujenga miundo ya data kwa kutumia viashiria mbichi, lakini mwishowe ni hatari zaidi kutumia kwa sababu ya mali zake za ziada.Ikiwa haujui ikiwa unapaswa kutumia `NonNull<T>`, tumia tu `*mut T`!
///
/// Tofauti na `*mut T`, pointer lazima iwe isiyo ya kweli kila wakati, hata kama pointer haijaonyeshwa tena.Hii ni ili enum zitumie thamani hii iliyokatazwa kama ubaguzi-`Option<NonNull<T>>` ina saizi sawa na `* mut T`.
/// Walakini, pointer bado inaweza kung'aa ikiwa haionyeshwi.
///
/// Tofauti na `*mut T`, `NonNull<T>` ilichaguliwa kuwa ya juu zaidi ya `T`.Hii inafanya uwezekano wa kutumia `NonNull<T>` wakati wa kujenga aina za aina, lakini inaleta hatari ya kutokuwa na uhakika ikiwa inatumiwa kwa aina ambayo haifai kuwa ya kawaida.
/// (Chaguo tofauti lilifanywa kwa `*mut T` ingawa kitaalam kutokuwa na busara kunaweza kusababishwa tu na kupiga kazi zisizo salama.)
///
/// Covariance ni sahihi kwa vizuizi vingi salama, kama vile `Box`, `Rc`, `Arc`, `Vec`, na `LinkedList`.Hii ndio kesi kwa sababu hutoa API ya umma inayofuata sheria za kawaida zinazoshirikiwa za XOR za Rust.
///
/// Ikiwa aina yako haiwezi kuwa ya kawaida, lazima uhakikishe kuwa ina uwanja wa ziada ili kutoa uvumbuzi.Mara nyingi uwanja huu utakuwa aina ya [`PhantomData`] kama `PhantomData<Cell<T>>` au `PhantomData<&'a mut T>`.
///
/// Ona kuwa `NonNull<T>` ina mfano wa `From` kwa `&T`.Walakini, hii haibadilishi ukweli kwamba kubadilika kupitia (pointer inayotokana na a) rejeleo iliyoshirikiwa ni tabia isiyojulikana isipokuwa mabadiliko yatatokea ndani ya [`UnsafeCell<T>`].Vivyo hivyo kwa kuunda rejeleo inayoweza kubadilika kutoka kwa rejeleo la pamoja.
///
/// Unapotumia mfano huu wa `From` bila `UnsafeCell<T>`, ni jukumu lako kuhakikisha kuwa `as_mut` haiitwi kamwe, na `as_ptr` haitumiki kamwe kwa mabadiliko.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` viashiria sio `Send` kwa sababu data wanayorejelea inaweza kutengwa.
// NB, impl hii sio lazima, lakini inapaswa kutoa ujumbe bora wa makosa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` viashiria sio `Sync` kwa sababu data wanayorejelea inaweza kutengwa.
// NB, impl hii sio lazima, lakini inapaswa kutoa ujumbe bora wa makosa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Inaunda `NonNull` mpya ambayo inaning'iniza, lakini iliyokaa vizuri.
    ///
    /// Hii ni muhimu kwa kuanzisha aina ambazo hutenga kwa uvivu, kama `Vec::new` inavyofanya.
    ///
    /// Kumbuka kuwa thamani ya pointer inaweza kuwakilisha kiashiria halali kwa `T`, ambayo inamaanisha hii haipaswi kutumiwa kama thamani ya senti ya "not yet initialized".
    /// Aina ambazo hutenga kwa uvivu lazima zifuatilie uanzishaji kwa njia zingine.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // USALAMA: mem::align_of() inarudi usize isiyo ya sifuri ambayo hutupwa
        // kwa * mut T.
        // Kwa hivyo, `ptr` sio batili na masharti ya kupiga simu new_unchecked() yanaheshimiwa.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Hurejesha marejeleo ya pamoja kwa thamani.Kinyume na [`as_ref`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake anayeweza kubadilika angalia [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa yote yafuatayo ni ya kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kubadilishwa (isipokuwa ndani ya `UnsafeCell`).
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Hurejesha marejeleo ya kipekee kwa thamani.Kinyume na [`as_mut`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake wa pamoja angalia [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa yote yafuatayo ni ya kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kupatikana (kusoma au kuandikwa) kupitia pointer nyingine yoyote.
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Inaunda `NonNull` mpya.
    ///
    /// # Safety
    ///
    /// `ptr` lazima isiwe batili.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // USALAMA: mpigaji lazima ahakikishe kuwa `ptr` sio ya bure.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Inaunda `NonNull` mpya ikiwa `ptr` sio ya bure.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // USALAMA: Kielekezi tayari kimekaguliwa na sio batili
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Inafanya utendaji sawa na [`std::ptr::from_raw_parts`], isipokuwa kwamba pointer ya `NonNull` inarejeshwa, tofauti na pointer ya `*const` mbichi.
    ///
    ///
    /// Tazama nyaraka za [`std::ptr::from_raw_parts`] kwa maelezo zaidi.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // USALAMA: Matokeo ya `ptr::from::raw_parts_mut` hayatoshi kwa sababu `data_address` ni.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Ondoa pointer (ikiwezekana pana) kwenye anwani na vifaa vya metadata.
    ///
    /// Pointer inaweza kujengwa baadaye na [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Inapata kiashiria cha msingi cha `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Hurejesha marejeleo ya pamoja kwa thamani.Ikiwa thamani inaweza kuwa isiyoanzishwa, [`as_uninit_ref`] lazima itumike badala yake.
    ///
    /// Kwa mwenzake anayeweza kubadilika angalia [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa yote yafuatayo ni ya kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Kiashiria lazima kielekeze mfano ulioanzishwa wa `T`.
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kubadilishwa (isipokuwa ndani ya `UnsafeCell`).
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    /// (Sehemu kuhusu kuanza kutumika bado haijaamuliwa kikamilifu, lakini hadi hapo, njia salama tu ni kuhakikisha kuwa zinaanzishwa kweli.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu.
        unsafe { &*self.as_ptr() }
    }

    /// Hurejesha rejeleo la kipekee kwa thamani.Ikiwa thamani inaweza kuwa isiyoanzishwa, [`as_uninit_mut`] lazima itumike badala yake.
    ///
    /// Kwa mwenzake wa pamoja angalia [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa yote yafuatayo ni ya kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Kiashiria lazima kielekeze mfano ulioanzishwa wa `T`.
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kupatikana (kusoma au kuandikwa) kupitia pointer nyingine yoyote.
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    /// (Sehemu kuhusu kuanza kutumika bado haijaamuliwa kikamilifu, lakini hadi hapo, njia salama tu ni kuhakikisha kuwa zinaanzishwa kweli.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu inayoweza kubadilika.
        unsafe { &mut *self.as_ptr() }
    }

    /// Inatupa kwa kiashiria cha aina nyingine.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // USALAMA: `self` ni kiashiria cha `NonNull` ambacho sio lazima kitekelezwe
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Inaunda kipande kisichokuwa cha mbichi kutoka kwa kijitahidi nyembamba na urefu.
    ///
    /// Hoja ya `len` ni idadi ya vitu **, sio idadi ya ka.
    ///
    /// Kazi hii ni salama, lakini kutofautisha thamani ya kurudisha sio salama.
    /// Tazama nyaraka za [`slice::from_raw_parts`] kwa mahitaji ya usalama wa kipande.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // tengeneza pointer ya kipande wakati unapoanza na kiboreshaji cha kipengee cha kwanza
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Kumbuka kuwa mfano huu unaonyesha matumizi ya njia hii, lakini `wacha kipande= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // USALAMA: `data` ni kiashiria cha `NonNull` ambacho sio lazima kitekelezwe
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Hurejesha urefu wa kipande kisichobadilika cha mbichi.
    ///
    /// Thamani iliyorudishwa ni idadi ya vipengee **, sio idadi ya ka.
    ///
    /// Kazi hii ni salama, hata wakati kipande kibichi kisicho cha null hakiwezi kutajwa kwa kipande kwa sababu pointer haina anwani halali.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Hurejesha kielekezi kisicho cha batili kwa bafa ya kipande.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // USALAMA: Tunajua `self` sio ya bure.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Hurejesha kielekezi kibichi kwenye bafa ya kipande.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Hurejesha rejeleo lililoshirikiwa kwa kipande cha thamani ambazo hazijaanzishwa.Kinyume na [`as_ref`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake anayeweza kubadilika angalia [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa yote yafuatayo ni ya kweli:
    ///
    /// * Kielekezi lazima kiwe [valid] kwa usomaji wa baiti `ptr.len() * mem::size_of::<T>()` nyingi, na lazima iwe iliyokaa sawa.Hii inamaanisha haswa:
    ///
    ///     * Upeo mzima wa kumbukumbu ya kipande hiki lazima iwe ndani ya kitu kimoja kilichotengwa!
    ///       Vipande haviwezi kupita kwenye vitu vingi vilivyotengwa.
    ///
    ///     * Kielekezi lazima kiwe sawa hata kwa vipande vya urefu wa sifuri.
    ///     Sababu moja ya hii ni kwamba uboreshaji wa mpangilio wa enum unaweza kutegemea marejeleo (pamoja na vipande vya urefu wowote) zikiwa zimepangiliwa na zisizo za kutofautisha kuzitofautisha na data zingine.
    ///
    ///     Unaweza kupata pointer inayoweza kutumika kama `data` kwa vipande vya urefu wa sifuri ukitumia [`NonNull::dangling()`].
    ///
    /// * Ukubwa wa jumla ya kipande `ptr.len() * mem::size_of::<T>()` lazima isiwe kubwa kuliko `isize::MAX`.
    ///   Tazama nyaraka za usalama za [`pointer::offset`].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kubadilishwa (isipokuwa ndani ya `UnsafeCell`).
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// Tazama pia [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Hurejesha marejeleo ya kipekee kwa kipande cha thamani ambazo hazijaanzishwa.Kinyume na [`as_mut`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake wa pamoja angalia [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa yote yafuatayo ni ya kweli:
    ///
    /// * Kielekezi lazima kiwe [valid] kwa usomaji na aandike kwa `ptr.len() * mem::size_of::<T>()` ka nyingi, na lazima iwe iliyokaa sawa.Hii inamaanisha haswa:
    ///
    ///     * Upeo mzima wa kumbukumbu ya kipande hiki lazima iwe ndani ya kitu kimoja kilichotengwa!
    ///       Vipande haviwezi kupita kwenye vitu vingi vilivyotengwa.
    ///
    ///     * Kielekezi lazima kiwe sawa hata kwa vipande vya urefu wa sifuri.
    ///     Sababu moja ya hii ni kwamba uboreshaji wa mpangilio wa enum unaweza kutegemea marejeleo (pamoja na vipande vya urefu wowote) zikiwa zimepangiliwa na zisizo za kutofautisha kuzitofautisha na data zingine.
    ///
    ///     Unaweza kupata pointer inayoweza kutumika kama `data` kwa vipande vya urefu wa sifuri ukitumia [`NonNull::dangling()`].
    ///
    /// * Ukubwa wa jumla ya kipande `ptr.len() * mem::size_of::<T>()` lazima isiwe kubwa kuliko `isize::MAX`.
    ///   Tazama nyaraka za usalama za [`pointer::offset`].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kupatikana (kusoma au kuandikwa) kupitia pointer nyingine yoyote.
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// Tazama pia [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Hii ni salama kwani `memory` ni halali kwa kusoma na inaandika kwa `memory.len()` ka nyingi.
    /// // Kumbuka kuwa kupiga simu `memory.as_mut()` hairuhusiwi hapa kwani yaliyomo yanaweza kutolewa.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Hurejesha kiboreshaji mbichi kwa kipengee au sehemu ndogo, bila kuangalia mipaka.
    ///
    /// Kuita njia hii na faharisi isiyo nje ya mipaka au wakati `self` haionyeshwi ni *[tabia isiyojulikana]* hata kama kitambulisho kinachosababisha hakitumiki.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // USALAMA: mpigaji anahakikisha kuwa `self` haiwezi kutolewa na `index` katika mipaka.
        // Kama matokeo, pointer inayosababisha haiwezi kuwa NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // USALAMA: Kiashiria cha kipekee hakiwezi kuwa batili, kwa hivyo masharti ya
        // new_unchecked() zinaheshimiwa.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // USALAMA: Rejea inayoweza kubadilika haiwezi kuwa batili.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // USALAMA: Rejeleo haliwezi kuwa batili, kwa hivyo masharti ya
        // new_unchecked() zinaheshimiwa.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}