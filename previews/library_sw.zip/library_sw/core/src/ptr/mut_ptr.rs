use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Inarudi `true` ikiwa pointer ni batili.
    ///
    /// Kumbuka kuwa aina ambazo hazijakadiriwa zina vidokezo vingi visivyo na maana, kwani kiashiria cha data ghafi tu kinazingatiwa, sio urefu wao, vtable, n.k.
    /// Kwa hivyo, viashiria viwili ambavyo ni batili bado haviwezi kulinganisha sawa na kila mmoja.
    ///
    /// ## Tabia wakati wa tathmini ya const
    ///
    /// Wakati kazi hii inatumiwa wakati wa tathmini ya const, inaweza kurudi `false` kwa viashiria ambavyo vinaonekana kuwa batili wakati wa kukimbia.
    /// Hasa, wakati pointer kwa kumbukumbu fulani imewekwa zaidi ya mipaka yake kwa njia ambayo pointer inayosababisha iko batili, kazi bado itarudi `false`.
    ///
    /// Hakuna njia ya CTFE kujua msimamo kamili wa kumbukumbu hiyo, kwa hivyo hatuwezi kujua ikiwa pointer ni batili au la.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Linganisha kupitia kutupwa kwa kiboreshaji nyembamba, kwa hivyo viashiria vya mafuta vinazingatia tu sehemu yao ya "data" kwa ujinga.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Inatupa kwa kiashiria cha aina nyingine.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Ondoa pointer (ikiwezekana pana) kwenye anwani na vifaa vya metadata.
    ///
    /// Pointer inaweza kujengwa baadaye na [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Hurejesha `None` ikiwa pointer ni batili, au sivyo inarudisha rejeleo lililoshirikiwa kwa thamani iliyofungwa katika `Some`.Ikiwa thamani inaweza kuwa isiyoanzishwa, [`as_uninit_ref`] lazima itumike badala yake.
    ///
    /// Kwa mwenzake anayeweza kubadilika angalia [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa *pointer ni NULL* au * yote yafuatayo ni kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Kiashiria lazima kielekeze mfano ulioanzishwa wa `T`.
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kubadilishwa (isipokuwa ndani ya `UnsafeCell`).
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    /// (Sehemu kuhusu kuanza kutumika bado haijaamuliwa kikamilifu, lakini hadi hapo, njia salama tu ni kuhakikisha kuwa zinaanzishwa kweli.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Toleo ambalo halijakaguliwa kabisa
    ///
    /// Ikiwa una hakika kuwa pointer haiwezi kuwa tupu na inatafuta aina fulani ya `as_ref_unchecked` ambayo inarudisha `&T` badala ya `Option<&T>`, ujue kuwa unaweza kutaja pointer moja kwa moja.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` ni halali kwa a
        // rejea ikiwa sio batili.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Hurejesha `None` ikiwa pointer ni batili, au sivyo inarudisha rejeleo lililoshirikiwa kwa thamani iliyofungwa katika `Some`.
    /// Kinyume na [`as_ref`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake anayeweza kubadilika angalia [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa *pointer ni NULL* au * yote yafuatayo ni kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kubadilishwa (isipokuwa ndani ya `UnsafeCell`).
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Hukokotoa malipo kutoka kwa kielekezi.
    ///
    /// `count` iko katika vitengo vya T;km, `count` ya 3 inawakilisha kipangamizi cha pointer cha baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ikiwa yoyote ya masharti yafuatayo yamekiukwa, matokeo yake ni tabia isiyojulikana:
    ///
    /// * Kiashiria cha kuanzia na kusababisha lazima iwe katika mipaka au baiti moja kupita mwisho wa kitu kimoja kilichotengwa.
    /// Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
    ///
    /// * Malipo yaliyokokotolewa,**kwa baiti**, hayawezi kufurika `isize`.
    ///
    /// * Kukosa kuwa katika mipaka hakuwezi kutegemea "wrapping around" nafasi ya anwani.Hiyo ni, jumla isiyo na ukomo wa usahihi,**katika baiti** lazima iwe sawa na usize.
    ///
    /// Mkusanyaji na maktaba ya kawaida kwa ujumla hujaribu kuhakikisha kuwa mgao haufikii saizi yoyote ambayo malipo ni ya wasiwasi.
    /// Kwa mfano, `Vec` na `Box` wanahakikisha kuwa hawagawi zaidi ya baiti za `isize::MAX`, kwa hivyo `vec.as_ptr().add(vec.len())` ni salama kila wakati.
    ///
    /// Majukwaa mengi kimsingi hayawezi hata kujenga mgao kama huo.
    /// Kwa mfano, hakuna jukwaa linalojulikana la 64-bit linaloweza kutumikia ombi la baiti 2 <sup>63 kwa</sup> sababu ya mapungufu ya meza-ukurasa au kugawanya nafasi ya anwani.
    /// Walakini, majukwaa mengine ya 32-bit na 16-bit yanaweza kufanikiwa kutuma ombi la zaidi ya baiti za `isize::MAX` na vitu kama Ugani wa Anwani ya Kimwili.
    ///
    /// Kwa hivyo, kumbukumbu iliyopatikana moja kwa moja kutoka kwa wagawaji au faili zilizopangwa kwa kumbukumbu * inaweza kuwa kubwa sana kushughulikia kazi hii.
    ///
    /// Fikiria kutumia [`wrapping_offset`] badala yake ikiwa vizuizi hivi ni ngumu kutosheleza.
    /// Faida pekee ya njia hii ni kwamba inawezesha uboreshaji zaidi wa mkusanyaji mkali.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `offset`.
        // Kiashiria kilichopatikana ni halali kwa kuandika kwani mpigaji lazima ahakikishe kuwa inaelekeza kwa kitu kimoja kilichotengwa kama `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Hukokotoa malipo kutoka kwa kielekezi kwa kutumia hesabu ya kufunga.
    /// `count` iko katika vitengo vya T;km, `count` ya 3 inawakilisha kipangamizi cha pointer cha baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Operesheni yenyewe yenyewe ni salama kila wakati, lakini kutumia pointer inayosababisha sio.
    ///
    /// Kiashiria kinachosababisha kinabaki kushikamana na kitu kile kile kilichotengwa ambacho `self` inaelekeza.
    /// Haiwezi * kutumiwa kufikia kitu tofauti kilichotengwa.Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
    ///
    /// Kwa maneno mengine, `let z = x.wrapping_offset((y as isize) - (x as isize))` haifanyi * `z` sawa na `y` hata ikiwa tunadhani `T` ina saizi `1` na hakuna kufurika: `z` bado imeambatanishwa na kitu `x` kimeambatanishwa, na kukionesha ni Tabia isiyojulikana isipokuwa `x` na `y` inaelekeza kwenye kitu kimoja kilichotengwa.
    ///
    /// Ikilinganishwa na [`offset`], njia hii kimsingi huchelewesha mahitaji ya kukaa ndani ya kitu kimoja kilichotengwa: [`offset`] ni tabia isiyojulikana wakati wa kuvuka mipaka ya kitu;`wrapping_offset` hutoa pointer lakini bado inaongoza kwa Tabia isiyojulikana ikiwa pointer haionyeshwi wakati iko nje ya mipaka ya kitu ambacho imeshikamana nacho.
    /// [`offset`] inaweza kuboreshwa bora na kwa hivyo inafaa katika nambari nyeti ya utendaji.
    ///
    /// Cheki iliyocheleweshwa inazingatia tu thamani ya pointer ambayo ilionyeshwa, sio maadili ya kati yaliyotumika wakati wa hesabu ya matokeo ya mwisho.
    /// Kwa mfano, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` daima ni sawa na `x`.Kwa maneno mengine, kuacha kitu kilichotengwa na kisha kukiingiza tena baadaye inaruhusiwa.
    ///
    /// Ikiwa unahitaji kuvuka mipaka ya kitu, tupa pointer kwa nambari kamili na ufanye hesabu hapo.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// // Iterate kutumia pointer mbichi katika nyongeza ya vitu viwili
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // USALAMA: asili ya `arith_offset` haina mahitaji ya kuitwa.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Hurejesha `None` ikiwa pointer ni batili, au sivyo inarudisha rejeleo la kipekee kwa thamani iliyofungwa katika `Some`.Ikiwa thamani inaweza kuwa isiyoanzishwa, [`as_uninit_mut`] lazima itumike badala yake.
    ///
    /// Kwa mwenzake wa pamoja angalia [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa *pointer ni NULL* au * yote yafuatayo ni kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Kiashiria lazima kielekeze mfano ulioanzishwa wa `T`.
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kupatikana (kusoma au kuandikwa) kupitia pointer nyingine yoyote.
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    /// (Sehemu kuhusu kuanza kutumika bado haijaamuliwa kikamilifu, lakini hadi hapo, njia salama tu ni kuhakikisha kuwa zinaanzishwa kweli.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Itachapisha: "[4, 2, 3]".
    /// ```
    ///
    /// # Toleo ambalo halijakaguliwa kabisa
    ///
    /// Ikiwa una hakika kuwa pointer haiwezi kuwa tupu na inatafuta aina fulani ya `as_mut_unchecked` ambayo inarudisha `&mut T` badala ya `Option<&mut T>`, ujue kuwa unaweza kutaja pointer moja kwa moja.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Itachapisha: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` ni halali kwa
        // rejeleo linaloweza kubadilika ikiwa sio batili.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Hurejesha `None` ikiwa pointer ni batili, au sivyo inarudisha rejeleo la kipekee kwa thamani iliyofungwa katika `Some`.
    /// Kinyume na [`as_mut`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake wa pamoja angalia [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa *pointer ni NULL* au * yote yafuatayo ni kweli:
    ///
    /// * Kiashiria lazima kiwe sawa.
    ///
    /// * Lazima iwe "dereferencable" kwa maana iliyofafanuliwa katika [the module documentation].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kupatikana (kusoma au kuandikwa) kupitia pointer nyingine yoyote.
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` inakidhi zote
        // mahitaji ya kumbukumbu.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Hurejesha ikiwa viashiria viwili vimehakikishiwa kuwa sawa.
    ///
    /// Wakati wa kukimbia kazi hii hufanya kama `self == other`.
    /// Walakini, katika hali zingine (kwa mfano, tathmini ya wakati wa kukusanya), haiwezekani kila wakati kuamua usawa wa viashiria viwili, kwa hivyo kazi hii inaweza kurudisha `false` kwa viashiria ambavyo baadaye vinaweza kuwa sawa.
    ///
    /// Lakini inaporudi `true`, viashiria vinahakikishiwa kuwa sawa.
    ///
    /// Kazi hii ni kioo cha [`guaranteed_ne`], lakini sio inverse yake.Kuna kulinganisha kwa pointer ambayo kazi zote mbili zinarudi `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Thamani ya kurudi inaweza kubadilika kulingana na toleo la mkusanyaji na nambari isiyo salama inaweza kutegemea matokeo ya kazi hii kwa utimamu.
    /// Inapendekezwa kutumia tu kazi hii kwa uboreshaji wa utendaji ambapo maadili ya kurudisha `false` na kazi hii hayaathiri matokeo, lakini utendaji tu.
    /// Matokeo ya kutumia njia hii kufanya wakati wa kukimbia na kukusanya nambari za wakati kuishi tofauti hazijachunguzwa.
    /// Njia hii haipaswi kutumiwa kuanzisha utofauti kama huo, na pia haipaswi kutuliza kabla ya kuelewa vizuri suala hili.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Hurejesha ikiwa viashiria viwili vimehakikishiwa kuwa sawa.
    ///
    /// Wakati wa kukimbia kazi hii hufanya kama `self != other`.
    /// Walakini, katika hali zingine (kwa mfano, tathmini ya wakati-kusanya), haiwezekani kila wakati kuamua usawa wa viashiria viwili, kwa hivyo kazi hii inaweza kurudisha `false` kwa viashiria ambavyo baadaye vinaonekana kuwa sawa.
    ///
    /// Lakini inaporudi `true`, viashiria vinahakikishiwa kuwa sawa.
    ///
    /// Kazi hii ni kioo cha [`guaranteed_eq`], lakini sio inverse yake.Kuna kulinganisha kwa pointer ambayo kazi zote mbili zinarudi `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Thamani ya kurudi inaweza kubadilika kulingana na toleo la mkusanyaji na nambari isiyo salama inaweza kutegemea matokeo ya kazi hii kwa utimamu.
    /// Inapendekezwa kutumia tu kazi hii kwa uboreshaji wa utendaji ambapo maadili ya kurudisha `false` na kazi hii hayaathiri matokeo, lakini utendaji tu.
    /// Matokeo ya kutumia njia hii kufanya wakati wa kukimbia na kukusanya nambari za wakati kuishi tofauti hazijachunguzwa.
    /// Njia hii haipaswi kutumiwa kuanzisha utofauti kama huo, na pia haipaswi kutuliza kabla ya kuelewa vizuri suala hili.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Huhesabu umbali kati ya viashiria viwili.Thamani iliyorudishwa iko katika vitengo vya T: umbali katika ka hugawanywa na `mem::size_of::<T>()`.
    ///
    /// Kazi hii ni kinyume cha [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Ikiwa yoyote ya masharti yafuatayo yamekiukwa, matokeo yake ni tabia isiyojulikana:
    ///
    /// * Kiashiria cha kuanzia na kingine lazima iwe katika mipaka au baiti moja kupita mwisho wa kitu kimoja kilichotengwa.
    /// Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
    ///
    /// * Viashiria vyote viwili lazima viwe *vinavyotokana na* kielekezi kwa kitu kimoja.
    ///   (Tazama hapa chini kwa mfano.)
    ///
    /// * Umbali kati ya kuyatumia, kwa ka, lazima iwe sawa sawa na saizi ya `T`.
    ///
    /// * Umbali kati ya kuyatumia,**kwa baiti**, hauwezi kufurika `isize`.
    ///
    /// * Umbali kuwa katika mipaka hauwezi kutegemea "wrapping around" nafasi ya anwani.
    ///
    /// Aina za Rust kamwe sio kubwa kuliko ugawaji wa `isize::MAX` na Rust kamwe hazizungukii nafasi ya anwani, kwa hivyo viashiria viwili ndani ya thamani fulani ya aina yoyote ya Rust `T` vitakidhi masharti mawili ya mwisho.
    ///
    /// Maktaba ya kawaida pia inahakikisha kuwa mgao haufikii saizi yoyote ambayo malipo ni ya wasiwasi.
    /// Kwa mfano, `Vec` na `Box` wanahakikisha kuwa hawagawi zaidi ya baiti za `isize::MAX`, kwa hivyo `ptr_into_vec.offset_from(vec.as_ptr())` hutosheleza hali mbili za mwisho.
    ///
    /// Majukwaa mengi kimsingi hayawezi hata kujenga mgawo mkubwa kama huo.
    /// Kwa mfano, hakuna jukwaa linalojulikana la 64-bit linaloweza kutumikia ombi la baiti 2 <sup>63 kwa</sup> sababu ya mapungufu ya meza-ukurasa au kugawanya nafasi ya anwani.
    /// Walakini, majukwaa mengine ya 32-bit na 16-bit yanaweza kufanikiwa kutuma ombi la zaidi ya baiti za `isize::MAX` na vitu kama Ugani wa Anwani ya Kimwili.
    /// Kwa hivyo, kumbukumbu iliyopatikana moja kwa moja kutoka kwa wagawaji au faili zilizopangwa kwa kumbukumbu * inaweza kuwa kubwa sana kushughulikia kazi hii.
    /// (Kumbuka kuwa [`offset`] na [`add`] pia zina kiwango sawa na kwa hivyo haziwezi kutumiwa kwa mgao mkubwa vile vile.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Kazi hii panics ikiwa `T` ni Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Matumizi * yasiyo sahihi:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Fanya ptr2_other "alias" ya ptr2, lakini imetokana na ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Kwa kuwa ptr2_other na ptr2 zimetokana na viashiria kwa vitu tofauti, kuhesabu hesabu yao ni tabia isiyojulikana, ingawa wanaelekeza kwa anwani moja!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Tabia isiyojulikana
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Hukokotoa malipo kutoka kwa kielekezi (urahisi wa `.offset(count as isize)`).
    ///
    /// `count` iko katika vitengo vya T;km, `count` ya 3 inawakilisha kipangamizi cha pointer cha baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ikiwa yoyote ya masharti yafuatayo yamekiukwa, matokeo yake ni tabia isiyojulikana:
    ///
    /// * Kiashiria cha kuanzia na kusababisha lazima iwe katika mipaka au baiti moja kupita mwisho wa kitu kimoja kilichotengwa.
    /// Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
    ///
    /// * Malipo yaliyokokotolewa,**kwa baiti**, hayawezi kufurika `isize`.
    ///
    /// * Kukamilisha kuwa katika mipaka hakuwezi kutegemea "wrapping around" nafasi ya anwani.Hiyo ni, jumla isiyo na kipimo lazima iwe sawa na `usize`.
    ///
    /// Mkusanyaji na maktaba ya kawaida kwa ujumla hujaribu kuhakikisha kuwa mgao haufikii saizi yoyote ambayo malipo ni ya wasiwasi.
    /// Kwa mfano, `Vec` na `Box` wanahakikisha kuwa hawagawi zaidi ya baiti za `isize::MAX`, kwa hivyo `vec.as_ptr().add(vec.len())` ni salama kila wakati.
    ///
    /// Majukwaa mengi kimsingi hayawezi hata kujenga mgao kama huo.
    /// Kwa mfano, hakuna jukwaa linalojulikana la 64-bit linaloweza kutumikia ombi la baiti 2 <sup>63 kwa</sup> sababu ya mapungufu ya meza-ukurasa au kugawanya nafasi ya anwani.
    /// Walakini, majukwaa mengine ya 32-bit na 16-bit yanaweza kufanikiwa kutuma ombi la zaidi ya baiti za `isize::MAX` na vitu kama Ugani wa Anwani ya Kimwili.
    ///
    /// Kwa hivyo, kumbukumbu iliyopatikana moja kwa moja kutoka kwa wagawaji au faili zilizopangwa kwa kumbukumbu * inaweza kuwa kubwa sana kushughulikia kazi hii.
    ///
    /// Fikiria kutumia [`wrapping_add`] badala yake ikiwa vizuizi hivi ni ngumu kutosheleza.
    /// Faida pekee ya njia hii ni kwamba inawezesha uboreshaji zaidi wa mkusanyaji mkali.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Hukokotoa malipo kutoka kwa kielekezi (urahisi wa `.offset ((hesabu kama isize).wrapping_neg())`).
    ///
    /// `count` iko katika vitengo vya T;km, `count` ya 3 inawakilisha kipangamizi cha pointer cha baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ikiwa yoyote ya masharti yafuatayo yamekiukwa, matokeo yake ni tabia isiyojulikana:
    ///
    /// * Kiashiria cha kuanzia na kusababisha lazima iwe katika mipaka au baiti moja kupita mwisho wa kitu kimoja kilichotengwa.
    /// Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
    ///
    /// * Kubadilishwa kwa hesabu hakuwezi kuzidi baiti `isize::MAX`** **.
    ///
    /// * Kukosa kuwa katika mipaka hakuwezi kutegemea "wrapping around" nafasi ya anwani.Hiyo ni, jumla ya usahihi usio na kipimo lazima iwe sawa na usize.
    ///
    /// Mkusanyaji na maktaba ya kawaida kwa ujumla hujaribu kuhakikisha kuwa mgao haufikii saizi yoyote ambayo malipo ni ya wasiwasi.
    /// Kwa mfano, `Vec` na `Box` wanahakikisha kuwa hawagawi zaidi ya baiti za `isize::MAX`, kwa hivyo `vec.as_ptr().add(vec.len()).sub(vec.len())` ni salama kila wakati.
    ///
    /// Majukwaa mengi kimsingi hayawezi hata kujenga mgao kama huo.
    /// Kwa mfano, hakuna jukwaa linalojulikana la 64-bit linaloweza kutumikia ombi la baiti 2 <sup>63 kwa</sup> sababu ya mapungufu ya meza-ukurasa au kugawanya nafasi ya anwani.
    /// Walakini, majukwaa mengine ya 32-bit na 16-bit yanaweza kufanikiwa kutuma ombi la zaidi ya baiti za `isize::MAX` na vitu kama Ugani wa Anwani ya Kimwili.
    ///
    /// Kwa hivyo, kumbukumbu iliyopatikana moja kwa moja kutoka kwa wagawaji au faili zilizopangwa kwa kumbukumbu * inaweza kuwa kubwa sana kushughulikia kazi hii.
    ///
    /// Fikiria kutumia [`wrapping_sub`] badala yake ikiwa vizuizi hivi ni ngumu kutosheleza.
    /// Faida pekee ya njia hii ni kwamba inawezesha uboreshaji zaidi wa mkusanyaji mkali.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Hukokotoa malipo kutoka kwa kielekezi kwa kutumia hesabu ya kufunga.
    /// (urahisi kwa `.wrapping_offset(count as isize)`)
    ///
    /// `count` iko katika vitengo vya T;km, `count` ya 3 inawakilisha kipangamizi cha pointer cha baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Operesheni yenyewe yenyewe ni salama kila wakati, lakini kutumia pointer inayosababisha sio.
    ///
    /// Kiashiria kinachosababisha kinabaki kushikamana na kitu kile kile kilichotengwa ambacho `self` inaelekeza.
    /// Haiwezi * kutumiwa kufikia kitu tofauti kilichotengwa.Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
    ///
    /// Kwa maneno mengine, `let z = x.wrapping_add((y as usize) - (x as usize))` haifanyi * `z` sawa na `y` hata ikiwa tunadhani `T` ina saizi `1` na hakuna kufurika: `z` bado imeambatanishwa na kitu `x` kimeambatanishwa, na kukionesha ni tabia isiyojulikana isipokuwa `x` na `y` inaelekeza kwenye kitu kimoja kilichotengwa.
    ///
    /// Ikilinganishwa na [`add`], njia hii kimsingi huchelewesha mahitaji ya kukaa ndani ya kitu kimoja kilichotengwa: [`add`] ni tabia isiyojulikana wakati wa kuvuka mipaka ya kitu;`wrapping_add` hutoa pointer lakini bado inaongoza kwa Tabia isiyojulikana ikiwa pointer haionyeshwi wakati iko nje ya mipaka ya kitu ambacho imeshikamana nacho.
    /// [`add`] inaweza kuboreshwa bora na kwa hivyo inafaa katika nambari nyeti ya utendaji.
    ///
    /// Cheki iliyocheleweshwa inazingatia tu thamani ya pointer ambayo ilionyeshwa, sio maadili ya kati yaliyotumika wakati wa hesabu ya matokeo ya mwisho.
    /// Kwa mfano, `x.wrapping_add(o).wrapping_sub(o)` daima ni sawa na `x`.Kwa maneno mengine, kuacha kitu kilichotengwa na kisha kukiingiza tena baadaye inaruhusiwa.
    ///
    /// Ikiwa unahitaji kuvuka mipaka ya kitu, tupa pointer kwa nambari kamili na ufanye hesabu hapo.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// // Iterate kutumia pointer mbichi katika nyongeza ya vitu viwili
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Mchoro huu unachapisha "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Hukokotoa malipo kutoka kwa kielekezi kwa kutumia hesabu ya kufunga.
    /// (urahisi wa ".kufungia_offset ((hesabu kama isize).wrapping_neg())`)
    ///
    /// `count` iko katika vitengo vya T;km, `count` ya 3 inawakilisha kipangamizi cha pointer cha baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Operesheni yenyewe yenyewe ni salama kila wakati, lakini kutumia pointer inayosababisha sio.
    ///
    /// Kiashiria kinachosababisha kinabaki kushikamana na kitu kile kile kilichotengwa ambacho `self` inaelekeza.
    /// Haiwezi * kutumiwa kufikia kitu tofauti kilichotengwa.Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
    ///
    /// Kwa maneno mengine, `let z = x.wrapping_sub((x as usize) - (y as usize))` haifanyi * `z` sawa na `y` hata ikiwa tunadhani `T` ina saizi `1` na hakuna kufurika: `z` bado imeambatanishwa na kitu `x` kimeambatanishwa, na kukionesha ni Tabia isiyojulikana isipokuwa `x` na `y` inaelekeza kwenye kitu kimoja kilichotengwa.
    ///
    /// Ikilinganishwa na [`sub`], njia hii kimsingi huchelewesha mahitaji ya kukaa ndani ya kitu kimoja kilichotengwa: [`sub`] ni tabia isiyojulikana wakati wa kuvuka mipaka ya kitu;`wrapping_sub` hutoa pointer lakini bado inaongoza kwa Tabia isiyojulikana ikiwa pointer haionyeshwi wakati iko nje ya mipaka ya kitu ambacho imeshikamana nacho.
    /// [`sub`] inaweza kuboreshwa bora na kwa hivyo inafaa katika nambari nyeti ya utendaji.
    ///
    /// Cheki iliyocheleweshwa inazingatia tu thamani ya pointer ambayo ilionyeshwa, sio maadili ya kati yaliyotumika wakati wa hesabu ya matokeo ya mwisho.
    /// Kwa mfano, `x.wrapping_add(o).wrapping_sub(o)` daima ni sawa na `x`.Kwa maneno mengine, kuacha kitu kilichotengwa na kisha kukiingiza tena baadaye inaruhusiwa.
    ///
    /// Ikiwa unahitaji kuvuka mipaka ya kitu, tupa pointer kwa nambari kamili na ufanye hesabu hapo.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// // Iterate kutumia pointer mbichi katika nyongeza ya vitu viwili (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Mchoro huu unachapisha "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Inaweka thamani ya pointer kwa `ptr`.
    ///
    /// Ikiwa `self` ni pointer ya (fat) kwa aina isiyo na ukubwa, operesheni hii itaathiri tu sehemu ya pointer, wakati kwa viashiria vya (thin) kwa aina za ukubwa, hii ina athari sawa na mgawo rahisi.
    ///
    /// Kiashiria kinachosababisha kitakuwa na asili ya `val`, yaani, kwa pointer ya mafuta, operesheni hii ni sawa na kuunda pointer mpya ya mafuta na thamani ya pointer ya data ya `val` lakini metadata ya `self`.
    ///
    ///
    /// # Examples
    ///
    /// Kazi hii ni muhimu kimsingi kwa kuruhusu hesabu ya pointer-busara kwa viashiria vya mafuta:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // itachapisha "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // USALAMA: Ikiwa kuna kiboreshaji nyembamba, shughuli hizi zinafanana
        // kwa mgawo rahisi.
        // Ikiwa kuna pointer ya mafuta, na utekelezwaji wa mpangilio wa kiashiria cha mafuta, uwanja wa kwanza wa pointer kama hiyo kila wakati ni pointer ya data, ambayo pia inapewa.
        //
        unsafe { *thin = val };
        self
    }

    /// Inasoma thamani kutoka kwa `self` bila kuihamisha.
    /// Hii inaacha kumbukumbu katika `self` bila kubadilika.
    ///
    /// Tazama [`ptr::read`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa ``.
        unsafe { read(self) }
    }

    /// Inafanya usomaji dhaifu wa thamani kutoka `self` bila kuisogeza.Hii inaacha kumbukumbu katika `self` bila kubadilika.
    ///
    /// Shughuli tete zinakusudiwa kutekeleza kumbukumbu ya I/O, na zinahakikishiwa kutopuuzwa au kupangwa tena na mkusanyaji katika shughuli zingine za kutatanisha.
    ///
    ///
    /// Tazama [`ptr::read_volatile`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Inasoma thamani kutoka kwa `self` bila kuihamisha.
    /// Hii inaacha kumbukumbu katika `self` bila kubadilika.
    ///
    /// Tofauti na `read`, pointer inaweza kutenganishwa.
    ///
    /// Tazama [`ptr::read_unaligned`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Nakala baiti `count * size_of<T>` kutoka `self` hadi `dest`.
    /// Chanzo na marudio zinaweza kuingiliana.
    ///
    /// NOTE: hii ina mpangilio wa hoja * sawa na [`ptr::copy`].
    ///
    /// Tazama [`ptr::copy`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Nakala baiti `count * size_of<T>` kutoka `self` hadi `dest`.
    /// Chanzo na marudio hayawezi * kuingiliana.
    ///
    /// NOTE: hii ina mpangilio wa hoja * sawa na [`ptr::copy_nonoverlapping`].
    ///
    /// Tazama [`ptr::copy_nonoverlapping`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Nakala baiti `count * size_of<T>` kutoka `src` hadi `self`.
    /// Chanzo na marudio zinaweza kuingiliana.
    ///
    /// NOTE: hii ina mpangilio *wa hoja* ya [`ptr::copy`].
    ///
    /// Tazama [`ptr::copy`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Nakala baiti `count * size_of<T>` kutoka `src` hadi `self`.
    /// Chanzo na marudio hayawezi * kuingiliana.
    ///
    /// NOTE: hii ina mpangilio *wa hoja* ya [`ptr::copy_nonoverlapping`].
    ///
    /// Tazama [`ptr::copy_nonoverlapping`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Hutekeleza uharibifu (ikiwa ipo) ya thamani iliyoelekezwa.
    ///
    /// Tazama [`ptr::drop_in_place`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Huandika mahali pa kumbukumbu na thamani iliyopewa bila kusoma au kushuka kwa thamani ya zamani.
    ///
    ///
    /// Tazama [`ptr::write`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `write`.
        unsafe { write(self, val) }
    }

    /// Inashawishi hesabu kwenye kiashiria kilichoainishwa, ikiweka baiti za kumbukumbu za `count * size_of::<T>()` kuanzia `self` hadi `val`.
    ///
    ///
    /// Tazama [`ptr::write_bytes`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Inafanya uandishi tete wa eneo la kumbukumbu na dhamana iliyopewa bila kusoma au kuacha thamani ya zamani.
    ///
    /// Shughuli tete zinakusudiwa kutekeleza kumbukumbu ya I/O, na zinahakikishiwa kutopuuzwa au kupangwa tena na mkusanyaji katika shughuli zingine za kutatanisha.
    ///
    ///
    /// Tazama [`ptr::write_volatile`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Huandika mahali pa kumbukumbu na thamani iliyopewa bila kusoma au kushuka kwa thamani ya zamani.
    ///
    ///
    /// Tofauti na `write`, pointer inaweza kutenganishwa.
    ///
    /// Tazama [`ptr::write_unaligned`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Inachukua nafasi ya thamani kwa `self` na `src`, kurudisha thamani ya zamani, bila kuacha ama.
    ///
    ///
    /// Tazama [`ptr::replace`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `replace`.
        unsafe { replace(self, src) }
    }

    /// Inabadilisha maadili katika maeneo mawili yanayoweza kubadilika ya aina moja, bila kuondoa mwanzo hata.
    /// Zinaweza kuingiliana, tofauti na `mem::swap` ambayo ni sawa sawa.
    ///
    /// Tazama [`ptr::swap`] kwa wasiwasi na mifano ya usalama.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `swap`.
        unsafe { swap(self, with) }
    }

    /// Hukokotoa mpangilio ambao unahitaji kutumiwa kwa pointer ili kuifanya iwe sawa na `align`.
    ///
    /// Ikiwa haiwezekani kusawazisha pointer, utekelezaji unarudi `usize::MAX`.
    /// Inaruhusiwa kwa utekelezaji kurudi *kila wakati*`usize::MAX`.
    /// Utendaji tu wa algorithm yako unaweza kutegemea kupata pesa inayoweza kutumika hapa, sio usahihi wake.
    ///
    /// Malipo yameonyeshwa kwa idadi ya vitu vya `T`, na sio ka.Thamani iliyorudishwa inaweza kutumika kwa njia ya `wrapping_add`.
    ///
    /// Hakuna dhamana yoyote kwamba kukomesha pointer hakutafurika au kwenda zaidi ya mgao ambao pointer inaelekeza.
    ///
    /// Ni juu ya mpigaji kuhakikisha kuwa malipo yaliyorejeshwa ni sahihi kwa maneno yote isipokuwa mpangilio.
    ///
    /// # Panics
    ///
    /// Kazi panics ikiwa `align` sio nguvu-ya-mbili.
    ///
    /// # Examples
    ///
    /// Kupata `u8` iliyo karibu kama `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // wakati pointer inaweza kuwa iliyokaa kupitia `offset`, ingeelekeza nje ya mgao
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // USALAMA: `align` imechunguzwa kuwa nguvu ya 2 hapo juu
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Hurejesha urefu wa kipande kibichi.
    ///
    /// Thamani iliyorudishwa ni idadi ya vipengee **, sio idadi ya ka.
    ///
    /// Kazi hii ni salama, hata wakati kipande kibichi hakiwezi kutupwa kwa rejeleo la kipande kwa sababu pointer ni batili au haijalinganishwa.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // USALAMA: hii ni salama kwa sababu `*const [T]` na `FatPtr<T>` zina mpangilio sawa.
            // Ni `std` tu inayoweza kutoa dhamana hii.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Hurejesha kielekezi kibichi kwenye bafa ya kipande.
    ///
    /// Hii ni sawa na kutupa `self` hadi `*mut T`, lakini salama zaidi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Hurejesha kiboreshaji mbichi kwa kipengee au sehemu ndogo, bila kuangalia mipaka.
    ///
    /// Kuita njia hii na faharisi isiyo nje ya mipaka au wakati `self` haionyeshwi ni *[tabia isiyojulikana]* hata kama kitambulisho kinachosababisha hakitumiki.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // USALAMA: mpigaji anahakikisha kuwa `self` haiwezi kutolewa na `index` katika mipaka.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Hurejesha `None` ikiwa pointer ni batili, au vinginevyo inarudisha kipande kilichoshirikiwa kwa thamani iliyofungwa katika `Some`.
    /// Kinyume na [`as_ref`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake anayeweza kubadilika angalia [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa *pointer ni NULL* au * yote yafuatayo ni kweli:
    ///
    /// * Kielekezi lazima kiwe [valid] kwa usomaji wa baiti `ptr.len() * mem::size_of::<T>()` nyingi, na lazima iwe iliyokaa sawa.Hii inamaanisha haswa:
    ///
    ///     * Upeo mzima wa kumbukumbu ya kipande hiki lazima iwe ndani ya kitu kimoja kilichotengwa!
    ///       Vipande haviwezi kupita kwenye vitu vingi vilivyotengwa.
    ///
    ///     * Kielekezi lazima kiwe sawa hata kwa vipande vya urefu wa sifuri.
    ///     Sababu moja ya hii ni kwamba uboreshaji wa mpangilio wa enum unaweza kutegemea marejeleo (pamoja na vipande vya urefu wowote) zikiwa zimepangiliwa na zisizo za kutofautisha kuzitofautisha na data zingine.
    ///
    ///     Unaweza kupata pointer inayoweza kutumika kama `data` kwa vipande vya urefu wa sifuri ukitumia [`NonNull::dangling()`].
    ///
    /// * Ukubwa wa jumla ya kipande `ptr.len() * mem::size_of::<T>()` lazima isiwe kubwa kuliko `isize::MAX`.
    ///   Tazama nyaraka za usalama za [`pointer::offset`].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kubadilishwa (isipokuwa ndani ya `UnsafeCell`).
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// Tazama pia [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Hurejesha `None` ikiwa pointer ni batili, au vinginevyo inarudisha kipande cha kipekee kwa thamani iliyofungwa katika `Some`.
    /// Kinyume na [`as_mut`], hii haihitaji kwamba thamani inapaswa kuzinduliwa.
    ///
    /// Kwa mwenzake wa pamoja angalia [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Wakati wa kuita njia hii, lazima uhakikishe kuwa *pointer ni NULL* au * yote yafuatayo ni kweli:
    ///
    /// * Kielekezi lazima kiwe [valid] kwa usomaji na aandike kwa `ptr.len() * mem::size_of::<T>()` ka nyingi, na lazima iwe iliyokaa sawa.Hii inamaanisha haswa:
    ///
    ///     * Upeo mzima wa kumbukumbu ya kipande hiki lazima iwe ndani ya kitu kimoja kilichotengwa!
    ///       Vipande haviwezi kupita kwenye vitu vingi vilivyotengwa.
    ///
    ///     * Kielekezi lazima kiwe sawa hata kwa vipande vya urefu wa sifuri.
    ///     Sababu moja ya hii ni kwamba uboreshaji wa mpangilio wa enum unaweza kutegemea marejeleo (pamoja na vipande vya urefu wowote) zikiwa zimepangiliwa na zisizo za kutofautisha kuzitofautisha na data zingine.
    ///
    ///     Unaweza kupata pointer inayoweza kutumika kama `data` kwa vipande vya urefu wa sifuri ukitumia [`NonNull::dangling()`].
    ///
    /// * Ukubwa wa jumla ya kipande `ptr.len() * mem::size_of::<T>()` lazima isiwe kubwa kuliko `isize::MAX`.
    ///   Tazama nyaraka za usalama za [`pointer::offset`].
    ///
    /// * Lazima utekeleze sheria za kujipendekeza za Rust, kwani maisha ya kurudi `'a` yamechaguliwa kiholela na haionyeshi wakati halisi wa data.
    ///   Hasa, kwa muda wa maisha haya, kumbukumbu inayoelekeza pointer haipaswi kupatikana (kusoma au kuandikwa) kupitia pointer nyingine yoyote.
    ///
    /// Hii inatumika hata ikiwa matokeo ya njia hii hayatumiki!
    ///
    /// Tazama pia [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Usawa wa viashiria
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}