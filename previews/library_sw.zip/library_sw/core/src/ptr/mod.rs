//! Simamia mwenyewe kumbukumbu kupitia viashiria mbichi.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Kazi nyingi katika moduli hii huchukua viashiria mbichi kama hoja na kuzisoma kutoka au kuziandikia.Ili hii iwe salama, viashiria hivi lazima viwe *halali*.
//! Ikiwa pointer ni halali inategemea operesheni ambayo hutumiwa (soma au andika), na kiwango cha kumbukumbu kinachopatikana (kwa mfano, ni kaiti ngapi read/written).
//! Kazi nyingi hutumia `*mut T` na `* const T` kufikia dhamana moja tu, katika hali hiyo nyaraka zinaacha saizi na inachukulia kuwa ni baiti za `size_of::<T>()`.
//!
//! Sheria sahihi za uhalali bado hazijaamuliwa.Dhamana ambazo hutolewa wakati huu ni ndogo sana:
//!
//! * Kiashiria cha [null] ni *kamwe* halali, hata kwa ufikiaji wa [size zero][zst].
//! * Ili pointer iwe halali, inahitajika, lakini haitoshi kila wakati, kwamba pointer inaweza kuwa "isiyoweza kuhesabiwa *: safu ya kumbukumbu ya saizi iliyopewa inayoanzia pointer lazima yote iwe ndani ya mipaka ya kitu kimoja kilichotengwa.
//!
//! Kumbuka kuwa katika Rust, kila anuwai ya (stack-allocated) inachukuliwa kuwa kitu tofauti kilichotengwa.
//! * Hata kwa shughuli za [size zero][zst], pointer haipaswi kuelekeza kwenye kumbukumbu iliyosambazwa, kwa hivyo, uhamishaji hufanya viashiria kuwa batili hata kwa shughuli za ukubwa wa sifuri.
//! Walakini, kutupa nambari yoyote isiyo ya sifuri *halisi* kwa kiboreshaji ni halali kwa ufikiaji wa ukubwa wa sifuri, hata ikiwa kumbukumbu fulani inapatikana katika anwani hiyo na inasambazwa.
//! Hii inalingana na kuandika mtengaji wako mwenyewe: kutenga vitu vyenye ukubwa wa sifuri sio ngumu sana.
//! Njia ya kisheria ya kupata pointer ambayo ni halali kwa ufikiaji wa saizi ni [`NonNull::dangling`].
//! * Ufikiaji wote uliofanywa na kazi kwenye moduli hii ni *isiyo ya atomiki* kwa maana ya [atomic operations] inayotumiwa kusawazisha kati ya nyuzi.
//! Hii inamaanisha kuwa ni tabia isiyoelezewa kufanya ufikiaji wa wakati mmoja kwa eneo moja kutoka kwa nyuzi tofauti isipokuwa ikiwa wote wanapata kusoma tu kutoka kwa kumbukumbu.
//! Kumbuka kuwa hii ni pamoja na [`read_volatile`] na [`write_volatile`]: Ufikiaji dhaifu hauwezi kutumiwa kwa usawazishaji wa baina ya baina.
//! * Matokeo ya kutuma rejeleo kwa kiashiria ni halali kwa muda mrefu ikiwa kitu cha msingi ni cha moja kwa moja na hakuna kumbukumbu (viashiria tu mbichi) hutumiwa kupata kumbukumbu ile ile.
//!
//! Axioms hizi, pamoja na matumizi makini ya [`offset`] kwa hesabu ya pointer, zinatosha kutekeleza kwa usahihi vitu vingi muhimu katika nambari isiyo salama.
//! Dhamana kali zitatolewa mwishowe, kwani sheria za [aliasing] zinaamuliwa.
//! Kwa habari zaidi, angalia [book] na vile vile sehemu katika kumbukumbu iliyotolewa kwa [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Viashiria halali kama ilivyoelezwa hapo juu sio lazima vilinganishwe vizuri (ambapo mpangilio wa "proper" hufafanuliwa na aina ya pointee, yaani, `*const T` lazima iwe iliyokaa na `mem::align_of::<T>()`).
//! Walakini, kazi nyingi zinahitaji hoja zao zilinganishwe vizuri, na zitaelezea wazi mahitaji haya katika nyaraka zao.
//! Isipokuwa maarufu kwa hii ni [`read_unaligned`] na [`write_unaligned`].
//!
//! Wakati kazi inahitaji usawa sawa, inafanya hivyo hata ikiwa ufikiaji una saizi 0, yaani, hata ikiwa kumbukumbu haiguswi.Fikiria kutumia [`NonNull::dangling`] katika hali kama hizo.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Hutekeleza uharibifu (ikiwa ipo) ya thamani iliyoelekezwa.
///
/// Hii ni sawa na kupiga [`ptr::read`] na kutupa matokeo, lakini ina faida zifuatazo:
///
/// * Inahitajika * kutumia `drop_in_place` kuacha aina ambazo hazina ukubwa kama vile vitu vya trait, kwa sababu haziwezi kusomwa kwenye gombo na kudondoshwa kawaida.
///
/// * Ni rafiki kwa optimizer kufanya hii zaidi ya [`ptr::read`] wakati wa kuacha kumbukumbu iliyotengwa kwa mikono (kwa mfano, katika utekelezaji wa `Box`/`Rc`/`Vec`), kwani mkusanyaji haitaji kudhibitisha kuwa ni sauti ya kutumia tena nakala.
///
///
/// * Inaweza kutumiwa kuacha data ya [pinned] wakati `T` sio `repr(packed)` (data iliyobandikwa haipaswi kuhamishwa kabla ya kudondoshwa).
///
/// Thamani ambazo hazijapangiliwa haziwezi kudondoshwa mahali, lazima zinakiliwe kwa eneo lililopangwa kwanza kwa kutumia [`ptr::read_unaligned`].Kwa ujenzi uliojaa, hoja hii hufanywa kiatomati na mkusanyaji.
/// Hii inamaanisha uwanja wa maeneo yaliyojaa haujashushwa mahali.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `to_drop` lazima iwe [valid] kwa wasomaji wote na wanaandika.
///
/// * `to_drop` lazima iwe iliyokaa sawa.
///
/// * Thamani ya `to_drop` inabidi iwe halali kwa kuacha, ambayo inaweza kumaanisha lazima itekeleze vizazi vya ziada, hii inategemea aina.
///
/// Kwa kuongezea, ikiwa `T` sio [`Copy`], kutumia thamani iliyoelekezwa baada ya kupiga simu `drop_in_place` kunaweza kusababisha tabia isiyojulikana.Kumbuka kuwa `*to_drop = foo` inahesabu kama matumizi kwa sababu itasababisha thamani kuteremshwa tena.
/// [`write()`] inaweza kutumiwa kuandika data bila kuishusha.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima iwe isiyo ya NULL na iliyokaa sawa.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ondoa kipengee cha mwisho kutoka kwa vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Pata pointer mbichi kwa kipengee cha mwisho katika `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Fupisha `v` ili kuzuia kipengee cha mwisho kuteremshwa.
///     // Tunafanya hivyo kwanza, kuzuia maswala ikiwa `drop_in_place` chini ya panics.
///     v.set_len(1);
///     // Bila simu `drop_in_place`, kipengee cha mwisho hakiwezi kamwe kutolewa, na kumbukumbu inayoweza kusimamia ingevuja.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Hakikisha kuwa kipengee cha mwisho kiliachwa.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Ona kuwa mkusanyaji hufanya nakala hii kiatomati wakati wa kuacha vitu vilivyojaa, kwa mfano, sio kawaida kuwa na wasiwasi juu ya maswala kama hayo isipokuwa utapiga simu kwa `drop_in_place` kwa mikono.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Nambari hapa haijalishi, hii inabadilishwa na gundi halisi ya kushuka na mkusanyaji.
    //

    // USALAMA: angalia maoni hapo juu
    unsafe { drop_in_place(to_drop) }
}

/// Inaunda pointer isiyofaa.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Inaunda pointer mbichi isiyoweza kubadilika.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Uingizaji wa mwongozo unahitajika ili kuepuka kufungwa kwa `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Uingizaji wa mwongozo unahitajika ili kuepuka kufungwa kwa `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Inaunda kipande kibichi kutoka kwa pointer na urefu.
///
/// Hoja ya `len` ni idadi ya vitu **, sio idadi ya ka.
///
/// Kazi hii ni salama, lakini kwa kweli kutumia dhamana ya kurudi sio salama.
/// Tazama nyaraka za [`slice::from_raw_parts`] kwa mahitaji ya usalama wa kipande.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // tengeneza pointer ya kipande wakati unapoanza na kiboreshaji cha kipengee cha kwanza
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // USALAMA: Kupata thamani kutoka kwa umoja wa `Repr` ni salama kwani * const [T]
        //
        // na FatPtr wana mipangilio sawa ya kumbukumbu.std tu ndio inaweza kufanya dhamana hii.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Inafanya utendaji sawa na [`slice_from_raw_parts`], isipokuwa kwamba kipande kibichi kinachoweza kubadilishwa kinarudishwa, kinyume na kipande kibichi kisichobadilika.
///
///
/// Tazama nyaraka za [`slice_from_raw_parts`] kwa maelezo zaidi.
///
/// Kazi hii ni salama, lakini kwa kweli kutumia dhamana ya kurudi sio salama.
/// Tazama nyaraka za [`slice::from_raw_parts_mut`] kwa mahitaji ya usalama wa kipande.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // mpe thamani kwenye faharisi kwenye kipande
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // USALAMA: Kupata thamani kutoka kwa umoja wa `Repr` ni salama kwani * mut [T]
        // na FatPtr wana mipangilio sawa ya kumbukumbu
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Inabadilisha maadili katika maeneo mawili yanayoweza kubadilika ya aina moja, bila kuondoa mwanzo hata.
///
/// Lakini kwa tofauti mbili zifuatazo, kazi hii ni sawa na [`mem::swap`]:
///
///
/// * Inafanya kazi kwa viashiria mbichi badala ya marejeleo.
/// Wakati marejeleo yanapatikana, [`mem::swap`] inapaswa kupendelewa.
///
/// * Thamani mbili zilizoelekezwa zinaweza kuingiliana.
/// Ikiwa maadili yanaingiliana, basi eneo linaloingiliana la kumbukumbu kutoka `x` litatumika.
/// Hii imeonyeshwa katika mfano wa pili hapa chini.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * Zote `x` na `y` lazima ziwe [valid] kwa wasomaji wote na wanaandika.
///
/// * Zote `x` na `y` lazima zilinganishwe vizuri.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, viashiria lazima visiwe vya NULL na vilinganishwe vizuri.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kubadilisha mikoa miwili isiyoingiliana:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // hii ni `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // hii ni `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Kubadilisha mikoa miwili inayoingiliana:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // hii ni `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // hii ni `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Fahirisi `1..3` ya kipande huingiliana kati ya `x` na `y`.
///     // Matokeo ya busara yatakuwa kwao `[2, 3]`, ili fahirisi `0..3` ni `[1, 2, 3]` (inayolingana na `y` kabla ya `swap`);au kwao wawe `[0, 1]` ili fahirisi `1..4` ziwe `[0, 1, 2]` (zinazofanana na `x` kabla ya `swap`).
/////
///     // Utekelezaji huu umefafanuliwa kufanya chaguo la mwisho.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Jipe nafasi ya mwanzo ya kufanya kazi nayo.
    // Hatupaswi kuwa na wasiwasi juu ya matone: `MaybeUninit` haifanyi chochote wakati imeshuka.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Fanya ubadilishaji USALAMA: mpigaji lazima ahakikishe kuwa `x` na `y` ni halali kwa uandishi na iliyokaa sawa.
    // `tmp` haiwezi kuingiliana ama `x` au `y` kwa sababu `tmp` ilitengwa tu kwenye ghala kama kitu tofauti kilichotengwa.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` na `y` inaweza kuingiliana
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Inabadilisha baiti za `count * size_of::<T>()` kati ya mikoa miwili ya kumbukumbu inayoanzia `x` na `y`.
/// Mikoa miwili lazima * isiingiliane.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * Zote `x` na `y` lazima ziwe [valid] kwa wasomaji wote na wanaandika ya `count *
///   saizi_ya: :<T>() `ka.
///
/// * Zote `x` na `y` lazima zilinganishwe vizuri.
///
/// * Eneo la kumbukumbu linaloanza saa `x` na saizi ya `count *
///   saizi_ya: :<T>() "baiti haipaswi * kuingiliana na eneo la kumbukumbu linaloanza saa `y` na saizi sawa.
///
/// Kumbuka kuwa hata ikiwa saizi iliyonakiliwa vyema (`count * size_of: :<T>()") ni `0`, viashiria lazima visivyo vya NULL na vikiwa sawa.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // USALAMA: mpigaji lazima ahakikishe kuwa `x` na `y` ni
    // halali kwa maandishi na iliyokaa vizuri.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Kwa aina ndogo kuliko uboreshaji wa vizuizi hapa chini, badilisha tu moja kwa moja ili kuepuka kudharau codegen
    //
    if mem::size_of::<T>() < 32 {
        // USALAMA: mpigaji lazima ahakikishe kuwa `x` na `y` ni halali
        // kwa anaandika, iliyokaa vizuri, na isiyoingiliana.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Njia hapa ni kutumia simd kubadilisha x&y kwa ufanisi.
    // Upimaji unaonyesha kuwa kubadilisha baiti 32 au ka 64 kwa wakati ni bora zaidi kwa wasindikaji wa Intel Haswell E.
    // LLVM ina uwezo zaidi wa kuboresha ikiwa tunatoa muundo wa #[repr(simd)], hata ikiwa hatutumii muundo huu moja kwa moja.
    //
    //
    // FIXME repr(simd) imevunjwa kwenye emscripten na redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop kupitia x&y, kunakili `Block` kwa wakati Optizer inapaswa kufungua kitanzi kikamilifu kwa aina nyingi NB
    // Hatuwezi kutumia kitanzi kwani `range` impl inaita `mem::swap` mara kwa mara
    //
    let mut i = 0;
    while i + block_size <= len {
        // Unda kumbukumbu isiyojulikana kama nafasi ya mwanzo Kutangaza `t` hapa inaepuka kuweka sawa wakati kitanzi hiki hakitumiki
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // USALAMA: Kama `i < len`, na kama mpigaji lazima ahakikishe kuwa `x` na `y` ni halali
        // kwa baiti `len`, `x + i` na `y + i` lazima ziwe anwani halali, ambazo zinatimiza mkataba wa usalama wa `add`.
        //
        // Pia, mpigaji lazima ahakikishe kuwa `x` na `y` ni halali kwa kuandika, iliyokaa vizuri, na isiyoingiliana, ambayo inatimiza mkataba wa usalama wa `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Badili kizuizi cha baiti ya x&y, ukitumia t kama bafa ya muda Hii inapaswa kuboreshwa katika utendaji mzuri wa SIMD inapopatikana
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Badilisha byte yoyote iliyobaki
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // USALAMA: angalia maoni ya zamani ya usalama.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Husogeza `src` kwenye `dst` iliyoelekezwa, na kurudisha thamani ya awali ya `dst`.
///
/// Thamani yoyote haijashushwa.
///
/// Kazi hii ni sawa na [`mem::replace`] isipokuwa inafanya kazi kwenye viashiria mbichi badala ya marejeleo.
/// Wakati marejeleo yanapatikana, [`mem::replace`] inapaswa kupendelewa.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `dst` lazima iwe [valid] kwa wasomaji wote na wanaandika.
///
/// * `dst` lazima iwe iliyokaa sawa.
///
/// * `dst` lazima ionyeshe thamani iliyoanzishwa vizuri ya aina `T`.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima iwe isiyo ya NULL na iliyokaa sawa.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ingekuwa na athari sawa bila kuhitaji kizuizi kisicho salama.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // USALAMA: mpigaji lazima ahakikishe kuwa `dst` ni halali kuwa
    // tuma kwa rejeleo linaloweza kubadilika (halali kwa kuandika, iliyokaa, iliyowekwa awali), na haiwezi kuingiliana na `src` kwani `dst` lazima ielekeze kwa kitu kilichotengwa tofauti.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // haiwezi kuingiliana
    }
    src
}

/// Inasoma thamani kutoka kwa `src` bila kuihamisha.Hii inaacha kumbukumbu katika `src` bila kubadilika.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `src` lazima iwe [valid] kwa usomaji.
///
/// * `src` lazima iwe iliyokaa sawa.Tumia [`read_unaligned`] ikiwa sio hivyo.
///
/// * `src` lazima ionyeshe thamani iliyoanzishwa vizuri ya aina `T`.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima iwe isiyo ya NULL na iliyokaa sawa.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Tumia mwenyewe [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Unda nakala ya thamani kidogo kwa `a` katika `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kutoka wakati huu (ama kwa kurudisha wazi au kwa kupiga kazi ambayo panics) itasababisha thamani katika `tmp` kushushwa wakati thamani ile ile bado inatajwa na `a`.
///         // Hii inaweza kusababisha tabia isiyojulikana ikiwa `T` sio `Copy`.
/////
/////
///
///         // Unda nakala ya thamani kidogo kwa `b` katika `a`.
///         // Hii ni salama kwa sababu marejeleo yanayoweza kubadilika hayawezi jina.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kama ilivyo hapo juu, kutoka hapa kunaweza kusababisha tabia isiyojulikana kwa sababu thamani hiyo hiyo inarejelewa na `a` na `b`.
/////
///
///         // Sogeza `tmp` hadi `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` imehamishwa (`write` inamiliki hoja yake ya pili), kwa hivyo hakuna kitu kinachotupwa kabisa hapa.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Umiliki wa Thamani Iliyorejeshwa
///
/// `read` huunda nakala kidogo ya `T`, bila kujali kama `T` ni [`Copy`].
/// Ikiwa `T` sio [`Copy`], kutumia thamani iliyorudishwa na thamani ya `*src` inaweza kukiuka usalama wa kumbukumbu.
/// Kumbuka kuwa kupeana hesabu za `*src` kama matumizi kwa sababu itajaribu kushusha thamani kwa `* src`.
///
/// [`write()`] inaweza kutumiwa kuandika data bila kuishusha.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` sasa inazungumzia kumbukumbu sawa ya msingi kama `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Kukabidhiwa `s2` husababisha thamani yake ya asili kushushwa.
///     // Zaidi ya hatua hii, `s` haipaswi kutumiwa tena, kwani kumbukumbu ya msingi imeachiliwa.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Kukabidhiwa `s` kungesababisha thamani ya zamani kushushwa tena, na kusababisha tabia isiyojulikana.
/////
///     // s= String::from("bar");//KOSA
///
///     // `ptr::write` inaweza kutumiwa kuandika thamani bila kuiacha.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // USALAMA: mpigaji lazima ahakikishe kuwa `src` ni halali kwa kusoma.
    // `src` haiwezi kuingiliana na `tmp` kwa sababu `tmp` ilitengwa tu kwenye ghala kama kitu tofauti kilichotengwa.
    //
    //
    // Pia, kwa kuwa tuliandika tu dhamana halali katika `tmp`, inahakikishiwa kuanza vizuri.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Inasoma thamani kutoka kwa `src` bila kuihamisha.Hii inaacha kumbukumbu katika `src` bila kubadilika.
///
/// Tofauti na [`read`], `read_unaligned` inafanya kazi na viashiria visivyo na mpangilio.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `src` lazima iwe [valid] kwa usomaji.
///
/// * `src` lazima ionyeshe thamani iliyoanzishwa vizuri ya aina `T`.
///
/// Kama [`read`], `read_unaligned` inaunda nakala kidogo ya `T`, bila kujali kama `T` ni [`Copy`].
/// Ikiwa `T` sio [`Copy`], kwa kutumia thamani iliyorudishwa na thamani ya `*src` inaweza [violate memory safety][read-ownership].
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima isiwe NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Kwenye `packed` structs
///
/// Hivi sasa haiwezekani kuunda viashiria mbichi kwa sehemu zisizo na muundo wa muundo uliojaa.
///
/// Kujaribu kuunda kiboreshaji mbichi kwenye uwanja wa muundo wa `unaligned` na usemi kama `&packed.unaligned as *const FieldType` huunda rejeleo la kati lisilo na saini kabla ya kuibadilisha kuwa pointer mbichi.
///
/// Kwamba rejeleo hili ni la muda na kutupwa mara moja sio muhimu kwani mkusanyaji kila wakati anatarajia marejeleo yalinganishwe vizuri.
/// Kama matokeo, kutumia `&packed.unaligned as *const FieldType` husababisha tabia ya haraka* isiyojulikana katika programu yako.
///
/// Mfano wa nini usifanye na jinsi hii inahusiana na `read_unaligned` ni:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hapa tunajaribu kuchukua anwani ya nambari 32-bit ambayo haijalingana.
///     let unaligned =
///         // Marejeleo ya muda ambayo hayajasainiwa yameundwa hapa ambayo husababisha tabia isiyojulikana bila kujali ikiwa rejea inatumika au la.
/////
///         &packed.unaligned
///         // Kutupa kwa pointer mbichi hakusaidii;kosa tayari limetokea.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Kufikia sehemu zisizo na mpangilio moja kwa moja na mfano `packed.unaligned` ni salama hata hivyo.
///
///
///
///
///
///
// FIXME: Sasisha hati kulingana na matokeo ya RFC #2582 na marafiki.
/// # Examples
///
/// Soma thamani ya usize kutoka bafa ya baiti:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // USALAMA: mpigaji lazima ahakikishe kuwa `src` ni halali kwa kusoma.
    // `src` haiwezi kuingiliana na `tmp` kwa sababu `tmp` ilitengwa tu kwenye ghala kama kitu tofauti kilichotengwa.
    //
    //
    // Pia, kwa kuwa tuliandika tu dhamana halali katika `tmp`, inahakikishiwa kuanza vizuri.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Huandika mahali pa kumbukumbu na thamani iliyopewa bila kusoma au kushuka kwa thamani ya zamani.
///
/// `write` haitoi yaliyomo ya `dst`.
/// Hii ni salama, lakini inaweza kuvuja mgao au rasilimali, kwa hivyo utunzaji unapaswa kuchukuliwa kutobadilisha kitu ambacho kinapaswa kutolewa.
///
///
/// Kwa kuongeza, haitoi `src`.Kimantiki, `src` inahamishiwa katika eneo lililoelekezwa na `dst`.
///
/// Hii ni sawa kwa kuanzisha kumbukumbu isiyojulikana, au kuandika kumbukumbu ambayo hapo awali ilikuwa [`read`] kutoka.
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `dst` lazima iwe [valid] ya kuandika.
///
/// * `dst` lazima iwe iliyokaa sawa.Tumia [`write_unaligned`] ikiwa sio hivyo.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima iwe isiyo ya NULL na iliyokaa sawa.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Tumia mwenyewe [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Unda nakala ya thamani kidogo kwa `a` katika `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kutoka wakati huu (ama kwa kurudisha wazi au kwa kupiga kazi ambayo panics) itasababisha thamani katika `tmp` kushushwa wakati thamani ile ile bado inatajwa na `a`.
///         // Hii inaweza kusababisha tabia isiyojulikana ikiwa `T` sio `Copy`.
/////
/////
///
///         // Unda nakala ya thamani kidogo kwa `b` katika `a`.
///         // Hii ni salama kwa sababu marejeleo yanayoweza kubadilika hayawezi jina.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kama ilivyo hapo juu, kutoka hapa kunaweza kusababisha tabia isiyojulikana kwa sababu thamani hiyo hiyo inarejelewa na `a` na `b`.
/////
///
///         // Sogeza `tmp` hadi `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` imehamishwa (`write` inamiliki hoja yake ya pili), kwa hivyo hakuna kitu kinachotupwa kabisa hapa.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Tunatoa wito kwa wahusika moja kwa moja ili kuzuia simu za kazi katika nambari iliyotengenezwa kwani `intrinsics::copy_nonoverlapping` ni kazi ya kufunika.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // USALAMA: mpigaji lazima ahakikishe kuwa `dst` ni halali kwa kuandika.
    // `dst` haiwezi kuingiliana na `src` kwa sababu mpigaji ana uwezo wa kufikia `dst` wakati `src` inamilikiwa na kazi hii.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Huandika mahali pa kumbukumbu na thamani iliyopewa bila kusoma au kushuka kwa thamani ya zamani.
///
/// Tofauti na [`write()`], pointer inaweza kutenganishwa.
///
/// `write_unaligned` haitoi yaliyomo ya `dst`.Hii ni salama, lakini inaweza kuvuja mgao au rasilimali, kwa hivyo utunzaji unapaswa kuchukuliwa kutobadilisha kitu ambacho kinapaswa kutolewa.
///
/// Kwa kuongeza, haitoi `src`.Kimantiki, `src` inahamishiwa katika eneo lililoelekezwa na `dst`.
///
/// Hii ni sawa kwa kuanzisha kumbukumbu isiyojulikana, au kuandika kumbukumbu ambayo hapo awali ilisomwa na [`read_unaligned`].
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `dst` lazima iwe [valid] ya kuandika.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima isiwe NULL.
///
/// [valid]: self#safety
///
/// ## Kwenye `packed` structs
///
/// Hivi sasa haiwezekani kuunda viashiria mbichi kwa sehemu zisizo na muundo wa muundo uliojaa.
///
/// Kujaribu kuunda kiboreshaji mbichi kwenye uwanja wa muundo wa `unaligned` na usemi kama `&packed.unaligned as *const FieldType` huunda rejeleo la kati lisilo na saini kabla ya kuibadilisha kuwa pointer mbichi.
///
/// Kwamba rejeleo hili ni la muda na kutupwa mara moja sio muhimu kwani mkusanyaji kila wakati anatarajia marejeleo yalinganishwe vizuri.
/// Kama matokeo, kutumia `&packed.unaligned as *const FieldType` husababisha tabia ya haraka* isiyojulikana katika programu yako.
///
/// Mfano wa nini usifanye na jinsi hii inahusiana na `write_unaligned` ni:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hapa tunajaribu kuchukua anwani ya nambari 32-bit ambayo haijalingana.
///     let unaligned =
///         // Marejeleo ya muda ambayo hayajasainiwa yameundwa hapa ambayo husababisha tabia isiyojulikana bila kujali ikiwa rejea inatumika au la.
/////
///         &mut packed.unaligned
///         // Kutupa kwa pointer mbichi hakusaidii;kosa tayari limetokea.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Kufikia sehemu zisizo na mpangilio moja kwa moja na mfano `packed.unaligned` ni salama hata hivyo.
///
///
///
///
///
///
///
///
///
// FIXME: Sasisha hati kulingana na matokeo ya RFC #2582 na marafiki.
/// # Examples
///
/// Andika thamani ya usize kwa bafa ya baiti:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // USALAMA: mpigaji lazima ahakikishe kuwa `dst` ni halali kwa kuandika.
    // `dst` haiwezi kuingiliana na `src` kwa sababu mpigaji ana uwezo wa kufikia `dst` wakati `src` inamilikiwa na kazi hii.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Tunapigia simu ya ndani moja kwa moja ili kuzuia simu za kazi katika nambari iliyotengenezwa.
        intrinsics::forget(src);
    }
}

/// Inafanya usomaji dhaifu wa thamani kutoka `src` bila kuisogeza.Hii inaacha kumbukumbu katika `src` bila kubadilika.
///
/// Shughuli tete zinakusudiwa kutekeleza kumbukumbu ya I/O, na zinahakikishiwa kutopuuzwa au kupangwa tena na mkusanyaji katika shughuli zingine za kutatanisha.
///
/// # Notes
///
/// Rust kwa sasa haina mfano wa kumbukumbu kwa ukali na rasmi, kwa hivyo semantiki sahihi ya kile "volatile" inamaanisha hapa inaweza kubadilika kwa muda.
/// Hiyo inasemwa, semantiki karibu kila wakati itaishia kufanana na [C11's definition of volatile][c11].
///
/// Mkusanyaji haipaswi kubadilisha mpangilio wa jamaa au idadi ya shughuli za kumbukumbu tete.
/// Walakini, shughuli za kumbukumbu tete kwenye aina zenye ukubwa wa sifuri (kwa mfano, ikiwa aina ya ukubwa wa sifuri imepitishwa kwa `read_volatile`) ni noops na inaweza kupuuzwa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `src` lazima iwe [valid] kwa usomaji.
///
/// * `src` lazima iwe iliyokaa sawa.
///
/// * `src` lazima ionyeshe thamani iliyoanzishwa vizuri ya aina `T`.
///
/// Kama [`read`], `read_volatile` inaunda nakala kidogo ya `T`, bila kujali kama `T` ni [`Copy`].
/// Ikiwa `T` sio [`Copy`], kwa kutumia thamani iliyorudishwa na thamani ya `*src` inaweza [violate memory safety][read-ownership].
/// Walakini, kuhifadhi aina ambazo sio ["Nakili"] katika kumbukumbu tete hakika sio sahihi.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima iwe isiyo ya NULL na iliyokaa sawa.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Kama ilivyo kwa C, ikiwa operesheni ni tete haina maana yoyote kwa maswali yanayohusu ufikiaji wa wakati mmoja kutoka kwa nyuzi nyingi.Ufikiaji dhaifu hutenda haswa kama ufikiaji usio wa atomiki katika suala hilo.
///
/// Hasa, mbio kati ya `read_volatile` na operesheni yoyote ya uandishi katika eneo moja ni tabia isiyojulikana.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Sio kuhofia kuweka athari ya codegen ndogo.
        abort();
    }
    // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Inafanya uandishi tete wa eneo la kumbukumbu na dhamana iliyopewa bila kusoma au kuacha thamani ya zamani.
///
/// Shughuli tete zinakusudiwa kutekeleza kumbukumbu ya I/O, na zinahakikishiwa kutopuuzwa au kupangwa tena na mkusanyaji katika shughuli zingine za kutatanisha.
///
/// `write_volatile` haitoi yaliyomo ya `dst`.Hii ni salama, lakini inaweza kuvuja mgao au rasilimali, kwa hivyo utunzaji unapaswa kuchukuliwa kutobadilisha kitu ambacho kinapaswa kutolewa.
///
/// Kwa kuongeza, haitoi `src`.Kimantiki, `src` inahamishiwa katika eneo lililoelekezwa na `dst`.
///
/// # Notes
///
/// Rust kwa sasa haina mfano wa kumbukumbu kwa ukali na rasmi, kwa hivyo semantiki sahihi ya kile "volatile" inamaanisha hapa inaweza kubadilika kwa muda.
/// Hiyo inasemwa, semantiki karibu kila wakati itaishia kufanana na [C11's definition of volatile][c11].
///
/// Mkusanyaji haipaswi kubadilisha mpangilio wa jamaa au idadi ya shughuli za kumbukumbu tete.
/// Walakini, shughuli za kumbukumbu tete kwenye aina zenye ukubwa wa sifuri (kwa mfano, ikiwa aina ya ukubwa wa sifuri imepitishwa kwa `write_volatile`) ni noops na inaweza kupuuzwa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tabia haijulikani ikiwa yoyote ya masharti yafuatayo yamekiukwa:
///
/// * `dst` lazima iwe [valid] ya kuandika.
///
/// * `dst` lazima iwe iliyokaa sawa.
///
/// Kumbuka kuwa hata ikiwa `T` ina saizi `0`, pointer lazima iwe isiyo ya NULL na iliyokaa sawa.
///
/// [valid]: self#safety
///
/// Kama ilivyo kwa C, ikiwa operesheni ni tete haina maana yoyote kwa maswali yanayohusu ufikiaji wa wakati mmoja kutoka kwa nyuzi nyingi.Ufikiaji dhaifu hutenda haswa kama ufikiaji usio wa atomiki katika suala hilo.
///
/// Hasa, mbio kati ya `write_volatile` na operesheni nyingine yoyote (kusoma au kuandika) kwenye eneo moja ni tabia isiyojulikana.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Sio kuhofia kuweka athari ya codegen ndogo.
        abort();
    }
    // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Panga kiashiria `p`.
///
/// Piga hesabu (kulingana na vitu vya hatua ya `stride`) ambayo inapaswa kutumiwa kwa kiashiria `p` ili pointer `p` iwe sawa na `a`.
///
/// Note: Utekelezaji huu umetengenezwa kwa uangalifu na sio panic.Ni UB kwa hii hadi panic.
/// Mabadiliko tu ya kweli ambayo yanaweza kufanywa hapa ni mabadiliko ya `INV_TABLE_MOD_16` na vipindi vinavyohusiana.
///
/// Ikiwa tutaamua kufanya iwezekane kupiga simu ya ndani na `a` ambayo sio nguvu ya mbili, pengine itakuwa busara zaidi kubadilika tu kuwa utekelezaji wa ujinga badala ya kujaribu kurekebisha hii ili kutoshea mabadiliko hayo.
///
///
/// Maswali yoyote nenda kwa@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Matumizi ya moja kwa moja ya maumbile haya inaboresha codegen kwa kiwango kikubwa katika kiwango cha kuchagua <=
    // 1, ambapo matoleo ya njia za shughuli hizi hazijawekwa.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Hesabu upinduaji wa msimu wa kuzidisha wa `x` modulo `m`.
    ///
    /// Utekelezaji huu umekusudiwa `align_offset` na ina masharti yafuatayo:
    ///
    /// * `m` ni nguvu-ya-mbili;
    /// * `x < m`; (ikiwa `x ≥ m`, pitisha kwa `x % m` badala yake)
    ///
    /// Utekelezaji wa kazi hii hautakuwa panic.Milele.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Jedwali la mabadiliko ya moduli ya moduli 2ulo=16.
        ///
        /// Kumbuka, kwamba meza hii haina maadili ambapo inverse haipo (yaani, kwa `0⁻¹ mod 16`, `2⁻¹ mod 16`, n.k.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo ambayo `INV_TABLE_MOD_16` imekusudiwa.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // USALAMA: `m` inahitajika kuwa nguvu ya mbili, kwa hivyo isiyo sifuri.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Tunapunguza "up" kwa kutumia fomula ifuatayo:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // hadi 2²ⁿ ≥ m.Basi tunaweza kupunguza kwa `m` yetu inayotakikana kwa kuchukua matokeo `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Kumbuka, kwamba tunatumia shughuli za kufunika hapa kwa makusudi-fomula asili hutumia kwa mfano, kutoa `mod n`.
                // Ni sawa kabisa kuzifanya `mod usize::MAX` badala yake, kwa sababu tunachukua matokeo `mod n` mwishoni hata hivyo.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // USALAMA: `a` ni nguvu-ya-mbili, kwa hivyo sio sifuri.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` kesi inaweza kuhesabiwa kwa urahisi zaidi kupitia `-p (mod a)`, lakini kufanya hivyo kunazuia uwezo wa LLVM kuchagua maagizo kama `lea`.Badala yake tunahesabu
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ambayo inasambaza shughuli karibu na kubeba mzigo, lakini kutia wasiwasi `and` vya kutosha kwa LLVM kuweza kutumia uboreshaji anuwai inayojua.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Tayari zimepangiliwa.Ndio!
        return 0;
    } else if stride == 0 {
        // Ikiwa pointer haijawekwa sawa, na kipengee kina ukubwa wa sifuri, basi hakuna idadi ya vitu ambavyo vitapatanisha pointer.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // USALAMA: a ni nguvu ya mbili kwa hivyo sio sifuri.stride==0 kesi imeshughulikiwa hapo juu.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // USALAMA: gcdpow ina kifungo cha juu ambacho ni idadi kubwa ya bits kwenye usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // USALAMA: gcd daima ni kubwa au sawa na 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch hii hutatua kwa usawa wa usawa wa fujo zifuatazo:
        //
        // ` p + so = 0 mod a `
        //
        // `p` hapa kuna thamani ya pointer, `s`, hatua ya `T`, `o` iliyosaidiwa katika `T`s, na `a`, mpangilio ulioombwa.
        //
        // Na `g = gcd(a, s)`, na hali hiyo hapo juu ikisisitiza kwamba `p` pia inaweza kugawanywa na `g`, tunaweza kuonyesha `a' = a/g`, `s' = s/g`, `p' = p/g`, basi hii inakuwa sawa na:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Muda wa kwanza ni "the relative alignment of `p` to `a`" (imegawanywa na `g`), kipindi cha pili ni "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (tena imegawanywa na `g`).
        //
        // Mgawanyiko na `g` ni muhimu kufanya inverse vizuri iliyoundwa ikiwa `a` na `s` sio co-prime.
        //
        // Kwa kuongezea, matokeo yaliyotokana na suluhisho hili sio "minimal", kwa hivyo ni muhimu kuchukua matokeo `o mod lcm(s, a)`.Tunaweza kuchukua nafasi ya `lcm(s, a)` na `a'` tu.
        //
        //
        //
        //
        //

        // USALAMA: `gcdpow` ina kifungo cha juu sio kubwa kuliko idadi ya trailing 0-bits katika `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // USALAMA: `a2` sio sifuri.Kuhamisha `a` na `gcdpow` haiwezi kuhamisha seti yoyote ya seti
        // katika `a` (ambayo ina moja haswa).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // USALAMA: `gcdpow` ina kifungo cha juu sio kubwa kuliko idadi ya trailing 0-bits katika `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // USALAMA: `gcdpow` ina kifungo cha juu sio kubwa kuliko idadi ya trailing 0-bits in
        // `a`.
        // Kwa kuongezea, utoaji hauwezi kufurika, kwa sababu `a2 = a >> gcdpow` siku zote itakuwa kubwa zaidi kuliko `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // USALAMA: `a2` ni nguvu-ya-mbili, kama inavyothibitishwa hapo juu.`s2` ni chini ya `a2`
        // kwa sababu `(s % a) >> gcdpow` ni chini ya `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Haiwezi kupangiliwa kabisa.
    usize::MAX
}

/// Inalinganisha viashiria mbichi vya usawa.
///
/// Hii ni sawa na kutumia mwendeshaji wa `==`, lakini chini ya generic:
/// hoja lazima ziwe viashiria mbichi vya `*const T`, sio kitu chochote kinachotumia `PartialEq`.
///
/// Hii inaweza kutumika kulinganisha marejeleo ya `&T` (ambayo hushurutisha kwa `*const T` kabisa) na anwani yao badala ya kulinganisha maadili wanayoelekeza (ambayo ndio utekelezaji wa `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Vipande pia hulinganishwa na urefu wao (mafuta ya kuyatumia):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits pia inalinganishwa na utekelezaji wao:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Viashiria vina anwani sawa.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Vitu vina anwani sawa, lakini `Trait` ina utekelezaji tofauti.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Kubadilisha rejeleo kwa `*const u8` kulinganisha na anwani.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash pointer mbichi.
///
/// Hii inaweza kutumika kuwa na kumbukumbu ya `&T` (ambayo inashurutisha `*const T` kabisa) na anwani yake badala ya thamani inayoelekezwa (ambayo ndivyo utekelezaji wa `Hash for &T` unavyofanya).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls kwa viashiria vya kazi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Kutupwa kati kama usize inahitajika kwa AVR
                // ili nafasi ya anwani ya pointer ya kazi ya chanzo ihifadhiwe kwenye kiashiria cha mwisho cha kazi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Kutupwa kati kama usize inahitajika kwa AVR
                // ili nafasi ya anwani ya pointer ya kazi ya chanzo ihifadhiwe kwenye kiashiria cha mwisho cha kazi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Hakuna kazi tofauti na vigezo 0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Unda pointer mbichi ya `const` mahali, bila kuunda rejeleo la kati.
///
/// Kuunda rejista na `&`/`&mut` inaruhusiwa tu ikiwa pointer imewekwa vizuri na inaelekeza kwa data iliyoanzishwa.
/// Kwa kesi ambazo mahitaji haya hayashiki, viashiria mbichi vinapaswa kutumiwa badala yake.
/// Walakini, `&expr as *const _` inaunda rejeleo kabla ya kuitupa kwa kiboreshaji kibichi, na kumbukumbu hiyo iko chini ya sheria sawa na marejeo mengine yote.
///
/// Macro hii inaweza kuunda pointer mbichi *bila* kuunda rejeleo kwanza.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` itaunda rejeleo isiyo na mpangilio, na hivyo kuwa tabia isiyojulikana!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Unda pointer mbichi ya `mut` mahali, bila kuunda rejeleo la kati.
///
/// Kuunda rejista na `&`/`&mut` inaruhusiwa tu ikiwa pointer imewekwa vizuri na inaelekeza kwa data iliyoanzishwa.
/// Kwa kesi ambazo mahitaji haya hayashiki, viashiria mbichi vinapaswa kutumiwa badala yake.
/// Walakini, `&mut expr as *mut _` inaunda rejeleo kabla ya kuitupa kwa kiboreshaji kibichi, na kumbukumbu hiyo iko chini ya sheria sawa na marejeo mengine yote.
///
/// Macro hii inaweza kuunda pointer mbichi *bila* kuunda rejeleo kwanza.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` itaunda rejeleo isiyo na mpangilio, na hivyo kuwa tabia isiyojulikana!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` vikosi vya kunakili shamba badala ya kuunda kumbukumbu.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}