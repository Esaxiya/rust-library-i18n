//! Moduli hii hutumia `Any` trait, ambayo inawezesha kuandika kwa nguvu kwa aina yoyote ya `'static` kupitia tafakari ya wakati wa kukimbia.
//!
//! `Any` yenyewe inaweza kutumika kupata `TypeId`, na ina huduma zaidi wakati inatumiwa kama kitu cha trait.
//! Kama `&dyn Any` (kitu kilichokopwa cha trait), ina njia za `is` na `downcast_ref`, kujaribu ikiwa thamani iliyomo ni ya aina fulani, na kupata kumbukumbu ya thamani ya ndani kama aina.
//! Kama `&mut dyn Any`, pia kuna njia ya `downcast_mut`, ya kupata rejeleo linaloweza kubadilika kwa thamani ya ndani.
//! `Box<dyn Any>` inaongeza njia ya `downcast`, ambayo inajaribu kubadilisha kuwa `Box<T>`.
//! Tazama nyaraka za [`Box`] kwa maelezo kamili.
//!
//! Kumbuka kuwa `&dyn Any` imewekewa upimaji tu ikiwa thamani ni ya aina maalum ya saruji, na haiwezi kutumiwa kujaribu ikiwa aina hutumia trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Viashiria vya Smart na `dyn Any`
//!
//! Tabia moja ya kuzingatia wakati unatumia `Any` kama kitu cha trait, haswa na aina kama `Box<dyn Any>` au `Arc<dyn Any>`, ni kwamba kupiga simu tu `.type_id()` kwa thamani kutatoa `TypeId` ya kontena *, sio kitu cha msingi cha trait.
//!
//! Hii inaweza kuepukwa kwa kubadilisha pointer smart kuwa `&dyn Any` badala yake, ambayo itarudisha `TypeId` ya kitu.
//! Kwa mfano:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Una uwezekano mkubwa wa kutaka hii:
//! let actual_id = (&*boxed).type_id();
//! // ... kuliko hii:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Fikiria hali ambapo tunataka kutoka nje thamani iliyopitishwa kwa kazi.
//! Tunajua thamani tunayofanyia kazi Utatuaji, lakini hatujui aina yake halisi.Tunataka kutoa matibabu maalum kwa aina fulani: katika kesi hii kuchapisha urefu wa maadili ya Kamba kabla ya thamani yao.
//! Hatujui aina halisi ya thamani yetu wakati wa kukusanya, kwa hivyo tunahitaji kutumia tafakari ya wakati wa kukimbia badala yake.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Kazi ya Logger ya aina yoyote inayotumia Utatuaji.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Jaribu kubadilisha thamani yetu kuwa `String`.
//!     // Ikiwa imefanikiwa, tunataka kutoa urefu wa Kamba pamoja na thamani yake.
//!     // Ikiwa sivyo, ni aina tofauti: ichapishe tu bila kupambwa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Kazi hii inataka kuweka nje parameter yake kabla ya kufanya kazi nayo.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... fanya kazi nyingine
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// trait yoyote
///////////////////////////////////////////////////////////////////////////////

/// trait kuiga uandishi wa nguvu.
///
/// Aina nyingi hutekeleza `Any`.Walakini, aina yoyote ambayo ina rejeleo isiyo ya "tuli" haifanyi hivyo.
/// Tazama [module-level documentation][mod] kwa maelezo zaidi.
///
/// [mod]: crate::any
// trait hii sio salama, ingawa tunategemea maalum ya kazi ya impl ya `type_id` pekee katika nambari isiyo salama (kwa mfano, `downcast`).Kwa kawaida, hilo lingekuwa shida, lakini kwa sababu impl ya `Any` ni utekelezaji wa blanketi, hakuna nambari nyingine inayoweza kutekeleza `Any`.
//
// Tunaweza kuifanya trait isiwe salama-haiwezi kusababisha kuvunjika, kwa kuwa tunadhibiti utekelezaji wote-lakini hatujichauri kwa kuwa hiyo sio lazima sana na inaweza kuwachanganya watumiaji kuhusu tofauti ya traits isiyo salama na njia zisizo salama (yaani, `type_id` bado ingekuwa salama kupiga simu, lakini labda tungetaka kuonyesha kama vile kwenye nyaraka).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Inapata `TypeId` ya `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Njia za ugani kwa vitu vyovyote vya trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Hakikisha kuwa matokeo ya mfano, kujiunga na uzi yanaweza kuchapishwa na kwa hivyo kutumiwa na `unwrap`.
// Hatimaye inaweza kuhitajika tena ikiwa kutuma kunafanya kazi na utangazaji.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Hurejesha `true` ikiwa aina ya ndondi ni sawa na `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Pata `TypeId` ya aina ambayo kazi hii imesisitizwa.
        let t = TypeId::of::<T>();

        // Pata `TypeId` ya aina katika kitu cha trait (`self`).
        let concrete = self.type_id();

        // Linganisha "TypeId" zote mbili juu ya usawa.
        t == concrete
    }

    /// Hurejesha rejeleo kwa thamani ya sanduku ikiwa ni ya aina `T`, au `None` ikiwa sio.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // USALAMA: angalia tu ikiwa tunaashiria aina sahihi, na tunaweza kutegemea
            // angalia usalama wa kumbukumbu kwa sababu tumetekeleza yoyote kwa aina zote;hakuna impls zingine zinaweza kuwepo kwani zingepingana na impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Hurejesha rejeleo linaloweza kubadilika kwa thamani ya kisanduku ikiwa ni ya aina `T`, au `None` ikiwa sio.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // USALAMA: angalia tu ikiwa tunaashiria aina sahihi, na tunaweza kutegemea
            // angalia usalama wa kumbukumbu kwa sababu tumetekeleza yoyote kwa aina zote;hakuna impls zingine zinaweza kuwepo kwani zingepingana na impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Sambaza kwa njia iliyoelezwa kwenye aina ya `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Sambaza kwa njia iliyoelezwa kwenye aina ya `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Sambaza kwa njia iliyoelezwa kwenye aina ya `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Sambaza kwa njia iliyoelezwa kwenye aina ya `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Sambaza kwa njia iliyoelezwa kwenye aina ya `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Sambaza kwa njia iliyoelezwa kwenye aina ya `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID na njia zake
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` inawakilisha kitambulisho cha kipekee cha ulimwengu cha aina.
///
/// Kila `TypeId` ni kitu kisichoonekana ambacho hairuhusu ukaguzi wa kilicho ndani lakini hairuhusu shughuli za kimsingi kama uundaji, kulinganisha, kuchapisha na kuonyesha.
///
///
/// `TypeId` kwa sasa inapatikana tu kwa aina ambazo hutaja `'static`, lakini kizuizi hiki kinaweza kuondolewa katika future.
///
/// Wakati `TypeId` inatumia `Hash`, `PartialOrd`, na `Ord`, ni muhimu kuzingatia kwamba hashes na kuagiza zitatofautiana kati ya kutolewa kwa Rust.
/// Jihadharini na kuzitegemea ndani ya nambari yako!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Hurejesha `TypeId` ya aina ambayo kazi ya generic imesisitizwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Hurejesha jina la aina kama kipande cha kamba.
///
/// # Note
///
/// Hii imekusudiwa matumizi ya utambuzi.
/// Yaliyomo halisi na fomati ya kamba iliyorudishwa haijaainishwa, isipokuwa kuwa maelezo bora ya aina hiyo.
/// Kwa mfano, kati ya masharti ambayo `type_name::<Option<String>>()` inaweza kurudi ni `"Option<String>"` na `"std::option::Option<std::string::String>"`.
///
///
/// Kamba iliyorejeshwa haipaswi kuzingatiwa kama kitambulisho cha kipekee cha aina kwani aina nyingi zinaweza ramani kwa jina la aina hiyo hiyo.
/// Vivyo hivyo, hakuna hakikisho kwamba sehemu zote za aina zitaonekana kwenye kamba iliyorudishwa: kwa mfano, vielelezo vya maisha kwa sasa hazijumuishwa.
/// Kwa kuongeza, pato linaweza kubadilika kati ya matoleo ya mkusanyaji.
///
/// Utekelezaji wa sasa unatumia miundombinu sawa na utambuzi wa mkusanyaji na debuginfo, lakini hii haihakikishiwa.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Hurejesha jina la aina ya thamani iliyoelekezwa kama kipande cha kamba.
/// Hii ni sawa na `type_name::<T>()`, lakini inaweza kutumika ambapo aina ya utofauti haipatikani kwa urahisi.
///
/// # Note
///
/// Hii imekusudiwa matumizi ya utambuzi.Yaliyomo halisi na muundo wa kamba hayajabainishwa, isipokuwa kuwa maelezo bora ya aina hiyo.
/// Kwa mfano, `type_name_of_val::<Option<String>>(None)` inaweza kurudisha `"Option<String>"` au `"std::option::Option<std::string::String>"`, lakini sio `"foobar"`.
///
/// Kwa kuongeza, pato linaweza kubadilika kati ya matoleo ya mkusanyaji.
///
/// Kazi hii haitatulii vitu vya trait, ikimaanisha kuwa `type_name_of_val(&7u32 as &dyn Debug)` inaweza kurudi `"dyn Debug"`, lakini sio `"u32"`.
///
/// Jina la aina halipaswi kuzingatiwa kitambulisho cha kipekee cha aina;
/// aina nyingi zinaweza kushiriki jina la aina moja.
///
/// Utekelezaji wa sasa unatumia miundombinu sawa na utambuzi wa mkusanyaji na debuginfo, lakini hii haihakikishiwa.
///
/// # Examples
///
/// Inachapisha idadi kamili na aina za kuelea.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}