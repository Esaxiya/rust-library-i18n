/// Imetumika kwa shughuli za kutofautisha zisizobadilika, kama `*v`.
///
/// Kwa kuongezea kutumiwa kwa shughuli wazi za kutofautisha na mwendeshaji wa (unary) `*` katika hali zisizobadilika, `Deref` pia hutumiwa kabisa na mkusanyaji katika hali nyingi.
/// Utaratibu huu unaitwa ['`Deref` coercion'][more].
/// Katika mazingira yanayoweza kubadilika, [`DerefMut`] hutumiwa.
///
/// Utekelezaji wa `Deref` kwa vidokezo vyema hufanya upatikanaji wa data nyuma yao iwe rahisi, ndiyo sababu wanatekeleza `Deref`.
/// Kwa upande mwingine, sheria kuhusu `Deref` na [`DerefMut`] zilibuniwa mahsusi kwa kuzingatia viashiria vya busara.
/// Kwa sababu ya hii,**`Deref` inapaswa kutekelezwa tu kwa viashiria vya smart** ili kuepuka kuchanganyikiwa.
///
/// Kwa sababu zinazofanana,**hii trait haipaswi kamwe kushindwa**.Kushindwa wakati wa kutofautisha kunaweza kutatanisha sana wakati `Deref` inaombwa kabisa.
///
/// # Zaidi juu ya kulazimishwa kwa `Deref`
///
/// Ikiwa `T` itatumia `Deref<Target = U>`, na `x` ni thamani ya aina `T`, basi:
///
/// * Katika mazingira yasiyoweza kubadilika, `*x` (ambapo `T` sio kumbukumbu wala kiashiria mbichi) ni sawa na `* Deref::deref(&x)`.
/// * Thamani za aina `&T` zimelazimishwa kwa maadili ya aina `&U`
/// * `T` kutekeleza kabisa njia zote za (immutable) za aina `U`.
///
/// Kwa maelezo zaidi, tembelea [the chapter in *The Rust Programming Language*][book] pamoja na sehemu za kumbukumbu kwenye [the dereference operator][ref-deref-op], [method resolution] na [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Muundo ulio na uwanja mmoja ambao unapatikana kwa kutofautisha muundo.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Aina inayosababishwa baada ya kutofaulu tena.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Inachagua thamani.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Imetumika kwa shughuli za kuondoa ubadilishaji zinazobadilika, kama katika `*v = 1;`.
///
/// Kwa kuongezea kutumiwa kwa shughuli wazi za kutofautisha na mwendeshaji wa (unary) `*` katika hali inayoweza kubadilika, `DerefMut` pia inatumiwa kabisa na mkusanyaji katika hali nyingi.
/// Utaratibu huu unaitwa ['`Deref` coercion'][more].
/// Katika mazingira yasiyoweza kubadilika, [`Deref`] hutumiwa.
///
/// Utekelezaji wa `DerefMut` kwa viashiria vya busara hufanya kubadilisha data nyuma yao iwe rahisi, ndio sababu wanatekeleza `DerefMut`.
/// Kwa upande mwingine, sheria kuhusu [`Deref`] na `DerefMut` zilibuniwa mahsusi kwa kuzingatia viashiria vya busara.
/// Kwa sababu ya hii,**`DerefMut` inapaswa kutekelezwa tu kwa viashiria vya akili** ili kuepuka kuchanganyikiwa.
///
/// Kwa sababu zinazofanana,**hii trait haipaswi kamwe kushindwa**.Kushindwa wakati wa kutofautisha kunaweza kutatanisha sana wakati `DerefMut` inaombwa kabisa.
///
/// # Zaidi juu ya kulazimishwa kwa `Deref`
///
/// Ikiwa `T` itatumia `DerefMut<Target = U>`, na `x` ni thamani ya aina `T`, basi:
///
/// * Katika mazingira yanayoweza kubadilika, `*x` (ambapo `T` sio kumbukumbu wala kiashiria mbichi) ni sawa na `* DerefMut::deref_mut(&mut x)`.
/// * Thamani za aina `&mut T` zimelazimishwa kwa maadili ya aina `&mut U`
/// * `T` kutekeleza kabisa njia zote za (mutable) za aina `U`.
///
/// Kwa maelezo zaidi, tembelea [the chapter in *The Rust Programming Language*][book] pamoja na sehemu za kumbukumbu kwenye [the dereference operator][ref-deref-op], [method resolution] na [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Muundo ulio na uwanja mmoja ambao unaweza kubadilika kwa kutofautisha muundo.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Inaweza kutaja thamani.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Inaonyesha kwamba muundo unaweza kutumika kama mpokeaji wa njia, bila kipengee cha `arbitrary_self_types`.
///
/// Hii inatekelezwa na aina za pointer za stdlib kama `Box<T>`, `Rc<T>`, `&T`, na `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}