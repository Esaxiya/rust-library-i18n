/// Inatumika kwa shughuli za kuorodhesha (`container[index]`) katika hali zisizobadilika.
///
/// `container[index]` ni sukari ya kisintaksia ya `*container.index(index)`, lakini tu wakati inatumiwa kama thamani isiyoweza kubadilika.
/// Ikiwa thamani inayoweza kubadilika imeombwa, [`IndexMut`] hutumiwa badala yake.
/// Hii inaruhusu vitu nzuri kama vile `let value = v[index]` ikiwa aina ya `value` inatumia [`Copy`].
///
/// # Examples
///
/// Mfano ufuatao hutumia `Index` kwenye kontena la `NucleotideCount` linalosomwa tu, na kuwezesha hesabu za mtu binafsi kupatikana na sintaksia ya faharisi.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Aina iliyorejeshwa baada ya kuorodhesha.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Inafanya operesheni ya kuorodhesha (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Inatumika kwa shughuli za kuorodhesha (`container[index]`) katika mazingira yanayoweza kubadilika.
///
/// `container[index]` ni sukari ya kisintaksia ya `*container.index_mut(index)`, lakini tu wakati inatumiwa kama thamani inayoweza kubadilika.
/// Ikiwa thamani isiyobadilika imeombwa, [`Index`] trait hutumiwa badala yake.
/// Hii inaruhusu vitu nzuri kama vile `v[index] = value`.
///
/// # Examples
///
/// Utekelezaji rahisi sana wa muundo wa `Balance` ambao una pande mbili, ambapo kila moja inaweza kuorodheshwa bila kubadilika na bila kubadilika.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Katika kesi hii, `balance[Side::Right]` ni sukari kwa `*balance.index(Side::Right)`, kwani tunasoma tu*`balance[Side::Right]`, na sio kuiandika.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Walakini, katika kesi hii `balance[Side::Left]` ni sukari kwa `*balance.index_mut(Side::Left)`, kwani tunaandika `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Inafanya kazi ya kuorodhesha inayoweza kubadilika ya (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}