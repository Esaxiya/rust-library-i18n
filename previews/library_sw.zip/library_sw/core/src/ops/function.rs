/// Toleo la mwendeshaji wa simu anayechukua mpokeaji asiyebadilika.
///
/// Matukio ya `Fn` yanaweza kuitwa mara kwa mara bila kubadilisha hali.
///
/// *trait (`Fn`) hii haifai kuchanganyikiwa na [function pointers] (`fn`).*
///
/// `Fn` inatekelezwa kiatomati na kufungwa ambayo inachukua tu marejeleo yasiyoweza kubadilika kwa vigeuzi vilivyonaswa au haikamata kitu chochote, na vile vile (safe) [function pointers] (pamoja na mapango kadhaa, angalia nyaraka zao kwa maelezo zaidi).
///
/// Kwa kuongeza, kwa aina yoyote `F` inayotumia `Fn`, `&F` hutumia `Fn`, pia.
///
/// Kwa kuwa zote mbili [`FnMut`] na [`FnOnce`] ni alama kuu za `Fn`, mfano wowote wa `Fn` unaweza kutumika kama kigezo ambapo [`FnMut`] au [`FnOnce`] inatarajiwa.
///
/// Tumia `Fn` ikiwa imefungwa wakati unataka kukubali parameta ya aina inayofanana na kazi na unahitaji kuiita mara kwa mara na bila kubadilisha hali (kwa mfano, wakati wa kuiita kwa wakati mmoja).
/// Ikiwa hauitaji mahitaji magumu kama hayo, tumia [`FnMut`] au [`FnOnce`] kama mipaka.
///
/// Tazama [chapter on closures in *The Rust Programming Language*][book] kwa habari zaidi juu ya mada hii.
///
/// Pia ya kumbuka ni syntax maalum ya `Fn` traits (kwa mfano
/// `Fn(usize, bool) -> usize`).Wale wanaopenda maelezo ya kiufundi ya hii wanaweza kutaja [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kuita kufungwa
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Kutumia parameter ya `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ili regex iweze kutegemea `&str: !FnMut` hiyo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Inafanya operesheni ya simu.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Toleo la mwendeshaji wa simu anayechukua mpokeaji anayeweza kubadilika.
///
/// Matukio ya `FnMut` yanaweza kuitwa mara kwa mara na inaweza kubadilisha hali.
///
/// `FnMut` inatekelezwa kiatomati na kufungwa ambayo huchukua marejeleo yanayoweza kubadilika kwa vigeuzi vilivyonaswa, pamoja na aina zote zinazotekeleza [`Fn`], kwa mfano, (safe) [function pointers] (kwani `FnMut` ni alama kuu ya [`Fn`]).
/// Kwa kuongeza, kwa aina yoyote `F` inayotumia `FnMut`, `&mut F` hutumia `FnMut`, pia.
///
/// Kwa kuwa [`FnOnce`] ni alama kuu ya `FnMut`, mfano wowote wa `FnMut` unaweza kutumika mahali ambapo [`FnOnce`] inatarajiwa, na kwa kuwa [`Fn`] ni ujanja wa `FnMut`, mfano wowote wa [`Fn`] unaweza kutumika ambapo `FnMut` inatarajiwa.
///
/// Tumia `FnMut` ikiwa imefungwa wakati unataka kukubali parameta ya aina inayofanana na kazi na unahitaji kuiita mara kwa mara, huku ukiiruhusu ibadilishe hali.
/// Ikiwa hutaki parameter ibadilishe hali, tumia [`Fn`] kama imefungwa;ikiwa hauitaji kuiita mara kwa mara, tumia [`FnOnce`].
///
/// Tazama [chapter on closures in *The Rust Programming Language*][book] kwa habari zaidi juu ya mada hii.
///
/// Pia ya kumbuka ni syntax maalum ya `Fn` traits (kwa mfano
/// `Fn(usize, bool) -> usize`).Wale wanaopenda maelezo ya kiufundi ya hii wanaweza kutaja [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kuita wito wa kukamata kufungwa
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Kutumia parameter ya `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ili regex iweze kutegemea `&str: !FnMut` hiyo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Inafanya operesheni ya simu.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Toleo la mwendeshaji wa simu anayechukua mpokeaji wa thamani.
///
/// Matukio ya `FnOnce` yanaweza kupigiwa simu, lakini inaweza isiweze kupigiwa mara kadhaa.Kwa sababu ya hii, ikiwa kitu pekee kinachojulikana juu ya aina ni kwamba hutumia `FnOnce`, inaweza kuitwa mara moja tu.
///
/// `FnOnce` inatekelezwa kiatomati na kufungwa ambayo inaweza kutumia vigeuzi vilivyonaswa, pamoja na aina zote zinazotekeleza [`FnMut`], kwa mfano, (safe) [function pointers] (kwani `FnOnce` ni alama kuu ya [`FnMut`]).
///
///
/// Kwa kuwa [`Fn`] na [`FnMut`] ni sehemu ndogo za `FnOnce`, mfano wowote wa [`Fn`] au [`FnMut`] unaweza kutumika ambapo `FnOnce` inatarajiwa.
///
/// Tumia `FnOnce` kama kifungo wakati unataka kukubali parameta ya aina inayofanana na kazi na unahitaji kuiita mara moja tu.
/// Ikiwa unahitaji kupiga parameter mara kwa mara, tumia [`FnMut`] kama imefungwa;ikiwa unahitaji pia kutobadilisha hali, tumia [`Fn`].
///
/// Tazama [chapter on closures in *The Rust Programming Language*][book] kwa habari zaidi juu ya mada hii.
///
/// Pia ya kumbuka ni syntax maalum ya `Fn` traits (kwa mfano
/// `Fn(usize, bool) -> usize`).Wale wanaopenda maelezo ya kiufundi ya hii wanaweza kutaja [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kutumia parameter ya `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` hutumia anuwai zake zilizokamatwa, kwa hivyo haiwezi kuendeshwa zaidi ya mara moja.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Kujaribu kuomba `func()` tena kutupa kosa la `use of moved value` kwa `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` haiwezi kutumiwa tena wakati huu
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ili regex iweze kutegemea `&str: !FnMut` hiyo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Aina iliyorejeshwa baada ya mwendeshaji kutumia.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Inafanya operesheni ya simu.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}