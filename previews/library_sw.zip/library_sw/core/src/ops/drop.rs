/// Nambari maalum ndani ya mwangamizi.
///
/// Wakati thamani haihitajiki tena, Rust itaendesha "destructor" kwa thamani hiyo.
/// Njia ya kawaida ambayo dhamana haihitajiki tena ni wakati inatoka nje ya wigo.Waangamizi bado wanaweza kukimbia katika hali zingine, lakini tutazingatia wigo wa mifano hapa.
/// Ili kujifunza juu ya baadhi ya visa vingine, tafadhali angalia sehemu ya [the reference] juu ya waharibifu.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Mwangamizi huyu ana vifaa viwili:
/// - Simu kwa `Drop::drop` kwa thamani hiyo, ikiwa `Drop` trait hii maalum inatekelezwa kwa aina yake.
/// - "drop glue" inayotengenezwa kiatomati ambayo inaita mara kwa mara waharibu wa nyanja zote za thamani hii.
///
/// Kama Rust inaita moja kwa moja waharibu wa nyanja zote zilizomo, sio lazima utekeleze `Drop` mara nyingi.
/// Lakini kuna visa kadhaa ambapo ni muhimu, kwa mfano kwa aina ambazo zinasimamia rasilimali moja kwa moja.
/// Rasilimali hiyo inaweza kuwa kumbukumbu, inaweza kuwa kielelezo cha faili, inaweza kuwa tundu la mtandao.
/// Mara tu thamani ya aina hiyo haitatumiwa tena, inapaswa "clean up" rasilimali yake kwa kufungua kumbukumbu au kufunga faili au tundu.
/// Hii ndio kazi ya mwangamizi, na kwa hivyo kazi ya `Drop::drop`.
///
/// ## Examples
///
/// Ili kuona waangamizi wakifanya kazi, wacha tuangalie programu ifuatayo:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust itaita kwanza `Drop::drop` kwa `_x` na kisha kwa `_x.one` na `_x.two`, ikimaanisha kuwa kuendesha hii kuchapisha
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Hata tukiondoa utekelezaji wa `Drop` kwa `HasTwoDrop`, waharibu wa uwanja wake bado wanaitwa.
/// Hii itasababisha
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Huwezi kupiga `Drop::drop` mwenyewe
///
/// Kwa sababu `Drop::drop` hutumiwa kusafisha thamani, inaweza kuwa hatari kutumia thamani hii baada ya njia kuitwa.
/// Kwa kuwa `Drop::drop` haichukui umiliki wa pembejeo yake, Rust inazuia matumizi mabaya kwa kutokuruhusu kupiga `Drop::drop` moja kwa moja.
///
/// Kwa maneno mengine, ikiwa ulijaribu kuita `Drop::drop` wazi katika mfano hapo juu, utapata kosa la mkusanyaji.
///
/// Ikiwa ungependa kumwita dhahiri mwangamizi wa thamani, [`mem::drop`] inaweza kutumika badala yake.
///
/// [`mem::drop`]: drop
///
/// ## Tone utaratibu
///
/// Je! Ni yupi kati ya matone yetu mawili ya `HasDrop` kwanza, hata hivyo?Kwa ujenzi, ni agizo sawa ambalo hutangazwa: kwanza `one`, halafu `two`.
/// Ikiwa ungependa kujaribu hii mwenyewe, unaweza kurekebisha `HasDrop` hapo juu ili iwe na data, kama nambari kamili, kisha uitumie ndani ya `println!` ndani ya `Drop`.
/// Tabia hii inahakikishiwa na lugha.
///
/// Tofauti na ujanibishaji, anuwai za mitaa zimeshuka kwa mpangilio wa nyuma:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Hii itachapisha
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Tafadhali angalia [the reference] kwa sheria kamili.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` na `Drop` ni za kipekee
///
/// Huwezi kutekeleza zote [`Copy`] na `Drop` kwa aina moja.Aina ambazo ni `Copy` hupigwa nakala kamili na mkusanyaji, na kuifanya iwe ngumu sana kutabiri ni lini, na waharibifu watatekelezwa mara ngapi.
///
/// Kama hivyo, aina hizi haziwezi kuwa na waharibifu.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Hufanya uharibifu wa aina hii.
    ///
    /// Njia hii inaitwa dhahiri wakati dhamana inatoka nje ya wigo, na haiwezi kuitwa wazi (hii ni kosa la mkusanyaji [E0040]).
    /// Walakini, kazi ya [`mem::drop`] katika prelude inaweza kutumika kuita utekelezaji wa hoja ya `Drop`.
    ///
    /// Wakati njia hii imeitwa, `self` bado haijasambazwa.
    /// Hiyo hufanyika tu baada ya njia kuisha.
    /// Ikiwa hii haikuwa hivyo, `self` ingekuwa rejeleo linalining'inia.
    ///
    /// # Panics
    ///
    /// Kwa kuzingatia kuwa [`panic!`] itaita `drop` inapojifungua, [`panic!`] yoyote katika utekelezaji wa `drop` inaweza kutoa mimba.
    ///
    /// Kumbuka kuwa hata kama panics hii, thamani hiyo inachukuliwa kuwa imeshuka;
    /// lazima usisababisha `drop` kuitwa tena.
    /// Hii kawaida hushughulikiwa kiatomati na mkusanyaji, lakini wakati wa kutumia nambari isiyo salama, wakati mwingine inaweza kutokea bila kukusudia, haswa wakati wa kutumia [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}