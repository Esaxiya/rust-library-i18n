//! Waendeshaji wanaoweza kupakia.
//!
//! Utekelezaji wa hizi traits hukuruhusu kupakia zaidi waendeshaji fulani.
//!
//! Baadhi ya hizi traits zinaingizwa na prelude, kwa hivyo zinapatikana katika kila mpango wa Rust.Waendeshaji tu wanaoungwa mkono na traits wanaweza kupakia zaidi.
//! Kwa mfano, mwendeshaji wa kuongeza (`+`) anaweza kupakia zaidi kupitia [`Add`] trait, lakini kwa kuwa mwendeshaji wa kazi (`=`) hana msaada wa trait, hakuna njia ya kupakia semantiki zake.
//! Kwa kuongeza, moduli hii haitoi utaratibu wowote wa kuunda waendeshaji wapya.
//! Ikiwa kupakia kupita kiasi bila waendeshaji au waendeshaji wa kawaida kunahitajika, unapaswa kuangalia kuelekea macros au programu-jalizi za mkusanyiko kupanua sintaksia ya Rust.
//!
//! Utekelezaji wa mwendeshaji traits inapaswa kuwa ya kushangaza katika mazingira yao, wakizingatia maana zao za kawaida na [operator precedence].
//! Kwa mfano, wakati wa kutekeleza [`Mul`], operesheni inapaswa kuwa na kufanana kwa kuzidisha (na kushiriki mali inayotarajiwa kama ushirika).
//!
//! Kumbuka kuwa waendeshaji wa muda mfupi wa `&&` na `||`, yaani, wanatathmini tu operesheni yao ya pili ikiwa inachangia matokeo.Kwa kuwa tabia hii haitekelezwi na traits, `&&` na `||` hazihimiliwi kama waendeshaji wanaoweza kupakia zaidi.
//!
//! Waendeshaji wengi huchukua operesheni zao kwa thamani.Katika mazingira yasiyo ya kawaida yanayojumuisha aina zilizojengwa, kawaida hii sio shida.
//! Walakini, kutumia waendeshaji hawa kwa nambari ya kawaida, inahitaji umakini ikiwa maadili yanapaswa kutumiwa tena kinyume na kuruhusu waendeshaji watumie.Chaguo moja ni kutumia mara kwa mara [`clone`].
//! Chaguo jingine ni kutegemea aina zinazohusika kutoa utekelezaji wa waendeshaji wa ziada kwa marejeleo.
//! Kwa mfano, kwa aina iliyoelezewa na mtumiaji `T` ambayo inapaswa kusaidia kuongezea, labda ni wazo nzuri kuwa na `T` na `&T` kutekeleza traits [`Add<T>`][`Add`] na [`Add<&T>`][`Add`] ili nambari ya jumla iweze kuandikwa bila ujanibishaji usiofaa.
//!
//!
//! # Examples
//!
//! Mfano huu unaunda muundo wa `Point` unaotumia [`Add`] na [`Sub`], na kisha unaonyesha kuongeza na kutoa `Point` mbili.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Tazama nyaraka za kila trait kwa mfano wa utekelezaji.
//!
//! [`Fn`], [`FnMut`], na [`FnOnce`] traits zinatekelezwa na aina ambazo zinaweza kutumiwa kama kazi.Kumbuka kuwa [`Fn`] inachukua `&self`, [`FnMut`] inachukua `&mut self` na [`FnOnce`] inachukua `self`.
//! Hizi zinahusiana na aina tatu za njia ambazo zinaweza kutumiwa kwa mfano: simu-kwa-rejeleo, rejeleo-kwa-inayoweza kubadilika-rejeleo, na wito-kwa-thamani.
//! Matumizi ya kawaida ya hizi traits ni kufanya kama mipaka kwa kazi za kiwango cha juu ambazo huchukua kazi au kufungwa kama hoja.
//!
//! Kuchukua [`Fn`] kama kigezo:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Kuchukua [`FnMut`] kama kigezo:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Kuchukua [`FnOnce`] kama kigezo:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` hutumia anuwai zake zilizokamatwa, kwa hivyo haiwezi kuendeshwa zaidi ya mara moja
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Kujaribu kuomba `func()` tena kutupa kosa la `use of moved value` kwa `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` haiwezi kutumiwa tena wakati huu
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;