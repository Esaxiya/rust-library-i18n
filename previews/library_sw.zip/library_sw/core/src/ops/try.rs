/// trait ya kubadilisha tabia ya mwendeshaji wa `?`.
///
/// Aina inayotekeleza `Try` ni ile ambayo ina njia ya kuidharau ya kuiona kwa suala la dichotomy ya success/failure.
/// trait hii inaruhusu wote kuchomoa mafanikio hayo au maadili ya kutofaulu kutoka kwa mfano uliopo na kuunda mfano mpya kutoka kwa mafanikio au thamani ya kutofaulu.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Aina ya thamani hii ikionekana kuwa imefanikiwa.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Aina ya thamani hii ikionekana kuwa imeshindwa.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Inatumika mwendeshaji wa "?".Kurudi kwa `Ok(t)` kunamaanisha kuwa utekelezaji unapaswa kuendelea kawaida, na matokeo ya `?` ni thamani `t`.
    /// Kurudi kwa `Err(e)` kunamaanisha kuwa utekelezaji unapaswa branch kwenda ndani kabisa ya `catch`, au kurudi kutoka kwa kazi.
    ///
    /// Ikiwa matokeo ya `Err(e)` yatarejeshwa, thamani `e` itakuwa "wrapped" katika aina ya kurudi ya wigo uliofungwa (ambao lazima yenyewe itekeleze `Try`).
    ///
    /// Hasa, thamani `X::from_error(From::from(e))` inarejeshwa, ambapo `X` ni aina ya kurudi ya kazi iliyofungwa.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Funga dhamana ya kosa ili kuunda matokeo ya ujumuishaji.
    /// Kwa mfano, `Result::Err(x)` na `Result::from_error(x)` ni sawa.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Funga dhamana sawa ili kujenga matokeo ya muundo.
    /// Kwa mfano, `Result::Ok(x)` na `Result::from_ok(x)` ni sawa.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}