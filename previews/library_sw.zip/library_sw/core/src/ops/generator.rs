use crate::marker::Unpin;
use crate::pin::Pin;

/// Matokeo ya kuanza tena kwa jenereta.
///
/// Enum hii inarejeshwa kutoka kwa njia ya `Generator::resume` na inaonyesha maadili ya kurudi ya jenereta.
/// Hivi sasa hii inalingana na sehemu ya kusimamishwa (`Yielded`) au hatua ya kukomesha (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Jenereta imesimamishwa na thamani.
    ///
    /// Hali hii inaonyesha kuwa jenereta imesimamishwa, na kawaida inafanana na taarifa ya `yield`.
    /// Thamani iliyotolewa katika lahaja hii inalingana na usemi uliopitishwa kwa `yield` na inaruhusu jenereta kutoa thamani kila wakati wanapozaa.
    ///
    ///
    Yielded(Y),

    /// Jenereta imekamilika na thamani ya kurudi.
    ///
    /// Hali hii inaonyesha kuwa jenereta imemaliza utekelezaji na dhamana iliyotolewa.
    /// Mara tu jenereta itakaporudisha `Complete` inachukuliwa kama kosa la programu kupiga `resume` tena.
    ///
    Complete(R),
}

/// trait inatekelezwa na aina za jenereta zilizojengwa.
///
/// Jenereta, ambazo pia hujulikana kama coroutines, kwa sasa ni sifa ya lugha ya majaribio katika Rust.
/// Imeongezwa katika jenereta za [RFC 2033] kwa sasa imekusudiwa kutoa msingi wa ujenzi wa sintaksia ya async/await lakini inaweza kupanua pia kutoa ufafanuzi wa ergonomic kwa watangazaji na vipaumbele vingine.
///
///
/// Sintaksia na semantiki kwa jenereta ni thabiti na itahitaji RFC zaidi kwa utulivu.Kwa wakati huu, hata hivyo, sintaksia ni kama kufungwa:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Nyaraka zaidi za jenereta zinaweza kupatikana katika kitabu kisicho na msimamo.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Aina ya thamani inazalisha jenereta hii.
    ///
    /// Aina hii inayohusiana inalingana na usemi wa `yield` na maadili ambayo yanaruhusiwa kurudishwa kila wakati jenereta inavuna.
    ///
    /// Kwa mfano iterator-as-a-generator ingeweza kuwa na aina hii kama `T`, aina hiyo ikiwashwa tena.
    ///
    type Yield;

    /// Aina ya thamani ambayo jenereta hii inarudi.
    ///
    /// Hii inalingana na aina iliyorudishwa kutoka kwa jenereta ama na taarifa ya `return` au kabisa kama usemi wa mwisho wa jenereta halisi.
    /// Kwa mfano futures ingetumia hii kama `Result<T, E>` kwani inawakilisha future iliyokamilishwa.
    ///
    ///
    type Return;

    /// Inaanza tena utekelezaji wa jenereta hii.
    ///
    /// Kazi hii itaanza tena utekelezaji wa jenereta au kuanza utekelezaji ikiwa bado haijawahi.
    /// Simu hii itarudi kwenye hatua ya mwisho ya kusimamishwa kwa jenereta, ikianza tena utekelezaji kutoka kwa `yield` ya hivi karibuni.
    /// Jenereta itaendelea kutekeleza hadi itoe mazao au kurudi, na wakati huu kazi hii itarudi.
    ///
    /// # Rudisha thamani
    ///
    /// Enum ya `GeneratorState` iliyorejeshwa kutoka kwa kazi hii inaonyesha hali gani jenereta iko katika kurudi.
    /// Ikiwa lahaja ya `Yielded` itarejeshwa basi jenereta imefikia hatua ya kusimamishwa na thamani imetolewa.
    /// Jenereta katika hali hii zinapatikana kwa kuanza tena baadaye.
    ///
    /// Ikiwa `Complete` itarejeshwa basi jenereta imekamilisha kabisa na dhamana iliyotolewa.Ni batili kwa jenereta kuanza tena.
    ///
    /// # Panics
    ///
    /// Kazi hii inaweza panic ikiwa inaitwa baada ya lahaja ya `Complete` kurudishwa hapo awali.
    /// Wakati maandishi ya jenereta kwa lugha yamehakikishiwa panic kuanza tena baada ya `Complete`, hii haihakikishiwi kwa utekelezaji wote wa `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}