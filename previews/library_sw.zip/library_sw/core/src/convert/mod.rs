//! Traits kwa ubadilishaji kati ya aina.
//!
//! traits katika moduli hii hutoa njia ya kubadilisha kutoka aina moja hadi aina nyingine.
//! Kila trait hutumikia kusudi tofauti:
//!
//! - Tekeleza [`AsRef`] trait kwa ubadilishaji rahisi wa rejea-rejeleo
//! - Tekeleza [`AsMut`] trait kwa ubadilishaji wa bei rahisi unaoweza kubadilika
//! - Tekeleza [`From`] trait kwa kutumia mabadiliko ya thamani-kwa-thamani
//! - Tekeleza [`Into`] trait kwa kutumia mabadiliko ya thamani-kwa-thamani kwa aina zilizo nje ya crate ya sasa
//! - [`TryFrom`] na [`TryInto`] traits zina tabia kama [`From`] na [`Into`], lakini inapaswa kutekelezwa wakati ubadilishaji unaweza kushindwa.
//!
//! traits katika moduli hii hutumiwa mara nyingi kama trait bound kwa kazi za generic kama vile kwa hoja za aina nyingi zinaungwa mkono.Tazama nyaraka za kila trait kwa mifano.
//!
//! Kama mwandishi wa maktaba, unapaswa kupendelea kila wakati kutekeleza [`From<T>`][`From`] au [`TryFrom<T>`][`TryFrom`] badala ya [`Into<U>`][`Into`] au [`TryInto<U>`][`TryInto`], kwani [`From`] na [`TryFrom`] hutoa kubadilika zaidi na hutoa utekelezaji sawa wa [`Into`] au [`TryInto`] bure, shukrani kwa utekelezaji wa blanketi kwenye maktaba ya kawaida.
//! Unapolenga toleo kabla ya Rust 1.41, inaweza kuwa muhimu kutekeleza [`Into`] au [`TryInto`] moja kwa moja wakati unabadilisha kuwa aina nje ya crate ya sasa.
//!
//! # Utekelezaji wa Kawaida
//!
//! - [`AsRef`] na Urekebishaji wa kiotomatiki wa [`AsMut`] ikiwa aina ya ndani ni kumbukumbu
//! - ["Kutoka"] <U>kwa maana T`inamaanisha ["Into`]`</u><T><U>kwa U`</u>
//! - ["Jaribu Kutoka"] <U>kwa maana T`inamaanisha ["JaribuInto"]`</u><T><U>kwa U`</u>
//! - [`From`] na [`Into`] ni ya kutafakari, ambayo inamaanisha kuwa kila aina inaweza `into` wenyewe na `from` wenyewe
//!
//! Tazama kila trait kwa mifano ya matumizi.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Kazi ya kitambulisho.
///
/// Mambo mawili ni muhimu kutambua juu ya kazi hii:
///
/// - Sio kila wakati sawa na kufungwa kama `|x| x`, kwani kufungwa kunaweza kulazimisha `x` kuwa aina tofauti.
///
/// - Inasonga pembejeo `x` iliyopitishwa kwa kazi.
///
/// Ingawa inaweza kuonekana kuwa ya kushangaza kuwa na kazi ambayo inarudisha tu pembejeo, kuna matumizi ya kupendeza.
///
///
/// # Examples
///
/// Kutumia `identity` kufanya chochote katika mlolongo wa kazi zingine za kupendeza:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Wacha tujifanye kuwa kuongeza moja ni kazi ya kupendeza.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Kutumia `identity` kama kesi ya msingi ya "do nothing" kwa masharti:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Fanya vitu vya kufurahisha zaidi ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Kutumia `identity` kuweka anuwai ya `Some` ya iterator ya `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Inatumika kufanya uongofu wa rejeleo kwa rejeleo nafuu.
///
/// trait hii ni sawa na [`AsMut`] ambayo hutumiwa kubadilisha kati ya marejeleo yanayoweza kubadilika.
/// Ikiwa unahitaji kufanya ubadilishaji wa gharama kubwa ni bora kutekeleza [`From`] na aina `&T` au andika kazi ya kawaida.
///
/// `AsRef` ina saini sawa na [`Borrow`], lakini [`Borrow`] ni tofauti katika nyanja chache:
///
/// - Tofauti na `AsRef`, [`Borrow`] ina blanketi impl kwa `T` yoyote, na inaweza kutumika kukubali rejeleo au thamani.
/// - [`Borrow`] inahitaji pia kwamba [`Hash`], [`Eq`] na [`Ord`] kwa thamani iliyokopwa ni sawa na ile ya thamani inayomilikiwa.
/// Kwa sababu hii, ikiwa unataka kukopa uwanja mmoja tu wa muundo unaweza kutekeleza `AsRef`, lakini sio [`Borrow`].
///
/// **Note: trait hii haipaswi kushindwa **.Ikiwa ubadilishaji unaweza kushindwa, tumia njia ya kujitolea ambayo inarudi [`Option<T>`] au [`Result<T, E>`].
///
/// # Utekelezaji wa Kawaida
///
/// - `AsRef` Urekebishaji wa kiotomatiki ikiwa aina ya ndani ni rejeleo au rejeleo linaloweza kubadilika (kwa mfano: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Kwa kutumia trait bound tunaweza kukubali hoja za aina tofauti maadamu zinaweza kubadilishwa kuwa aina maalum ya `T`.
///
/// Kwa mfano: Kwa kuunda kazi ya generic ambayo inachukua `AsRef<str>` tunaelezea kwamba tunataka kukubali marejeleo yote ambayo yanaweza kubadilishwa kuwa [`&str`] kama hoja.
/// Kwa kuwa [`String`] na [`&str`] hutumia `AsRef<str>` tunaweza kukubali zote kama hoja ya kuingiza.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Inafanya uongofu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Inatumiwa kufanya ubadilishaji wa rejeleo wa bei rahisi unaoweza kubadilika.
///
/// trait hii ni sawa na [`AsRef`] lakini imetumika kubadilisha kati ya marejeleo yanayoweza kubadilika.
/// Ikiwa unahitaji kufanya ubadilishaji wa gharama kubwa ni bora kutekeleza [`From`] na aina `&mut T` au andika kazi ya kawaida.
///
/// **Note: trait hii haipaswi kushindwa **.Ikiwa ubadilishaji unaweza kushindwa, tumia njia ya kujitolea ambayo inarudi [`Option<T>`] au [`Result<T, E>`].
///
/// # Utekelezaji wa Kawaida
///
/// - `AsMut` chaguzi za kiotomatiki ikiwa aina ya ndani ni rejeleo linaloweza kubadilika (kwa mfano: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Kutumia `AsMut` kama trait bound kwa kazi ya generic tunaweza kukubali marejeleo yote yanayoweza kubadilika ambayo yanaweza kubadilishwa kuwa aina ya `&mut T`.
/// Kwa sababu [`Box<T>`] hutumia `AsMut<T>` tunaweza kuandika kazi `add_one` ambayo inachukua hoja zote ambazo zinaweza kubadilishwa kuwa `&mut u64`.
/// Kwa sababu [`Box<T>`] hutumia `AsMut<T>`, `add_one` inakubali hoja za aina `&mut Box<u64>` pia:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Inafanya uongofu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Ubadilishaji wa thamani-kwa-thamani ambao hutumia thamani ya pembejeo.Kinyume cha [`From`].
///
/// Mtu anapaswa kuepuka kutekeleza [`Into`] na atekeleze [`From`] badala yake.
/// Utekelezaji wa [`From`] hutoa moja kwa moja utekelezaji wa shukrani ya [`Into`] kwa utekelezaji wa blanketi katika maktaba ya kawaida.
///
/// Pendelea kutumia [`Into`] juu ya [`From`] wakati ukitaja trait bound kwenye kazi ya generic ili kuhakikisha kuwa aina zinazotumia [`Into`] tu zinaweza kutumika pia.
///
/// **Note: trait hii haipaswi kushindwa **.Ikiwa uongofu unaweza kushindwa, tumia [`TryInto`].
///
/// # Utekelezaji wa Kawaida
///
/// - ["Kutoka"] `<T>kwa maana U` inamaanisha `Into<U> for T`
/// - [`Into`] ni ya kutafakari, ambayo inamaanisha kuwa `Into<T> for T` inatekelezwa
///
/// # Utekelezaji wa [`Into`] kwa ubadilishaji wa aina za nje katika matoleo ya zamani ya Rust
///
/// Kabla ya Rust 1.41, ikiwa aina ya marudio haikuwa sehemu ya crate ya sasa basi haungeweza kutekeleza [`From`] moja kwa moja.
/// Kwa mfano, chukua nambari hii:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Hii itashindwa kukusanya katika matoleo ya zamani ya lugha kwa sababu sheria za watoto yatima za Rust zilikuwa ngumu zaidi.
/// Kupita hii, unaweza kutekeleza [`Into`] moja kwa moja:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Ni muhimu kuelewa kuwa [`Into`] haitoi utekelezaji wa [`From`] (kama [`From`] inavyofanya na [`Into`]).
/// Kwa hivyo, unapaswa kujaribu kila wakati kutekeleza [`From`] na kisha urudi kwa [`Into`] ikiwa [`From`] haiwezi kutekelezwa.
///
/// # Examples
///
/// [`String`] vifaa [`Into`]`<`[`Vec`] `<<[[` u8`]`>> >>:
///
/// Ili kuelezea kwamba tunataka kazi ya generic kuchukua hoja zote ambazo zinaweza kubadilishwa kuwa aina maalum ya `T`, tunaweza kutumia trait bound ya [`Into`]`<T>`.
///
/// Kwa mfano: Kazi `is_hello` inachukua hoja zote zinazoweza kubadilishwa kuwa [`Vec`]`<<"[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Inafanya uongofu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Inatumika kufanya mabadiliko ya thamani-kwa-thamani wakati unatumia thamani ya kuingiza.Ni kurudiana kwa [`Into`].
///
/// Mtu anapaswa kupendelea kutekeleza `From` zaidi ya [`Into`] kwa sababu kutekeleza `From` hutoa moja kwa moja utekelezaji wa [`Into`] shukrani kwa utekelezaji wa blanketi kwenye maktaba ya kawaida.
///
///
/// Tekeleza tu [`Into`] unapolenga toleo kabla ya Rust 1.41 na ubadilishe kuwa aina nje ya crate ya sasa.
/// `From` hakuweza kufanya aina hizi za ubadilishaji katika matoleo ya awali kwa sababu ya sheria za mayatima za Rust.
/// Tazama [`Into`] kwa maelezo zaidi.
///
/// Pendelea kutumia [`Into`] juu ya kutumia `From` wakati wa kubainisha trait bound kwenye kazi ya generic.
/// Kwa njia hii, aina ambazo hutekeleza [`Into`] moja kwa moja zinaweza kutumika kama hoja pia.
///
/// `From` pia ni muhimu sana wakati wa kufanya utunzaji wa makosa.Wakati wa kujenga kazi ambayo inaweza kushindwa, aina ya kurudi kwa ujumla itakuwa ya fomu `Result<T, E>`.
/// `From` trait inarahisisha utunzaji wa makosa kwa kuruhusu kazi kurudisha aina ya kosa moja ambayo inajumuisha aina nyingi za makosa.Tazama sehemu ya "Examples" na [the book][book] kwa maelezo zaidi.
///
/// **Note: trait hii haipaswi kushindwa **.Ikiwa uongofu unaweza kushindwa, tumia [`TryFrom`].
///
/// # Utekelezaji wa Kawaida
///
/// - `From<T> for U` inamaanisha ["Into`] <U>kwa T`</u>
/// - `From` ni ya kutafakari, ambayo inamaanisha kuwa `From<T> for T` inatekelezwa
///
/// # Examples
///
/// [`String`] kutekeleza `From<&str>`:
///
/// Ubadilishaji wazi kutoka kwa `&str` hadi Kamba hufanywa kama ifuatavyo:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Wakati wa kufanya utunzaji wa makosa mara nyingi ni muhimu kutekeleza `From` kwa aina yako ya makosa.
/// Kwa kubadilisha aina za makosa ya msingi kuwa aina ya makosa yetu ya kawaida ambayo hujumuisha aina ya makosa ya msingi, tunaweza kurudisha aina ya kosa moja bila kupoteza habari juu ya sababu ya msingi.
/// Opereta '?' hubadilisha kiatomati aina ya makosa kuwa aina ya makosa yetu kwa kupiga `Into<CliError>::into` ambayo hutolewa kiatomati wakati wa kutekeleza `From`.
/// Mkusanyaji kisha anabainisha ni utekelezaji gani wa `Into` unapaswa kutumiwa.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Inafanya uongofu.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ubadilishaji uliojaribu ambao hutumia `self`, ambayo inaweza kuwa au inaweza kuwa ghali.
///
/// Waandishi wa maktaba kawaida hawapaswi kutekeleza moja kwa moja trait, lakini wanapaswa kupendelea kutekeleza [`TryFrom`] trait, ambayo inatoa kubadilika zaidi na hutoa utekelezaji sawa wa `TryInto` bure, kwa sababu ya utekelezaji wa blanketi katika maktaba ya kawaida.
/// Kwa habari zaidi juu ya hili, angalia nyaraka za [`Into`].
///
/// # Utekelezaji wa `TryInto`
///
/// Hii inakabiliwa na vizuizi sawa na hoja kama kutekeleza [`Into`], angalia hapo kwa maelezo.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Aina hiyo ilirejeshwa ikiwa kuna hitilafu ya ubadilishaji.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Inafanya uongofu.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Mabadiliko rahisi na salama ambayo yanaweza kushindwa kwa njia inayodhibitiwa chini ya hali fulani.Ni kurudiana kwa [`TryInto`].
///
/// Hii ni muhimu wakati unafanya ubadilishaji wa aina ambayo inaweza kufanikiwa kidogo lakini inaweza pia kuhitaji utunzaji maalum.
/// Kwa mfano, hakuna njia ya kubadilisha [`i64`] kuwa [`i32`] kwa kutumia [`From`] trait, kwa sababu [`i64`] inaweza kuwa na thamani ambayo [`i32`] haiwezi kuwakilisha na kwa hivyo ubadilishaji utapoteza data.
///
/// Hii inaweza kushughulikiwa kwa kupunguza [`i64`] kuwa [`i32`] (kimsingi kutoa thamani ya ["i64"] modulo [`i32::MAX`]) au kwa kurudisha tu [`i32::MAX`], au kwa njia nyingine.
/// [`From`] trait imekusudiwa kwa wongofu kamili, kwa hivyo `TryFrom` trait inamjulisha programu wakati ubadilishaji wa aina unaweza kuwa mbaya na huwaacha waamue jinsi ya kuishughulikia.
///
/// # Utekelezaji wa Kawaida
///
/// - `TryFrom<T> for U` inamaanisha ["JaribuInto"] <U>kwa T`</u>
/// - [`try_from`] ni ya kutafakari, ambayo inamaanisha kuwa `TryFrom<T> for T` inatekelezwa na haiwezi kushindwa-aina inayohusiana ya `Error` ya kupiga `T::try_from()` kwa thamani ya aina `T` ni [`Infallible`].
/// Wakati aina ya [`!`] imetulia [`Infallible`] na [`!`] itakuwa sawa.
///
/// `TryFrom<T>` inaweza kutekelezwa kama ifuatavyo:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kama ilivyoelezewa, [`i32`] inatumia `TryFrom <` [`i64`]`>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Kimya kimya hukata `big_number`, inahitaji kugundua na kushughulikia ukata baada ya ukweli.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Hurejesha hitilafu kwa sababu `big_number` ni kubwa sana kuweza kutoshea `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Inarudi `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Aina hiyo ilirejeshwa ikiwa kuna hitilafu ya ubadilishaji.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Inafanya uongofu.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ATHARI ZA UJUMLA
////////////////////////////////////////////////////////////////////////////////

// Unapoinua juu&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Unapoinua zaidi ya &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): badilisha impls zilizo hapo juu za&/&mut na moja ifuatayo zaidi:
// // Kama inainua juu ya Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Ukubwa> AsRef <U>ya D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut inainua zaidi ya &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): badilisha impl ya hapo juu ya &mut na moja ifuatayo zaidi:
// // AsMut inainua DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Ukubwa> AsMut <U>kwa D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Kutoka kwa maana ya kuingia
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Kutoka (na hivyo kuingia) ni fikra
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Ujumbe wa utulivu:** Impl hii bado haipo, lakini sisi ni "reserving space" kuiongeza kwenye future.
/// Tazama [rust-lang/rust#64715][#64715] kwa maelezo.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): fanya marekebisho yenye kanuni badala yake.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Jaribu Kutoka kwa maana JaribuInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Mabadiliko yasiyoweza kukosea ni sawa na wongofu wa makosa na aina ya hitilafu isiyokaliwa.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPRS YA UWANDA
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// AINA YA KOSA YA KOSA
////////////////////////////////////////////////////////////////////////////////

/// Aina ya makosa ya makosa ambayo hayawezi kutokea kamwe.
///
/// Kwa kuwa enum hii haina lahaja, thamani ya aina hii haiwezi kamwe kuwepo.
/// Hii inaweza kuwa na manufaa kwa API za kawaida ambazo zinatumia [`Result`] na kuashiria aina ya makosa, kuonyesha kuwa matokeo ni [`Ok`] kila wakati.
///
/// Kwa mfano, [`TryFrom`] trait (ubadilishaji unaorudisha [`Result`]) ina utekelezaji wa blanketi kwa kila aina ambapo utekelezaji wa [`Into`] wa nyuma upo.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Utangamano wa Future
///
/// Enum hii ina jukumu sawa na [the `!`“never”type][never], ambayo haina msimamo katika toleo hili la Rust.
/// Wakati `!` imetengezwa, tunapanga kuifanya `Infallible` kuwa jina la aina hiyo:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Na mwishowe hudharau `Infallible`.
///
/// Walakini kuna kesi moja ambapo syntax ya `!` inaweza kutumika kabla `!` haijatulizwa kama aina kamili: katika nafasi ya aina ya kurudi kwa kazi.
/// Hasa, inawezekana utekelezaji wa aina mbili tofauti za kiashiria cha kazi:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Kwa `Infallible` kuwa enum, nambari hii halali.
/// Walakini wakati `Infallible` inakuwa jina la never type, `impl`s mbili zitaanza kuingiliana na kwa hivyo zitakataliwa na sheria za mshikamano wa trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}