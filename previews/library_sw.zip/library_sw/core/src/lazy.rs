//! Thamani za uvivu na uanzishaji wa wakati mmoja wa data tuli.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Kiini ambacho kinaweza kuandikwa kwa mara moja tu.
///
/// Tofauti na `RefCell`, `OnceCell` hutoa tu marejeleo ya `&T` ya pamoja kwa thamani yake.
/// Tofauti na `Cell`, `OnceCell` haiitaji kunakili au kubadilisha thamani kuipata.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: imeandikwa kwa mara moja.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Inaunda seli mpya tupu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Inapata rejeleo la thamani ya msingi.
    ///
    /// Hurejesha `None` ikiwa seli haina kitu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // USALAMA: Salama kwa sababu ya mabadiliko ya "ndani"
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Inapata rejeleo linaloweza kubadilika kwa thamani ya msingi.
    ///
    /// Hurejesha `None` ikiwa seli haina kitu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // USALAMA: Salama kwa sababu tuna ufikiaji wa kipekee
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Inaweka yaliyomo kwenye seli hadi `value`.
    ///
    /// # Errors
    ///
    /// Njia hii inarudi `Ok(())` ikiwa seli ilikuwa tupu na `Err(value)` ikiwa imejaa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // USALAMA: Salama kwa sababu hatuwezi kuwa na ukopaji unaoweza kuingiliana
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // USALAMA: Hapa ndipo mahali pekee tunapoweka mpangilio, hakuna mbio
        // kwa sababu ya reentrancy/concurrency inawezekana, na tumeangalia kwamba yanayopangwa kwa sasa ni `None`, kwa hivyo maandishi haya yanadumisha uvamizi wa "ndani".
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Hupata yaliyomo kwenye seli, akianzisha na `f` ikiwa seli ilikuwa tupu.
    ///
    /// # Panics
    ///
    /// Ikiwa `f` panics, panic imeenezwa kwa anayepiga, na seli hubaki bila kuzinduliwa.
    ///
    ///
    /// Ni kosa kuanzisha tena seli kutoka `f`.Kufanya hivyo husababisha panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Hupata yaliyomo kwenye seli, akianzisha na `f` ikiwa seli ilikuwa tupu.
    /// Ikiwa seli ilikuwa tupu na `f` ilishindwa, hitilafu inarejeshwa.
    ///
    /// # Panics
    ///
    /// Ikiwa `f` panics, panic imeenezwa kwa anayepiga, na seli hubaki bila kuzinduliwa.
    ///
    ///
    /// Ni kosa kuanzisha tena seli kutoka `f`.Kufanya hivyo husababisha panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Kumbuka kuwa * aina zingine za uanzishaji wa reentrant zinaweza kusababisha UB (angalia mtihani wa `reentrant_init`).
        // Ninaamini kuwa kuondoa hii `assert`, wakati kuweka `set/get` itakuwa sauti, lakini inaonekana kuwa bora kwa panic, badala ya kutumia kimya thamani ya zamani.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Inatumia seli, kurudisha thamani iliyofungwa.
    ///
    /// Hurejesha `None` ikiwa seli ilikuwa tupu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Kwa sababu `into_inner` inachukua `self` kwa thamani, mkusanyaji huthibitisha kwamba kwa sasa haijakopwa.
        // Kwa hivyo ni salama kuondoka `Option<T>`.
        self.inner.into_inner()
    }

    /// Inachukua thamani kutoka kwa `OnceCell` hii, na kuirudisha kwenye hali isiyoanzishwa.
    ///
    /// Haina athari na inarudi `None` ikiwa `OnceCell` haijaanzishwa.
    ///
    /// Usalama umehakikishiwa kwa kuhitaji kumbukumbu inayoweza kubadilika.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Thamani ambayo imeanzishwa kwenye ufikiaji wa kwanza.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   tayari kuanzisha
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Inaunda thamani mpya ya uvivu na kazi iliyopewa ya kuanzisha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Hulazimisha tathmini ya thamani hii ya uvivu na kurudisha rejeleo la matokeo.
    ///
    ///
    /// Hii ni sawa na kuingiza `Deref`, lakini ni wazi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Inaunda thamani mpya ya uvivu kutumia `Default` kama kazi ya kuanzisha.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}