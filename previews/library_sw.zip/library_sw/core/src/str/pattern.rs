//! Kamba ya muundo wa API.
//!
//! Mfano wa API hutoa utaratibu wa generic wa kutumia aina tofauti za muundo wakati unatafuta kupitia kamba.
//!
//! Kwa maelezo zaidi, angalia traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], na [`DoubleEndedSearcher`].
//!
//! Ingawa API hii haina msimamo, inadhihirishwa kupitia API thabiti kwenye aina ya [`str`].
//!
//! # Examples
//!
//! [`Pattern`] ni [implemented][pattern-impls] katika API thabiti ya [`&str`][`str`], [`char`], vipande vya [`char`], na kazi na kufungwa kwa kutekeleza `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // muundo wa char
//! assert_eq!(s.find('n'), Some(2));
//! // kipande cha muundo wa chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // muundo wa kufungwa
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Mfano wa kamba.
///
/// `Pattern<'a>` inaelezea kuwa aina ya utekelezaji inaweza kutumika kama muundo wa kamba kwa kutafuta katika [`&'a str`][str].
///
/// Kwa mfano, zote `'a'` na `"aa"` ni mifumo ambayo ingefanana kwenye faharisi `1` kwenye kamba `"baaaab"`.
///
/// trait yenyewe hufanya kama mjenzi wa aina inayohusiana ya [`Searcher`], ambayo inafanya kazi halisi ya kupata matukio ya muundo katika kamba.
///
///
/// Kulingana na aina ya muundo, tabia ya njia kama [`str::find`] na [`str::contains`] zinaweza kubadilika.
/// Jedwali hapa chini linaelezea baadhi ya tabia hizo.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Mtafuta anayehusishwa wa muundo huu
    type Searcher: Searcher<'a>;

    /// Huunda mtafuta inayohusiana kutoka `self` na `haystack` kutafuta ndani.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Hukagua kama muundo unalingana mahali popote kwenye nyasi
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Hukagua kama muundo unalingana mbele ya nyasi
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Hukagua kama muundo unalingana nyuma ya nyasi
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Huondoa muundo kutoka mbele ya nyasi, ikiwa inafanana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // USALAMA: `Searcher` inajulikana kurudisha fahirisi halali.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Huondoa muundo kutoka nyuma ya nyasi, ikiwa inafanana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // USALAMA: `Searcher` inajulikana kurudisha fahirisi halali.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Matokeo ya kupiga simu [`Searcher::next()`] au [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Inadhihirisha kuwa mechi ya muundo imepatikana kwenye `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Inadhihirisha kuwa `haystack[a..b]` imekataliwa kama mechi inayowezekana ya muundo.
    ///
    /// Kumbuka kuwa kunaweza kuwa na zaidi ya `Reject` kati ya `Mechi` mbili, hakuna sharti la wao kuunganishwa kuwa moja.
    ///
    ///
    Reject(usize, usize),
    /// Inafahamisha kuwa kila baiti ya nyasi imetembelewa, na kumaliza uwasilishaji.
    ///
    Done,
}

/// Mtafuta kwa muundo wa kamba.
///
/// trait hii inatoa njia za kutafuta mechi zisizoingiliana za muundo unaoanzia mbele ya (left) ya kamba.
///
/// Itatekelezwa na aina zinazohusiana za `Searcher` za [`Pattern`] trait.
///
/// trait imewekwa alama kuwa si salama kwa sababu fahirisi zilizorejeshwa na njia za [`next()`][Searcher::next] zinahitajika kulala kwenye mipaka halali ya utf8 kwenye haystack.
/// Hii inawezesha watumiaji wa trait hii kukata nyasi bila hundi za ziada za wakati wa kukimbia.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter kwa kamba ya msingi itafutwe
    ///
    /// Daima tutarudi [`&str`][str] sawa.
    fn haystack(&self) -> &'a str;

    /// Inafanya hatua inayofuata ya utaftaji kutoka mbele.
    ///
    /// - Hurejesha [`Match(a, b)`][SearchStep::Match] ikiwa `haystack[a..b]` inalingana na muundo.
    /// - Hurejesha [`Reject(a, b)`][SearchStep::Reject] ikiwa `haystack[a..b]` haiwezi kulinganisha muundo, hata kidogo.
    /// - Hurejesha [`Done`][SearchStep::Done] ikiwa kila baiti ya nyasi imetembelewa.
    ///
    /// Mtiririko wa [`Match`][SearchStep::Match] na [`Reject`][SearchStep::Reject] maadili hadi [`Done`][SearchStep::Done] utakuwa na safu za faharisi zilizo karibu, zisizoingiliana, zinazofunika nyasi nzima, na kuweka mipaka ya utf8.
    ///
    ///
    /// Matokeo ya [`Match`][SearchStep::Match] yanahitaji kuwa na muundo mzima unaofanana, hata hivyo matokeo ya [`Reject`][SearchStep::Reject] yanaweza kugawanywa kuwa vipande vingi vya karibu.Masafa yote yanaweza kuwa na urefu wa sifuri.
    ///
    /// Kama mfano, muundo `"aaa"` na haystack `"cbaaaaab"` inaweza kutoa mkondo
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Inapata matokeo yafuatayo ya [`Match`][SearchStep::Match].Tazama [`next()`][Searcher::next].
    ///
    /// Tofauti na [`next()`][Searcher::next], hakuna hakikisho kwamba safu zilizorejeshwa za hii na [`next_reject`][Searcher::next_reject] zitapishana.
    /// Hii itarudi `(start_match, end_match)`, ambapo start_match ni faharisi ya wapi mechi inaanzia, na end_match ndio faharisi baada ya kumalizika kwa mechi.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Inapata matokeo yafuatayo ya [`Reject`][SearchStep::Reject].Tazama [`next()`][Searcher::next] na [`next_match()`][Searcher::next_match].
    ///
    /// Tofauti na [`next()`][Searcher::next], hakuna hakikisho kwamba safu zilizorejeshwa za hii na [`next_match`][Searcher::next_match] zitapishana.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Kitafuta-tafuta cha muundo wa kamba.
///
/// trait hii inatoa njia za kutafuta mechi zisizoingiliana za muundo kuanzia nyuma ya (right) ya kamba.
///
/// Itatekelezwa na aina zinazohusiana za [`Searcher`] za [`Pattern`] trait ikiwa muundo unasaidia kuutafuta kutoka nyuma.
///
///
/// Safu za faharisi zilizorejeshwa na trait hazihitajiki kufanana kabisa na zile za utaftaji wa mbele kwa kurudi nyuma.
///
/// Kwa sababu hii trait imewekwa alama kuwa si salama, waone kama mzazi trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Inafanya hatua inayofuata ya utaftaji kutoka nyuma.
    ///
    /// - Hurejesha [`Match(a, b)`][SearchStep::Match] ikiwa `haystack[a..b]` inalingana na muundo.
    /// - Hurejesha [`Reject(a, b)`][SearchStep::Reject] ikiwa `haystack[a..b]` haiwezi kulinganisha muundo, hata kidogo.
    /// - Hurejesha [`Done`][SearchStep::Done] ikiwa kila baiti ya nyasi imetembelewa
    ///
    /// Mtiririko wa [`Match`][SearchStep::Match] na [`Reject`][SearchStep::Reject] maadili hadi [`Done`][SearchStep::Done] utakuwa na safu za faharisi zilizo karibu, zisizoingiliana, zinazofunika nyasi nzima, na kuweka mipaka ya utf8.
    ///
    ///
    /// Matokeo ya [`Match`][SearchStep::Match] yanahitaji kuwa na muundo mzima unaofanana, hata hivyo matokeo ya [`Reject`][SearchStep::Reject] yanaweza kugawanywa kuwa vipande vingi vya karibu.Masafa yote yanaweza kuwa na urefu wa sifuri.
    ///
    /// Kama mfano, muundo `"aaa"` na haystack `"cbaaaaab"` inaweza kutoa mto `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Inapata matokeo ya [`Match`][SearchStep::Match] inayofuata.
    /// Tazama [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Inapata matokeo ya [`Reject`][SearchStep::Reject] inayofuata.
    /// Tazama [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Alama trait kuelezea kuwa [`ReverseSearcher`] inaweza kutumika kwa utekelezaji wa [`DoubleEndedIterator`].
///
/// Kwa hili, uingizaji wa [`Searcher`] na [`ReverseSearcher`] unahitaji kufuata masharti haya:
///
/// - Matokeo yote ya `next()` yanahitaji kufanana na matokeo ya `next_back()` kwa mpangilio wa nyuma.
/// - `next()` na `next_back()` wanahitaji kuishi kama ncha mbili za anuwai ya maadili, kwamba hawawezi "walk past each other".
///
/// # Examples
///
/// `char::Searcher` ni `DoubleEndedSearcher` kwa sababu kutafuta [`char`] inahitaji tu kutazama moja kwa wakati, ambayo hufanya sawa kutoka pande zote mbili.
///
/// `(&str)::Searcher` sio `DoubleEndedSearcher` kwa sababu muundo `"aa"` kwenye haystack `"aaa"` inalingana kama `"[aa]a"` au `"a[aa]"`, kulingana na ni upande gani unatafutwa.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl kwa char
/////////////////////////////////////////////////////////////////////////////

/// Aina inayohusiana ya `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // mvamizi wa usalama: `finger`/`finger_back` lazima iwe faharisi halali ya utf8 ya `haystack` Kiasi hiki kinaweza kuvunjika *ndani ya* next_match na next_match_back, hata hivyo lazima zitoke na vidole kwenye mipaka halali ya nambari ya nambari.
    //
    //
    /// `finger` ni faharisi ya baiti ya sasa ya utaftaji wa mbele.
    /// Fikiria kwamba iko kabla ya ka kwenye faharisi yake, yaani
    /// `haystack[finger]` ni kaa ya kwanza ya kipande lazima tuchunguze wakati wa kutafuta mbele
    ///
    finger: usize,
    /// `finger_back` ni faharisi ya sasa ya baiti ya utaftaji wa nyuma.
    /// Fikiria kwamba iko baada ya kaa kwenye faharisi yake, yaani
    /// haystack [finger_back, 1] ni kawiti ya mwisho ya kipande ambacho lazima tukague wakati wa kutafuta mbele (na kwa hivyo baiti ya kwanza kukaguliwa wakati wa kupiga next_back()).
    ///
    finger_back: usize,
    /// Tabia inayotafutwa
    needle: char,

    // mvumbuzi wa usalama: `utf8_size` lazima iwe chini ya 5
    /// Idadi ya baiti `needle` huchukua wakati imesimbwa katika utf8.
    utf8_size: usize,
    /// Nakala iliyosimbwa ya utf8 ya `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // USALAMA: 1-4 dhamana ya usalama wa `get_unchecked`
        // 1. `self.finger` na `self.finger_back` huwekwa kwenye mipaka ya unicode (hii haibadiliki)
        // 2. `self.finger >= 0` kwa kuwa huanza saa 0 na huongezeka tu
        // 3. `self.finger < self.finger_back` kwa sababu vinginevyo char `iter` itarudi `SearchStep::Done`
        // 4.
        // `self.finger` huja kabla ya mwisho wa nyasi kwa sababu `self.finger_back` inaanzia mwisho na inapungua tu
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // ongeza idadi ndogo ya tabia ya sasa bila kusimba tena kama utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // pata nyasi baada ya mhusika wa mwisho kupatikana
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // baiti ya mwisho ya USALAMA wa sindano iliyosimbwa ya X01: tunayo isiyobadilika kuwa `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Kidole kipya ni faharisi ya baiti tuliyoipata, pamoja na moja, kwa kuwa tulikumbuka hati ndogo ya mwisho ya mhusika.
                //
                // Kumbuka kuwa hii haitupatii kidole kila wakati kwenye mpaka wa UTF8.
                // Ikiwa hatukupata tabia yetu tunaweza kuwa tumeorodhesha baiti isiyo ya mwisho ya baiti 3 au 4-baiti.
                // Hatuwezi kuruka tu kwa njia inayofuata inayofaa ya kuanza kwa sababu mhusika kama ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` tutapata kila wakati kupata kaiti ya pili wakati wa kutafuta ya tatu.
                //
                //
                // Walakini, hii ni sawa kabisa.
                // Wakati tunayo isiyobadilika kuwa self.finger iko kwenye mpaka wa UTF8, kibadilishaji hiki hakitegemei ndani ya njia hii (inategemewa katika CharSearcher::next()).
                //
                // Tunatoka tu kwa njia hii tunapofikia mwisho wa kamba, au ikiwa tunapata kitu.Tunapopata kitu `finger` itawekwa mpaka wa UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // hakupata chochote, toka
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // wacha ijayo_katae utekelezaji chaguomsingi kutoka kwa Kitafutaji trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // USALAMA: angalia maoni ya next() hapo juu
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // toa malipo ya baiti ya herufi ya sasa bila kusimba tena kama utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // pata nyasi hadi lakini bila kujumuisha herufi ya mwisho iliyotafutwa
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // baiti ya mwisho ya USALAMA wa sindano iliyosimbwa ya X01: tunayo isiyobadilika kuwa `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // tulitafuta kipande ambacho kilikamilishwa na self.finger, ongeza self.finger kurudisha faharisi asili
                //
                let index = self.finger + index;
                // memrchr atarudisha faharisi ya baiti tunayotaka kupata.
                // Kwa hali ya tabia ya ASCII, hii ndio kweli tungetaka kidole chetu kipya kiwe ("after" the char found in the paradigm of reverse iteration).
                //
                // Kwa chars za multibyte tunahitaji kuruka chini na idadi ya ka zaidi wanayo kuliko ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // songa kidole kabla ya mhusika kupatikana (yaani, katika faharisi ya mwanzo)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Hatuwezi kutumia finger_back=index, size + 1 hapa.
                // Ikiwa tumepata char ya mwisho ya herufi ya ukubwa tofauti (au baiti ya kati ya mhusika tofauti) tunahitaji kugonga kidole_cha chini hadi `index`.
                // Hii vile vile hufanya `finger_back` iwe na uwezo tena wa kuwa kwenye mpaka, lakini hii ni sawa kwani tunatoka tu kwenye kazi hii kwenye mpaka au wakati nyasi imetafutwa kabisa.
                //
                //
                // Tofauti na next_match hii haina shida ya ka mara kwa mara katika utf-8 kwa sababu tunatafuta baiti ya mwisho, na tunaweza tu kupata baiti ya mwisho wakati wa kutafuta nyuma.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // hakupata chochote, toka
                return None;
            }
        }
    }

    // hebu ijayo_kataa_kutumia utekelezaji chaguomsingi kutoka kwa Kitafutaji trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Utafutaji wa chars ambazo ni sawa na [`char`] uliyopewa.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl kwa kifuniko cha MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Linganisha urefu wa iterator ya kipande cha ndani cha baiti ili kupata urefu wa char ya sasa
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Linganisha urefu wa iterator ya kipande cha ndani cha baiti ili kupata urefu wa char ya sasa
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl kwa&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Badilisha/Ondoa kwa sababu ya utata wa maana.

/// Aina inayohusiana ya `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Utafutaji wa chars ambazo ni sawa na yoyote ya "char" kwenye kipande.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl kwa F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Aina inayohusiana ya `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Utafutaji wa ["char"] unaolingana na kiarifu kilichopewa.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl kwa&&str
/////////////////////////////////////////////////////////////////////////////

/// Wajumbe kwa uingizaji wa `&str`.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl kwa &str
/////////////////////////////////////////////////////////////////////////////

/// Utafutaji usiogawanyika wa substring.
///
/// Itashughulikia muundo `""` kama kurudisha mechi tupu katika kila mpaka wa herufi.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Hukagua kama muundo unalingana mbele ya nyasi.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Huondoa muundo kutoka mbele ya nyasi, ikiwa inafanana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // USALAMA: kiambishi awali kilithibitishwa tu kuwepo.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Hukagua kama muundo unalingana nyuma ya nyasi.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Huondoa muundo kutoka nyuma ya nyasi, ikiwa inafanana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // USALAMA: kiambishi kilithibitishwa tu kuwa kipo.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Njia mbili mtaftaji wa njia kuu
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Aina inayohusiana ya `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // sindano tupu inakataa kila char na inalingana na kila kamba tupu kati yao
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // Utafutaji wa Mbili hutengeneza fahirisi halali *za Mechi* ambazo hugawanyika kwa mipaka ya char muda mrefu ikiwa inalingana sawa na kwamba nyasi na sindano ni halali UTF-8 *Inakataa* kutoka kwa algorithm inaweza kuanguka kwa fahirisi yoyote, lakini tutawatembea kwa mikono hadi mpaka wa tabia inayofuata. , ili wawe salama utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ruka mpaka wa pili wa char
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // andika kesi za `true` na `false` kuhamasisha mkusanyaji kutaja kesi mbili tofauti.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ruka mpaka wa pili wa char
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // andika `true` na `false`, kama `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Hali ya ndani ya njia mbili za utaftaji wa njia ndogo ya utaftaji.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// faharisi muhimu ya ujasusi
    crit_pos: usize,
    /// faharisi muhimu ya sababu ya sindano iliyobadilishwa
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ni ugani (sio sehemu ya algorithm ya njia mbili);
    /// ni 64-bit "fingerprint" ambapo kila seti `j` inalingana na (byte&63)==j iliyopo kwenye sindano.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index ndani ya sindano kabla ambayo tayari tumefananisha
    memory: usize,
    /// index ndani ya sindano baada ya ambayo tayari tumefananisha
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Ufafanuzi unaosomeka haswa wa kile kinachoendelea hapa unaweza kupatikana katika kitabu cha Crochemore na kitabu cha Rytter "Text Algorithms", sura ya 13.
        // Hasa angalia nambari ya "Algorithm CP" kwenye uk.
        // 323.
        //
        // Kinachoendelea ni kwamba tuna sababu muhimu (u, v) ya sindano, na tunataka kuamua ikiwa u ni kiambishi cha&v [.. kipindi].
        // Ikiwa ni, tunatumia "Algorithm CP1".
        // Vinginevyo tunatumia "Algorithm CP2", ambayo imeboreshwa kwa wakati wa sindano ni kubwa.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // kesi ya kipindi kifupi-kipindi ni sawa hesabu tofauti muhimu kwa sindano iliyoachwa x=u 'v' wapi | v '|<period(x).
            //
            // Hii inaharakishwa na kipindi kinachojulikana tayari.
            // Kumbuka kuwa kesi kama x= "acba" inaweza kusambazwa mbele zaidi (crit_pos=1, period=3) huku ikijumuishwa na takriban kipindi cha nyuma (crit_pos=2, period=2).
            // Tunatumia uboreshaji uliopewa uliyopewa lakini tunaweka kipindi halisi.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // kesi ya muda mrefu-tuna takriban kwa kipindi halisi, na usitumie kukariri.
            //
            //
            // Takriban kipindi hicho na max(|u|, |v|) + 1 iliyofungwa chini.
            // Sababu muhimu ni bora kutumia kwa utaftaji wa mbele na wa nyuma.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Thamani ya dummy kuashiria kuwa kipindi ni kirefu
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Moja ya maoni makuu ya Njia Mbili ni kwamba tunaingiza sindano katika nusu mbili, (u, v), na kuanza kujaribu kupata v kwenye nyasi kwa kutambaza kushoto kwenda kulia.
    // Ikiwa v inalingana, tunajaribu kukufananisha na skanning kulia kwenda kushoto.
    // Je! Ni umbali gani tunaweza kuruka tunapokutana na mismatch yote yanategemea ukweli kwamba (u, v) ni sababu muhimu kwa sindano.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` hutumia `self.position` kama mshale wake
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Angalia kuwa tuna nafasi ya kutafuta katika nafasi + sindano_last haiwezi kufurika ikiwa tunafikiria vipande vimefungwa na masafa ya isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Ruka haraka na sehemu kubwa ambazo hazihusiani na safu yetu
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Angalia ikiwa sehemu sahihi ya sindano inalingana
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Angalia ikiwa sehemu ya kushoto ya sindano inalingana
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Tumepata mechi!
            let match_pos = self.position;

            // Note: ongeza self.period badala ya needle.len() kuwa na mechi zinazoingiliana
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // weka needle.len(), self.period kwa mechi zinazoingiliana
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Inafuata maoni katika `next()`.
    //
    // Ufafanuzi ni ulinganifu, na period(x) = period(reverse(x)) na local_period(u, v) = local_period(reverse(v), reverse(u)), kwa hivyo ikiwa (u, v) ni sababu muhimu, ndivyo ilivyo (reverse(v), reverse(u)).
    //
    //
    // Kwa kesi ya nyuma tumehesabu sababu muhimu x=u 'v' (uwanja `crit_pos_back`).Tunahitaji | u |<period(x) kwa kesi ya mbele na hivyo | v '|<period(x) kwa upande wa nyuma.
    //
    // Kutafuta kwa kurudi nyuma kupitia nyasi, tunatafuta mbele kupitia nyasi iliyogeuzwa na sindano iliyobadilishwa, inayofanana kwanza u 'na kisha v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` hutumia `self.end` kama mshale wake-ili `next()` na `next_back()` zijitegemea.
        //
        let old_end = self.end;
        'search: loop {
            // Angalia kuwa tuna nafasi ya kutafuta mwisho, needle.len() itazunguka wakati hakuna nafasi zaidi, lakini kwa sababu ya mipaka ya urefu wa kipande haiwezi kuzunguka kwa urefu wa nyasi.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Ruka haraka na sehemu kubwa ambazo hazihusiani na safu yetu
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Angalia ikiwa sehemu ya kushoto ya sindano inalingana
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Angalia ikiwa sehemu sahihi ya sindano inalingana
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Tumepata mechi!
            let match_pos = self.end - needle.len();
            // Note: sub self.period badala ya needle.len() kuwa na mechi zinazoingiliana
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Tumia kiambishi cha juu kabisa cha `arr`.
    //
    // Kiambishi cha juu kabisa ni uwezekano muhimu wa kuhesabu (u, v) wa `arr`.
    //
    // Anarudi (`i`, `p`) ambapo `i` ni faharisi ya kuanzia ya v na `p` ni kipindi cha v.
    //
    // `order_greater` huamua ikiwa mpangilio wa lexical ni `<` au `>`.
    // Amri zote mbili lazima zihesabiwe-kuagiza na `i` kubwa hutoa sababu muhimu.
    //
    //
    // Kwa kesi za kipindi kirefu, kipindi kinachosababishwa sio sawa (ni kifupi sana).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Inalingana na i kwenye karatasi
        let mut right = 1; // Inalingana na j kwenye karatasi
        let mut offset = 0; // Inalingana na k kwenye karatasi, lakini kuanzia saa 0
        // ili kulinganisha indexing ya msingi wa 0.
        let mut period = 1; // Inalingana na p kwenye karatasi

        while let Some(&a) = arr.get(right + offset) {
            // `left` itakuwa inbound wakati `right` iko.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Kiambishi ni kidogo, kipindi ni kiambishi kamili hadi sasa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Mapema kupitia kurudia kwa kipindi cha sasa.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Kiambishi ni kubwa, anza kutoka eneo la sasa.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Tumia kiambishi cha juu kabisa cha nyuma ya `arr`.
    //
    // Kiambishi cha juu kabisa ni uwezekano muhimu wa kuhesabu (u ', v') wa `arr`.
    //
    // Hurejesha `i` ambapo `i` ni faharisi ya kuanzia ya v ', kutoka nyuma;
    // inarudi mara moja wakati kipindi cha `known_period` kinafikiwa.
    //
    // `order_greater` huamua ikiwa mpangilio wa lexical ni `<` au `>`.
    // Amri zote mbili lazima zihesabiwe-kuagiza na `i` kubwa hutoa sababu muhimu.
    //
    //
    // Kwa kesi za kipindi kirefu, kipindi kinachosababishwa sio sawa (ni kifupi sana).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Inalingana na i kwenye karatasi
        let mut right = 1; // Inalingana na j kwenye karatasi
        let mut offset = 0; // Inalingana na k kwenye karatasi, lakini kuanzia saa 0
        // ili kulinganisha indexing ya msingi wa 0.
        let mut period = 1; // Inalingana na p kwenye karatasi
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Kiambishi ni kidogo, kipindi ni kiambishi kamili hadi sasa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Mapema kupitia kurudia kwa kipindi cha sasa.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Kiambishi ni kubwa, anza kutoka eneo la sasa.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// MbiliWayStr Strategy inaruhusu algorithm ama kuruka mechi zisizo haraka haraka iwezekanavyo, au kufanya kazi kwa hali ambayo hutoa Vimekataa haraka.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Ruka kulinganisha vipindi haraka iwezekanavyo
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Anakataa mara kwa mara
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}