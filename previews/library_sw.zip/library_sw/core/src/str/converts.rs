//! Njia za kuunda `str` kutoka kwa kipande cha ka.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Hubadilisha kipande cha ka kuwa kipande cha kamba.
///
/// Kipande cha kamba ([`&str`]) kimeundwa na ka ([`u8`]), na kipande cha byte ([`&[u8]`][byteslice]) kimeundwa na ka, kwa hivyo kazi hii inabadilika kati ya hizo mbili.
/// Sio vipande vyote vya baiti ni vipande halali vya kamba, hata hivyo: [`&str`] inahitaji kuwa ni UTF-8 halali.
/// `from_utf8()` hundi ili kuhakikisha kuwa ka ni halali UTF-8, na kisha inafanya uongofu.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ikiwa una hakika kuwa kipande cha baiti ni halali UTF-8, na hautaki kupata kichwa cha ukaguzi wa uhalali, kuna toleo lisilo salama la kazi hii, [`from_utf8_unchecked`], ambayo ina tabia sawa lakini inaruka hundi.
///
///
/// Ikiwa unahitaji `String` badala ya `&str`, fikiria [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Kwa sababu unaweza kugawanya-kutenga `[u8; N]`, na unaweza kuchukua [`&[u8]`][byteslice] yake, kazi hii ni njia moja ya kuwa na kamba iliyotengwa kwa stack.Kuna mfano wa hii katika sehemu ya mifano hapa chini.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Hurejesha `Err` ikiwa kipande sio UTF-8 na maelezo kwa nini kipande kilichotolewa sio UTF-8.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::str;
///
/// // baiti zingine, katika vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tunajua ka hizi ni halali, kwa hivyo tumia `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Baiti zisizo sahihi:
///
/// ```
/// use std::str;
///
/// // ka fulani batili, katika vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Tazama hati za [`Utf8Error`] kwa maelezo zaidi juu ya aina ya makosa ambayo yanaweza kurudishwa.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // baiti zingine, katika safu iliyotengwa kwa stack
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Tunajua ka hizi ni halali, kwa hivyo tumia `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // USALAMA: Tumia tu uthibitishaji.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Hugeuza kipande cha baiti kinachoweza kubadilika kuwa kipande cha kamba kinachoweza kubadilika.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" kama vector inayoweza kubadilika
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Kama tunavyojua ka hizi ni halali, tunaweza kutumia `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Baiti zisizo sahihi:
///
/// ```
/// use std::str;
///
/// // Baiti zingine batili katika vector inayoweza kubadilika
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Tazama hati za [`Utf8Error`] kwa maelezo zaidi juu ya aina ya makosa ambayo yanaweza kurudishwa.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // USALAMA: Tumia tu uthibitishaji.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Hubadilisha kipande cha ka kuwa kipande cha kamba bila kuangalia kuwa kamba ina UTF-8 halali.
///
/// Angalia toleo salama, [`from_utf8`], kwa habari zaidi.
///
/// # Safety
///
/// Kazi hii sio salama kwa sababu haiangalii kama baiti zilizopitishwa kwake ni UTF-8 halali.
/// Ikiwa kizuizi hiki kimekiukwa, matokeo yasiyofafanuliwa ya tabia, kama Rust iliyobaki inadhania kuwa [`&str`] s ni halali UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::str;
///
/// // baiti zingine, katika vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // USALAMA: mpigaji lazima ahakikishe kuwa kaiti `v` ni UTF-8 halali.
    // Pia inategemea `&str` na `&[u8]` kuwa na mpangilio sawa.
    unsafe { mem::transmute(v) }
}

/// Hubadilisha kipande cha ka kuwa kipande cha kamba bila kuangalia kuwa kamba ina UTF-8 halali;toleo linaloweza kubadilika.
///
///
/// Tazama toleo lisilobadilika, [`from_utf8_unchecked()`] kwa habari zaidi.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // USALAMA: mpigaji lazima ahakikishe kuwa kaiti `v`
    // ni halali UTF-8, kwa hivyo kutupwa kwa `*mut str` ni salama.
    // Pia, dereferensi ya pointer ni salama kwa sababu pointer hiyo hutoka kwa rejea ambayo imehakikishiwa kuwa halali kwa kuandika.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}