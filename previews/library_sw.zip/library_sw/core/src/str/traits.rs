//! Utekelezaji wa Trait kwa `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Inatekeleza kuagiza kwa nyuzi.
///
/// Kamba zimeagizwa [lexicographically](Ord#lexicographical-comparison) na maadili yao ya baiti.
/// Hii inaamuru nambari za nambari za Unicode kulingana na nafasi zao kwenye chati za nambari.
/// Hii sio lazima iwe sawa na mpangilio wa "alphabetical", ambayo inatofautiana na lugha na eneo.
/// Kupanga kamba kulingana na viwango vinavyokubalika kitamaduni kunahitaji data maalum ya eneo ambalo liko nje ya wigo wa aina ya `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Inatekeleza shughuli za kulinganisha kwenye kamba.
///
/// Kamba zinalinganishwa [lexicographically](Ord#lexicographical-comparison) na maadili yao ya ka.
/// Hii inalinganisha nambari za nambari za Unicode kulingana na nafasi zao kwenye chati za nambari.
/// Hii sio lazima iwe sawa na mpangilio wa "alphabetical", ambayo inatofautiana na lugha na eneo.
/// Kulinganisha masharti kulingana na viwango vinavyokubalika kitamaduni inahitaji data maalum ya eneo ambayo iko nje ya wigo wa aina ya `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Inatumia kukataza substring na syntax `&self[..]` au `&mut self[..]`.
///
/// Hurejesha kipande cha kamba nzima, yaani, inarudi `&self` au `&mut self`.Sawa na `&self [0 ..
/// len] `au`&mut mut [0 ..
/// len]`.
/// Tofauti na shughuli zingine za uorodheshaji, hii haiwezi kamwe panic.
///
/// Operesheni hii ni *O*(1).
///
/// Kabla ya 1.20.0, shughuli hizi za uorodheshaji bado zilisaidiwa na utekelezaji wa moja kwa moja wa `Index` na `IndexMut`.
///
/// Sawa na `&self[0 .. len]` au `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Inatumia kukataza substring na syntax `&self[begin .. end]` au `&mut self[begin .. end]`.
///
/// Hurejesha kipande cha kamba iliyopewa kutoka kwa fungu la baiti [`start`, `end`).
///
/// Operesheni hii ni *O*(1).
///
/// Kabla ya 1.20.0, shughuli hizi za uorodheshaji bado zilisaidiwa na utekelezaji wa moja kwa moja wa `Index` na `IndexMut`.
///
/// # Panics
///
/// Panics ikiwa `begin` au `end` haionyeshi kipengee cha kuanzia cha tabia (kama inavyofafanuliwa na `is_char_boundary`), ikiwa ni `begin > end`, au ikiwa `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // haya mapenzi panic:
/// // baiti 2 iko ndani ya `ö`:
/// // &s [2 ..3];
///
/// // baiti 8 iko ndani ya `老`&s [1 ..
/// // 8];
///
/// // baiti 100 iko nje ya kamba&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // USALAMA: umeangalia tu kuwa `start` na `end` ziko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            // Tuliangalia pia mipaka ya char, kwa hivyo hii ni UTF-8 halali.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // USALAMA: umeangalia tu kuwa `start` na `end` ziko kwenye mpaka wa char.
            // Tunajua pointer ni ya kipekee kwa sababu tumeipata kutoka `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // USALAMA: mpigaji dhamana kwamba `self` iko katika mipaka ya `slice`
        // ambayo inakidhi masharti yote ya `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // USALAMA: angalia maoni ya `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary hundi kwamba faharisi iko katika [0, .len()] haiwezi kutumia tena `get` kama ilivyo hapo juu, kwa sababu ya shida ya NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // USALAMA: umeangalia tu kuwa `start` na `end` ziko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Inatumia kukataza substring na syntax `&self[.. end]` au `&mut self[.. end]`.
///
/// Hurejesha kipande cha kamba iliyopewa kutoka kwa fungu la baiti [`0`, `end`).
/// Sawa na `&self[0 .. end]` au `&mut self[0 .. end]`.
///
/// Operesheni hii ni *O*(1).
///
/// Kabla ya 1.20.0, shughuli hizi za uorodheshaji bado zilisaidiwa na utekelezaji wa moja kwa moja wa `Index` na `IndexMut`.
///
/// # Panics
///
/// Panics ikiwa `end` haionyeshi kipengee cha kuanzia cha tabia (kama inavyofafanuliwa na `is_char_boundary`), au ikiwa `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // USALAMA: angalia tu kuwa `end` iko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // USALAMA: angalia tu kuwa `end` iko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // USALAMA: angalia tu kuwa `end` iko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Inatumia kukataza substring na syntax `&self[begin ..]` au `&mut self[begin ..]`.
///
/// Hurejesha kipande cha kamba iliyopewa kutoka kwa fungu la baiti [`start`, `len`).Sawa na `&ubinafsi [anza ..
/// len] `au`&mut mut [anza ..
/// len]`.
///
/// Operesheni hii ni *O*(1).
///
/// Kabla ya 1.20.0, shughuli hizi za uorodheshaji bado zilisaidiwa na utekelezaji wa moja kwa moja wa `Index` na `IndexMut`.
///
/// # Panics
///
/// Panics ikiwa `begin` haionyeshi kipengee cha kuanzia cha tabia (kama inavyofafanuliwa na `is_char_boundary`), au ikiwa `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // USALAMA: angalia tu kuwa `start` iko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // USALAMA: angalia tu kuwa `start` iko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // USALAMA: mpigaji dhamana kwamba `self` iko katika mipaka ya `slice`
        // ambayo inakidhi masharti yote ya `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // USALAMA: sawa na `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // USALAMA: angalia tu kuwa `start` iko kwenye mpaka wa char,
            // na tunapita kwa kumbukumbu salama, kwa hivyo thamani ya kurudi pia itakuwa moja.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Inatumia kukataza substring na syntax `&self[begin ..= end]` au `&mut self[begin ..= end]`.
///
/// Hurejesha kipande cha mfuatano uliopewa kutoka fungu la baiti [`begin`, `end`].Sawa na `&self [begin .. end + 1]` au `&mut self[begin .. end + 1]`, isipokuwa `end` ina kiwango cha juu cha `usize`.
///
/// Operesheni hii ni *O*(1).
///
/// # Panics
///
/// Panics ikiwa `begin` haionyeshi kipengee cha kuanzia cha mhusika (kama inavyofafanuliwa na `is_char_boundary`), ikiwa `end` haionyeshi alama ya kumaliza ya tabia (`end + 1` labda ni malipo ya kahawia ya kuanzia au sawa na `len`), ikiwa `begin > end`, au ikiwa `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Inatumia kukataza substring na syntax `&self[..= end]` au `&mut self[..= end]`.
///
/// Hurejesha kipande cha kamba iliyopewa kutoka kwa fungu la [0, `end`].
/// Sawa na `&self [0 .. end + 1]`, isipokuwa ikiwa `end` ina kiwango cha juu cha `usize`.
///
/// Operesheni hii ni *O*(1).
///
/// # Panics
///
/// Panics ikiwa `end` haionyeshi kukomesha baiti ya herufi (`end + 1` labda ni pesa ya kuanzia kama inavyoelezwa na `is_char_boundary`, au sawa na `len`), au ikiwa `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // USALAMA: mpigaji lazima azingatie mkataba wa usalama wa `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Changanua thamani kutoka kwa kamba
///
/// Njia ya [`from_str`] ya "KutokaStr" hutumiwa mara kwa mara, kupitia njia ya ["str"] ya [`parse`].
/// Tazama nyaraka za ["parse`] kwa mifano.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` haina kigezo cha maisha, na kwa hivyo unaweza kuchanganua tu aina ambazo hazina parameta ya maisha yenyewe.
///
/// Kwa maneno mengine, unaweza kuchanganua `i32` na `FromStr`, lakini sio `&i32`.
/// Unaweza kuchanganua muundo ulio na `i32`, lakini sio moja ambayo ina `&i32`.
///
/// # Examples
///
/// Utekelezaji wa kimsingi wa `FromStr` kwa mfano `Point` aina:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Hitilafu inayohusiana ambayo inaweza kurudishwa kutoka kwa kuchanganua.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Inachanganua kamba `s` ili kurudisha thamani ya aina hii.
    ///
    /// Ikiwa kuchanganua kunafanikiwa, rudisha thamani ndani ya [`Ok`], vinginevyo wakati kamba imeumbizwa vibaya rudisha kosa maalum kwa [`Err`] ya ndani.
    /// Aina ya kosa ni maalum kwa utekelezaji wa trait.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi na [`i32`], aina inayotumia `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Changanua `bool` kutoka kwa kamba.
    ///
    /// Inazaa `Result<bool, ParseBoolError>`, kwa sababu `s` inaweza au haiwezi kusomeka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Kumbuka, katika hali nyingi, njia ya `.parse()` kwenye `str` ni sahihi zaidi.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}