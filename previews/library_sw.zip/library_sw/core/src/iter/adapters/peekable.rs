use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Iterator iliyo na `peek()` ambayo inarudisha rejeleo la hiari kwa kipengee kinachofuata.
///
///
/// `struct` hii imeundwa na njia ya [`peekable`] kwenye [`Iterator`].
/// Tazama nyaraka zake kwa zaidi.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Kumbuka thamani iliyotengwa, hata ikiwa haikuwa.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Inayoonekana lazima ikumbuke ikiwa hakuna Imeonekana katika njia ya `.peek()`.
// Inahakikisha kuwa `.peek();.peek();` au `.peek();.next();` huendeleza tu iterator ya msingi mara moja.
// Hii haifanyi yenyewe iterator ichanganyike.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Hurejesha rejeleo la thamani ya next() bila kusongesha iterator.
    ///
    /// Kama [`next`], ikiwa kuna thamani, imefungwa kwa `Some(T)`.
    /// Lakini ikiwa upigaji kura umekwisha, `None` inarejeshwa.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Kwa sababu `peek()` inarudisha rejeleo, na iterators nyingi hupindukia juu ya marejeleo, kunaweza kuwa na hali ya kutatanisha ambapo dhamana ya kurudi ni rejeleo mbili.
    /// Unaweza kuona athari hii katika mifano hapa chini.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() hebu tuone kwenye future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Iterator haiendelei hata ikiwa sisi ni `peek` mara nyingi
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Baada ya iterator kumaliza, vile vile `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Hurejesha rejeleo inayoweza kubadilika kwa thamani ya next() bila kusongesha kisanidi.
    ///
    /// Kama [`next`], ikiwa kuna thamani, imefungwa kwa `Some(T)`.
    /// Lakini ikiwa upigaji kura umekwisha, `None` inarejeshwa.
    ///
    /// Kwa sababu `peek_mut()` inarudisha rejeleo, na iterators nyingi hupindukia juu ya marejeleo, kunaweza kuwa na hali ya kutatanisha ambapo dhamana ya kurudi ni rejeleo mbili.
    /// Unaweza kuona athari hii katika mifano hapa chini.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Kama na `peek()`, tunaweza kuona ndani ya future bila kuendeleza iterator.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Tazama kwenye iterator na uweke thamani nyuma ya rejeleo linaloweza kubadilika.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Thamani tunayoweka inaonekana tena wakati iterator inaendelea.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Tumia na urudishe thamani inayofuata ya iterator hii ikiwa hali ni kweli.
    /// Ikiwa `func` inarudi `true` kwa thamani inayofuata ya iterator hii, tumia na uirudishe.
    /// Vinginevyo, rudisha `None`.
    /// # Examples
    /// Tumia nambari ikiwa ni sawa na 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Bidhaa ya kwanza ya iterator ni 0;itumie.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Bidhaa inayofuata imerudishwa sasa ni 1, kwa hivyo `consume` itarudi `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` inaokoa thamani ya kipengee kinachofuata ikiwa haikuwa sawa na `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Tumia nambari yoyote chini ya 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Tumia nambari zote chini ya 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Thamani inayofuata itarejeshwa itakuwa 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Kwa kuwa tuliita `self.next()`, tulitumia `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Tumia na urudishe kipengee kinachofuata ikiwa ni sawa na `expected`.
    /// # Example
    /// Tumia nambari ikiwa ni sawa na 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Bidhaa ya kwanza ya iterator ni 0;itumie.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Bidhaa inayofuata imerudishwa sasa ni 1, kwa hivyo `consume` itarudi `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` inaokoa thamani ya kipengee kinachofuata ikiwa haikuwa sawa na `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // USALAMA: kazi isiyo salama kusambaza kazi isiyo salama na mahitaji sawa
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}