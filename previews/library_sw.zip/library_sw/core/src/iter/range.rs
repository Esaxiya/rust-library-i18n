use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Vitu ambavyo vina wazo la shughuli za "mrithi *na* mtangulizi *.
///
/// Operesheni ya *mrithi* inahamia kwenye maadili yanayolinganisha zaidi.
/// Operesheni ya "mtangulizi" inaelekea kwenye maadili ambayo yanalinganisha kidogo.
///
/// # Safety
///
/// trait hii ni `unsafe` kwa sababu utekelezaji wake lazima uwe sahihi kwa usalama wa utekelezaji wa `unsafe trait TrustedLen`, na matokeo ya kutumia trait hii yanaweza kuaminiwa na nambari ya `unsafe` kuwa sahihi na kutimiza majukumu yaliyoorodheshwa.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Hurejesha idadi ya hatua *za mrithi* zinazohitajika kutoka `start` hadi `end`.
    ///
    /// Hurejesha `None` ikiwa idadi ya hatua zingefurika `usize` (au haina mwisho, au ikiwa `end` haiwezi kufikiwa kamwe).
    ///
    ///
    /// # Invariants
    ///
    /// Kwa `a` yoyote, `b`, na `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ikiwa na tu ikiwa `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ikiwa na tu ikiwa `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` tu ikiwa `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` ikiwa na ikiwa tu `a == b`
    ///   * Kumbuka kuwa `a <= b` haina maana ya _not_ `steps_between(&a, &b) != None`;
    ///     hii ndio kesi wakati itahitaji hatua zaidi ya `usize::MAX` kufikia `b`
    /// * `steps_between(&a, &b) == None` ikiwa `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Hurejesha thamani ambayo itapatikana kwa kuchukua *mrithi* wa mara `self` `count`.
    ///
    /// Ikiwa hii itafurika anuwai ya maadili inayoungwa mkono na `Self`, inarudisha `None`.
    ///
    /// # Invariants
    ///
    /// Kwa `a` yoyote, `n`, na `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Kwa `a` yoyote, `n`, na `m` ambapo `n + m` haizidi:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Kwa `a` yoyote na `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Hurejesha thamani ambayo itapatikana kwa kuchukua *mrithi* wa mara `self` `count`.
    ///
    /// Ikiwa hii itafurika anuwai ya maadili inayoungwa mkono na `Self`, kazi hii inaruhusiwa kwa panic, kufunika, au kueneza.
    ///
    /// Tabia iliyopendekezwa ni kwa panic wakati madai ya utatuzi yamewezeshwa, na kufunika au kueneza vinginevyo.
    ///
    /// Nambari isiyo salama haipaswi kutegemea usahihi wa tabia baada ya kufurika.
    ///
    /// # Invariants
    ///
    /// Kwa `a` yoyote, `n`, na `m`, ambapo hakuna kufurika kutokea:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Kwa `a` yoyote na `n`, ambapo hakuna kufurika hutokea:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Hurejesha thamani ambayo itapatikana kwa kuchukua *mrithi* wa mara `self` `count`.
    ///
    /// # Safety
    ///
    /// Ni tabia isiyojulikana kwa operesheni hii kufurika anuwai ya maadili inayoungwa mkono na `Self`.
    /// Ikiwa huwezi kuhakikisha kuwa hii haitafurika, tumia `forward` au `forward_checked` badala yake.
    ///
    /// # Invariants
    ///
    /// Kwa `a` yoyote:
    ///
    /// * ikiwa kuna `b` kama vile `b > a`, ni salama kupiga `Step::forward_unchecked(a, 1)`
    /// * ikiwa kuna `b`, `n` kama vile `steps_between(&a, &b) == Some(n)`, ni salama kupiga `Step::forward_unchecked(a, m)` kwa `m <= n` yoyote.
    ///
    ///
    /// Kwa `a` yoyote na `n`, ambapo hakuna kufurika hutokea:
    ///
    /// * `Step::forward_unchecked(a, n)` ni sawa na `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Hurejesha thamani ambayo itapatikana kwa kuchukua *mtangulizi* wa mara `self` `count`.
    ///
    /// Ikiwa hii itafurika anuwai ya maadili inayoungwa mkono na `Self`, inarudisha `None`.
    ///
    /// # Invariants
    ///
    /// Kwa `a` yoyote, `n`, na `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Kwa `a` yoyote na `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Hurejesha thamani ambayo itapatikana kwa kuchukua *mtangulizi* wa mara `self` `count`.
    ///
    /// Ikiwa hii itafurika anuwai ya maadili inayoungwa mkono na `Self`, kazi hii inaruhusiwa kwa panic, kufunika, au kueneza.
    ///
    /// Tabia iliyopendekezwa ni kwa panic wakati madai ya utatuzi yamewezeshwa, na kufunika au kueneza vinginevyo.
    ///
    /// Nambari isiyo salama haipaswi kutegemea usahihi wa tabia baada ya kufurika.
    ///
    /// # Invariants
    ///
    /// Kwa `a` yoyote, `n`, na `m`, ambapo hakuna kufurika kutokea:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Kwa `a` yoyote na `n`, ambapo hakuna kufurika hutokea:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Hurejesha thamani ambayo itapatikana kwa kuchukua *mtangulizi* wa mara `self` `count`.
    ///
    /// # Safety
    ///
    /// Ni tabia isiyojulikana kwa operesheni hii kufurika anuwai ya maadili inayoungwa mkono na `Self`.
    /// Ikiwa huwezi kuhakikisha kuwa hii haitafurika, tumia `backward` au `backward_checked` badala yake.
    ///
    /// # Invariants
    ///
    /// Kwa `a` yoyote:
    ///
    /// * ikiwa kuna `b` kama vile `b < a`, ni salama kupiga `Step::backward_unchecked(a, 1)`
    /// * ikiwa kuna `b`, `n` kama vile `steps_between(&b, &a) == Some(n)`, ni salama kupiga `Step::backward_unchecked(a, m)` kwa `m <= n` yoyote.
    ///
    ///
    /// Kwa `a` yoyote na `n`, ambapo hakuna kufurika hutokea:
    ///
    /// * `Step::backward_unchecked(a, n)` ni sawa na `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Hizi bado zimetengenezwa kwa jumla kwa sababu fasihi kamili huamua kwa aina tofauti.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // USALAMA: mpigaji lazima ahakikishe kuwa `start + n` haifuriki.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // USALAMA: mpigaji lazima ahakikishe kuwa `start - n` haifuriki.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Katika utatuzi hujengwa, changamsha panic juu ya kufurika.
            // Hii inapaswa kuboresha kabisa katika ujenzi wa kutolewa.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Je, kufunga math ili kuruhusu mfano `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Katika utatuzi hujengwa, changamsha panic juu ya kufurika.
            // Hii inapaswa kuboresha kabisa katika ujenzi wa kutolewa.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Je, kufunga math ili kuruhusu mfano `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Hii inategemea $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ikiwa n iko nje ya kiwango, `unsigned_start + n` pia ni
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ikiwa n iko nje ya kiwango, `unsigned_start - n` pia ni
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Hii inategemea $i_narrower <=usize
                        //
                        // Kutupa kwa ukubwa kunapanua upana lakini huhifadhi ishara.
                        // Tumia kufunika_sub katika nafasi ya usize na tuma kwa usize kuhesabu tofauti ambayo inaweza kutoshea ndani ya anuwai ya isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Kushughulikia kesi kama `Step::forward(-120_i8, 200) == Some(80_i8)`, ingawa 200 iko nje ya i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Nyongeza ilifurika
                            }
                        }
                        // Ikiwa n iko nje ya anuwai ya mfano
                        // u8, basi ni kubwa kuliko anuwai nzima ya i8 ni pana kwa hivyo `any_i8 + n` lazima ifurike i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Kushughulikia kesi kama `Step::forward(-120_i8, 200) == Some(80_i8)`, ingawa 200 iko nje ya i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Utoaji ulifurika
                            }
                        }
                        // Ikiwa n iko nje ya anuwai ya mfano
                        // u8, basi ni kubwa kuliko anuwai nzima ya i8 ni pana kwa hivyo `any_i8 - n` lazima ifurike i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ikiwa tofauti ni kubwa sana kwa mfano
                            // i128, pia itakuwa kubwa sana kwa usize na bits chache.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // USALAMA: res ni kiwango halali cha unicode
            // (chini ya 0x110000 na sio katika 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // USALAMA: res ni kiwango halali cha unicode
        // (chini ya 0x110000 na sio katika 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // USALAMA: mpigaji lazima ahakikishe kuwa hii haifuriki
        // anuwai ya thamani ya char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // USALAMA: mpigaji lazima ahakikishe kuwa hii haifuriki
            // anuwai ya thamani ya char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // USALAMA: kwa sababu ya mkataba uliopita, hii imehakikishiwa
        // na mpiga simu kuwa char halali.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // USALAMA: mpigaji lazima ahakikishe kuwa hii haifuriki
        // anuwai ya thamani ya char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // USALAMA: mpigaji lazima ahakikishe kuwa hii haifuriki
            // anuwai ya thamani ya char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // USALAMA: kwa sababu ya mkataba uliopita, hii imehakikishiwa
        // na mpiga simu kuwa char halali.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // USALAMA: tumechunguza sharti tu
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // USALAMA: tumechunguza sharti tu
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Hizi macros hutengeneza uingizaji wa `ExactSizeIterator` kwa anuwai anuwai.
//
// * `ExactSizeIterator::len` inahitajika kurudisha `usize` kila wakati, kwa hivyo hakuna masafa ambayo yanaweza kuwa ndefu kuliko `usize::MAX`.
//
// * Kwa aina kamili katika `Range<_>` hii ndio kesi kwa aina nyembamba kuliko au pana kama `usize`.
//   Kwa aina kamili katika `RangeInclusive<_>` hii ndio kesi kwa aina * nyembamba kabisa kuliko `usize` kwani kwa mfano
//   `(0..=u64::MAX).len()` itakuwa `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Hizi hazibadiliki kwa sababu ya hoja hapo juu, lakini kuziondoa itakuwa mabadiliko ya kuvunja kwani ziliimarishwa katika Rust 1.0.0.
    // Kwa mfano
    // `(0..66_000_u32).len()` kwa mfano itajikusanya bila kosa au onyo kwenye majukwaa 16-bit, lakini endelea kutoa matokeo yasiyofaa.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Hizi hazibadiliki kwa sababu ya hoja hapo juu, lakini kuziondoa itakuwa mabadiliko ya kuvunja kwani ziliimarishwa katika Rust 1.26.0.
    // Kwa mfano
    // `(0..=u16::MAX).len()` kwa mfano itajikusanya bila kosa au onyo kwenye majukwaa 16-bit, lakini endelea kutoa matokeo yasiyofaa.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // USALAMA: tumechunguza sharti tu
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // USALAMA: tumechunguza sharti tu
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // USALAMA: tumechunguza sharti tu
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // USALAMA: tumechunguza sharti tu
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // USALAMA: tumechunguza sharti tu
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // USALAMA: tumechunguza sharti tu
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}