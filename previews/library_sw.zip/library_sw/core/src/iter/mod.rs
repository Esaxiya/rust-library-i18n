//! Iteration ya nje inayoweza kutengenezwa.
//!
//! Ikiwa umejikuta na mkusanyiko wa aina fulani, na inahitajika kufanya operesheni kwenye vitu vya mkusanyiko uliosema, utaingia haraka kwa 'iterators'.
//! Iterators hutumiwa sana katika nambari ya ujinga ya Rust, kwa hivyo inafaa kuwajua.
//!
//! Kabla ya kuelezea zaidi, wacha tuzungumze juu ya jinsi moduli hii imeundwa:
//!
//! # Organization
//!
//! Moduli hii kwa kiasi kikubwa imepangwa na aina:
//!
//! * [Traits] ni sehemu ya msingi: hizi traits hufafanua ni aina gani ya iterators iliyopo na nini unaweza kufanya nao.Njia za traits hizi zinafaa kuweka wakati wa ziada wa kusoma ndani.
//! * [Functions] toa njia kadhaa za kusaidia kuunda iterators msingi.
//! * [Structs] mara nyingi ni aina za kurudi kwa njia anuwai kwenye moduli hii ya traits.Kawaida utataka kuangalia njia ambayo inaunda `struct`, badala ya `struct` yenyewe.
//! Kwa undani zaidi juu ya kwanini, tazama '[Inplating Iterator](#utekelezaji-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Hiyo ndio!Wacha tuchimbe kwenye iterators.
//!
//! # Iterator
//!
//! Moyo na roho ya moduli hii ni [`Iterator`] trait.Kiini cha [`Iterator`] kinaonekana kama hii:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Kitunzi kina njia, [`next`], ambayo ikiitwa, inarudisha [`Chaguo`]`<Item>`.
//! [`next`] itarudi [`Some(Item)`] maadamu kuna vitu, na vikiwa vimechoka kabisa, itarudi `None` kuonyesha kwamba iteration imekamilika.
//! Watafutaji wa kibinafsi wanaweza kuchagua kuanza tena iteration, na kwa hivyo kupiga [`next`] tena inaweza au inaweza kuanza kuanza kurudisha [`Some(Item)`] tena wakati fulani (kwa mfano, angalia [`TryIter`]).
//!
//!
//! Ufafanuzi kamili wa [`Iterator`] unajumuisha njia zingine kadhaa pia, lakini ni njia chaguomsingi, zilizojengwa juu ya [`next`], na kwa hivyo unazipata bure.
//!
//! Iterators pia zinatengenezwa, na ni kawaida kuziunganisha pamoja ili kufanya aina ngumu zaidi za usindikaji.Tazama sehemu ya [Adapters](#adapters) hapa chini kwa maelezo zaidi.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Aina tatu za upigaji kura
//!
//! Kuna njia tatu za kawaida ambazo zinaweza kuunda iterators kutoka kwenye mkusanyiko:
//!
//! * `iter()`, ambayo inazidi juu ya `&T`.
//! * `iter_mut()`, ambayo inazidi juu ya `&mut T`.
//! * `into_iter()`, ambayo inazidi juu ya `T`.
//!
//! Vitu anuwai katika maktaba ya kawaida vinaweza kutekeleza moja au zaidi ya hayo matatu, inapofaa.
//!
//! # Utekelezaji wa Iterator
//!
//! Kuunda iterator yako mwenyewe kunajumuisha hatua mbili: kuunda `struct` kushikilia hali ya iterator, na kisha kutekeleza [`Iterator`] kwa `struct` hiyo.
//! Hii ndio sababu kuna `miundo` mingi katika moduli hii: kuna moja kwa kila iterator na adapta ya iterator.
//!
//! Wacha tufanye iterator iitwayo `Counter` ambayo inahesabu kutoka `1` hadi `5`:
//!
//! ```
//! // Kwanza, muundo:
//!
//! /// Iterator ambayo inahesabu kutoka moja hadi tano
//! struct Counter {
//!     count: usize,
//! }
//!
//! // tunataka hesabu yetu ianze kwa moja, kwa hivyo wacha tuongeze njia ya new() kusaidia.
//! // Hii sio lazima sana, lakini ni rahisi.
//! // Kumbuka kuwa tunaanza `count` kwa sifuri, tutaona ni kwanini katika utekelezaji wa `next()`'s hapa chini.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Halafu, tunatekeleza `Iterator` kwa `Counter` yetu:
//!
//! impl Iterator for Counter {
//!     // tutakuwa tunahesabu na usize
//!     type Item = usize;
//!
//!     // next() ni njia pekee inayohitajika
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Kuongeza hesabu yetu.Hii ndio sababu tulianza sifuri.
//!         self.count += 1;
//!
//!         // Angalia kuona ikiwa tumemaliza kuhesabu au la.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Na sasa tunaweza kuitumia!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Kuita [`next`] kwa njia hii kunarudiwa.Rust ina muundo ambao unaweza kupiga [`next`] kwenye iterator yako, hadi ifike `None`.Wacha tuende juu ya hiyo ijayo.
//!
//! Pia kumbuka kuwa `Iterator` inatoa utekelezaji kamili wa njia kama vile `nth` na `fold` ambazo huita `next` kwa ndani.
//! Walakini, inawezekana pia kuandika utekelezaji wa kawaida wa njia kama `nth` na `fold` ikiwa iterator inaweza kuzihesabu vizuri zaidi bila kupiga `next`.
//!
//! # `for` matanzi na `IntoIterator`
//!
//! Syntax ya kitanzi ya Rust ya `for` ni sukari kwa iterators.Hapa kuna mfano wa msingi wa `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Hii itachapisha nambari moja hadi tano, kila moja kwa laini yao.Lakini utaona kitu hapa: hatujawahi kupiga kitu chochote kwenye vector yetu kutengeneza iterator.Nini kinatoa?
//!
//! Kuna trait kwenye maktaba ya kawaida ya kubadilisha kitu kuwa iterator: [`IntoIterator`].
//! trait hii ina njia moja, [`into_iter`], ambayo hubadilisha kitu kinachotekeleza [`IntoIterator`] kuwa iterator.
//! Wacha tuangalie kitanzi hicho cha `for` tena, na kile mkusanyaji hubadilisha kuwa:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sukari hii kuwa:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Kwanza, tunaita `into_iter()` juu ya thamani.Halafu, tunalingana kwenye iterator ambayo inarudi, ikiita [`next`] mara kwa mara hadi tuone `None`.
//! Wakati huo, sisi `break` tumetoka kitanzi, na tumemaliza kuhesabu.
//!
//! Kuna kitu kidogo cha hila hapa: maktaba ya kawaida ina utekelezaji wa kuvutia wa [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Kwa maneno mengine, [ʻIterator "zote zinatekeleza [`IntoIterator`], kwa kujirudisha tu.Hii inamaanisha mambo mawili:
//!
//! 1. Ikiwa unaandika [`Iterator`], unaweza kuitumia na kitanzi cha `for`.
//! 2. Ikiwa unaunda mkusanyiko, kutekeleza [`IntoIterator`] kwa hiyo itaruhusu mkusanyiko wako utumike na kitanzi cha `for`.
//!
//! # Kuanzisha kwa kumbukumbu
//!
//! Kwa kuwa [`into_iter()`] inachukua `self` kwa thamani, kwa kutumia kitanzi cha `for` ili kupunguza juu ya mkusanyiko hutumia mkusanyiko huo.Mara nyingi, unaweza kutaka kupindua juu ya mkusanyiko bila kuitumia.
//! Makusanyo mengi hutoa njia zinazowapa watendaji juu ya marejeleo, ambayo kwa kawaida huitwa `iter()` na `iter_mut()` mtawaliwa:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` bado inamilikiwa na kazi hii.
//! ```
//!
//! Ikiwa aina ya mkusanyiko `C` inatoa `iter()`, kawaida pia hutumia `IntoIterator` kwa `&C`, na utekelezaji ambao huita tu `iter()`.
//! Vivyo hivyo, mkusanyiko `C` ambao hutoa `iter_mut()` kwa ujumla hutumia `IntoIterator` kwa `&mut C` kwa kuipatia `iter_mut()`.Hii inawezesha kifupi rahisi:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // sawa na `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sawa na `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Wakati makusanyo mengi hutoa `iter()`, sio yote hutoa `iter_mut()`.
//! Kwa mfano, kubadilisha funguo za [`HashSet<T>`] au [`HashMap<K, V>`] kunaweza kuweka mkusanyiko katika hali isiyoendana ikiwa ufunguo wa haraka unabadilika, kwa hivyo makusanyo haya hutoa `iter()` tu.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Kazi ambazo huchukua [`Iterator`] na kurudisha [`Iterator`] nyingine mara nyingi huitwa 'adapta za iterator', kwani ni aina ya 'adapta.
//! pattern'.
//!
//! Adapter za kawaida za iterator ni pamoja na [`map`], [`take`], na [`filter`].
//! Kwa zaidi, angalia nyaraka zao.
//!
//! Ikiwa adapta ya iterator panics, iterator itakuwa katika hali isiyojulikana (lakini salama ya kumbukumbu).
//! Hali hii pia haihakikishiwi kukaa sawa kwenye matoleo ya Rust, kwa hivyo unapaswa kuepuka kutegemea maadili halisi yaliyorudishwa na iterator ambayo ilishikwa na hofu.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (na iterator [adapters](#adapters)) ni *wavivu*. Hii inamaanisha kuwa kuunda iterator sio _do_ kabisa. Hakuna kinachotokea hadi upigie simu [`next`].
//! Hii wakati mwingine ni chanzo cha mkanganyiko wakati wa kuunda iterator tu kwa athari zake.
//! Kwa mfano, njia ya [`map`] inaita kufungwa kwa kila kitu kinachozidi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Hii haitachapisha maadili yoyote, kwani tuliunda tu iterator, badala ya kuitumia.Mkusanyaji atatuonya juu ya tabia ya aina hii:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Njia ya ujinga ya kuandika [`map`] kwa athari zake ni kutumia kitanzi cha `for` au piga njia ya [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Njia nyingine ya kawaida ya kutathmini iterator ni kutumia njia ya [`collect`] kutoa mkusanyiko mpya.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators sio lazima iwe na mwisho.Kama mfano, anuwai ya wazi ni iterator isiyo na kipimo:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ni kawaida kutumia adapta ya [`take`] iterator kugeuza iterator isiyo na kipimo kuwa ya mwisho:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Hii itachapisha nambari `0` kupitia `4`, kila moja kwa laini yao.
//!
//! Kumbuka kuwa njia juu ya wasanidi wa hesabu wasio na mwisho, hata zile ambazo matokeo yake yanaweza kuamua kihesabu wakati wa mwisho, haiwezi kumaliza.
//! Hasa, njia kama [`min`], ambazo kwa jumla zinahitaji kupita kila kitu kwenye iterator, labda hazirudi kwa mafanikio kwa iterators yoyote isiyo na kipimo.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // La hasha!Kitanzi kisicho na mwisho!
//! // `ones.min()` husababisha kitanzi kisicho na mwisho, kwa hivyo hatutafikia hatua hii!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;