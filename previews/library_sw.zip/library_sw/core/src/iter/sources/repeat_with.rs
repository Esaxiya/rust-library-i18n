use crate::iter::{FusedIterator, TrustedLen};

/// Inaunda iterator mpya ambayo inarudia vitu vya aina `A` bila ukomo kwa kutumia kufungwa iliyotolewa, anayerudia, `F: FnMut() -> A`.
///
/// Kazi ya `repeat_with()` inaita anayerudia kurudia tena na tena.
///
/// Iterators zisizo na mwisho kama `repeat_with()` hutumiwa mara nyingi na adapta kama [`Iterator::take()`], ili kuzifanya ziwe na mwisho.
///
/// Ikiwa aina ya kipengee cha iterator unahitaji kutekeleza [`Clone`], na ni sawa kuweka kipengee cha chanzo kwenye kumbukumbu, unapaswa kutumia kazi ya [`repeat()`].
///
///
/// Iterator iliyotengenezwa na `repeat_with()` sio [`DoubleEndedIterator`].
/// Ikiwa unahitaji `repeat_with()` kurudisha [`DoubleEndedIterator`], tafadhali fungua suala la GitHub inayoelezea kesi yako ya matumizi.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::iter;
///
/// // wacha tufikirie tuna thamani ya aina ambayo sio `Clone` au ambayo haitaki kuwa na kumbukumbu bado kwa sababu ni ghali:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // thamani fulani milele:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Kutumia mabadiliko na kwenda mwisho:
///
/// ```rust
/// use std::iter;
///
/// // Kutoka kwa zeroth hadi nguvu ya tatu ya mbili:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... na sasa tumemaliza
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterator ambayo inarudia vitu vya aina `A` bila kikomo kwa kutumia kufungwa `F: FnMut() -> A` iliyotolewa.
///
///
/// `struct` hii imeundwa na kazi ya [`repeat_with()`].
/// Tazama nyaraka zake kwa zaidi.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}