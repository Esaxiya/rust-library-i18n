use crate::fmt;

/// Inaunda iterator mpya ambapo kila iteration inaita kufungwa kwa `F: FnMut() -> Option<T>`.
///
/// Hii inaruhusu kuunda iterator ya kawaida na tabia yoyote bila kutumia syntax ya kitenzi zaidi ya kuunda aina ya kujitolea na kutekeleza [`Iterator`] trait kwa hiyo.
///
/// Kumbuka kuwa iterator ya `FromFn` haifikirii juu ya tabia ya kufungwa, na kwa hivyo kwa uaminifu haitekelezi [`FusedIterator`], au inapita [`Iterator::size_hint()`] kutoka kwa chaguo-msingi `(0, None)`.
///
///
/// Kufungwa kunaweza kutumia unasaji na mazingira yake kufuatilia hali wakati wote.Kulingana na jinsi iterator inatumiwa, hii inaweza kuhitaji kutaja neno kuu la [`move`] kwenye kufungwa.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Wacha tutekeleze tena iterator ya kukabiliana kutoka [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Kuongeza hesabu yetu.Hii ndio sababu tulianza sifuri.
///     count += 1;
///
///     // Angalia kuona ikiwa tumemaliza kuhesabu au la.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterator ambapo kila iteration inaita kufungwa kwa `F: FnMut() -> Option<T>` iliyotolewa.
///
/// `struct` hii imeundwa na kazi ya [`iter::from_fn()`].
/// Tazama nyaraka zake kwa zaidi.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}