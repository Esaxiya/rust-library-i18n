use crate::iter::{FusedIterator, TrustedLen};

/// Inaunda iterator ambayo inazalisha uthamani haswa mara moja kwa kutumia kufungwa iliyotolewa.
///
/// Hii kawaida hutumiwa kurekebisha jenereta ya thamani moja kuwa [`chain()`] ya aina zingine za iteration.
/// Labda unayo iterator ambayo inashughulikia karibu kila kitu, lakini unahitaji kesi maalum zaidi.
/// Labda una kazi ambayo inafanya kazi kwa iterators, lakini unahitaji tu kusindika thamani moja.
///
/// Tofauti na [`once()`], kazi hii itazalisha thamani kwa ombi.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::iter;
///
/// // moja ni namba ya upweke
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // moja tu, ndio tu tunapata
/// assert_eq!(None, one.next());
/// ```
///
/// Kuunganisha pamoja na iterator nyingine.
/// Wacha tuseme kwamba tunataka kupunguza kila faili ya saraka ya `.foo`, lakini pia faili ya usanidi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // tunahitaji kubadilisha kutoka iterator ya DirEntry-s kuwa iterator ya PathBufs, kwa hivyo tunatumia ramani
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // sasa, iterator yetu tu ya faili yetu ya usanidi
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // mnyororo iterators mbili pamoja katika iterator moja kubwa
/// let files = dirs.chain(config);
///
/// // hii itatupa faili zote katika .foo na .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator ambayo hutoa kipengee kimoja cha aina `A` kwa kutumia kufungwa `F: FnOnce() -> A` iliyotolewa.
///
///
/// `struct` hii imeundwa na kazi ya [`once_with()`].
/// Tazama nyaraka zake kwa zaidi.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}