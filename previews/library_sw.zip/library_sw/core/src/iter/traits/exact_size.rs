/// Iterator inayojua urefu wake halisi.
///
/// Wengi [`Iterator`] hawajui ni mara ngapi watapindua, lakini wengine wanajua.
/// Ikiwa iterator inajua ni mara ngapi inaweza kupindukia, kutoa ufikiaji wa habari hiyo inaweza kuwa muhimu.
/// Kwa mfano, ikiwa unataka kurudi nyuma, mwanzo mzuri ni kujua mwisho uko wapi.
///
/// Wakati wa kutekeleza `ExactSizeIterator`, lazima pia utekeleze [`Iterator`].
/// Wakati wa kufanya hivyo, utekelezaji wa [`Iterator::size_hint`]*lazima* irudishe saizi halisi ya iterator.
///
/// Njia ya [`len`] ina utekelezaji wa msingi, kwa hivyo kawaida haupaswi kuitekeleza.
/// Walakini, unaweza kutoa utekelezaji bora kuliko ule wa msingi, kwa hivyo kuizidi katika kesi hii kuna maana.
///
///
/// Kumbuka kuwa trait hii ni trait salama na kwa hivyo haifanyi *na* haiwezi * kuhakikisha kuwa urefu uliorejeshwa ni sahihi.
/// Hii inamaanisha kuwa nambari ya `unsafe`**haipaswi** kutegemea usahihi wa [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait isiyo na utulivu na salama inatoa dhamana hii ya ziada.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// // masafa yenye mipaka inajua haswa itakua mara ngapi
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Katika [module-level docs], tulitekeleza [`Iterator`], `Counter`.
/// Wacha tutekeleze `ExactSizeIterator` kwa hiyo pia:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Tunaweza kuhesabu kwa urahisi idadi iliyobaki ya kurudiwa.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Na sasa tunaweza kuitumia!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Hurejesha urefu halisi wa iterator.
    ///
    /// Utekelezaji unahakikisha kwamba iterator itarudi haswa mara `len()` zaidi ya thamani ya [`Some(T)`], kabla ya kurudisha [`None`].
    ///
    /// Njia hii ina utekelezaji wa msingi, kwa hivyo kawaida haifai kuitekeleza moja kwa moja.
    /// Walakini, ikiwa unaweza kutoa utekelezaji mzuri zaidi, unaweza kufanya hivyo.
    /// Tazama hati za [trait-level] kwa mfano.
    ///
    /// Kazi hii ina dhamana sawa ya usalama kama kazi ya [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// // masafa yenye mipaka inajua haswa itakua mara ngapi
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Madai haya ni ya kujihami kupita kiasi, lakini inakagua isiyobadilika
        // umehakikishiwa na trait.
        // Ikiwa trait hii ingekuwa rust-ya ndani, tunaweza kutumia debug_assert !;sisitiza_eq!itaangalia utekelezaji wote wa mtumiaji wa Rust pia.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Hurejesha `true` ikiwa iterator haina kitu.
    ///
    /// Njia hii ina utekelezaji wa msingi kwa kutumia [`ExactSizeIterator::len()`], kwa hivyo hauitaji kuitumia mwenyewe.
    ///
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}