/// Uongofu kutoka kwa [`Iterator`].
///
/// Kwa kutekeleza `FromIterator` kwa aina, unafafanua jinsi itaundwa kutoka kwa iterator.
/// Hii ni kawaida kwa aina ambazo zinaelezea mkusanyiko wa aina fulani.
///
/// [`FromIterator::from_iter()`] mara chache huitwa wazi, na badala yake hutumiwa kupitia njia ya [`Iterator::collect()`].
///
/// Tazama nyaraka za [`Iterator::collect()`]'s kwa mifano zaidi.
///
/// Angalia pia: [`IntoIterator`].
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Kutumia [`Iterator::collect()`] kutumia kabisa `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Utekelezaji wa `FromIterator` kwa aina yako:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Mkusanyiko wa sampuli, hiyo ni kifuniko tu juu ya Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Wacha tuipe njia kadhaa ili tuweze kuunda moja na kuongeza vitu kwake.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // na tutaweza kutekeleza FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Sasa tunaweza kutengeneza iterator mpya ...
/// let iter = (0..5).into_iter();
///
/// // ... na fanya MyCollection kutoka kwake
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // kukusanya kazi pia!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Inaunda dhamana kutoka kwa iterator.
    ///
    /// Tazama [module-level documentation] kwa zaidi.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Kubadilisha kuwa [`Iterator`].
///
/// Kwa kutekeleza `IntoIterator` kwa aina, unafafanua jinsi itabadilishwa kuwa iterator.
/// Hii ni kawaida kwa aina ambazo zinaelezea mkusanyiko wa aina fulani.
///
/// Faida moja ya kutekeleza `IntoIterator` ni kwamba aina yako itakuwa [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Angalia pia: [`FromIterator`].
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Utekelezaji wa `IntoIterator` kwa aina yako:
///
/// ```
/// // Mkusanyiko wa sampuli, hiyo ni kifuniko tu juu ya Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Wacha tuipe njia kadhaa ili tuweze kuunda moja na kuongeza vitu kwake.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // na tutaweza kutekeleza IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Sasa tunaweza kutengeneza mkusanyiko mpya ...
/// let mut c = MyCollection::new();
///
/// // ... ongeza vitu kadhaa kwake ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... na kisha ibadilishe kuwa Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ni kawaida kutumia `IntoIterator` kama trait bound.Hii inaruhusu aina ya mkusanyiko wa pembejeo ibadilike, maadamu bado ni iterator.
/// Mipaka ya ziada inaweza kutajwa kwa kuzuia juu
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Aina ya vitu vinavyochapishwa tena.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Je! Ni aina gani ya iterator tunayogeuza hii kuwa?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Inaunda iterator kutoka kwa thamani.
    ///
    /// Tazama [module-level documentation] kwa zaidi.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Panua mkusanyiko na yaliyomo kwenye iterator.
///
/// Iterators hutengeneza safu ya maadili, na makusanyo pia yanaweza kuzingatiwa kama safu ya maadili.
/// `Extend` trait huziba pengo hili, hukuruhusu kupanua mkusanyiko kwa kujumuisha yaliyomo kwenye iterator hiyo.
/// Wakati wa kupanua mkusanyiko na ufunguo uliopo tayari, kiingilio hicho kinasasishwa au, katika hali ya makusanyo ambayo inaruhusu ingizo nyingi zilizo na funguo sawa, ingizo hilo linaingizwa.
///
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// // Unaweza kupanua Kamba na chars kadhaa:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Utekelezaji wa `Extend`:
///
/// ```
/// // Mkusanyiko wa sampuli, hiyo ni kifuniko tu juu ya Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Wacha tuipe njia kadhaa ili tuweze kuunda moja na kuongeza vitu kwake.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kwa kuwa MyCollection ina orodha ya i32s, tunatekeleza Panua kwa i32
/// impl Extend<i32> for MyCollection {
///
///     // Hii ni rahisi kidogo na saini ya aina halisi: tunaweza kupiga simu kupanua kwenye kitu chochote ambacho kinaweza kugeuzwa kuwa Iterator ambayo hutupa i32s.
///     // Kwa sababu tunahitaji i32s kuweka kwenye MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Utekelezaji ni wa moja kwa moja: kitanzi kupitia iterator, na add() kila kitu kwetu.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // wacha tuongeze ukusanyaji wetu na nambari zingine tatu
/// c.extend(vec![1, 2, 3]);
///
/// // tumeongeza vitu hivi mwishoni
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Huongeza mkusanyiko na yaliyomo kwenye iterator.
    ///
    /// Kwa kuwa hii ndiyo njia pekee inayohitajika kwa trait hii, hati za [trait-level] zina maelezo zaidi.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// // Unaweza kupanua Kamba na chars kadhaa:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Hupanua mkusanyiko na kipengee kimoja.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Uwezo wa akiba katika mkusanyiko wa idadi iliyopewa ya vitu vya ziada.
    ///
    /// Utekelezaji chaguo-msingi haufanyi chochote.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}