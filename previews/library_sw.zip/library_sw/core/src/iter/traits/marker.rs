/// Iterator ambayo kila wakati inaendelea kutoa `None` wakati imechoka.
///
/// Kupiga simu ijayo kwenye iterator iliyounganishwa ambayo imerudisha `None` mara moja imehakikishiwa kurudi [`None`] tena.
/// trait hii inapaswa kutekelezwa na iterators zote ambazo zina tabia hii kwa sababu inaruhusu kuongeza [`Iterator::fuse()`].
///
///
/// Note: Kwa ujumla, haupaswi kutumia `FusedIterator` katika mipaka ya generic ikiwa unahitaji iterator iliyochanganywa.
/// Badala yake, unapaswa kupiga [`Iterator::fuse()`] kwenye iterator.
/// Ikiwa iterator tayari imechanganywa, kifuniko cha [`Fuse`] cha ziada kitakuwa hakuna-op bila adhabu ya utendaji.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator ambayo inaripoti urefu sahihi kwa kutumia size_hint.
///
/// Iterator inaripoti kidokezo cha ukubwa ambapo ni sawa (vifungo vya chini ni sawa na vifungo vya juu), au kifungo cha juu ni [`None`].
///
/// Pande ya juu lazima iwe tu [`None`] ikiwa urefu halisi wa iterator ni kubwa kuliko [`usize::MAX`].
/// Katika kesi hiyo, kifungo cha chini lazima kiwe [`usize::MAX`], na kusababisha [`Iterator::size_hint()`] ya `(usize::MAX, None)`.
///
/// Iterator lazima itoe haswa idadi ya vitu ilivyoripoti au kutengana kabla ya kufikia mwisho.
///
/// # Safety
///
/// trait hii lazima itekelezwe tu wakati mkataba unashikiliwa.
/// Watumiaji wa trait hii lazima wachunguze [`Iterator::size_hint()`]’s imefungwa juu.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iterator ambayo wakati wa kutoa kitu itakuwa imechukua angalau kitu kimoja kutoka kwa msingi wa [`SourceIter`].
///
/// Kuita njia yoyote inayoendeleza iterator, kwa mfano
/// [`next()`] au [`try_fold()`], inahakikishia kwamba kwa kila hatua angalau thamani moja ya chanzo cha msingi cha iterator imehamishwa na matokeo ya mnyororo wa iterator inaweza kuingizwa mahali pake, ikizingatiwa vikwazo vya muundo wa chanzo huruhusu uingizaji kama huo.
///
/// Kwa maneno mengine hii trait inaonyesha kuwa bomba la iterator linaweza kukusanywa mahali.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}