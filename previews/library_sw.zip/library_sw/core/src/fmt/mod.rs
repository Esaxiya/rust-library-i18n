//! Huduma kwa fomati na uchapishaji masharti.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Marekebisho yanayowezekana yamerudishwa na `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Dalili kwamba yaliyomo yanapaswa kushikamana kushoto.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Dalili kwamba yaliyomo yanapaswa kuwa sawa-sawa.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Dalili kwamba yaliyomo yanapaswa kuwa yaliyokaa katikati.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Aina iliyorejeshwa kwa njia za fomati.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Aina ya kosa ambayo inarudishwa kutoka kwa muundo wa ujumbe kuwa mtiririko.
///
/// Aina hii haitumii usafirishaji wa kosa isipokuwa kosa limetokea.
/// Habari yoyote ya ziada inapaswa kupangwa ili kupitishwa kupitia njia zingine.
///
/// Jambo muhimu kukumbuka ni kwamba aina `fmt::Error` haipaswi kuchanganyikiwa na [`std::io::Error`] au [`std::error::Error`], ambayo unaweza pia kuwa nayo katika upeo.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait ya kuandika au kupangilia katika bafa au mito inayokubali Unicode.
///
/// trait hii inakubali tu data iliyosimbwa ya UTF-8 na sio [flushable].
/// Ikiwa unataka tu kukubali Unicode na hauitaji kuvuta, unapaswa kutekeleza trait;
/// vinginevyo unapaswa kutekeleza [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Anaandika kipande cha kamba kwa mwandishi huyu, na kurudisha ikiwa maandishi yamefaulu.
    ///
    /// Njia hii inaweza kufanikiwa tu ikiwa kipande chote cha kamba kiliandikwa kwa mafanikio, na njia hii haitarudi hadi data yote iwe imeandikwa au kosa linatokea.
    ///
    ///
    /// # Errors
    ///
    /// Kazi hii itarudisha mfano wa [`Error`] kwa kosa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Anaandika [`char`] kwa mwandishi huyu, na kurudisha ikiwa maandishi yamefaulu.
    ///
    /// [`char`] moja inaweza kusimbwa kama ka zaidi ya moja.
    /// Njia hii inaweza kufanikiwa tu ikiwa mlolongo wote wa baiti uliandikwa kwa mafanikio, na njia hii haitarudi hadi data yote iwe imeandikwa au kosa linatokea.
    ///
    ///
    /// # Errors
    ///
    /// Kazi hii itarudisha mfano wa [`Error`] kwa kosa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Gundi ya matumizi ya jumla ya [`write!`] na watekelezaji wa hii trait.
    ///
    /// Njia hii kwa ujumla haipaswi kutafutwa kwa mikono, lakini badala ya kupitia jumla ya [`write!`] yenyewe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Usanidi wa muundo.
///
/// `Formatter` inawakilisha chaguzi anuwai zinazohusiana na muundo.
/// Watumiaji hawajengi `Formatter`s moja kwa moja;rejeleo linaloweza kubadilika kwa moja limepitishwa kwa njia ya `fmt` ya muundo wote wa traits, kama [`Debug`] na [`Display`].
///
///
/// Ili kuingiliana na `Formatter`, utaita njia anuwai za kubadilisha chaguzi anuwai zinazohusiana na uumbizaji.
/// Kwa mifano, tafadhali angalia nyaraka za njia zilizoainishwa kwenye `Formatter` hapa chini.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Hoja kimsingi ni kazi ya muundo inayotumiwa kwa sehemu, sawa na `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Muundo huu unawakilisha "argument" ya kawaida ambayo inachukuliwa na familia ya kazi ya Xprintf.Inayo kazi ya muundo wa dhamana iliyopewa.
/// Wakati wa kukusanya inahakikishwa kuwa kazi na dhamana zina aina sahihi, na kisha muundo huu unatumiwa kutoa hoja kwa aina moja.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Hii inathibitisha dhamana moja thabiti ya kiashiria cha kazi kinachohusiana na indices/counts katika miundombinu ya uumbizaji.
//
// Kumbuka kuwa kazi iliyofafanuliwa kama hiyo haitakuwa sahihi kwani kazi kila wakati huwekwa tagi isiyo na jina_addr na upunguzaji wa sasa kwa LLVM IR, kwa hivyo anwani yao haichukuliwi kuwa muhimu kwa LLVM na kwa hivyo wahusika wa_usize wangeweza kutungwa vibaya.
//
// Katika mazoezi, hatuiti kamwe as_usize juu ya usize usize iliyo na data (kama suala la kizazi tuli cha hoja za kupangilia), kwa hivyo hii ni hundi ya ziada.
//
// Tunataka kuhakikisha kwamba kiboreshaji cha kazi kwenye `USIZE_MARKER` kina anwani inayoambatana na *tu* kwa kazi ambazo pia huchukua `&usize` kama hoja yao ya kwanza.
// Read_volatile hapa inahakikisha kwamba tunaweza kuandaa salama salama kutoka kwa rejeleo lililopitishwa na kwamba anwani hii haionyeshi kazi ya kuchukua-usize.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // USALAMA: ptr ni kumbukumbu
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // USALAMA: `mem::transmute(x)` ni salama kwa sababu
        //     1. `&'b T` huweka maisha yote yaliyotokana na `'b` (ili usiwe na maisha yasiyo na mipaka)
        //     2.
        //     `&'b T` na `&'b Opaque` zina mpangilio wa kumbukumbu sawa (wakati `T` ni `Sized`, kama ilivyo hapa) `mem::transmute(f)` ni salama kwani `fn(&T, &mut Formatter<'_>) -> Result` na `fn(&Opaque, &mut Formatter<'_>) -> Result` zina ABI sawa (ilimradi `T` ni `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // USALAMA: Sehemu ya `formatter` imewekwa tu kwa USIZE_MARKER ikiwa
            // thamani ni usize, kwa hivyo hii ni salama
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// bendera zinazopatikana katika muundo wa v1 wa format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Unapotumia format_args! () Jumla, kazi hii hutumiwa kutengeneza muundo wa Hoja.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Kazi hii hutumiwa kubainisha vigezo vya uundaji visivyo na viwango.
    /// Safu ya `pieces` lazima iwe angalau `fmt` ili kujenga muundo halali wa Hoja.
    /// Pia, `Count` yoyote ndani ya `fmt` ambayo ni `CountIsParam` au `CountIsNextParam` inapaswa kuelekeza kwenye hoja iliyoundwa na `argumentusize`.
    ///
    /// Walakini, kutofanya hivyo hakusababishi usalama, lakini itapuuza batili.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Inakadiriwa urefu wa maandishi yaliyopangwa.
    ///
    /// Hii imekusudiwa kutumiwa kwa kuweka uwezo wa awali wa `String` wakati wa kutumia `format!`.
    /// Note: hii sio ya chini wala ya juu.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Ikiwa kamba ya fomati itaanza na hoja, usipewe kitu chochote, isipokuwa urefu wa vipande ni muhimu.
            //
            //
            0
        } else {
            // Kuna hoja kadhaa, kwa hivyo kushinikiza yoyote ya ziada itabadilisha kamba.
            //
            // Ili kuepuka hilo, sisi ni "pre-doubling" uwezo hapa.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Muundo huu unawakilisha toleo lililofunguliwa salama la fomati na hoja zake.
/// Hii haiwezi kuzalishwa wakati wa kukimbia kwa sababu haiwezi kufanywa salama, kwa hivyo hakuna wajenzi wanaopewa na uwanja ni wa kibinafsi kuzuia mabadiliko.
///
///
/// Macro [`format_args!`] itaunda salama muundo wa muundo huu.
/// Macro inathibitisha kamba ya fomati wakati wa kukusanya ili utumiaji wa kazi za [`write()`] na [`format()`] ziweze kufanywa salama.
///
/// Unaweza kutumia `Arguments<'a>` ambayo [`format_args!`] inarudi katika hali ya `Debug` na `Display` kama inavyoonekana hapa chini.
/// Mfano pia unaonyesha kuwa muundo wa `Debug` na `Display` kwa kitu kimoja: kamba ya fomati iliyoingiliwa katika `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Umbiza vipande vya kamba ili uchapishe.
    pieces: &'a [&'static str],

    // Vipimo vya kishika nafasi, au `None` ikiwa vielelezo vyote ni chaguo-msingi (kama ilivyo kwa "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Hoja zenye nguvu za kuingiliana, kuingiliana na vipande vya kamba.
    // (Kila hoja hutanguliwa na kipande cha kamba.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Pata kamba iliyoumbizwa, ikiwa haina hoja za kupangiliwa.
    ///
    /// Hii inaweza kutumika kuzuia mgao katika hali ndogo zaidi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` inapaswa kupangilia pato katika muktadha unaokabiliwa na programu, utatuaji.
///
/// Kwa ujumla, unapaswa tu `derive` utekelezaji wa `Debug`.
///
/// Inapotumiwa na kiboreshaji mbadala cha fomati `#?`, pato linachapishwa vizuri.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// trait hii inaweza kutumika na `#[derive]` ikiwa nyanja zote zinatekeleza `Debug`.
/// Wakati `hupatikana`d kwa ujenzi, itatumia jina la `struct`, halafu `{`, kisha orodha iliyotenganishwa kwa koma ya jina la kila uwanja na thamani ya `Debug`, halafu `}`.
/// Kwa `enum`s, itatumia jina la lahaja na, ikiwa inafaa, `(`, kisha maadili ya `Debug` ya uwanja, halafu `)`.
///
/// # Stability
///
/// Fomati za `Debug` zilizotengenezwa sio thabiti, na kwa hivyo zinaweza kubadilika na matoleo ya future Rust.
/// Kwa kuongezea, utekelezaji wa `Debug` wa aina zilizotolewa na maktaba ya kawaida (`libstd`, `libcore`, `liballoc`, n.k.) sio sawa, na inaweza pia kubadilika na matoleo ya future Rust.
///
///
/// # Examples
///
/// Kupata utekelezaji:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Utekelezaji wa mikono:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Kuna njia kadhaa za wasaidizi kwenye muundo wa [`Formatter`] kukusaidia na utekelezaji wa mwongozo, kama vile [`debug_struct`].
///
/// `Debug` utekelezaji kwa kutumia `derive` au mjenzi wa utatuzi wa API kwenye [`Formatter`] inasaidia uchapishaji mzuri kutumia bendera mbadala: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Uchapishaji mzuri na `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Tenga moduli ili kusafirisha tena jumla ya `Debug` kutoka prelude bila trait `Debug`.
pub(crate) mod macros {
    /// Pata jumla ya kuzalisha impl ya trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Umbiza trait kwa muundo tupu, `{}`.
///
/// `Display` ni sawa na [`Debug`], lakini `Display` ni ya pato linalowakabili watumiaji, na kwa hivyo haiwezi kupatikana.
///
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Utekelezaji wa `Display` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait inapaswa kuunda muundo wake kama nambari katika base-8.
///
/// Kwa nambari kamili zilizosainiwa za zamani (`i8` hadi `i128`, na `isize`), maadili hasi yanapangiliwa kama uwakilishi wa mbili hizo.
///
///
/// Bendera mbadala, `#`, inaongeza `0o` mbele ya pato.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Matumizi ya kimsingi na `i32`:
///
/// ```
/// let x = 42; // 42 ni '52' katika octal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Utekelezaji wa `Octal` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // mjumbe kwa utekelezaji wa i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait inapaswa kuunda muundo wake kama nambari katika binary.
///
/// Kwa nambari kamili zilizosainiwa za zamani ([`i8`] hadi [`i128`], na [`isize`]), maadili hasi yanapangiliwa kama uwakilishi wa mbili hizo.
///
///
/// Bendera mbadala, `#`, inaongeza `0b` mbele ya pato.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Matumizi ya kimsingi na [`i32`]:
///
/// ```
/// let x = 42; // 42 ni '101010' kwa binary
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Utekelezaji wa `Binary` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // mjumbe kwa utekelezaji wa i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait inapaswa kupangilia pato lake kama nambari katika hexadecimal, na `a` kupitia `f` kwa herufi ndogo.
///
/// Kwa nambari kamili zilizosainiwa za zamani (`i8` hadi `i128`, na `isize`), maadili hasi yanapangiliwa kama uwakilishi wa mbili hizo.
///
///
/// Bendera mbadala, `#`, inaongeza `0x` mbele ya pato.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Matumizi ya kimsingi na `i32`:
///
/// ```
/// let x = 42; // 42 ni '2a' katika hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Utekelezaji wa `LowerHex` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // mjumbe kwa utekelezaji wa i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait inapaswa kupangilia pato lake kama nambari katika hexadecimal, na `A` kupitia `F` katika hali ya juu.
///
/// Kwa nambari kamili zilizosainiwa za zamani (`i8` hadi `i128`, na `isize`), maadili hasi yanapangiliwa kama uwakilishi wa mbili hizo.
///
///
/// Bendera mbadala, `#`, inaongeza `0x` mbele ya pato.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Matumizi ya kimsingi na `i32`:
///
/// ```
/// let x = 42; // 42 ni '2A' katika hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Utekelezaji wa `UpperHex` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // mjumbe kwa utekelezaji wa i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait inapaswa kupangilia pato lake kama eneo la kumbukumbu.
/// Hii huwasilishwa kama hexadecimal.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Matumizi ya kimsingi na `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // hii inazalisha kitu kama '0x7f06092ac6d0'
/// ```
///
/// Utekelezaji wa `Pointer` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // tumia `as` kugeuza kuwa `*const T`, ambayo hutumia Kiashiria, ambacho tunaweza kutumia
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait inapaswa kupangilia pato lake katika notation ya kisayansi na `e` ya hali ya chini.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Matumizi ya kimsingi na `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ni '4.2e1' katika nukuu ya kisayansi
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Utekelezaji wa `LowerExp` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // mjumbe kwa utekelezaji wa f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait inapaswa kupangilia pato lake katika notation ya kisayansi na `E` ya hali ya juu.
///
/// Kwa habari zaidi juu ya fomati, tazama [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Matumizi ya kimsingi na `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ni '4.2E1' katika nukuu ya kisayansi
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Utekelezaji wa `UpperExp` kwa aina:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // mjumbe kwa utekelezaji wa f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Hutengeneza thamani kwa kutumia fomati iliyopewa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Kazi ya `write` inachukua mkondo wa pato, na muundo wa `Arguments` ambao unaweza kusanidiwa na jumla ya `format_args!`.
///
///
/// Hoja zitapangiliwa kulingana na foleni ya fomati iliyoainishwa kwenye mkondo wa pato uliotolewa.
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Tafadhali kumbuka kuwa kutumia [`write!`] kunaweza kuwa bora.Mfano:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Tunaweza kutumia vigezo vya fomati chaguo-msingi kwa hoja zote.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Kila spec ina hoja inayolingana ambayo imetanguliwa na kipande cha kamba.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // USALAMA: Arg na args.args hutoka kwa Hoja zile zile,
                // ambayo inathibitisha faharisi kila wakati iko ndani ya mipaka.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Kunaweza kuwa na kipande kimoja tu cha safu ya kushoto iliyobaki.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // USALAMA: Arg na args hutoka kwa Hoja zile zile,
    // ambayo inathibitisha faharisi kila wakati iko ndani ya mipaka.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Toa hoja sahihi
    debug_assert!(arg.position < args.len());
    // USALAMA: Arg na args hutoka kwa Hoja zile zile,
    // ambayo inathibitisha faharisi yake iko ndani ya mipaka kila wakati.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Basi kweli fanya uchapishaji
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // USALAMA: cnt na args hutoka kwa Hoja zile zile,
            // ambayo inathibitisha faharisi hii iko ndani ya mipaka kila wakati.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Kusafisha baada ya mwisho wa kitu.Imerejeshwa na `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Andika chapisho hili la chapisho.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Tunataka kubadilisha hii
            buf: wrap(self.buf),

            // Na uhifadhi haya
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Njia za msaidizi zinazotumiwa kwa ukandaji na usindikaji hoja ambazo muundo wote wa traits unaweza kutumia.
    //

    /// Inafanya utaftaji sahihi kwa nambari kamili ambayo tayari imetolewa kwa str.
    /// The str haipaswi * kuwa na ishara ya nambari kamili, ambayo itaongezwa na njia hii.
    ///
    /// # Arguments
    ///
    /// * is_nnegative, ikiwa nambari ya asili ilikuwa chanya au sifuri.
    /// * kiambishi awali, ikiwa herufi '#' (Alternate) imetolewa, hiki ndio kiambishi awali cha kuweka mbele ya nambari.
    ///
    /// * buf, safu ya idadi ambayo nambari imeundwa
    ///
    /// Kazi hii itahesabu kwa usahihi bendera zilizotolewa pamoja na upana wa chini.
    /// Haitazingatia usahihi katika akaunti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Tunahitaji kuondoa "-" kutoka kwa pato la nambari.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Huandika ishara ikiwa ipo, na kisha kiambishi ikiwa iliombwa
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Sehemu ya `width` ni zaidi ya kigezo cha `min-width` wakati huu.
        match self.width {
            // Ikiwa hakuna mahitaji ya urefu wa chini basi tunaweza tu kuandika ka.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Angalia ikiwa tuko juu ya upana wa chini, ikiwa ni hivyo basi tunaweza pia kuandika ka.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Ishara na kiambishi awali huenda mbele ya padding ikiwa herufi ya kujaza ni sifuri
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Vinginevyo, ishara na kiambishi awali huenda baada ya padding
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Kazi hii inachukua kipande cha kamba na kuipeleka kwa bafa ya ndani baada ya kutumia bendera zinazofaa za uumbizaji zilizoainishwa.
    /// Bendera zinazotambuliwa kwa kamba za generic ni:
    ///
    /// * upana, upana wa chini wa nini utoe
    /// * fill/align - cha kutoa na wapi utoe ikiwa kamba iliyotolewa inahitaji kuingizwa
    /// * usahihi, urefu wa juu kutoa, kamba hukatwa ikiwa ni ndefu kuliko urefu huu
    ///
    /// Hasa kazi hii inapuuza vigezo vya `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Hakikisha kuna njia ya haraka mbele
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Sehemu ya `precision` inaweza kutafsiriwa kama `max-width` kwa kamba iliyoumbizwa.
        //
        let s = if let Some(max) = self.precision {
            // Ikiwa kamba yetu ni ndefu kuliko usahihi, basi lazima tuwe na truncation.
            // Walakini bendera zingine kama `fill`, `width` na `align` lazima zifanye kama kawaida.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM hapa haiwezi kudhibitisha kuwa `..i` haitasababisha panic `&s[..i]`, lakini tunajua kuwa haiwezi panic.
                // Tumia `get` + `unwrap_or` kuepusha `unsafe` na vinginevyo usitoe nambari yoyote inayohusiana na panic hapa.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Sehemu ya `width` ni zaidi ya kigezo cha `min-width` wakati huu.
        match self.width {
            // Ikiwa tuko chini ya urefu wa juu, na hakuna mahitaji ya urefu wa chini, basi tunaweza tu kutoa kamba
            //
            None => self.buf.write_str(s),
            // Ikiwa tuko chini ya upana wa kiwango cha juu, angalia ikiwa tuko juu ya upana wa chini, ikiwa ni rahisi kama kutoa tu kamba.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Ikiwa tuko chini ya upeo na upeo wa chini, basi jaza upana wa chini na kamba iliyoainishwa + mpangilio fulani.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Andika utaftaji wa mapema na urudishe maandishi ya posta ambayo hayajaandikwa.
    /// Wapigaji simu wanawajibika kuhakikisha kuwa baada ya padding imeandikwa baada ya kitu kinachowekwa.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Inachukua sehemu zilizopangwa na hutumia padding.
    /// Inadhani kwamba mpigaji simu tayari ameshatoa sehemu hizo kwa usahihi unaohitajika, ili `self.precision` ipuuzwe.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // kwa utaftaji wa sifuri unaofahamu ishara, tunatoa ishara kwanza na kuishi kama kwamba hatukuwa na ishara tangu mwanzo.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ishara daima huenda kwanza
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ondoa ishara kutoka kwa sehemu zilizopangwa
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // sehemu zilizobaki hupitia mchakato wa kawaida wa padding.
            let len = formatted.len();
            let ret = if width <= len {
                // hakuna padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // hii ndio kesi ya kawaida na tunachukua njia ya mkato
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // USALAMA: Hii hutumiwa kwa `flt2dec::Part::Num` na `flt2dec::Part::Copy`.
            // Ni salama kutumiwa kwa `flt2dec::Part::Num` kwani kila char `c` iko kati ya `b'0'` na `b'9'`, ambayo inamaanisha `s` ni UTF-8 halali.
            // Pia ni salama katika mazoezi ya kutumia kwa `flt2dec::Part::Copy(buf)` kwani `buf` inapaswa kuwa wazi ASCII, lakini inawezekana kwa mtu kupita kwa thamani mbaya ya `buf` kuwa `flt2dec::to_shortest_str` kwani ni kazi ya umma.
            //
            // FIXME: Tambua ikiwa hii inaweza kusababisha UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // Zero 64
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Huandika data fulani kwa bafa ya msingi iliyo ndani ya fomati hii.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Hii ni sawa na:
    ///         // andika! (fomati, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Anaandika habari fomati katika mfano huu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Bendera za uumbizaji
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Tabia inayotumiwa kama 'fill' wakati wowote kuna mpangilio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Tunaweka usawa upande wa kulia na ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Bendera inayoonyesha aina gani ya mpangilio uliombwa.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Upana wa nambari iliyochaguliwa kwa hiari ambayo pato inapaswa kuwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Ikiwa tulipokea upana, tunatumia
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Vinginevyo hatufanyi chochote maalum
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Usahihi uliochaguliwa kwa hiari kwa aina za nambari.
    /// Vinginevyo, upana wa juu wa aina za kamba.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Ikiwa tumepokea usahihi, tunatumia.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Vinginevyo sisi default kwa 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Huamua ikiwa bendera ya `+` ilibainishwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Huamua ikiwa bendera ya `-` ilibainishwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Unataka ishara ya kuondoa?Kuwa na moja!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Huamua ikiwa bendera ya `#` ilibainishwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Huamua ikiwa bendera ya `0` ilibainishwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Tunapuuza chaguzi za fomati.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Amua ni API gani ya umma tunayotaka kwa bendera hizi mbili.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Inaunda mjenzi wa [`DebugStruct`] iliyoundwa kusaidia utengenezaji wa utekelezaji wa [`fmt::Debug`] kwa structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Inaunda mjenzi wa `DebugTuple` iliyoundwa kusaidia utengenezaji wa utekelezaji wa `fmt::Debug` kwa ujenzi wa Tuple.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Inaunda mjenzi wa `DebugList` iliyoundwa kusaidia utengenezaji wa utekelezaji wa `fmt::Debug` kwa miundo inayofanana na orodha.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Inaunda mjenzi wa `DebugSet` iliyoundwa kusaidia utengenezaji wa utekelezaji wa `fmt::Debug` kwa miundo inayofanana.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Katika mfano huu ngumu zaidi, tunatumia [`format_args!`] na `.debug_set()` kuunda orodha ya silaha za mechi:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Inaunda mjenzi wa `DebugMap` iliyoundwa kusaidia utengenezaji wa utekelezaji wa `fmt::Debug` kwa miundo inayofanana na ramani.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Utekelezaji wa muundo wa msingi wa traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Ikiwa char inahitaji kutoroka, kurudisha nyuma nyuma hadi sasa na andika, vinginevyo ruka
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Bendera mbadala tayari imechukuliwa na LowerHex kama maalum-inaashiria ikiwa kiambishi awali na 0x.
        // Tunatumia kufanyia kazi kama kupanua au kutokuongeza sifuri, na kisha kuiweka bila masharti kupata kiambishi awali.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Utekelezaji wa Display/Debug kwa aina anuwai ya msingi

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell imekopwa kwa busara kwa hivyo hatuwezi kuangalia thamani yake hapa.
                // Onyesha kishika nafasi badala yake.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Ikiwa unatarajia majaribio yatakuwa hapa, angalia faili ya core/tests/fmt.rs, ni rahisi zaidi kuliko kuunda miundo yote ya rt::Piece hapa.
//
// Pia kuna vipimo katika crate iliyotengwa, kwa wale wanaohitaji mgao.