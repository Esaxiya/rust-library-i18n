//! Hii ni moduli ya ndani inayotumiwa na ifmt!wakati wa kukimbia.Miundo hii hutolewa kwa safu tuli ili kuandaa nyuzi za fomati kabla ya wakati.
//!
//! Ufafanuzi huu ni sawa na ulinganifu wao wa `ct`, lakini hutofautiana kwa kuwa hizi zinaweza kugawanywa kitakwimu na zimeboreshwa kidogo kwa wakati wa kukimbia
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Marekebisho yanayowezekana ambayo yanaweza kuombwa kama sehemu ya maagizo ya uumbizaji.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Dalili kwamba yaliyomo yanapaswa kushikamana kushoto.
    Left,
    /// Dalili kwamba yaliyomo yanapaswa kuwa sawa-sawa.
    Right,
    /// Dalili kwamba yaliyomo yanapaswa kuwa yaliyokaa katikati.
    Center,
    /// Hakuna mpangilio uliombwa.
    Unknown,
}

/// Inatumiwa na vibainishi vya [width](https://doc.rust-lang.org/std/fmt/#width) na [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Iliyotajwa na nambari halisi, huhifadhi thamani
    Is(usize),
    /// Iliyotajwa kwa kutumia sintaksia za `$` na `*`, huhifadhi faharisi katika `args`
    Param(usize),
    /// Haijabainishwa
    Implied,
}