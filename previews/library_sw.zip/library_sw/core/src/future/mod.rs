#![stable(feature = "futures_api", since = "1.36.0")]

//! Thamani za Asynchronous.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Aina hii inahitajika kwa sababu:
///
/// a) Jenereta haziwezi kutekeleza `for<'a, 'b> Generator<&'a mut Context<'b>>`, kwa hivyo tunahitaji kupitisha kiboreshaji mbichi (tazama <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Viashiria mbichi na `NonNull` sio `Send` au `Sync`, kwa hivyo hiyo itafanya kila future non-Send/Sync pia, na hatutaki hiyo.
///
/// Pia inarahisisha upunguzaji wa HIR wa `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Funga jenereta kwenye future.
///
/// Kazi hii inarudisha `GenFuture` chini, lakini inaificha katika `impl Trait` ili kutoa ujumbe bora wa makosa (`impl Future` badala ya `GenFuture<[closure.....]>`).
///
// Hii ni `const` ili kuepuka makosa ya ziada baada ya kupona kutoka `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Tunategemea ukweli kwamba async/await futures haziwezi kusonga ili kuunda ukopaji wa kibinafsi katika jenereta ya msingi.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // USALAMA: Salama kwa sababu sisi ni !Unpin + !Drop, na hii ni makadirio ya uwanja tu.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Endelea na jenereta, ukigeuza `&mut Context` kuwa kiashiria mbichi cha `NonNull`.
            // Kupungua kwa `.await` kutarudisha salama hiyo kwa `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // USALAMA: mpigaji lazima ahakikishe kuwa `cx.0` ni kiboreshaji halali
    // ambayo inatimiza mahitaji yote ya kumbukumbu inayoweza kubadilika.
    unsafe { &mut *cx.0.as_ptr().cast() }
}