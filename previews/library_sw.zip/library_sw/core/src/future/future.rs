#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future inawakilisha hesabu asynchronous.
///
/// future ni thamani ambayo huenda haijamaliza kompyuta bado.
/// Aina hii ya "asynchronous value" inafanya uwezekano wa uzi kuendelea kufanya kazi muhimu wakati unangojea thamani kupatikana.
///
///
/// # Njia ya `poll`
///
/// Njia kuu ya future, `poll`,*inajaribu* kutatua future kuwa thamani ya mwisho.
/// Njia hii haizui ikiwa dhamana haiko tayari.
/// Badala yake, jukumu la sasa limepangwa kuamshwa wakati inawezekana kufanya maendeleo zaidi kwa `kupiga kura tena.
/// `context` iliyopitishwa kwa njia ya `poll` inaweza kutoa [`Waker`], ambayo ni kushughulikia kuamsha kazi ya sasa.
///
/// Unapotumia future, kwa jumla hautaita `poll` moja kwa moja, lakini badala yake `.await` thamani.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Aina ya thamani iliyozalishwa baada ya kukamilika.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Jaribio la kutatua future kwa thamani ya mwisho, kusajili jukumu la sasa la kuamka ikiwa thamani bado haipatikani.
    ///
    /// # Rudisha thamani
    ///
    /// Kazi hii inarudi:
    ///
    /// - [`Poll::Pending`] ikiwa future bado iko tayari
    /// - [`Poll::Ready(val)`] na matokeo `val` ya future hii ikiwa imemaliza kwa mafanikio.
    ///
    /// Mara baada ya future kumaliza, wateja hawapaswi kuiweka `poll` tena.
    ///
    /// Wakati future bado iko tayari, `poll` inarudi `Poll::Pending` na inahifadhi kiini cha [`Waker`] iliyonakiliwa kutoka kwa [`Context`] ya sasa.
    /// [`Waker`] hii inaamshwa mara future inaweza kufanya maendeleo.
    /// Kwa mfano, future inayosubiri tundu ili iweze kusomeka ingeita `.clone()` kwenye [`Waker`] na kuihifadhi.
    /// Wakati ishara inafika mahali pengine inayoonyesha kuwa tundu linasomeka, [`Waker::wake`] inaitwa na kazi ya tundu future inaamshwa.
    /// Mara baada ya kazi kuamshwa, inapaswa kujaribu `poll` future tena, ambayo inaweza au haiwezi kutoa thamani ya mwisho.
    ///
    /// Kumbuka kuwa kwenye simu nyingi kwenda `poll`, ni [`Waker`] tu kutoka [`Context`] iliyopitishwa kwa simu ya hivi karibuni inapaswa kupangwa kupokea kuamka.
    ///
    /// # Tabia za wakati wa kukimbia
    ///
    /// Futures peke yake ni *inert*;lazima wachaguliwe * kwa bidii ili kufanya maendeleo, ikimaanisha kuwa kila wakati kazi ya sasa inapoamshwa, inapaswa kurudia "kura" inasubiri futures ambayo bado inavutiwa nayo.
    ///
    /// Kazi ya `poll` haiitwi mara kwa mara kwenye kitanzi chenye kubana-badala yake, inapaswa kuitwa tu wakati future inaonyesha kuwa iko tayari kufanya maendeleo (kwa kupiga simu `wake()`).
    /// Ikiwa unafahamiana na picha za `poll(2)` au `select(2)` kwenye Unix ni muhimu kuzingatia kwamba futures kawaida haina * kuteseka na shida sawa za "all wakeups must poll all events";wao ni kama `epoll(4)`.
    ///
    /// Utekelezaji wa `poll` unapaswa kujitahidi kurudi haraka, na haipaswi kuzuia.Kurudi haraka huzuia kuziba nyuzi bila lazima au vitanzi vya hafla.
    /// Ikiwa inajulikana kabla ya wakati kuwa simu kwa `poll` inaweza kuishia kuchukua muda, kazi inapaswa kutolewa kwenye dimbwi la uzi (au kitu kama hicho) kuhakikisha kuwa `poll` inaweza kurudi haraka.
    ///
    /// # Panics
    ///
    /// Mara tu future imekamilisha (kurudisha `Ready` kutoka `poll`), ikiita njia yake ya `poll` tena inaweza panic, kuzuia milele, au kusababisha shida zingine;`Future` trait haitoi mahitaji yoyote juu ya athari za simu kama hiyo.
    /// Walakini, kwa kuwa njia ya `poll` haijawekwa alama `unsafe`, sheria za kawaida za Rust zinatumika: simu hazipaswi kusababisha tabia isiyojulikana (ufisadi wa kumbukumbu, utumiaji mbaya wa kazi za `unsafe`, au zingine kama hizo), bila kujali hali ya future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}