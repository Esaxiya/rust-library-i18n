use crate::future::Future;

/// Ubadilishaji kuwa `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Pato ambalo future itazalisha ukikamilika.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Je! Ni aina gani ya future tunayogeuza hii kuwa?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Inaunda future kutoka kwa thamani.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}