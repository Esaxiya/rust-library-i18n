#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Inapanuka kuwa `$crate::panic::panic_2015` au `$crate::panic::panic_2021` kulingana na toleo la anayepiga.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Inahifadhi kwamba misemo miwili ni sawa na kila mmoja (kwa kutumia [`PartialEq`]).
///
/// Kwenye panic, jumla hii itachapisha maadili ya misemo na uwakilishi wao wa utatuzi.
///
///
/// Kama [`assert!`], jumla hii ina fomu ya pili, ambapo ujumbe maalum wa panic unaweza kutolewa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ukopaji hapa chini ni wa kukusudia.
                    // Bila yao, mpangilio wa mpangilio wa kukopa umeanzishwa hata kabla ya viwango kulinganishwa, na kusababisha kupungua kwa kasi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ukopaji hapa chini ni wa kukusudia.
                    // Bila yao, mpangilio wa mpangilio wa kukopa umeanzishwa hata kabla ya viwango kulinganishwa, na kusababisha kupungua kwa kasi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Inahifadhi kwamba misemo miwili si sawa kwa kila mmoja (kwa kutumia [`PartialEq`]).
///
/// Kwenye panic, jumla hii itachapisha maadili ya misemo na uwakilishi wao wa utatuzi.
///
///
/// Kama [`assert!`], jumla hii ina fomu ya pili, ambapo ujumbe maalum wa panic unaweza kutolewa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ukopaji hapa chini ni wa kukusudia.
                    // Bila yao, mpangilio wa mpangilio wa kukopa umeanzishwa hata kabla ya viwango kulinganishwa, na kusababisha kupungua kwa kasi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ukopaji hapa chini ni wa kukusudia.
                    // Bila yao, mpangilio wa mpangilio wa kukopa umeanzishwa hata kabla ya viwango kulinganishwa, na kusababisha kupungua kwa kasi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Inahifadhi kwamba usemi wa boolean ni `true` wakati wa kukimbia.
///
/// Hii itaomba jumla ya [`panic!`] ikiwa usemi uliyopewa hauwezi kutathminiwa kwa `true` wakati wa kukimbia.
///
/// Kama [`assert!`], jumla hii pia ina toleo la pili, ambapo ujumbe maalum wa panic unaweza kutolewa.
///
/// # Uses
///
/// Tofauti na [`assert!`], taarifa za `debug_assert!` zinawezeshwa tu katika ujenzi usioboreshwa kwa chaguo-msingi.
/// Ujenzi ulioboreshwa hautafanya taarifa za `debug_assert!` isipokuwa `-C debug-assertions` ipitishwe kwa mkusanyaji.
/// Hii inafanya `debug_assert!` kuwa muhimu kwa hundi ambazo ni ghali sana kuwapo katika toleo la kutolewa lakini zinaweza kusaidia wakati wa maendeleo.
/// Matokeo ya kupanua `debug_assert!` huangaliwa kila wakati.
///
/// Madai yasiyodhibitiwa huruhusu programu katika hali isiyokubaliana kuendelea kufanya kazi, ambayo inaweza kuwa na matokeo yasiyotarajiwa lakini haileti usalama wakati hii itatokea tu kwa nambari salama.
///
/// Gharama ya utendaji wa madai, hata hivyo, haipimiki kwa ujumla.
/// Kubadilisha [`assert!`] na `debug_assert!` kunahimizwa tu baada ya maelezo kamili, na muhimu zaidi, tu kwa nambari salama!
///
/// # Examples
///
/// ```
/// // ujumbe wa panic kwa madai haya ni dhamana iliyoshonwa ya usemi uliopewa.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // kazi rahisi sana
/// debug_assert!(some_expensive_computation());
///
/// // sisitiza na ujumbe wa kawaida
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Inaongeza kuwa misemo miwili ni sawa na kila mmoja.
///
/// Kwenye panic, jumla hii itachapisha maadili ya misemo na uwakilishi wao wa utatuzi.
///
/// Tofauti na [`assert_eq!`], taarifa za `debug_assert_eq!` zinawezeshwa tu katika ujenzi usioboreshwa kwa chaguo-msingi.
/// Ujenzi ulioboreshwa hautafanya taarifa za `debug_assert_eq!` isipokuwa `-C debug-assertions` ipitishwe kwa mkusanyaji.
/// Hii inafanya `debug_assert_eq!` kuwa muhimu kwa hundi ambazo ni ghali sana kuwapo katika toleo la kutolewa lakini zinaweza kusaidia wakati wa maendeleo.
///
/// Matokeo ya kupanua `debug_assert_eq!` huangaliwa kila wakati.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Inaongeza kuwa misemo miwili hailingani.
///
/// Kwenye panic, jumla hii itachapisha maadili ya misemo na uwakilishi wao wa utatuzi.
///
/// Tofauti na [`assert_ne!`], taarifa za `debug_assert_ne!` zinawezeshwa tu katika ujenzi usioboreshwa kwa chaguo-msingi.
/// Ujenzi ulioboreshwa hautafanya taarifa za `debug_assert_ne!` isipokuwa `-C debug-assertions` ipitishwe kwa mkusanyaji.
/// Hii inafanya `debug_assert_ne!` kuwa muhimu kwa hundi ambazo ni ghali sana kuwapo katika toleo la kutolewa lakini zinaweza kusaidia wakati wa maendeleo.
///
/// Matokeo ya kupanua `debug_assert_ne!` huangaliwa kila wakati.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Hurejesha ikiwa msemo uliopewa unalingana na muundo wowote uliopewa.
///
/// Kama ilivyo kwa usemi wa `match`, muundo unaweza kufuatwa kwa hiari na `if` na usemi wa walinzi ambao unaweza kufikia majina yaliyofungwa na muundo.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Kufungua matokeo au kueneza makosa yake.
///
/// Operesheni ya `?` iliongezwa kuchukua nafasi ya `try!` na inapaswa kutumiwa badala yake.
/// Kwa kuongezea, `try` ni neno lililohifadhiwa katika Rust 2018, kwa hivyo ikiwa ni lazima utumie, utahitaji kutumia [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` inalingana na [`Result`] iliyopewa.Katika kesi ya lahaja ya `Ok`, usemi una thamani ya thamani iliyofungwa.
///
/// Ikiwa kuna lahaja ya `Err`, hupata kosa la ndani.`try!` kisha hufanya ubadilishaji kwa kutumia `From`.
/// Hii hutoa ubadilishaji wa moja kwa moja kati ya makosa maalum na yale ya jumla.
/// Kosa linalosababishwa hurejeshwa mara moja.
///
/// Kwa sababu ya kurudi mapema, `try!` inaweza kutumika tu katika kazi zinazorudisha [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Njia inayopendelewa ya Kurudi Makosa haraka
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Njia ya awali ya Kurudi Makosa
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Hii ni sawa na:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Huandika data iliyoumbizwa katika bafa.
///
/// Macro hii inakubali 'writer', fomati ya fomati, na orodha ya hoja.
/// Hoja zitapangwa kulingana na fomati iliyofafanuliwa na matokeo yatapitishwa kwa mwandishi.
/// Mwandishi anaweza kuwa na thamani yoyote na njia ya `write_fmt`;kwa ujumla hii inatokana na utekelezaji wa [`fmt::Write`] au [`io::Write`] trait.
/// Macro inarudi chochote njia ya `write_fmt` inarudi;kawaida [`fmt::Result`], au [`io::Result`].
///
/// Tazama [`std::fmt`] kwa habari zaidi juu ya sintaksia ya fomati.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Moduli inaweza kuagiza `std::fmt::Write` na `std::io::Write` na kupiga `write!` kwenye vitu vinavyotekeleza ama, kwani vitu havitekelezi vyote kwa kawaida.
///
/// Walakini, moduli lazima iingize traits zilizohitimu ili majina yao yasipigane:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // hutumia fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // hutumia io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Macro hii inaweza kutumika katika mipangilio ya `no_std` pia.
/// Katika usanidi wa `no_std` unawajibika kwa maelezo ya utekelezaji wa vifaa.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Andika data iliyopangwa kwenye bafa, na laini mpya imeongezwa.
///
/// Kwenye majukwaa yote, laini mpya ni tabia ya LINE FEED (`\n`/`U+000A`) peke yake (hakuna CARRIAGE RETURN (`\r`/`U+000D`) ya ziada.
///
/// Kwa habari zaidi, angalia [`write!`].Kwa habari juu ya sintaksia ya fomati, ona [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Moduli inaweza kuagiza `std::fmt::Write` na `std::io::Write` na kupiga `write!` kwenye vitu vinavyotekeleza ama, kwani vitu havitekelezi vyote kwa kawaida.
/// Walakini, moduli lazima iingize traits zilizohitimu ili majina yao yasipigane:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // hutumia fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // hutumia io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Inaonyesha nambari isiyoweza kufikiwa.
///
/// Hii ni muhimu wakati wowote ambapo mkusanyaji hawezi kuamua kuwa nambari fulani haipatikani.Kwa mfano:
///
/// * Linganisha mikono na hali ya ulinzi.
/// * Matanzi ambayo hukomesha kwa nguvu.
/// * Iterators ambazo hukomesha kwa nguvu.
///
/// Ikiwa uamuzi kwamba nambari haipatikani inathibitisha sio sahihi, mpango huo unamalizika na [`panic!`].
///
/// Mwenzake salama wa jumla hii ni kazi ya [`unreachable_unchecked`], ambayo itasababisha tabia isiyoeleweka ikiwa nambari imefikiwa.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Hii itakuwa [`panic!`] kila wakati.
///
/// # Examples
///
/// Linganisha mikono:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kukusanya kosa ikiwa imetolewa maoni
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // moja ya utekelezaji duni kabisa wa x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Inaonyesha nambari isiyotekelezwa kwa kuogopa na ujumbe wa "not implemented".
///
/// Hii inaruhusu nambari yako kuchapa-kukagua, ambayo ni muhimu ikiwa unachakata au unatumia trait ambayo inahitaji njia nyingi ambazo huna mpango wa kutumia zote.
///
/// Tofauti kati ya `unimplemented!` na [`todo!`] ni kwamba wakati `todo!` inatoa dhamira ya kutekeleza utendaji baadaye na ujumbe ni "not yet implemented", `unimplemented!` haitoi madai kama hayo.
/// Ujumbe wake ni "not implemented".
/// Pia IDE zingine zitaashiria `todo!` S.
///
/// # Panics
///
/// Hii itakuwa [`panic!`] kila wakati kwa sababu `unimplemented!` ni kifupi tu cha `panic!` na ujumbe maalum, maalum.
///
/// Kama `panic!`, jumla hii ina fomu ya pili ya kuonyesha maadili ya kawaida.
///
/// # Examples
///
/// Sema tuna trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Tunataka kutekeleza `Foo` kwa 'MyStruct', lakini kwa sababu fulani ni busara tu kutekeleza kazi ya `bar()`.
/// `baz()` na `qux()` bado itahitaji kufafanuliwa katika utekelezaji wetu wa `Foo`, lakini tunaweza kutumia `unimplemented!` katika ufafanuzi wao kuruhusu nambari yetu kukusanyika.
///
/// Bado tunataka mpango wetu uachane na kazi ikiwa njia zisizotekelezwa zitafikiwa.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Haina maana kwa `baz` `MyStruct`, kwa hivyo hatuna mantiki hapa kabisa.
/////
///         // Hii itaonyesha "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Tuna mantiki hapa, tunaweza kuongeza ujumbe kwa kutotekelezwa!kuonyesha upungufu wetu.
///         // Hii itaonyesha: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Inaonyesha msimbo ambao haujakamilika.
///
/// Hii inaweza kuwa na faida ikiwa unafanya mfano na unatafuta tu kuwa na kichupo chako cha nambari.
///
/// Tofauti kati ya [`unimplemented!`] na `todo!` ni kwamba wakati `todo!` inatoa dhamira ya kutekeleza utendaji baadaye na ujumbe ni "not yet implemented", `unimplemented!` haitoi madai kama hayo.
/// Ujumbe wake ni "not implemented".
/// Pia IDE zingine zitaashiria `todo!` S.
///
/// # Panics
///
/// Hii itakuwa [`panic!`] kila wakati.
///
/// # Examples
///
/// Hapa kuna mfano wa nambari inayoendelea.Tuna trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Tunataka kutekeleza `Foo` kwenye moja ya aina zetu, lakini pia tunataka kufanya kazi kwa `bar()` tu kwanza.Ili nambari yetu ijumuike, tunahitaji kutekeleza `baz()`, kwa hivyo tunaweza kutumia `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // utekelezaji huenda hapa
///     }
///
///     fn baz(&self) {
///         // wacha tuwe na wasiwasi juu ya kutekeleza baz() kwa sasa
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // hatutumii hata baz(), kwa hivyo hii ni sawa.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Ufafanuzi wa macros zilizojengwa.
///
/// Sifa nyingi za jumla (utulivu, kujulikana, n.k.) huchukuliwa kutoka kwa nambari ya chanzo hapa, isipokuwa kazi za upanuzi kubadilisha pembejeo za jumla kuwa matokeo, kazi hizo hutolewa na mkusanyaji.
///
///
pub(crate) mod builtin {

    /// Husababisha mkusanyiko kushindwa na ujumbe wa makosa uliyopewa wakati unapokutana.
    ///
    /// Macro hii inapaswa kutumika wakati crate inatumia mkakati wa mkusanyiko wa masharti kutoa ujumbe bora wa makosa kwa hali mbaya.
    ///
    /// Ni fomu ya kiwango cha mkusanyaji wa [`panic!`], lakini hutoa hitilafu wakati wa mkusanyiko *badala ya wakati wa kukimbia*.
    ///
    /// # Examples
    ///
    /// Mifano mbili kama hizo ni mazingira ya macros na `#[cfg]`.
    ///
    /// Toa hitilafu bora ya mkusanyaji ikiwa jumla imepitishwa kwa maadili batili.
    /// Bila branch ya mwisho, mkusanyaji bado angeweza kutoa hitilafu, lakini ujumbe wa kosa hautaweza kutaja maadili mawili halali.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Ondoa hitilafu ya mkusanyaji ikiwa moja ya huduma haipatikani.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Huunda vigezo vya macros mengine ya muundo wa kamba.
    ///
    /// Kazi hizi kubwa kwa kuchukua fomati ya fomati halisi iliyo na `{}` kwa kila hoja ya ziada iliyopitishwa.
    /// `format_args!` huandaa vigezo vya ziada ili kuhakikisha kuwa pato linaweza kutafsiliwa kama kamba na huwasilisha hoja kuwa aina moja.
    /// Thamani yoyote inayotumia [`Display`] trait inaweza kupitishwa kwa `format_args!`, kama vile utekelezaji wowote wa [`Debug`] unaweza kupitishwa kwa `{:?}` ndani ya fomati ya fomati.
    ///
    ///
    /// Macro hii hutoa thamani ya aina [`fmt::Arguments`].Thamani hii inaweza kupitishwa kwa macros ndani ya [`std::fmt`] kwa kufanya uelekezaji muhimu.
    /// Macro zingine zote za uumbizaji ([`format!`], [`write!`], [`println!`], n.k) zimewasilishwa kupitia hii.
    /// `format_args!`, tofauti na macros yake yanayotokana, huepuka mgao wa chungu.
    ///
    /// Unaweza kutumia thamani ya [`fmt::Arguments`] ambayo `format_args!` inarudi katika hali ya `Debug` na `Display` kama inavyoonekana hapa chini.
    /// Mfano pia unaonyesha kuwa muundo wa `Debug` na `Display` kwa kitu kimoja: kamba ya fomati iliyoingiliwa katika `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Kwa habari zaidi, angalia nyaraka katika [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sawa na `format_args`, lakini inaongeza laini mpya mwishowe.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inakagua mabadiliko ya mazingira wakati wa kukusanya.
    ///
    /// Macro hii itapanuka hadi thamani ya ubadilishaji wa mazingira uliopewa jina wakati wa kukusanya, ikitoa usemi wa aina `&'static str`.
    ///
    ///
    /// Ikiwa ubadilishaji wa mazingira haujafafanuliwa, basi kosa la mkusanyiko litatolewa.
    /// Ili usitoe kosa la kukusanya, tumia macro ya [`option_env!`] badala yake.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Unaweza kubadilisha ujumbe wa kosa kwa kupitisha kamba kama kigezo cha pili:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ikiwa utofauti wa mazingira ya `documentation` haujafafanuliwa, utapata hitilafu ifuatayo:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kwa hiari hukagua mabadiliko ya mazingira wakati wa kukusanya.
    ///
    /// Ikiwa ubadilishaji wa mazingira uliotajwa upo wakati wa kukusanya, hii itapanuka kuwa kielelezo cha aina `Option<&'static str>` ambayo thamani yake ni `Some` ya thamani ya utofauti wa mazingira.
    /// Ikiwa ubadilishaji wa mazingira haupo, basi hii itapanuka hadi `None`.
    /// Tazama [`Option<T>`][Option] kwa habari zaidi juu ya aina hii.
    ///
    /// Kosa la wakati wa kukusanya haitoi kamwe wakati wa kutumia jumla hii bila kujali iwapo utofauti wa mazingira upo au la.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Huunganisha vitambulisho kuwa kitambulisho kimoja.
    ///
    /// Macro hii inachukua idadi yoyote ya vitambulisho vilivyotenganishwa kwa koma, na inawaunganisha wote kuwa moja, ikitoa usemi ambao ni kitambulisho kipya.
    /// Kumbuka kuwa usafi hufanya hivyo kwamba jumla hii haiwezi kukamata vigeuzi vya kawaida.
    /// Pia, kama sheria ya jumla, macro zinaruhusiwa tu kwenye kipengee, taarifa au nafasi ya kujieleza.
    /// Hiyo inamaanisha wakati unaweza kutumia jumla hii kwa kurejelea anuwai zilizopo, kazi au moduli nk, huwezi kufafanua mpya nayo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (mpya, ya kufurahisha, jina) { }//haitumiki kwa njia hii!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inaunganisha fasihi kwenye kipande cha kamba tuli.
    ///
    /// Macro hii inachukua idadi yoyote ya fasihi zilizotenganishwa kwa koma, ikitoa usemi wa aina `&'static str` ambayo inawakilisha fasihi zote zilizofungwa kutoka kushoto kwenda kulia.
    ///
    ///
    /// Fasihi kamili na zinazoelea zimefungwa ili kuunganishwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inapanuka hadi nambari ya laini ambayo ilitumiwa.
    ///
    /// Na [`column!`] na [`file!`], macros haya hutoa habari ya utatuzi kwa watengenezaji kuhusu eneo ndani ya chanzo.
    ///
    /// Maneno yaliyopanuliwa yana aina `u32` na ni msingi wa 1, kwa hivyo mstari wa kwanza katika kila faili hutathmini 1, ya pili hadi 2, n.k.
    /// Hii ni sawa na ujumbe wa makosa na watunzi wa kawaida au wahariri maarufu.
    /// Mstari uliorejeshwa sio lazima * mstari wa ombi la `line!` yenyewe, lakini badala ya ombi kubwa la kwanza linalosababisha ombi la jumla ya `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Inapanuka hadi nambari ya safu wima ambayo ilitumiwa.
    ///
    /// Na [`line!`] na [`file!`], macros haya hutoa habari ya utatuzi kwa watengenezaji kuhusu eneo ndani ya chanzo.
    ///
    /// Maneno yaliyopanuliwa yana aina `u32` na ni msingi wa 1, kwa hivyo safu ya kwanza katika kila mstari hutathmini hadi 1, ya pili hadi ya 2, n.k.
    /// Hii ni sawa na ujumbe wa makosa na watunzi wa kawaida au wahariri maarufu.
    /// Safu iliyorudishwa sio lazima * mstari wa ombi la `column!` yenyewe, lakini badala ya ombi kubwa la kwanza linalosababisha ombi la jumla ya `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Inapanuka kwa jina la faili ambalo liliombwa.
    ///
    /// Na [`line!`] na [`column!`], macros haya hutoa habari ya utatuzi kwa watengenezaji kuhusu eneo ndani ya chanzo.
    ///
    /// Maneno yaliyopanuliwa yana aina ya `&'static str`, na faili iliyorejeshwa sio ombi la jumla ya `file!` yenyewe, lakini badala ya ombi kubwa la kwanza linaloongoza kwa kuomba kwa jumla ya `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Inashikilia hoja zake.
    ///
    /// Macro hii itatoa usemi wa aina `&'static str` ambayo ni ujumuishaji wa tokens zote zilizopitishwa kwa jumla.
    /// Hakuna vizuizi vimewekwa kwenye sintaksia ya maombi ya jumla yenyewe.
    ///
    /// Kumbuka kuwa matokeo yaliyopanuliwa ya tokens ya kuingiza yanaweza kubadilika katika future.Unapaswa kuwa mwangalifu ikiwa unategemea pato.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inajumuisha faili iliyosimbwa ya UTF-8 kama kamba.
    ///
    /// Faili iko karibu na faili ya sasa (sawa na jinsi moduli zinapatikana).
    /// Njia iliyotolewa hutafsiriwa kwa njia maalum ya jukwaa wakati wa kukusanya.
    /// Kwa hivyo, kwa mfano, dua iliyo na njia ya Windows iliyo na backslashes `\` haiwezi kukusanyika kwa usahihi kwenye Unix.
    ///
    ///
    /// Macro hii itatoa usemi wa aina `&'static str` ambayo ni yaliyomo kwenye faili.
    ///
    /// # Examples
    ///
    /// Fikiria kuna faili mbili kwenye saraka sawa na yaliyomo yafuatayo:
    ///
    /// Faili 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faili 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Kukusanya 'main.rs' na kuendesha binary inayosababisha itachapisha "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inajumuisha faili kama kumbukumbu ya safu ya ka.
    ///
    /// Faili iko karibu na faili ya sasa (sawa na jinsi moduli zinapatikana).
    /// Njia iliyotolewa hutafsiriwa kwa njia maalum ya jukwaa wakati wa kukusanya.
    /// Kwa hivyo, kwa mfano, dua iliyo na njia ya Windows iliyo na backslashes `\` haiwezi kukusanyika kwa usahihi kwenye Unix.
    ///
    ///
    /// Macro hii itatoa usemi wa aina `&'static [u8; N]` ambayo ni yaliyomo kwenye faili.
    ///
    /// # Examples
    ///
    /// Fikiria kuna faili mbili kwenye saraka sawa na yaliyomo yafuatayo:
    ///
    /// Faili 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faili 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Kukusanya 'main.rs' na kuendesha binary inayosababisha itachapisha "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inapanuka kwa kamba ambayo inawakilisha njia ya moduli ya sasa.
    ///
    /// Njia ya moduli ya sasa inaweza kuzingatiwa kama safu ya safu ya moduli zinazoongoza hadi crate root.
    /// Sehemu ya kwanza ya njia iliyorejeshwa ni jina la crate inayojumuishwa sasa.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Inatathmini mchanganyiko wa boolean wa bendera za usanidi wakati wa kukusanya.
    ///
    /// Mbali na sifa ya `#[cfg]`, jumla hii hutolewa ili kuruhusu tathmini ya kujieleza ya boolean ya bendera za usanidi.
    /// Hii mara nyingi husababisha nambari ndogo ya nakala.
    ///
    /// Sintaksia iliyopewa jumla hii ni sintaksia sawa na sifa ya [`cfg`].
    ///
    /// `cfg!`, tofauti na `#[cfg]`, haiondoi nambari yoyote na hutathmini tu kuwa kweli au uwongo.
    /// Kwa mfano, vizuizi vyote katika usemi wa if/else vinahitaji kuwa halali wakati `cfg!` inatumiwa kwa hali hiyo, bila kujali ni nini `cfg!` inatathmini.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inachanganua faili kama usemi au kipengee kulingana na muktadha.
    ///
    /// Faili iko karibu na faili ya sasa (sawa na jinsi moduli zinapatikana).Njia iliyotolewa hutafsiriwa kwa njia maalum ya jukwaa wakati wa kukusanya.
    /// Kwa hivyo, kwa mfano, dua iliyo na njia ya Windows iliyo na backslashes `\` haiwezi kukusanyika kwa usahihi kwenye Unix.
    ///
    /// Kutumia jumla hii mara nyingi ni wazo mbaya, kwa sababu ikiwa faili imechanganuliwa kama kielelezo, itawekwa katika nambari inayoizunguka bila usafi.
    /// Hii inaweza kusababisha vigeuzi au kazi kuwa tofauti na kile faili ilivyotarajiwa ikiwa kuna vigeuzi au kazi ambazo zina jina sawa kwenye faili ya sasa.
    ///
    ///
    /// # Examples
    ///
    /// Fikiria kuna faili mbili kwenye saraka sawa na yaliyomo yafuatayo:
    ///
    /// Faili 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Faili 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Kukusanya 'main.rs' na kuendesha binary inayosababisha itachapisha "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inahifadhi kwamba usemi wa boolean ni `true` wakati wa kukimbia.
    ///
    /// Hii itaomba jumla ya [`panic!`] ikiwa usemi uliyopewa hauwezi kutathminiwa kwa `true` wakati wa kukimbia.
    ///
    /// # Uses
    ///
    /// Daima huangaliwa kila wakati katika utatuzi na kutolewa hujengwa, na haiwezi kuzimwa.
    /// Tazama [`debug_assert!`] kwa madai ambayo hayajawezeshwa katika toleo la ujenzi kwa chaguo-msingi.
    ///
    /// Nambari isiyo salama inaweza kutegemea `assert!` kulazimisha vivamizi vya wakati wa kukimbia ambavyo, ikikiukwa inaweza kusababisha kutokuwa salama.
    ///
    /// Matukio mengine ya matumizi ya `assert!` ni pamoja na kujaribu na kutekeleza vivamizi vya wakati wa kukimbia kwa nambari salama (ambayo ukiukaji wake hauwezi kusababisha usalama).
    ///
    ///
    /// # Ujumbe wa kawaida
    ///
    /// Macro hii ina fomu ya pili, ambapo ujumbe maalum wa panic unaweza kutolewa na au bila hoja za muundo.
    /// Tazama [`std::fmt`] kwa sintaksia ya fomu hii.
    /// Maneno yanayotumiwa kama hoja za muundo yatatathminiwa tu ikiwa madai hayatafaulu.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ujumbe wa panic kwa madai haya ni dhamana iliyoshonwa ya usemi uliopewa.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // kazi rahisi sana
    ///
    /// assert!(some_computation());
    ///
    /// // sisitiza na ujumbe wa kawaida
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Mkutano wa ndani.
    ///
    /// Soma [unstable book] kwa matumizi.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Mkutano wa ndani wa mtindo wa LLVM.
    ///
    /// Soma [unstable book] kwa matumizi.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Mkutano wa ndani wa kiwango cha moduli.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints zilipitisha tokens kwenye pato la kawaida.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Huwasha au kulemaza ufuatiliaji wa utendaji uliotumika kwa utatuaji wa macros mengine
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Sambaza jumla inayotumika kutumia macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Sifa ya jumla inayotumika kwenye kazi kuibadilisha kuwa jaribio la kitengo.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Sifa jumla imewekwa kwa kazi kuibadilisha kuwa jaribio la benchi.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Maelezo ya utekelezaji wa macros `#[test]` na `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Sambaza jumla inayotumika kwa tuli kusajili kama mgawanyaji wa ulimwengu.
    ///
    /// Tazama pia [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Huweka kipengee kinachotumiwa ikiwa njia iliyopitishwa inapatikana, na inaiondoa vinginevyo.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Inapanua sifa zote za `#[cfg]` na `#[cfg_attr]` kwenye kipande cha nambari ambacho kinatumika.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Maelezo ya utulivu wa mkusanyaji wa `rustc`, usitumie.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Maelezo ya utulivu wa mkusanyaji wa `rustc`, usitumie.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}