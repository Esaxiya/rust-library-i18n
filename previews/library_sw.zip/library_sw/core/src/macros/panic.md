Panics uzi wa sasa.

Hii inaruhusu mpango kusitisha mara moja na kutoa maoni kwa mpigaji programu.
`panic!` inapaswa kutumika wakati mpango unafikia hali isiyoweza kupatikana.

Macro hii ndiyo njia kamili ya kudhibitisha hali katika nambari ya mfano na katika vipimo.
`panic!` imefungwa kwa karibu na njia ya `unwrap` ya enum zote za [`Option`][ounwrap] na [`Result`][runwrap].
Utekelezaji wote huita `panic!` wakati zimewekwa kwa anuwai za [`None`] au [`Err`].

Unapotumia `panic!()` unaweza kutaja malipo ya kamba, ambayo imejengwa kwa kutumia syntax ya [`format!`].
Mzigo huo wa malipo hutumiwa wakati wa kuingiza panic kwenye uzi wa Rust, na kusababisha uzi kuwa panic kabisa.

Tabia ya chaguo-msingi `std` hook, yaani
nambari inayoendesha moja kwa moja baada ya panic kutumika, ni kuchapisha malipo ya ujumbe kwa `stderr` pamoja na habari ya file/line/column ya simu ya `panic!()`.

Unaweza kubatilisha panic hook ukitumia [`std::panic::set_hook()`].
Ndani ya hook panic inaweza kupatikana kama `&dyn Any + Send`, ambayo ina `&str` au `String` kwa dua za kawaida za `panic!()`.
Kwa panic na thamani ya aina nyingine, [`panic_any`] inaweza kutumika.

[`Result`] enum mara nyingi ni suluhisho bora ya kupona kutoka kwa makosa kuliko kutumia jumla ya `panic!`.
Macro hii inapaswa kutumiwa kuzuia kuendelea kutumia maadili sahihi, kama vile kutoka kwa vyanzo vya nje.
Maelezo ya kina juu ya utunzaji wa makosa hupatikana katika [book].

Tazama pia Mac00 [`compile_error!`], ya kuongeza makosa wakati wa mkusanyiko.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Utekelezaji wa sasa

Ikiwa uzi kuu panics utakomesha nyuzi zako zote na kumaliza programu yako na nambari `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





