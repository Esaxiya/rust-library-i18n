//! Msaada wa Panic kwa libcore
//!
//! Maktaba ya msingi haiwezi kufafanua kuhofia, lakini inasema *kutangaza* hofu.
//! Hii inamaanisha kuwa kazi zilizo ndani ya libcore zinaruhusiwa kwa panic, lakini kuwa muhimu crate ya mto lazima ifafanue kuogopa kwa libcore kutumia.
//! Kiolesura cha sasa cha kuhofia ni:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ufafanuzi huu unaruhusu kuhofia na ujumbe wowote wa jumla, lakini hairuhusu kushindwa na thamani ya `Box<Any>`.
//! (`PanicInfo` ina `&(dyn Any + Send)` tu, ambayo tunajaza thamani ya dummy katika `PanicInfo: : internal_constructor`.) Sababu ya hii ni kwamba libcore hairuhusiwi kutenga.
//!
//!
//! Moduli hii ina kazi zingine kadhaa za kuhofia, lakini hizi ni vitu muhimu tu vya mkusanyaji.panics zote zimepangwa kupitia kazi hii moja.
//! Alama halisi imetangazwa kupitia sifa ya `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Utekelezaji wa msingi wa macro ya `panic!` ya libcore wakati hakuna fomati inayotumika.
#[cold]
// usiwe ndani kabisa isipokuwa panic_mediate_abort ili kuzuia bloat ya nambari kwenye tovuti za simu iwezekanavyo
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // inahitajika na codegen kwa panic juu ya kufurika na vishiriki vingine vya `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Tumia Arguments::new_v1 badala ya format_args! ("{}", Expr) ili kupunguza ukubwa wa kichwa.
    // Fomati_mbuzi!jumla hutumia str's Display trait kuandika expr, ambayo inaita Formatter::pad, ambayo inapaswa kubeba truncation ya kamba na padding (hata ingawa hakuna inayotumika hapa).
    //
    // Kutumia Arguments::new_v1 kunaweza kumruhusu mkusanyaji aachilie Formatter::pad kutoka kwa kipengee cha pato, akiba hadi kilobytes chache.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // inahitajika kwa panics iliyopimwa na const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // inahitajika na codegen kwa panic kwenye ufikiaji wa OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Utekelezaji wa msingi wa jumla ya `panic!` ya jumla wakati fomati inatumiwa.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // KUMBUKA Kazi hii haivuki mpaka wa FFI;ni simu ya Rust-to-Rust ambayo hutatuliwa kwa kazi ya `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // USALAMA: `panic_impl` hufafanuliwa kwa nambari salama ya Rust na kwa hivyo ni salama kupiga simu.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Kazi ya ndani ya `assert_eq!` na `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}