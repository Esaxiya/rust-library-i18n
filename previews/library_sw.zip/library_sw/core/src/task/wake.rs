#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` inaruhusu mtekelezaji wa msimamizi wa kazi kuunda [`Waker`] ambayo hutoa tabia ya kuamka iliyoboreshwa.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Inayo pointer ya data na [virtual function pointer table (vtable)][vtable] ambayo inabadilisha tabia ya `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Kiashiria cha data, ambacho kinaweza kutumika kuhifadhi data holela kama inavyotakiwa na msimamizi.
    /// Hii inaweza kuwa mfano
    /// kiashiria kilichofutwa kwa aina ya `Arc` ambacho kinahusishwa na kazi hiyo.
    /// Thamani ya uwanja huu hupitishwa kwa kazi zote ambazo ni sehemu ya vtable kama parameter ya kwanza.
    ///
    data: *const (),
    /// Jedwali la kiashiria cha kazi inayobadilisha tabia ya waker hii.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Inaunda `RawWaker` mpya kutoka kwa kielekezi cha `data` na `vtable`.
    ///
    /// Pointer ya `data` inaweza kutumika kuhifadhi data holela kama inavyotakiwa na msimamizi.Hii inaweza kuwa mfano
    /// kiashiria kilichofutwa kwa aina ya `Arc` ambacho kinahusishwa na kazi hiyo.
    /// Thamani ya pointer hii itapitishwa kwa kazi zote ambazo ni sehemu ya `vtable` kama kigezo cha kwanza.
    ///
    /// `vtable` inabadilisha tabia ya `Waker` ambayo huundwa kutoka kwa `RawWaker`.
    /// Kwa kila operesheni kwenye `Waker`, kazi inayohusishwa katika `vtable` ya msingi wa `RawWaker` itaitwa.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Jedwali la kiashiria cha kazi ya kawaida (vtable) ambayo inabainisha tabia ya [`RawWaker`].
///
/// Kiashiria kilichopitishwa kwa kazi zote ndani ya vtable ni pointer ya `data` kutoka kwa kitu kilichofungwa cha [`RawWaker`].
///
/// Kazi zilizo ndani ya muundo huu zinalenga tu kuitwa kwenye kiashiria cha `data` cha kitu kilichojengwa vizuri cha [`RawWaker`] kutoka ndani ya utekelezaji wa [`RawWaker`].
/// Kuita moja ya kazi zilizomo kutumia kiashiria kingine chochote cha `data` itasababisha tabia isiyojulikana.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Kazi hii itaitwa wakati [`RawWaker`] inapopigwa, kwa mfano wakati [`Waker`] ambayo [`RawWaker`] imehifadhiwa inapigwa.
    ///
    /// Utekelezaji wa kazi hii lazima ihifadhi rasilimali zote zinazohitajika kwa mfano huu wa nyongeza wa [`RawWaker`] na kazi inayohusiana.
    /// Kuita `wake` kwenye [`RawWaker`] inayosababisha inapaswa kusababisha kuamka kwa kazi ile ile ambayo ingeamshwa na [`RawWaker`] asili.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Kazi hii itaitwa wakati `wake` inaitwa kwenye [`Waker`].
    /// Lazima iamshe kazi inayohusishwa na [`RawWaker`] hii.
    ///
    /// Utekelezaji wa kazi hii lazima uhakikishe kutolewa rasilimali zozote ambazo zinahusishwa na mfano huu wa [`RawWaker`] na kazi inayohusiana.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Kazi hii itaitwa wakati `wake_by_ref` inaitwa kwenye [`Waker`].
    /// Lazima iamshe kazi inayohusishwa na [`RawWaker`] hii.
    ///
    /// Kazi hii ni sawa na `wake`, lakini haipaswi kutumia kiashiria cha data kilichotolewa.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Kazi hii inaitwa [`RawWaker`] inaposhuka.
    ///
    /// Utekelezaji wa kazi hii lazima uhakikishe kutolewa rasilimali zozote ambazo zinahusishwa na mfano huu wa [`RawWaker`] na kazi inayohusiana.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Inaunda `RawWakerVTable` mpya kutoka kwa kazi zilizotolewa za `clone`, `wake`, `wake_by_ref`, na `drop`.
    ///
    /// # `clone`
    ///
    /// Kazi hii itaitwa wakati [`RawWaker`] inapopigwa, kwa mfano wakati [`Waker`] ambayo [`RawWaker`] imehifadhiwa inapigwa.
    ///
    /// Utekelezaji wa kazi hii lazima ihifadhi rasilimali zote zinazohitajika kwa mfano huu wa nyongeza wa [`RawWaker`] na kazi inayohusiana.
    /// Kuita `wake` kwenye [`RawWaker`] inayosababisha inapaswa kusababisha kuamka kwa kazi ile ile ambayo ingeamshwa na [`RawWaker`] asili.
    ///
    /// # `wake`
    ///
    /// Kazi hii itaitwa wakati `wake` inaitwa kwenye [`Waker`].
    /// Lazima iamshe kazi inayohusishwa na [`RawWaker`] hii.
    ///
    /// Utekelezaji wa kazi hii lazima uhakikishe kutolewa rasilimali zozote ambazo zinahusishwa na mfano huu wa [`RawWaker`] na kazi inayohusiana.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Kazi hii itaitwa wakati `wake_by_ref` inaitwa kwenye [`Waker`].
    /// Lazima iamshe kazi inayohusishwa na [`RawWaker`] hii.
    ///
    /// Kazi hii ni sawa na `wake`, lakini haipaswi kutumia kiashiria cha data kilichotolewa.
    ///
    /// # `drop`
    ///
    /// Kazi hii inaitwa [`RawWaker`] inaposhuka.
    ///
    /// Utekelezaji wa kazi hii lazima uhakikishe kutolewa rasilimali zozote ambazo zinahusishwa na mfano huu wa [`RawWaker`] na kazi inayohusiana.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` ya kazi ya kupendeza.
///
/// Hivi sasa, `Context` hutumika tu kutoa ufikiaji wa `&Waker` ambayo inaweza kutumika kuamsha kazi ya sasa.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Hakikisha sisi future-uthibitisho dhidi ya mabadiliko ya kutofautisha kwa kulazimisha maisha kuwa ya kawaida (nyakati za msimamo wa hoja ni tofauti wakati maisha ya nafasi ya kurudi ni ya kutofautisha).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Unda `Context` mpya kutoka kwa `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Hurejesha marejeleo ya `Waker` kwa kazi ya sasa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ni kipini cha kuamka kazi kwa kumjulisha msimamizi wake kuwa iko tayari kuendeshwa.
///
/// Ushughulikiaji huu unajumuisha mfano wa [`RawWaker`], ambao hufafanua tabia maalum ya kuamka kwa mtekelezaji.
///
///
/// Inatumia [`Clone`], [`Send`], na [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Amka kazi inayohusishwa na `Waker` hii.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Simu halisi ya kuamka imekabidhiwa kupitia simu ya kazi ya kawaida kwa utekelezaji ambayo hufafanuliwa na mtekelezaji.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Usipige `drop`-waker itatumiwa na `wake`.
        crate::mem::forget(self);

        // USALAMA: Hii ni salama kwa sababu `Waker::from_raw` ndiyo njia pekee
        // kuanzisha `wake` na `data` inayohitaji mtumiaji kukubali kuwa mkataba wa `RawWaker` unashikiliwa.
        //
        unsafe { (wake)(data) };
    }

    /// Amka kazi inayohusiana na `Waker` hii bila kutumia `Waker`.
    ///
    /// Hii ni sawa na `wake`, lakini inaweza kuwa na ufanisi kidogo katika kesi ambapo `Waker` inayomilikiwa inapatikana.
    /// Njia hii inapaswa kupendelewa kupiga `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Simu halisi ya kuamka imekabidhiwa kupitia simu ya kazi ya kawaida kwa utekelezaji ambayo hufafanuliwa na mtekelezaji.
        //

        // USALAMA: tazama `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Hurejesha `true` ikiwa `Waker` hii na `Waker` nyingine zimeamsha kazi hiyo hiyo.
    ///
    /// Kazi hii inafanya kazi kwa juhudi bora, na inaweza kurudi uongo hata wakati `Waker wangeamsha kazi hiyo hiyo.
    /// Walakini, ikiwa kazi hii inarudi `true`, inahakikishwa kuwa `Waker`s wataamsha kazi hiyo hiyo.
    ///
    /// Kazi hii kimsingi hutumiwa kwa madhumuni ya uboreshaji.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Inaunda `Waker` mpya kutoka [`RawWaker`].
    ///
    /// Tabia ya `Waker` iliyorejeshwa haijafafanuliwa ikiwa mkataba uliofafanuliwa katika nyaraka za ["RawWaker"] na ["RawWakerVTable"] haujazingatiwa.
    ///
    /// Kwa hivyo njia hii sio salama.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // USALAMA: Hii ni salama kwa sababu `Waker::from_raw` ndiyo njia pekee
            // kuanzisha `clone` na `data` inayohitaji mtumiaji kukubali kuwa mkataba wa [`RawWaker`] unashikiliwa.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // USALAMA: Hii ni salama kwa sababu `Waker::from_raw` ndiyo njia pekee
        // kuanzisha `drop` na `data` inayohitaji mtumiaji kukubali kuwa mkataba wa `RawWaker` unashikiliwa.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}