#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Inayo ufafanuzi wa muundo wa mpangilio wa aina zilizojengwa katika mkusanyaji.
//!
//! Wanaweza kutumiwa kama malengo ya kupitisha kwa nambari isiyo salama ya kudhibiti uwakilishi mbichi moja kwa moja.
//!
//!
//! Ufafanuzi wao unapaswa kuwa sawa na ABI iliyofafanuliwa katika `rustc_middle::ty::layout`.
//!

/// Uwakilishi wa kitu cha trait kama `&dyn SomeTrait`.
///
/// Muundo huu una mpangilio sawa na aina kama `&dyn SomeTrait` na `Box<dyn AnotherTrait>`.
///
/// `TraitObject` imehakikishiwa kufanana na mipangilio, lakini sio aina ya vitu vya trait (kwa mfano, uwanja haupatikani moja kwa moja kwenye `&dyn SomeTrait`) na haidhibiti mpangilio huo (kubadilisha ufafanuzi hautabadilisha mpangilio wa `&dyn SomeTrait`).
///
/// Imeundwa tu kutumiwa na nambari isiyo salama ambayo inahitaji kudhibiti maelezo ya kiwango cha chini.
///
/// Hakuna njia ya kurejelea vitu vyote vya trait kwa ujumla, kwa hivyo njia pekee ya kuunda maadili ya aina hii ni pamoja na kazi kama [`std::mem::transmute`][transmute].
/// Vivyo hivyo, njia pekee ya kuunda kitu halisi cha trait kutoka kwa thamani ya `TraitObject` iko na `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Kuunganisha kitu cha trait na aina ambazo hazijalinganishwa - moja ambayo vtable hailingani na aina ya thamani ambayo pointer ya data inaelekeza-ina uwezekano mkubwa wa kusababisha tabia isiyojulikana.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // mfano trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // acha mkusanyaji afanye kitu trait
/// let object: &dyn Foo = &value;
///
/// // angalia uwakilishi mbichi
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // pointer ya data ni anwani ya `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // jenga kitu kipya, ukiashiria `i32` tofauti, kuwa mwangalifu kutumia vtable ya `i32` kutoka `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // inapaswa kufanya kazi kana kwamba tumeunda kitu cha trait kutoka `other_value` moja kwa moja
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}