//! # Maktaba ya Msingi ya Rust
//!
//! Maktaba ya Rust ni msingi wa utegemezi [^ bure] wa [The Rust Standard Library](../std/index.html).
//! Ni gundi inayoweza kubebeka kati ya lugha na maktaba zake, ikifafanua vizuizi vya ndani na vya zamani vya nambari zote za Rust.
//!
//! Haiungani na maktaba zilizo juu, hakuna maktaba za mfumo, na hakuna libc.
//!
//! [^free]: Strictly kusema, kuna ishara ambazo zinahitajika lakini
//!          sio lazima kila wakati.
//!
//! Maktaba ya msingi ni *ndogo*: haijui hata mgao wa lundo, wala haitoi sarafu au I/O.
//! Vitu hivi vinahitaji ujumuishaji wa jukwaa, na maktaba hii ni jukwaa-agnostic.
//!
//! # Jinsi ya kutumia maktaba ya msingi
//!
//! Tafadhali kumbuka kuwa maelezo haya yote kwa sasa hayazingatiwi kuwa thabiti.
//!
//!
//!
// FIXME: Nijaze kwa undani zaidi wakati kigeuzi kinakaa
//! Maktaba hii imejengwa juu ya dhana ya alama chache zilizopo:
//!
//! * `memcpy`, `memcmp`, `memset`, Hizi ni mazoea ya kumbukumbu ya msingi ambayo mara nyingi hutengenezwa na LLVM.
//! Kwa kuongeza, maktaba hii inaweza kupiga simu wazi kwa kazi hizi.
//! Saini zao ni sawa na kupatikana katika C.
//!   Kazi hizi mara nyingi hutolewa na mfumo wa libc, lakini pia inaweza kutolewa na [compiler-builtins crate](https://crates.io/crates/compiler_builtins).
//!
//!
//! * `rust_begin_panic` - Kazi hii inachukua hoja nne, `fmt::Arguments`, `&'static str`, na "u32" mbili.
//! Hoja hizi nne zinaamuru ujumbe wa panic, faili ambayo panic iliombwa, na mstari na safu ndani ya faili.
//! Ni juu ya watumiaji wa maktaba hii ya msingi kufafanua kazi hii ya panic;inahitajika tu kurudi kamwe.
//! Hii inahitaji sifa ya `lang` iitwayo `panic_impl`.
//!
//! * `rust_eh_personality` - hutumiwa na mifumo ya kutofaulu ya mkusanyaji.
//! Hii mara nyingi hupangwa kwa kazi ya utu wa GCC, lakini crates ambazo hazisababishi panic zinaweza kuhakikishiwa kuwa kazi hii haiitwi kamwe.
//! Sifa ya `lang` inaitwa `eh_personality`.
//!
//!
//!

// Kwa kuwa libcore inafafanua vitu vingi vya kimsingi vya lang, vipimo vyote vinaishi katika crate tofauti, iliyo bora zaidi, ili kuzuia maswala ya kushangaza.
//
// Hapa sisi dhahiri#[cfg]-nje ya crate hii yote wakati wa kujaribu.
// Ikiwa hatufanyi hivi, kifaa cha jaribio kilichozalishwa na libtest iliyounganishwa (ambayo kwa pamoja inajumuisha libcore) zote zitafafanua seti sawa ya vitu vya lang, na hii itasababisha kosa la E0152 "found duplicate lang item".
//
// Tazama majadiliano katika #50466 kwa maelezo.
//
// Hii cfg haitaathiri majaribio ya hati.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // Tazama #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: haiitaji kuwa ya umma
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// Vuta kwenye `core_arch` crate moja kwa moja kwenye libcore.Yaliyomo ya `core_arch` yako katika hazina tofauti: rust-lang/stdarch.
//
// `core_arch` inategemea libcore, lakini yaliyomo kwenye moduli hii imewekwa kwa njia ambayo kuivuta moja kwa moja hapa inafanya kazi kwamba crate inatumia crate hii kama libcore yake.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: Ufafanuzi huu unapaswa kuhamishiwa kwenye rust-lang/stdarch baada ya matamshi ya clashing_extern_
// imeunganishwa.Kwa sasa haiwezi kwa sababu bootstrap inashindwa kwani lint haijafafanuliwa bado.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;