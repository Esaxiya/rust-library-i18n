//! Kazi za kimsingi za kushughulikia kumbukumbu.
//!
//! Moduli hii ina kazi za kuuliza ukubwa na mpangilio wa aina, kuanzisha na kudhibiti kumbukumbu.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Inachukua umiliki na "forgets" juu ya thamani **bila kuendesha uharibifu wake**.
///
/// Rasilimali yoyote ambayo dhamana inasimamia, kama kumbukumbu ya lundo au kipini cha faili, itakaa milele katika hali isiyoweza kufikiwa.Walakini, haihakikishi kuwa viashiria vya kumbukumbu hii vitabaki halali.
///
/// * Ikiwa unataka kuvuja kumbukumbu, tazama [`Box::leak`].
/// * Ikiwa unataka kupata pointer mbichi kwenye kumbukumbu, tazama [`Box::into_raw`].
/// * Ikiwa unataka kutoa dhamana vizuri, ukiendesha uharibifu wake, angalia [`mem::drop`].
///
/// # Safety
///
/// `forget` haijawekwa alama kama `unsafe`, kwa sababu dhamana ya usalama ya Rust haijumuishi dhamana ya kuwa waharibifu wataendesha kila wakati.
/// Kwa mfano, mpango unaweza kuunda mzunguko wa kumbukumbu ukitumia [`Rc`][rc], au piga simu [`process::exit`][exit] ili uondoke bila kuwaangamiza waharibu.
/// Kwa hivyo, kuruhusu `mem::forget` kutoka kwa nambari salama haibadilishi kimsingi dhamana za usalama za Rust.
///
/// Hiyo ilisema, kuvuja kwa rasilimali kama kumbukumbu au vitu vya I/O kawaida haifai.
/// Uhitaji unakuja katika visa maalum vya utumiaji wa FFI au nambari isiyo salama, lakini hata hivyo, [`ManuallyDrop`] hupendekezwa kawaida.
///
/// Kwa sababu kusahau thamani inaruhusiwa, nambari yoyote ya `unsafe` unayoandika lazima iruhusu uwezekano huu.Huwezi kurudisha thamani na unatarajia kwamba mpigaji lazima aendeshe uharibifu wa dhamana.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Matumizi salama ya kanuni ya `mem::forget` ni kukwepa uharibifu wa thamani unaotekelezwa na `Drop` trait.Kwa mfano, hii itavuja `File`, yaani
/// rejesha nafasi iliyochukuliwa na kutofautisha lakini usifunge rasilimali ya msingi ya mfumo:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Hii ni muhimu wakati umiliki wa rasilimali ya msingi hapo awali ulihamishiwa kwa nambari nje ya Rust, kwa mfano kwa kupeleka kielezi kibichi cha faili kwa nambari C.
///
/// # Uhusiano na `ManuallyDrop`
///
/// Wakati `mem::forget` pia inaweza kutumika kuhamisha umiliki wa kumbukumbu *, kufanya hivyo ni kukosea kwa makosa.
/// [`ManuallyDrop`] inapaswa kutumika badala yake.Fikiria, kwa mfano, nambari hii:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Jenga `String` ukitumia yaliyomo kwenye `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // kuvuja `v` kwa sababu kumbukumbu yake sasa inasimamiwa na `s`
/// mem::forget(v);  // KOSA, v ni batili na haipaswi kupitishwa kwa kazi
/// assert_eq!(s, "Az");
/// // `s` imeshushwa kabisa na kumbukumbu yake ikahamishwa.
/// ```
///
/// Kuna masuala mawili na mfano hapo juu:
///
/// * Ikiwa nambari zaidi ingeongezwa kati ya ujenzi wa `String` na ombi la `mem::forget()`, panic ndani yake itasababisha bure mara mbili kwa sababu kumbukumbu hiyo hiyo inasimamiwa na `v` na `s`.
/// * Baada ya kupiga simu `v.as_mut_ptr()` na kupeleka umiliki wa data kwa `s`, thamani ya `v` ni batili.
/// Hata wakati thamani inahamishiwa kwa `mem::forget` (ambayo haitaikagua), aina zingine zina mahitaji kali juu ya maadili yao ambayo huwafanya kuwa batili wakati wa kulenga au kutomilikiwa tena.
/// Kutumia nambari zisizo sahihi kwa njia yoyote, pamoja na kuzipitisha au kuzirudisha kutoka kwa kazi, hufanya tabia isiyojulikana na inaweza kuvunja mawazo yaliyofanywa na mkusanyaji.
///
/// Kubadilisha kwenda `ManuallyDrop` kunaepuka maswala yote mawili:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Kabla hatujakusanya `v` katika sehemu zake mbichi, hakikisha haipunguki!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Sasa changanya `v`.Shughuli hizi haziwezi panic, kwa hivyo hakuwezi kuvuja.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Mwishowe, jenga `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` imeshushwa kabisa na kumbukumbu yake ikahamishwa.
/// ```
///
/// `ManuallyDrop` kwa nguvu huzuia kutokuwa na maradufu kwa sababu tunalemaza mwangamizi wa v kabla ya kufanya kitu kingine chochote.
/// `mem::forget()` hairuhusu hii kwa sababu hutumia hoja yake, ikitulazimisha kuiita tu baada ya kutoa chochote tunachohitaji kutoka kwa `v`.
/// Hata kama panic ingeletwa kati ya ujenzi wa `ManuallyDrop` na kujenga kamba (ambayo haiwezi kutokea kwa nambari kama inavyoonyeshwa), itasababisha kuvuja na sio bure mara mbili.
/// Kwa maneno mengine, `ManuallyDrop` inakosea upande wa kuvuja badala ya kukosea upande wa (double-) kuacha.
///
/// Pia, `ManuallyDrop` inatuzuia kuwa na "touch" `v` baada ya kuhamisha umiliki kwa `s`-hatua ya mwisho ya kuingiliana na `v` kuitupa bila kuendesha mharibifu wake inaepukwa kabisa.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Kama [`forget`], lakini pia inakubali viwango visivyo na ukubwa.
///
/// Kazi hii ni shim tu inayokusudiwa kuondolewa wakati kipengee cha `unsized_locals` kinapotulia.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Hurejesha saizi ya aina katika ka.
///
/// Hasa haswa, hii ndio rejeshi ya ka kati ya vitu vifuatavyo katika safu na aina ya kipengee hicho ikiwa ni pamoja na pedi ya mpangilio.
///
/// Kwa hivyo, kwa aina yoyote `T` na urefu `n`, `[T; n]` ina saizi ya `n * size_of::<T>()`.
///
/// Kwa ujumla, saizi ya aina sio thabiti kwa mkusanyiko, lakini aina maalum kama vile vipaumbele viko.
///
/// Jedwali lifuatalo linatoa saizi ya vipaumbele.
///
/// Chapa |saizi_ya: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Kwa kuongezea, `usize` na `isize` zina saizi sawa.
///
/// Aina `*const T`, `&T`, `Box<T>`, `Option<&T>`, na `Option<Box<T>>` zote zina saizi sawa.
/// Ikiwa `T` ni Ukubwa, aina zote hizo zina ukubwa sawa na `usize`.
///
/// Kubadilika kwa pointer hakubadilishi saizi yake.Kwa hivyo, `&T` na `&mut T` zina saizi sawa.
/// Vivyo hivyo kwa `*const T` na `* mut T`.
///
/// # Ukubwa wa vitu vya `#[repr(C)]`
///
/// Uwakilishi wa `C` wa vitu una mpangilio uliofafanuliwa.
/// Kwa mpangilio huu, saizi ya vitu pia ni sawa maadamu uwanja wote una saizi thabiti.
///
/// ## Ukubwa wa Ujenzi
///
/// Kwa `structs`, saizi imedhamiriwa na algorithm ifuatayo.
///
/// Kwa kila uwanja katika muundo ulioamriwa na agizo la tamko:
///
/// 1. Ongeza saizi ya shamba.
/// 2. Zungusha saizi ya sasa kwa anuwai ya karibu ya uwanja unaofuata wa [alignment].
///
/// Mwishowe, zungusha saizi ya muundo kwa anuwai ya karibu ya [alignment] yake.
/// Mpangilio wa muundo kawaida ni usawa mkubwa zaidi wa uwanja wake wote;hii inaweza kubadilishwa na matumizi ya `repr(align(N))`.
///
/// Tofauti na `C`, structs za sifuri hazijazungushwa hadi baiti moja kwa saizi.
///
/// ## Ukubwa wa Enum
///
/// Enum ambazo hazina data yoyote isipokuwa ubaguzi zina ukubwa sawa na enum za C kwenye jukwaa ambalo wamekusanywa.
///
/// ## Ukubwa wa Vyama vya Wafanyakazi
///
/// Ukubwa wa umoja ni saizi ya uwanja wake mkubwa.
///
/// Tofauti na `C`, vyama vya wafanyakazi vya sifuri havijazungushwa hadi baiti moja kwa ukubwa.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Baadhi ya maliasili
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Baadhi ya safu
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Usawa wa ukubwa wa kiashiria
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Kutumia `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ukubwa wa uwanja wa kwanza ni 1, kwa hivyo ongeza 1 kwa saizi.Ukubwa ni 1.
/// // Mpangilio wa uwanja wa pili ni 2, kwa hivyo ongeza 1 kwa saizi ya pedi.Ukubwa ni 2.
/// // Ukubwa wa uwanja wa pili ni 2, kwa hivyo ongeza 2 kwa saizi.Ukubwa ni 4.
/// // Mpangilio wa uwanja wa tatu ni 1, kwa hivyo ongeza 0 kwa saizi ya pedi.Ukubwa ni 4.
/// // Ukubwa wa uwanja wa tatu ni 1, kwa hivyo ongeza 1 kwa saizi.Ukubwa ni 5.
/// // Mwishowe, mpangilio wa muundo ni 2 (kwa sababu mpangilio mkubwa kati ya uwanja wake ni 2), kwa hivyo ongeza 1 kwa saizi ya pedi.
/// // Ukubwa ni 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs kufuata sheria sawa.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Kumbuka kuwa kupanga upya shamba kunaweza kupunguza ukubwa.
/// // Tunaweza kuondoa kaiti zote mbili za kuweka pedi kwa kuweka `third` kabla ya `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ukubwa wa umoja ni saizi ya uwanja mkubwa zaidi.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Hurejesha ukubwa wa thamani iliyoelekezwa kwa ka.
///
/// Hii kawaida ni sawa na `size_of::<T>()`.
/// Walakini, wakati `T`*haina* saizi inayojulikana kwa kitakwimu, kwa mfano, kipande [`[T]`][slice] au [trait object], basi `size_of_val` inaweza kutumika kupata saizi inayojulikana kwa nguvu.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // USALAMA: `val` ni kumbukumbu, kwa hivyo ni pointer halali ghafi
    unsafe { intrinsics::size_of_val(val) }
}

/// Hurejesha ukubwa wa thamani iliyoelekezwa kwa ka.
///
/// Hii kawaida ni sawa na `size_of::<T>()`.Walakini, wakati `T`*haina* saizi inayojulikana kwa kitakwimu, kwa mfano, kipande [`[T]`][slice] au [trait object], basi `size_of_val_raw` inaweza kutumika kupata saizi inayojulikana kwa nguvu.
///
/// # Safety
///
/// Kazi hii ni salama kupiga simu ikiwa hali zifuatazo zinashikilia:
///
/// - Ikiwa `T` ni `Sized`, kazi hii ni salama kupiga simu kila wakati.
/// - Ikiwa mkia usio na ukubwa wa `T` ni:
///     - [slice], basi urefu wa mkia wa kipande lazima iwe nambari kamili, na saizi ya *thamani nzima*(urefu wa mkia wenye nguvu + kiambishi cha ukubwa wa kitabaka) lazima iwe sawa na `isize`.
///     - [trait object], kisha sehemu inayoweza kushughulikiwa ya pointer lazima ielekeze kwa vtable halali inayopatikana kwa kulazimisha kutosheleza, na saizi ya *thamani nzima*(urefu wa mkia wenye nguvu + kiambishi awali cha ukubwa) lazima iwe sawa na `isize`.
///
///     - (unstable) [extern type], basi kazi hii ni salama kupiga simu kila wakati, lakini panic au vinginevyo irudishe thamani isiyofaa, kwani mpangilio wa aina ya nje haujulikani.
///     Hii ni tabia sawa na [`size_of_val`] kwenye kumbukumbu ya aina iliyo na mkia wa aina ya nje.
///     - vinginevyo, hairuhusiwi kihalisi kuita kazi hii.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // USALAMA: mpigaji lazima atoe kiboreshaji halali kibichi
    unsafe { intrinsics::size_of_val(val) }
}

/// Hurejesha upangiliaji wa chini unaohitajika wa [ABI] wa aina.
///
/// Kila marejeleo ya thamani ya aina `T` lazima iwe nambari kadhaa.
///
/// Huu ndio mpangilio uliotumika kwa uwanja wa muundo.Inaweza kuwa ndogo kuliko mpangilio uliopendelea.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Hurejesha mpangilio wa chini unaohitajika [ABI] wa aina ya thamani ambayo `val` inaelekeza.
///
/// Kila marejeleo ya thamani ya aina `T` lazima iwe nambari kadhaa.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // USALAMA: val ni kumbukumbu, kwa hivyo ni pointer halali ghafi
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Hurejesha upangiliaji wa chini unaohitajika wa [ABI] wa aina.
///
/// Kila marejeleo ya thamani ya aina `T` lazima iwe nambari kadhaa.
///
/// Huu ndio mpangilio uliotumika kwa uwanja wa muundo.Inaweza kuwa ndogo kuliko mpangilio uliopendelea.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Hurejesha mpangilio wa chini unaohitajika [ABI] wa aina ya thamani ambayo `val` inaelekeza.
///
/// Kila marejeleo ya thamani ya aina `T` lazima iwe nambari kadhaa.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // USALAMA: val ni kumbukumbu, kwa hivyo ni pointer halali ghafi
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Hurejesha mpangilio wa chini unaohitajika [ABI] wa aina ya thamani ambayo `val` inaelekeza.
///
/// Kila marejeleo ya thamani ya aina `T` lazima iwe nambari kadhaa.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Kazi hii ni salama kupiga simu ikiwa hali zifuatazo zinashikilia:
///
/// - Ikiwa `T` ni `Sized`, kazi hii ni salama kupiga simu kila wakati.
/// - Ikiwa mkia usio na ukubwa wa `T` ni:
///     - [slice], basi urefu wa mkia wa kipande lazima iwe nambari kamili, na saizi ya *thamani nzima*(urefu wa mkia wenye nguvu + kiambishi cha ukubwa wa kitabaka) lazima iwe sawa na `isize`.
///     - [trait object], kisha sehemu inayoweza kushughulikiwa ya pointer lazima ielekeze kwa vtable halali inayopatikana kwa kulazimisha kutosheleza, na saizi ya *thamani nzima*(urefu wa mkia wenye nguvu + kiambishi awali cha ukubwa) lazima iwe sawa na `isize`.
///
///     - (unstable) [extern type], basi kazi hii ni salama kupiga simu kila wakati, lakini panic au vinginevyo irudishe thamani isiyofaa, kwani mpangilio wa aina ya nje haujulikani.
///     Hii ni tabia sawa na [`align_of_val`] kwenye kumbukumbu ya aina iliyo na mkia wa aina ya nje.
///     - vinginevyo, hairuhusiwi kihalisi kuita kazi hii.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // USALAMA: mpigaji lazima atoe kiboreshaji halali kibichi
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Hurejesha `true` ikiwa inaacha maadili ya aina ya `T`.
///
/// Hili ni dokezo la matumizi, na linaweza kutekelezwa kihafidhina:
/// inaweza kurudisha `true` kwa aina ambazo hazihitaji kudondoshwa.
/// Kama vile kurudi `true` kila wakati itakuwa utekelezaji halali wa kazi hii.Walakini ikiwa kazi hii inarudi `false`, basi unaweza kuwa na uhakika wa kuacha `T` haina athari ya upande.
///
/// Utekelezaji wa kiwango cha chini cha vitu kama makusanyo, ambayo yanahitaji kuacha data zao kwa mikono, inapaswa kutumia kazi hii ili kuepuka kujaribu kutupwa yaliyomo wakati usiohitajika.
///
/// Hii inaweza isileti tofauti katika kutolewa huunda (ambapo kitanzi kisicho na athari-mbaya hugundulika na kuondolewa), lakini mara nyingi ni ushindi mkubwa kwa utengenezaji wa utatuzi.
///
/// Kumbuka kuwa [`drop_in_place`] tayari inafanya hundi hii, kwa hivyo ikiwa mzigo wako wa kazi unaweza kupunguzwa hadi idadi ndogo ya simu za [`drop_in_place`], kutumia hii sio lazima.
/// Hasa kumbuka kuwa unaweza [`drop_in_place`] kipande, na hiyo itafanya ukaguzi wa mahitaji-drop moja kwa maadili yote.
///
/// Aina kama Vec kwa hivyo ni `drop_in_place(&mut self[..])` tu bila kutumia `needs_drop` wazi.
/// Aina kama [`HashMap`], kwa upande mwingine, zinapaswa kuacha maadili moja kwa moja na inapaswa kutumia API hii.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hapa kuna mfano wa jinsi mkusanyiko unaweza kutumia `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // kuacha data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Hurejesha thamani ya aina `T` inayowakilishwa na muundo wote wa sifuri.
///
/// Hii inamaanisha kuwa, kwa mfano, kauri ya padding katika `(u8, u16)` sio lazima ifunguliwe.
///
/// Hakuna hakikisho kwamba muundo-wa-sifuri-wote unawakilisha thamani halali ya aina fulani ya `T`.
/// Kwa mfano, muundo wote wa sifuri sio thamani halali kwa aina za rejeleo (`&T`, `&mut T`) na viashiria vya kazi.
/// Kutumia `zeroed` kwenye aina kama hizo husababisha [undefined behavior][ub] ya haraka kwa sababu [the Rust compiler assumes][inv] ambayo kila wakati kuna dhamana halali katika anuwai ambayo inazingatia kuwa imeanzishwa.
///
///
/// Hii ina athari sawa na [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Ni muhimu kwa FFI wakati mwingine, lakini inapaswa kuepukwa kwa ujumla.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Matumizi sahihi ya kazi hii: kuanzisha nambari na sifuri.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Matumizi yasiyo sahihi* ya kazi hii: kuanzisha kumbukumbu na sifuri.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Tabia isiyojulikana!
/// let _y: fn() = unsafe { mem::zeroed() }; // Na tena!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // USALAMA: mpigaji lazima ahakikishe kwamba thamani ya sifuri yote ni halali kwa `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ufuatiliaji wa kawaida wa kumbukumbu za uanzishaji wa kumbukumbu za Rust kwa kujifanya kutoa dhamana ya aina `T`, bila kufanya chochote.
///
/// **Kazi hii imepunguzwa.** Tumia [`MaybeUninit<T>`] badala yake.
///
/// Sababu ya kukata tamaa ni kwamba kazi kimsingi haiwezi kutumika kwa usahihi: ina athari sawa na [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kama [`assume_init` documentation][assume_init] inavyoelezea, [the Rust compiler assumes][inv] kwamba maadili yameanzishwa vizuri.
/// Kama matokeo, kupiga simu mfano
/// `mem::uninitialized::<bool>()` husababisha tabia isiyojulikana ya kurudisha `bool` ambayo sio `true` au `false`.
/// Mbaya zaidi, kumbukumbu isiyojulikana kama ile inayorudishwa hapa ni maalum kwa kuwa mkusanyaji anajua kuwa haina thamani iliyowekwa.
/// Hii inafanya kuwa tabia isiyojulikana kuwa na data isiyo ya kawaida katika kutofautisha hata ikiwa kutofautisha kuna aina ya nambari.
/// (Ona kuwa sheria zinazozunguka nambari ambazo hazijakamilishwa bado hazijakamilika, lakini hadi hapo zinapokamilika, inashauriwa kuziepuka.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // USALAMA: mpigaji lazima ahakikishe kuwa thamani isiyoanzishwa ni halali kwa `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Inabadilisha maadili katika maeneo mawili yanayoweza kubadilika, bila kukomesha mojawapo.
///
/// * Ikiwa unataka kubadilishana na chaguo-msingi au dummy, tazama [`take`].
/// * Ikiwa unataka kubadilishana na thamani iliyopitishwa, kurudisha thamani ya zamani, angalia [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // USALAMA: viashiria mbichi vimeundwa kutoka kwa marejeo salama yanayoweza kutosheleza faili zote za
    // vikwazo kwenye `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Inachukua nafasi ya `dest` na thamani chaguo-msingi ya `T`, na kurudisha thamani ya awali ya `dest`.
///
/// * Ikiwa unataka kuchukua nafasi ya maadili ya anuwai mbili, angalia [`swap`].
/// * Ikiwa unataka kubadilisha na dhamana iliyopitishwa badala ya chaguo-msingi, angalia [`replace`].
///
/// # Examples
///
/// Mfano rahisi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` inaruhusu kuchukua umiliki wa uwanja wa muundo kwa kuibadilisha na thamani ya "empty".
/// Bila `take` unaweza kujiingiza katika maswala kama haya:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Kumbuka kuwa `T` sio lazima itekeleze [`Clone`], kwa hivyo haiwezi hata kushikilia na kuweka upya `self.buf`.
/// Lakini `take` inaweza kutumika kutenganisha dhamana ya asili ya `self.buf` kutoka `self`, ikiruhusu irudishwe:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Husogeza `src` kwenye `dest` iliyotajwa, na kurudisha thamani ya awali ya `dest`.
///
/// Thamani yoyote haijashushwa.
///
/// * Ikiwa unataka kuchukua nafasi ya maadili ya anuwai mbili, angalia [`swap`].
/// * Ikiwa unataka kuchukua nafasi ya thamani chaguo-msingi, tazama [`take`].
///
/// # Examples
///
/// Mfano rahisi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` inaruhusu matumizi ya uwanja wa muundo kwa kuibadilisha na thamani nyingine.
/// Bila `replace` unaweza kujiingiza katika maswala kama haya:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Kumbuka kuwa `T` sio lazima itekeleze [`Clone`], kwa hivyo hatuwezi hata kushika `self.buf[i]` ili kuepusha hoja hiyo.
/// Lakini `replace` inaweza kutumika kutenganisha thamani ya asili kwenye faharisi hiyo kutoka kwa `self`, ikiruhusu irudishwe:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // USALAMA: Tunasoma kutoka `dest` lakini moja kwa moja andika `src` ndani yake baadaye,
    // vile kwamba thamani ya zamani haikunakiliwa.
    // Hakuna kitu kilichoangushwa na hakuna kitu hapa kinachoweza panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Hutoa thamani.
///
/// Hii inafanya hivyo kwa kuita utekelezaji wa hoja ya [`Drop`][drop].
///
/// Hii haifanyi chochote kwa aina ambazo hutekeleza `Copy`, kwa mfano
/// integers.
/// Thamani kama hizo zinakiliwa na _then_ imehamishwa kwenye kazi, kwa hivyo thamani hiyo inaendelea baada ya simu hii ya kazi.
///
///
/// Kazi hii sio uchawi;inafafanuliwa kihalisi kama
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Kwa sababu `_x` imehamishiwa kwenye kazi, hutupwa kiatomati kabla ya kazi kurudi.
///
/// [drop]: Drop
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // acha wazi vector
/// ```
///
/// Kwa kuwa [`RefCell`] inasisitiza sheria za kukopa wakati wa kukimbia, `drop` inaweza kutolewa kwa kukopa [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // achilia mbali kukopa zinazobadilika kwenye nafasi hii
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Nambari na aina zingine zinazotekeleza [`Copy`] haziathiriwi na `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // nakala ya `x` imehamishwa na kudondoshwa
/// drop(y); // nakala ya `y` imehamishwa na kudondoshwa
///
/// println!("x: {}, y: {}", x, y.0); // bado inapatikana
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Inatafsiri `src` kama ina aina `&U`, halafu inasoma `src` bila kusonga thamani iliyomo.
///
/// Kazi hii itafikiria bila usalama pointer `src` ni halali kwa baiti za [`size_of::<U>`][size_of] kwa kusambaza `&T` hadi `&U` na kisha kusoma `&U` (isipokuwa kwamba hii imefanywa kwa njia ambayo ni sahihi hata wakati `&U` inafanya mahitaji ya mpangilio mkali kuliko `&T`).
/// Pia itaunda salama nakala ya dhamana iliyomo badala ya kutoka kwa `src`.
///
/// Sio kosa la kukusanya wakati ikiwa `T` na `U` zina saizi tofauti, lakini inahimizwa sana kuomba tu kazi hii ambapo `T` na `U` zina saizi sawa.Kazi hii inasababisha [undefined behavior][ub] ikiwa `U` ni kubwa kuliko `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Nakili data kutoka 'foo_array' na uichukue kama 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Rekebisha data iliyonakiliwa
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Yaliyomo ya 'foo_array' hayapaswi kubadilika
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ikiwa U ina mahitaji ya upangiliaji wa hali ya juu, src inaweza isiwe sawa.
    if align_of::<U>() > align_of::<T>() {
        // USALAMA: `src` ni kumbukumbu ambayo imehakikishiwa kuwa halali kwa usomaji.
        // Mpigaji lazima ahakikishe kuwa uhamisho halisi ni salama.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // USALAMA: `src` ni kumbukumbu ambayo imehakikishiwa kuwa halali kwa usomaji.
        // Tuliangalia tu kuwa `src as *const U` ilikuwa imewekwa vizuri.
        // Mpigaji lazima ahakikishe kuwa uhamisho halisi ni salama.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Aina ya opaque inayowakilisha ubaguzi wa enum.
///
/// Tazama kazi ya [`discriminant`] katika moduli hii kwa habari zaidi.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Utekelezaji huu wa trait hauwezi kupatikana kwa sababu hatutaki mipaka yoyote kwenye T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Hurejesha thamani ya kipekee kubainisha lahaja ya enum katika `v`.
///
/// Ikiwa `T` sio enum, kuita kazi hii hakutasababisha tabia isiyojulikana, lakini thamani ya kurudi haijulikani.
///
///
/// # Stability
///
/// Ubaguzi wa lahaja ya enum inaweza kubadilika ikiwa ufafanuzi wa enum utabadilika.
/// Ubaguzi wa aina fulani hautabadilika kati ya mkusanyiko na mkusanyaji mmoja.
///
/// # Examples
///
/// Hii inaweza kutumika kulinganisha enum ambazo hubeba data, wakati unapuuza data halisi:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Hurejesha idadi ya anuwai katika aina ya enum `T`.
///
/// Ikiwa `T` sio enum, kuita kazi hii hakutasababisha tabia isiyojulikana, lakini thamani ya kurudi haijulikani.
/// Vivyo hivyo, ikiwa `T` ni enum iliyo na anuwai zaidi ya `usize::MAX` thamani ya kurudi haijulikani.
/// Tofauti zisizokaliwa zitahesabiwa.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}