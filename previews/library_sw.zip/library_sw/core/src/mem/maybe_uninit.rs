use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Aina ya kufunika ili kuunda visa visivyoanzishwa vya `T`.
///
/// # Uanzishaji wa uanzishaji
///
/// Mkusanyaji, kwa jumla, anafikiria kuwa kutofautisha kunaanzishwa vizuri kulingana na mahitaji ya aina ya ubadilishaji.Kwa mfano, anuwai ya aina ya kumbukumbu lazima iwe iliyokaa na isiyo ya NULL.
/// Huyu ni mbadilishaji ambaye lazima *aangaliwe* kila wakati, hata kwa nambari isiyo salama.
/// Kama matokeo, sifuri-kuanzisha utofauti wa aina ya rejeleo husababisha [undefined behavior][ub] ya mara moja, bila kujali ikiwa kumbukumbu hiyo inatumika kupata kumbukumbu:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // tabia isiyojulikana!.️
/// // Nambari sawa na `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // tabia isiyojulikana!.️
/// ```
///
/// Hii inatumiwa na mkusanyaji kwa uboreshaji anuwai, kama vile kukomesha ukaguzi wa wakati wa kukimbia na kuboresha mpangilio wa `enum`.
///
/// Vivyo hivyo, kumbukumbu isiyojulikana kabisa inaweza kuwa na yaliyomo, wakati `bool` lazima iwe `true` au `false` kila wakati.Kwa hivyo, kuunda `bool` isiyojulikana ni tabia isiyojulikana:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // tabia isiyojulikana!.️
/// // Nambari sawa na `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // tabia isiyojulikana!.️
/// ```
///
/// Kwa kuongezea, kumbukumbu isiyojulikana ni maalum kwa kuwa haina thamani iliyowekwa ("fixed" ikimaanisha "it won't change without being written to").Kusoma baiti ile ile isiyofafanuliwa mara kadhaa inaweza kutoa matokeo tofauti.
/// Hii inafanya kuwa tabia isiyojulikana kuwa na data isiyo ya msingi katika kutofautisha hata ikiwa kutofautisha kuna aina ya nambari, ambayo vinginevyo inaweza kushikilia muundo wowote * uliowekwa:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // tabia isiyojulikana!.️
/// // Nambari sawa na `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // tabia isiyojulikana!.️
/// ```
/// (Ona kuwa sheria zinazozunguka nambari ambazo hazijakamilishwa bado hazijakamilika, lakini hadi hapo zinapokamilika, inashauriwa kuziepuka.)
///
/// Juu ya hayo, kumbuka kwamba aina nyingi zina viboreshaji vya ziada zaidi ya kuzingatiwa tu kuwa vimeanzishwa katika kiwango cha aina.
/// Kwa mfano, `1`-iliyoanzishwa [`Vec<T>`] inachukuliwa kuwa imeanzishwa (chini ya utekelezaji wa sasa; hii sio dhamana thabiti) kwa sababu mahitaji tu ambayo mkusanyaji anajua juu yake ni kwamba pointer ya data lazima isiwe batili.
/// Kuunda `Vec<T>` kama hiyo haisababishi tabia ya "haraka" isiyojulikana, lakini itasababisha tabia isiyojulikana na shughuli salama zaidi (pamoja na kuiacha).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` hutumika kuwezesha nambari isiyo salama kushughulikia data ambazo hazijaanza.
/// Ni ishara kwa mkusanyaji inayoonyesha kuwa data hapa inaweza kuwa * isianzishwe:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Unda rejeleo lisilojulikana wazi.
/// // Mkusanyaji anajua kuwa data ndani ya `MaybeUninit<T>` inaweza kuwa batili, na kwa hivyo hii sio UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Weka kwa thamani halali.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Toa data iliyoanzishwa-hii inaruhusiwa tu *baada ya* kuanzisha vizuri `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Mkusanyaji basi anajua kutofanya mawazo yoyote yasiyofaa au uboreshaji kwenye nambari hii.
///
/// Unaweza kufikiria `MaybeUninit<T>` kama kidogo kama `Option<T>` lakini bila ufuatiliaji wowote wa wakati wa kukimbia na bila ukaguzi wowote wa usalama.
///
/// ## out-pointers
///
/// Unaweza kutumia `MaybeUninit<T>` kutekeleza "out-pointers": badala ya kurudisha data kutoka kwa kazi, pitisha kiashiria kwa kumbukumbu fulani ya (uninitialized) ili kuweka matokeo ndani.
/// Hii inaweza kuwa na manufaa wakati ni muhimu kwa mpigaji kudhibiti jinsi kumbukumbu inavyotunzwa kwa matokeo, na unataka kuzuia hatua zisizohitajika.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` haitoi yaliyomo ya zamani, ambayo ni muhimu.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Sasa tunajua `v` imeanzishwa!Hii pia inahakikisha vector inapungua vizuri.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Kuanzisha kipengee cha kipengee-kwa-kipengee
///
/// `MaybeUninit<T>` inaweza kutumika kuanzisha safu kubwa ya kipengee-na-kipengee:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Unda safu isiyojulikana ya `MaybeUninit`.
///     // `assume_init` ni salama kwa sababu aina ambayo tunadai kuwa imeanzisha hapa ni rundo la `MaybeUninit`s, ambazo hazihitaji uanzishaji.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Kuacha `MaybeUninit` hakufanyi chochote.
///     // Kwa hivyo kutumia mgawo wa pointer mbadala badala ya `ptr::write` haisababishi thamani ya zamani isiyoanzishwa kushushwa.
/////
///     // Pia ikiwa kuna panic wakati wa kitanzi hiki, tuna uvujaji wa kumbukumbu, lakini hakuna suala la usalama wa kumbukumbu.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Kila kitu kimeanzishwa.
///     // Hamisha safu kwa aina iliyoanzishwa.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Unaweza pia kufanya kazi na safu zilizoanzishwa kwa sehemu, ambazo zinaweza kupatikana katika muundo wa kiwango cha chini.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Unda safu isiyojulikana ya `MaybeUninit`.
/// // `assume_init` ni salama kwa sababu aina ambayo tunadai kuwa imeanzisha hapa ni rundo la `MaybeUninit`s, ambazo hazihitaji uanzishaji.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Hesabu idadi ya vitu ambavyo tumepewa.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Kwa kila kitu katika safu, angusha ikiwa tumetenga.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inazindua uwanja kwa shamba
///
/// Unaweza kutumia `MaybeUninit<T>`, na jumla ya [`std::ptr::addr_of_mut`], kuanzisha uwanja kwa shamba:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inazindua uwanja wa `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Kuanzisha uwanja wa `list` Ikiwa kuna panic hapa, basi `String` kwenye uwanja wa `name` huvuja.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Sehemu zote zimeanzishwa, kwa hivyo tunaita `assume_init` kupata Foo iliyoanzishwa.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` imehakikishiwa kuwa na saizi sawa, mpangilio, na ABI kama `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Walakini kumbuka kuwa aina *iliyo na*`MaybeUninit<T>` sio mpangilio sawa;Rust haihakikishi kwa ujumla kuwa uwanja wa `Foo<T>` una mpangilio sawa na `Foo<U>` hata ikiwa `T` na `U` zina ukubwa sawa na mpangilio.
///
/// Kwa kuongezea kwa sababu dhamana yoyote ni halali kwa `MaybeUninit<T>` mkusanyaji hawezi kutumia uboreshaji wa non-zero/niche-filling, ambayo inaweza kusababisha saizi kubwa:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ikiwa `T` ni salama ya FFI, basi ndivyo `MaybeUninit<T>`.
///
/// Wakati `MaybeUninit` ni `#[repr(transparent)]` (ikionyesha inahakikisha saizi sawa, mpangilio, na ABI kama `T`), hii haibadilishi pango yoyote ya hapo awali.
/// `Option<T>` na `Option<MaybeUninit<T>>` bado inaweza kuwa na saizi tofauti, na aina zilizo na uwanja wa aina `T` zinaweza kuwekwa (na ukubwa) tofauti kuliko ikiwa uwanja huo ulikuwa `MaybeUninit<T>`.
/// `MaybeUninit` ni aina ya umoja, na `#[repr(transparent)]` juu ya vyama vya wafanyakazi haina utulivu (tazama [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Baada ya muda, dhamana halisi ya `#[repr(transparent)]` kwenye vyama vya wafanyakazi inaweza kubadilika, na `MaybeUninit` inaweza kubaki au haiwezi kubaki `#[repr(transparent)]`.
/// Hiyo ilisema, `MaybeUninit<T>`*daima* itahakikisha kuwa ina saizi sawa, mpangilio, na ABI kama `T`;ni kwamba tu njia `MaybeUninit` inayotumia dhamana hiyo inaweza kubadilika.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang bidhaa ili tuweze kufunga aina zingine ndani yake.Hii ni muhimu kwa jenereta.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Bila kupiga simu `T::clone()`, hatuwezi kujua ikiwa tumeanzishwa vya kutosha kwa hiyo.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Inaunda `MaybeUninit<T>` mpya iliyoanzishwa na thamani iliyopewa.
    /// Ni salama kupiga [`assume_init`] kwa thamani ya kurudi ya kazi hii.
    ///
    /// Kumbuka kuwa kuacha `MaybeUninit<T>` haitaita nambari ya kushuka ya "T".
    /// Ni jukumu lako kuhakikisha `T` inashuka ikiwa itaanza.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Inaunda `MaybeUninit<T>` mpya katika hali isiyoanzishwa.
    ///
    /// Kumbuka kuwa kuacha `MaybeUninit<T>` haitaita nambari ya kushuka ya "T".
    /// Ni jukumu lako kuhakikisha `T` inashuka ikiwa itaanza.
    ///
    /// Tazama [type-level documentation][MaybeUninit] kwa mifano kadhaa.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Unda safu mpya ya vitu vya `MaybeUninit<T>`, katika hali isiyoanzishwa.
    ///
    /// Note: katika toleo la future Rust njia hii inaweza kuwa ya lazima wakati sintaksia halisi inaruhusu [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Mfano hapa chini unaweza kutumia `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Hurejesha kipande cha data (ikiwezekana kidogo) ambacho kilisomwa kweli
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // USALAMA: `[MaybeUninit<_>; LEN]` isiyoanzishwa ni halali.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Inaunda `MaybeUninit<T>` mpya katika hali isiyoanzishwa, na kumbukumbu imejazwa na ka `0`.Inategemea `T` ikiwa hiyo tayari inafanya uanzishaji sahihi.
    ///
    /// Kwa mfano, `MaybeUninit<usize>::zeroed()` imeanzishwa, lakini `MaybeUninit<&'static i32>::zeroed()` sio kwa sababu marejeo hayapaswi kuwa batili.
    ///
    /// Kumbuka kuwa kuacha `MaybeUninit<T>` haitaita nambari ya kushuka ya "T".
    /// Ni jukumu lako kuhakikisha `T` inashuka ikiwa itaanza.
    ///
    /// # Example
    ///
    /// Matumizi sahihi ya kazi hii: kuanzisha muundo na sifuri, ambapo sehemu zote za muundo zinaweza kushikilia muundo-kidogo 0 kama dhamana halali.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Matumizi yasiyo sahihi* ya kazi hii: kupiga simu `x.zeroed().assume_init()` wakati `0` sio muundo halali wa aina hiyo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Ndani ya jozi, tunaunda `NotZero` ambayo haina ubaguzi halali.
    /// // Hii ni tabia isiyojulikana..️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // USALAMA: `u.as_mut_ptr()` inaashiria kumbukumbu iliyotengwa.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Inaweka thamani ya `MaybeUninit<T>`.
    /// Hii inachukua nambari yoyote ya zamani bila kuiacha, kwa hivyo kuwa mwangalifu usitumie hii mara mbili isipokuwa unataka kuruka mharibu.
    ///
    /// Kwa urahisi wako, hii pia inarudisha rejeleo linaloweza kubadilika kwa yaliyomo (sasa yameanzishwa salama) ya `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // USALAMA: Tumeanzisha tu thamani hii.
        unsafe { self.assume_init_mut() }
    }

    /// Inapata kiashiria cha thamani iliyomo.
    /// Kusoma kutoka kwa kiboreshaji hiki au kukibadilisha kuwa rejeleo ni tabia isiyojulikana isipokuwa `MaybeUninit<T>` itakapoanzishwa.
    /// Kuandika kwenye kumbukumbu kwamba pointer hii (non-transitively) inaelekeza kwa tabia isiyojulikana (isipokuwa ndani ya `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Matumizi sahihi ya njia hii:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Unda kumbukumbu kwenye `MaybeUninit<T>`.Hii ni sawa kwa sababu tuliianzisha.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// * Matumizi yasiyo sahihi ya njia hii:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Tumeunda rejeleo kwa vector ambayo haijazinduliwa!Hii ni tabia isiyojulikana..️
    /// ```
    ///
    /// (Kumbuka kuwa sheria zinazohusu marejeleo ya data ambazo hazijakamilishwa bado hazijakamilika, lakini hadi hapo zinapokamilika, inashauriwa kuziepuka.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` na `ManuallyDrop` zote ni `repr(transparent)` kwa hivyo tunaweza tupa pointer.
        self as *const _ as *const T
    }

    /// Inapata kiboreshaji kinachoweza kubadilika kwa thamani iliyomo.
    /// Kusoma kutoka kwa kiboreshaji hiki au kukibadilisha kuwa rejeleo ni tabia isiyojulikana isipokuwa `MaybeUninit<T>` itakapoanzishwa.
    ///
    /// # Examples
    ///
    /// Matumizi sahihi ya njia hii:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Unda kumbukumbu kwenye `MaybeUninit<Vec<u32>>`.
    /// // Hii ni sawa kwa sababu tuliianzisha.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// * Matumizi yasiyo sahihi ya njia hii:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Tumeunda rejeleo kwa vector ambayo haijazinduliwa!Hii ni tabia isiyojulikana..️
    /// ```
    ///
    /// (Kumbuka kuwa sheria zinazohusu marejeleo ya data ambazo hazijakamilishwa bado hazijakamilika, lakini hadi hapo zinapokamilika, inashauriwa kuziepuka.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` na `ManuallyDrop` zote ni `repr(transparent)` kwa hivyo tunaweza tupa pointer.
        self as *mut _ as *mut T
    }

    /// Inatoa thamani kutoka kwa chombo cha `MaybeUninit<T>`.Hii ni njia nzuri ya kuhakikisha kuwa data itashuka, kwa sababu `T` inayosababishwa iko chini ya utunzaji wa kawaida wa kushuka.
    ///
    /// # Safety
    ///
    /// Ni juu ya mpigaji kuhakikisha kwamba `MaybeUninit<T>` kweli iko katika hali iliyoanzishwa.Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    /// [type-level documentation][inv] ina habari zaidi juu ya uvumbuzi huu wa uanzishaji.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Juu ya hayo, kumbuka kwamba aina nyingi zina viboreshaji vya ziada zaidi ya kuzingatiwa tu kuwa vimeanzishwa katika kiwango cha aina.
    /// Kwa mfano, `1`-iliyoanzishwa [`Vec<T>`] inachukuliwa kuwa imeanzishwa (chini ya utekelezaji wa sasa; hii sio dhamana thabiti) kwa sababu mahitaji tu ambayo mkusanyaji anajua juu yake ni kwamba pointer ya data lazima isiwe batili.
    ///
    /// Kuunda `Vec<T>` kama hiyo haisababishi tabia ya "haraka" isiyojulikana, lakini itasababisha tabia isiyojulikana na shughuli salama zaidi (pamoja na kuiacha).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Matumizi sahihi ya njia hii:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// * Matumizi yasiyo sahihi ya njia hii:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ilikuwa haijaanzishwa bado, kwa hivyo laini hii ya mwisho ilisababisha tabia isiyojulikana..️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` imeanzishwa.
        // Hii inamaanisha pia kuwa `self` lazima iwe lahaja ya `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Inasoma thamani kutoka kwa chombo cha `MaybeUninit<T>`.`T` inayosababishwa iko chini ya utunzaji wa kawaida wa kushuka.
    ///
    /// Wakati wowote inapowezekana, ni vyema kutumia [`assume_init`] badala yake, ambayo inazuia kuiga yaliyomo kwenye `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Ni juu ya mpigaji kuhakikisha kwamba `MaybeUninit<T>` kweli iko katika hali iliyoanzishwa.Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    /// [type-level documentation][inv] ina habari zaidi juu ya uvumbuzi huu wa uanzishaji.
    ///
    /// Kwa kuongezea, hii inaacha nakala ya data ile ile nyuma ya `MaybeUninit<T>`.
    /// Unapotumia nakala nyingi za data (kwa kupiga simu `assume_init_read` mara kadhaa, au kwanza kupiga simu `assume_init_read` halafu [`assume_init`]), ni jukumu lako kuhakikisha kuwa data hiyo inaweza kurudiwa.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Matumizi sahihi ya njia hii:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ni `Copy`, kwa hivyo tunaweza kusoma mara kadhaa.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Kurudisha thamani ya `None` ni sawa, kwa hivyo tunaweza kusoma mara kadhaa.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// * Matumizi yasiyo sahihi ya njia hii:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Sasa tumeunda nakala mbili za vector hiyo hiyo, na kusababisha kutokuwa na bure mara mbili wakati wote watashuka!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` imeanzishwa.
        // Kusoma kutoka `self.as_ptr()` ni salama kwani `self` inapaswa kuanza.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Huteremsha thamani iliyomo.
    ///
    /// Ikiwa una umiliki wa `MaybeUninit`, unaweza kutumia [`assume_init`] badala yake.
    ///
    /// # Safety
    ///
    /// Ni juu ya mpigaji kuhakikisha kwamba `MaybeUninit<T>` kweli iko katika hali iliyoanzishwa.Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    ///
    /// Juu ya hayo, wavamizi wote wa ziada wa aina `T` lazima waridhike, kwani utekelezaji wa `Drop` wa `T` (au wanachama wake) unaweza kutegemea hii.
    /// Kwa mfano, `1`-iliyoanzishwa [`Vec<T>`] inachukuliwa kuwa imeanzishwa (chini ya utekelezaji wa sasa; hii sio dhamana thabiti) kwa sababu mahitaji tu ambayo mkusanyaji anajua juu yake ni kwamba pointer ya data lazima isiwe batili.
    ///
    /// Kuacha `Vec<T>` kama hiyo kutasababisha tabia isiyojulikana.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` imeanzishwa na
        // inakidhi wavamizi wote wa `T`.
        // Kuacha thamani mahali ni salama ikiwa ndivyo ilivyo.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Inapata rejeleo la pamoja la thamani iliyomo.
    ///
    /// Hii inaweza kuwa muhimu wakati tunataka kufikia `MaybeUninit` ambayo imeanzishwa lakini haina umiliki wa `MaybeUninit` (kuzuia utumiaji wa `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kupigia simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana: ni juu ya mpigaji kuhakikisha kwamba `MaybeUninit<T>` iko katika hali ya kwanza.
    ///
    ///
    /// # Examples
    ///
    /// ### Matumizi sahihi ya njia hii:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Anzisha `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Sasa kwa kuwa `MaybeUninit<_>` yetu inajulikana kuanza, ni sawa kuunda rejeleo la pamoja kwa hiyo:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // USALAMA: `x` imeanzishwa.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Matumizi yasiyo sahihi ya njia hii:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Tumeunda rejeleo kwa vector ambayo haijazinduliwa!Hii ni tabia isiyojulikana..️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Anzisha `MaybeUninit` ukitumia `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Rejea kwa `Cell<bool>` isiyojulikana: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` imeanzishwa.
        // Hii inamaanisha pia kuwa `self` lazima iwe lahaja ya `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Inapata rejeleo ya (unique) inayoweza kubadilika kwa thamani iliyomo.
    ///
    /// Hii inaweza kuwa muhimu wakati tunataka kufikia `MaybeUninit` ambayo imeanzishwa lakini haina umiliki wa `MaybeUninit` (kuzuia utumiaji wa `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kupigia simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana: ni juu ya mpigaji kuhakikisha kwamba `MaybeUninit<T>` iko katika hali ya kwanza.
    /// Kwa mfano, `.assume_init_mut()` haiwezi kutumika kuanzisha `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Matumizi sahihi ya njia hii:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inazindua ka *zote* za bafa ya kuingiza.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Anzisha `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Sasa tunajua kuwa `buf` imeanzishwa, kwa hivyo tunaweza kuiweka `.assume_init()`.
    /// // Walakini, kutumia `.assume_init()` kunaweza kusababisha `memcpy` ya ka 2048.
    /// // Kudhibitisha bafa yetu imeanzishwa bila kuiga, tunaboresha `&mut MaybeUninit<[u8; 2048]>` kuwa `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // USALAMA: `buf` imeanzishwa.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Sasa tunaweza kutumia `buf` kama kipande cha kawaida:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Matumizi yasiyo sahihi ya njia hii:
    ///
    /// Huwezi kutumia `.assume_init_mut()` kuanzisha thamani:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Tumeunda kumbukumbu ya (mutable) kwa `bool` isiyojulikana!
    ///     // Hii ni tabia isiyojulikana..️
    /// }
    /// ```
    ///
    /// Kwa mfano, huwezi [`Read`] kwenye bafa isiyojulikana:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) kumbukumbu ya kumbukumbu isiyojulikana!
    ///                             // Hii ni tabia isiyojulikana.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Wala huwezi kutumia ufikiaji wa shamba moja kwa moja kufanya uanzishaji wa shamba-na-shamba taratibu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) kumbukumbu ya kumbukumbu isiyojulikana!
    ///                  // Hii ni tabia isiyojulikana.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) kumbukumbu ya kumbukumbu isiyojulikana!
    ///                  // Hii ni tabia isiyojulikana.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Kwa sasa tunategemea hapo juu kuwa sio sahihi, yaani, tunayo marejeleo ya data isiyojulikana (kwa mfano, katika `libcore/fmt/float.rs`).
    // Tunapaswa kufanya uamuzi wa mwisho juu ya sheria kabla ya utulivu.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // USALAMA: mpigaji lazima ahakikishe kuwa `self` imeanzishwa.
        // Hii inamaanisha pia kuwa `self` lazima iwe lahaja ya `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Inatoa maadili kutoka kwa safu ya vyombo vya `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Ni juu ya mpigaji kuhakikisha kuwa vitu vyote vya safu viko katika hali iliyoanzishwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // USALAMA: Sasa salama kama tulivyoanzisha vitu vyote
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Mpigaji simu anahakikisha kuwa vitu vyote vya safu vimeanzishwa
        // * `MaybeUninit<T>` na T wamehakikishiwa kuwa na mpangilio sawa
        // * LabdaUnint haitoi, kwa hivyo hakuna uhuru mara mbili Na kwa hivyo ubadilishaji ni salama
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Kwa kudhani vitu vyote vimeanzishwa, pata kipande kwao.
    ///
    /// # Safety
    ///
    /// Ni juu ya mpigaji kuhakikisha kuwa vitu vya `MaybeUninit<T>` kweli viko katika hali ya kuanzishwa.
    ///
    /// Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    ///
    /// Tazama [`assume_init_ref`] kwa maelezo zaidi na mifano.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // USALAMA: kutupa kipande kwa `*const [T]` ni salama kwani mpigaji anahakikisha kuwa
        // `slice` imeanzishwa, na`LabdaUninit` imehakikishiwa kuwa na mpangilio sawa na `T`.
        // Kiashiria kilichopatikana ni halali kwani inamaanisha kumbukumbu inayomilikiwa na `slice` ambayo ni kumbukumbu na kwa hivyo imehakikishwa kuwa halali kwa usomaji.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Kwa kudhani vitu vyote vimeanzishwa, pata kipande kinachoweza kubadilika kwao.
    ///
    /// # Safety
    ///
    /// Ni juu ya mpigaji kuhakikisha kuwa vitu vya `MaybeUninit<T>` kweli viko katika hali ya kuanzishwa.
    ///
    /// Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    ///
    /// Tazama [`assume_init_mut`] kwa maelezo zaidi na mifano.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // USALAMA: sawa na maelezo ya usalama ya `slice_get_ref`, lakini tuna
        // rejea inayoweza kubadilika ambayo pia imehakikishiwa kuwa halali kwa kuandika.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Inapata pointer kwa kipengee cha kwanza cha safu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Inapata kiboreshaji kinachoweza kubadilika kwa kipengee cha kwanza cha safu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Inakili vitu kutoka `src` hadi `this`, ikirudisha rejeleo linaloweza kubadilika kwa yaliyomo sasa ya `this`.
    ///
    /// Ikiwa `T` haitekelezi `Copy`, tumia [`write_slice_cloned`]
    ///
    /// Hii ni sawa na [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa vipande viwili vina urefu tofauti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // USALAMA: tumenakili vitu vyote vya len katika uwezo wa vipuri
    /// // vitu vya kwanza vya src.len() vya vec ni halali sasa.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // USALAMA: &[T] na&[LabdaUninit<T>] kuwa na mpangilio sawa
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // USALAMA: Vipengee halali vimenakiliwa kwenye `this` kwa hivyo imewekwa ndani
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Huiga vitu kutoka `src` hadi `this`, kurudisha rejeleo linaloweza kubadilika kwa yaliyomo sasa ya `this`.
    /// Vipengee vyovyote vilivyowekwa tayari haitaangushwa.
    ///
    /// Ikiwa `T` itatumia `Copy`, tumia [`write_slice`]
    ///
    /// Hii ni sawa na [`slice::clone_from_slice`] lakini haiangushi vitu vilivyopo.
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa vipande viwili vina urefu tofauti, au ikiwa utekelezaji wa `Clone` panics.
    ///
    /// Ikiwa kuna panic, vitu vilivyotengenezwa tayari vitashushwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // USALAMA: tumeunda tu vitu vyote vya len katika uwezo wa vipuri
    /// // vitu vya kwanza vya src.len() vya vec ni halali sasa.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // tofauti na copy_from_slice hii haiiti clone_from_slice kwenye kipande hii ni kwa sababu `MaybeUninit<T: Clone>` haitekelezi Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // USALAMA: kipande hiki kibichi kitakuwa na vitu vilivyoanzishwa tu
                // ndiyo sababu, inaruhusiwa kuiacha.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Tunahitaji kuzipaka wazi kwa urefu sawa
        // kwa kuangalia mipaka kutengwa, na kiboreshaji kitazalisha memcpy kwa kesi rahisi (kwa mfano T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // walinzi inahitajika b/c panic inaweza kutokea wakati wa mwamba
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // USALAMA: Vipengee halali vimeandikwa tu kwenye `this` kwa hivyo imewekewa nguvu
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}