use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Kifuniko cha kuzuia mkusanyaji kutoka kwa kumwita kiharibu "T" kiotomatiki.
/// Kifuniko hiki ni cha gharama 0.
///
/// `ManuallyDrop<T>` iko chini ya uboreshaji sawa wa mpangilio kama `T`.
/// Kama matokeo, haina *athari* kwa mawazo ambayo mkusanyaji hufanya juu ya yaliyomo.
/// Kwa mfano, kuanzisha `ManuallyDrop<&mut T>` na [`mem::zeroed`] ni tabia isiyojulikana.
/// Ikiwa unahitaji kushughulikia data isiyoanzishwa, tumia [`MaybeUninit<T>`] badala yake.
///
/// Kumbuka kuwa kupata thamani ndani ya `ManuallyDrop<T>` ni salama.
/// Hii inamaanisha kuwa `ManuallyDrop<T>` ambayo yaliyomo yametupwa hayapaswi kufunuliwa kupitia API salama ya umma.
/// Vivyo hivyo, `ManuallyDrop::drop` sio salama.
///
/// # `ManuallyDrop` na kuacha utaratibu.
///
/// Rust ina [drop order] iliyofafanuliwa vizuri ya maadili.
/// Ili kuhakikisha kuwa shamba au wenyeji wameachwa kwa mpangilio maalum, panga tena matamko kwamba utaratibu wa kushuka wazi ni sawa.
///
/// Inawezekana kutumia `ManuallyDrop` kudhibiti mpangilio wa kushuka, lakini hii inahitaji nambari isiyo salama na ni ngumu kufanya vizuri mbele ya kufungua.
///
///
/// Kwa mfano, ikiwa unataka kuhakikisha kuwa uwanja maalum umeshushwa baada ya zingine, fanya iwe uwanja wa mwisho wa muundo:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` itashushwa baada ya `children`.
///     // Rust inahakikishia kuwa uwanja umeshushwa kwa utaratibu wa tamko.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Funga thamani itatupwe mwenyewe.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Bado unaweza kufanya kazi kwa usalama kwa thamani
    /// assert_eq!(*x, "Hello");
    /// // Lakini `Drop` haitaendeshwa hapa
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Inatoa thamani kutoka kwa chombo cha `ManuallyDrop`.
    ///
    /// Hii inaruhusu thamani kushushwa tena.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Hii inashuka `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Inachukua thamani kutoka kwa kontena la `ManuallyDrop<T>` nje.
    ///
    /// Njia hii kimsingi imekusudiwa kuhamisha maadili kwa kushuka.
    /// Badala ya kutumia [`ManuallyDrop::drop`] kushuka kwa thamani, unaweza kutumia njia hii kuchukua thamani na kuitumia hata hivyo unavyotaka.
    ///
    /// Wakati wowote inapowezekana, ni vyema kutumia [`into_inner`][`ManuallyDrop::into_inner`] badala yake, ambayo inazuia kuiga yaliyomo kwenye `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Kazi hii inahamisha thamani iliyomo bila kuzuia matumizi zaidi, ikiacha hali ya kontena hili bila kubadilika.
    /// Ni jukumu lako kuhakikisha kuwa `ManuallyDrop` hii haitumiki tena.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // USALAMA: tunasoma kutoka kwa kumbukumbu, ambayo imehakikishiwa
        // kuwa halali kwa kusoma.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Kwa mkono hupunguza thamani iliyomo.Hii ni sawa kabisa na kupiga [`ptr::drop_in_place`] na kiashiria kwa thamani iliyomo.
    /// Kama hivyo, isipokuwa ikiwa dhamana iliyo na muundo uliojaa, mwangamizi ataitwa mahali bila kusonga thamani, na kwa hivyo inaweza kutumiwa kuacha data ya [pinned] salama.
    ///
    /// Ikiwa una umiliki wa thamani, unaweza kutumia [`ManuallyDrop::into_inner`] badala yake.
    ///
    /// # Safety
    ///
    /// Kazi hii inaendesha uharibifu wa thamani iliyomo.
    /// Nyingine zaidi ya mabadiliko yaliyofanywa na mwangamizi yenyewe, kumbukumbu imesalia bila kubadilika, na kwa kadiri mkusanyaji anahusika bado ana muundo kidogo ambao ni halali kwa aina ya `T`.
    ///
    ///
    /// Walakini, thamani hii ya "zombie" haipaswi kufunuliwa kwa nambari salama, na kazi hii haipaswi kuitwa zaidi ya mara moja.
    /// Kutumia thamani baada ya kudondoshwa, au kushuka kwa thamani mara kadhaa, kunaweza kusababisha Tabia Isiyojulikana (kulingana na kile `drop` inafanya).
    /// Hii kawaida huzuiwa na mfumo wa aina, lakini watumiaji wa `ManuallyDrop` lazima wazingatie dhamana hizo bila msaada kutoka kwa mkusanyaji.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // USALAMA: tunaacha dhamana iliyoonyeshwa na rejeleo linaloweza kubadilika
        // ambayo imehakikishiwa kuwa halali kwa kuandika.
        // Ni juu ya mpigaji kuhakikisha kuwa `slot` haijaangushwa tena.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}