use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Hii sio eneo la uso thabiti, lakini inasaidia kuweka `?` kwa bei rahisi kati yao, hata kama LLVM haiwezi kuifaidika kila wakati sasa.
    //
    // (Kwa kusikitisha Matokeo na Chaguo haziendani, kwa hivyo ControlFlow haiwezi kulinganisha zote mbili.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}