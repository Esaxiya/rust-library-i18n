//! Maktaba ya msaada kwa waandishi wa jumla wakati wa kufafanua macros mpya.
//!
//! Maktaba hii, iliyotolewa na usambazaji wa kawaida, hutoa aina zinazotumiwa katika mwingiliano wa ufafanuzi wa jumla wa kiakili kama vile kazi kama macros `#[proc_macro]`, sifa za jumla `#[proc_macro_attribute]` na sifa za kawaida za kupata "#[proc_macro_derive]`.
//!
//!
//! Tazama [the book] kwa zaidi.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Huamua ikiwa proc_macro imefanywa kupatikana kwa programu inayoendesha sasa.
///
/// Proc_macro crate imekusudiwa tu kutumiwa ndani ya utekelezaji wa macros ya kiutaratibu.Kazi zote katika hii crate panic ikiwa imeombwa kutoka nje ya jumla ya kiutaratibu, kama vile kutoka kwa hati ya kujenga au jaribio la kitengo au kawaida ya Rust.
///
/// Kwa kuzingatia maktaba ya Rust ambayo yameundwa kusaidia visa vyote vya matumizi makubwa na yasiyo ya jumla, `proc_macro::is_available()` hutoa njia isiyo ya kutisha ya kugundua ikiwa miundombinu inayohitajika kutumia API ya proc_macro inapatikana sasa.
/// Hurejesha kweli ikiwa imeombwa kutoka ndani ya jumla ya kiutaratibu, uwongo ikiwa imeombwa kutoka kwa binary nyingine yoyote.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Aina kuu iliyotolewa na crate hii, inayowakilisha mkondo wa dhana ya tokens, au, haswa, mlolongo wa miti ya token.
/// Aina hiyo hutoa mwingiliano wa kupindukia juu ya miti hiyo ya token na, kinyume chake, kukusanya miti kadhaa ya token kwenye kijito kimoja.
///
///
/// Hii ni pembejeo na pato la ufafanuzi wa `#[proc_macro]`, `#[proc_macro_attribute]` na `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Hitilafu imerejeshwa kutoka `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Hurejesha `TokenStream` tupu isiyo na miti ya token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Hundi ikiwa `TokenStream` hii haina kitu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Jaribio la kuvunja kamba kuwa tokens na kuchanganua hizo tokens kwenye mkondo wa token.
/// Inaweza kutofaulu kwa sababu kadhaa, kwa mfano, ikiwa kamba ina vibadilishaji visivyo na usawa au herufi ambazo hazipo katika lugha hiyo.
///
/// tokens zote kwenye mkondo uliochanganuliwa hupata spani za `Span::call_site()`.
///
/// NOTE: makosa mengine yanaweza kusababisha panics badala ya kurudisha `LexError`.Tuna haki ya kubadilisha makosa haya kuwa `LexError`s baadaye.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, daraja linatoa `to_string` tu, kutekeleza `fmt::Display` kwa msingi wake (nyuma ya uhusiano wa kawaida kati ya hizo mbili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Inachapisha mkondo wa token kama kamba ambayo inapaswa kubadilishwa bila hasara kurudi kwenye mkondo huo huo wa token (modulo spans), isipokuwa kwa uwezekano wa `TokenTree: : Group`s iliyo na wakataji wa `Delimiter::None` na fasihi hasi za nambari.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Prints token katika fomu inayofaa kwa utatuzi.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Inaunda mkondo wa token ulio na mti mmoja wa token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Inakusanya miti kadhaa ya token kwenye kijito kimoja.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operesheni ya "flattening" kwenye mito token, hukusanya miti ya token kutoka mito nyingi ya token kwenye kijito kimoja.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Tumia utekelezaji ulioboreshwa wa if/when iwezekanavyo.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Maelezo ya utekelezaji wa umma wa aina ya `TokenStream`, kama iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterator juu ya "TokenTree" ya "TokenStream".
    /// Iteration ni "shallow", kwa mfano, iterator hairudi katika vikundi vilivyopunguzwa, na inarudi vikundi vyote kama miti ya token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` inakubali tokens holela na inapanuka kuwa `TokenStream` inayoelezea pembejeo.
/// Kwa mfano, `quote!(a + b)` itatoa usemi, ambayo, ikitathminiwa, inaunda `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unukuu hufanywa na `$`, na inafanya kazi kwa kuchukua kitambulisho kimoja kinachofuata kama neno lisilotajwa.
/// Kunukuu `$` yenyewe, tumia `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Eneo la msimbo wa chanzo, pamoja na habari ya upanuzi wa jumla.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Inaunda `Diagnostic` mpya na `message` iliyopewa kwa span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Kipindi ambacho kinasuluhisha katika wavuti ya ufafanuzi wa jumla.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Kipindi cha kuomba kwa jumla ya kiutaratibu.
    /// Vitambulisho vilivyoundwa na muda huu vitasuluhishwa kana kwamba viliandikwa moja kwa moja kwenye eneo kubwa la simu (usafi wa tovuti) na nambari zingine kwenye tovuti ya simu kuu zitaweza kuzitaja pia.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Kipindi kinachowakilisha usafi wa `macro_rules`, na wakati mwingine hutatua kwenye wavuti ya ufafanuzi wa jumla (vigeuzi vya ndani, lebo, `$crate`) na wakati mwingine kwenye tovuti ya simu kubwa (kila kitu kingine).
    ///
    /// Eneo span ni kuchukuliwa kutoka wito tovuti.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Faili chanzo asili ambayo muda huu unaelekezwa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` ya tokens katika upanuzi wa jumla uliopita ambayo `self` ilitengenezwa kutoka, ikiwa ipo.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Urefu wa nambari ya chanzo asili ambayo `self` ilitengenezwa kutoka.
    /// Ikiwa `Span` hii haikutengenezwa kutoka kwa upanuzi mwingine jumla basi thamani ya kurudi ni sawa na `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Inapata line/column ya kuanzia katika faili ya chanzo kwa kipindi hiki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Inapata mwisho wa line/column katika faili chanzo kwa kipindi hiki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Inaunda span mpya inayojumuisha `self` na `other`.
    ///
    /// Hurejesha `None` ikiwa `self` na `other` zinatoka kwa faili tofauti.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Inaunda kipindi kipya na habari sawa ya line/column kama `self` lakini hiyo hutatua alama kana kwamba ilikuwa katika `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Inaunda kipindi kipya na tabia sawa ya azimio la jina kama `self` lakini na habari ya line/column ya `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Inalinganisha na spans kuona ikiwa ni sawa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Hurejesha maandishi ya chanzo nyuma ya muda.
    /// Hii huhifadhi nambari asili ya asili, pamoja na nafasi na maoni.
    /// Inarudisha tu matokeo ikiwa span inalingana na nambari halisi ya chanzo.
    ///
    /// Note: Matokeo yanayoonekana ya jumla yanapaswa kutegemea tu tokens na sio maandishi haya ya chanzo.
    ///
    /// Matokeo ya kazi hii ni juhudi bora kutumiwa kwa uchunguzi tu.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Inachapisha span katika fomu inayofaa kwa utatuzi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Jozi ya safu wima inayowakilisha mwanzo au mwisho wa `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Mstari wa faharisi-1 kwenye faili ya chanzo ambayo muda huanza na kumaliza (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Safu wima ya faharisi ya 0 (katika herufi UTF-8) katika faili ya chanzo ambayo muda huanza na kumaliza (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Faili ya chanzo ya `Span` iliyopewa.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Inapata njia ya kufikia faili ya chanzo.
    ///
    /// ### Note
    /// Ikiwa muda wa nambari uliohusishwa na `SourceFile` hii ulitengenezwa na jumla ya nje, jumla hii, hii inaweza kuwa sio njia halisi kwenye mfumo wa faili.
    /// Tumia [`is_real`] kuangalia.
    ///
    /// Pia kumbuka kuwa hata ikiwa `is_real` inarudi `true`, ikiwa `--remap-path-prefix` ilipitishwa kwenye laini ya amri, njia iliyotolewa inaweza kuwa sio halali.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Hurejesha `true` ikiwa faili hii chanzo ni faili halisi, na haizalishwi na upanuzi wa jumla.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Huu ni utapeli hadi vipindi vya intercrate vinatekelezwa na tunaweza kuwa na faili halisi za chanzo kwa spans zinazozalishwa kwenye macros za nje.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token moja au mlolongo uliopunguzwa wa miti ya token (kwa mfano, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Kijito cha token kilichozungukwa na wakataji wa mabano.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Kitambulisho.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Tabia moja ya uakifishaji ("+", `,`, `$`, n.k.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Tabia halisi (`'a'`), kamba (`"hello"`), nambari (`2.3`), n.k.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Hurejesha urefu wa mti huu, ikikabidhi njia ya `span` ya token iliyo na mkondo au mkondo uliopunguzwa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Inasanidi muda wa *token* hii pekee.
    ///
    /// Kumbuka kuwa ikiwa token ni `Group` basi njia hii haitasanidi span ya kila tokens ya ndani, hii itawasilisha tu njia ya `set_span` ya kila lahaja.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Chapa mti wa token kwa njia inayofaa kwa utatuzi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kila moja ya hizi ina jina katika aina ya muundo katika utatuzi uliotokana, kwa hivyo usijisumbue na safu ya ziada ya mwelekeo
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, daraja linatoa `to_string` tu, kutekeleza `fmt::Display` kwa msingi wake (nyuma ya uhusiano wa kawaida kati ya hizo mbili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Chapa mti wa token kama kamba ambayo inastahili kugeuzwa bila hasara kurudi ndani ya mti huo huo wa token (modulo spans), isipokuwa kwa uwezekano wa `TokenTree: : Group`s na watenganishaji wa `Delimiter::None` na fasihi hasi za nambari.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Mto uliopunguzwa wa token.
///
/// `Group` ndani ina `TokenStream` ambayo imezungukwa na `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Inaelezea jinsi mlolongo wa miti ya token imepunguzwa.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Mpunguzaji kamili, ambayo inaweza, kwa mfano, kuonekana karibu na tokens inayotoka kwa "macro variable" `$var`.
    /// Ni muhimu kuhifadhi vipaumbele vya waendeshaji katika hali kama `$var * 3` ambapo `$var` ni `1 + 2`.
    /// Wasimamizi kamili hawawezi kuishi kwa kuzunguka kwa mkondo wa token kupitia kamba.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Inaunda `Group` mpya na delimiter iliyopewa na mkondo wa token.
    ///
    /// Mjenzi huyu ataweka nafasi kwa kikundi hiki hadi `Span::call_site()`.
    /// Kubadilisha kipindi unaweza kutumia njia ya `set_span` hapa chini.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Hurejesha kikomo cha `Group` hii
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Hurejesha `TokenStream` ya tokens ambazo zimepunguzwa katika `Group` hii.
    ///
    /// Kumbuka kuwa mkondo uliorudishwa wa token haujumuishi kikomo kilichorudishwa hapo juu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Hurejesha span kwa watenganishaji wa mkondo huu wa token, inayoenea kwa `Group` nzima.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Hurejesha kipindi kinachoelekeza kwenye kikomo cha ufunguzi wa kikundi hiki.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Hurejesha kipindi kinachoelekeza kwenye kikomo cha kufunga cha kikundi hiki.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Inasanidi span kwa wapiga kura wa "Kikundi" hiki, lakini sio tokens yake ya ndani.
    ///
    /// Njia hii haitaweka ** upeo wa tokens zote za ndani zilizowekwa na kikundi hiki, lakini badala yake itaweka tu upeo wa mpangilio wa tokens katika kiwango cha `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, daraja linatoa `to_string` tu, kutekeleza `fmt::Display` kwa msingi wake (nyuma ya uhusiano wa kawaida kati ya hizo mbili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Inachapisha kikundi kama kamba ambayo inapaswa kubadilika bila hasara kurudi kwenye kundi moja (modulo spans), isipokuwa kwa uwezekano wa `TokenTree: : Group`s na `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` ni herufi moja ya uakifishaji kama `+`, `-` au `#`.
///
/// Waendeshaji wa wahusika anuwai kama `+=` wanawakilishwa kama visa viwili vya `Punct` na aina tofauti za `Spacing` zimerejeshwa.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ikiwa `Punct` inafuatwa mara moja na `Punct` nyingine au ikifuatiwa na token nyingine au nafasi nyeupe.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// km, `+` ni `Alone` katika `+ =`, `+ident` au `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// km, `+` ni `Joint` katika `+=` au `'#`.
    /// Kwa kuongeza, nukuu moja `'` inaweza kujiunga na vitambulisho kuunda maisha ya `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Inaunda `Punct` mpya kutoka kwa mhusika na nafasi.
    /// Hoja ya `ch` lazima iwe herufi sahihi ya uakifishaji inayoruhusiwa na lugha, vinginevyo kazi itakuwa panic.
    ///
    /// `Punct` iliyorudishwa itakuwa na urefu wa kawaida wa `Span::call_site()` ambao unaweza kusanidiwa zaidi na njia ya `set_span` hapa chini.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Hurejesha thamani ya herufi hii ya uakifishaji kama `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Hurejesha nafasi ya herufi hii ya uakifishaji, ikionyesha ikiwa inafuatwa mara moja na `Punct` nyingine kwenye mkondo wa token, kwa hivyo zinaweza kuunganishwa kuwa opereta wa wahusika anuwai (`Joint`), au inafuatwa na token nyingine au nafasi nyeupe (`Alone`) kwa hivyo mwendeshaji hakika ilimalizika.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Hurejesha muda wa herufi hii ya uakifishaji.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Sanidi urefu wa herufi hii ya uakifishaji.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, daraja linatoa `to_string` tu, kutekeleza `fmt::Display` kwa msingi wake (nyuma ya uhusiano wa kawaida kati ya hizo mbili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Inachapisha herufi za uakifishaji kama kamba ambayo inapaswa kubadilishwa bila hasara kurudi katika herufi ile ile.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Kitambulisho (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Inaunda `Ident` mpya na `string` iliyopewa pamoja na `span` maalum.
    /// Hoja ya `string` lazima iwe kitambulisho halali kinachoruhusiwa na lugha (pamoja na maneno, mfano `self` au `fn`).Vinginevyo, kazi itakuwa panic.
    ///
    /// Kumbuka kuwa `span`, kwa sasa iko katika rustc, inasanidi habari ya usafi kwa kitambulisho hiki.
    ///
    /// Kufikia wakati huu `Span::call_site()` inajiweka wazi kwa usafi wa "call-site" ikimaanisha kuwa vitambulisho vilivyoundwa na muda huu vitasuluhishwa kana kwamba viliandikwa moja kwa moja kwenye eneo la simu kuu, na nambari nyingine kwenye tovuti ya simu kuu itaweza kurejelea wao pia.
    ///
    ///
    /// Vipindi vya baadaye kama `Span::def_site()` vitaruhusu kujiingiza kwenye usafi wa "definition-site" ikimaanisha kuwa vitambulisho vilivyoundwa na muda huu vitasuluhishwa katika eneo la ufafanuzi wa jumla na nambari nyingine kwenye tovuti ya simu kuu haitaweza kuzitaja.
    ///
    /// Kwa sababu ya umuhimu wa sasa wa mjenzi huyu, tofauti na tokens zingine, inahitaji `Span` kutajwa kwenye ujenzi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sawa na `Ident::new`, lakini inaunda kitambulisho ghafi (`r#ident`).
    /// Hoja ya `string` iwe kitambulisho halali kinachoruhusiwa na lugha (pamoja na maneno, mfano `fn`).
    /// Maneno muhimu ambayo yanatumika katika sehemu za njia (kwa mfano
    /// `self`, `super`) haitumiki, na itasababisha panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Hurejesha muda wa `Ident` hii, ikijumuisha kamba nzima iliyorudishwa na [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Inasanidi muda wa `Ident` hii, ikiwezekana ikibadilisha muktadha wake wa usafi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, daraja linatoa `to_string` tu, kutekeleza `fmt::Display` kwa msingi wake (nyuma ya uhusiano wa kawaida kati ya hizo mbili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Chapa kitambulisho kama kamba ambayo inapaswa kubadilishwa bila hasara kurudi kwenye kitambulisho sawa.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Kamba halisi (`"hello"`), kamba ya baiti (`b"hello"`), herufi (`'a'`), herufi (`b'a'`), nambari kamili au nambari ya kuelea iliyo na au bila kiambishi (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Fasihi za Boolean kama `true` na `false` sio za hapa, ni `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Inaunda nambari mpya kamili ya nambari na thamani maalum.
        ///
        /// Kazi hii itaunda nambari kama `1u32` ambapo nambari kamili iliyoainishwa ni sehemu ya kwanza ya token na ujumuishaji pia umetoshelezwa mwishoni.
        /// Fasihi zilizoundwa kutoka kwa nambari hasi haziwezi kuishi safari za kuzunguka kupitia `TokenStream` au kamba na zinaweza kuvunjika katika tokens mbili (`-` na halisi halisi).
        ///
        ///
        /// Fasihi zilizoundwa kupitia njia hii zina urefu wa `Span::call_site()` kwa chaguo-msingi, ambayo inaweza kusanidiwa na njia ya `set_span` hapa chini.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Inaunda nambari mpya isiyo na viambatanisho halisi na thamani maalum.
        ///
        /// Kazi hii itaunda nambari kama `1` ambapo nambari kamili imeainishwa ni sehemu ya kwanza ya token.
        /// Hakuna kiambishi kilichoainishwa kwenye token hii, ikimaanisha kuwa dua kama `Literal::i8_unsuffixed(1)` ni sawa na `Literal::u32_unsuffixed(1)`.
        /// Fasihi zilizoundwa kutoka kwa nambari hasi haziwezi kuishi kwa njia ya mlolongo kupitia `TokenStream` au kamba na zinaweza kuvunjika kwa tokens mbili (`-` na halisi halisi).
        ///
        ///
        /// Fasihi zilizoundwa kupitia njia hii zina urefu wa `Span::call_site()` kwa chaguo-msingi, ambayo inaweza kusanidiwa na njia ya `set_span` hapa chini.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Inaunda kipengee kipya kisicho na viambatanisho halisi.
    ///
    /// Mjenzi huyu ni sawa na wale kama `Literal::i8_unsuffixed` ambapo thamani ya kuelea hutolewa moja kwa moja kwenye token lakini hakuna kiambishi kinachotumiwa, kwa hivyo inaweza kuzingatiwa kuwa `f64` baadaye katika mkusanyaji.
    ///
    /// Fasihi zilizoundwa kutoka kwa nambari hasi haziwezi kuishi kwa njia ya mlolongo kupitia `TokenStream` au kamba na zinaweza kuvunjika kwa tokens mbili (`-` na halisi halisi).
    ///
    /// # Panics
    ///
    /// Kazi hii inahitaji kwamba kuelea maalum kumalizika, kwa mfano ikiwa ni infinity au NaN kazi hii itakuwa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Inaunda kipengee kipya cha kuelea-halisi halisi.
    ///
    /// Mjenzi huyu ataunda halisi kama `1.0f32` ambapo thamani iliyoainishwa ni sehemu iliyotangulia ya token na `f32` ni kiambishi cha token.
    /// token hii itahesabiwa kuwa `f32` katika mkusanyaji.
    /// Fasihi zilizoundwa kutoka kwa nambari hasi haziwezi kuishi kwa njia ya mlolongo kupitia `TokenStream` au kamba na zinaweza kuvunjika kwa tokens mbili (`-` na halisi halisi).
    ///
    ///
    /// # Panics
    ///
    /// Kazi hii inahitaji kwamba kuelea maalum kumalizika, kwa mfano ikiwa ni infinity au NaN kazi hii itakuwa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Inaunda kipengee kipya kisicho na viambatanisho halisi.
    ///
    /// Mjenzi huyu ni sawa na wale kama `Literal::i8_unsuffixed` ambapo thamani ya kuelea hutolewa moja kwa moja kwenye token lakini hakuna kiambishi kinachotumiwa, kwa hivyo inaweza kuzingatiwa kuwa `f64` baadaye katika mkusanyaji.
    ///
    /// Fasihi zilizoundwa kutoka kwa nambari hasi haziwezi kuishi kwa njia ya mlolongo kupitia `TokenStream` au kamba na zinaweza kuvunjika kwa tokens mbili (`-` na halisi halisi).
    ///
    /// # Panics
    ///
    /// Kazi hii inahitaji kwamba kuelea maalum kumalizika, kwa mfano ikiwa ni infinity au NaN kazi hii itakuwa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Inaunda kipengee kipya cha kuelea-halisi halisi.
    ///
    /// Mjenzi huyu ataunda halisi kama `1.0f64` ambapo thamani iliyoainishwa ni sehemu iliyotangulia ya token na `f64` ni kiambishi cha token.
    /// token hii itahesabiwa kuwa `f64` katika mkusanyaji.
    /// Fasihi zilizoundwa kutoka kwa nambari hasi haziwezi kuishi kwa njia ya mlolongo kupitia `TokenStream` au kamba na zinaweza kuvunjika kwa tokens mbili (`-` na halisi halisi).
    ///
    ///
    /// # Panics
    ///
    /// Kazi hii inahitaji kwamba kuelea maalum kumalizika, kwa mfano ikiwa ni infinity au NaN kazi hii itakuwa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Kamba halisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Tabia halisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Kamba ya baiti halisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Hurejesha span inayojumuisha halisi hii.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Inasanidi span inayohusishwa na hii halisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Hurejesha `Span` ambayo ni sehemu ndogo ya `self.span()` iliyo na baiti chanzo tu katika fungu la `range`.
    /// Hurejesha `None` ikiwa kipindi kilichopunguzwa kiko nje ya mipaka ya `self`.
    ///
    // FIXME(SergioBenitez): angalia kuwa safu ya baiti inaanza na kuishia kwenye mpaka wa UTF-8 wa chanzo.
    // vinginevyo, kuna uwezekano kwamba panic itatokea mahali pengine wakati maandishi ya asili yamechapishwa.
    // FIXME(SergioBenitez): hakuna njia ya mtumiaji kujua ni nini `self.span()` inachora ramani, kwa hivyo njia hii inaweza kuitwa kwa upofu tu.
    // Kwa mfano, `to_string()` kwa tabia 'c' inarudi "'\u{63}'";hakuna njia ya mtumiaji kujua ikiwa maandishi ya asili yalikuwa 'c' au ikiwa ni '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) kitu sawa na `Option::cloned`, lakini kwa `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, daraja linatoa `to_string` tu, kutekeleza `fmt::Display` kwa msingi wake (nyuma ya uhusiano wa kawaida kati ya hizo mbili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Chapa halisi kama kamba ambayo inapaswa kubadilishwa bila hasara kurudi kwenye moja kwa moja (isipokuwa kwa kuzunguka kwa fasihi za kuelea).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ufikiaji uliofuatiliwa wa anuwai za mazingira.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Pata mabadiliko ya mazingira na uongeze ili ujenge maelezo ya utegemezi.
    /// Jenga mfumo unaotumia mkusanyaji utajua kuwa ubadilishaji huo ulipatikana wakati wa mkusanyiko, na utaweza kurudisha ujenzi wakati thamani ya mabadiliko hayo hubadilika.
    ///
    /// Mbali na ufuatiliaji wa utegemezi kazi hii inapaswa kuwa sawa na `env::var` kutoka kwa maktaba ya kawaida, isipokuwa kwamba hoja lazima iwe UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}