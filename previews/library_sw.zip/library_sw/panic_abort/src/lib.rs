//! Utekelezaji wa Rust panics kupitia mchakato wa kutoa mimba
//!
//! Ikilinganishwa na utekelezaji kupitia kufungua, hii crate ni * rahisi sana!Hiyo inasemwa, sio rahisi sana, lakini hapa inakwenda!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" malipo na shim kwa mimba inayofaa kwenye jukwaa husika.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // piga simu std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Kwenye Windows, tumia utaratibu maalum wa processor __fastfail.Katika Windows 8 na baadaye, hii itasitisha mchakato mara moja bila kuendesha washughulikiaji wowote wa mchakato.
            // Katika matoleo ya awali ya Windows, mlolongo huu wa maagizo utachukuliwa kama ukiukaji wa ufikiaji, kukomesha mchakato lakini bila kupita kwa washughulikiaji wote wa ubaguzi.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: huu ni utekelezaji sawa na wa libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Hii ... ni ya kushangaza kidogo.Tl; dr;ni kwamba hii inahitajika kuunganishwa kwa usahihi, maelezo marefu ni hapa chini.
//
// Hivi sasa binaries za libcore/libstd ambazo tunasafirisha zote zimekusanywa na `-C panic=unwind`.Hii imefanywa ili kuhakikisha kuwa binaries zinaambatana kabisa na hali nyingi iwezekanavyo.
// Mkusanyaji, hata hivyo, inahitaji "personality function" kwa kazi zote zilizojumuishwa na `-C panic=unwind`.Kazi hii ya utu imewekwa alama kwa alama ya `rust_eh_personality` na inafafanuliwa na kipengee cha `eh_personality` lang.
//
// So...
// kwa nini usifafanue tu kitu cha lang hapa?Swali zuri!Njia ambayo wakati wa kukimbia wa panic umeunganishwa ndani ni kweli hila kidogo kwa kuwa wao ni "sort of" katika duka la mkusanyaji wa crate, lakini inaunganishwa tu ikiwa nyingine haijaunganishwa kweli kweli.
//
// Hii inaishia kumaanisha kuwa crate zote na panic_unwind crate zinaweza kuonekana kwenye duka la mkusanyaji crate, na ikiwa zote zinafafanua kipengee cha `eh_personality` lang basi hiyo itapata hitilafu.
//
// Kushughulikia hili mkusanyaji anahitaji tu `eh_personality` inafafanuliwa ikiwa wakati wa kukimbia wa panic unaounganishwa ni wakati wa kukimbia, na vinginevyo haihitajiki kufafanuliwa (sawa hivyo).
// Katika kesi hii, hata hivyo, maktaba hii inafafanua tu ishara hii kwa hivyo kuna angalau utu mahali.
//
// Kwa kweli ishara hii imeelezewa kuwa na waya hadi libcore/libstd binaries, lakini haipaswi kuitwa kamwe kwani hatuunganishi wakati wa kukimbia kabisa.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Kwenye x86_64-pc-windows-gnu tunatumia kazi yetu ya kibinafsi ambayo inahitaji kurudisha `ExceptionContinueSearch` tunapopita muafaka wetu wote.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Sawa na hapo juu, hii inalingana na kipengee cha `eh_catch_typeinfo` lang ambacho kinatumika tu kwenye Emscripten sasa.
    //
    // Kwa kuwa panics hazizalishi ubaguzi na tofauti za kigeni kwa sasa ni UB na -C panic=kutoa mimba (ingawa hii inaweza kubadilika), simu zozote za catch_unwind hazitatumia aina hii ya habari.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Hizi mbili huitwa na vitu vyetu vya kuanza kwenye i686-pc-windows-gnu, lakini hazihitaji kufanya chochote kwa hivyo miili ni nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}