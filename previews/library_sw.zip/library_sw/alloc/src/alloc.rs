//! Ugawaji wa kumbukumbu APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Hizi ndio alama za uchawi kumwita mtengaji wa ulimwengu.rustc inawazalisha kupiga `__rg_alloc` nk.
    // ikiwa kuna sifa ya `#[global_allocator]` (nambari inayopanua sifa hiyo hutoa kazi hizo), au kuita utekelezaji wa msingi katika libstd (`__rdl_alloc` nk.
    //
    // katika `library/std/src/alloc.rs`) vinginevyo.
    // rustc fork ya LLVM pia ni kesi maalum majina haya ya kazi kuweza kuyaboresha kama `malloc`, `realloc`, na `free`, mtawaliwa.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Mtoaji kumbukumbu wa ulimwengu.
///
/// Aina hii hutumia [`Allocator`] trait kwa kupeleka simu kwa mgawaji aliyesajiliwa na sifa ya `#[global_allocator]` ikiwa kuna moja, au chaguo-msingi ya `std` crate.
///
///
/// Note: wakati aina hii haina utulivu, utendaji unaotoa unaweza kupatikana kupitia [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Tenga kumbukumbu na mtengaji wa ulimwengu.
///
/// Kazi hii inasonga mbele kwa njia ya [`GlobalAlloc::alloc`] ya mtengaji iliyosajiliwa na sifa ya `#[global_allocator]` ikiwa kuna moja, au chaguo-msingi ya `std` crate.
///
///
/// Kazi hii inatarajiwa kupunguzwa kwa kupendelea njia ya `alloc` ya aina ya [`Global`] wakati yeye na [`Allocator`] trait zitakuwa sawa.
///
/// # Safety
///
/// Tazama [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Tenga kumbukumbu na mtengaji wa ulimwengu.
///
/// Kazi hii inasonga mbele kwa njia ya [`GlobalAlloc::dealloc`] ya mtengaji iliyosajiliwa na sifa ya `#[global_allocator]` ikiwa kuna moja, au chaguo-msingi ya `std` crate.
///
///
/// Kazi hii inatarajiwa kupunguzwa kwa kupendelea njia ya `dealloc` ya aina ya [`Global`] wakati yeye na [`Allocator`] trait zitakuwa sawa.
///
/// # Safety
///
/// Tazama [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Tenga kumbukumbu na mtengaji wa ulimwengu.
///
/// Kazi hii inasonga mbele kwa njia ya [`GlobalAlloc::realloc`] ya mtengaji iliyosajiliwa na sifa ya `#[global_allocator]` ikiwa kuna moja, au chaguo-msingi ya `std` crate.
///
///
/// Kazi hii inatarajiwa kupunguzwa kwa kupendelea njia ya `realloc` ya aina ya [`Global`] wakati yeye na [`Allocator`] trait zitakuwa sawa.
///
/// # Safety
///
/// Tazama [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Tenga kumbukumbu iliyotanguliwa na sifuri na mtengaji wa ulimwengu.
///
/// Kazi hii inasonga mbele kwa njia ya [`GlobalAlloc::alloc_zeroed`] ya mtengaji iliyosajiliwa na sifa ya `#[global_allocator]` ikiwa kuna moja, au chaguo-msingi ya `std` crate.
///
///
/// Kazi hii inatarajiwa kupunguzwa kwa kupendelea njia ya `alloc_zeroed` ya aina ya [`Global`] wakati yeye na [`Allocator`] trait zitakuwa sawa.
///
/// # Safety
///
/// Tazama [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // USALAMA: `layout` haina ukubwa wa sifuri,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // USALAMA: Sawa na `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // USALAMA: `new_size` sio sifuri kwani `old_size` ni kubwa kuliko au sawa na `new_size`
            // inavyotakiwa na hali ya usalama.Masharti mengine yanapaswa kuzingatiwa na mpigaji simu
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` labda huangalia `new_size >= old_layout.size()` au kitu kama hicho.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // USALAMA: kwa sababu `new_layout.size()` lazima iwe kubwa kuliko au sawa na `old_size`,
            // mgao wa kumbukumbu ya zamani na mpya ni halali kwa kusoma na huandika kwa baiti za `old_size`.
            // Pia, kwa sababu mgao wa zamani ulikuwa haujashughulikiwa, hauwezi kuingiliana na `new_ptr`.
            // Kwa hivyo, simu kwa `copy_nonoverlapping` ni salama.
            // Mkataba wa usalama wa `dealloc` lazima uzingatiwe na mpiga simu.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // USALAMA: `layout` haina ukubwa wa sifuri,
            // masharti mengine lazima yazingatiwe na anayepiga simu
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // USALAMA: masharti yote yanapaswa kuzingatiwa na anayepiga simu
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // USALAMA: masharti yote yanapaswa kuzingatiwa na anayepiga simu
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // USALAMA: masharti lazima yazingatiwe na anayepiga simu
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // USALAMA: `new_size` sio sifuri.Masharti mengine yanapaswa kuzingatiwa na mpigaji simu
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` labda huangalia `new_size <= old_layout.size()` au kitu kama hicho.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // USALAMA: kwa sababu `new_size` lazima iwe ndogo kuliko au sawa na `old_layout.size()`,
            // mgao wa kumbukumbu ya zamani na mpya ni halali kwa kusoma na huandika kwa baiti za `new_size`.
            // Pia, kwa sababu mgao wa zamani ulikuwa haujashughulikiwa, hauwezi kuingiliana na `new_ptr`.
            // Kwa hivyo, simu kwa `copy_nonoverlapping` ni salama.
            // Mkataba wa usalama wa `dealloc` lazima uzingatiwe na mpiga simu.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Mtengaji wa viashiria vya kipekee.
// Kazi hii haipaswi kupumzika.Ikiwa inafanya hivyo, MIR codegen itashindwa.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Saini hii lazima iwe sawa na `Box`, vinginevyo ICE itatokea.
// Wakati parameta ya ziada kwa `Box` imeongezwa (kama `A: Allocator`), hii inapaswa kuongezwa hapa pia.
// Kwa mfano ikiwa `Box` imebadilishwa kuwa `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, kazi hii lazima ibadilishwe kuwa `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` pia.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Kidhibiti cha kosa la ugawaji

extern "Rust" {
    // Hii ndio ishara ya uchawi kumwita mshughulikiaji wa makosa ya ugawaji wa ulimwengu.
    // rustc inazalisha kupiga `__rg_oom` ikiwa kuna `#[alloc_error_handler]`, au kuita utekelezaji wa msingi chini ya (`__rdl_oom`) vinginevyo.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Ondoa kosa la ugawaji wa kumbukumbu au kutofaulu.
///
/// Wapigaji simu wa mgao wa kumbukumbu wanaotaka kutoa hesabu kujibu hitilafu ya ugawaji wanahimizwa kuiita kazi hii, badala ya kuomba `panic!` moja kwa moja au sawa.
///
///
/// Tabia ya msingi ya kazi hii ni kuchapisha ujumbe kwa hitilafu ya kawaida na kutoa mchakato.
/// Inaweza kubadilishwa na [`set_alloc_error_hook`] na [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Kwa mtihani wa kugawa `std::alloc::handle_alloc_error` inaweza kutumika moja kwa moja.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // inayoitwa kupitia `__rust_alloc_error_handler` iliyozalishwa

    // ikiwa hakuna `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ikiwa kuna `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Utaalam clones katika kumbukumbu iliyotengwa awali, isiyo ya awali.
/// Inatumiwa na `Box::clone` na `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Baada ya kutenga *kwanza* kunaweza kuruhusu optimizer kuunda dhamana iliyowekwa mahali, ikiruka ya ndani na hoja.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Tunaweza kunakili kila mahali mahali, bila kuhusisha thamani ya kawaida.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}