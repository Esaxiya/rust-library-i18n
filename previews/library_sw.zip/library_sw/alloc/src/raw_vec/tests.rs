use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Kuandika jaribio la ujumuishaji kati ya watengaji wa tatu na `RawVec` ni gumu kidogo kwa sababu API ya `RawVec` haionyeshi njia mbaya za ugawaji, kwa hivyo hatuwezi kuangalia ni nini kinatokea wakati mtoaji amechoka (zaidi ya kugundua panic).
    //
    //
    // Badala yake, hii inakagua tu kuwa njia za `RawVec` hazipiti kupitia Allocator API wakati inabaki kuhifadhi.
    //
    //
    //
    //
    //

    // Mgawaji bubu anayetumia kiasi fulani cha mafuta kabla ya majaribio ya ugawaji kuanza kutofaulu.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (husababisha uhamishaji, kwa hivyo kutumia vitengo vya mafuta 50 + 150=200)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Kwanza, `reserve` hutenga kama `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 ni zaidi ya mara mbili ya 7, kwa hivyo `reserve` inapaswa kufanya kazi kama `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ni chini ya nusu ya 12, kwa hivyo `reserve` lazima ikue kwa kasi.
        // Wakati wa kuandika kipimo hiki cha ukuaji ni 2, kwa hivyo uwezo mpya ni 24, hata hivyo, sababu ya ukuaji wa 1.5 ni sawa pia.
        //
        // Kwa hivyo `>= 18` inadai.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}