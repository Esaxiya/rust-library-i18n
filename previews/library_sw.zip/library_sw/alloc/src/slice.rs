//! Mtazamo wa ukubwa wenye nguvu katika mlolongo unaofanana, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Vipande ni mtazamo kwenye kizuizi cha kumbukumbu inayowakilishwa kama pointer na urefu.
//!
//! ```
//! // kukata Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // kulazimisha safu kwa kipande
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Vipande vinaweza kubadilika au kushirikiwa.
//! Aina ya kipande kilichoshirikiwa ni `&[T]`, wakati aina ya kipande kinachoweza kubadilika ni `&mut [T]`, ambapo `T` inawakilisha aina ya kipengee.
//! Kwa mfano, unaweza kubadilisha kumbukumbu ya kipande ambacho kipande kinachoweza kubadilika kinaelekeza kwa:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hapa kuna vitu kadhaa ambavyo moduli hii ina:
//!
//! ## Structs
//!
//! Kuna structs kadhaa ambazo ni muhimu kwa vipande, kama vile [`Iter`], ambayo inawakilisha iteration juu ya kipande.
//!
//! ## Utekelezaji wa Trait
//!
//! Kuna utekelezaji kadhaa wa traits ya kawaida kwa vipande.Mifano zingine ni pamoja na:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], kwa vipande ambavyo aina ya kipengee ni [`Eq`] au [`Ord`].
//! * [`Hash`] - kwa vipande ambavyo aina ya elementi ni [`Hash`].
//!
//! ## Iteration
//!
//! Vipande vinatekeleza `IntoIterator`.Msimamizi hutoa marejeleo ya vitu vya kipande.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Kipande kinachoweza kubadilika hutoa marejeleo yanayoweza kubadilika kwa vitu:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Iterator hii hutoa marejeleo yanayoweza kubadilika kwa vitu vya kipande, kwa hivyo wakati aina ya kipande ni `i32`, aina ya kipengee cha iterator ni `&mut i32`.
//!
//!
//! * [`.iter`] na [`.iter_mut`] ndio njia wazi za kurudisha iterators chaguomsingi.
//! * Njia zingine ambazo zinarudisha iterators ni [`.split`], [`.splitn`], [`.chunks`], [`.windows`] na zaidi.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Matumizi mengi katika moduli hii hutumiwa tu katika usanidi wa jaribio.
// Ni safi kuzima tu onyo lisilotumika_kuagiza kuliko kuzirekebisha.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Njia za msingi za ugani wa kipande
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) inahitajika kwa utekelezaji wa jumla ya `vec!` wakati wa kujaribu NB, angalia moduli ya `hack` katika faili hii kwa maelezo zaidi.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) inahitajika kwa utekelezaji wa `Vec::clone` wakati wa kujaribu NB, angalia moduli ya `hack` katika faili hii kwa maelezo zaidi.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Na cfg(test) `impl [T]` haipatikani, kazi hizi tatu ni njia ambazo ziko katika `impl [T]` lakini sio `core::slice::SliceExt`, tunahitaji kusambaza kazi hizi kwa jaribio la `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Hatupaswi kuongeza sifa ya ndani kwa hii kwani hii hutumiwa katika jumla ya `vec!` na inasababisha kurudi nyuma kwa manukato.
    // Tazama #71204 kwa majadiliano na matokeo ya manukato.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Vitu viliwekwa alama kwenye kitanzi hapa chini
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ni muhimu kwa LLVM kuondoa ukaguzi wa mipaka na ina codegen bora kuliko zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ilitengwa na kuanzishwa hapo juu kwa angalau urefu huu.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // zilizotengwa hapo juu na uwezo wa `s`, na uanzishe kwa `s.len()` katika ptr::copy_to_non_overlapping hapa chini.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Aina ya kipande.
    ///
    /// Aina hii ni thabiti (yaani, haipangi upya vitu sawa) na *O*(*n*\*log(* n*)) kesi mbaya.
    ///
    /// Inapofaa, upangaji thabiti unapendelea kwa sababu kwa ujumla ni haraka kuliko upangaji thabiti na haitoi kumbukumbu ya msaidizi.
    /// Tazama [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa ni adaptive, iterative unganisha aina iliyoongozwa na [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Imeundwa kuwa ya haraka sana katika hali ambapo kipande kinakaribia kupangwa, au ina safu mbili au zaidi zilizopangwa zilizoangaziwa moja baada ya nyingine.
    ///
    ///
    /// Pia, hutenga uhifadhi wa muda wa nusu saizi ya `self`, lakini kwa vipande vifupi aina ya kuingiza isiyogawi hutumiwa badala yake.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Aina ya kipande na kazi ya kulinganisha.
    ///
    /// Aina hii ni thabiti (yaani, haipangi upya vitu sawa) na *O*(*n*\*log(* n*)) kesi mbaya.
    ///
    /// Kazi ya kulinganisha lazima ifafanue kuagiza kwa jumla kwa vitu kwenye kipande.Ikiwa kuagiza sio jumla, mpangilio wa vitu haujabainishwa.
    /// Agizo ni agizo la jumla ikiwa ni (kwa wote `a`, `b` na `c`):
    ///
    /// * jumla na antisymmetric: moja ya `a < b`, `a == b` au `a > b` ni kweli, na
    /// * transitive, `a < b` na `b < c` inamaanisha `a < c`.Vile vile lazima viwe na `==` na `>`.
    ///
    /// Kwa mfano, wakati [`f64`] haitekelezi [`Ord`] kwa sababu `NaN != NaN`, tunaweza kutumia `partial_cmp` kama kazi yetu ya aina wakati tunajua kipande hakina `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Inapofaa, upangaji thabiti unapendelea kwa sababu kwa ujumla ni haraka kuliko upangaji thabiti na haitoi kumbukumbu ya msaidizi.
    /// Tazama [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa ni adaptive, iterative unganisha aina iliyoongozwa na [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Imeundwa kuwa ya haraka sana katika hali ambapo kipande kinakaribia kupangwa, au ina safu mbili au zaidi zilizopangwa zilizoangaziwa moja baada ya nyingine.
    ///
    /// Pia, hutenga uhifadhi wa muda wa nusu saizi ya `self`, lakini kwa vipande vifupi aina ya kuingiza isiyogawi hutumiwa badala yake.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // kuchagua nyuma
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Aina ya kipande na kazi muhimu ya uchimbaji.
    ///
    /// Aina hii ni thabiti (yaani, haipangi upya vitu sawa) na *O*(*m*\* * n *\* log(*n*)) kesi mbaya, ambapo kazi muhimu ni *O*(*m*).
    ///
    /// Kwa kazi muhimu za gharama kubwa (kwa mfano
    /// kazi ambazo sio ufikiaji rahisi wa mali au shughuli za kimsingi), [`sort_by_cached_key`](slice::sort_by_cached_key) inaweza kuwa haraka sana, kwani hailipi funguo za vitu.
    ///
    ///
    /// Inapofaa, upangaji thabiti unapendelea kwa sababu kwa ujumla ni haraka kuliko upangaji thabiti na haitoi kumbukumbu ya msaidizi.
    /// Tazama [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa ni adaptive, iterative unganisha aina iliyoongozwa na [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Imeundwa kuwa ya haraka sana katika hali ambapo kipande kinakaribia kupangwa, au ina safu mbili au zaidi zilizopangwa zilizoangaziwa moja baada ya nyingine.
    ///
    /// Pia, hutenga uhifadhi wa muda wa nusu saizi ya `self`, lakini kwa vipande vifupi aina ya kuingiza isiyogawi hutumiwa badala yake.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Aina ya kipande na kazi muhimu ya uchimbaji.
    ///
    /// Wakati wa kuchagua, kazi muhimu inaitwa mara moja tu kwa kila kipengee.
    ///
    /// Aina hii ni thabiti (yaani, haipangi upya vitu sawa) na *O*(*m*\* * n *+* n *\* log(*n*)) kesi mbaya, ambapo kazi muhimu ni *O*(*m*) .
    ///
    /// Kwa kazi muhimu muhimu (kwa mfano, kazi ambazo ni ufikiaji wa mali au shughuli za kimsingi), [`sort_by_key`](slice::sort_by_key) inaweza kuwa haraka zaidi.
    ///
    /// # Utekelezaji wa sasa
    ///
    /// Algorithm ya sasa inategemea [pattern-defeating quicksort][pdqsort] na Orson Peters, ambayo inachanganya kesi ya wastani ya haraka ya bahati nasibu na kesi mbaya zaidi ya heapsort, wakati inafikia wakati wa laini kwenye vipande na mifumo fulani.
    /// Inatumia ujanibishaji fulani kuzuia kesi zinazoharibika, lakini kwa seed iliyowekwa ili kutoa tabia ya kuamua kila wakati.
    ///
    /// Katika hali mbaya zaidi, hesabu hiyo hutenga uhifadhi wa muda katika `Vec<(K, usize)>` urefu wa kipande.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Msaidizi wa jumla wa kuorodhesha vector yetu na aina ndogo zaidi, ili kupunguza mgawanyo.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Vipengele vya `indices` ni vya kipekee, kwani vimeorodheshwa, kwa hivyo aina yoyote itakuwa sawa na kipande cha asili.
                // Tunatumia `sort_unstable` hapa kwa sababu inahitaji ugawaji mdogo wa kumbukumbu.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Nakala `self` kuwa `Vec` mpya.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hapa, `s` na `x` zinaweza kubadilishwa kwa kujitegemea.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Nakili `self` kuwa `Vec` mpya na mtengaji.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hapa, `s` na `x` zinaweza kubadilishwa kwa kujitegemea.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, angalia moduli ya `hack` katika faili hii kwa maelezo zaidi.
        hack::to_vec(self, alloc)
    }

    /// Inabadilisha `self` kuwa vector bila clones au mgao.
    ///
    /// vector inayosababishwa inaweza kubadilishwa kuwa sanduku kupitia `Vec<T>Njia ya `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` haiwezi kutumika tena kwa sababu imebadilishwa kuwa `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, angalia moduli ya `hack` katika faili hii kwa maelezo zaidi.
        hack::into_vec(self)
    }

    /// Inaunda vector kwa kurudia kipande mara `n`.
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa uwezo utafurika.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic wakati wa kufurika:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ikiwa `n` ni kubwa kuliko sifuri, inaweza kugawanywa kama `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` ni nambari inayowakilishwa na kipande cha kushoto cha '1' cha `n`, na `rem` ni sehemu iliyobaki ya `n`.
        //
        //

        // Kutumia `Vec` kufikia `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` marudio hufanywa kwa mara mbili ya `buf` `expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ikiwa `m > 0`, zimebaki bits hadi kushoto '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ina uwezo wa `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) marudio hufanywa kwa kunakili marudio ya kwanza ya `rem` kutoka `buf` yenyewe.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Hii haiingiliani tangu `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` sawa na `buf.capacity()` ("= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens kipande cha `T` kwa thamani moja `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens kipande cha `T` kuwa nambari moja `Self::Output`, ukiweka kitenganishi kati ya kila moja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens kipande cha `T` kuwa nambari moja `Self::Output`, ukiweka kitenganishi kati ya kila moja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Hurejesha vector iliyo na nakala ya kipande hiki ambapo kila kaa imewekwa ramani kwa kesi yake kuu ya ASCII.
    ///
    ///
    /// Barua za ASCII 'a' hadi 'z' zimepangwa kwa 'A' hadi 'Z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kuongeza thamani mahali, tumia [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Hurejesha vector iliyo na nakala ya kipande hiki ambapo kila kaa imewekwa ramani kwa kesi yake ndogo ya ASCII.
    ///
    ///
    /// Barua za ASCII 'A' hadi 'Z' zimepangwa kwa 'a' hadi 'z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kupunguza thamani mahali, tumia [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ugani traits kwa vipande juu ya aina maalum za data
////////////////////////////////////////////////////////////////////////////////

/// Msaidizi trait kwa [`[T]: : concat`](kipande::concat).
///
/// Note: parameter ya aina ya `Item` haitumiki katika trait hii, lakini inaruhusu impls kuwa generic zaidi.
/// Bila hiyo, tunapata kosa hili:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Hii ni kwa sababu kunaweza kuwa na aina za `V` zilizo na vipengee vingi vya `Borrow<[_]>`, kama kwamba aina nyingi za `T` zingetumika:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Aina inayosababishwa baada ya concatenation
    type Output;

    /// Utekelezaji wa [`[T]: : concat`](kipande::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Msaidizi trait kwa [`[T]: : jiunge`](kipande::jiunge)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Aina inayosababishwa baada ya concatenation
    type Output;

    /// Utekelezaji wa [`[T]: : jiunga`](kipande::jiunge)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Utekelezaji wa kawaida wa trait kwa vipande
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // toa kitu chochote kwenye shabaha ambacho hakitaandikwa tena
        target.truncate(self.len());

        // target.len <= self.len kwa sababu ya truncate hapo juu, kwa hivyo vipande hapa viko katika mipaka kila wakati.
        //
        let (init, tail) = self.split_at(target.len());

        // tumia tena maadili yaliyomo allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Inaingiza `v[0]` katika mlolongo wa awali uliopangwa `v[1..]` ili `v[..]` nzima iweze kupangwa.
///
/// Hii ndio sehemu kuu ya aina ya kuingizwa.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Kuna njia tatu za kutekeleza kuingizwa hapa:
            //
            // 1. Badilisha vitu vya karibu hadi ile ya kwanza ifikie mwisho wake.
            //    Walakini, kwa njia hii tunakili data karibu zaidi ya inahitajika.
            //    Ikiwa vitu ni miundo mikubwa (ina gharama kubwa kunakili), njia hii itakuwa polepole.
            //
            // 2. Iterate mpaka mahali pazuri kwa kipengee cha kwanza kinapatikana.
            // Kisha songa vitu vilivyofanikiwa ili uvitengee nafasi na mwishowe uweke ndani ya shimo lililobaki.
            // Hii ni njia nzuri.
            //
            // 3. Nakili kipengee cha kwanza katika ubadilishaji wa muda.Iterate hadi mahali sahihi pa kupatikana.
            // Tunapoendelea, nakili kila kitu kilichopitishwa kwenye nafasi inayotangulia.
            // Mwishowe, nakili data kutoka kwa ubadilishaji wa muda kwenye shimo lililobaki.
            // Njia hii ni nzuri sana.
            // Viashiria vilionyesha utendaji bora kidogo kuliko njia ya 2.
            //
            // Njia zote ziliwekwa alama, na ya tatu ilionyesha matokeo bora.Kwa hivyo tukachagua hiyo.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Hali ya kati ya mchakato wa kuingiza daima inafuatiliwa na `hole`, ambayo hutimiza madhumuni mawili:
            // 1. Inalinda uadilifu wa `v` kutoka panics katika `is_less`.
            // 2. Hujaza shimo iliyobaki katika `v` mwishowe.
            //
            // Usalama wa Panic:
            //
            // Ikiwa `is_less` panics wakati wowote wakati wa mchakato, `hole` itashuka na kujaza shimo kwenye `v` na `tmp`, na hivyo kuhakikisha kuwa `v` bado inashikilia kila kitu ambacho hapo awali kilishikilia mara moja.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` inashuka na hivyo kunakili `tmp` kwenye shimo lililobaki katika `v`.
        }
    }

    // Wakati imeshuka, nakala kutoka `src` hadi `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Huunganisha mbio zisizopungua `v[..mid]` na `v[mid..]` kutumia `buf` kama uhifadhi wa muda, na huhifadhi matokeo kuwa `v[..]`.
///
/// # Safety
///
/// Vipande viwili lazima visivyo na tupu na `mid` lazima iwe katika mipaka.
/// Bafa ya `buf` lazima iwe na urefu wa kutosha kushikilia nakala ya kipande kifupi.
/// Pia, `T` haipaswi kuwa aina ya ukubwa wa sifuri.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Mchakato wa kuunganisha kwanza nakala fupi zinaingia kwenye `buf`.
    // Halafu inafuatilia kukimbia kunakiliwa hivi karibuni na kukimbia mbele zaidi (au nyuma), kulinganisha vitu vifuatavyo visivyochukuliwa na kunakili ile ndogo (au kubwa) kuwa `v`.
    //
    // Mara tu kukimbia mfupi kunatumiwa kabisa, mchakato hufanywa.Ikiwa kukimbia kwa muda mrefu kunatumiwa kwanza, basi lazima tunakili chochote kilichobaki cha kukimbia mfupi kwenye shimo iliyobaki ya `v`.
    //
    // Hali ya kati ya mchakato daima inafuatiliwa na `hole`, ambayo hutimiza madhumuni mawili:
    // 1. Inalinda uadilifu wa `v` kutoka panics katika `is_less`.
    // 2. Hujaza shimo lililobaki katika `v` ikiwa mwendo mrefu utatumiwa kwanza.
    //
    // Usalama wa Panic:
    //
    // Ikiwa `is_less` panics wakati wowote wakati wa mchakato, `hole` itashuka na kujaza shimo kwenye `v` na safu isiyofikiriwa katika `buf`, na hivyo kuhakikisha kuwa `v` bado inashikilia kila kitu ambacho hapo awali kilishikilia mara moja.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Kukimbia kushoto ni fupi.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Hapo awali, viashiria hivi vinaelekeza kwa mwanzo wa safu zao.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Tumia upande mdogo.
            // Ikiwa ni sawa, pendelea mbio ya kushoto ili kudumisha utulivu.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Kukimbia kulia ni mfupi.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Hapo awali, viashiria hivi vinaelekeza kupita mwisho wa safu zao.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Tumia upande mkubwa.
            // Ikiwa ni sawa, pendelea mbio inayofaa ili kudumisha utulivu.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Mwishowe, `hole` inashuka.
    // Ikiwa mbio fupi haikutumiwa kabisa, mabaki yake yoyote sasa yatanakiliwa kwenye shimo kwenye `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Wakati imeshuka, nakili fungu la `start..end` kuwa `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` sio aina ya saizi, kwa hivyo ni sawa kugawanya kwa saizi yake.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Aina hii ya kuunganisha inakopa maoni (lakini sio yote) kutoka TimSort, ambayo inaelezewa kwa undani [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algorithm inabainisha madhubuti ya kushuka na yasiyo ya kushuka, ambayo huitwa kukimbia kwa asili.Kuna mkusanyiko wa mbio zinazosubiri bado kuunganishwa.
/// Kila kukimbia mpya kunasukumwa kwenye ghala, na kisha jozi za mbio zilizo karibu zimeunganishwa hadi hawa wavamizi wawili waridhike:
///
/// 1. kwa kila `i` katika `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. kwa kila `i` katika `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Wavamizi wanahakikisha kuwa jumla ya wakati wa kukimbia ni *O*(*n*\*log(* n*)) kesi mbaya.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Vipande vya hadi urefu huu hupangwa kwa kutumia aina ya kuingizwa.
    const MAX_INSERTION: usize = 20;
    // Kukimbia kwa kifupi sana kunapanuliwa kwa kutumia aina ya uingizaji ili kupanua angalau vitu hivi vingi.
    const MIN_RUN: usize = 10;

    // Kupanga hakuna tabia ya maana kwa aina za saizi.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Safu fupi hupangwa mahali kwa njia ya kuingizwa ili kuzuia mgawanyo.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Tenga bafa ili utumie kama kumbukumbu ya mwanzo.Tunaweka urefu wa 0 ili tuweze kuweka ndani yake nakala za kina za yaliyomo kwenye `v` bila kuhatarisha dtors zinazoendesha nakala ikiwa `is_less` panics.
    //
    // Wakati wa kuunganisha mbio mbili zilizopangwa, bafa hii inashikilia nakala ya kukimbia mfupi, ambayo siku zote itakuwa na urefu wa `len / 2` zaidi.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Ili kutambua mbio za asili katika `v`, tunapita nyuma.
    // Huo unaweza kuonekana kama uamuzi wa kushangaza, lakini fikiria ukweli kwamba kuunganishwa mara nyingi huenda kwa mwelekeo tofauti (forwards).
    // Kulingana na viashiria, kuunganisha mbele ni haraka kidogo kuliko kuunganisha nyuma.
    // Kuhitimisha, kutambua kukimbia kwa kupita nyuma kunaboresha utendaji.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Pata mbio inayofuata ya asili, na uibadilishe ikiwa inashuka kabisa.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Ingiza vipengee vingine kwenye kukimbia ikiwa ni fupi sana.
        // Aina ya kuingiza ni haraka kuliko kuunganisha aina kwenye mfuatano mfupi, kwa hivyo hii inaboresha utendaji.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Shinikiza kukimbia kwenye stack.
        runs.push(Run { start, len: end - start });
        end = start;

        // Unganisha jozi kadhaa za mbio za karibu ili kukidhi wavamizi.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Mwishowe, kukimbia moja lazima kubaki kwenye stack.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Inachunguza mkusanyiko wa mbio na kubainisha michache ijayo ya kukimbia ili kuungana.
    // Hasa haswa, ikiwa `Some(r)` inarejeshwa, hiyo inamaanisha `runs[r]` na `runs[r + 1]` lazima ziunganishwe baadaye.
    // Ikiwa algorithm inapaswa kuendelea kujenga mbio mpya badala yake, `None` inarejeshwa.
    //
    // TimSort ni maarufu kwa utekelezaji wake wa buggy, kama ilivyoelezewa hapa:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Kiini cha hadithi ni: lazima tutie nguvu kwa wavamizi kwenye mbio nne za juu kwenye gombo.
    // Kuzisimamia kwenye tatu tu za juu haitoshi kuhakikisha kuwa wavamizi bado watashikilia mbio za *zote* kwenye ghala.
    //
    // Kazi hii huangalia kwa usahihi wavamizi kwa kukimbia nne za juu.
    // Kwa kuongezea, ikiwa mbio ya juu itaanza katika faharisi ya 0, itahitaji kila wakati operesheni ya kuunganisha mpaka stack imeanguka kabisa, ili kukamilisha aina hiyo.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}