//! Vipande vya kamba ya Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Aina ya `&str` ni moja wapo ya aina kuu mbili za kamba, na nyingine ni `String`.
//! Tofauti na mwenzake wa `String`, yaliyomo yamekopwa.
//!
//! # Matumizi ya Msingi
//!
//! Tamko la kimsingi la aina ya `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Hapa tumetangaza kamba halisi, pia inajulikana kama kipande cha kamba.
//! Fasihi za kamba zina maisha ya tuli, ambayo inamaanisha kuwa kamba `hello_world` imehakikishiwa kuwa halali kwa kipindi chote cha programu nzima.
//!
//! Tunaweza kubainisha wazi maisha ya "hello_world" pia:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Matumizi mengi katika moduli hii hutumiwa tu katika usanidi wa jaribio.
// Ni safi kuzima tu onyo lisilotumika_kuagiza kuliko kuzirekebisha.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` katika `Concat<str>` haina maana hapa.
/// Aina ya parameter ya trait ipo tu kuwezesha kuingiza mwingine.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // matanzi yenye saizi zilizochapishwa huendesha haraka zaidi kutaja kesi zilizo na urefu mdogo wa kitenganishi
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // kiholela kisicho cha sifuri kurudi nyuma
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Utekelezaji uliojiunga ulioboreshwa ambao hufanya kazi kwa Vec zote mbili<T>(T: Nakala) na vec ya ndani ya Kamba Hivi sasa (2018-05-13) kuna mdudu aliye na udadisi wa aina na utaalam (tazama toleo #36262) Kwa sababu hii SliceConcat<T>sio maalum kwa T: Nakala na SliceConcat<str>ndiye mtumiaji pekee wa kazi hii.
// Imeachwa mahali kwa wakati ambapo hiyo imewekwa.
//
// mipaka ya Kujiunga-String ni S: Kopa<str>na kwa Vec-jiunga Borrow <[T]> [T] na str zote mbili impl AsRef <[T]> kwa baadhi ya T
// => s.borrow().as_ref() na sisi daima tuna vipande
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // kipande cha kwanza ndio pekee bila kitenganishi kilichotangulia
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // hesabu urefu kamili wa Vec iliyojiunga ikiwa hesabu ya `len` imejaa, tutakuwa panic tungekuwa tumepoteza kumbukumbu hata hivyo na kazi iliyobaki inahitaji Vec nzima iliyotengwa tayari kwa usalama
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // andaa bafa isiyojulikana
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // nakala ya kujitenga na vipande bila hundi za mipaka hutengeneza vitanzi na vifurushi vilivyo ngumu kwa watenganishaji wadogo maboresho makubwa yanayowezekana (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Utekelezaji wa kukopa wa kushangaza unaweza kurudisha vipande tofauti kwa hesabu ya urefu na nakala halisi.
        //
        // Hakikisha hatutoi kaiti ambazo hazijaanzishwa kwa mpigaji.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Njia za vipande vya kamba.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Inabadilisha `Box<str>` kuwa `Box<[u8]>` bila kunakili au kutenga.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Inabadilisha mechi zote za muundo na kamba nyingine.
    ///
    /// `replace` huunda [`String`] mpya, na kunakili data kutoka kwa kipande hiki cha kamba ndani yake.
    /// Wakati wa kufanya hivyo, inajaribu kupata mechi za muundo.
    /// Ikiwa inapata yoyote, inachukua nafasi yao na kipande cha kamba badala.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Wakati muundo hailingani:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Inabadilisha mechi za kwanza N za muundo na kamba nyingine.
    ///
    /// `replacen` huunda [`String`] mpya, na kunakili data kutoka kwa kipande hiki cha kamba ndani yake.
    /// Wakati wa kufanya hivyo, inajaribu kupata mechi za muundo.
    /// Ikiwa inapata yoyote, inachukua nafasi ya kipande cha kamba badala ya mara `count`.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Wakati muundo hailingani:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Natumai kupunguza nyakati za kutenga tena
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Hurejesha herufi ndogo sawa na kipande cha kamba hii, kama [`String`] mpya.
    ///
    /// 'Lowercase' hufafanuliwa kulingana na masharti ya Unicode Derives Core Property `Lowercase`.
    ///
    /// Kwa kuwa wahusika wengine wanaweza kupanuka kuwa herufi nyingi wakati wa kubadilisha kesi, kazi hii inarudi [`String`] badala ya kurekebisha parameta mahali.
    ///
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Mfano mgumu, na sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // lakini mwisho wa neno, ni ς, sio σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Lugha bila kesi hazibadilishwa:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ ramani kwa σ, isipokuwa mwisho wa neno ambapo ramani kwenda ς.
                // Hii ni ramani tu ya (contextual) lakini ramani inayojitegemea ya lugha katika `SpecialCasing.txt`, kwa hivyo nambari ngumu badala ya kuwa na utaratibu wa generic "condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // kwa ufafanuzi wa `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Hurejesha ukubwa sawa wa kipande cha kamba hii, kama [`String`] mpya.
    ///
    /// 'Uppercase' hufafanuliwa kulingana na masharti ya Unicode Derives Core Property `Uppercase`.
    ///
    /// Kwa kuwa wahusika wengine wanaweza kupanuka kuwa herufi nyingi wakati wa kubadilisha kesi, kazi hii inarudi [`String`] badala ya kurekebisha parameta mahali.
    ///
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Maandishi bila kesi hayabadilishwe:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Tabia moja inaweza kuwa nyingi:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Inabadilisha [`Box<str>`] kuwa [`String`] bila kunakili au kutenga.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Inaunda [`String`] mpya kwa kurudia kamba mara `n`.
    ///
    /// # Panics
    ///
    /// Kazi hii itakuwa panic ikiwa uwezo utafurika.
    ///
    /// # Examples
    ///
    /// Matumizi ya kimsingi:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic wakati wa kufurika:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Hurejesha nakala ya kamba hii ambapo kila mhusika amewekwa ramani kwa herufi kubwa ya ASCII.
    ///
    ///
    /// Barua za ASCII 'a' hadi 'z' zimepangwa kwa 'A' hadi 'Z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kuongeza thamani mahali, tumia [`make_ascii_uppercase`].
    ///
    /// Ili kuongeza herufi kubwa za ASCII pamoja na herufi zisizo za ASCII, tumia [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() huhifadhi kibadilishaji cha UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Hurejesha nakala ya kamba hii ambapo kila mhusika amewekwa ramani kwa herufi ndogo ya ASCII.
    ///
    ///
    /// Barua za ASCII 'A' hadi 'Z' zimepangwa kwa 'a' hadi 'z', lakini barua zisizo za ASCII hazibadilishwa.
    ///
    /// Ili kupunguza thamani mahali, tumia [`make_ascii_lowercase`].
    ///
    /// Ili kupunguza herufi za ASCII pamoja na herufi zisizo za ASCII, tumia [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() huhifadhi kibadilishaji cha UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Hubadilisha kipande cha baiti zilizo kwenye ndondi kuwa kipande cha kamba bila kuangalia kuwa kamba ina UTF-8 halali.
///
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}