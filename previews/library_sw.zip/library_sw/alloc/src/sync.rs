#![stable(feature = "rust1", since = "1.0.0")]

//! Vidokezo vya kuhesabu kumbukumbu salama.
//!
//! Tazama nyaraka za [`Arc<T>`][Arc] kwa maelezo zaidi.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Kikomo laini juu ya kiwango cha marejeleo ambayo inaweza kufanywa kwa `Arc`.
///
/// Kuenda juu ya kikomo hiki kutaharibu mpango wako (ingawa sio lazima) kwenye marejeleo ya _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer haitumii uzio wa kumbukumbu.
// Ili kuepuka ripoti chanya za uwongo katika Utekelezaji/Utekelezaji dhaifu tumia mizigo ya atomiki kwa usawazishaji badala yake.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Kiashiria cha kuhesabu kumbukumbu salama-salama.'Arc' inasimama kwa 'Rejea ya Atomiki Iliyohesabiwa'.
///
/// Aina `Arc<T>` hutoa umiliki wa pamoja wa thamani ya aina `T`, iliyotengwa katika lundo.Kuingiza [`clone`][clone] kwenye `Arc` kunatoa mfano mpya wa `Arc`, ambao unaonyesha mgawanyo sawa kwenye lundo kama chanzo `Arc`, huku ikiongeza hesabu ya kumbukumbu.
/// Wakati pointer ya mwisho ya `Arc` kwa mgao uliopewa imeharibiwa, thamani iliyohifadhiwa katika mgao huo (mara nyingi hujulikana kama "inner value") pia imeshuka.
///
/// Marejeleo yaliyoshirikiwa katika Rust hairuhusu mabadiliko kwa chaguo-msingi, na `Arc` sio ubaguzi: kwa ujumla huwezi kupata rejeleo linaloweza kubadilika kwa kitu ndani ya `Arc`.Ikiwa unahitaji kubadilika kupitia `Arc`, tumia [`Mutex`][mutex], [`RwLock`][rwlock], au moja ya aina ya [`Atomic`][atomic].
///
/// ## Usalama wa Thread
///
/// Tofauti na [`Rc<T>`], `Arc<T>` hutumia shughuli za atomiki kwa kuhesabu kumbukumbu yake.Hii inamaanisha kuwa iko salama kwa uzi.Ubaya ni kwamba shughuli za atomiki ni ghali zaidi kuliko ufikiaji wa kumbukumbu ya kawaida.Ikiwa haushiriki mgawanyo uliohesabiwa kati ya nyuzi, fikiria kutumia [`Rc<T>`] kwa kichwa cha chini.
/// [`Rc<T>`] ni chaguo-msingi salama, kwa sababu mkusanyaji atapata jaribio lolote la kutuma [`Rc<T>`] kati ya nyuzi.
/// Walakini, maktaba inaweza kuchagua `Arc<T>` ili kuwapa watumiaji wa maktaba kubadilika zaidi.
///
/// `Arc<T>` itatekeleza [`Send`] na [`Sync`] ilimradi `T` itekeleze [`Send`] na [`Sync`].
/// Kwa nini huwezi kuweka aina isiyo salama ya nyuzi `T` katika `Arc<T>` kuifanya iwe salama?Hii inaweza kuwa ya kukanusha kidogo mwanzoni: baada ya yote, sio uhakika wa usalama wa nyuzi ya `Arc<T>`?Muhimu ni hii: `Arc<T>` inafanya salama kuwa na umiliki wa data sawa, lakini haiongezi usalama wa uzi kwa data yake.
///
/// Fikiria `Safu <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] sio [`Sync`], na ikiwa `Arc<T>` mara zote ilikuwa [`Send`], `Arc <` [`RefCell<T>`]`>`ingekuwa vile vile.
/// Lakini basi tungekuwa na shida:
/// [`RefCell<T>`] sio salama kwa uzi;inafuatilia hesabu ya kukopa kwa kutumia shughuli zisizo za atomiki.
///
/// Mwishowe, hii inamaanisha kuwa unaweza kuhitaji kuoanisha `Arc<T>` na aina fulani ya aina ya [`std::sync`], kawaida [`Mutex<T>`][mutex].
///
/// ## Kuvunja mizunguko na `Weak`
///
/// Njia ya [`downgrade`][downgrade] inaweza kutumika kuunda pointer ya [`Weak`] isiyomiliki.Kiashiria cha [`Weak`] kinaweza kuwa ["kuboresha"][kuboresha] d hadi `Arc`, lakini hii itarudi [`None`] ikiwa thamani iliyohifadhiwa katika mgao tayari imeshuka.
/// Kwa maneno mengine, viashiria vya `Weak` havihifadhi thamani ndani ya mgao hai;Walakini, wao *hufanya* kuweka ugawaji (duka ya kuhifadhi nakala kwa thamani) hai.
///
/// Mzunguko kati ya viashiria vya `Arc` hautasambazwa kamwe.
/// Kwa sababu hii, [`Weak`] hutumiwa kuvunja mizunguko.Kwa mfano, mti unaweza kuwa na viashiria vikali vya `Arc` kutoka nodi za wazazi hadi watoto, na viashiria vya [`Weak`] kutoka kwa watoto kurudi kwa wazazi wao.
///
/// # Marejeleo ya kuunda
///
/// Kuunda rejeleo mpya kutoka kwa kiashiria kilichohesabiwa cha rejea hufanywa kwa kutumia `Clone` trait iliyotekelezwa kwa [`Arc<T>`][Arc] na [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Sintaksia mbili hapa chini ni sawa.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, na foo zote ni Arcs ambazo zinaelekeza kwenye eneo sawa la kumbukumbu
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` marejeleo ya moja kwa moja kwa `T` (kupitia [`Deref`][deref] trait), kwa hivyo unaweza kupiga njia za `T` juu ya thamani ya aina `Arc<T>`.Ili kuepusha migongano ya jina na njia za `T, njia za `Arc<T>` yenyewe ni kazi zinazohusiana, zinazoitwa kutumia [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Safu<T>Utekelezaji wa traits kama `Clone` pia inaweza kuitwa kutumia syntax iliyostahili kabisa.
/// Watu wengine wanapendelea kutumia sintaksia iliyostahili kabisa, wakati wengine wanapendelea kutumia syntax ya njia-wito.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Njia ya kupiga simu syntax
/// let arc2 = arc.clone();
/// // Sintaksia yenye sifa kamili
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] haionyeshi kiotomatiki kwa `T`, kwa sababu thamani ya ndani inaweza kuwa tayari imeshuka.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Kushiriki data ambazo hazibadiliki kati ya nyuzi:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Kumbuka kuwa sisi ** hatuendeshi majaribio haya hapa.
// Wajenzi wa windows hafurahii sana ikiwa uzi unapita zaidi ya uzi kuu na kisha kutoka kwa wakati mmoja (kitu kilichotengwa) kwa hivyo tunaepuka hii kabisa kwa kutofanya majaribio haya.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Kushiriki [`AtomicUsize`] inayoweza kubadilika:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Tazama [`rc` documentation][rc_examples] kwa mifano zaidi ya kuhesabu kumbukumbu kwa ujumla.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ni toleo la [`Arc`] ambalo lina kumbukumbu isiyo ya kumiliki mgao uliosimamiwa.
/// Mgawo huo unapatikana kwa kupiga [`upgrade`] kwenye kidokezo cha `Weak`, ambacho kinarudisha [`Chaguo`]`<<[[Arc`] `<T>>".
///
/// Kwa kuwa rejeleo la `Weak` halizingatii umiliki, halitazuia dhamana iliyohifadhiwa katika mgao kuteremshwa, na `Weak` yenyewe haitoi dhamana juu ya dhamana ambayo bado iko.
///
/// Kwa hivyo inaweza kurudisha [`None`] wakati [`kuboresha"] d.
/// Kumbuka hata hivyo kwamba kumbukumbu ya `Weak` * inazuia ugawaji wenyewe (duka la kuunga mkono) lisihamishwe.
///
/// Kiashiria cha `Weak` ni muhimu kwa kuweka kumbukumbu ya muda kwa mgao unaosimamiwa na [`Arc`] bila kuzuia thamani yake ya ndani ishuzwe.
/// Inatumika pia kuzuia marejeleo ya duara kati ya viashiria vya [`Arc`], kwani marejeleo ya umiliki wa pande zote hayangeruhusu [`Arc`] kutolewa.
/// Kwa mfano, mti unaweza kuwa na viashiria vikali vya [`Arc`] kutoka nodi za wazazi hadi watoto, na viashiria vya `Weak` kutoka kwa watoto kurudi kwa wazazi wao.
///
/// Njia ya kawaida ya kupata pointer ya `Weak` ni kupiga [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Hii ni `NonNull` inayoruhusu kuongeza ukubwa wa aina hii katika enum, lakini sio lazima kuwa ni pointer halali.
    //
    // `Weak::new` inaweka hii kwa `usize::MAX` ili isihitaji kutenga nafasi kwenye lundo.
    // Hiyo sio thamani ambayo pointer halisi itakuwa nayo kwa sababu RcBox ina mpangilio angalau 2.
    // Hii inawezekana tu wakati `T: Sized`;`T` isiyo na ukubwa kamwe haingiliki.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Hii ni repr(C) hadi future-ushahidi dhidi ya upangaji wa uwanja unaowezekana, ambao utaingiliana na [into|from]_raw() salama ya aina za ndani zinazoweza kupitishwa.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // thamani usize::MAX hufanya kama sentineli kwa muda "locking" uwezo wa kuboresha vidokezo dhaifu au kushusha nguvu;hii hutumiwa kuzuia mbio katika `make_mut` na `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Inaunda `Arc<T>` mpya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Anza hesabu dhaifu ya pointer kama 1 ambayo ni pointer dhaifu ambayo inashikiliwa na viashiria vyote vikali (kinda), angalia std/rc.rs kwa habari zaidi
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Inaunda `Arc<T>` mpya kwa kutumia rejista dhaifu kwa yenyewe.
    /// Kujaribu kuboresha marejeleo dhaifu kabla ya kazi hii kurudi itasababisha thamani ya `None`.
    /// Walakini, rejeleo dhaifu linaweza kuumbwa kwa uhuru na kuhifadhiwa kwa matumizi baadaye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Jenga ya ndani katika jimbo la "uninitialized" na kumbukumbu moja dhaifu.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ni muhimu tusiachane na umiliki wa pointer dhaifu, au sivyo kumbukumbu inaweza kutolewa wakati `data_fn` inarudi.
        // Ikiwa kweli tunataka kupitisha umiliki, tunaweza kujiboresha kiashiria dhaifu, lakini hii itasababisha sasisho za ziada kwa hesabu dhaifu ya rejeleo ambayo inaweza kuwa sio lazima vinginevyo.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Sasa tunaweza kuanzisha vizuri thamani ya ndani na kugeuza rejea yetu dhaifu kuwa rejeleo kali.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Uandishi hapo juu kwenye uwanja wa data lazima uonekane na nyuzi zozote ambazo zinaangalia hesabu isiyo na sifuri.
            // Kwa hivyo tunahitaji angalau kuagiza "Release" ili kusawazisha na `compare_exchange_weak` katika `Weak::upgrade`.
            //
            // "Acquire" kuagiza haihitajiki.
            // Wakati wa kuzingatia tabia zinazowezekana za `data_fn` tunahitaji tu kuangalia ni nini inaweza kufanya kwa kurejelea `Weak` isiyoweza kusasishwa:
            //
            // - Inaweza *kushikilia*`Weak`, ikiongeza hesabu dhaifu ya rejeleo.
            // - Inaweza kuacha viini hivyo, ikipunguza hesabu dhaifu ya rejeleo (lakini isiwe sifuri).
            //
            // Madhara haya hayatuathiri kwa njia yoyote, na hakuna athari zingine zinazowezekana na nambari salama peke yake.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Marejeleo yenye nguvu yanapaswa kwa pamoja kumiliki rejelei dhaifu iliyoshirikiwa, kwa hivyo usiendeshe uharibifu kwa rejeleo letu dhaifu la zamani.
        //
        mem::forget(weak);
        strong
    }

    /// Inaunda `Arc` mpya na yaliyomo ambayo hayajaanza.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Inaunda `Arc` mpya na yaliyomo ambayo hayajaanza, na kumbukumbu imejazwa na ka `0`.
    ///
    ///
    /// Tazama [`MaybeUninit::zeroed`][zeroed] kwa mifano ya matumizi sahihi na yasiyo sahihi ya njia hii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Inaunda `Pin<Arc<T>>` mpya.
    /// Ikiwa `T` haitekelezi `Unpin`, basi `data` itapachikwa kwenye kumbukumbu na haiwezi kuhamishwa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Huunda `Arc<T>` mpya, ikirudisha hitilafu ikiwa mgao unashindwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Anza hesabu dhaifu ya pointer kama 1 ambayo ni pointer dhaifu ambayo inashikiliwa na viashiria vyote vikali (kinda), angalia std/rc.rs kwa habari zaidi
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Inaunda `Arc` mpya na yaliyomo ambayo hayajaanza, inarudi kosa ikiwa mgawanyiko hautafanikiwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Inaunda `Arc` mpya na yaliyomo ambayo hayajaanza, na kumbukumbu imejazwa na kaiti za `0`, ikirudisha hitilafu ikiwa mgao unashindwa.
    ///
    ///
    /// Tazama [`MaybeUninit::zeroed`][zeroed] kwa mifano ya matumizi sahihi na yasiyo sahihi ya njia hii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Hurejesha thamani ya ndani, ikiwa `Arc` ina kumbukumbu moja kali.
    ///
    /// Vinginevyo, [`Err`] inarejeshwa na `Arc` ile ile ambayo ilipitishwa.
    ///
    ///
    /// Hii itafaulu hata ikiwa kuna marejeleo dhaifu dhaifu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Tengeneza kiashiria dhaifu kusafisha rejeleo dhaifu-dhaifu
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Huunda kipande kipya cha hesabu iliyohesabiwa na atomiki na yaliyomo ambayo hayajaanza.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Inaunda kipande kipya cha hesabu kilichohesabiwa na atomiki na yaliyomo ambayo hayajaanza, na kumbukumbu imejazwa na ka `0`.
    ///
    ///
    /// Tazama [`MaybeUninit::zeroed`][zeroed] kwa mifano ya matumizi sahihi na yasiyo sahihi ya njia hii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Inabadilisha kuwa `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Kama ilivyo kwa [`MaybeUninit::assume_init`], ni juu ya mpigaji kuhakikisha kwamba thamani ya ndani kweli iko katika hali iliyoanzishwa.
    ///
    /// Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Inabadilisha kuwa `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kama ilivyo kwa [`MaybeUninit::assume_init`], ni juu ya mpigaji kuhakikisha kwamba thamani ya ndani kweli iko katika hali iliyoanzishwa.
    ///
    /// Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Inatumia `Arc`, ikirudisha pointer iliyofungwa.
    ///
    /// Ili kuzuia kuvuja kwa kumbukumbu pointer lazima ibadilishwe kuwa `Arc` kwa kutumia [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Hutoa pointer mbichi kwa data.
    ///
    /// Hesabu haziathiriwi kwa njia yoyote na `Arc` haitumiwi.
    /// Kiashiria ni halali kwa muda mrefu kama kuna hesabu kali katika `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // USALAMA: Hii haiwezi kupitia Deref::deref au RcBoxPtr::inner kwa sababu
        // hii inahitajika kuhifadhi asili ya raw/mut kama vile mfano
        // `get_mut` unaweza kuandika kupitia pointer baada ya Rc kurejeshwa kupitia `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Inaunda `Arc<T>` kutoka kwa pointer mbichi.
    ///
    /// Kiashiria mbichi lazima kilirudishwa hapo awali na simu kwa [`Arc<U>::into_raw`][into_raw] ambapo `U` lazima iwe na saizi sawa na mpangilio kama `T`.
    /// Hii ni kweli kidogo ikiwa `U` ni `T`.
    /// Kumbuka kuwa ikiwa `U` sio `T` lakini ina ukubwa sawa na mpangilio, hii kimsingi ni kama kusambaza marejeleo ya aina tofauti.
    /// Tazama [`mem::transmute`][transmute] kwa habari zaidi juu ya vizuizi vipi vinavyotumika katika kesi hii.
    ///
    /// Mtumiaji wa `from_raw` lazima ahakikishe thamani maalum ya `T` imeshuka mara moja tu.
    ///
    /// Kazi hii sio salama kwa sababu matumizi yasiyofaa yanaweza kusababisha usalama wa kumbukumbu, hata ikiwa `Arc<T>` iliyorudishwa haipatikani kamwe.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Badilisha hadi `Arc` kuzuia kuvuja.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Simu zaidi kwa `Arc::from_raw(x_ptr)` itakuwa salama-kumbukumbu.
    /// }
    ///
    /// // Kumbukumbu iliachiliwa wakati `x` ilitoka kwa wigo hapo juu, kwa hivyo `x_ptr` sasa inaning'inia!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Rudisha deni ili upate ArcInner asili.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Inaunda pointer mpya ya [`Weak`] kwa mgao huu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Kufurahi hii ni sawa kwa sababu tunaangalia thamani katika CAS hapa chini.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // angalia ikiwa kaunta dhaifu sasa ni "locked";kama ni hivyo, spin.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: nambari hii kwa sasa inapuuza uwezekano wa kufurika
            // ndani ya usize::MAX;kwa jumla Rc na Arc zinahitaji kurekebishwa ili kukabiliana na kufurika.
            //

            // Tofauti na Clone(), tunahitaji hii iwe Pata kusoma ili kulandanisha na maandishi yanayotokana na `is_unique`, ili hafla za kabla ya uandishi huo zifanyike kabla ya kusoma.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Hakikisha hatuunda dhaifu
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Inapata idadi ya viashiria vya [`Weak`] kwa mgao huu.
    ///
    /// # Safety
    ///
    /// Njia hii yenyewe ni salama, lakini kuitumia kwa usahihi inahitaji utunzaji wa ziada.
    /// Thread nyingine inaweza kubadilisha hesabu dhaifu wakati wowote, pamoja na uwezekano wa kupiga simu njia hii na kutekeleza matokeo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Madai haya ni ya kuamua kwa sababu hatujashiriki `Arc` au `Weak` kati ya nyuzi.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ikiwa hesabu dhaifu imefungwa kwa sasa, thamani ya hesabu ilikuwa 0 kabla tu ya kuchukua kufuli.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Inapata idadi ya viashiria vikali vya (`Arc`) kwa mgao huu.
    ///
    /// # Safety
    ///
    /// Njia hii yenyewe ni salama, lakini kuitumia kwa usahihi inahitaji utunzaji wa ziada.
    /// Thread nyingine inaweza kubadilisha hesabu kali wakati wowote, pamoja na uwezekano wa kupiga simu njia hii na kutekeleza matokeo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Madai haya ni ya kuamua kwa sababu hatujashiriki `Arc` kati ya nyuzi.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Huongeza hesabu kubwa ya rejeleo kwenye `Arc<T>` inayohusishwa na kiashiria kilichotolewa kwa moja.
    ///
    /// # Safety
    ///
    /// Kiashiria lazima kipatikane kupitia `Arc::into_raw`, na mfano unaohusishwa wa `Arc` lazima uwe halali (yaani
    /// hesabu kali lazima iwe angalau 1) kwa muda wa njia hii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Madai haya ni ya kuamua kwa sababu hatujashiriki `Arc` kati ya nyuzi.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Hifadhi Safu, lakini usiguse hesabu kwa kufunika kwenye ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Sasa ongeza hesabu tena, lakini usisimamishe hesabu mpya pia
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Kupunguza hesabu ya kumbukumbu yenye nguvu kwenye `Arc<T>` inayohusishwa na kiboreshaji kilichopewa moja.
    ///
    /// # Safety
    ///
    /// Kiashiria lazima kipatikane kupitia `Arc::into_raw`, na mfano unaohusishwa wa `Arc` lazima uwe halali (yaani
    /// hesabu kali lazima iwe angalau 1) wakati wa kutumia njia hii.
    /// Njia hii inaweza kutumika kutoa `Arc` ya mwisho na kuhifadhi kuhifadhi, lakini **haipaswi** kuitwa baada ya `Arc` ya mwisho kutolewa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Madai hayo ni ya kuamua kwa sababu hatujashiriki `Arc` kati ya nyuzi.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ukosefu wa usalama huu ni sawa kwa sababu wakati safu hii iko hai tunahakikishiwa kuwa pointer ya ndani ni halali.
        // Kwa kuongezea, tunajua kuwa muundo wa `ArcInner` yenyewe ni `Sync` kwa sababu data ya ndani ni `Sync` pia, kwa hivyo tuko sawa kutoa kiboreshaji kisichobadilika kwa yaliyomo.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Sehemu isiyo ya ndani ya `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Vunja data kwa wakati huu, hata ingawa hatuwezi kutoa mgawanyo wa sanduku yenyewe (bado kunaweza kuwa na viashiria dhaifu vilivyozunguka).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Ondoa marejeleo dhaifu yaliyoshikiliwa na marejeleo yote yenye nguvu
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Hurejesha `true` ikiwa sehemu mbili za `Arc` zinaelekeza kwa mgao huo (kwa mshipa sawa na [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Hutenga `ArcInner<T>` na nafasi ya kutosha kwa thamani ya ndani isiyo na ukubwa ambapo thamani ina mpangilio uliyopewa.
    ///
    /// Kazi `mem_to_arcinner` inaitwa na pointer ya data na lazima irudishe tena (uwezekano wa mafuta)-mtaalam wa `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Hesabu mpangilio ukitumia mpangilio wa thamani uliopewa.
        // Hapo awali, mpangilio ulihesabiwa juu ya usemi wa `&*(ptr as* const ArcInner<T>)`, lakini hii iliunda rejeleo lililopangwa vibaya (tazama #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Hutenga `ArcInner<T>` na nafasi ya kutosha kwa thamani ya ndani isiyo na ukubwa ambapo thamani ina mpangilio uliyopewa, kurudisha kosa ikiwa mgawanyiko unashindwa.
    ///
    ///
    /// Kazi `mem_to_arcinner` inaitwa na pointer ya data na lazima irudishe tena (uwezekano wa mafuta)-mtaalam wa `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Hesabu mpangilio ukitumia mpangilio wa thamani uliopewa.
        // Hapo awali, mpangilio ulihesabiwa juu ya usemi wa `&*(ptr as* const ArcInner<T>)`, lakini hii iliunda rejeleo lililopangwa vibaya (tazama #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Anzisha ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Hutenga `ArcInner<T>` na nafasi ya kutosha kwa thamani ya ndani isiyo na ukubwa.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Tenga kwa `ArcInner<T>` ukitumia thamani uliyopewa.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nakili thamani kama ka
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Bure mgao bila kuacha yaliyomo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Hutenga `ArcInner<[T]>` na urefu uliopewa.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Nakili vipengee kutoka kipande hadi kwenye Safu mpya iliyotengwa <\[T\]>
    ///
    /// Sio salama kwa sababu mpigaji lazima lazima achukue umiliki au afunge `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Inaunda `Arc<[T]>` kutoka kwa iterator inayojulikana kuwa ya saizi fulani.
    ///
    /// Tabia haijafafanuliwa ikiwa saizi itakuwa mbaya.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Mlinzi wa Panic wakati wa kuunda vitu vya T.
        // Katika tukio la panic, vitu ambavyo vimeandikwa kwenye ArcInner mpya vitaondolewa, kisha kumbukumbu itafunguliwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Kielekezi kwa kipengee cha kwanza
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Yote wazi.Kusahau mlinzi ili isiwe huru ArcInner mpya.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Utaalam trait kutumika kwa `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Inafanya mwamba wa pointer ya `Arc`.
    ///
    /// Hii inaunda kiboreshaji kingine kwa mgao huo huo, ikiongeza hesabu kubwa ya kumbukumbu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Kutumia kuagiza kwa utulivu ni sawa hapa, kwani maarifa ya rejeleo la asili huzuia nyuzi zingine zisifute kitu kimakosa.
        //
        // Kama ilivyoelezewa katika [Boost documentation][1], Kuongeza kaunta ya kumbukumbu inaweza kufanywa kila wakati na kumbukumbu_order_relaxed: Marejeleo mapya ya kitu yanaweza tu kuundwa kutoka kwa kumbukumbu iliyopo, na kupitisha rejeleo lililopo kutoka kwa uzi mmoja hadi mwingine lazima tayari litoe usawazishaji wowote unaohitajika.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Walakini tunahitaji kujilinda dhidi ya hesabu kubwa ikiwa mtu atakuwa "mem: : kusahau Arcs.
        // Ikiwa hatufanyi hivi hesabu inaweza kufurika na watumiaji watatumia-baada ya bure.
        // Sisi hujaa kwa hiari hadi `isize::MAX` kwa kudhani kuwa hakuna nyuzi bilioni ~2 zinazoongeza hesabu ya kumbukumbu mara moja.
        //
        // branch hii haitachukuliwa kamwe katika mpango wowote wa kweli.
        //
        // Tunatoa mimba kwa sababu mpango kama huo ni mbaya sana, na hatujali kuunga mkono.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Inafanya rejeleo inayoweza kubadilika katika `Arc` iliyopewa.
    ///
    /// Ikiwa kuna vidokezo vingine vya `Arc` au [`Weak`] kwa mgao huo huo, basi `make_mut` itaunda mgawo mpya na kuomba [`clone`][clone] kwa thamani ya ndani kuhakikisha umiliki wa kipekee.
    /// Hii pia inajulikana kama clone-on-write.
    ///
    /// Kumbuka kuwa hii inatofautiana na tabia ya [`Rc::make_mut`] ambayo hutenganisha viashiria vyovyote vya `Weak` vilivyobaki.
    ///
    /// Tazama pia [`get_mut`][get_mut], ambayo itashindwa badala ya kuunda.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Haitabadilisha chochote
    /// let mut other_data = Arc::clone(&data); // Haitabadilisha data ya ndani
    /// *Arc::make_mut(&mut data) += 1;         // Takwimu za ndani za Clones
    /// *Arc::make_mut(&mut data) += 1;         // Haitabadilisha chochote
    /// *Arc::make_mut(&mut other_data) *= 2;   // Haitabadilisha chochote
    ///
    /// // Sasa `data` na `other_data` zinaelekeza kwa mgao tofauti.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Kumbuka kuwa tunashikilia rejea kali na rejeleo dhaifu.
        // Kwa hivyo, kutoa rejeleo letu kali sio tu, kwa yenyewe, itasababisha kumbukumbu kusambazwa.
        //
        // Tumia Pata ili kuhakikisha kuwa tunaona yeyote anaandika kwa `weak` ambayo hufanyika kabla ya kutolewa anaandika (yaani, kupungua) hadi `strong`.
        // Kwa kuwa tuna hesabu dhaifu, hakuna nafasi ArcInner yenyewe inaweza kusambazwa.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Kiashiria kingine chenye nguvu kipo, kwa hivyo lazima tugundike.
            // Tenga kumbukumbu mapema ili kuruhusu kuandika dhamana moja kwa moja.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Kutulia kunatosheleza hapo juu kwa sababu hii kimsingi ni utaftaji: sisi kila wakati tunakimbia na viashiria dhaifu vikiangushwa.
            // Kesi mbaya zaidi, tunaishia kutenga Arc mpya bila lazima.
            //

            // Tuliondoa kiboreshaji cha mwisho chenye nguvu, lakini kuna mabaki mengine dhaifu yaliyosalia.
            // Tutahamisha yaliyomo kwenye Safu mpya, na kubatilisha marekebisho mengine dhaifu.
            //

            // Kumbuka kuwa haiwezekani kwa kusoma kwa `weak` kutoa usize::MAX (yaani, imefungwa), kwani hesabu dhaifu inaweza kufungwa tu na uzi na rejeleo kali.
            //
            //

            // Tumia kiashiria chetu dhaifu dhaifu, ili iweze kusafisha ArcInner kama inahitajika.
            //
            let _weak = Weak { ptr: this.ptr };

            // Je! Unaweza kuiba data, kilichobaki ni Dhaifu
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Tulikuwa rejea pekee ya aina yoyote;rudisha nyuma hesabu kali ya kumbukumbu.
            //
            this.inner().strong.store(1, Release);
        }

        // Kama ilivyo kwa `get_mut()`, usalama ni sawa kwa sababu rejea yetu ilikuwa ya kipekee kwa kuanzia, au ikawa moja baada ya kuunda yaliyomo.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Hurejesha rejeleo linaloweza kubadilika katika `Arc` iliyopewa, ikiwa hakuna viashiria vingine vya `Arc` au [`Weak`] kwa mgao huo.
    ///
    ///
    /// Hurejesha [`None`] vinginevyo, kwa sababu sio salama kubadilisha thamani inayoshirikiwa.
    ///
    /// Tazama pia [`make_mut`][make_mut], ambayo itakuwa [`clone`][clone] thamani ya ndani wakati kuna vidokezo vingine.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ukosefu wa usalama huu ni sawa kwa sababu tumehakikishiwa kuwa pointer imerudishwa ni pointer *pekee* ambayo itarejeshwa kwa T.
            // Hesabu yetu ya rejeleo imehakikishiwa kuwa 1 kwa wakati huu, na tulihitaji Safu yenyewe kuwa `mut`, kwa hivyo tunarudisha rejeleo pekee linalowezekana kwa data ya ndani.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Hurejesha rejeleo inayoweza kubadilika katika `Arc` iliyotolewa, bila hundi yoyote.
    ///
    /// Tazama pia [`get_mut`], ambayo ni salama na inafanya ukaguzi unaofaa.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Viashiria vingine vyovyote vya `Arc` au [`Weak`] kwa mgao huo huo havipaswi kuonyeshwa tena kwa muda wa kukopa kurudi.
    ///
    /// Hii ni kesi ndogo ikiwa hakuna viashiria vile, kwa mfano mara tu baada ya `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tuko makini *sio* kuunda rejareja inayofunika uwanja wa "count", kwani hii ingekuwa jina moja na ufikiaji wa wakati mmoja kwa hesabu za kumbukumbu (kwa mfano.
        // na `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Tambua ikiwa hii ni rejeleo la kipekee (pamoja na refu dhaifu) kwa data ya msingi.
    ///
    ///
    /// Kumbuka kuwa hii inahitaji kufunga hesabu dhaifu ya kumbukumbu.
    fn is_unique(&mut self) -> bool {
        // funga hesabu dhaifu ya pointer ikiwa tunaonekana tu kuwa mmiliki dhaifu wa pointer.
        //
        // Lebo ya kupata hapa inahakikisha uhusiano wa mapema na mtu yeyote anaandika kwa `strong` (haswa katika `Weak::upgrade`) kabla ya kupungua kwa hesabu ya `weak` (kupitia `Weak::drop`, ambayo hutumia kutolewa).
        // Ikiwa kiboreshaji dhaifu kilichoboreshwa hakijawahi kushushwa, CAS hapa itashindwa kwa hivyo hatujali kusawazisha.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Hii inahitaji kuwa `Acquire` ili kusawazisha na upunguzaji wa kaunta ya `strong` katika `drop`-ufikiaji pekee ambao hufanyika wakati wowote isipokuwa rejeleo la mwisho linashushwa.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Kutolewa andika hapa kunalinganisha na kusoma katika `downgrade`, kuzuia vizuri kusoma hapo juu ya `strong` kutokea baada ya kuandika.
            //
            //
            self.inner().weak.store(1, Release); // toa kufuli
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Matone ya `Arc`.
    ///
    /// Hii itapunguza hesabu kubwa ya kumbukumbu.
    /// Ikiwa hesabu kubwa ya kumbukumbu hufikia sifuri basi marejeleo mengine pekee (ikiwa yapo) ni [`Weak`], kwa hivyo sisi `drop` thamani ya ndani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Haichapishi chochote
    /// drop(foo2);   // Kuchapisha "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Kwa sababu `fetch_sub` tayari ni ya atomiki, hatuhitaji kusawazisha na nyuzi zingine isipokuwa tutafuta kitu.
        // Mantiki hiyo hiyo inatumika kwa chini ya `fetch_sub` kwa hesabu ya `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Uzio huu unahitajika kuzuia upangaji upya wa utumiaji wa data na ufutaji wa data.
        // Kwa sababu imewekwa alama ya `Release`, kupungua kwa hesabu ya kumbukumbu kunalingana na uzio huu wa `Acquire`.
        // Hii inamaanisha kuwa utumiaji wa data hufanyika kabla ya kupungua kwa hesabu ya kumbukumbu, ambayo hufanyika kabla ya uzio huu, ambayo hufanyika kabla ya kufutwa kwa data.
        //
        // Kama ilivyoelezwa katika [Boost documentation][1],
        //
        // > Ni muhimu kutekeleza ufikiaji wowote unaowezekana wa kitu kwa moja
        // > thread (kupitia rejeleo iliyopo) ili kutokea kabla ya * kufuta
        // > kitu katika uzi tofauti.Hii inafanikiwa na "release"
        // > operesheni baada ya kuacha kumbukumbu (ufikiaji wowote wa kitu
        // > kupitia kumbukumbu hii lazima iwe ilitokea hapo awali), na
        // > "acquire" operesheni kabla ya kufuta kitu.
        //
        // Hasa, wakati yaliyomo kwenye Arc kawaida hayabadiliki, inawezekana kuwa na mambo ya ndani huandika kwa kitu kama Mutex<T>.
        // Kwa kuwa Mutex haipatikani wakati inafutwa, hatuwezi kutegemea mantiki yake ya maingiliano ili kuandika kwenye thread A inayoonekana kwa mwangamizi anayeendesha katika uzi B.
        //
        //
        // Pia kumbuka kuwa Pata uzio hapa pengine unaweza kubadilishwa na Pata mzigo, ambao unaweza kuboresha utendaji katika hali zinazoshindaniwa sana.Tazama [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Jaribio la kuangusha `Arc<dyn Any + Send + Sync>` kwa aina halisi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Inaunda `Weak<T>` mpya, bila kutenga kumbukumbu yoyote.
    /// Kupiga simu [`upgrade`] kwa thamani ya kurudi daima hutoa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Aina ya msaidizi kuruhusu kufikia hesabu za kumbukumbu bila kutoa madai yoyote juu ya uwanja wa data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Hurejesha pointer mbichi kwa kitu `T` kilichoelekezwa na `Weak<T>` hii.
    ///
    /// Kiashiria ni halali tu ikiwa kuna marejeleo madhubuti.
    /// Pointer inaweza kuwa inaning'inia, haijalinganishwa au hata [`null`] vinginevyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Wote huelekeza kwenye kitu kimoja
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Nguvu hapa huiweka hai, kwa hivyo tunaweza bado kupata kitu hicho.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Lakini sio zaidi.
    /// // Tunaweza kufanya weak.as_ptr(), lakini kufikia pointer kutasababisha tabia isiyojulikana.
    /// // assert_eq! ("hello", salama {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ikiwa pointer inaning'inia, tunarudisha sentinel moja kwa moja.
            // Hii haiwezi kuwa anwani halali ya malipo, kwani upakiaji wa malipo ni sawa kama ArcInner (usize).
            ptr as *const T
        } else {
            // USALAMA: ikiwa_kunyongwa kunarudi kwa uwongo, basi pointer haiwezi kutolewa.
            // Mshahara unaweza kutolewa kwa wakati huu, na tunapaswa kudumisha asili, kwa hivyo tumia ujanja wa pointer mbichi.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Inatumia `Weak<T>` na kuibadilisha kuwa pointer mbichi.
    ///
    /// Hii inabadilisha pointer dhaifu kuwa pointer mbichi, wakati bado inahifadhi umiliki wa kumbukumbu moja dhaifu (hesabu dhaifu haibadilishwa na operesheni hii).
    /// Inaweza kugeuzwa kuwa `Weak<T>` na [`from_raw`].
    ///
    /// Vikwazo vile vile vya kufikia lengo la pointer kama vile [`as_ptr`] inatumika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Inabadilisha pointer mbichi iliyoundwa hapo awali na [`into_raw`] kurudi `Weak<T>`.
    ///
    /// Hii inaweza kutumiwa kupata rejeleo kali (kwa kupiga simu [`upgrade`] baadaye) au kusambaza hesabu dhaifu kwa kuacha `Weak<T>`.
    ///
    /// Inachukua umiliki wa kumbukumbu moja dhaifu (isipokuwa vidokezo vilivyoundwa na [`new`], kwani hizi hazina chochote; njia bado inafanya kazi kwao).
    ///
    /// # Safety
    ///
    /// Kiashiria lazima kiwe kimetoka kwa [`into_raw`] na lazima bado kiwe na rejeleo lake dhaifu.
    ///
    /// Inaruhusiwa kwa hesabu kali kuwa 0 wakati wa kupiga simu hii.
    /// Walakini, hii inachukua umiliki wa rejelei moja dhaifu inayowakilishwa sasa kama kiboreshaji kibichi (hesabu dhaifu haibadilishwa na operesheni hii) na kwa hivyo inapaswa kuoanishwa na simu ya awali kwa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Punguza hesabu dhaifu ya mwisho.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tazama Weak::as_ptr kwa muktadha wa jinsi kielekezi cha kuingiza kinatokana.

        let ptr = if is_dangling(ptr as *mut T) {
            // Huu ni udhaifu wa kujinyonga.
            ptr as *mut ArcInner<T>
        } else {
            // Vinginevyo, tunahakikishiwa kuwa pointer ilitoka kwa Mtu dhaifu dhaifu.
            // USALAMA: data_offset ni salama kupiga simu, kwani ptr inarejelea halisi (inayoweza kudondoshwa) T.
            let offset = unsafe { data_offset(ptr) };
            // Kwa hivyo, tunabadilisha malipo ili kupata RcBox nzima.
            // USALAMA: pointer ilitoka kwa Dhaifu, kwa hivyo malipo haya ni salama.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // USALAMA: sasa tumepata pointer dhaifu ya asili, kwa hivyo tunaweza kuunda Wanyonge.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Jaribio la kuboresha pointer ya `Weak` hadi [`Arc`], kuchelewesha kushuka kwa thamani ya ndani ikiwa imefanikiwa.
    ///
    ///
    /// Hurejesha [`None`] ikiwa thamani ya ndani imeshuka tangu hapo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Kuharibu kuyatumia nguvu zote.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Tunatumia kitanzi cha CAS kuongeza hesabu kali badala ya fetch_add kwani kazi hii haipaswi kuchukua hesabu ya kumbukumbu kutoka sifuri hadi moja.
        //
        //
        let inner = self.inner()?;

        // Mzigo uliopumzika kwa sababu maandishi yoyote ya 0 ambayo tunaweza kuona yanaacha uwanja katika hali ya sifuri kabisa (kwa hivyo kusoma kwa "stale" ya 0 ni sawa), na dhamana nyingine yoyote imethibitishwa kupitia CAS hapa chini.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Tazama maoni katika `Arc::clone` kwa nini tunafanya hivyo (kwa `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Kutulia ni sawa kwa kesi ya kutofaulu kwa sababu hatuna matarajio yoyote juu ya serikali mpya.
            // Kupata ni muhimu kwa kesi ya kufanikiwa ili kusawazisha na `Arc::new_cyclic`, wakati thamani ya ndani inaweza kuanza baada ya rejeleo za `Weak` tayari kuundwa.
            // Katika kesi hiyo, tunatarajia kuona dhamana iliyoanzishwa kikamilifu.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null imechunguzwa hapo juu
                Err(old) => n = old,
            }
        }
    }

    /// Inapata idadi ya viashiria vikali vya (`Arc`) vinavyoelekeza kwenye mgao huu.
    ///
    /// Ikiwa `self` iliundwa kwa kutumia [`Weak::new`], hii itarudi 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Inapata makadirio ya idadi ya viashiria vya `Weak` vinavyoashiria mgao huu.
    ///
    /// Ikiwa `self` iliundwa kwa kutumia [`Weak::new`], au ikiwa hakuna viashiria vikali vilivyobaki, hii itarudi 0.
    ///
    /// # Accuracy
    ///
    /// Kwa sababu ya maelezo ya utekelezaji, thamani iliyorudishwa inaweza kuzimwa na 1 katika mwelekeo wowote wakati nyuzi zingine zinatumia `Arc`s au`Weak`s zinazoelekeza kwa mgao huo.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Kwa kuwa tuliona kuwa kulikuwa na kiboreshaji cha nguvu angalau moja baada ya kusoma hesabu dhaifu, tunajua kwamba kumbukumbu dhaifu kabisa (iliyopo wakati wowote marejeleo mazito yapo hai) ilikuwa bado karibu wakati tuliona hesabu dhaifu, na kwa hivyo tunaweza kuiondoa salama.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Inarudi `None` wakati pointer inaning'inia na hakuna `ArcInner` iliyotengwa, (yaani, wakati `Weak` hii iliundwa na `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tuko makini *sio* kuunda rejea inayofunika uwanja wa "data", kwani uwanja unaweza kubadilishwa kwa wakati mmoja (kwa mfano, ikiwa `Arc` ya mwisho imeshushwa, uwanja wa data utashushwa mahali).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Hurejesha `true` ikiwa `Weak` mbili zinaelekeza kwa mgao sawa (sawa na [`ptr::eq`]), au ikiwa zote mbili hazionyeshi mgao wowote (kwa sababu ziliundwa na `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kwa kuwa hii inalinganisha viashiria inamaanisha kuwa `Weak::new()` italingana, ingawa hazionyeshi mgao wowote.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Kulinganisha `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Inafanya mwamba wa pointer ya `Weak` inayoelekeza kwa mgao huo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Tazama maoni katika Arc::clone() kwa nini hii ni walishirikiana.
        // Hii inaweza kutumia fetch_add (kupuuza kufuli) kwa sababu hesabu dhaifu imefungwa tu ambapo hakuna vidokezo vingine dhaifu.
        //
        // (Kwa hivyo hatuwezi kutumia nambari hii kwa hali hiyo).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Tazama maoni katika Arc::clone() kwa nini tunafanya hivyo (kwa mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Inaunda `Weak<T>` mpya, bila kutenga kumbukumbu.
    /// Kupiga simu [`upgrade`] kwa thamani ya kurudi daima hutoa [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Matone pointer `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Haichapishi chochote
    /// drop(foo);        // Kuchapisha "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ikiwa tutagundua kuwa tulikuwa pointer dhaifu dhaifu, basi wakati wake wa kusambaza data kabisa.Tazama majadiliano katika Arc::drop() juu ya agizo la kumbukumbu
        //
        // Sio lazima kuangalia hali iliyofungwa hapa, kwa sababu hesabu dhaifu inaweza kufungwa tu ikiwa kulikuwa na kiboreshaji dhaifu moja, ikimaanisha kuwa kushuka kunaweza tu kuendeshea ile iliyobaki dhaifu, ambayo inaweza kutokea tu baada ya kufuli kutolewa.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Tunafanya utaalam huu hapa, na sio kama utaftaji wa jumla kwa `&T`, kwa sababu ingeongeza gharama kwa ukaguzi wote wa usawa kwenye Ref.
/// Tunafikiria kuwa `Arc`s hutumiwa kuhifadhi maadili makubwa, ambayo ni polepole kushikilia, lakini pia ni nzito kuangalia usawa, na kusababisha gharama hii kulipa kwa urahisi zaidi.
///
/// Ina uwezekano mkubwa zaidi kuwa na viini viwili vya `Arc`, vinavyoelekeza kwa thamani sawa, kuliko `&T`s mbili.
///
/// Tunaweza tu kufanya hivyo wakati `T: Eq` kama `PartialEq` inaweza kuwa isiyofaa kwa makusudi.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Usawa kwa `Arc`s mbili.
    ///
    /// `Arc`s mbili ni sawa ikiwa maadili yao ya ndani ni sawa, hata ikiwa yamehifadhiwa katika mgawanyo tofauti.
    ///
    /// Ikiwa `T` pia inatumiza `Eq` (ikimaanisha kutafakari kwa usawa), `Arc` mbili ambazo zinaonyesha mgawanyo huo huo huwa sawa kila wakati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ukosefu wa usawa kwa `Arc`s mbili.
    ///
    /// `Arc`s mbili hazina usawa ikiwa maadili yao ya ndani hayalingani.
    ///
    /// Ikiwa `T` pia inatumiza `Eq` (ikimaanisha kutafakari kwa usawa), `Arc` mbili ambazo zinaonyesha thamani sawa hazilingani kamwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Ulinganisho wa sehemu kwa `Arc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `partial_cmp()` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Chini ya kulinganisha kwa `Arc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `<` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Chini ya au sawa na' kulinganisha kwa `Arc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `<=` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Kubwa kuliko kulinganisha kwa `Arc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `>` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Mkubwa kuliko au sawa na' kulinganisha kwa `Arc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `>=` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Kulinganisha kwa `Arc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `cmp()` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Inaunda `Arc<T>` mpya, na thamani ya `Default` ya `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Tenga kipande kilichohesabiwa cha kumbukumbu na ujaze kwa kuorodhesha vitu vya `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Tenga `str` iliyohesabiwa kumbukumbu na nakili `v` ndani yake.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Tenga `str` iliyohesabiwa kumbukumbu na nakili `v` ndani yake.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Sogeza kitu kilichowekwa kwenye sanduku kwa mgawanyo mpya, uliohesabiwa kumbukumbu
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Tenga kipande kilichohesabiwa cha kumbukumbu na uhamishe vitu vya `v 'ndani yake.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Ruhusu Vec kutolewa kumbukumbu yake, lakini isiharibu yaliyomo
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Inachukua kila kitu kwenye `Iterator` na inakusanya katika `Arc<[T]>`.
    ///
    /// # Tabia za utendaji
    ///
    /// ## Kesi ya jumla
    ///
    /// Katika hali ya jumla, kukusanya katika `Arc<[T]>` hufanywa kwa kukusanya kwanza kwenye `Vec<T>`.Hiyo ni, wakati wa kuandika yafuatayo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// hii ni kama tunavyoandika:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Seti ya kwanza ya mgao hufanyika hapa.
    ///     .into(); // Mgawo wa pili wa `Arc<[T]>` hufanyika hapa.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Hii itatenga mara nyingi kama inahitajika kwa kuunda `Vec<T>` na kisha itatenga mara moja kwa kugeuza `Vec<T>` kuwa `Arc<[T]>`.
    ///
    ///
    /// ## Iterators ya urefu unaojulikana
    ///
    /// Wakati `Iterator` yako inatumiza `TrustedLen` na ina ukubwa halisi, mgao mmoja utafanywa kwa `Arc<[T]>`.Kwa mfano:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Mgao mmoja tu hufanyika hapa.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Umaalumu trait uliotumika kukusanya katika `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Hii ndio kesi ya iterator ya `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // USALAMA: Tunahitaji kuhakikisha kuwa iterator ina urefu halisi na tunao.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Rudi kwenye utekelezaji wa kawaida.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Pata malipo ndani ya `ArcInner` kwa upakiaji wa malipo nyuma ya pointer.
///
/// # Safety
///
/// Kiashiria lazima kielekeze (na kuwa na metadata halali ya) mfano halali wa hapo awali wa T, lakini T inaruhusiwa kutolewa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Patanisha thamani isiyo na ukubwa hadi mwisho wa ArcInner.
    // Kwa sababu RcBox ni repr(C), daima itakuwa uwanja wa mwisho kwenye kumbukumbu.
    // USALAMA: kwa kuwa aina pekee ambazo hazina ukubwa ni vipande, vitu vya trait,
    // na aina za nje, mahitaji ya usalama wa pembejeo kwa sasa yanatosha kukidhi mahitaji ya align_of_val_raw;hii ni maelezo ya utekelezaji wa lugha ambayo haiwezi kutegemewa nje ya std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}