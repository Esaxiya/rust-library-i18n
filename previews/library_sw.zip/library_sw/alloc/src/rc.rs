//! Vidokezo vya kuhesabu rejelezi moja.'Rc' inasimama kwa 'Rejea.'
//! Counted'.
//!
//! Aina [`Rc<T>`][`Rc`] hutoa umiliki wa pamoja wa thamani ya aina `T`, iliyotengwa katika lundo.
//! Kuingiza [`clone`][clone] kwenye [`Rc`] hutoa kiboreshaji kipya kwa mgao huo katika chungu.
//! Wakati pointer ya mwisho ya [`Rc`] kwa mgao uliopewa imeharibiwa, thamani iliyohifadhiwa katika mgao huo (mara nyingi hujulikana kama "inner value") pia imeshuka.
//!
//! Marejeleo yaliyoshirikiwa katika Rust hairuhusu mabadiliko kwa chaguo-msingi, na [`Rc`] sio ubaguzi: kwa ujumla huwezi kupata rejeleo linaloweza kubadilika kwa kitu ndani ya [`Rc`].
//! Ikiwa unahitaji mabadiliko, weka [`Cell`] au [`RefCell`] ndani ya [`Rc`];tazama [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] hutumia hesabu ya rejeleo isiyo ya atomiki.
//! Hii inamaanisha kuwa kichwa ni kidogo sana, lakini [`Rc`] haiwezi kutumwa kati ya nyuzi, na kwa hivyo [`Rc`] haitekelezi [`Send`][send].
//! Kama matokeo, mkusanyaji wa Rust ataangalia *wakati wa kukusanya* kwamba hutumii [`Rc`] kati ya nyuzi.
//! Ikiwa unahitaji nyuzi nyingi, hesabu ya kumbukumbu ya atomiki, tumia [`sync::Arc`][arc].
//!
//! Njia ya [`downgrade`][downgrade] inaweza kutumika kuunda pointer ya [`Weak`] isiyomiliki.
//! Kiashiria cha [`Weak`] kinaweza kuwa ["kuboresha"][kuboresha] d hadi [`Rc`], lakini hii itarudi [`None`] ikiwa thamani iliyohifadhiwa katika mgao tayari imeshuka.
//! Kwa maneno mengine, viashiria vya `Weak` havihifadhi thamani ndani ya mgao hai;Walakini, wao *hufanya* kuweka ugawaji (duka linalounga mkono kwa thamani ya ndani) liwe hai.
//!
//! Mzunguko kati ya viashiria vya [`Rc`] hautasambazwa kamwe.
//! Kwa sababu hii, [`Weak`] hutumiwa kuvunja mizunguko.
//! Kwa mfano, mti unaweza kuwa na viashiria vikali vya [`Rc`] kutoka nodi za wazazi hadi watoto, na viashiria vya [`Weak`] kutoka kwa watoto kurudi kwa wazazi wao.
//!
//! `Rc<T>` marejeleo ya moja kwa moja kwa `T` (kupitia [`Deref`] trait), kwa hivyo unaweza kupiga njia za `T` juu ya thamani ya aina [`Rc<T>`][`Rc`].
//! Ili kuzuia mabishano ya jina na njia za `T, mbinu za [`Rc<T>`][`Rc`] yenyewe ni kazi zinazohusiana, zinazoitwa kutumia [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Utekelezaji wa traits kama `Clone` pia inaweza kuitwa kutumia syntax iliyostahili kabisa.
//! Watu wengine wanapendelea kutumia sintaksia iliyostahili kabisa, wakati wengine wanapendelea kutumia syntax ya njia-wito.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Njia ya kupiga simu syntax
//! let rc2 = rc.clone();
//! // Sintaksia yenye sifa kamili
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] haionyeshi kiotomatiki kwa `T`, kwa sababu thamani ya ndani inaweza kuwa tayari imeshuka.
//!
//! # Marejeleo ya kuunda
//!
//! Kuunda rejeleo mpya kwa mgao sawa na kiashiria kilichopo cha kuhesabiwa kumbukumbu hufanywa kwa kutumia `Clone` trait iliyotekelezwa kwa [`Rc<T>`][`Rc`] na [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Sintaksia mbili hapa chini ni sawa.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a na b zote zinaelekeza kwenye eneo sawa la kumbukumbu kama foo.
//! ```
//!
//! Sintaksia ya `Rc::clone(&from)` ndio ya ujinga zaidi kwa sababu inatoa wazi zaidi maana ya nambari.
//! Katika mfano hapo juu, sintaksia hii inafanya iwe rahisi kuona kuwa nambari hii inaunda kumbukumbu mpya badala ya kunakili yaliyomo yote ya foo.
//!
//! # Examples
//!
//! Fikiria hali ambapo seti ya "Gadget" inamilikiwa na `Owner` iliyopewa.
//! Tunataka kuwa na "Gadget" yetu inayoelekeza kwa `Owner` yao.Hatuwezi kufanya hivyo kwa umiliki wa kipekee, kwa sababu zaidi ya kifaa kimoja kinaweza kuwa cha `Owner` sawa.
//! [`Rc`] inaturuhusu kushiriki `Owner` kati ya `Gadget`s nyingi, na kuwa na `Owner` kubaki imetengwa kwa muda mrefu kama alama yoyote ya `Gadget` iko.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... nyanja zingine
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... nyanja zingine
//! }
//!
//! fn main() {
//!     // Unda kumbukumbu iliyohesabiwa ya `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Unda "Vifaa" vya `gadget_owner`.
//!     // Kuunganisha `Rc<Owner>` hutupatia pointer mpya kwa mgao huo wa `Owner`, kuongeza hesabu ya kumbukumbu katika mchakato.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Tupa anuwai yetu ya ndani `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Licha ya kuacha `gadget_owner`, bado tunaweza kuchapisha jina la `Owner` ya `Gadget`s.
//!     // Hii ni kwa sababu tumeacha `Rc<Owner>` moja tu, sio `Owner` inayoelekeza.
//!     // Ilimradi kuna `Rc<Owner>` nyingine inayoonyesha mgao huo wa `Owner`, itabaki hai.
//!     // Makadirio ya uwanja `gadget1.owner.name` hufanya kazi kwa sababu `Rc<Owner>` hurejelea kiatomati kwa `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Mwisho wa kazi, `gadget1` na `gadget2` zinaharibiwa, na kumbukumbu za mwisho zilizohesabiwa kwa `Owner` yetu.
//!     // Gadget Man sasa anaharibiwa pia.
//!     //
//! }
//! ```
//!
//! Ikiwa mahitaji yetu yatabadilika, na tunahitaji pia kuvuka kutoka `Owner` hadi `Gadget`, tutapata shida.
//! Kiashiria cha [`Rc`] kutoka `Owner` hadi `Gadget` huanzisha mzunguko.
//! Hii inamaanisha kwamba hesabu zao za kumbukumbu haziwezi kufikia 0, na mgao hautaangamizwa kamwe:
//! kuvuja kumbukumbu.Ili kuzunguka hii, tunaweza kutumia viashiria vya [`Weak`].
//!
//! Rust kweli inafanya iwe ngumu kutoa kitanzi hiki kwanza.Ili kuishia na maadili mawili ambayo yanaelekeana, moja yao inahitaji kubadilika.
//! Hii ni ngumu kwa sababu [`Rc`] inalazimisha usalama wa kumbukumbu kwa kutoa tu marejeleo ya pamoja ya dhamana inayofungwa, na hizi haziruhusu mabadiliko ya moja kwa moja.
//! Tunahitaji kufunika sehemu ya thamani tunayotaka kubadilisha katika [`RefCell`], ambayo hutoa *mabadiliko ya ndani*: njia ya kufikia mabadiliko kupitia rejeleo la pamoja.
//! [`RefCell`] huimarisha sheria za kukopa za Rust wakati wa kukimbia.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... nyanja zingine
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... nyanja zingine
//! }
//!
//! fn main() {
//!     // Unda kumbukumbu iliyohesabiwa ya `Owner`.
//!     // Kumbuka kuwa tumeweka vector ya "Mmiliki" ya "Gadget" ndani ya `RefCell` ili tuweze kuibadilisha kupitia rejeleo la pamoja.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Unda "Vifaa" vya `gadget_owner`, kama hapo awali.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Ongeza `Gadget` kwenye `Owner` yao.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` nguvu ya kukopa inaishia hapa.
//!     }
//!
//!     // Iterate juu ya `Gadget`s yetu, kuchapa maelezo yao nje.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ni `Weak<Gadget>`.
//!         // Kwa kuwa viashiria vya `Weak` haviwezi kuhakikisha kuwa mgao bado upo, tunahitaji kupiga `upgrade`, ambayo inarudi `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Katika kesi hii tunajua mgao bado upo, kwa hivyo sisi tu `unwrap` `Option`.
//!         // Katika programu ngumu zaidi, unaweza kuhitaji utunzaji wa makosa ya neema kwa matokeo ya `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Mwisho wa kazi, `gadget_owner`, `gadget1`, na `gadget2` zinaharibiwa.
//!     // Sasa hakuna viashiria vikali vya (`Rc`) kwa vidude, kwa hivyo vinaharibiwa.
//!     // Zero hizi zinahesabu hesabu ya Gadget Man, kwa hivyo yeye pia huharibiwa.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Hii ni repr(C) hadi future-ushahidi dhidi ya upangaji wa uwanja unaowezekana, ambao utaingiliana na [into|from]_raw() salama ya aina za ndani zinazoweza kupitishwa.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Kiashiria kimoja cha kuhesabu rejeleo.'Rc' inasimama kwa 'Rejea.'
/// Counted'.
///
/// Tazama [module-level documentation](./index.html) kwa maelezo zaidi.
///
/// Mbinu za asili za `Rc` zote ni kazi zinazohusiana, ambayo inamaanisha kuwa lazima uwaite kama, [`Rc::get_mut(&mut value)`][get_mut] badala ya `value.get_mut()`.
/// Hii inepuka migongano na njia za aina ya ndani `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ukosefu wa usalama huu ni sawa kwa sababu wakati Rc huyu yuko hai tunahakikishiwa kuwa pointer ya ndani ni halali.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Inaunda `Rc<T>` mpya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Kuna pointer dhaifu isiyo na kifani inayomilikiwa na viashiria vyote vikali, ambayo inahakikisha kwamba mwangamizi dhaifu kamwe haachilii mgao wakati mwangamizi mwenye nguvu anaendesha, hata kama pointer dhaifu imehifadhiwa ndani ya ile yenye nguvu.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Inaunda `Rc<T>` mpya kwa kutumia rejista dhaifu kwa yenyewe.
    /// Kujaribu kuboresha marejeleo dhaifu kabla ya kazi hii kurudi itasababisha thamani ya `None`.
    ///
    /// Walakini, rejeleo dhaifu linaweza kuumbwa kwa uhuru na kuhifadhiwa kwa matumizi baadaye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // Mashamba zaidi
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Jenga ya ndani katika jimbo la "uninitialized" na kumbukumbu moja dhaifu.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ni muhimu tusiachane na umiliki wa pointer dhaifu, au sivyo kumbukumbu inaweza kutolewa wakati `data_fn` inarudi.
        // Ikiwa kweli tunataka kupitisha umiliki, tunaweza kujiboresha kiashiria dhaifu, lakini hii itasababisha sasisho za ziada kwa hesabu dhaifu ya rejeleo ambayo inaweza kuwa sio lazima vinginevyo.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Marejeleo yenye nguvu yanapaswa kwa pamoja kumiliki rejelei dhaifu iliyoshirikiwa, kwa hivyo usiendeshe uharibifu kwa rejeleo letu dhaifu la zamani.
        //
        mem::forget(weak);
        strong
    }

    /// Inaunda `Rc` mpya na yaliyomo ambayo hayajaanza.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Inaunda `Rc` mpya na yaliyomo ambayo hayajaanza, na kumbukumbu imejazwa na ka `0`.
    ///
    ///
    /// Tazama [`MaybeUninit::zeroed`][zeroed] kwa mifano ya matumizi sahihi na yasiyo sahihi ya njia hii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Huunda `Rc<T>` mpya, ikirudisha hitilafu ikiwa mgao unashindwa
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Kuna pointer dhaifu isiyo na kifani inayomilikiwa na viashiria vyote vikali, ambayo inahakikisha kwamba mwangamizi dhaifu kamwe haachilii mgao wakati mwangamizi mwenye nguvu anaendesha, hata kama pointer dhaifu imehifadhiwa ndani ya ile yenye nguvu.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Inaunda `Rc` mpya na yaliyomo ambayo hayajaanza, inarudi kosa ikiwa mgawanyo hautafanikiwa
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Inaunda `Rc` mpya na yaliyomo ambayo hayajaanza, na kumbukumbu imejazwa na ka `0`, ikirudisha kosa ikiwa mgawanyo haukufaulu
    ///
    ///
    /// Tazama [`MaybeUninit::zeroed`][zeroed] kwa mifano ya matumizi sahihi na yasiyo sahihi ya njia hii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Inaunda `Pin<Rc<T>>` mpya.
    /// Ikiwa `T` haitekelezi `Unpin`, basi `value` itapachikwa kwenye kumbukumbu na haiwezi kuhamishwa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Hurejesha thamani ya ndani, ikiwa `Rc` ina kumbukumbu moja kali.
    ///
    /// Vinginevyo, [`Err`] inarejeshwa na `Rc` ile ile ambayo ilipitishwa.
    ///
    ///
    /// Hii itafaulu hata ikiwa kuna marejeleo dhaifu dhaifu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // nakili kitu kilichomo

                // Onyesha Wanyonge kwamba hawawezi kukuzwa kwa kupunguza hesabu kali, na kisha uondoe kiashiria wazi cha "strong weak" wakati pia unashughulikia mantiki ya kushuka kwa kuunda tu Dhaifu bandia.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Inaunda kipande kipya kilichohesabiwa rejea na yaliyomo ambayo hayajaanzishwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Inaunda kipande kipya kilichohesabiwa na kumbukumbu na yaliyomo ambayo hayajaanza, na kumbukumbu imejazwa na ka `0`.
    ///
    ///
    /// Tazama [`MaybeUninit::zeroed`][zeroed] kwa mifano ya matumizi sahihi na yasiyo sahihi ya njia hii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Inabadilisha kuwa `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Kama ilivyo kwa [`MaybeUninit::assume_init`], ni juu ya mpigaji kuhakikisha kwamba thamani ya ndani kweli iko katika hali iliyoanzishwa.
    ///
    /// Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Inabadilisha kuwa `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kama ilivyo kwa [`MaybeUninit::assume_init`], ni juu ya mpigaji kuhakikisha kwamba thamani ya ndani kweli iko katika hali iliyoanzishwa.
    ///
    /// Kupiga simu hii wakati yaliyomo bado hayajakamilishwa kikamilifu husababisha tabia isiyojulikana.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uanzishaji uliochaguliwa:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Inatumia `Rc`, ikirudisha pointer iliyofungwa.
    ///
    /// Ili kuzuia kuvuja kwa kumbukumbu pointer lazima ibadilishwe kuwa `Rc` kwa kutumia [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Hutoa pointer mbichi kwa data.
    ///
    /// Hesabu haziathiriwi kwa njia yoyote na `Rc` haitumiwi.
    /// Kiashiria ni halali kwa muda mrefu kuna hesabu kali katika `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // USALAMA: Hii haiwezi kupitia Deref::deref au Rc::inner kwa sababu
        // hii inahitajika kuhifadhi asili ya raw/mut kama vile mfano
        // `get_mut` unaweza kuandika kupitia pointer baada ya Rc kurejeshwa kupitia `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Inaunda `Rc<T>` kutoka kwa pointer mbichi.
    ///
    /// Kiashiria mbichi lazima kilirudishwa hapo awali na simu kwa [`Rc<U>::into_raw`][into_raw] ambapo `U` lazima iwe na saizi sawa na mpangilio kama `T`.
    /// Hii ni kweli kidogo ikiwa `U` ni `T`.
    /// Kumbuka kuwa ikiwa `U` sio `T` lakini ina ukubwa sawa na mpangilio, hii kimsingi ni kama kusambaza marejeleo ya aina tofauti.
    /// Tazama [`mem::transmute`][transmute] kwa habari zaidi juu ya vizuizi vipi vinavyotumika katika kesi hii.
    ///
    /// Mtumiaji wa `from_raw` lazima ahakikishe thamani maalum ya `T` imeshuka mara moja tu.
    ///
    /// Kazi hii sio salama kwa sababu matumizi yasiyofaa yanaweza kusababisha usalama wa kumbukumbu, hata ikiwa `Rc<T>` iliyorudishwa haipatikani kamwe.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Badilisha hadi `Rc` kuzuia kuvuja.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Simu zaidi kwa `Rc::from_raw(x_ptr)` itakuwa salama-kumbukumbu.
    /// }
    ///
    /// // Kumbukumbu iliachiliwa wakati `x` ilitoka kwa wigo hapo juu, kwa hivyo `x_ptr` sasa inaning'inia!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Rekebisha malipo ili upate RcBox asili.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Inaunda pointer mpya ya [`Weak`] kwa mgao huu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Hakikisha hatuunda dhaifu
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Inapata idadi ya viashiria vya [`Weak`] kwa mgao huu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Inapata idadi ya viashiria vikali vya (`Rc`) kwa mgao huu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Hurejesha `true` ikiwa hakuna viashiria vingine vya `Rc` au [`Weak`] kwa mgao huu.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Hurejesha rejeleo linaloweza kubadilika katika `Rc` iliyopewa, ikiwa hakuna viashiria vingine vya `Rc` au [`Weak`] kwa mgao huo.
    ///
    ///
    /// Hurejesha [`None`] vinginevyo, kwa sababu sio salama kubadilisha thamani inayoshirikiwa.
    ///
    /// Tazama pia [`make_mut`][make_mut], ambayo itakuwa [`clone`][clone] thamani ya ndani wakati kuna vidokezo vingine.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Hurejesha rejeleo inayoweza kubadilika katika `Rc` iliyotolewa, bila hundi yoyote.
    ///
    /// Tazama pia [`get_mut`], ambayo ni salama na inafanya ukaguzi unaofaa.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Viashiria vingine vyovyote vya `Rc` au [`Weak`] kwa mgao huo huo havipaswi kuonyeshwa tena kwa muda wa kukopa kurudi.
    ///
    /// Hii ni kesi ndogo ikiwa hakuna viashiria vile, kwa mfano mara tu baada ya `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tuko makini *sio* kuunda rejareja inayofunika uwanja wa "count", kwani hii itapingana na ufikiaji wa hesabu za kumbukumbu (mf.
        // na `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Hurejesha `true` ikiwa `Rc` mbili zinaelekeza kwa mgao huo (kwa mshipa sawa na [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Inafanya rejeleo inayoweza kubadilika katika `Rc` iliyopewa.
    ///
    /// Ikiwa kuna viashiria vingine vya `Rc` kwa mgao huo huo, basi `make_mut` itakuwa [`clone`] thamani ya ndani kwa mgawanyo mpya ili kuhakikisha umiliki wa kipekee.
    /// Hii pia inajulikana kama clone-on-write.
    ///
    /// Ikiwa hakuna viashiria vingine vya `Rc` kwa mgao huu, basi viashiria vya [`Weak`] kwa mgawanyo huu vitaachwa.
    ///
    /// Tazama pia [`get_mut`], ambayo itashindwa badala ya kuunda.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Haitabadilisha chochote
    /// let mut other_data = Rc::clone(&data);    // Haitabadilisha data ya ndani
    /// *Rc::make_mut(&mut data) += 1;        // Takwimu za ndani za Clones
    /// *Rc::make_mut(&mut data) += 1;        // Haitabadilisha chochote
    /// *Rc::make_mut(&mut other_data) *= 2;  // Haitabadilisha chochote
    ///
    /// // Sasa `data` na `other_data` zinaelekeza kwa mgao tofauti.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] vidokezo vitaachwa:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Umepata data, kuna Rcs zingine.
            // Tenga kumbukumbu mapema ili kuruhusu kuandika dhamana moja kwa moja.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Je! Unaweza kuiba data, kilichobaki ni Dhaifu
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Ondoa nguvu kamili dhaifu (hakuna haja ya kutengeneza Dhaifu bandia hapa-tunajua Wanyonge wengine wanaweza kutusafishia)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ukosefu wa usalama huu ni sawa kwa sababu tumehakikishiwa kuwa pointer imerudishwa ni pointer *pekee* ambayo itarejeshwa kwa T.
        // Hesabu yetu ya rejeleo imehakikishiwa kuwa 1 kwa wakati huu, na tulihitaji `Rc<T>` yenyewe iwe `mut`, kwa hivyo tunarudisha rejeleo pekee linalowezekana kwa mgao.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Jaribio la kuangusha `Rc<dyn Any>` kwa aina halisi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Hutenga `RcBox<T>` na nafasi ya kutosha kwa thamani ya ndani isiyo na ukubwa ambapo thamani ina mpangilio uliyopewa.
    ///
    /// Kazi `mem_to_rcbox` inaitwa na pointer ya data na lazima irudishe tena (uwezekano wa mafuta)-mtaalam wa `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Hesabu mpangilio ukitumia mpangilio wa thamani uliopewa.
        // Hapo awali, mpangilio ulihesabiwa juu ya usemi wa `&*(ptr as* const RcBox<T>)`, lakini hii iliunda rejeleo lililopangwa vibaya (tazama #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Hutenga `RcBox<T>` na nafasi ya kutosha kwa thamani ya ndani isiyo na ukubwa ambapo thamani ina mpangilio uliyopewa, kurudisha kosa ikiwa mgawanyiko unashindwa.
    ///
    ///
    /// Kazi `mem_to_rcbox` inaitwa na pointer ya data na lazima irudishe tena (uwezekano wa mafuta)-mtaalam wa `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Hesabu mpangilio ukitumia mpangilio wa thamani uliopewa.
        // Hapo awali, mpangilio ulihesabiwa juu ya usemi wa `&*(ptr as* const RcBox<T>)`, lakini hii iliunda rejeleo lililopangwa vibaya (tazama #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Tenga kwa mpangilio.
        let ptr = allocate(layout)?;

        // Anzisha RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Hutenga `RcBox<T>` na nafasi ya kutosha kwa thamani ya ndani isiyo na ukubwa
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Tenga kwa `RcBox<T>` ukitumia thamani uliyopewa.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nakili thamani kama ka
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Bure mgao bila kuacha yaliyomo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Hutenga `RcBox<[T]>` na urefu uliopewa.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Nakili vipengee kutoka kipande hadi Rc mpya\\[T\]>
    ///
    /// Sio salama kwa sababu mpigaji lazima lazima achukue umiliki au afunge `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Inaunda `Rc<[T]>` kutoka kwa iterator inayojulikana kuwa ya saizi fulani.
    ///
    /// Tabia haijafafanuliwa ikiwa saizi itakuwa mbaya.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Mlinzi wa Panic wakati wa kuunda vitu vya T.
        // Katika tukio la panic, vitu ambavyo vimeandikwa kwenye RcBox mpya vitaondolewa, kisha kumbukumbu itafunguliwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Kielekezi kwa kipengee cha kwanza
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Yote wazi.Kusahau mlinzi ili isiwe huru RcBox mpya.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Utaalam trait kutumika kwa `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Matone ya `Rc`.
    ///
    /// Hii itapunguza hesabu kubwa ya kumbukumbu.
    /// Ikiwa hesabu kubwa ya kumbukumbu hufikia sifuri basi marejeleo mengine pekee (ikiwa yapo) ni [`Weak`], kwa hivyo sisi `drop` thamani ya ndani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Haichapishi chochote
    /// drop(foo2);   // Kuchapisha "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // kuharibu kitu kilichomo
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ondoa kiashiria wazi cha "strong weak" sasa kwa kuwa tumeharibu yaliyomo.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Inafanya mwamba wa pointer ya `Rc`.
    ///
    /// Hii inaunda kiboreshaji kingine kwa mgao huo huo, ikiongeza hesabu kubwa ya kumbukumbu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Inaunda `Rc<T>` mpya, na thamani ya `Default` ya `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack kuruhusu mtaalamu wa `Eq` ingawa `Eq` ina njia.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Tunafanya utaalam huu hapa, na sio kama utaftaji wa jumla kwa `&T`, kwa sababu ingeongeza gharama kwa ukaguzi wote wa usawa kwenye Ref.
/// Tunafikiria kuwa `Rc`s hutumiwa kuhifadhi maadili makubwa, ambayo ni polepole kushikilia, lakini pia ni nzito kuangalia usawa, na kusababisha gharama hii kulipa kwa urahisi zaidi.
///
/// Ina uwezekano mkubwa zaidi kuwa na viini viwili vya `Rc`, vinavyoelekeza kwa thamani sawa, kuliko `&T`s mbili.
///
/// Tunaweza tu kufanya hivyo wakati `T: Eq` kama `PartialEq` inaweza kuwa isiyofaa kwa makusudi.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Usawa kwa `Rc`s mbili.
    ///
    /// `Rc`s mbili ni sawa ikiwa maadili yao ya ndani ni sawa, hata ikiwa yamehifadhiwa katika mgawanyo tofauti.
    ///
    /// Ikiwa `T` pia hutumia `Eq` (ikimaanisha kutafakari kwa usawa), `Rc`s mbili ambazo zinaelekeza kwa mgawanyo huo huo huwa sawa kila wakati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ukosefu wa usawa kwa `Rc`s mbili.
    ///
    /// `Rc`s mbili hazina usawa ikiwa maadili yao ya ndani hayalingani.
    ///
    /// Ikiwa `T` pia inatumiza `Eq` (ikimaanisha kutafakari kwa usawa), `Rc` mbili ambazo zinaelezea mgawanyo huo huo kamwe hazilingani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Ulinganisho wa sehemu kwa `Rc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `partial_cmp()` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Chini ya kulinganisha kwa `Rc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `<` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Chini ya au sawa na' kulinganisha kwa `Rc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `<=` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Mkubwa zaidi kuliko kulinganisha kwa `Rc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `>` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Mkubwa kuliko au sawa na' kulinganisha kwa `Rc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `>=` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Kulinganisha kwa `Rc`s mbili.
    ///
    /// Wawili hao wanalinganishwa na kupiga `cmp()` juu ya maadili yao ya ndani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Tenga kipande kilichohesabiwa cha kumbukumbu na ujaze kwa kuorodhesha vitu vya `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Tenga kipande cha kamba kilichohesabiwa kwa kumbukumbu na nakili `v` ndani yake.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Tenga kipande cha kamba kilichohesabiwa kwa kumbukumbu na nakili `v` ndani yake.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Sogeza kitu kilichowekwa kwenye sanduku kwa mgao mpya, uliohesabiwa kumbukumbu, mgawanyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Tenga kipande kilichohesabiwa cha kumbukumbu na uhamishe vitu vya `v 'ndani yake.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Ruhusu Vec kutolewa kumbukumbu yake, lakini isiharibu yaliyomo
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Inachukua kila kitu kwenye `Iterator` na inakusanya katika `Rc<[T]>`.
    ///
    /// # Tabia za utendaji
    ///
    /// ## Kesi ya jumla
    ///
    /// Katika hali ya jumla, kukusanya katika `Rc<[T]>` hufanywa kwa kukusanya kwanza kwenye `Vec<T>`.Hiyo ni, wakati wa kuandika yafuatayo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// hii ni kama tunavyoandika:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Seti ya kwanza ya mgao hufanyika hapa.
    ///     .into(); // Mgawo wa pili wa `Rc<[T]>` hufanyika hapa.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Hii itatenga mara nyingi kama inahitajika kwa kuunda `Vec<T>` na kisha itatenga mara moja kwa kugeuza `Vec<T>` kuwa `Rc<[T]>`.
    ///
    ///
    /// ## Iterators ya urefu unaojulikana
    ///
    /// Wakati `Iterator` yako inatumiza `TrustedLen` na ina ukubwa halisi, mgao mmoja utafanywa kwa `Rc<[T]>`.Kwa mfano:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Mgao mmoja tu hufanyika hapa.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Utaalam trait kutumika kwa kukusanya katika `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Hii ndio kesi ya iterator ya `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // USALAMA: Tunahitaji kuhakikisha kuwa iterator ina urefu halisi na tunao.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Rudi kwenye utekelezaji wa kawaida.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ni toleo la [`Rc`] ambalo lina kumbukumbu isiyo ya kumiliki mgao uliosimamiwa.Mgawo huo unapatikana kwa kupiga simu [`upgrade`] kwenye kidokezo cha `Weak`, ambacho kinarudisha [`Chaguo`]`<<[[Rc`] `<T>>".
///
/// Kwa kuwa rejeleo la `Weak` halizingatii umiliki, halitazuia dhamana iliyohifadhiwa katika mgao kuteremshwa, na `Weak` yenyewe haitoi dhamana juu ya dhamana ambayo bado iko.
/// Kwa hivyo inaweza kurudisha [`None`] wakati [`kuboresha"] d.
/// Kumbuka hata hivyo kwamba kumbukumbu ya `Weak` * inazuia ugawaji wenyewe (duka la kuunga mkono) lisihamishwe.
///
/// Kiashiria cha `Weak` ni muhimu kwa kuweka kumbukumbu ya muda kwa mgao unaosimamiwa na [`Rc`] bila kuzuia thamani yake ya ndani ishuzwe.
/// Inatumika pia kuzuia marejeleo ya duara kati ya viashiria vya [`Rc`], kwani marejeleo ya umiliki wa pande zote hayangeruhusu [`Rc`] kutupwa.
/// Kwa mfano, mti unaweza kuwa na viashiria vikali vya [`Rc`] kutoka nodi za wazazi hadi watoto, na viashiria vya `Weak` kutoka kwa watoto kurudi kwa wazazi wao.
///
/// Njia ya kawaida ya kupata pointer ya `Weak` ni kupiga [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Hii ni `NonNull` inayoruhusu kuongeza ukubwa wa aina hii katika enum, lakini sio lazima kuwa ni pointer halali.
    //
    // `Weak::new` inaweka hii kwa `usize::MAX` ili isihitaji kutenga nafasi kwenye lundo.
    // Hiyo sio thamani ambayo pointer halisi itakuwa nayo kwa sababu RcBox ina mpangilio angalau 2.
    // Hii inawezekana tu wakati `T: Sized`;`T` isiyo na ukubwa kamwe haingiliki.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Inaunda `Weak<T>` mpya, bila kutenga kumbukumbu yoyote.
    /// Kupiga simu [`upgrade`] kwa thamani ya kurudi daima hutoa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Aina ya msaidizi kuruhusu kufikia hesabu za kumbukumbu bila kutoa madai yoyote juu ya uwanja wa data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Hurejesha pointer mbichi kwa kitu `T` kilichoelekezwa na `Weak<T>` hii.
    ///
    /// Kiashiria ni halali tu ikiwa kuna marejeleo madhubuti.
    /// Pointer inaweza kuwa inaning'inia, haijalinganishwa au hata [`null`] vinginevyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Wote huelekeza kwenye kitu kimoja
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Nguvu hapa huiweka hai, kwa hivyo tunaweza bado kupata kitu hicho.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Lakini sio zaidi.
    /// // Tunaweza kufanya weak.as_ptr(), lakini kufikia pointer kutasababisha tabia isiyojulikana.
    /// // assert_eq! ("hello", salama {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ikiwa pointer inaning'inia, tunarudisha sentinel moja kwa moja.
            // Hii haiwezi kuwa anwani halali ya malipo, kwani upakiaji wa malipo ni sawa kama RcBox (usize).
            ptr as *const T
        } else {
            // USALAMA: ikiwa_kunyongwa kunarudi kwa uwongo, basi pointer haiwezi kutolewa.
            // Mshahara unaweza kutolewa kwa wakati huu, na tunapaswa kudumisha asili, kwa hivyo tumia ujanja wa pointer mbichi.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Inatumia `Weak<T>` na kuibadilisha kuwa pointer mbichi.
    ///
    /// Hii inabadilisha pointer dhaifu kuwa pointer mbichi, wakati bado inahifadhi umiliki wa kumbukumbu moja dhaifu (hesabu dhaifu haibadilishwa na operesheni hii).
    /// Inaweza kugeuzwa kuwa `Weak<T>` na [`from_raw`].
    ///
    /// Vikwazo vile vile vya kufikia lengo la pointer kama vile [`as_ptr`] inatumika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Inabadilisha pointer mbichi iliyoundwa hapo awali na [`into_raw`] kurudi `Weak<T>`.
    ///
    /// Hii inaweza kutumiwa kupata rejeleo kali (kwa kupiga simu [`upgrade`] baadaye) au kusambaza hesabu dhaifu kwa kuacha `Weak<T>`.
    ///
    /// Inachukua umiliki wa kumbukumbu moja dhaifu (isipokuwa vidokezo vilivyoundwa na [`new`], kwani hizi hazina chochote; njia bado inafanya kazi kwao).
    ///
    /// # Safety
    ///
    /// Kiashiria lazima kiwe kimetoka kwa [`into_raw`] na lazima bado kiwe na rejeleo lake dhaifu.
    ///
    /// Inaruhusiwa kwa hesabu kali kuwa 0 wakati wa kupiga simu hii.
    /// Walakini, hii inachukua umiliki wa rejelei moja dhaifu inayowakilishwa sasa kama kiboreshaji kibichi (hesabu dhaifu haibadilishwa na operesheni hii) na kwa hivyo inapaswa kuoanishwa na simu ya awali kwa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Punguza hesabu dhaifu ya mwisho.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tazama Weak::as_ptr kwa muktadha wa jinsi kielekezi cha kuingiza kinatokana.

        let ptr = if is_dangling(ptr as *mut T) {
            // Huu ni udhaifu wa kujinyonga.
            ptr as *mut RcBox<T>
        } else {
            // Vinginevyo, tunahakikishiwa kuwa pointer ilitoka kwa Mtu dhaifu dhaifu.
            // USALAMA: data_offset ni salama kupiga simu, kwani ptr inarejelea halisi (inayoweza kudondoshwa) T.
            let offset = unsafe { data_offset(ptr) };
            // Kwa hivyo, tunabadilisha malipo ili kupata RcBox nzima.
            // USALAMA: pointer ilitoka kwa Dhaifu, kwa hivyo malipo haya ni salama.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // USALAMA: sasa tumepata pointer dhaifu ya asili, kwa hivyo tunaweza kuunda Wanyonge.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Jaribio la kuboresha pointer ya `Weak` hadi [`Rc`], kuchelewesha kushuka kwa thamani ya ndani ikiwa imefanikiwa.
    ///
    ///
    /// Hurejesha [`None`] ikiwa thamani ya ndani imeshuka tangu hapo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Kuharibu kuyatumia nguvu zote.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Inapata idadi ya viashiria vikali vya (`Rc`) vinavyoelekeza kwenye mgao huu.
    ///
    /// Ikiwa `self` iliundwa kwa kutumia [`Weak::new`], hii itarudi 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Inapata idadi ya viashiria vya `Weak` vinavyoashiria mgao huu.
    ///
    /// Ikiwa hakuna viashiria vikali vilivyobaki, hii itarudi sifuri.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // toa ptr dhaifu isiyo dhahiri
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Inarudi `None` wakati pointer inaning'inia na hakuna `RcBox` iliyotengwa, (yaani, wakati `Weak` hii iliundwa na `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tuko makini *sio* kuunda rejea inayofunika uwanja wa "data", kwani uwanja unaweza kubadilishwa kwa wakati mmoja (kwa mfano, ikiwa `Rc` ya mwisho imeshushwa, uwanja wa data utashushwa mahali).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Hurejesha `true` ikiwa `Weak` mbili zinaelekeza kwa mgao sawa (sawa na [`ptr::eq`]), au ikiwa zote mbili hazionyeshi mgao wowote (kwa sababu ziliundwa na `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kwa kuwa hii inalinganisha viashiria inamaanisha kuwa `Weak::new()` italingana, ingawa hazionyeshi mgao wowote.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Kulinganisha `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Matone pointer `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Haichapishi chochote
    /// drop(foo);        // Kuchapisha "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // hesabu dhaifu huanza saa 1, na itaenda sifuri ikiwa viashiria vyote vikali vimepotea.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Inafanya mwamba wa pointer ya `Weak` inayoelekeza kwa mgao huo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Inaunda `Weak<T>` mpya, ikitoa kumbukumbu ya `T` bila kuianza.
    /// Kupiga simu [`upgrade`] kwa thamani ya kurudi daima hutoa [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Tuliangalia_kuongeza hapa kushughulikia mem::forget salama.Hasa
// ikiwa wewe ni mem::forget Rcs (au Weaks), hesabu ya kutafakari inaweza kufurika, na kisha unaweza kutoa ugawaji wakati Rcs bora (au Dhaifu) zipo.
//
// Tunatoa mimba kwa sababu hii ni hali mbaya sana kwamba hatujali juu ya kile kinachotokea-hakuna mpango wowote wa kweli ambao unapaswa kuwa na uzoefu huu.
//
// Hii inapaswa kuwa na kichwa kidogo kwa kuwa hauitaji kuiga sana katika Rust shukrani kwa umiliki na semantiki ya kusonga.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Tunataka kutoa mimba kwa kufurika badala ya kuacha thamani.
        // Hesabu ya kumbukumbu haitakuwa sifuri wakati hii inaitwa;
        // Walakini, tunaingiza mimba hapa ili kudokeza LLVM katika utaftaji uliokosa vingine.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Tunataka kutoa mimba kwa kufurika badala ya kuacha thamani.
        // Hesabu ya kumbukumbu haitakuwa sifuri wakati hii inaitwa;
        // Walakini, tunaingiza mimba hapa ili kudokeza LLVM katika utaftaji uliokosa vingine.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Pata malipo ndani ya `RcBox` kwa upakiaji wa malipo nyuma ya pointer.
///
/// # Safety
///
/// Kiashiria lazima kielekeze (na kuwa na metadata halali ya) mfano halali wa hapo awali wa T, lakini T inaruhusiwa kutolewa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Patanisha thamani isiyo na ukubwa hadi mwisho wa RcBox.
    // Kwa sababu RcBox ni repr(C), daima itakuwa uwanja wa mwisho kwenye kumbukumbu.
    // USALAMA: kwa kuwa aina pekee ambazo hazina ukubwa ni vipande, vitu vya trait,
    // na aina za nje, mahitaji ya usalama wa pembejeo kwa sasa yanatosha kukidhi mahitaji ya align_of_val_raw;hii ni maelezo ya utekelezaji wa lugha ambayo haiwezi kutegemewa nje ya std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}