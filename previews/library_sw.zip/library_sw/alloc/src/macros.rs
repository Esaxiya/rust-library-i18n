/// Inaunda [`Vec`] iliyo na hoja.
///
/// `vec!` inaruhusu `Vec` kufafanuliwa na sintaksia sawa na misemo ya safu.
/// Kuna aina mbili za jumla hii:
///
/// - Unda [`Vec`] iliyo na orodha ya vitu:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Unda [`Vec`] kutoka kwa kipengee na saizi uliyopewa:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Kumbuka kuwa tofauti na misemo ya safu ya sintaksia hii inasaidia vitu vyote ambavyo hutekeleza [`Clone`] na idadi ya vitu haifai kuwa ya kila wakati.
///
/// Hii itatumia `clone` kurudia usemi, kwa hivyo mtu anapaswa kuwa mwangalifu kutumia hii na aina zilizo na utekelezaji wa `Clone` isiyo ya kawaida.
/// Kwa mfano, `vec![Rc::new(1);5] "itaunda vector ya marejeleo matano kwa nambari sawa ya sanduku lenye sanduku, sio marejeleo matano yanayoashiria nambari za sanduku za kujitegemea.
///
///
/// Pia, kumbuka kuwa `vec![expr; 0]` inaruhusiwa, na hutoa vector tupu.
/// Hii bado itatathmini `expr`, hata hivyo, na mara moja itoe thamani inayosababishwa, kwa hivyo kumbuka athari mbaya.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): na cfg(test) njia asili ya `[T]::into_vec`, ambayo inahitajika kwa ufafanuzi huu wa jumla, haipatikani.
// Badala yake tumia kazi ya `slice::into_vec` ambayo inapatikana tu na cfg(test) NB angalia moduli ya slice::hack katika slice.rs kwa habari zaidi
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Inaunda `String` kwa kutumia ujumuishaji wa misemo ya wakati wa kukimbia.
///
/// Hoja ya kwanza `format!` inapokea ni kamba ya fomati.Hii lazima iwe kamba halisi.Nguvu ya fomati ya muundo iko katika "{}` zilizomo.
///
/// Vigezo vya ziada vilivyopitishwa kwa `format!` vinachukua nafasi ya `{}` ndani ya fomati ya fomati kwa agizo lililopewa isipokuwa vigezo vya kutajwa au vya hali vitatumika;tazama [`std::fmt`] kwa habari zaidi.
///
///
/// Matumizi ya kawaida ya `format!` ni kuunganishwa na kuingiliana kwa kamba.
/// Mkutano huo huo hutumiwa na [`print!`] na [`write!`] macros, kulingana na marudio yaliyokusudiwa ya kamba.
///
/// Kubadilisha thamani moja kuwa kamba, tumia njia ya [`to_string`].Hii itatumia muundo wa [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics ikiwa muundo wa trait unarudisha hitilafu.
/// Hii inaonyesha utekelezaji sio sahihi kwani `fmt::Write for String` haileti tena kosa lenyewe.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Lazimisha nodi ya AST kwa usemi ili kuboresha utambuzi katika nafasi ya muundo.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}