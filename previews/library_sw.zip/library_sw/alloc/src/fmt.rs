//! Huduma za uumbizaji na uchapishaji `String`s.
//!
//! Moduli hii ina msaada wa wakati wa kukimbia kwa ugani wa syntax ya [`format!`].
//! Macro hii inatekelezwa katika mkusanyaji kutoa simu kwenye moduli hii ili kuunda hoja wakati wa kukimbia kuwa nyuzi.
//!
//! # Usage
//!
//! Macro ya [`format!`] imekusudiwa kufahamika kwa wale wanaokuja kutoka kwa kazi za C's `printf`/`fprintf` au Python's `str.format`.
//!
//! Mifano zingine za ugani wa [`format!`] ni:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" na zero zinazoongoza
//! ```
//!
//! Kutoka kwa hizi, unaweza kuona kuwa hoja ya kwanza ni kamba ya fomati.Inahitajika na mkusanyaji ili hii iwe kamba halisi;haiwezi kuwa tofauti inayopitishwa (ili kufanya ukaguzi wa uhalali).
//! Mkusanyaji atachanganua kamba ya fomati na aamue ikiwa orodha ya hoja zilizotolewa zinafaa kupitisha kwenye fomati hii ya fomati.
//!
//! Kubadilisha thamani moja kuwa kamba, tumia njia ya [`to_string`].Hii itatumia muundo wa [`Display`] trait.
//!
//! ## Vigezo vya nafasi
//!
//! Kila hoja ya uumbizaji inaruhusiwa kutaja ni nambari gani ya thamani inayorejelea, na ikiwa imeachwa inachukuliwa kuwa "the next argument".
//! Kwa mfano, kamba ya fomati `{} {} {}` itachukua vigezo vitatu, na vingefomatiwa kwa mpangilio sawa na vile wamepewa.
//! Kamba ya fomati `{2} {1} {0}`, hata hivyo, ingeunda muundo wa hoja kwa mpangilio wa nyuma.
//!
//! Vitu vinaweza kupata gumu kidogo mara tu unapoanza kuingiliana na aina mbili za viashiria vya msimamo.Kibainishi cha "next argument" kinaweza kuzingatiwa kama iterator juu ya hoja.
//! Kila wakati kiboreshaji cha "next argument" kinapoonekana, iterator huendelea.Hii inasababisha tabia kama hii:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iterator ya ndani juu ya hoja haijasonga mbele wakati `{}` ya kwanza inavyoonekana, kwa hivyo inachapisha hoja ya kwanza.Halafu baada ya kufikia `{}` ya pili, iterator imeendelea mbele kwa hoja ya pili.
//! Kwa kweli, vigezo ambavyo hutaja hoja yao wazi haziathiri vigezo ambavyo havijazi hoja kwa suala la viashiria vya nafasi.
//!
//! Kamba ya fomati inahitajika kutumia hoja zake zote, vinginevyo ni kosa la wakati wa kukusanya.Unaweza kutaja hoja hiyo hiyo zaidi ya mara moja kwenye kamba ya fomati.
//!
//! ## Vigezo vilivyopewa jina
//!
//! Rust yenyewe haina Python-sawa na vigezo vilivyotajwa kwa kazi, lakini jumla ya [`format!`] ni ugani wa sintaksia ambayo inaruhusu kupata vigezo vilivyoitwa.
//! Vigezo vilivyotajwa vimeorodheshwa mwishoni mwa orodha ya hoja na ina syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Kwa mfano, maneno yafuatayo ya [`format!`] hutumia hoja yenye jina:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Sio halali kuweka vigezo vya nafasi (zile zisizo na majina) baada ya hoja zilizo na majina.Kama ilivyo na vigezo vya hali, sio halali kutoa vigezo vilivyotajwa ambavyo havijatumiwa na kamba ya fomati.
//!
//! # Viwango vya Uundaji
//!
//! Kila hoja inayoumbizwa inaweza kubadilishwa na vigezo kadhaa vya uumbizaji (vinavyolingana na `format_spec` katika [the syntax](#syntax)). Vigezo hivi vinaathiri uwakilishi wa kamba wa kile kinachoumbizwa.
//!
//! ## Width
//!
//! ```
//! // Zote hizi zinachapishwa "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Hii ni parameter ya "minimum width" ambayo fomati inapaswa kuchukua.
//! Ikiwa kamba ya thamani haijajaza wahusika wengi, basi padding iliyoainishwa na fill/alignment itatumika kuchukua nafasi inayohitajika (tazama hapa chini).
//!
//! Thamani ya upana pia inaweza kutolewa kama [`usize`] katika orodha ya vigezo kwa kuongeza postfix `$`, ikionyesha kuwa hoja ya pili ni [`usize`] inayoelezea upana.
//!
//! Kurejelea hoja na sintaksia ya dola hakuathiri kaunta ya "next argument", kwa hivyo kawaida ni wazo nzuri kurejelea hoja kwa msimamo, au kutumia hoja zilizotajwa.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Tabia ya kujaza hiari na mpangilio hutolewa kawaida kwa kushirikiana na parameta ya [`width`](#width).Lazima ifafanuliwe kabla ya `width`, mara tu baada ya `:`.
//! Hii inaonyesha kwamba ikiwa thamani inayoumbizwa ni ndogo kuliko `width` wahusika wengine watachapishwa kuzunguka.
//! Kujaza kunakuja kwa anuwai zifuatazo kwa mpangilio tofauti:
//!
//! * `[fill]<` - hoja hiyo imepangiliwa kushoto katika safu wima za `width`
//! * `[fill]^` - hoja hiyo imepangiliwa katikati katika safu wima za `width`
//! * `[fill]>` - hoja hiyo iko sawa katika safu za `width`
//!
//! Chaguo-msingi la [fill/alignment](#fillalignment) kwa wasio nambari ni nafasi na iliyokaa kushoto.Chaguo-msingi kwa fomati za nambari pia ni tabia ya nafasi lakini kwa mpangilio wa kulia.
//! Ikiwa bendera ya `0` (angalia hapa chini) imeainishwa kwa nambari, basi herufi kamili ya kujaza ni `0`.
//!
//! Kumbuka kuwa mpangilio hauwezi kutekelezwa na aina fulani.Hasa, haitekelezwi kwa jumla kwa `Debug` trait.
//! Njia nzuri ya kuhakikisha pedi inatumika ni kuunda muundo wako, kisha weka kamba hii inayosababisha kupata pato lako:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Halo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Hizi zote ni bendera zinazobadilisha tabia ya fomati.
//!
//! * `+` - Hii imekusudiwa aina za nambari na inaonyesha kwamba ishara inapaswa kuchapishwa kila wakati.Ishara nzuri hazichapishwa kamwe na default, na ishara hasi imechapishwa tu kwa chaguo-msingi kwa `Signed` trait.
//! Bendera hii inaonyesha kwamba ishara sahihi (`+` au `-`) inapaswa kuchapishwa kila wakati.
//! * `-` - Hivi sasa haitumiki
//! * `#` - Bendera hii inaonyesha kwamba aina ya uchapishaji ya "alternate" inapaswa kutumika.Fomu mbadala ni:
//!     * `#?` - chapisha vizuri muundo wa [`Debug`]
//!     * `#x` - hutangulia hoja na `0x`
//!     * `#X` - hutangulia hoja na `0x`
//!     * `#b` - hutangulia hoja na `0b`
//!     * `#o` - hutangulia hoja na `0o`
//! * `0` - Hii hutumiwa kuonyesha kwa fomati kamili kuwa utaftaji wa `width` unapaswa kufanywa na herufi ya `0` na pia kuwa na ufahamu wa ishara.
//! Muundo kama `{:08}` utatoa `00000001` kwa nambari kamili `1`, wakati muundo huo huo utatoa `-0000001` kwa nambari kamili `-1`.
//! Kumbuka kuwa toleo hasi lina sifuri moja kidogo kuliko toleo chanya.
//!         Kumbuka kuwa zero za padding huwekwa kila wakati baada ya ishara (ikiwa ipo) na kabla ya nambari.Wakati unatumiwa pamoja na bendera ya `#`, sheria kama hiyo inatumika: ziro za kujifunga zinaingizwa baada ya kiambishi awali lakini kabla ya nambari.
//!         Kiambishi awali kimejumuishwa katika upana wa jumla.
//!
//! ## Precision
//!
//! Kwa aina zisizo za nambari, hii inaweza kuzingatiwa kama "maximum width".
//! Ikiwa kamba inayosababisha ni ndefu kuliko upana huu, basi imekatwa kwa herufi nyingi na kwamba thamani iliyokatwa hutolewa na `fill`, `alignment` na `width` sahihi ikiwa vigezo hivyo vimewekwa.
//!
//! Kwa aina muhimu, hii inapuuzwa.
//!
//! Kwa aina za hatua zinazoelea, hii inaonyesha ni idadi ngapi baada ya alama ya desimali inapaswa kuchapishwa.
//!
//! Kuna njia tatu zinazowezekana za kutaja `precision` inayotaka:
//!
//! 1. Nambari kamili ya `.N`:
//!
//!    nambari kamili ya `N` yenyewe ni usahihi.
//!
//! 2. Nambari kamili au jina ikifuatiwa na ishara ya dola `.N$`:
//!
//!    tumia fomati *hoja*`N` (ambayo lazima iwe `usize`) kama usahihi.
//!
//! 3. Nyota `.*`:
//!
//!    `.*` inamaanisha kuwa `{...}` hii inahusishwa na pembejeo za muundo wa *mbili* badala ya moja: pembejeo la kwanza linashikilia usahihi wa `usize`, na ya pili inashikilia thamani ya kuchapisha.
//!    Kumbuka kuwa katika kesi hii, ikiwa mtu atatumia kamba ya fomati `{<arg>:<spec>.*}`, basi sehemu ya `<arg>` inahusu* thamani * kuchapisha, na `precision` lazima iingie kwenye pembejeo iliyotangulia `<arg>`.
//!
//! Kwa mfano, simu zifuatazo zote zinachapisha kitu kimoja `Hello x is 0.01000`:
//!
//! ```
//! // Halo {arg 0 ("x")} ni {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Halo {arg 1 ("x")} ni {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Halo {arg 0 ("x")} ni {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} ni {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} ni {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} ni {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Wakati hizi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! chapisha vitu vitatu tofauti:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Katika lugha zingine za programu, tabia ya kazi za uumbizaji wa kamba hutegemea mipangilio ya eneo la mfumo wa uendeshaji.
//! Kazi za muundo zilizotolewa na maktaba ya kawaida ya Rust hazina dhana yoyote ya eneo na zitatoa matokeo sawa kwenye mifumo yote bila kujali usanidi wa mtumiaji.
//!
//! Kwa mfano, nambari ifuatayo itachapisha `1.5` kila wakati hata kama eneo la mfumo linatumia kitenganishi cha desimali zaidi ya nukta.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Herufi halisi `{` na `}` zinaweza kujumuishwa kwenye kamba kwa kuzitangulia na mhusika sawa.Kwa mfano, tabia ya `{` imitoroka na `{{` na tabia ya `}` imitoroka na `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Kwa muhtasari, hapa unaweza kupata sarufi kamili ya nyuzi za fomati.
//! Sintaksia ya lugha ya uumbizaji inayotumiwa imetolewa kutoka kwa lugha zingine, kwa hivyo haipaswi kuwa mgeni sana.Hoja zimeundwa na syntax ya Python-kama, ikimaanisha kuwa hoja zimezungukwa na `{}` badala ya C-kama `%`.
//! Sarufi halisi ya sintaksia ya uumbizaji ni:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Katika sarufi hapo juu, `text` inaweza kuwa na herufi yoyote `'{'` au `'}'`.
//!
//! # Kubadilisha traits
//!
//! Unapoomba hoja iwe imeumbizwa na aina fulani, kwa kweli unaomba kwamba hoja ibadilishwe kwa trait fulani.
//! Hii inaruhusu aina nyingi halisi kuumbizwa kupitia `{:x}` (kama [`i8`] na [`isize`]).Ramani ya sasa ya aina kwa traits ni:
//!
//! * *hakuna kitu* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] na nambari ndogo za hexadecimal
//! * `X?` ⇒ [`Debug`] na nambari kubwa za hexadecimal
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Maana yake ni kwamba aina yoyote ya hoja inayotumia [`fmt::Binary`][`Binary`] trait inaweza kuumbizwa na `{:b}`.Utekelezaji hutolewa kwa hizi traits kwa aina kadhaa za zamani na maktaba ya kawaida pia.
//!
//! Ikiwa hakuna muundo uliowekwa (kama ilivyo kwa `{}` au `{:6}`), basi muundo wa trait uliotumika ni [`Display`] trait.
//!
//! Wakati wa kutekeleza muundo trait kwa aina yako mwenyewe, italazimika kutekeleza njia ya saini:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // aina yetu ya kawaida
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Aina yako itapitishwa kama rejeleo la `self`, na kisha kazi hiyo inapaswa kutoa pato kwenye mkondo wa `f.buf`.Ni juu ya kila muundo wa trait utekelezaji kufuata kwa usahihi vigezo vya uundaji vilivyoombwa.
//! Thamani za vigezo hivi zitaorodheshwa katika uwanja wa muundo wa [`Formatter`].Ili kusaidia na hii, muundo wa [`Formatter`] pia hutoa njia kadhaa za msaidizi.
//!
//! Kwa kuongezea, thamani ya kurudisha ya kazi hii ni [`fmt::Result`] ambayo ni jina la aina ya [`Matokeo`]`<(),`[`std: : fmt::Error`] `>`.
//! Utekelezaji wa muundo unapaswa kuhakikisha kuwa wanaeneza makosa kutoka kwa [`Formatter`] (kwa mfano, wakati wa kupiga [`write!`]).
//! Walakini, hawapaswi kurudi makosa vibaya.
//! Hiyo ni, utekelezaji wa muundo lazima na unaweza tu kurudisha kosa ikiwa [`Formatter`] iliyopitishwa inarudisha kosa.
//! Hii ni kwa sababu, kinyume na kile saini ya kazi inaweza kupendekeza, muundo wa kamba ni operesheni isiyo na makosa.
//! Kazi hii inarudisha tu matokeo kwa sababu kuandikia mkondo wa msingi kunaweza kutofaulu na lazima itoe njia ya kueneza ukweli kwamba kosa limetokea kuhifadhi nakala.
//!
//! Mfano wa kutekeleza fomati traits itaonekana kama:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Thamani ya `f` hutumia `Write` trait, ambayo ndio kuandika!jumla inatarajia.
//!         // Kumbuka kuwa fomati hii inapuuza bendera anuwai zilizopewa fomati za fomati.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits tofauti huruhusu aina tofauti za pato la aina.
//! // Maana ya muundo huu ni kuchapisha ukubwa wa vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Heshimu bendera za uumbizaji kwa kutumia njia ya msaidizi `pad_integral` kwenye kitu cha Formatter.
//!         // Tazama nyaraka za njia kwa maelezo, na kazi `pad` inaweza kutumika kwa nyuzi za pedi.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` dhidi ya `fmt::Debug`
//!
//! Uundaji hizi mbili traits zina malengo tofauti:
//!
//! - [`fmt::Display`][`Display`] utekelezaji unasisitiza kwamba aina hiyo inaweza kuwakilishwa kwa uaminifu kama kamba ya UTF-8 wakati wote.Haitarajiwi ** kwamba kila aina kutekeleza [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] utekelezaji unapaswa kutekelezwa kwa aina zote ** za umma.
//!   Pato kwa kawaida litawakilisha hali ya ndani kwa uaminifu iwezekanavyo.
//!   Madhumuni ya [`Debug`] trait ni kuwezesha utatuzi wa nambari ya Rust.Katika hali nyingi, kutumia `#[derive(Debug)]` inatosha na inashauriwa.
//!
//! Mifano kadhaa ya pato kutoka kwa traits zote mbili:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macro zinazohusiana
//!
//! Kuna idadi kubwa ya macros zinazohusiana katika familia ya [`format!`].Zilizotekelezwa sasa ni:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Hii na [`writeln!`] ni macros mawili ambayo hutumiwa kutoa kamba ya fomati kwenye mkondo maalum.Hii hutumiwa kuzuia mgao wa kati wa nyuzi za fomati na badala yake andika pato moja kwa moja.
//! Chini ya hood, kazi hii inaomba kazi ya [`write_fmt`] iliyoainishwa kwenye [`std::io::Write`] trait.
//! Matumizi ya mfano ni:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Hii na [`println!`] hutoa pato lao kwa stdout.Vivyo hivyo kwa jumla ya [`write!`], lengo la macros haya ni kuzuia mgao wa kati wakati wa kuchapisha pato.Matumizi ya mfano ni:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] na [`eprintln!`] macros zinafanana na [`print!`] na [`println!`], mtawaliwa, isipokuwa zinatoa pato lao kwa stderr.
//!
//! ### `format_args!`
//!
//! Hii ni macro ya kushangaza inayotumiwa kupita salama karibu na kitu kisicho na kifani kinachoelezea kamba ya fomati.Kitu hiki hakihitaji mgao wowote wa chungu kuunda, na inarejelea tu habari juu ya stack.
//! Chini ya hood, macro zote zinazohusiana zinatekelezwa kwa suala hili.
//! Kwanza, matumizi ya mfano ni:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Matokeo ya jumla ya [`format_args!`] ni thamani ya aina [`fmt::Arguments`].
//! Muundo huu unaweza kupitishwa kwa kazi za [`write`] na [`format`] ndani ya moduli hii ili kusindika fomati ya fomati.
//! Lengo la jumla hii ni kuzuia zaidi mgao wa kati wakati wa kushughulika na nyuzi za muundo.
//!
//! Kwa mfano.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Kazi ya `format` inachukua muundo wa [`Arguments`] na kurudisha kamba iliyoumbizwa iliyosababishwa.
///
///
/// Mfano wa [`Arguments`] unaweza kuundwa na jumla ya [`format_args!`].
///
/// # Examples
///
/// Matumizi ya kimsingi:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Tafadhali kumbuka kuwa kutumia [`format!`] kunaweza kuwa bora.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}