use core::intrinsics;
use core::mem;
use core::ptr;

/// Hii inachukua nafasi ya thamani nyuma ya kumbukumbu ya kipekee ya `v` kwa kupiga kazi inayofaa.
///
///
/// Ikiwa panic itatokea kwenye kufungwa kwa `change`, mchakato mzima utatolewa.
#[allow(dead_code)] // weka kama kielelezo na kwa matumizi ya future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Hii inachukua nafasi ya thamani nyuma ya kumbukumbu ya kipekee ya `v` kwa kupiga kazi inayofaa, na inarudisha matokeo yaliyopatikana njiani.
///
///
/// Ikiwa panic itatokea kwenye kufungwa kwa `change`, mchakato mzima utatolewa.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}