// Hili ni jaribio la utekelezaji kufuatia bora
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Kwa kuwa Rust haina aina tegemezi na kurudia kwa polymorphic, tunafanya bila usalama mwingi.
//

// Lengo kuu la moduli hii ni kuzuia ugumu kwa kutibu mti kama chombo cha kawaida (ikiwa umbo la kushangaza) na kuzuia kushughulika na wavamizi wengi wa Miti ya B.
//
// Kwa hivyo, moduli hii haijali kama maingizo yamepangwa, ni node zipi zinaweza kuwa kamili, au hata maana ya maana.Walakini, tunategemea wavamizi wachache:
//
// - Miti lazima iwe na sare depth/height.Hii inamaanisha kuwa kila njia chini ya jani kutoka kwa node iliyopewa ina urefu sawa.
// - Node ya urefu `n` ina funguo `n`, maadili ya `n`, na kingo za `n + 1`.
//   Hii inamaanisha kuwa hata node tupu ina angalau edge moja.
//   Kwa nodi ya jani, "having an edge" inamaanisha tu tunaweza kutambua nafasi katika nodi, kwani kingo za majani hazina chochote na hazihitaji uwakilishi wa data.
// Katika node ya ndani, edge zote mbili hutambua nafasi na ina pointer kwa node ya mtoto.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Uwakilishi wa msingi wa nodi za majani na sehemu ya uwakilishi wa nodi za ndani.
struct LeafNode<K, V> {
    /// Tunataka kujipanga katika `K` na `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Faharisi ya nodi hii katika safu ya mzazi ya `edges`.
    /// `*node.parent.edges[node.parent_idx]` inapaswa kuwa kitu sawa na `node`.
    /// Hii imehakikishiwa kuanzishwa tu wakati `parent` sio ya kweli.
    parent_idx: MaybeUninit<u16>,

    /// Idadi ya funguo na maadili ya node hii huhifadhi.
    len: u16,

    /// Safu zinazohifadhi data halisi ya node.
    /// Vipengele vya kwanza vya `len` vya kila safu ndio vimeanzishwa na halali.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inazindua `LeafNode` mpya mahali.
    unsafe fn init(this: *mut Self) {
        // Kama sera ya jumla, tunaacha sehemu zikiwa hazijaanza ikiwa zinaweza, kwani hii inapaswa kuwa ya haraka kidogo na rahisi kufuata katika Valgrind.
        //
        unsafe {
            // parent_idx, funguo, na vals zote ni labdaUnunit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Inaunda sanduku mpya la `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Uwakilishi wa msingi wa nodi za ndani.Kama ilivyo kwa `LeafNode`s, hizi zinapaswa kujificha nyuma ya`BoxedNode` ili kuzuia kuacha vitufe na maadili yasiyofunguliwa.
/// Kiashiria chochote kwa `InternalNode` kinaweza kutupwa moja kwa moja kwa kiboreshaji kwa sehemu ya msingi ya `LeafNode` ya nodi, ikiruhusu nambari kuchukua hatua kwenye jani na nodi za ndani kwa ujumla bila hata kukagua ni nani kati ya hizo mbili zinazoelekeza.
///
/// Mali hii imewezeshwa na matumizi ya `repr(C)`.
///
#[repr(C)]
// gdb_providers.py hutumia jina la aina hii kutafakari.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Vidokezo kwa watoto wa node hii.
    /// `len + 1` kati ya hizi huhesabiwa kuwa zimeanzishwa na halali, isipokuwa kwamba karibu na mwisho, wakati mti unashikiliwa kupitia aina ya kukopa `Dying`, viashiria vingine vinaning'inia.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Inaunda sanduku mpya la `InternalNode`.
    ///
    /// # Safety
    /// Mbadala wa nodi za ndani ni kwamba wana angalau edge iliyoanzishwa na halali.
    /// Kazi hii haianzishi edge kama hiyo.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Tunahitaji tu kuanzisha data;kingo ni LabdaUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Kiashiria kilichodhibitiwa, kisicho cha batili kwa nodi.Hii labda ni pointer inayomilikiwa kwa `LeafNode<K, V>` au pointer inayomilikiwa kwa `InternalNode<K, V>`.
///
/// Walakini, `BoxedNode` haina habari juu ya aina gani ya nodi ambayo ina, na, kwa sababu ya ukosefu huu wa habari, sio aina tofauti na haina mwangamizi.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Node ya mizizi ya mti unaomilikiwa.
///
/// Kumbuka kuwa hii haina mwangamizi, na inapaswa kusafishwa kwa mikono.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Hurejesha mti mpya unaomilikiwa, na node yake ya mizizi ambayo hapo awali haina tupu.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` lazima isiwe sifuri.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Kwa pamoja hukopa nodi ya mizizi inayomilikiwa.
    /// Tofauti na `reborrow_mut`, hii ni salama kwa sababu thamani ya kurudi haiwezi kutumiwa kuharibu mzizi, na hakuwezi kuwa na marejeleo mengine kwa mti.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kwa kiasi kidogo hukopa nodi ya mizizi inayomilikiwa.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mabadiliko yasiyoweza kurejeshwa kwa rejeleo ambayo inaruhusu kuvuka na kutoa njia za uharibifu na si kitu kingine chochote.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Inaongeza node mpya ya ndani na edge moja inayoashiria nodi ya mizizi ya awali, fanya node hiyo mpya kuwa node ya mizizi, na uirudishe.
    /// Hii huongeza urefu kwa 1 na ni kinyume cha `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, isipokuwa tu kwamba tulisahau tu kuwa wa ndani sasa:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Huondoa kiini cha ndani cha mizizi, ikitumia mtoto wake wa kwanza kama kiini kipya cha mizizi.
    /// Kama inavyokusudiwa kuitwa tu wakati kiini cha mizizi kina mtoto mmoja tu, hakuna usafishaji unaofanywa kwenye funguo, maadili na watoto wengine.
    ///
    /// Hii inapunguza urefu kwa 1 na ni kinyume cha `push_internal_level`.
    ///
    /// Inahitaji ufikiaji wa kipekee kwa kitu cha `Root` lakini sio kwenye nodi ya mizizi;
    /// haitafanya batili nyingine au marejeleo ya nodi ya mizizi.
    ///
    /// Panics ikiwa hakuna kiwango cha ndani, yaani, ikiwa node ya mizizi ni jani.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // USALAMA: tulidai kuwa ya ndani.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // USALAMA: tulikopa `self` peke yake na aina yake ya kukopa ni ya kipekee.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // USALAMA: edge ya kwanza huanzishwa kila wakati.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` daima ni ya kawaida katika `K` na `V`, hata wakati `BorrowType` ni `Mut`.
// Hii ni kweli kitaalam, lakini haiwezi kusababisha usalama wowote kwa sababu ya matumizi ya ndani ya `NodeRef` kwa sababu tunakaa kabisa zaidi ya `K` na `V`.
//
// Walakini, wakati wowote aina ya umma inapoifunga `NodeRef`, hakikisha kuwa ina tofauti sahihi.
//
/// Rejeleo la nodi.
///
/// Aina hii ina vigezo kadhaa vinavyodhibiti jinsi inavyofanya kazi:
/// - `BorrowType`: Aina ya dummy ambayo inaelezea aina ya kukopa na hubeba maisha yote.
///    - Wakati hii ni `Immut<'a>`, `NodeRef` hufanya takriban kama `&'a Node`.
///    - Wakati hii ni `ValMut<'a>`, `NodeRef` hufanya takriban kama `&'a Node` kwa kuzingatia funguo na muundo wa mti, lakini pia inaruhusu marejeleo mengi yanayoweza kubadilika kwa maadili katika mti wote kuishi pamoja.
///    - Wakati hii ni `Mut<'a>`, `NodeRef` hufanya takriban kama `&'a mut Node`, ingawa njia za kuingiza huruhusu pointer inayoweza kubadilika kuwa na thamani ya kuishi pamoja.
///    - Wakati hii ni `Owned`, `NodeRef` hufanya takriban `Box<Node>`, lakini haina uharibifu, na inapaswa kusafishwa kwa mikono.
///    - Wakati hii ni `Dying`, `NodeRef` bado hufanya kama `Box<Node>`, lakini ina mbinu za kuharibu mti kidogo kidogo, na njia za kawaida, ingawa hazijawekwa alama kama salama ya kupiga simu, zinaweza kuomba UB ikiwa itaitwa vibaya.
///
///   Kwa kuwa `NodeRef` yoyote inaruhusu kuvinjari kupitia mti, `BorrowType` inatumika kwa mti mzima, sio kwa node yenyewe.
/// - `K` na `V`: Hizi ni aina za funguo na maadili yaliyohifadhiwa kwenye nodi.
/// - `Type`: Hii inaweza kuwa `Leaf`, `Internal`, au `LeafOrInternal`.
/// Wakati hii ni `Leaf`, `NodeRef` inaelekeza kwenye nodi ya jani, wakati hii ni `Internal` `NodeRef` inaelekeza kwa nodi ya ndani, na wakati hii ni `LeafOrInternal` `NodeRef` inaweza kuashiria aina yoyote ya nodi.
///   `Type` inaitwa `NodeType` wakati inatumiwa nje ya `NodeRef`.
///
/// Zote `BorrowType` na `NodeType` huzuia ni njia zipi tunatumia, kutumia usalama wa aina ya tuli.Kuna mapungufu katika njia ambayo tunaweza kutumia vizuizi kama hivi:
/// - Kwa kila kigezo cha aina, tunaweza kufafanua njia moja kwa moja au kwa aina fulani.
/// Kwa mfano, hatuwezi kufafanua njia kama `into_kv` kwa jumla kwa `BorrowType` zote, au mara moja kwa aina zote ambazo hubeba maisha yote, kwa sababu tunataka irudishe marejeleo ya `&'a`.
///   Kwa hivyo, tunaifafanua tu kwa aina isiyo na nguvu ya `Immut<'a>`.
/// - Hatuwezi kupata kulazimishwa dhahiri kutoka kwa kusema `Mut<'a>` hadi `Immut<'a>`.
///   Kwa hivyo, lazima tuita wazi `reborrow` kwenye `NodeRef` yenye nguvu zaidi ili kufikia njia kama `into_kv`.
///
/// Njia zote kwenye `NodeRef` ambazo zinarudisha aina fulani ya kumbukumbu, ama:
/// - Chukua `self` kwa thamani, na urudishe maisha uliobebwa na `BorrowType`.
///   Wakati mwingine, kuomba njia kama hiyo, tunahitaji kupiga `reborrow_mut`.
/// - Chukua `self` kwa kumbukumbu, na (implicitly) urudishe wakati wa rejeleo hilo, badala ya wakati wa maisha uliobeba `BorrowType`.
/// Kwa njia hiyo, kikaguaji cha kukopa huhakikishia kuwa `NodeRef` inabaki ikopwa ilimradi rejeleo lililorejeshwa linatumika.
///   Njia zinazosaidia kuingiza pindisha sheria hii kwa kurudisha pointer mbichi, yaani, kumbukumbu bila maisha yoyote.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Idadi ya viwango ambavyo nodi na kiwango cha majani ni tofauti, mara kwa mara ya nodi ambayo haiwezi kuelezewa kabisa na `Type`, na kwamba node yenyewe haihifadhi.
    /// Tunahitaji tu kuhifadhi urefu wa nodi ya mizizi, na kupata urefu wa kila node kutoka kwake.
    /// Lazima iwe sifuri ikiwa `Type` ni `Leaf` na sio sifuri ikiwa `Type` ni `Internal`.
    ///
    ///
    height: usize,
    /// Kiashiria kwa jani au node ya ndani.
    /// Ufafanuzi wa `InternalNode` unahakikisha kuwa pointer ni halali kwa njia yoyote.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ondoa rejeleo la nodi ambalo lilikuwa limejaa kama `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Inafunua data ya node ya ndani.
    ///
    /// Hurejesha ptr mbichi ili kuzuia kuhalalisha marejeleo mengine ya nodi hii.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // USALAMA: aina ya nodi tuli ni `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Inakopa ufikiaji wa kipekee kwa data ya node ya ndani.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Inapata urefu wa nodi.Hii ndio idadi ya funguo au maadili.
    /// Idadi ya kingo ni `len() + 1`.
    /// Kumbuka kuwa, licha ya kuwa salama, kuita kazi hii kunaweza kuwa na athari ya kukataza marejeleo yanayoweza kubadilika ambayo nambari isiyo salama imeunda.
    ///
    pub fn len(&self) -> usize {
        // Kwa muhimu, tunapata tu uwanja wa `len` hapa.
        // Ikiwa BorrowType ni marker::ValMut, kunaweza kuwa na marejeleo bora yanayoweza kubadilika kwa maadili ambayo hatupaswi kubatilisha.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Hurejesha idadi ya viwango ambavyo nodi na majani hutengana.
    /// Urefu wa sifuri inamaanisha kwamba node ni jani yenyewe.
    /// Ikiwa unapiga picha miti iliyo na mzizi juu, nambari inasema juu ya mwinuko ambao nodi hiyo inaonekana.
    /// Ikiwa una picha ya miti iliyo na majani juu, nambari inasema urefu wa mti huo unapanuka juu ya nodi.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Kwa muda huchukua rejea nyingine, isiyoweza kubadilika ya nodi hiyo hiyo.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Inadhihirisha sehemu ya jani la jani lolote au nodi ya ndani.
    ///
    /// Hurejesha ptr mbichi ili kuzuia kuhalalisha marejeleo mengine ya nodi hii.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Node lazima iwe halali kwa angalau sehemu ya LeafNode.
        // Hii sio rejeleo katika aina ya NodeRef kwa sababu hatujui ikiwa inapaswa kuwa ya kipekee au kushirikiwa.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Inapata mzazi wa nodi ya sasa.
    /// Hurejesha `Ok(handle)` ikiwa nodi ya sasa ina mzazi, ambapo `handle` inaelekeza kwa edge ya mzazi inayoelekeza kwa nodi ya sasa.
    ///
    /// Hurejesha `Err(self)` ikiwa nodi ya sasa haina mzazi, ikirudisha `NodeRef` asili.
    ///
    /// Jina la njia linakubali miti ya picha na node ya mizizi juu.
    ///
    /// `edge.descend().ascend().unwrap()` na `node.ascend().unwrap().descend()` haipaswi kufanya chochote, juu ya mafanikio.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Tunahitaji kutumia viashiria mbichi kwa nodi kwa sababu, ikiwa BorrowType ni marker::ValMut, kunaweza kuwa na marejeleo bora yanayoweza kubadilika kwa maadili ambayo hatupaswi kubatilisha.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Kumbuka kuwa `self` lazima iwe bila malipo.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Kumbuka kuwa `self` lazima iwe bila malipo.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Huonyesha sehemu ya jani la jani lolote au nodi ya ndani kwenye mti usiobadilika.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // USALAMA: hakuwezi kuwa na marejeo yanayoweza kubadilika kwenye mti huu uliokopwa kama `Immut`.
        unsafe { &*ptr }
    }

    /// Inakopa mtazamo katika funguo zilizohifadhiwa kwenye node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Sawa na `ascend`, hupata rejea ya nodi ya mzazi wa nodi, lakini pia inashughulikia node ya sasa katika mchakato.
    /// Hii sio salama kwa sababu node ya sasa bado itapatikana licha ya kusambazwa.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kwa usalama inasisitiza kwa mkusanyaji habari tuli kwamba node hii ni `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kwa usalama inasisitiza kwa mkusanyaji habari tuli kwamba node hii ni `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Kwa muda huchukua kumbukumbu nyingine inayoweza kubadilika kwa nodi hiyo hiyo.Jihadharini, kwani njia hii ni hatari sana, mara mbili hivyo kwa kuwa inaweza kuonekana mara moja kuwa hatari.
    ///
    /// Kwa sababu vidokezo vinavyoweza kubadilika vinaweza kuzunguka mahali popote karibu na mti, pointer iliyorudishwa inaweza kutumika kwa urahisi kufanya pointer ya asili ikining'inia, nje ya mipaka, au batili chini ya sheria za kukopa zilizowekwa.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) fikiria kuongeza kigezo kingine cha aina kwa `NodeRef` ambayo inazuia utumiaji wa njia za urambazaji kwenye viashiria vilivyokopwa, kuzuia usalama huu.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Inakopa ufikiaji wa kipekee kwa sehemu ya jani la jani lolote au node ya ndani.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // USALAMA: tuna ufikiaji wa kipekee wa nodi nzima.
        unsafe { &mut *ptr }
    }

    /// Inatoa ufikiaji wa kipekee kwa sehemu ya jani la jani lolote au node ya ndani.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // USALAMA: tuna ufikiaji wa kipekee wa nodi nzima.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Inakopa ufikiaji wa kipekee kwa kipengee cha eneo muhimu la uhifadhi.
    ///
    /// # Safety
    /// `index` iko katika mipaka ya 0..UWEZO
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // USALAMA: mpigaji simu hataweza kuita njia zaidi juu yake mwenyewe
        // mpaka rejeleo la kipande muhimu litatupwa, kwani tuna ufikiaji wa kipekee kwa maisha yote ya kukopa.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Inakopa ufikiaji wa kipekee kwa kipengee au kipande cha eneo la uhifadhi wa thamani ya nodi.
    ///
    /// # Safety
    /// `index` iko katika mipaka ya 0..UWEZO
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // USALAMA: mpigaji simu hataweza kuita njia zaidi juu yake mwenyewe
        // mpaka rejeleo la kipande cha thamani litakapoondolewa, kwani tuna ufikiaji wa kipekee kwa wakati wote wa kukopa.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Inakopa ufikiaji wa kipekee kwa kipengee au kipande cha eneo la uhifadhi wa nodi kwa yaliyomo ya edge.
    ///
    /// # Safety
    /// `index` iko katika mipaka ya 0..UWEZO + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // USALAMA: mpigaji simu hataweza kuita njia zaidi juu yake mwenyewe
        // mpaka marejeleo ya kipande cha edge yameondolewa, kwani tuna ufikiaji wa kipekee kwa maisha yote ya kukopa.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Node ina zaidi ya vipengee vya `idx` vilivyoanzishwa.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Tunaunda tu rejeleo la kitu kimoja tunachovutiwa nacho, ili kuepuka kutafakari na marejeleo bora kwa vitu vingine, haswa, zile zilizorudishwa kwa mpigaji simu katika matembezi ya mapema.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Lazima tushurutishe kwa kuyatumia safu zisizo na ukubwa kwa sababu ya toleo la Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Inakopa ufikiaji wa kipekee kwa urefu wa nodi.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Inaweka kiunga cha nodi kwa mzazi wake edge, bila kubatilisha marejeleo mengine ya nodi.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Husafisha kiunga cha mzizi kwa mzazi wake edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Inaongeza jozi ya thamani muhimu hadi mwisho wa nodi.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Kila kitu kilichorudishwa na `range` ni faharisi halali ya edge ya nodi.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Inaongeza jozi ya thamani muhimu, na edge kwenda kulia kwa jozi hiyo, hadi mwisho wa nodi.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Inakagua ikiwa nodi ni nambari ya `Internal` au nambari ya `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Rejeleo la jozi maalum ya thamani muhimu au edge ndani ya nodi.
/// Kigezo cha `Node` lazima kiwe `NodeRef`, wakati `Type` inaweza kuwa `KV` (ikiashiria mpini kwenye jozi ya thamani muhimu) au `Edge` (ikiashiria mpini kwenye edge).
///
/// Kumbuka kuwa hata nodi za `Leaf` zinaweza kuwa na vipini vya `Edge`.
/// Badala ya kuwakilisha kiboreshaji kwa nodi ya mtoto, hizi zinawakilisha nafasi ambazo viashiria vya watoto vinaweza kwenda kati ya jozi za thamani muhimu.
/// Kwa mfano, katika node yenye urefu wa 2, kutakuwa na maeneo 3 yanayowezekana ya edge, moja kushoto kwa nodi, moja kati ya jozi mbili, na moja kulia kwa nodi.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Hatuhitaji ukamilifu kamili wa `#[derive(Clone)]`, kwani wakati pekee `Node` itakuwa "Clone" inayowezekana ni wakati ni kumbukumbu isiyoweza kubadilika na kwa hivyo `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Inarudisha node iliyo na edge au jozi ya thamani muhimu ufunguo huu wa kushughulikia.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Inarudisha nafasi ya kushughulikia hii kwenye node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Inaunda kipini kipya kwa jozi ya thamani muhimu katika `node`.
    /// Sio salama kwa sababu mpigaji lazima ahakikishe kuwa `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Inaweza kuwa utekelezaji wa umma wa PartialEq, lakini hutumiwa tu katika moduli hii.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Kwa muda huchukua mpini mwingine, usiobadilika kwenye eneo moja.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Hatuwezi kutumia Handle::new_kv au Handle::new_edge kwa sababu hatujui aina yetu
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Kwa usalama inasisitiza kwa mkusanyaji habari tuli kwamba node ya kushughulikia ni `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Kwa muda huchukua kiwambo kingine kinachoweza kubadilika katika eneo moja.
    /// Jihadharini, kwani njia hii ni hatari sana, mara mbili hivyo kwa kuwa inaweza kuonekana mara moja kuwa hatari.
    ///
    ///
    /// Kwa maelezo, angalia `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Hatuwezi kutumia Handle::new_kv au Handle::new_edge kwa sababu hatujui aina yetu
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Inaunda kipini kipya kwa edge katika `node`.
    /// Sio salama kwa sababu mpigaji lazima ahakikishe kuwa `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Kwa kupewa faharisi ya edge ambapo tunataka kuingiza ndani ya nodi iliyojazwa na uwezo, inahesabu faharisi ya busara ya KV ya sehemu ya mgawanyiko na mahali pa kuingiza.
///
/// Lengo la hatua ya kupasuliwa ni kwa ufunguo na thamani kuishia katika nodi ya mzazi;
/// funguo, maadili na kingo upande wa kushoto wa sehemu ya mgawanyiko huwa mtoto wa kushoto;
/// funguo, maadili na kingo za kulia kwa mahali pa kugawanyika huwa mtoto sahihi.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Toleo la Rust #74834 inajaribu kuelezea sheria hizi za ulinganifu.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inaingiza jozi mpya ya thamani kati ya jozi za thamani muhimu na kulia na kushoto kwa edge hii.
    /// Njia hii inadhania kuwa kuna nafasi ya kutosha katika nodi kwa jozi mpya kutoshea.
    ///
    /// Kielekezi kilichorudishwa kinaelekeza kwenye thamani iliyoingizwa.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inaingiza jozi mpya ya thamani kati ya jozi za thamani muhimu na kulia na kushoto kwa edge hii.
    /// Njia hii hugawanya node ikiwa hakuna nafasi ya kutosha.
    ///
    /// Kielekezi kilichorudishwa kinaelekeza kwenye thamani iliyoingizwa.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Hurekebisha pointer ya mzazi na faharisi katika node ya mtoto ambayo hii edge inaunganisha.
    /// Hii ni muhimu wakati kuagiza kingo kumebadilishwa,
    fn correct_parent_link(self) {
        // Unda kisanduku cha nyuma bila kubatilisha marejeo mengine ya nodi.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Inaingiza jozi mpya ya thamani muhimu na edge ambayo itaenda kulia kwa jozi hiyo mpya kati ya edge na jozi ya thamani muhimu kwa kulia kwa edge hii.
    /// Njia hii inadhania kuwa kuna nafasi ya kutosha katika nodi kwa jozi mpya kutoshea.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Inaingiza jozi mpya ya thamani muhimu na edge ambayo itaenda kulia kwa jozi hiyo mpya kati ya edge na jozi ya thamani muhimu kwa kulia kwa edge hii.
    /// Njia hii hugawanya node ikiwa hakuna nafasi ya kutosha.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inaingiza jozi mpya ya thamani kati ya jozi za thamani muhimu na kulia na kushoto kwa edge hii.
    /// Njia hii hugawanya nodi ikiwa hakuna nafasi ya kutosha, na inajaribu kuingiza sehemu iliyogawanywa kwenye nodi ya mzazi mara kwa mara, hadi mzizi ufikiwe.
    ///
    ///
    /// Ikiwa matokeo yaliyorudishwa ni `Fit`, node ya kushughulikia inaweza kuwa node ya edge au babu.
    /// Ikiwa matokeo yaliyorudishwa ni `Split`, uwanja wa `left` utakuwa kiini cha mizizi.
    /// Kielekezi kilichorudishwa kinaelekeza kwenye thamani iliyoingizwa.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Inapata node iliyoelekezwa na hii edge.
    ///
    /// Jina la njia linakubali miti ya picha na node ya mizizi juu.
    ///
    /// `edge.descend().ascend().unwrap()` na `node.ascend().unwrap().descend()` haipaswi kufanya chochote, juu ya mafanikio.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Tunahitaji kutumia viashiria mbichi kwa nodi kwa sababu, ikiwa BorrowType ni marker::ValMut, kunaweza kuwa na marejeleo bora yanayoweza kubadilika kwa maadili ambayo hatupaswi kubatilisha.
        // Hakuna wasiwasi kupata uwanja wa urefu kwa sababu thamani hiyo inakiliwa.
        // Jihadharini kwamba, mara tu kiashiria cha node kinaporejeshwa, tunapata safu ya kingo na rejeleo (toleo la Rust #73987) na kubatilisha marejeo mengine yoyote kwa au ndani ya safu, ikiwa kuna yoyote yuko karibu.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Hatuwezi kuita njia tofauti na njia tofauti, kwa sababu kuita ya pili kunabatilisha rejeleo lililorejeshwa na la kwanza.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Badilisha ufunguo na thamani ambayo kushughulikia KV inahusu.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Husaidia utekelezaji wa `split` kwa `NodeType` fulani, kwa kutunza data ya majani.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Inagawanya node ya msingi katika sehemu tatu:
    ///
    /// - Node imekataliwa kuwa na jozi zenye thamani muhimu kushoto kwa mpini huu.
    /// - Kitufe na thamani iliyoelekezwa kwa kushughulikia hii hutolewa.
    /// - Jozi zote za thamani muhimu kwa kulia kwa mpini huu zimewekwa kwenye node mpya iliyotengwa.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Huondoa jozi ya thamani muhimu iliyoelekezwa kwa kishikizo hiki na kuirudisha, pamoja na edge ambayo jozi ya thamani muhimu ilianguka.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Inagawanya node ya msingi katika sehemu tatu:
    ///
    /// - Node imekatwa kuwa na kingo na jozi za thamani muhimu kushoto kwa kipini hiki.
    /// - Kitufe na thamani iliyoelekezwa kwa kushughulikia hii hutolewa.
    /// - Pembe zote na jozi za thamani muhimu kwa kulia kwa mpini huu zimewekwa kwenye node mpya iliyotengwa.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Inawakilisha kikao cha kutathmini na kufanya operesheni ya kusawazisha karibu na jozi ya ndani ya thamani muhimu.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Inachagua muktadha wa kusawazisha unaojumuisha node kama mtoto, kwa hivyo kati ya KV mara moja kushoto au kulia katika nodi ya mzazi.
    /// Hurejesha `Err` ikiwa hakuna mzazi.
    /// Panics ikiwa mzazi hana kitu.
    ///
    /// Inapendelea upande wa kushoto, kuwa bora ikiwa nodi iliyopewa imejaa kwa njia fulani, ikimaanisha hapa tu kwamba ina vitu vichache kuliko ndugu yake wa kushoto na kuliko ndugu yake wa kulia, ikiwa zipo.
    /// Katika kesi hiyo, kuungana na ndugu wa kushoto ni haraka, kwani tunahitaji tu kusonga vitu vya N, n badala ya kuzisogeza kulia na kusonga zaidi ya vitu vya N mbele.
    /// Kuiba kutoka kwa ndugu wa kushoto pia kuna kasi zaidi, kwani tunahitaji tu kuhamisha vipengee vya n kwa upande wa kulia, badala ya kuhamisha angalau N ya vitu vya ndugu kushoto.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Hurejesha ikiwa inawezekana kuunganishwa, yaani, ikiwa kuna nafasi ya kutosha katika nodi ili kuchanganya KV ya kati na sehemu zote mbili za watoto zilizo karibu.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Inafanya kuungana na inaruhusu kufungwa kuamua nini cha kurudi.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // USALAMA: urefu wa nodi zilizounganishwa ni moja chini ya urefu
                // ya node ya edge hii, kwa hivyo juu ya sifuri, kwa hivyo ni ya ndani.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Huunganisha jozi ya thamani muhimu ya mzazi na nodi zote mbili za watoto zilizo karibu na nodi ya mtoto wa kushoto na kurudisha nodi ya mzazi iliyopungua.
    ///
    ///
    /// Panics isipokuwa sisi `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Huunganisha jozi ya thamani muhimu ya mzazi na nodi za watoto zilizo karibu katika nodi ya mtoto wa kushoto na kurudisha nodi hiyo ya mtoto.
    ///
    ///
    /// Panics isipokuwa sisi `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Huunganisha jozi ya thamani muhimu ya mzazi na nodi zote mbili za watoto zilizo karibu na nodi ya kushoto ya mtoto na kurudisha ushughulikiaji wa edge katika nodi ya mtoto ambapo mtoto aliyefuatiliwa edge aliishia
    ///
    ///
    /// Panics isipokuwa sisi `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Huondoa jozi ya thamani muhimu kutoka kwa mtoto wa kushoto na kuiweka katika uhifadhi wa dhamana ya mzazi, huku ikisukuma jozi ya zamani ya thamani ya mzazi kwa mtoto wa kulia.
    ///
    /// Hurejesha kipini kwa edge katika mtoto wa kulia inayolingana na mahali ambapo edge asili iliyoainishwa na `track_right_edge_idx` iliishia.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Huondoa jozi ya dhamana ya ufunguo kutoka kwa mtoto wa kulia na kuiweka kwenye uhifadhi wa thamani ya mzazi, huku ikisukuma jozi ya zamani ya thamani ya mzazi kwa mtoto wa kushoto.
    ///
    /// Hurejesha kipini kwa edge katika mtoto wa kushoto iliyoainishwa na `track_left_edge_idx`, ambayo haikusonga.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Hii haina kuiba sawa na `steal_left` lakini inaiba vitu vingi mara moja.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Hakikisha kwamba tunaweza kuiba salama.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Hoja data ya majani.
            {
                // Tengeneza nafasi ya vitu vilivyoibiwa kwa mtoto sahihi.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Sogeza vitu kutoka kwa mtoto wa kushoto kwenda kulia.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Hamisha jozi zilizoibiwa kushoto kwa mzazi.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Hamisha jozi ya thamani muhimu ya mzazi kwenda kwa mtoto wa kulia.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Tengeneza nafasi ya kingo zilizoibiwa.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Wizi kingo.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Aina ya ulinganifu ya `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Hakikisha kwamba tunaweza kuiba salama.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Hoja data ya majani.
            {
                // Hamisha jozi zilizoibiwa kulia kwa mzazi.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Hamisha jozi ya thamani ya ufunguo wa mzazi kwenda kwa mtoto wa kushoto.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Hoja vitu kutoka kwa mtoto wa kulia kwenda kushoto.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Jaza pengo ambapo vitu vilivyoibiwa vilikuwa.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Wizi kingo.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Jaza pengo ambapo kingo zilizoibiwa zilikuwa hapo awali.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Huondoa habari zozote zinazosisitiza kwamba nodi hii ni nodi ya `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Huondoa habari yoyote tuli inayosisitiza kwamba nodi hii ni nodi ya `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Hukagua ikiwa msingi wa msingi ni nodi ya `Internal` au node ya `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Sogeza kiambishi baada ya `self` kutoka nodi moja hadi nyingine.`right` lazima iwe tupu.
    /// edge ya kwanza ya `right` bado haibadilika.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Matokeo ya kuingizwa, wakati node inahitajika kupanua zaidi ya uwezo wake.
pub struct SplitResult<'a, K, V, NodeType> {
    // Node iliyobadilishwa kwenye mti uliopo na vitu na kingo ambazo ni za kushoto kwa `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Baadhi ya ufunguo na thamani hugawanyika, kuingizwa mahali pengine.
    pub kv: (K, V),
    // Inayomilikiwa, isiyoambatanishwa, nodi mpya na vitu na kingo ambazo ni za kulia kwa `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ikiwa marejeleo ya nodi ya aina hii ya kukopa huruhusu kupita kwenye nodi zingine kwenye mti.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Usafiri hauhitajiki, hufanyika kwa kutumia matokeo ya `borrow_mut`.
        // Kwa kulemaza kupita, na kuunda tu marejeo mapya kwa mizizi, tunajua kwamba kila kumbukumbu ya aina ya `Owned` iko kwenye nodi ya mizizi.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Huingiza thamani kwenye kipande cha vitu vilivyoanzishwa na kufuatiwa na kipengee kimoja ambacho hakijaanzishwa.
///
/// # Safety
/// Kipande kina zaidi ya vitu `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Huondoa na kurudisha dhamana kutoka kwa kipande cha vitu vyote vilivyoanzishwa, ikiacha nyuma kitu kimoja kisichojulikana.
///
///
/// # Safety
/// Kipande kina zaidi ya vitu `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Inabadilisha vitu kwenye nafasi ya `distance` kushoto.
///
/// # Safety
/// Kipande kina angalau vitu vya `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Huhamisha vipengee kwenye nafasi za `distance` kulia.
///
/// # Safety
/// Kipande kina angalau vitu vya `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Husogeza maadili yote kutoka kwa kipande cha vitu vilivyoanzishwa hadi kipande cha vitu visivyoanzishwa, ikiacha `src` kama yote ambayo haijasanidiwa.
///
/// Inafanya kazi kama `dst.copy_from_slice(src)` lakini haiitaji `T` kuwa `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;