use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Msingi wa iterator ambayo inaunganisha pato la iterators mbili zinazopanda sana, kwa mfano umoja au tofauti ya ulinganifu.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Viashiria kwa kasi zaidi kuliko kufunika iterators zote mbili kwa urahisi, labda kwa sababu tunaweza kumudu kulazimisha FusedIterator amefungwa.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Inaunda msingi mpya wa iterator kuunganisha jozi ya vyanzo.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Hurejesha jozi inayofuata ya vitu vinavyotokana na jozi ya vyanzo kuunganishwa.
    /// Ikiwa chaguzi zote mbili zilizorudishwa zina thamani, thamani hiyo ni sawa na hufanyika katika vyanzo vyote viwili.
    /// Ikiwa moja ya chaguzi zilizorejeshwa zina dhamana, thamani hiyo haipatikani kwenye chanzo kingine (au vyanzo havipandi kabisa).
    ///
    /// Ikiwa hakuna chaguo lililorudishwa lenye dhamana, iteration imekamilika na simu zinazofuata zitarudisha jozi zile zile tupu.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Inarudisha jozi ya mipaka ya juu kwa `size_hint` ya iterator ya mwisho.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}