use core::marker::PhantomData;
use core::ptr::NonNull;

/// Huonyesha kurudishwa kwa rejeleo la kipekee, wakati unajua kuwa malipo na uzao wake wote (yaani, viashiria vyote na marejeleo yanayotokana nayo) hayatatumika tena wakati fulani, baada ya hapo unataka kutumia rejeleo la kipekee la kipekee tena .
///
///
/// Kikaguaji cha kukopa kawaida hushughulikia mkusanyiko huu wa kukopa kwako, lakini udhibiti fulani unatimiza stacking hii ni ngumu sana kwa mkusanyaji kufuata.
/// `DormantMutRef` hukuruhusu kukagua kujikopa, wakati bado unaelezea asili yake iliyowekwa, na kuambatanisha nambari mbichi ya kiashiria inayohitajika kufanya hii bila tabia isiyojulikana.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Piga mkopo wa kipekee, na uikopeshe mara moja.
    /// Kwa mkusanyaji, maisha ya kumbukumbu mpya ni sawa na wakati wa rejeleo la asili, lakini wewe kuahidi kuitumia kwa kipindi kifupi.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // USALAMA: tunashikilia kukopa kote 'kupitia `_marker`, na tunafunua
        // rejea hii tu, kwa hivyo ni ya kipekee.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Rejea kwa kukopa kwa kipekee iliyokamatwa hapo awali.
    ///
    /// # Safety
    ///
    /// Kutoa tena lazima kumalizike, yaani, rejeleo lililorejeshwa na `new` na viashiria vyote na marejeleo yanayotokana nayo, hayapaswi kutumiwa tena.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // USALAMA: hali yetu ya usalama inamaanisha rejea hii ni ya kipekee tena.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;