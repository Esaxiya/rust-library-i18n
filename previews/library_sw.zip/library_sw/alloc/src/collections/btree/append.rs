use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Inatumia jozi zote za thamani muhimu kutoka kwa umoja wa iterators mbili zinazopanda, ikiongeza kutofautiana kwa `length` njiani.Mwisho hufanya iwe rahisi kwa mpigaji kuepusha kuvuja wakati mshughulikiaji wa matone anaogopa.
    ///
    /// Ikiwa iterators zote mbili zinatoa kitufe kimoja, njia hii inashusha jozi kutoka kwa iterator ya kushoto na inaongeza jozi kutoka kwa iterator ya kulia.
    ///
    /// Ikiwa unataka mti uishe kwa mpangilio mkali, kama kwa `BTreeMap`, iterators zote mbili zinapaswa kutoa funguo kwa mpangilio mkali, kila moja kubwa kuliko funguo zote kwenye mti, pamoja na funguo zozote zilizopo kwenye mti wakati wa kuingia.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Tunatayarisha kuunganisha `left` na `right` katika mlolongo uliopangwa kwa wakati ulio sawa.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Wakati huo huo, tunaunda mti kutoka kwa mlolongo uliopangwa kwa wakati ulio sawa.
        self.bulk_push(iter, length)
    }

    /// Inasukuma jozi zote za thamani muhimu hadi mwisho wa mti, ikiongeza kutofautiana kwa `length` njiani.
    /// Mwisho hufanya iwe rahisi kwa mpigaji kuepusha kuvuja wakati iterator inashtuka.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Gawanya jozi zote za thamani muhimu, ukizisukuma kwenye nodi katika kiwango sahihi.
        for (key, value) in iter {
            // Jaribu kushinikiza jozi ya thamani muhimu kwenye nodi ya jani ya sasa.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Hakuna nafasi iliyobaki, nenda juu na kushinikiza huko.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Pata node iliyo na nafasi ya kushoto, bonyeza hapa.
                                open_node = parent;
                                break;
                            } else {
                                // Nenda tena.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Tuko juu, tengeneza nodi mpya ya mizizi na sukuma hapo.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Bonyeza jozi ya thamani muhimu na sehemu ndogo mpya ya kulia.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Nenda chini kwenye jani la kulia zaidi.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Urefu wa kuongezeka kila kukokotoa, ili kuhakikisha kuwa ramani inadondosha vitu vilivyoongezwa hata ikiwa inaendeleza iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterator ya kuunganisha mfuatano uliopangwa kuwa moja
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ikiwa funguo mbili ni sawa, inarudisha jozi ya thamani muhimu kutoka chanzo sahihi.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}