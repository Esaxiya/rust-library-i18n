#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Yaliyomo kwenye kumbukumbu mpya hayakuanzishwa.
    Uninitialized,
    /// Kumbukumbu mpya ni uhakika kuwa zeroed.
    Zeroed,
}

/// Huduma ya kiwango cha chini cha kutenga zaidi ergonomic, kuhamisha, na kusambaza bafa ya kumbukumbu kwenye lundo bila kuwa na wasiwasi juu ya kesi zote za kona zinazohusika.
///
/// Aina hii ni bora kwa kujenga miundo yako ya data kama Vec na VecDeque.
/// Hasa:
///
/// * Inazalisha `Unique::dangling()` kwa aina za saizi.
/// * Inazalisha `Unique::dangling()` kwa mgao wa urefu wa sifuri.
/// * Inepuka kukomboa `Unique::dangling()`.
/// * Inakamata mafuriko yote katika hesabu za uwezo (inakuza kwa "capacity overflow" panics).
/// * Walinzi dhidi ya mifumo 32-bit inayotenga zaidi ya baiti isize::MAX.
/// * Walinzi dhidi ya kufurika urefu wako.
/// * Inapiga simu `handle_alloc_error` kwa mgao usiofaa.
/// * Inayo `ptr::Unique` na kwa hivyo inampa mtumiaji faida zote zinazohusiana.
/// * Inatumia ziada iliyorudishwa kutoka kwa mgawaji kutumia uwezo mkubwa zaidi unaopatikana.
///
/// Aina hii haina kukagua kumbukumbu ambayo inasimamia.Ikiachwa *itatoa kumbukumbu yake, lakini* haitajaribu kuacha yaliyomo.
/// Ni juu ya mtumiaji wa `RawVec` kushughulikia vitu halisi *vilivyohifadhiwa* ndani ya `RawVec`.
///
/// Kumbuka kuwa ziada ya aina zenye ukubwa wa sifuri daima hazina mwisho, kwa hivyo `capacity()` inarudisha `usize::MAX` kila wakati.
/// Hii inamaanisha kuwa unahitaji kuwa mwangalifu wakati wa kuzunguka aina hii na `Box<[T]>`, kwani `capacity()` haitatoa urefu.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Hii ipo kwa sababu `#[unstable]` `const fn`s hazihitaji kufuata `min_const_fn` na kwa hivyo haziwezi kuitwa katika`min_const_fn`s pia.
    ///
    /// Ukibadilisha `RawVec<T>::new` au utegemezi, tafadhali jihadharini usilete kitu chochote ambacho kitakiuka `min_const_fn`.
    ///
    /// NOTE: Tunaweza kuzuia udanganyifu huu na kuangalia kufanana na sifa fulani ya `#[rustc_force_min_const_fn]` ambayo inahitaji kufanana na `min_const_fn` lakini hairuhusu kuiita kwa `stable(...) const fn`/nambari ya mtumiaji isiyowezesha `foo` wakati `#[rustc_const_unstable(feature = "foo", issue = "01234")]` iko.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Inaunda `RawVec` kubwa zaidi (kwenye lundo la mfumo) bila kutenga.
    /// Ikiwa `T` ina saizi nzuri, basi hii hufanya `RawVec` na uwezo wa `0`.
    /// Ikiwa `T` ina ukubwa wa sifuri, basi inafanya `RawVec` na uwezo wa `usize::MAX`.
    /// Muhimu kwa kutekeleza ugawaji uliocheleweshwa.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Inaunda `RawVec` (kwenye lundo la mfumo) na uwezo na mahitaji ya mpangilio wa `[T; capacity]`.
    /// Hii ni sawa na kupiga `RawVec::new` wakati `capacity` ni `0` au `T` ni saizi ya sifuri.
    /// Kumbuka kuwa ikiwa `T` ina ukubwa wa sifuri hii inamaanisha hautapata `RawVec` na uwezo ulioombwa.
    ///
    /// # Panics
    ///
    /// Panics ikiwa uwezo ulioombwa unazidi baiti za `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Utoaji mimba kwa OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kama `with_capacity`, lakini inahakikishia bafa imefungwa.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Inarekebisha `RawVec` kutoka kwa pointer na uwezo.
    ///
    /// # Safety
    ///
    /// `ptr` lazima igawanywe (kwenye lundo la mfumo), na kwa `capacity` iliyopewa.
    /// `capacity` haiwezi kuzidi `isize::MAX` kwa aina za ukubwa.(wasiwasi tu kwenye mifumo 32-bit).
    /// ZST vectors inaweza kuwa na uwezo hadi `usize::MAX`.
    /// Ikiwa `ptr` na `capacity` zinatoka kwa `RawVec`, basi hii imehakikishiwa.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs ndogo ni bubu.Ruka kwa:
    // - 8 ikiwa saizi ya kipengee ni 1, kwa sababu wagawaji wowote wa lundo wanaweza kumaliza ombi la chini ya ka 8 hadi angalau ka 8.
    //
    // - 4 ikiwa vitu vina ukubwa wa wastani (<=1 KiB).
    // - 1 vinginevyo, ili kuepuka kupoteza nafasi nyingi kwa Vecs fupi sana.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Kama `new`, lakini imewekwa parameter juu ya chaguo la mtengaji wa `RawVec` iliyorejeshwa.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` inamaanisha "unallocated".aina za ukubwa wa sifuri hupuuzwa.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Kama `with_capacity`, lakini imewekwa parameter juu ya chaguo la mtengaji wa `RawVec` iliyorejeshwa.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Kama `with_capacity_zeroed`, lakini imewekwa parameter juu ya chaguo la mtengaji wa `RawVec` iliyorejeshwa.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Inabadilisha `Box<[T]>` kuwa `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Inabadilisha bafa nzima kuwa `Box<[MaybeUninit<T>]>` na `len` iliyoainishwa.
    ///
    /// Kumbuka kuwa hii itaunda upya mabadiliko yoyote ya `cap` ambayo yanaweza kufanywa.(Angalia maelezo ya aina kwa maelezo.)
    ///
    /// # Safety
    ///
    /// * `len` lazima iwe kubwa kuliko au sawa na uwezo ulioombwa hivi karibuni, na
    /// * `len` lazima iwe chini au sawa na `self.capacity()`.
    ///
    /// Kumbuka, kwamba uwezo ulioombwa na `self.capacity()` zinaweza kutofautiana, kwani mtengaji anaweza kushiriki na kurudisha kumbukumbu kubwa kuliko ilivyoombwa.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Usafi angalia nusu moja ya mahitaji ya usalama (hatuwezi kuangalia nusu nyingine).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Tunaepuka `unwrap_or_else` hapa kwa sababu inazuia kiwango cha LLVM IR kilichozalishwa.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Inatengeneza tena `RawVec` kutoka kwa kiboreshaji, uwezo, na kitengaji.
    ///
    /// # Safety
    ///
    /// `ptr` lazima igawanywe (kupitia mtoaji aliyopewa `alloc`), na na `capacity` iliyopewa.
    /// `capacity` haiwezi kuzidi `isize::MAX` kwa aina za ukubwa.
    /// (wasiwasi tu kwenye mifumo 32-bit).
    /// ZST vectors inaweza kuwa na uwezo hadi `usize::MAX`.
    /// Ikiwa `ptr` na `capacity` zinatoka kwa `RawVec` iliyoundwa kupitia `alloc`, basi hii imehakikishiwa.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Inapata pointer mbichi hadi mwanzo wa mgao.
    /// Kumbuka kuwa hii ni `Unique::dangling()` ikiwa `capacity == 0` au `T` ni saizi ya sifuri.
    /// Katika kesi ya zamani, lazima uwe mwangalifu.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Inapata uwezo wa mgao.
    ///
    /// Hii itakuwa `usize::MAX` kila wakati ikiwa `T` ina ukubwa wa sifuri.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Hurejesha rejeleo lililoshirikiwa kwa mtengaji akiunga mkono `RawVec` hii.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tunayo kumbukumbu iliyotengwa, kwa hivyo tunaweza kupitisha ukaguzi wa wakati wa kukimbia ili kupata mpangilio wetu wa sasa.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Inahakikisha kuwa bafa ina angalau nafasi ya kutosha kushikilia vipengee vya `len + additional`.
    /// Ikiwa tayari haina uwezo wa kutosha, itabadilisha nafasi ya kutosha pamoja na nafasi nzuri ya upole ili kupata tabia ya kupunguzwa *O*(1).
    ///
    /// Itapunguza tabia hii ikiwa itajisababisha panic.
    ///
    /// Ikiwa `len` inazidi `self.capacity()`, hii inaweza kushindwa kutenga nafasi iliyoombwa.
    /// Hii sio salama kabisa, lakini nambari isiyo salama * unayoandika ambayo inategemea tabia ya kazi hii inaweza kuvunjika.
    ///
    /// Hii ni bora kwa kutekeleza operesheni ya kushinikiza kwa wingi kama `extend`.
    ///
    /// # Panics
    ///
    /// Panics ikiwa uwezo mpya unazidi kaiti `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Utoaji mimba kwa OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // hifadhi ingekuwa imetoa mimba au hofu ikiwa len ilizidi `isize::MAX` kwa hivyo hii ni salama kufanya bila kukaguliwa sasa.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Sawa na `reserve`, lakini inarudi kwa makosa badala ya kuhofia au kutoa mimba.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Inahakikisha kuwa bafa ina angalau nafasi ya kutosha kushikilia vipengee vya `len + additional`.
    /// Ikiwa haiko tayari, itahamisha kiwango cha chini cha kumbukumbu muhimu.
    /// Kwa jumla hii itakuwa sawa na kumbukumbu inayohitajika, lakini kimsingi mtengaji yuko huru kurudisha zaidi ya vile tulivyoomba.
    ///
    ///
    /// Ikiwa `len` inazidi `self.capacity()`, hii inaweza kushindwa kutenga nafasi iliyoombwa.
    /// Hii sio salama kabisa, lakini nambari isiyo salama * unayoandika ambayo inategemea tabia ya kazi hii inaweza kuvunjika.
    ///
    /// # Panics
    ///
    /// Panics ikiwa uwezo mpya unazidi kaiti `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Utoaji mimba kwa OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sawa na `reserve_exact`, lakini inarudi kwa makosa badala ya kuhofia au kutoa mimba.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Inapunguza mgao hadi kiasi kilichoainishwa.
    /// Ikiwa kiasi kilichopewa ni 0, kweli inashughulika kabisa.
    ///
    /// # Panics
    ///
    /// Panics ikiwa kiasi kilichopewa ni *kubwa* kuliko uwezo wa sasa.
    ///
    /// # Aborts
    ///
    /// Utoaji mimba kwa OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Hurejesha ikiwa bafa inahitaji kukua ili kutimiza uwezo wa ziada unaohitajika.
    /// Hasa kutumika kufanya akiba ya-akiba-wito iwezekanavyo bila kupachika `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Njia hii kawaida husisitizwa mara nyingi.Kwa hivyo tunataka iwe ndogo iwezekanavyo, kuboresha nyakati za kukusanya.
    // Lakini pia tunataka yaliyomo ndani yake kuwa ya hesabu ya hesabu iwezekanavyo, ili kufanya nambari iliyozalishwa iende haraka.
    // Kwa hivyo, njia hii imeandikwa kwa uangalifu ili nambari yote ambayo inategemea `T` iko ndani yake, wakati nambari nyingi ambayo haitegemei `T` iwezekanavyo iko katika kazi ambazo sio za kawaida zaidi ya `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Hii inahakikishwa na muktadha wa wito.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Kwa kuwa tunarudisha uwezo wa `usize::MAX` wakati `elem_size` iko
            // 0, kufika hapa inamaanisha kuwa `RawVec` imejaa zaidi.
            return Err(CapacityOverflow);
        }

        // Hakuna kitu tunaweza kufanya kweli juu ya hundi hizi, kwa kusikitisha.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Hii inahakikishia ukuaji wa kielelezo.
        // Kuzidisha hakuwezi kufurika kwa sababu `cap <= isize::MAX` na aina ya `cap` ni `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` sio ya kawaida zaidi ya `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Vikwazo vya njia hii ni sawa na ile ya `grow_amortized`, lakini njia hii kawaida husisitizwa mara nyingi kwa hivyo sio muhimu sana.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Kwa kuwa tunarudisha uwezo wa `usize::MAX` wakati saizi ya aina ni
            // 0, kufika hapa inamaanisha kuwa `RawVec` imejaa zaidi.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` sio ya kawaida zaidi ya `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Kazi hii iko nje ya `RawVec` ili kupunguza nyakati za kukusanya.Tazama maoni hapo juu `RawVec::grow_amortized` kwa maelezo.
// (Kigezo cha `A` sio muhimu, kwa sababu idadi ya aina tofauti za `A` zinazoonekana katika mazoezi ni ndogo sana kuliko idadi ya aina za `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Angalia kosa hapa ili kupunguza ukubwa wa `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Mgawaji anakagua usawa wa usawa
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Huruhusu kumbukumbu inayomilikiwa na `RawVec`*bila* kujaribu kuacha yaliyomo.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Kazi kuu ya utunzaji wa makosa ya akiba.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Tunahitaji kuhakikisha yafuatayo:
// * Hatuna kamwe kutenga vitu vya ukubwa wa `> isize::MAX`.
// * Hatuzidi `usize::MAX` na kweli tunatenga kidogo sana.
//
// Kwenye 64-bit tunahitaji tu kuangalia kufurika kwani kujaribu kutenga baiti za `> isize::MAX` hakika kutashindwa.
// Kwenye 32-bit na 16-bit tunahitaji kuongeza walinzi wa ziada kwa hili ikiwa tunaendesha kwenye jukwaa ambalo linaweza kutumia 4GB zote katika nafasi ya mtumiaji, kwa mfano, PAE au x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Jukumu moja kuu linalowajibika kwa kuripoti uwezo wa kuripoti.
// Hii itahakikisha kuwa kizazi cha nambari zinazohusiana na hizi panics ni ndogo kwani kuna eneo moja tu ambalo panics badala ya rundo kwenye moduli.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}