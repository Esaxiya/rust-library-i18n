#![stable(feature = "wake_trait", since = "1.51.0")]
//! Aina na Traits za kufanya kazi na majukumu ya kupendeza.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Utekelezaji wa kuamka kazi kwa msimamizi.
///
/// trait hii inaweza kutumika kuunda [`Waker`].
/// Msimamizi anaweza kufafanua utekelezaji wa trait hii, na atumie kujenga Waker kupitisha majukumu ambayo hutekelezwa kwa msimamizi huyo.
///
/// trait hii ni njia salama ya kumbukumbu na ergonomic ya kujenga [`RawWaker`].
/// Inasaidia muundo wa kawaida wa wasimamizi ambao data inayotumika kuamsha kazi imehifadhiwa kwenye [`Arc`].
/// Wasimamizi wengine (haswa wale wa mifumo iliyoingia) hawawezi kutumia API hii, ndiyo sababu [`RawWaker`] ipo kama mbadala wa mifumo hiyo.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Kazi ya msingi ya `block_on` ambayo inachukua future na kuikamilisha kwenye uzi wa sasa.
///
/// **Note:** Mfano huu hufanya biashara kwa usahihi kwa unyenyekevu.
/// Ili kuzuia vikwazo, utekelezaji wa kiwango cha uzalishaji pia utahitaji kushughulikia simu za kati kwa `thread::unpark` na pia maombi ya kiota.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// A waker ambayo huamsha uzi wa sasa wakati inaitwa.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Endesha future hadi ukamilishe kwenye uzi wa sasa.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Bandika future ili iweze kupigwa kura.
///     let mut fut = Box::pin(fut);
///
///     // Unda muktadha mpya kupitishwa kwa future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Endesha future hadi ukamilishe.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Amka kazi hii.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Amka kazi hii bila kutumia waker.
    ///
    /// Ikiwa msimamizi anaunga mkono njia ya bei rahisi ya kuamka bila kutumia waker, inapaswa kubatilisha njia hii.
    /// Kwa chaguo-msingi, inashikilia [`Arc`] na inaita [`wake`] kwenye koni.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // USALAMA: Hii ni salama kwa sababu raw_waker huunda salama
        // RawWaker kutoka Tao<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Kazi hii ya faragha ya kuunda RawWaker hutumiwa, badala ya
// kuweka hii ndani ya uingizaji wa `From<Arc<W>> for RawWaker`, kuhakikisha kuwa usalama wa `From<Arc<W>> for Waker` hautegemei trait sahihi, badala yake impls zote huita kazi hii moja kwa moja na wazi.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ongeza hesabu ya kumbukumbu ya arc ili kuibadilisha.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Amka kwa thamani, ukisogeza Safu kwenye kazi ya Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Amka kwa rejeleo, funga waker katika ManuallyDrop ili kuepuka kuiangusha
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Punguza hesabu ya kumbukumbu ya Safu kwenye tone
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}