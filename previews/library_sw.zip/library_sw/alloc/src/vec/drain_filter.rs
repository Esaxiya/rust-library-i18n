use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Iterator ambayo hutumia kufungwa ili kubaini ikiwa kipengee kinapaswa kuondolewa.
///
/// Muundo huu umeundwa na [`Vec::drain_filter`].
/// Tazama nyaraka zake kwa zaidi.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Faharisi ya kitu ambacho kitakaguliwa na simu inayofuata kwenda `next`.
    pub(super) idx: usize,
    /// Idadi ya vitu ambavyo vimetolewa (removed) hadi sasa.
    pub(super) del: usize,
    /// Urefu wa asili wa `vec` kabla ya kukimbia.
    pub(super) old_len: usize,
    /// Kiarifu cha jaribio la kichujio.
    pub(super) pred: F,
    /// Bendera ambayo inaonyesha panic imetokea katika kiarifu cha jaribio la kichujio.
    /// Hii inatumiwa kama kidokezo katika utekelezaji wa kushuka ili kuzuia matumizi ya salio la `DrainFilter`.
    /// Vitu vyovyote visivyosindikwa vitarejeshwa nyuma katika `vec`, lakini hakuna vitu zaidi vitakavyoangushwa au kupimwa na mtabiri wa kichujio.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Hurejesha rejeleo kwa msambazaji wa msingi.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Sasisha faharisi *baada ya* kiarifu kuitwa.
                // Ikiwa faharasa inasasishwa kabla na kiashiria panics, kipengee kwenye faharisi hii kitavuja.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Hii ni hali nzuri iliyochanganyikiwa, na hakuna jambo dhahiri sahihi la kufanya.
                        // Hatutaki kuendelea kujaribu kutekeleza `pred`, kwa hivyo tunarudisha nyuma vitu vyote ambavyo havijasindika na kuwaambia vec kuwa bado zipo.
                        //
                        // Sehemu ya nyuma inahitajika ili kuzuia tone-mbili la kipengee cha mwisho kilichofanikiwa kabla ya panic katika kielekezi.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Jaribu kutumia vipengee vyovyote vilivyobaki ikiwa kisingizio cha kichungi bado hakijaogopa.
        // Tutarudisha nyuma vitu vyovyote vilivyobaki ikiwa tayari tumeogopa au ikiwa matumizi hapa panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}