use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Alama ya utaalam ya kukusanya bomba la iterator ndani ya Vec wakati unatumia tena ugawaji wa chanzo, yaani
/// kutekeleza bomba mahali pake.
///
/// Mzazi wa SourceIter trait ni muhimu kwa kazi maalum ya kupata mgawo ambao utatumiwa tena.
/// Lakini haitoshi kwa utaalam kuwa halali.
/// Tazama mipaka ya ziada kwenye impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-ndani SourceIter/InPlaceIterable traits hutekelezwa tu na minyororo ya Adapter <Adapter<Adapter<IntoIter>>> (zote zinamilikiwa na core/std).
// Mipaka ya ziada kwenye utekelezaji wa adapta (zaidi ya `impl<I: Trait> Trait for Adapter<I>`) inategemea tu traits zingine ambazo tayari zimetiwa alama kama utaalam traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. alama haitegemei maisha ya aina zinazotolewa na watumiaji.Modulo shimo la Nakili, ambalo utaalam zingine kadhaa tayari hutegemea.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Mahitaji ya ziada ambayo hayawezi kuonyeshwa kupitia trait bound.Tunategemea const eval badala yake:
        // a) hakuna ZSTs kwani hakutakuwa na mgao wa kutumia tena na hesabu ya pointer ingekuwa panic b) saizi inayolingana na inavyotakiwa na mkataba wa Alloc c) usawa wa mechi kama inavyotakiwa na mkataba wa Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // kurudi kwa utekelezaji zaidi wa generic
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // tumia jaribu tangu
        // - inaboresha vyema kwa adapta zingine za iterator
        // - tofauti na njia nyingi za ndani za kukokota, inachukua tu ubinafsi wa &mut
        // - inatuacha tushike pointer ya kuandika kupitia matumbo yake na kuirudisha mwishowe
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration imefanikiwa, usishuke kichwa
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // angalia ikiwa mkataba wa SourceIter ulizingatiwa onyo: ikiwa hazingekuwa hivyo hatuwezi hata kufikia hatua hii
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // angalia Mkataba wa InPlaceIterable.Hii inawezekana tu ikiwa iterator iliendeleza kiboreshaji cha chanzo kabisa.
        // Ikiwa inatumia ufikiaji ambao haujakaguliwa kupitia TrustedRandomAccess basi pointer ya chanzo itakaa katika nafasi yake ya kwanza na hatuwezi kuitumia kama rejeleo
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // toa maadili yoyote yaliyobaki kwenye mkia wa chanzo lakini uzuie kushuka kwa mgao yenyewe mara tu IntoIter itakapopotea ikiwa tone la panics basi pia tunavuja vitu vyovyote vilivyokusanywa kwenye dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // Mkataba wa InPlaceIterable hauwezi kudhibitishwa hapa kwa kuwa try_fold ina rejeleo la kipekee kwa kielekezi chanzo tunachoweza kufanya ni kuangalia ikiwa bado iko katika anuwai
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}