use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Utaalam trait kutumika kwa Vec::from_iter
///
/// ## Grafu ya ujumbe:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Kesi ya kawaida inapitisha vector kuwa kazi ambayo hukusanya tena vector.
        // Tunaweza kuzunguka mzunguko huu ikiwa IntoIter haijasonga mbele kabisa.
        // Wakati imekuwa ya juu Tunaweza pia kutumia tena kumbukumbu na kusogeza data mbele.
        // Lakini tunafanya hivyo tu wakati Vec inayosababisha haingekuwa na uwezo zaidi wa kuitumia kuliko kuiunda kupitia utekelezaji wa generic FromIterator.
        //
        // Upeo huo sio lazima sana kwani tabia ya mgao wa Vec haijulikani kwa makusudi.
        // Lakini ni chaguo la kihafidhina.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // lazima ikabidhi kwa spec_extend() kwa kuwa extend() yenyewe ni mjumbe kwa spec_from kwa Vecs tupu
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Hii hutumia `iterator.as_slice().to_vec()` kwani spec_extend lazima ichukue hatua zaidi za kufikiria juu ya uwezo wa mwisho + na kwa hivyo kufanya kazi zaidi.
// `to_vec()` hutenga moja kwa moja kiwango sahihi na huijaza haswa.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): na cfg(test) njia asili ya `[T]::to_vec`, ambayo inahitajika kwa ufafanuzi wa njia hii, haipatikani.
    // Badala yake tumia kazi ya `slice::to_vec` ambayo inapatikana tu na cfg(test) NB angalia moduli ya slice::hack katika slice.rs kwa habari zaidi
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}