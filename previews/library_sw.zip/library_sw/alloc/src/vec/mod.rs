//! Aina ya safu inayoweza kukua na yaliyomo kwenye lundo, iliyoandikwa `Vec<T>`.
//!
//! Vectors zina faharisi ya `O(1)`, kushinikiza `O(1)` (hadi mwisho) na `O(1)` pop (kutoka mwisho).
//!
//!
//! Vectors wanahakikisha kuwa hawagawi zaidi ya ka `isize::MAX`.
//!
//! # Examples
//!
//! Unaweza kuunda [`Vec`] wazi na [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... au kwa kutumia jumla ya [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // sifuri kumi
//! ```
//!
//! Unaweza kuweka maadili ya [`push`] mwisho wa vector (ambayo itakua vector inahitajika):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Maadili ya popping hufanya kazi kwa njia ile ile:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors pia inasaidia kuorodhesha (kupitia [`Index`] na [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Aina ya safu inayoweza kukua, iliyoandikwa kama `Vec<T>` na kutamka 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Macro ya [`vec!`] hutolewa ili kufanya uanzishaji uwe rahisi zaidi:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Inaweza pia kuanzisha kila kipengee cha `Vec<T>` na thamani iliyopewa.
/// Hii inaweza kuwa na ufanisi zaidi kuliko kutekeleza ugawaji na uanzishaji kwa hatua tofauti, haswa wakati wa kuanzisha vector ya zero.
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ifuatayo ni sawa, lakini inaweza kuwa polepole:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Kwa habari zaidi, angalia [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Tumia `Vec<T>` kama mpangilio mzuri:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Machapisho 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Aina ya `Vec` inaruhusu kufikia maadili kwa faharisi, kwa sababu inatumia [`Index`] trait.Mfano utakuwa wazi zaidi:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // itaonyesha '2'
/// ```
///
/// Walakini kuwa mwangalifu: ukijaribu kupata faharisi ambayo haiko kwenye `Vec`, programu yako itakuwa panic!Huwezi kufanya hivi:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Tumia [`get`] na [`get_mut`] ikiwa unataka kuangalia ikiwa faharisi iko katika `Vec`.
///
/// # Slicing
///
/// `Vec` inaweza kubadilika.Kwa upande mwingine, vipande ni vitu vya kusoma tu.
/// Kupata [slice][prim@slice], tumia [`&`].Mfano:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... na hiyo ndiyo yote!
/// // unaweza pia kuifanya hivi:
/// let u: &[usize] = &v;
/// // au kama hii:
/// let u: &[_] = &v;
/// ```
///
/// Katika Rust, ni kawaida kupitisha vipande kama hoja badala ya vectors wakati unataka kutoa ufikiaji wa kusoma.Vivyo hivyo huenda kwa [`String`] na [`&str`].
///
/// # Uwezo na uhamishaji
///
/// Uwezo wa vector ni kiwango cha nafasi iliyotengwa kwa vitu vyovyote vya future ambavyo vitaongezwa kwenye vector.Hii haifai kuchanganyikiwa na *urefu* wa vector, ambayo inabainisha idadi ya vitu halisi ndani ya vector.
/// Ikiwa urefu wa vector unazidi uwezo wake, uwezo wake utaongezwa kiatomati, lakini vitu vyake vitapaswa kugawanywa tena.
///
/// Kwa mfano, vector yenye uwezo wa 10 na urefu 0 itakuwa vector tupu na nafasi ya vitu 10 zaidi.Kusukuma vitu 10 au vichache kwenye vector haitabadilisha uwezo wake au kusababisha ugawaji upya kutokea.
/// Walakini, ikiwa urefu wa vector umeongezeka hadi 11, italazimika kuhamisha, ambayo inaweza kuwa polepole.Kwa sababu hii, inashauriwa kutumia [`Vec::with_capacity`] kila inapowezekana kutaja ukubwa wa vector inatarajiwa kupata.
///
/// # Guarantees
///
/// Kwa sababu ya asili yake ya kushangaza sana, `Vec` hufanya dhamana nyingi juu ya muundo wake.Hii inahakikisha kuwa ni ya chini sana kama inavyowezekana katika hali ya jumla, na inaweza kudhibitiwa kwa usahihi kwa njia za zamani na nambari isiyo salama.Kumbuka kuwa dhamana hizi zinarejelea `Vec<T>` isiyostahiki.
/// Ikiwa vigezo vya aina ya ziada vimeongezwa (kwa mfano, kusaidia wagawaji wa kawaida), kupuuza chaguo-msingi zao kunaweza kubadilisha tabia.
///
/// Kimsingi, `Vec` ni na itakuwa siku zote (pointer, uwezo, urefu) tatu.Hakuna zaidi, sio chini.Mpangilio wa uwanja huu haujafahamika kabisa, na unapaswa kutumia njia zinazofaa kurekebisha hizi.
/// Pointer haitawahi kuwa batili, kwa hivyo aina hii imeboreshwa.
///
/// Walakini, pointer inaweza isionyeshe kumbukumbu iliyotengwa.
/// Hasa ikiwa utaunda `Vec` na uwezo 0 kupitia [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], au kwa kupiga [`shrink_to_fit`] kwenye Vec tupu, haitatoa kumbukumbu.Vivyo hivyo, ikiwa utahifadhi aina zenye ukubwa wa sifuri ndani ya `Vec`, haitatoa nafasi kwao.
/// *Kumbuka kuwa katika kesi hii `Vec` haiwezi kuripoti [`capacity`] ya 0*.
/// `Vec` itatenga ikiwa na ikiwa tu ["mem: : size_of::<T>`]`() * capacity()> 0`.
/// Kwa ujumla, maelezo ya mgao wa "Vec" ni ya hila sana-ikiwa unakusudia kutenga kumbukumbu kwa kutumia `Vec` na kuitumia kwa kitu kingine (ama kupitisha nambari isiyo salama, au kujenga mkusanyiko wako unaoungwa mkono na kumbukumbu), hakikisha kusambaza kumbukumbu hii kwa kutumia `from_raw_parts` kupata `Vec` na kisha kuiacha.
///
/// Ikiwa `Vec` * imetenga kumbukumbu, basi kumbukumbu inayoelekeza iko juu ya lundo (kama inavyofafanuliwa na mtengaji Rust imesanidiwa kutumiwa kwa chaguo-msingi), na alama yake ya kuelekeza kwa [`len`] imeanzisha, vitu vinavyoambatana ili (ungependa nini angalia ikiwa umeilazimisha kwa kipande), ikifuatiwa na [`capacity`]`,`[`len`] kimantiki isiyoanzishwa, vitu vinavyojumuisha.
///
///
/// vector iliyo na vitu `'a'` na `'b'` na uwezo wa 4 inaweza kuonyeshwa kama hapa chini.Sehemu ya juu ni muundo wa `Vec`, ina kiboreshaji kwa kichwa cha mgao katika lundo, urefu na uwezo.
/// Sehemu ya chini ni mgao kwenye lundo, kizuizi cha kumbukumbu.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** inawakilisha kumbukumbu ambayo haijaanzishwa, tazama [`MaybeUninit`].
/// - Note: ABI sio thabiti na `Vec` haitoi dhamana juu ya mpangilio wa kumbukumbu (pamoja na mpangilio wa uwanja).
///
/// `Vec` kamwe haitafanya "small optimization" ambapo vitu vimehifadhiwa kwenye stack kwa sababu mbili:
///
/// * Ingefanya iwe ngumu zaidi kwa nambari isiyo salama kutumia kwa usahihi `Vec`.Yaliyomo kwenye `Vec` hayangekuwa na anwani thabiti ikiwa ingehamishwa tu, na itakuwa ngumu zaidi kuamua ikiwa `Vec` ilikuwa imetenga kumbukumbu.
///
/// * Ingeadhibu kesi ya jumla, ikileta branch ya ziada kwenye kila ufikiaji.
///
/// `Vec` kamwe haitashuka yenyewe, hata ikiwa haina kitu.Hii inahakikisha hakuna mgao usiohitajika au ugawaji kutokea.Kutoa `Vec` na kisha kuijaza hadi [`len`] hiyo hiyo haipaswi kupata simu kwa mtengaji.Ikiwa unataka kufungua kumbukumbu isiyotumiwa, tumia [`shrink_to_fit`] au [`shrink_to`].
///
/// [`push`] na [`insert`] haita (re) kutenga ikiwa uwezo ulioripotiwa unatosha.[`push`] na [`insert`]* *(re) zitatenga ikiwa [`len`]```==`[` capacity`].Hiyo ni, uwezo ulioripotiwa ni sahihi kabisa, na unaweza kutegemewa.Inaweza hata kutumiwa kufungua kumbukumbu iliyotengwa na `Vec` ikiwa inataka.
/// Njia za kuingiza wingi * zinaweza kuhama tena, hata wakati sio lazima.
///
/// `Vec` haihakikishi mkakati wowote wa ukuaji wakati wa kuhamisha tena wakati umejaa, wala wakati [`reserve`] inaitwa.Mkakati wa sasa ni wa msingi na inaweza kudhibitisha kuhitajika kutumia sababu isiyo ya kawaida ya ukuaji.Mkakati wowote utumikao hakika itahakikisha *O*(1) imepunguzwa [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, na [`Vec::with_capacity(n)`][`Vec::with_capacity`], zote zitatoa `Vec` na uwezo ulioombwa haswa.
/// Ikiwa [`len`]`==`[`uwezo`], (kama ilivyo kwa jumla ya [`vec!`]), basi `Vec<T>` inaweza kubadilishwa kuwa na kutoka [`Box<[T]>`][owned slice] bila kuhamisha au kuhamisha vitu.
///
/// `Vec` haitaandika kabisa data yoyote ambayo imeondolewa kutoka kwake, lakini pia haitaihifadhi haswa.Kumbukumbu yake isiyojulikana ni nafasi ya mwanzo ambayo inaweza kutumia hata inavyotaka.Kwa ujumla itafanya tu chochote kinachofaa zaidi au vinginevyo rahisi kutekeleza.Usitegemee data iliyoondolewa kufutwa kwa sababu za usalama.
/// Hata ukiacha `Vec`, bafa yake inaweza kutumika tena na `Vec` nyingine.
/// Hata kama utakumbuka kumbukumbu ya "Vec" kwanza, hiyo haiwezi kutokea kwa sababu kiboreshaji haizingatii athari hii ambayo inapaswa kuhifadhiwa.
/// Kuna kesi moja ambayo hatutaivunja, hata hivyo: kutumia nambari ya `unsafe` kuandika kwa uwezo wa ziada, na kisha kuongeza urefu kulinganisha, daima ni halali.
///
/// Hivi sasa, `Vec` haihakikishi mpangilio ambao vitu vimeshuka.
/// Agizo limebadilika hapo awali na linaweza kubadilika tena.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Njia za asili
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Inaunda `Vec<T>` mpya, tupu.
    ///
    /// vector haitatoa mpaka vitu vishinikizwe juu yake.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Inaunda `Vec<T>` mpya, tupu na uwezo uliowekwa.
    ///
    /// vector itaweza kushikilia vitu vya `capacity` bila kuhamisha tena.
    /// Ikiwa `capacity` ni 0, vector haitatenga.
    ///
    /// Ni muhimu kutambua kwamba ingawa vector iliyorejeshwa ina uwezo wa *maalum, vector itakuwa na urefu wa sifuri*.
    ///
    /// Kwa maelezo ya tofauti kati ya urefu na uwezo, angalia *[Uwezo na uwekaji upya]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector haina vitu, ingawa ina uwezo wa zaidi
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Haya yote hufanywa bila kuhamisha tena ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lakini hii inaweza kuifanya vector ibadilike tena
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Inaunda `Vec<T>` moja kwa moja kutoka kwa malighafi ya vector nyingine.
    ///
    /// # Safety
    ///
    /// Hii sio salama sana, kwa sababu ya idadi ya wavamizi ambao hawajakaguliwa:
    ///
    /// * `ptr` inahitaji kutengwa hapo awali kupitia [`String`]/`Vec<T>"(angalau, kuna uwezekano mkubwa kuwa sio sahihi ikiwa haikuwa hivyo).
    /// * `T` inahitaji kuwa na saizi sawa na mpangilio kama ile `ptr` ilitengwa nayo.
    ///   (`T` kuwa na mpangilio mkali haitoshi, mpangilio unahitaji kuwa sawa kutosheleza mahitaji ya [`dealloc`] kwamba kumbukumbu lazima itengwe na kusambazwa na mpangilio huo huo.)
    ///
    /// * `length` inahitaji kuwa chini ya au sawa na `capacity`.
    /// * `capacity` inahitaji kuwa uwezo ambao pointer ilitengwa nayo.
    ///
    /// Kukiuka hizi kunaweza kusababisha shida kama kuharibu miundo ya data ya ndani ya mtengaji.Kwa mfano ni **sio** salama kujenga `Vec<u8>` kutoka kwa pointer hadi safu ya C `char` yenye urefu wa `size_t`.
    /// Sio salama pia kujenga moja kutoka `Vec<u16>` na urefu wake, kwa sababu mtengaji anajali usawa, na aina hizi mbili zina mpangilio tofauti.
    /// Bafa ilitengwa na mpangilio wa 2 (kwa `u16`), lakini baada ya kuibadilisha kuwa `Vec<u8>` itasambazwa na mpangilio 1.
    ///
    /// Umiliki wa `ptr` unahamishiwa kwa `Vec<T>` ambayo inaweza kusambaza, kuhamisha tena au kubadilisha yaliyomo kwenye kumbukumbu iliyoelekezwa na pointer kwa mapenzi.
    /// Hakikisha kuwa hakuna kitu kingine kinachotumia pointer baada ya kuita kazi hii.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Sasisha hii wakati vec_into_raw_parts imetulia.
    ///     // Kuzuia mwangamizi wa `v` kwa hivyo tuko katika udhibiti kamili wa mgao.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Vuta vipande muhimu vya habari kuhusu `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Andika maandishi na 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rudisha kila kitu pamoja kwenye Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Inaunda `Vec<T, A>` mpya, tupu.
    ///
    /// vector haitatoa mpaka vitu vishinikizwe juu yake.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Inaunda `Vec<T, A>` mpya, tupu na uwezo maalum na mgawaji uliyopewa.
    ///
    /// vector itaweza kushikilia vitu vya `capacity` bila kuhamisha tena.
    /// Ikiwa `capacity` ni 0, vector haitatenga.
    ///
    /// Ni muhimu kutambua kwamba ingawa vector iliyorejeshwa ina uwezo wa *maalum, vector itakuwa na urefu wa sifuri*.
    ///
    /// Kwa maelezo ya tofauti kati ya urefu na uwezo, angalia *[Uwezo na uwekaji upya]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector haina vitu, ingawa ina uwezo wa zaidi
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Haya yote hufanywa bila kuhamisha tena ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lakini hii inaweza kuifanya vector ibadilike tena
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Inaunda `Vec<T, A>` moja kwa moja kutoka kwa malighafi ya vector nyingine.
    ///
    /// # Safety
    ///
    /// Hii sio salama sana, kwa sababu ya idadi ya wavamizi ambao hawajakaguliwa:
    ///
    /// * `ptr` inahitaji kutengwa hapo awali kupitia [`String`]/`Vec<T>"(angalau, kuna uwezekano mkubwa kuwa sio sahihi ikiwa haikuwa hivyo).
    /// * `T` inahitaji kuwa na saizi sawa na mpangilio kama ile `ptr` ilitengwa nayo.
    ///   (`T` kuwa na mpangilio mkali haitoshi, mpangilio unahitaji kuwa sawa kutosheleza mahitaji ya [`dealloc`] kwamba kumbukumbu lazima itengwe na kusambazwa na mpangilio huo huo.)
    ///
    /// * `length` inahitaji kuwa chini ya au sawa na `capacity`.
    /// * `capacity` inahitaji kuwa uwezo ambao pointer ilitengwa nayo.
    ///
    /// Kukiuka hizi kunaweza kusababisha shida kama kuharibu miundo ya data ya ndani ya mtengaji.Kwa mfano ni **sio** salama kujenga `Vec<u8>` kutoka kwa pointer hadi safu ya C `char` yenye urefu wa `size_t`.
    /// Sio salama pia kujenga moja kutoka `Vec<u16>` na urefu wake, kwa sababu mtengaji anajali usawa, na aina hizi mbili zina mpangilio tofauti.
    /// Bafa ilitengwa na mpangilio wa 2 (kwa `u16`), lakini baada ya kuibadilisha kuwa `Vec<u8>` itasambazwa na mpangilio 1.
    ///
    /// Umiliki wa `ptr` unahamishiwa kwa `Vec<T>` ambayo inaweza kusambaza, kuhamisha tena au kubadilisha yaliyomo kwenye kumbukumbu iliyoelekezwa na pointer kwa mapenzi.
    /// Hakikisha kuwa hakuna kitu kingine kinachotumia pointer baada ya kuita kazi hii.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Sasisha hii wakati vec_into_raw_parts imetulia.
    ///     // Kuzuia mwangamizi wa `v` kwa hivyo tuko katika udhibiti kamili wa mgao.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Vuta vipande muhimu vya habari kuhusu `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Andika maandishi na 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rudisha kila kitu pamoja kwenye Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Inayooza `Vec<T>` katika sehemu zake mbichi.
    ///
    /// Hurejesha pointer mbichi kwa data ya msingi, urefu wa vector (katika vipengee), na uwezo uliotengwa wa data (katika vitu).
    /// Hizi ni hoja sawa kwa mpangilio sawa na hoja kwa [`from_raw_parts`].
    ///
    /// Baada ya kuita kazi hii, mpigaji anahusika na kumbukumbu iliyosimamiwa hapo awali na `Vec`.
    /// Njia pekee ya kufanya hivyo ni kubadilisha kiboreshaji mbichi, urefu, na uwezo kuwa `Vec` na kazi ya [`from_raw_parts`], ikiruhusu mwangamizi kufanya usafi.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Sasa tunaweza kufanya mabadiliko kwa vifaa, kama vile kupeleka pointer mbichi kwa aina inayofaa.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Inayooza `Vec<T>` katika sehemu zake mbichi.
    ///
    /// Hurejesha pointer mbichi kwa data ya msingi, urefu wa vector (katika vipengee), uwezo uliotengwa wa data (katika vitu), na mtoaji.
    /// Hizi ni hoja sawa kwa mpangilio sawa na hoja kwa [`from_raw_parts_in`].
    ///
    /// Baada ya kuita kazi hii, mpigaji anahusika na kumbukumbu iliyosimamiwa hapo awali na `Vec`.
    /// Njia pekee ya kufanya hivyo ni kubadilisha kiboreshaji mbichi, urefu, na uwezo kuwa `Vec` na kazi ya [`from_raw_parts_in`], ikiruhusu mwangamizi kufanya usafi.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Sasa tunaweza kufanya mabadiliko kwa vifaa, kama vile kupeleka pointer mbichi kwa aina inayofaa.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Hurejesha idadi ya vitu ambavyo vector inaweza kushikilia bila kuhamisha tena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Inahifadhi uwezo wa angalau vitu `additional` zaidi kuingizwa katika `Vec<T>` iliyopewa.
    /// Mkusanyiko unaweza kuhifadhi nafasi zaidi ili kuepuka uhamishaji wa mara kwa mara.
    /// Baada ya kupiga simu `reserve`, uwezo utakuwa mkubwa kuliko au sawa na `self.len() + additional`.
    /// Haifanyi chochote ikiwa uwezo tayari unatosha.
    ///
    /// # Panics
    ///
    /// Panics ikiwa uwezo mpya unazidi kaiti `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Inahifadhi uwezo wa chini kabisa wa vipengee zaidi vya `additional` kuingizwa kwenye `Vec<T>` iliyopewa.
    ///
    /// Baada ya kupiga simu `reserve_exact`, uwezo utakuwa mkubwa kuliko au sawa na `self.len() + additional`.
    /// Haifanyi chochote ikiwa uwezo tayari unatosha.
    ///
    /// Kumbuka kuwa mtengaji anaweza kutoa mkusanyiko nafasi zaidi kuliko inavyoomba.
    /// Kwa hivyo, uwezo hauwezi kutegemewa kuwa ndogo sana.
    /// Pendelea `reserve` ikiwa uingizaji wa future unatarajiwa.
    ///
    /// # Panics
    ///
    /// Panics ikiwa uwezo mpya unafurika `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Inajaribu kuhifadhi uwezo wa angalau vitu `additional` zaidi kuingizwa kwenye `Vec<T>` iliyopewa.
    /// Mkusanyiko unaweza kuhifadhi nafasi zaidi ili kuepuka uhamishaji wa mara kwa mara.
    /// Baada ya kupiga simu `try_reserve`, uwezo utakuwa mkubwa kuliko au sawa na `self.len() + additional`.
    /// Haifanyi chochote ikiwa uwezo tayari unatosha.
    ///
    /// # Errors
    ///
    /// Ikiwa uwezo unafurika, au mgawaji anaripoti kutofaulu, basi kosa hurejeshwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Hifadhi kumbukumbu kabla, ikitoka ikiwa hatuwezi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sasa tunajua hii haiwezi OOM katikati ya kazi yetu ngumu
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ngumu sana
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Inajaribu kuweka kiwango cha chini cha vitu vya `additional` kuingizwa kwenye `Vec<T>` iliyopewa.
    /// Baada ya kupiga simu `try_reserve_exact`, uwezo utakuwa mkubwa kuliko au sawa na `self.len() + additional` ikiwa itarudisha `Ok(())`.
    ///
    /// Haifanyi chochote ikiwa uwezo tayari unatosha.
    ///
    /// Kumbuka kuwa mtengaji anaweza kutoa mkusanyiko nafasi zaidi kuliko inavyoomba.
    /// Kwa hivyo, uwezo hauwezi kutegemewa kuwa ndogo sana.
    /// Pendelea `reserve` ikiwa uingizaji wa future unatarajiwa.
    ///
    /// # Errors
    ///
    /// Ikiwa uwezo unafurika, au mgawaji anaripoti kutofaulu, basi kosa hurejeshwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Hifadhi kumbukumbu kabla, ikitoka ikiwa hatuwezi
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Sasa tunajua hii haiwezi OOM katikati ya kazi yetu ngumu
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ngumu sana
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Inapunguza uwezo wa vector iwezekanavyo.
    ///
    /// Itashuka chini kwa karibu iwezekanavyo kwa urefu lakini mtengaji bado anaweza kumjulisha vector kuwa kuna nafasi ya vitu kadhaa zaidi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Uwezo sio chini ya urefu, na hakuna cha kufanya wakati ni sawa, kwa hivyo tunaweza kuzuia kesi ya panic katika `RawVec::shrink_to_fit` kwa kuipigia tu na uwezo mkubwa.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Inapunguza uwezo wa vector na kifungo cha chini.
    ///
    /// Uwezo utabaki angalau kubwa kama urefu na thamani iliyotolewa.
    ///
    ///
    /// Ikiwa uwezo wa sasa ni chini ya kikomo cha chini, hii sio op-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Inabadilisha vector kuwa [`Box<[T]>`][owned slice].
    ///
    /// Kumbuka kuwa hii itashusha uwezo wowote wa ziada.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Uwezo wowote wa ziada huondolewa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Hufupisha vector, kuweka vitu vya kwanza vya `len` na kuacha zingine.
    ///
    /// Ikiwa `len` ni kubwa kuliko urefu wa sasa wa vector, hii haina athari.
    ///
    /// Njia ya [`drain`] inaweza kuiga `truncate`, lakini inasababisha vitu vya ziada kurudishwa badala ya kudondoshwa.
    ///
    ///
    /// Kumbuka kuwa njia hii haina athari kwa uwezo uliotengwa wa vector.
    ///
    /// # Examples
    ///
    /// Kupunguza kipengee tano vector kuwa vitu viwili:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Hakuna truncation inayotokea wakati `len` ni kubwa kuliko urefu wa sasa wa vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Kukata wakati `len == 0` ni sawa na kuita njia ya [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Hii ni salama kwa sababu:
        //
        // * kipande kilichopitishwa kwa `drop_in_place` ni halali;kesi ya `len > self.len` inaepuka kuunda kipande batili, na
        // * `len` ya vector imepungua kabla ya kupiga simu `drop_in_place`, kama kwamba hakuna thamani itashushwa mara mbili ikiwa `drop_in_place` ingefika panic mara moja (ikiwa ni panics mara mbili, programu hiyo inaachana).
        //
        //
        //
        unsafe {
            // Note: Ni kusudi kwamba hii ni `>` na sio `>=`.
            //       Kubadilisha kuwa `>=` kuna athari mbaya za utendaji katika hali zingine.
            //       Tazama #78884 kwa zaidi.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Inatoa kipande kilicho na vector nzima.
    ///
    /// Sawa na `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Inatoa kipande kinachoweza kubadilika cha vector nzima.
    ///
    /// Sawa na `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Hurejesha pointer mbichi kwa bafa ya vector.
    ///
    /// Mpigaji lazima ahakikishe kwamba vector inapita kiboreshaji cha kazi hii inarudi, au sivyo itaishia kuelekeza kwenye takataka.
    /// Kubadilisha vector kunaweza kusababisha bafa yake kuwekwa tena, ambayo pia inaweza kufanya viashiria vyovyote kuwa batili.
    ///
    /// Anayepiga simu lazima pia ahakikishe kumbukumbu ya pointer (non-transitively) inayoelekezwa haiandikiwi kamwe (isipokuwa ndani ya `UnsafeCell`) kwa kutumia kichocheo hiki au kitambulisho chochote kinachotokana nayo.
    /// Ikiwa unahitaji kubadilisha yaliyomo kwenye kipande, tumia [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Tunatia kivuli njia ya kipande ya jina moja ili kuepuka kupitia `deref`, ambayo inaunda rejeleo la kati.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Hurejesha kielekezi kisicho salama kinachoweza kubadilika kwa bafa ya vector.
    ///
    /// Mpigaji lazima ahakikishe kwamba vector inapita kiboreshaji cha kazi hii inarudi, au sivyo itaishia kuelekeza kwenye takataka.
    ///
    /// Kubadilisha vector kunaweza kusababisha bafa yake kuwekwa tena, ambayo pia inaweza kufanya viashiria vyovyote kuwa batili.
    ///
    /// # Examples
    ///
    /// ```
    /// // Tenga vector kubwa kwa kutosha kwa vitu 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Anzisha vitu kupitia pointer mbichi huandika, kisha weka urefu.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Tunatia kivuli njia ya kipande ya jina moja ili kuepuka kupitia `deref_mut`, ambayo inaunda rejeleo la kati.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Hurejesha rejeleo kwa msambazaji wa msingi.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Vikosi urefu wa vector hadi `new_len`.
    ///
    /// Huu ni operesheni ya kiwango cha chini ambayo haitumii vivamizi vya kawaida vya aina hiyo.
    /// Kawaida kubadilisha urefu wa vector hufanywa kwa kutumia moja ya shughuli salama badala yake, kama [`truncate`], [`resize`], [`extend`], au [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` lazima iwe chini au sawa na [`capacity()`].
    /// - Vipengele kwenye `old_len..new_len` lazima zianzishwe.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Njia hii inaweza kuwa muhimu kwa hali ambazo vector inafanya kazi kama bafa ya nambari nyingine, haswa juu ya FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Hii ni mifupa ndogo tu kwa mfano wa hati;
    /// # // usitumie hii kama mwanzo wa maktaba halisi.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Kwa hati za njia ya FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // USALAMA: Wakati `deflateGetDictionary` inarudi `Z_OK`, inashikilia kuwa:
    ///     // 1. `dict_length` vitu vilianzishwa.
    ///     // 2.
    ///     // `dict_length` <=uwezo (32_768) ambayo hufanya `set_len` salama kupiga simu.
    ///     unsafe {
    ///         // Piga simu ya FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... na usasishe urefu kwa kile kilichoanzishwa.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Wakati mfano ufuatao ni mzuri, kuna uvujaji wa kumbukumbu kwani vectors ya ndani haikuachiliwa kabla ya simu ya `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ni tupu kwa hivyo hakuna vitu vinahitaji kuanzishwa.
    /// // 2. `0 <= capacity` daima hushikilia chochote `capacity` ni.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Kwa kawaida, hapa, mtu atatumia [`clear`] badala yake kudondosha yaliyomo na kwa hivyo sio kuvuja kumbukumbu.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Huondoa kipengee kutoka kwa vector na kuirudisha.
    ///
    /// Kipengele kilichoondolewa hubadilishwa na kitu cha mwisho cha vector.
    ///
    /// Hii haihifadhi kuagiza, lakini ni O(1).
    ///
    /// # Panics
    ///
    /// Panics ikiwa `index` iko nje ya mipaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Tunabadilisha [index] ya kibinafsi na kipengee cha mwisho.
            // Kumbuka kuwa ikiwa ukaguzi wa mipaka hapo juu unafanikiwa lazima kuwe na kipengee cha mwisho (ambacho kinaweza kuwa yenyewe [index] yenyewe).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Inaweka kipengee katika nafasi ya `index` ndani ya vector, ikihamisha vitu vyote baada yake kwenda kulia.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // nafasi ya kipengee kipya
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // isiyo na makosa doa ya kuweka thamani mpya
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Hamisha kila kitu juu ili utengeneze nafasi.
                // (Kuiga kipengee cha `index`th katika sehemu mbili mfululizo.)
                ptr::copy(p, p.offset(1), len - index);
                // Iandike, ukiweka nakala ya kwanza ya kipengee cha `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Huondoa na kurudisha kipengee katika nafasi ya `index` ndani ya vector, ikihamisha vitu vyote baada yake kushoto.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `index` iko nje ya mipaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // mahali tunachukua kutoka.
                let ptr = self.as_mut_ptr().add(index);
                // nakili nje, bila salama kuwa na nakala ya dhamana kwenye stack na katika vector kwa wakati mmoja.
                //
                ret = ptr::read(ptr);

                // Shift kila kitu chini kujaza mahali hapo.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Inabakia tu vitu vilivyoainishwa na mtabiri.
    ///
    /// Kwa maneno mengine, ondoa vitu vyote `e` hivi kwamba `f(&e)` inarudi `false`.
    /// Njia hii inafanya kazi mahali pake, ikitembelea kila kitu haswa mara moja katika mpangilio wa asili, na inahifadhi mpangilio wa vitu vilivyohifadhiwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Kwa sababu vitu vinatembelewa haswa mara moja kwa mpangilio wa asili, hali ya nje inaweza kutumiwa kuamua ni vitu vipi vya kutunza.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Epuka kuacha mara mbili ikiwa mlinzi wa tone hajatekelezwa, kwani tunaweza kufanya mashimo wakati wa mchakato.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-kusindika len-> |^-karibu na kuangalia
        //                  | <-ilifutwa cnt-> |
        //      | <-asili_len-> |Imehifadhiwa: Vipengele ambavyo kiarifu kinarudi kweli.
        //
        // Shimo: Inasongeshwa au imeshuka kipengee cha kipengee
        // Haijakaguliwa: Vipengee halali ambavyo havijakaguliwa.
        //
        // Mlinzi huyu wa matone ataombwa wakati kiarifu au `drop` ya kipengee imeogopa.
        // Inabadilisha vitu ambavyo havijakaguliwa kufunika shimo na `set_len` kwa urefu sahihi.
        // Katika kesi wakati mtangulizi na `drop` haogopi kamwe, itaboreshwa.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // USALAMA: Kufuatilia vitu ambavyo havijakaguliwa lazima iwe halali kwani hatuzigusi kamwe.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // USALAMA: Baada ya kujaza mashimo, vitu vyote viko kwenye kumbukumbu inayojumuisha.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // USALAMA: Kipengee kisichochaguliwa lazima kiwe halali.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Mapema mapema ili kuepuka kushuka mara mbili ikiwa `drop_in_place` imeogopa.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // USALAMA: Hatugusi tena kitu hiki baada ya kudondoka.
                unsafe { ptr::drop_in_place(cur) };
                // Tayari tumeendeleza kaunta.
                continue;
            }
            if g.deleted_cnt > 0 {
                // USALAMA: `deleted_cnt`> 0, kwa hivyo nafasi ya shimo haipaswi kuingiliana na kipengee cha sasa.
                // Tunatumia nakala kwa hoja, na usiguse tena kitu hiki tena.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Bidhaa zote zinachakatwa.Hii inaweza kuboreshwa kwa `set_len` na LLVM.
        drop(g);
    }

    /// Huondoa yote isipokuwa ya kwanza ya vitu mfululizo katika vector ambazo hutatua kwa kitufe kimoja.
    ///
    ///
    /// Ikiwa vector imepangwa, hii inaondoa marudio yote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Huondoa yote isipokuwa ya kwanza ya vitu mfululizo katika vector inayoridhisha uhusiano wa usawa uliopewa.
    ///
    /// Kazi ya `same_bucket` imepitisha marejeleo ya vitu viwili kutoka kwa vector na lazima iamue ikiwa vitu vinalinganisha sawa.
    /// Vipengee hupitishwa kwa mpangilio tofauti kutoka kwa mpangilio wao kwenye kipande, kwa hivyo ikiwa `same_bucket(a, b)` inarudi `true`, `a` imeondolewa.
    ///
    ///
    /// Ikiwa vector imepangwa, hii inaondoa marudio yote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Inatumia kipengee nyuma ya mkusanyiko.
    ///
    /// # Panics
    ///
    /// Panics ikiwa uwezo mpya unazidi kaiti `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Hii itatoa panic au kutoa mimba ikiwa tungetenga> isize::MAX ka au ikiwa urefu wa urefu utafurika kwa aina za saizi.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Huondoa kipengee cha mwisho kutoka kwa vector na kuirudisha, au [`None`] ikiwa haina kitu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Inahamisha vipengee vyote vya `other` kuwa `Self`, na kuacha `other` tupu.
    ///
    /// # Panics
    ///
    /// Panics ikiwa idadi ya vitu kwenye vector inazidi `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Inatumia vitu kwa `Self` kutoka kwa bafa nyingine.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Inaunda iterator ya kuondoa maji ambayo huondoa anuwai maalum katika vector na kutoa vitu vilivyoondolewa.
    ///
    /// Wakati iterator **imeshuka**, vitu vyote katika masafa huondolewa kwenye vector, hata ikiwa iterator haikutumiwa kabisa.
    /// Ikiwa iterator **haijaangushwa**(na [`mem::forget`] kwa mfano), haijulikani ni vitu vingapi vimeondolewa.
    ///
    /// # Panics
    ///
    /// Panics ikiwa mahali pa kuanzia ni kubwa kuliko mahali pa mwisho au ikiwa ncha ya mwisho ni kubwa kuliko urefu wa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Masafa kamili husafisha vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Usalama wa kumbukumbu
        //
        // Wakati Drain imeundwa kwa mara ya kwanza, inapunguza urefu wa chanzo vector kuhakikisha kuwa hakuna vitu visivyoanzishwa au vilivyohamishwa vinavyoweza kupatikana kabisa ikiwa mwangamizi wa Drain hatawahi kukimbia.
        //
        //
        // Drain itaondoa maadili ya ptr::read.
        // Baada ya kumaliza, mkia uliobaki wa vec unakiliwa nyuma kufunika shimo, na urefu wa vector umerejeshwa kwa urefu mpya.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // weka urefu wa self.vec kuanza, kuwa salama iwapo Drain itatolewa
            self.set_len(start);
            // Tumia kukopa katika IterMut kuonyesha tabia ya kukopa ya iterator Drain nzima (kama &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Hufuta vector, kuondoa maadili yote.
    ///
    /// Kumbuka kuwa njia hii haina athari kwa uwezo uliotengwa wa vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Hurejesha idadi ya vitu kwenye vector, pia inajulikana kama 'length' yake.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Hurejesha `true` ikiwa vector haina vitu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Inagawanya mkusanyiko kuwa mbili kwenye faharisi iliyopewa.
    ///
    /// Hurejesha vector iliyotengwa mpya iliyo na vipengee katika fungu la `[at, len)`.
    /// Baada ya simu, vector asili itasalia ikiwa na vitu `[0, at)` na uwezo wake wa zamani haujabadilika.
    ///
    ///
    /// # Panics
    ///
    /// Panics ikiwa `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector mpya inaweza kuchukua bafa asili na kuzuia nakala
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Salama `set_len` na unakili vitu kwa `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Inarekebisha ukubwa wa `Vec` mahali ili `len` iwe sawa na `new_len`.
    ///
    /// Ikiwa `new_len` ni kubwa kuliko `len`, `Vec` inapanuliwa na tofauti, na kila nafasi ya ziada imejazwa na matokeo ya kupiga kufungwa `f`.
    ///
    /// Thamani za kurudi kutoka `f` zitaishia kwenye `Vec` kwa utaratibu ambao umetengenezwa.
    ///
    /// Ikiwa `new_len` ni chini ya `len`, `Vec` imepunguzwa tu.
    ///
    /// Njia hii hutumia kufungwa ili kuunda maadili mpya kwa kila kushinikiza.Ikiwa ungependa [`Clone`] thamani uliyopewa, tumia [`Vec::resize`].
    /// Ikiwa unataka kutumia [`Default`] trait kutengeneza maadili, unaweza kupitisha [`Default::default`] kama hoja ya pili.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Hutumia na kuvuja `Vec`, kurudisha rejeleo linaloweza kubadilika kwa yaliyomo, `&'a mut [T]`.
    /// Kumbuka kuwa aina `T` lazima iishi muda uliochaguliwa wa maisha `'a`.
    /// Ikiwa aina ina marejeleo ya tuli tu, au hakuna kabisa, basi hii inaweza kuchaguliwa kuwa `'static`.
    ///
    /// Kazi hii ni sawa na kazi ya [`leak`][Box::leak] kwenye [`Box`] isipokuwa kwamba hakuna njia ya kurejesha kumbukumbu iliyovuja.
    ///
    ///
    /// Kazi hii ni muhimu sana kwa data inayoishi kwa kipindi chote cha maisha ya programu.
    /// Kuacha rejeleo lililorejeshwa itasababisha kuvuja kwa kumbukumbu.
    ///
    /// # Examples
    ///
    /// Matumizi rahisi:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Hurejesha uwezo uliobaki wa vector kama kipande cha `MaybeUninit<T>`.
    ///
    /// Kipande kilichorudishwa kinaweza kutumiwa kujaza vector na data (kwa mfano
    /// kwa kusoma kutoka kwa faili) kabla ya kuweka alama ya data kama ilivyoanzishwa kwa kutumia njia ya [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Tenga vector kubwa kwa kutosha kwa vitu 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Jaza vitu 3 vya kwanza.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Tia alama vipengee 3 vya kwanza vya vector kuwa vimeanzishwa.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Njia hii haijatekelezwa kulingana na `split_at_spare_mut`, kuzuia ubadilishaji wa viashiria kwa bafa.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Hurejesha yaliyomo ya vector kama kipande cha `T`, pamoja na uwezo uliobaki wa vector kama kipande cha `MaybeUninit<T>`.
    ///
    /// Kipande cha uwezo wa vipuri kilichorudishwa kinaweza kutumiwa kujaza vector na data (kwa mfano kwa kusoma kutoka kwa faili) kabla ya kuweka alama ya data kama ilivyoanzishwa kwa kutumia njia ya [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Kumbuka kuwa hii ni API ya kiwango cha chini, ambayo inapaswa kutumiwa kwa uangalifu kwa madhumuni ya uboreshaji.
    /// Ikiwa unahitaji kuongeza data kwa `Vec` unaweza kutumia [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] au [`resize_with`], kulingana na mahitaji yako halisi.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Hifadhi nafasi ya ziada kubwa kwa vitu 10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Jaza vitu 4 vifuatavyo.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Tia alama vitu 4 vya vector kama vimeanzishwa.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len hupuuzwa na kwa hivyo haibadilishwa kamwe
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Usalama: kubadilisha kurejeshwa .2 (&mut usize) inachukuliwa kuwa sawa na kupiga `.set_len(_)`.
    ///
    /// Njia hii hutumiwa kuwa na ufikiaji wa kipekee kwa sehemu zote za vec mara moja katika `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` imehakikishiwa kuwa halali kwa vipengee vya `len`
        // - `spare_ptr` inaelekeza kipengee kimoja kupita bafa, kwa hivyo haiingiliani na `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Inarekebisha ukubwa wa `Vec` mahali ili `len` iwe sawa na `new_len`.
    ///
    /// Ikiwa `new_len` ni kubwa kuliko `len`, `Vec` inapanuliwa na tofauti, na kila slot ya ziada imejazwa na `value`.
    ///
    /// Ikiwa `new_len` ni chini ya `len`, `Vec` imepunguzwa tu.
    ///
    /// Njia hii inahitaji `T` kutekeleza [`Clone`], ili kuweza kulinganisha thamani iliyopitishwa.
    /// Ikiwa unahitaji kubadilika zaidi (au unataka kutegemea [`Default`] badala ya [`Clone`]), tumia [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones na inaongeza vitu vyote kwenye kipande kwa `Vec`.
    ///
    /// Iterates juu ya kipande `other`, clones kila kitu, na kisha inaongeza kwa `Vec` hii.
    /// `other` vector imepitishwa kwa utaratibu.
    ///
    /// Kumbuka kuwa kazi hii ni sawa na [`extend`] isipokuwa ni maalum kufanya kazi na vipande badala yake.
    ///
    /// Ikiwa na wakati Rust itapata utaalam kazi hii inaweza kupunguzwa (lakini bado inapatikana).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Inakili vitu kutoka kwa `src` hadi mwisho wa vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` inahakikishia kuwa anuwai iliyopewa ni halali kwa kuorodhesha kibinafsi
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Nambari hii inaleta jumla ya `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Panua vector kwa maadili ya `n`, ukitumia jenereta iliyopewa.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Tumia SetLenOnDrop kufanya kazi karibu na mdudu ambapo mkusanyaji anaweza asigundue duka kupitia `ptr` kupitia self.set_len() sio alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Andika vitu vyote isipokuwa ya mwisho
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Ongeza urefu katika kila hatua ikiwa next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Tunaweza kuandika kipengee cha mwisho moja kwa moja bila kujumuisha bila lazima
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len iliyowekwa na mlinzi wa wigo
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Huondoa vitu mfululizo vya vector kulingana na utekelezaji wa [`PartialEq`] trait.
    ///
    ///
    /// Ikiwa vector imepangwa, hii inaondoa marudio yote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Njia na kazi za ndani
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` inahitaji kuwa index sahihi
    /// - `self.capacity() - self.len()` lazima iwe `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len imeongezeka tu baada ya kuanzisha vitu
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - guaratees za wapigaji simu kuwa src ni faharisi sahihi
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Kipengele kilianzishwa tu na `MaybeUninit::write`, kwa hivyo ni sawa kuongeza lensi
            // - len imeongezeka baada ya kila kitu kuzuia uvujaji (tazama toleo #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - wapiga simu kwamba `src` ni faharisi sahihi
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Vidokezo vyote viwili vimeundwa kutoka kwa marejeleo ya kipekee ya kipande (`&mut [_]`) kwa hivyo ni halali na hayapishana.
            //
            // - Vipengele ni: Nakili kwa hivyo ni sawa kunakili, bila kufanya chochote na maadili ya asili
            // - `count` ni sawa na len ya `source`, kwa hivyo chanzo ni halali kwa kusoma `count`
            // - `.reserve(count)` inahakikishia kuwa `spare.len() >= count` kwa hivyo vipuri ni halali kwa `count` inaandika
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Vipengele vilianzishwa tu na `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Utekelezaji wa kawaida wa trait kwa Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): na cfg(test) njia asili ya `[T]::to_vec`, ambayo inahitajika kwa ufafanuzi wa njia hii, haipatikani.
    // Badala yake tumia kazi ya `slice::to_vec` ambayo inapatikana tu na cfg(test) NB angalia moduli ya slice::hack katika slice.rs kwa habari zaidi
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // kuacha chochote ambacho hakitaandikwa tena
        self.truncate(other.len());

        // self.len <= other.len kwa sababu ya truncate hapo juu, kwa hivyo vipande hapa viko katika mipaka kila wakati.
        //
        let (init, tail) = other.split_at(self.len());

        // tumia tena maadili yaliyomo allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Inaunda iterator ya kuteketeza, ambayo ni, ambayo hutoa kila thamani kutoka kwa vector (kutoka mwanzo hadi mwisho).
    /// vector haiwezi kutumika baada ya kupiga simu hii.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // ina aina ya Kamba, sio &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // njia ya jani ambayo utekelezaji anuwai ya SpecFrom/SpecExtend huwakabidhi wakati hawana uboreshaji zaidi wa kutumia
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Hii ndio kesi kwa iterator ya jumla.
        //
        // Kazi hii inapaswa kuwa sawa na maadili ya:
        //
        //      kwa kipengee katika iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB haiwezi kufurika kwani tungelazimika kutenga nafasi ya anwani
                self.set_len(len + 1);
            }
        }
    }

    /// Inaunda kitambulisho cha kuiga ambacho kinachukua nafasi ya upeo maalum katika vector na iterator iliyopewa `replace_with` na kutoa vitu vilivyoondolewa.
    ///
    /// `replace_with` hauitaji kuwa na urefu sawa na `range`.
    ///
    /// `range` huondolewa hata ikiwa iterator haitumiwi hadi mwisho.
    ///
    /// Haijabainishwa ni ngapi vitu vimeondolewa kutoka kwa vector ikiwa thamani ya `Splice` imevuja.
    ///
    /// Iterator ya kuingiza `replace_with` hutumiwa tu wakati thamani ya `Splice` imeshuka.
    ///
    /// Hii ni sawa ikiwa:
    ///
    /// * Mkia (vitu katika vector baada ya `range`) ni tupu,
    /// * au `replace_with` hutoa vitu vichache au sawa kuliko urefu wa `masafa`
    /// * au kifungo cha chini cha `size_hint()` yake ni sawa.
    ///
    /// Vinginevyo, vector ya muda imetengwa na mkia huhamishwa mara mbili.
    ///
    /// # Panics
    ///
    /// Panics ikiwa mahali pa kuanzia ni kubwa kuliko mahali pa mwisho au ikiwa ncha ya mwisho ni kubwa kuliko urefu wa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Inaunda iterator ambayo hutumia kufungwa ili kubaini ikiwa kipengee kinapaswa kuondolewa.
    ///
    /// Ikiwa kufungwa kunarudi kweli, basi kipengee huondolewa na kutolewa.
    /// Ikiwa kufungwa kunarudi kwa uwongo, kipengee kitabaki kwenye vector na hakitatolewa na iterator.
    ///
    /// Kutumia njia hii ni sawa na nambari ifuatayo:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // nambari yako hapa
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Lakini `drain_filter` ni rahisi kutumia.
    /// `drain_filter` pia ni bora zaidi, kwa sababu inaweza kurudisha nyuma vitu vya safu kwa wingi.
    ///
    /// Kumbuka kuwa `drain_filter` pia hukuruhusu kubadilisha kila kitu kwenye kufungwa kwa kichujio, bila kujali ikiwa unachagua kuiweka au kuiondoa.
    ///
    ///
    /// # Examples
    ///
    /// Kugawanya safu ndani ya jioni na hali mbaya, kutumia tena mgao wa asili:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Jilinde dhidi yetu kuvuja (kukuza uvujaji)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Panua utekelezaji ambao unakili vitu nje ya marejeleo kabla ya kuzisukuma kwenye Vec.
///
/// Utekelezaji huu ni maalum kwa watengenezaji wa vipande, ambapo hutumia [`copy_from_slice`] kuongezea kipande nzima mara moja.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Inatumia kulinganisha vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Inatekeleza kuagiza kwa vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // tumia tone kwa [T] tumia kipande kibichi kutaja vitu vya vector kama aina dhaifu muhimu;
            //
            // inaweza kuepuka maswali ya uhalali katika hali fulani
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec inashughulikia uhamishaji
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Inaunda `Vec<T>` tupu.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: mtihani unavuta katika libstd, ambayo husababisha makosa hapa
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: mtihani unavuta katika libstd, ambayo husababisha makosa hapa
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Inapata yaliyomo yote ya `Vec<T>` kama safu, ikiwa saizi yake inafanana kabisa na safu iliyoombwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ikiwa urefu hailingani, pembejeo inarudi kwa `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ikiwa uko sawa kwa kupata kiambishi awali cha `Vec<T>`, unaweza kupiga [`.truncate(N)`](Vec::truncate) kwanza.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // USALAMA: `.set_len(0)` daima ni sauti.
        unsafe { vec.set_len(0) };

        // USALAMA: Kiashiria cha `Vec` kimewekwa sawa kila wakati, na
        // mpangilio wa mahitaji ya safu ni sawa na vitu.
        // Tuliangalia mapema kuwa tuna vitu vya kutosha.
        // Vitu havitashuka mara mbili kwani `set_len` inaiambia `Vec` isiangushe pia.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}