//! Prelude iliyotengwa
//!
//! Madhumuni ya moduli hii ni kupunguza uagizaji wa vitu vinavyotumiwa sana vya `alloc` crate kwa kuongeza uingizaji wa glob juu ya moduli:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;