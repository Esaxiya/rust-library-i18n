#![feature(no_core)]
#![no_core]

// Tazama rustc-std-nafasi ya kazi-msingi kwa nini crate hii inahitajika.

// Badili jina crate ili kuepuka kupingana na moduli ya mgao katika liballoc.
extern crate alloc as foo;

pub use foo::*;