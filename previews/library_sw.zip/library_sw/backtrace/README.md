# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Maktaba ya kupata alama za nyuma wakati wa kukimbia kwa Rust.
Maktaba hii inakusudia kuongeza msaada wa maktaba ya kawaida kwa kutoa kiolesura cha programu cha kufanya kazi nayo, lakini pia inasaidia kwa urahisi kuchapisha backtrace ya sasa kama panics ya libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ili kunasa tu kurudi nyuma na kuahirisha kushughulika nayo hadi wakati mwingine, unaweza kutumia aina ya kiwango cha juu cha `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ikiwa, hata hivyo, ungependa ufikiaji mbichi zaidi kwa utendaji halisi wa utaftaji, unaweza kutumia kazi za `trace` na `resolve` moja kwa moja.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Suluhisha kielekezi hiki cha maelekezo kwa jina la ishara
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // endelea kwenda kwenye fremu inayofuata
    });
}
```

# License

Mradi huu umepewa leseni chini ya yoyote ya

 * Leseni ya Apache, Toleo 2.0, ([LICENSE-APACHE](LICENSE-APACHE) au http://www.apache.org/licenses/LICENSE-2.0)
 * Leseni ya MIT ([LICENSE-MIT](LICENSE-MIT) au http://opensource.org/licenses/MIT)

kwa chaguo lako.

### Contribution

Isipokuwa ukisema waziwazi vinginevyo, mchango wowote uliowasilishwa kwa makusudi kuingizwa kwenye backtrace-rs na wewe, kama ilivyoainishwa katika leseni ya Apache-2.0, itakuwa na leseni mbili kama hapo juu, bila sheria na masharti yoyote ya ziada.







