use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr inachukua simu ambayo itapokea dl_phdr_info pointer kwa kila DSO ambayo imeunganishwa kwenye mchakato.
    // dl_iterate_phdr pia inahakikisha kuwa kiunganishi chenye nguvu kimefungwa kutoka mwanzo hadi mwisho wa iteration.
    // Ikiwa upigaji simu utarudisha thamani isiyo ya sifuri iteration imekomeshwa mapema.
    // 'data' itapitishwa kama hoja ya tatu kwa kurejeshwa kwa kila simu.
    // 'size' inatoa saizi ya dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Tunahitaji kuchambua kitambulisho cha ujenzi na data ya msingi ya programu ambayo inamaanisha kuwa tunahitaji vitu kadhaa kutoka kwa maelezo ya ELF pia.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Sasa tunalazimika kuiga, kidogo, muundo wa aina ya dl_phdr_info inayotumiwa na kiunganishi cha nguvu cha fuchsia.
// Chromium pia ina mpaka huu wa ABI pamoja na pedi ya ajali.
// Hatimaye tungependa kuhamisha kesi hizi kutumia utaftaji wa elf lakini tungehitaji kutoa hiyo katika SDK na hiyo bado haijafanyika.
//
// Kwa hivyo sisi (na wao) tumekwama kutumia njia hii ambayo inaunganisha sana na fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Hatuna njia ya kujua kuangalia ikiwa e_phoff na e_phnum ni halali.
    // libc inapaswa kuhakikisha hii kwetu hata hivyo ni salama kuunda kipande hapa.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr inawakilisha kichwa cha programu cha EL-64-bit katika endianness ya usanifu wa lengo.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr inawakilisha kichwa cha programu halali cha ELF na yaliyomo.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Hatuna njia ya kuangalia ikiwa p_addr au p_memsz ni halali.
    // Libc ya Fuchsia inachambua maelezo kwanza hata hivyo kwa sababu ya kuwa hapa vichwa hivi lazima iwe halali.
    //
    // KumbukaIter haiitaji data ya msingi kuwa halali lakini inahitaji mipaka kuwa halali.
    // Tunaamini kwamba libc imehakikisha kuwa hii ndio kesi kwetu hapa.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Aina ya noti ya vitambulisho vya ujenzi.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr inawakilisha kichwa cha kumbuka cha ELF katika endianness ya lengo.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Kumbuka inawakilisha noti ya ELF (kichwa + yaliyomo).
// Jina limeachwa kama kipande cha u8 kwa sababu sio kila wakati hukomeshwa na rust inafanya iwe rahisi kutosha kuangalia kama baiti zinafanana.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// KumbukaIter hukuruhusu upunguze salama juu ya sehemu ya maandishi.
// Inakoma mara tu kosa linapotokea au hakuna vidokezo zaidi.
// Ukipima juu ya data batili itafanya kazi kana kwamba hakuna noti zilizopatikana.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ni mabadiliko ya kazi ambayo pointer na saizi iliyopewa inaashiria anuwai ya ka ambazo zinaweza kusomwa zote.
    // Yaliyomo ya ka hizi zinaweza kuwa chochote lakini anuwai lazima iwe halali ili hii iwe salama.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' kwa 'to'-byte alignment kudhani 'to' ni nguvu ya 2.
// Hii inafuata muundo wa kawaida katika msimbo wa kuchanganua C/C ++ ELF ambapo (x + to, 1)&-to inatumiwa.
// Rust hairuhusu wewe kupuuza usize kwa hivyo ninatumia
// 2-inayosaidia ubadilishaji ili kurudia hiyo.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 hutumia baiti za nambari kutoka kwa kipande (ikiwa iko) na pia inahakikisha kwamba kipande cha mwisho kimepangiliwa sawa.
// Ikiwa idadi ya ka zilizoombwa ni kubwa sana au kipande hakiwezi kubadilishwa baadaye kwa sababu ya baiti za kutosha zilizopo, Hakuna inayorudishwa na kipande hakijabadilishwa.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Kazi hii haina vivamizi halisi mpigaji lazima azingatie isipokuwa labda kwamba 'bytes' inapaswa kulinganishwa na utendaji (na juu ya usahihi wa usanifu).
// Thamani katika sehemu za Elf_Nhdr zinaweza kuwa za kipuuzi lakini kazi hii haihakikishi kitu kama hicho.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Hii ni salama maadamu kuna nafasi ya kutosha na tumethibitisha tu kuwa katika taarifa ikiwa hapo juu kwa hivyo hii haipaswi kuwa salama.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Kumbuka kuwa sice_of: :<Elf_Nhdr>() daima ni 4-byte iliyokaa.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Angalia ikiwa tumefika mwisho.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Tunasambaza nhdr lakini tunazingatia kwa uangalifu muundo unaosababishwa.
        // Hatuamini namesz au descsz na hatufanyi maamuzi yasiyofaa kulingana na aina.
        //
        // Kwa hivyo hata tukipata takataka kamili bado tunapaswa kuwa salama.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Inaonyesha kuwa sehemu inaweza kutekelezwa.
const PERM_X: u32 = 0b00000001;
/// Inaonyesha kuwa sehemu inaandikiwa.
const PERM_W: u32 = 0b00000010;
/// Inaonyesha kuwa sehemu inasomeka.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Inawakilisha sehemu ya ELF wakati wa kukimbia.
struct Segment {
    /// Hutoa anwani ya wakati wa kukimbia ya yaliyomo katika sehemu hii.
    addr: usize,
    /// Hutoa saizi ya kumbukumbu ya yaliyomo katika sehemu hii.
    size: usize,
    /// Inatoa moduli anwani halisi ya sehemu hii na faili ya ELF.
    mod_rel_addr: usize,
    /// Hutoa ruhusa zinazopatikana kwenye faili ya ELF.
    /// Ruhusa hizi sio lazima ruhusa ziwepo wakati wa kukimbia hata hivyo.
    flags: Perm,
}

/// Lets moja iterate juu ya Sehemu kutoka DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Inawakilisha ELF DSO (Kitu cha Dynamic Shared).
/// Aina hii inarejelea data iliyohifadhiwa kwenye DSO halisi badala ya kutengeneza nakala yake mwenyewe.
struct Dso<'a> {
    /// Kiunganishi chenye nguvu hutupa jina kila wakati, hata ikiwa jina ni tupu.
    /// Katika kesi ya kutekelezeka kuu jina hili litakuwa tupu.
    /// Katika kesi ya kitu kilichoshirikiwa itakuwa soname (tazama DT_SONAME).
    name: &'a str,
    /// Kwenye Fuchsia karibu kila binaries zina vitambulisho vya ujenzi lakini hii sio mahitaji muhimu.
    /// Hakuna njia ya kulinganisha habari ya DSO na faili halisi ya ELF baadaye ikiwa hakuna ujenzi_wa hivyo tunahitaji kwamba kila DSO iwe nayo hapa.
    ///
    /// DSO bila ujenzi_juu hupuuzwa.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Inarudisha iterator juu ya Sehemu katika DSO hii.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Makosa haya husimba maswala yanayotokea wakati wa kuchambua habari kuhusu kila DSO.
///
enum Error {
    /// JinaError inamaanisha kuwa hitilafu ilitokea wakati wa kubadilisha kamba ya mtindo wa C kuwa kamba ya rust.
    ///
    NameError(core::str::Utf8Error),
    /// Kosa la Ujenzi linamaanisha kuwa hatukupata kitambulisho cha ujenzi.
    /// Hii inaweza kuwa kwa sababu DSO haikuwa na kitambulisho cha ujenzi au kwa sababu sehemu iliyo na kitambulisho cha ujenzi ilikuwa na hitilafu.
    ///
    BuildIDError,
}

/// Inaita 'dso' au 'error' kwa kila DSO iliyounganishwa kwenye mchakato na kiunganishi chenye nguvu.
///
///
/// # Arguments
///
/// * `visitor` - Mchapishaji wa Dso ambayo itakuwa na njia moja ya kula inayoitwa foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr inahakikisha kuwa info.name itaelekeza kwa eneo halali.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Kazi hii inachapisha alama ya ishara ya Fuchsia kwa habari zote zilizomo kwenye DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}