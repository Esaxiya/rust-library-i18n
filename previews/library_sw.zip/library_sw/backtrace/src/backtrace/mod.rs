use core::ffi::c_void;
use core::fmt;

/// Inakagua mpigo wa simu wa sasa, ikipitisha fremu zote zinazotumika katika kufungwa kunakotolewa ili kukokotoa ufuatiliaji wa mpororo.
///
/// Kazi hii ni kazi ya maktaba hii katika kuhesabu athari za programu.Kufungwa kwa `cb` kunapewa hali ya `Frame` ambayo inawakilisha habari kuhusu fremu hiyo ya simu kwenye stack.
/// Kufungwa kunapewa muafaka kwa mtindo wa juu-chini (hivi karibuni huitwa kazi kwanza).
///
/// Thamani ya kurudi kwa kufungwa ni dalili ya kuwa njia ya nyuma inapaswa kuendelea.Thamani ya kurudi ya `false` itamaliza utaftaji wa nyuma na kurudi mara moja.
///
/// Mara tu `Frame` itakapopatikana utataka kupiga `backtrace::resolve` kubadilisha `ip` (pointer ya kufundishia) au anwani ya alama kuwa `Symbol` kupitia ambayo jina na/au jina la faili/nambari ya laini inaweza kujifunza.
///
///
/// Kumbuka kuwa hii ni kazi ya kiwango cha chini na ikiwa ungependa, kwa mfano, kunasa njia ya nyuma kukaguliwa baadaye, basi aina ya `Backtrace` inaweza kuwa sahihi zaidi.
///
/// # Vipengele vinavyohitajika
///
/// Kazi hii inahitaji kipengee cha `std` cha `backtrace` crate kuwezeshwa, na huduma ya `std` imewezeshwa na chaguo-msingi.
///
/// # Panics
///
/// Kazi hii inajitahidi kamwe panic, lakini ikiwa `cb` ilitoa panics basi majukwaa mengine yatalazimisha panic mara mbili kutoa mchakato huo.
/// Baadhi ya majukwaa hutumia maktaba ya C ambayo kwa ndani hutumia vizuizi ambavyo haziwezi kufunuliwa, kwa hivyo kuhofia kutoka kwa `cb` kunaweza kusababisha mchakato kutoa mimba.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // endelea nyuma
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sawa na `trace`, salama tu kwani haijafananishwa.
///
/// Kazi hii haina madalali ya usawazishaji lakini inapatikana wakati kipengee cha `std` cha crate hiki hakijajumuishwa.
/// Tazama kazi ya `trace` kwa nyaraka zaidi na mifano.
///
/// # Panics
///
/// Angalia habari juu ya `trace` kwa mapango juu ya kuhofia `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait inayowakilisha fremu moja ya backtrace, iliyotolewa kwa kazi ya `trace` ya crate hii.
///
/// Kufungwa kwa kazi ya kufuatilia kutapewa muafaka, na fremu inatumwa kwani utekelezaji wa msingi haujulikani kila wakati hadi wakati wa kukimbia.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Hurejesha kielekezi cha maagizo cha sasa cha fremu hii.
    ///
    /// Hii kawaida ni maagizo yafuatayo kutekeleza katika sura, lakini sio utekelezaji wote huorodhesha hii kwa usahihi wa 100% (lakini kwa ujumla iko karibu sana).
    ///
    ///
    /// Inashauriwa kupitisha thamani hii kwa `backtrace::resolve` kuibadilisha kuwa jina la ishara.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Hurejesha kielekezi cha sasa cha mpangilio wa fremu hii.
    ///
    /// Katika kesi ambayo backend haiwezi kupata pointer ya stack kwa fremu hii, pointer null inarejeshwa.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Hurejesha anwani ya ishara ya kuanzia ya fremu ya kazi hii.
    ///
    /// Hii itajaribu kurudisha nyuma kiboreshaji cha maagizo kilichorudishwa na `ip` mwanzoni mwa kazi, ikirudisha thamani hiyo.
    ///
    /// Katika visa vingine, hata hivyo, kurudi nyuma kutarudisha `ip` kutoka kwa kazi hii.
    ///
    /// Thamani iliyorudishwa wakati mwingine inaweza kutumika ikiwa `backtrace::resolve` ilishindwa kwenye `ip` iliyotolewa hapo juu.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Hurejesha anwani ya msingi ya moduli ambayo fremu ni yake.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Hii inahitaji kuja kwanza, kuhakikisha kuwa Miri anachukua kipaumbele juu ya jukwaa la mwenyeji
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // tu kutumika katika dbghelp mfano
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}