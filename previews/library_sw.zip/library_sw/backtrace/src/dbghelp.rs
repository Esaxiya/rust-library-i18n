//! Moduli ya kusaidia katika kusimamia vifungo vya dbghelp kwenye Windows
//!
//! Backtraces kwenye Windows (angalau kwa MSVC) hutumiwa kwa nguvu kupitia `dbghelp.dll` na kazi anuwai ambayo ina.
//! Kazi hizi kwa sasa zimepakiwa *kwa nguvu* badala ya kuunganisha kwa `dbghelp.dll` kitakwimu.
//! Hii sasa inafanywa na maktaba ya kawaida (na kwa nadharia inahitajika hapo), lakini ni juhudi ya kusaidia kupunguza utegemezi wa tuli wa maktaba kwani visukuku nyuma kawaida ni chaguo nzuri.
//!
//! Hiyo inasemwa, `dbghelp.dll` karibu kila wakati inafanikiwa kupakia kwenye Windows.
//!
//! Kumbuka ingawa kwa kuwa kwa kuwa tunapakia msaada huu wote kwa nguvu hatuwezi kutumia ufafanuzi mbichi katika `winapi`, lakini badala yake tunahitaji kufafanua aina za kiashiria cha kazi sisi wenyewe na tutumie hiyo.
//! Hatutaki kabisa kuwa katika biashara ya kuiga winapi, kwa hivyo tuna Cargo kipengele `verify-winapi` ambacho kinasisitiza kuwa vifungo vyote vinafanana na vilivyo katika winapi na huduma hii imewezeshwa kwenye CI.
//!
//! Mwishowe, utaona hapa kwamba dll ya `dbghelp.dll` haijawahi kupakuliwa, na hiyo kwa sasa ni ya kukusudia.
//! Mawazo ni kwamba tunaweza kuiweka akiba ulimwenguni na kuitumia kati ya simu kwenda kwa API, tukiepuka loads/unloads ya gharama kubwa.
//! Ikiwa hii ni shida kwa wachunguzi wa uvujaji au kitu kama hicho tunaweza kuvuka daraja tukifika hapo.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Fanya kazi karibu na `SymGetOptions` na `SymSetOptions` usiwepo kwenye winapi yenyewe.
// Vinginevyo hii inatumika tu wakati tunakagua aina mbili dhidi ya winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Haijafafanuliwa katika winapi bado
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Hii inafafanuliwa katika winapi, lakini sio sahihi (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Haijafafanuliwa katika winapi bado
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Macro hii hutumiwa kufafanua muundo wa `Dbghelp` ambao ndani una vidokezo vyote vya kazi ambavyo tunaweza kupakia.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL iliyobeba kwa `dbghelp.dll`
            dll: HMODULE,

            // Kila kiashiria cha kazi kwa kila kazi tunayoweza kutumia
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Hapo awali hatujapakia DLL
            dll: 0 as *mut _,
            // Anitiall kazi zote zimewekwa sifuri kusema zinahitaji kupakiwa kwa nguvu.
            //
            $($name: 0,)*
        };

        // Aina ya urahisi kwa kila aina ya kazi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Majaribio ya kufungua `dbghelp.dll`.
            /// Inarudisha mafanikio ikiwa inafanya kazi au kosa ikiwa `LoadLibraryW` inashindwa.
            ///
            /// Panics ikiwa maktaba tayari imeshapakiwa.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Kazi kwa kila njia tungependa kutumia.
            // Ikiitwa itaweza kusoma kiashiria cha kazi iliyohifadhiwa au kuipakia na kurudisha thamani iliyopakiwa.
            // Mizigo imesisitizwa kufanikiwa.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Wakala wa urahisi wa kutumia kufuli kusafisha ili kurejelea kazi za dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Anzisha msaada wote muhimu kupata huduma za `dbghelp` API kutoka kwa crate hii.
///
///
/// Kumbuka kuwa kazi hii ni **salama**, ndani ina usawazishaji wake.
/// Pia kumbuka kuwa ni salama kuita kazi hii mara kadhaa kurudia.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Jambo la kwanza tunalohitaji kufanya ni kusawazisha kazi hii.Hii inaweza kuitwa wakati mmoja kutoka kwa nyuzi zingine au kurudia ndani ya uzi mmoja.
        // Kumbuka kuwa ni ngumu zaidi kuliko hiyo kwa sababu kwa sababu tunachotumia hapa, `dbghelp`,*pia* inahitaji kusawazishwa na wapiga simu wengine wote kwa `dbghelp` katika mchakato huu.
        //
        // Kwa kawaida hakuna simu nyingi kwa `dbghelp` katika mchakato huo huo na tunaweza kudhani salama kuwa sisi tu ndio tunaifikia.
        // Kuna, hata hivyo, mtumiaji mwingine wa kimsingi tunapaswa kuwa na wasiwasi juu ya ambayo ni sisi wenyewe, lakini kwenye maktaba ya kawaida.
        // Maktaba ya kawaida ya Rust inategemea crate hii kwa msaada wa backtrace, na crate hii pia ipo kwenye crates.io.
        // Hii inamaanisha kuwa ikiwa maktaba ya kawaida inachapisha backtrace ya panic inaweza kushindana na crate hii kutoka crates.io, na kusababisha machafuko.
        //
        // Ili kusaidia kutatua shida hii ya maingiliano tunatumia hila maalum ya Windows hapa (kwa kweli, ni kizuizi maalum cha Windows juu ya maingiliano).
        // Tunaunda *kikao-cha ndani* kilichoitwa mutex kulinda simu hii.
        // Kusudi hapa ni kwamba maktaba ya kawaida na hii crate sio lazima igawane API za kiwango cha Rust ili kusawazisha hapa lakini badala yake zinaweza kufanya kazi nyuma ya pazia ili kuhakikisha zinawiana.
        //
        // Kwa njia hiyo wakati kazi hii inaitwa kupitia maktaba ya kawaida au kupitia crates.io tunaweza kuwa na hakika kuwa bubu sawa inapatikana.
        //
        // Kwa hivyo hiyo yote ni kusema kwamba jambo la kwanza tunalofanya hapa ni sisi kuunda `HANDLE` ambayo ni mutex inayoitwa Windows.
        // Tunasawazisha kidogo na nyuzi zingine zinazoshiriki kazi hii haswa na kuhakikisha kuwa kushughulikia moja tu imeundwa kwa mfano wa kazi hii.
        // Kumbuka kuwa kipini hakijafungwa kamwe baada ya kuhifadhiwa ulimwenguni.
        //
        // Baada ya kweli kwenda kwenye kufuli tunapata tu, na kipini chetu cha `Init` tutakachotoa kitakuwa na jukumu la kuiacha mwishowe.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Sasa kwa kuwa sote tumesawazishwa salama, wacha tuanze kusindika kila kitu.
        // Kwanza kabisa tunahitaji kuhakikisha kuwa `dbghelp.dll` imepakiwa katika mchakato huu.
        // Tunafanya hivi kwa nguvu ili kuepuka utegemezi tuli.
        // Hii kihistoria imefanywa kufanya kazi karibu na maswala ya kushikamana ya kushangaza na inakusudiwa kufanya binaries iweze kubebeka zaidi kwani hii ni huduma ya utatuzi tu.
        //
        //
        // Mara tu tutakapofungua `dbghelp.dll` tunahitaji kuita kazi kadhaa za uanzishaji ndani yake, na hiyo imefafanuliwa zaidi hapa chini.
        // Tunafanya hii mara moja tu, hata hivyo, kwa hivyo tuna boolean ya ulimwengu inayoonyesha ikiwa tumemaliza bado au la.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Hakikisha kwamba bendera ya `SYMOPT_DEFERRED_LOADS` imewekwa, kwa sababu kulingana na hati za MSVC juu ya hii: "This is the fastest, most efficient way to use the symbol handler.", kwa hivyo wacha tufanye hivyo!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Anzisha alama na MSVC.Kumbuka kuwa hii inaweza kushindwa, lakini tunapuuza.
        // Hakuna tani ya sanaa ya awali kwa hii kwa kila se, lakini LLVM ndani inaonekana kupuuza thamani ya kurudi hapa na moja ya maktaba ya usafi katika LLVM inachapisha onyo la kutisha ikiwa hii itashindwa lakini kimsingi inapuuza mwishowe.
        //
        //
        // Kesi moja hii inakuja sana kwa Rust ni kwamba maktaba ya kawaida na hii crate kwenye crates.io zote zinataka kushindana kwa `SymInitializeW`.
        // Maktaba ya kawaida kihistoria ilitaka kuanzisha kisha kusafisha mara nyingi, lakini sasa kwa kuwa inatumia crate inamaanisha kuwa mtu atafika kwa uanzishaji kwanza na mwingine atachukua uanzishaji huo.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}