#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Muundo wa vinjari vya nyuma.
///
/// Aina hii inaweza kutumika kuchapisha backtrace bila kujali backtrace yenyewe inatoka wapi.
/// Ikiwa una aina ya `Backtrace` basi utekelezaji wake wa `Debug` tayari unatumia fomati hii ya uchapishaji.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Mitindo ya uchapishaji ambayo tunaweza kuchapisha
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Inachapisha backtrace ya terser ambayo ina habari muhimu tu
    Short,
    /// Printa backtrace ambayo ina habari zote zinazowezekana
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Unda `BacktraceFmt` mpya ambayo itaandika pato kwa `fmt` iliyotolewa.
    ///
    /// Hoja ya `format` itadhibiti mtindo ambao mkondo wa nyuma umechapishwa, na hoja ya `print_path` itatumika kuchapisha matukio ya `BytesOrWideString` ya majina ya faili.
    /// Aina hii yenyewe haifanyi uchapishaji wowote wa majina ya faili, lakini upigaji simu huu unahitajika kufanya hivyo.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Huandika utangulizi wa wimbo wa nyuma unaotaka kuchapishwa.
    ///
    /// Hii inahitajika kwenye majukwaa mengine ya nyuso za nyuma kuonyeshwa kikamilifu baadaye, na vinginevyo hii inapaswa kuwa tu njia ya kwanza unayoita baada ya kuunda `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Inaongeza fremu kwa pato la nyuma.
    ///
    /// Ahadi hii inarudisha mfano wa RAII wa `BacktraceFrameFmt` ambayo inaweza kutumika kuchapisha sura, na juu ya uharibifu itaongeza kaunta ya fremu.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Inakamilisha pato la nyuma.
    ///
    /// Hii kwa sasa sio-op lakini imeongezwa kwa utangamano wa future na fomati za kurudi nyuma.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Hivi sasa hakuna-op-pamoja na hook hii kuruhusu nyongeza za future.
        Ok(())
    }
}

/// Muundo wa fremu moja tu ya backtrace.
///
/// Aina hii imeundwa na kazi ya `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Chapa `BacktraceFrame` na fomati ya fremu hii.
    ///
    /// Hii itachapisha mara kwa mara visa vyote vya `BacktraceSymbol` ndani ya `BacktraceFrame`.
    ///
    /// # Vipengele vinavyohitajika
    ///
    /// Kazi hii inahitaji kipengee cha `std` cha `backtrace` crate kuwezeshwa, na huduma ya `std` imewezeshwa na chaguo-msingi.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Huandika `BacktraceSymbol` ndani ya `BacktraceFrame`.
    ///
    /// # Vipengele vinavyohitajika
    ///
    /// Kazi hii inahitaji kipengee cha `std` cha `backtrace` crate kuwezeshwa, na huduma ya `std` imewezeshwa na chaguo-msingi.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: hii sio nzuri kwamba hatuishi kuchapisha chochote
            // na majina yasiyo ya utf8.
            // Kwa bahati nzuri karibu kila kitu ni utf8 kwa hivyo hii haipaswi kuwa mbaya sana.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Inachapisha mbichi iliyoangaziwa `Frame` na `Symbol`, kawaida kutoka ndani ya vibichi mbichi vya crate hii.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Inaongeza fremu mbichi kwa pato la nyuma.
    ///
    /// Njia hii, tofauti na ile ya awali, inachukua hoja mbichi ikiwa zinatoka kwa maeneo tofauti.
    /// Kumbuka kuwa hii inaweza kuitwa mara nyingi kwa fremu moja.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Inaongeza fremu mbichi kwa pato la nyuma, pamoja na habari ya safu.
    ///
    /// Njia hii, kama ile ya awali, inachukua hoja mbichi ikiwa zinatokana na maeneo tofauti.
    /// Kumbuka kuwa hii inaweza kuitwa mara nyingi kwa fremu moja.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia haiwezi kuashiria ndani ya mchakato kwa hivyo ina muundo maalum ambao unaweza kutumika kuashiria baadaye.
        // Chapisha hiyo badala ya kuchapisha anwani katika muundo wetu hapa.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Hakuna haja ya kuchapisha fremu za "null", inamaanisha tu kwamba mfumo wa kurudi nyuma ulikuwa na hamu kubwa ya kutafuta nyuma sana.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Ili kupunguza saizi ya TCB katika nyumba ya Sgx, hatutaki kutekeleza utendaji wa utatuzi wa ishara.
        // Badala yake, tunaweza kuchapisha nakala ya anwani hapa, ambayo inaweza kupangwa baadaye ili kurekebisha kazi.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Chapisha faharisi ya fremu na vile vile kielekezi cha maelekezo ya hiari ya fremu.
        // Ikiwa tuko zaidi ya ishara ya kwanza ya sura hii ingawa tunachapisha tu nafasi nyeupe.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ifuatayo andika jina la ishara, ukitumia fomati mbadala kwa habari zaidi ikiwa tuko nyuma kabisa.
        // Hapa pia tunashughulikia alama ambazo hazina jina,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Na mwisho, chapisha nambari ya filename/line ikiwa inapatikana.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line zimechapishwa kwenye mistari chini ya jina la ishara, kwa hivyo chapa nafasi nyeupe ya kuchagua aina ya kujipanga sawa.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Shiriki kwa kupigiwa simu kwa ndani ili kuchapisha jina la faili na kisha uchapishe nambari ya laini.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Ongeza nambari ya safu wima, ikiwa inapatikana.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Tunajali tu ishara ya kwanza ya sura
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}