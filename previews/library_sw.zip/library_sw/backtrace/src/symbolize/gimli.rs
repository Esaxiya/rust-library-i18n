//! Msaada wa ishara kwa kutumia `gimli` crate kwenye crates.io
//!
//! Huu ndio utekelezaji kamili wa ishara kwa Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // maisha ya tuli ni uwongo kudanganya ukosefu wa msaada kwa vibarua vya kujipendekeza.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Badilisha kwa 'maisha ya tuli kwa sababu alama zinapaswa kukopa `map` na `stash` tu na tunazihifadhi hapo chini.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Kwa kupakia maktaba za asili kwenye Windows, angalia majadiliano kwenye rust-lang/rust#71060 kwa mikakati anuwai hapa.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Maktaba za MinGW kwa sasa haziunga mkono ASLR (rust-lang/rust#16514), lakini DLL bado zinaweza kuhamishwa kuzunguka katika nafasi ya anwani.
            // Inaonekana kwamba anwani katika maelezo ya utatuzi zote ziko kama maktaba hii ilipakiwa kwenye "image base" yake, ambayo ni uwanja katika vichwa vya faili vya COFF.
            // Kwa kuwa hii ndio debuginfo inaonekana kuorodhesha tunachanganua meza ya alama na anwani za duka kama maktaba ilipakiwa kwenye "image base" pia.
            //
            // Maktaba haiwezi kupakiwa kwenye "image base", hata hivyo.
            // (labda kitu kingine kinaweza kupakiwa hapo?) Hapa ndipo uwanja wa `bias` unapoanza kucheza, na tunahitaji kujua thamani ya `bias` hapa.Kwa bahati mbaya ingawa haijulikani jinsi ya kupata hii kutoka kwa moduli iliyobeba.
            // Tunacho, hata hivyo, ni anwani halisi ya mzigo (`modBaseAddr`).
            //
            // Kama sehemu ya nakala ya nakala kwa sasa tunapiga faili, soma habari ya kichwa cha faili, kisha uachie mmap.Hii ni ubadhirifu kwa sababu labda tutafungua tena mmap baadaye, lakini hii inapaswa kufanya kazi vizuri kwa sasa.
            //
            // Mara tu tunapokuwa na `image_base` (eneo la mzigo unaotakiwa) na `base_addr` (eneo halisi la mzigo) tunaweza kujaza `bias` (tofauti kati ya halisi na inayotakiwa) na kisha anwani iliyoonyeshwa ya kila sehemu ni `image_base` kwani hiyo ndiyo faili inasema.
            //
            //
            // Kwa sasa inaonekana kuwa tofauti na ELF/MachO tunaweza kufanya na sehemu moja kwa kila maktaba, tukitumia `modBaseSize` kama saizi yote.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS hutumia fomati ya faili ya Mach-O na hutumia API maalum za DYLD kupakia orodha ya maktaba za asili ambazo ni sehemu ya programu.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Leta jina la maktaba hii ambayo inalingana na njia ya wapi kuipakia pia.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Pakia kichwa cha picha cha maktaba hii na ukabidhi kwa `object` kuchanganua amri zote za mzigo ili tuweze kujua sehemu zote zinazohusika hapa.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterate juu ya sehemu na uandikishe mikoa inayojulikana kwa sehemu ambazo tunapata.
            // Kwa kuongeza rekodi rekodi za sehemu za maandishi za kusindika baadaye, angalia maoni hapa chini.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Tambua "slide" kwa maktaba hii ambayo inaishia kuwa upendeleo ambao tunatumia kujua ni wapi vitu vya kumbukumbu vimepakiwa.
            // Hii ni hesabu ya kushangaza ingawa ni matokeo ya kujaribu vitu kadhaa porini na kuona ni nini kinachoshikilia.
            //
            // Wazo la jumla ni kwamba `bias` pamoja na sehemu ya `stated_virtual_memory_address` itakuwa mahali ambapo sehemu ya anwani inakaa katika anwani halisi.
            // Jambo lingine tunalotegemea ingawa ni kwamba anwani halisi ikiondoa `bias` ndio faharisi ya kuangalia juu kwenye jedwali la ishara na debuginfo.
            //
            // Inageuka, hata hivyo, kwamba kwa maktaba iliyobeba mfumo mahesabu haya sio sahihi.Kwa watekelezaji wa asili, hata hivyo, inaonekana kuwa sahihi.
            // Kuinua mantiki kutoka kwa chanzo cha LLDB ina vifaa maalum kwa kifungu cha kwanza cha `__TEXT` kilichopakiwa kutoka kwa faili iliyowekwa 0 na saizi ya nonzero.
            // Kwa sababu yoyote wakati hii iko inavyoonekana inamaanisha kuwa jedwali la alama linahusiana na slaidi ya vmaddr tu ya maktaba.
            // Ikiwa haipo * basi meza ya ishara inahusiana na slaidi ya vmaddr pamoja na anwani iliyotajwa ya sehemu hiyo.
            //
            // Ili kushughulikia hali hii ikiwa hatujapata sehemu ya maandishi kwenye faili iliyokadiriwa sifuri basi tunaongeza upendeleo kwa anwani ya sehemu ya maandishi ya kwanza na kupunguza anwani zote zilizoonyeshwa na kiasi hicho pia.
            //
            // Kwa njia hiyo meza ya ishara daima inaonekana ikilinganishwa na kiwango cha upendeleo wa maktaba.
            // Hii inaonekana kuwa na matokeo sahihi ya kuashiria kupitia jedwali la ishara.
            //
            // Kweli sina hakika kabisa ikiwa hii ni sawa au ikiwa kuna kitu kingine ambacho kinapaswa kuonyesha jinsi ya kufanya hivyo.
            // Kwa sasa ingawa hii inaonekana kufanya kazi vizuri ya kutosha (?) na tunapaswa kila wakati kuweza kurekebisha hii kwa wakati ikiwa ni lazima.
            //
            // Kwa habari zaidi angalia #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Nyingine Unix (kwa mfano
        // Linux) majukwaa hutumia ELF kama muundo wa faili ya kitu na kawaida hutumia API inayoitwa `dl_iterate_phdr` kupakia maktaba za asili.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` inapaswa kuwa viashiria halali.
        // `vec` inapaswa kuwa kiboreshaji halali kwa `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 haiungi mkono asili habari ya utatuzi, lakini mfumo wa kujenga utaweka maelezo ya utatuzi kwenye njia `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Kila kitu kingine kinapaswa kutumia ELF, lakini haijui jinsi ya kupakia maktaba za asili.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Maktaba zote za pamoja zinazojulikana ambazo zimepakiwa.
    libraries: Vec<Library>,

    /// Ramani ya ramani ambapo tunahifadhi habari ndogo ndogo.
    ///
    /// Orodha hii ina uwezo wa kudumu kwa wakati wote wa maisha ambayo haiongezeki kamwe.
    /// Kipengee cha `usize` cha kila jozi ni faharisi ya `libraries` hapo juu ambapo `usize::max_value()` inawakilisha inayoweza kutekelezwa sasa.
    ///
    /// `Mapping` inalingana na habari iliyochanganuliwa.
    ///
    /// Kumbuka kuwa hii kimsingi ni kashe ya LRU na tutabadilisha vitu kuzunguka hapa tunapowakilisha anwani.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Sehemu za maktaba hii zimepakiwa kwenye kumbukumbu, na zinapakiwa wapi.
    segments: Vec<LibrarySegment>,
    /// "bias" ya maktaba hii, kawaida ambapo imewekwa kwenye kumbukumbu.
    /// Thamani hii imeongezwa kwenye anwani ya kila sehemu ili kupata anwani halisi ya kumbukumbu ambayo sehemu hiyo imeingizwa.
    /// Kwa kuongezea upendeleo huu umetolewa kutoka kwa anwani halisi za kumbukumbu ili kuorodhesha katika debuginfo na jedwali la ishara.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Anwani iliyotajwa ya sehemu hii katika faili ya kitu.
    /// Hapa sio mahali ambapo sehemu hiyo imepakiwa, lakini badala anwani hii pamoja na `bias` ya maktaba ni mahali pa kuipata.
    ///
    stated_virtual_memory_address: usize,
    /// Ukubwa wa sehemu hiyo katika kumbukumbu.
    len: usize,
}

// salama kwa sababu hii inahitajika kusawazishwa nje
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // salama kwa sababu hii inahitajika kusawazishwa nje
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Cache ndogo sana, rahisi sana ya LRU ya utaftaji wa maelezo ya utatuzi.
        //
        // Kiwango cha hit kinapaswa kuwa cha juu sana, kwani stack ya kawaida haivuki kati ya maktaba nyingi zinazoshirikiwa.
        //
        // Miundo ya `addr2line::Context` ni ghali sana kuunda.
        // Gharama yake inatarajiwa kupunguzwa pesa na maswali yanayofuata ya `locate`, ambayo hutengeneza miundo iliyojengwa wakati wa kujenga "addr2line: : Context" kupata kasi nzuri.
        //
        // Ikiwa hatungekuwa na kashe hii, upunguzaji wa pesa haungewahi kutokea, na ishara ya nyuma ingekuwa ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Kwanza, jaribu ikiwa `lib` hii ina sehemu yoyote iliyo na `addr` (kushughulikia kuhamishwa).Ikiwa hundi hii itapita basi tunaweza kuendelea hapa chini na kutafsiri anwani.
                //
                // Kumbuka kuwa tunatumia `wrapping_add` hapa ili kuzuia ukaguzi wa kufurika.Imeonekana porini kwamba hesabu ya upendeleo ya SVMA + imejaa.
                // Inaonekana ni isiyo ya kawaida ambayo ingetokea lakini hakuna kiasi kikubwa tunaweza kufanya juu yake isipokuwa labda puuza tu sehemu hizo kwani labda zinaelekeza angani.
                //
                // Hii awali ilikuja katika rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Sasa kwa kuwa tunajua `lib` ina `addr`, tunaweza kukabiliana na upendeleo kupata anwani ya kumbukumbu ya virutal.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: baada ya masharti haya kukamilika bila kurudi mapema
        // kutoka kwa kosa, kuingia kwa kashe kwa njia hii iko kwenye faharisi ya 0

        if let Some(idx) = idx {
            // Wakati ramani iko tayari kwenye kashe, isonge mbele.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Wakati ramani haipo kwenye kashe, tengeneza ramani mpya, ingiza mbele ya kashe, na uondoe kiingilio cha zamani zaidi ikiwa ni lazima.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // usivujishe maisha ya `'static`, hakikisha imepunguzwa kwa sisi wenyewe
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Panua maisha ya `sym` hadi `'static` kwa kuwa kwa bahati mbaya tunatakiwa hapa, lakini inaendelea kutolewa kama rejeleo kwa hivyo hakuna kumbukumbu yake inapaswa kuendelea zaidi ya fremu hii hata hivyo.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Mwishowe, pata ramani iliyohifadhiwa au tengeneza ramani mpya ya faili hii, na tathmini maelezo ya DWARF kupata file/line/name kwa anwani hii.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Tuliweza kupata habari ya fremu ya ishara hii, na fremu ya "addr2line" ndani ina maelezo yote ya uchungu.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Haikuweza kupata habari ya utatuzi, lakini tuliipata kwenye jedwali la ishara ya elf inayoweza kutekelezwa.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}