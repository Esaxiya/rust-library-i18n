use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Suluhisha anwani kwa ishara, ukipitisha ishara kwa kufungwa maalum.
///
/// Kazi hii itatafuta anwani uliyopewa katika maeneo kama jedwali la alama ya ndani, jedwali la ishara ya nguvu, au maelezo ya utatuzi wa DWARF (kulingana na utekelezaji uliowekwa) kupata alama za kutoa.
///
///
/// Kufungwa hakuwezi kuitwa ikiwa azimio lisingeweza kutekelezwa, na pia linaweza kuitwa zaidi ya mara moja ikiwa kuna kazi zilizopangwa.
///
/// Alama zinazotolewa huwakilisha utekelezaji kwa `addr` iliyoainishwa, ikirudisha jozi za file/line kwa anwani hiyo (ikiwa inapatikana).
///
/// Kumbuka kuwa ikiwa una `Frame` basi inashauriwa kutumia kazi ya `resolve_frame` badala ya hii.
///
/// # Vipengele vinavyohitajika
///
/// Kazi hii inahitaji kipengee cha `std` cha `backtrace` crate kuwezeshwa, na huduma ya `std` imewezeshwa na chaguo-msingi.
///
/// # Panics
///
/// Kazi hii inajitahidi kamwe panic, lakini ikiwa `cb` ilitoa panics basi majukwaa mengine yatalazimisha panic mara mbili kutoa mchakato huo.
/// Baadhi ya majukwaa hutumia maktaba ya C ambayo kwa ndani hutumia vizuizi ambavyo haziwezi kufunuliwa, kwa hivyo kuhofia kutoka kwa `cb` kunaweza kusababisha mchakato kutoa mimba.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // angalia tu fremu ya juu
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Suluhisha fremu ya kukamata hapo awali kwa ishara, ukipitisha ishara kwa kufungwa maalum.
///
/// Functin hii hufanya kazi sawa na `resolve` isipokuwa kwamba inachukua `Frame` kama hoja badala ya anwani.
/// Hii inaweza kuruhusu utekelezaji wa jukwaa la kutafuta nyuma ili kutoa habari sahihi zaidi ya ishara au habari kuhusu fremu zilizo kwenye mstari kwa mfano.
///
/// Inashauriwa kutumia hii ikiwa unaweza.
///
/// # Vipengele vinavyohitajika
///
/// Kazi hii inahitaji kipengee cha `std` cha `backtrace` crate kuwezeshwa, na huduma ya `std` imewezeshwa na chaguo-msingi.
///
/// # Panics
///
/// Kazi hii inajitahidi kamwe panic, lakini ikiwa `cb` ilitoa panics basi majukwaa mengine yatalazimisha panic mara mbili kutoa mchakato huo.
/// Baadhi ya majukwaa hutumia maktaba ya C ambayo kwa ndani hutumia vizuizi ambavyo haziwezi kufunuliwa, kwa hivyo kuhofia kutoka kwa `cb` kunaweza kusababisha mchakato kutoa mimba.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // angalia tu fremu ya juu
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Thamani za IP kutoka kwa fremu za ghalama kawaida ni (always?) maagizo *baada ya* simu hiyo ndio athari halisi ya stack.
// Kuashiria hii kwa sababu husababisha nambari ya filename/line kuwa moja mbele na labda kuwa batili ikiwa iko karibu na mwisho wa kazi.
//
// Hii inaonekana kimsingi huwa kesi kwenye majukwaa yote, kwa hivyo kila wakati tunatoa moja kutoka kwa ip iliyosuluhishwa kuitatua kwa maagizo ya simu ya hapo awali badala ya maagizo kurudishwa.
//
//
// Kwa kweli hatungefanya hivi.
// Kwa kweli tungehitaji wapigaji wa API za `resolve` hapa kufanya kwa mikono -1 na akaunti kwamba wanataka habari ya eneo kwa maagizo ya * yaliyopita, sio ya sasa.
// Kwa kweli tungedhihirisha pia `Frame` ikiwa kweli sisi ni anwani ya maagizo yanayofuata au ya sasa.
//
// Kwa sasa ingawa hii ni wasiwasi mzuri wa niche kwa hivyo sisi tu ndani kila wakati tunatoa moja.
// Wateja wanapaswa kuendelea kufanya kazi na kupata matokeo mazuri, kwa hivyo tunapaswa kuwa wa kutosha.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sawa na `resolve`, sio salama tu kwani haijafananishwa.
///
/// Kazi hii haina madalali ya usawazishaji lakini inapatikana wakati kipengee cha `std` cha crate hiki hakijajumuishwa.
/// Tazama kazi ya `resolve` kwa nyaraka zaidi na mifano.
///
/// # Panics
///
/// Angalia habari juu ya `resolve` kwa mapango juu ya kuhofia `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sawa na `resolve_frame`, salama tu kwani haijafananishwa.
///
/// Kazi hii haina madalali ya usawazishaji lakini inapatikana wakati kipengee cha `std` cha crate hiki hakijajumuishwa.
/// Tazama kazi ya `resolve_frame` kwa nyaraka zaidi na mifano.
///
/// # Panics
///
/// Angalia habari juu ya `resolve_frame` kwa mapango juu ya kuhofia `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait inayowakilisha azimio la ishara kwenye faili.
///
/// trait hii imetolewa kama kitu cha trait kwa kufungwa kwa kazi ya `backtrace::resolve`, na imetumwa kabisa kwani haijulikani ni utekelezaji gani ulio nyuma yake.
///
///
/// Alama inaweza kutoa habari ya muktadha juu ya kazi, kwa mfano jina, jina la faili, nambari ya laini, anwani sahihi, n.k.
/// Sio habari zote zinazopatikana kila wakati kwa ishara, hata hivyo, kwa hivyo njia zote zinarudisha `Option`.
///
///
pub struct Symbol {
    // TODO: kifungo hiki cha maisha kinahitaji kuendelea mwishowe hadi `Symbol`,
    // lakini kwa sasa ni mabadiliko ya kuvunja.
    // Kwa sasa hii ni salama kwani `Symbol` hutolewa tu kwa kumbukumbu na haiwezi kuumbwa.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Hurejesha jina la kazi hii.
    ///
    /// Muundo uliorejeshwa unaweza kutumiwa kuuliza mali anuwai juu ya jina la ishara:
    ///
    ///
    /// * Utekelezaji wa `Display` utachapisha alama iliyotengwa.
    /// * Thamani ghafi ya `str` ya ishara inaweza kupatikana (ikiwa ni halali utf-8).
    /// * Baiti mbichi za jina la ishara zinaweza kupatikana.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Hurejesha anwani ya kuanzia ya kazi hii.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Hurejesha jina la faili mbichi kama kipande.
    /// Hii ni muhimu sana kwa mazingira ya `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Hurejesha nambari ya safu wima ambapo ishara hii inatekelezwa kwa sasa.
    ///
    /// Ni gimli tu sasa inayotoa dhamana hapa na hata hivyo tu ikiwa `filename` inarudi `Some`, na kwa hivyo basi iko chini ya mapango kama hayo.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Hurejesha nambari ya laini ambapo ishara hii inatekelezwa kwa sasa.
    ///
    /// Thamani hii ya kurudi kawaida ni `Some` ikiwa `filename` inarudi `Some`, na kwa hivyo iko chini ya tahadhari sawa.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Hurejesha jina la faili ambapo kazi hii ilifafanuliwa.
    ///
    /// Hii sasa inapatikana tu wakati libbacktrace au gimli inatumiwa (kwa mfano
    /// unix majukwaa mengine) na wakati binary imejumuishwa na debuginfo.
    /// Ikiwa hakuna moja ya masharti haya yamekidhiwa basi hii itarudi `None`.
    ///
    /// # Vipengele vinavyohitajika
    ///
    /// Kazi hii inahitaji kipengee cha `std` cha `backtrace` crate kuwezeshwa, na huduma ya `std` imewezeshwa na chaguo-msingi.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Labda ishara ya C++ iliyochanganuliwa, ikiwa kuchanganua ishara iliyoangaziwa kama Rust imeshindwa.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Hakikisha kuweka ukubwa huu wa sifuri, ili huduma ya `cpp_demangle` isiwe na gharama yoyote ikiwa imelemazwa.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Kifuniko karibu na jina la ishara ili kutoa vifaa vya ergonomic kwa jina lililotengwa, ka ghafi, kamba mbichi, n.k.
///
// Ruhusu msimbo uliokufa wakati kipengee cha `cpp_demangle` hakijawezeshwa.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Inaunda jina jipya la ishara kutoka kwa ka msingi mbichi.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Hurejesha jina la alama ghafi ya (mangled) kama `str` ikiwa ishara ni halali utf-8.
    ///
    /// Tumia utekelezaji wa `Display` ikiwa unataka toleo lililotengwa.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Hurejesha jina la ishara mbichi kama orodha ya ka
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Hii inaweza kuchapisha ikiwa ishara iliyotengwa sio halali, kwa hivyo shughulikia kosa hapa kwa uzuri kwa kutokueneza nje.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Jaribio la kutaka kurudisha kumbukumbu iliyohifadhiwa kuhifadhiana anwani.
///
/// Njia hii itajaribu kutoa miundo yoyote ya data ya ulimwengu ambayo imewekwa akiba ulimwenguni au kwenye uzi ambao kawaida huwakilisha habari ya DWARF au sawa.
///
///
/// # Caveats
///
/// Wakati kazi hii inapatikana kila wakati haifanyi chochote kwenye utekelezaji mwingi.
/// Maktaba kama dbghelp au libbacktrace haitoi vifaa vya kusambaza hali na kudhibiti kumbukumbu iliyotengwa.
/// Kwa sasa kipengee cha `gimli-symbolize` cha crate hii ndio sifa pekee ambapo kazi hii ina athari yoyote.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}