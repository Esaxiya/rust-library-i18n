// kutumika tu kwenye Linux hivi sasa, kwa hivyo ruhusu nambari iliyokufa mahali pengine
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Mgawanyiko wa uwanja rahisi kwa bafa za baiti.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Hutenga bafa ya saizi iliyoainishwa na kurudisha rejeleo linaloweza kubadilika kwake.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // USALAMA: hii ndiyo kazi pekee ambayo inaunda mabadiliko
        // kumbukumbu ya `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // USALAMA: hatuondoi vitu kutoka `self.buffers`, kwa hivyo rejeleo
        // kwa data iliyo ndani ya bafa yoyote itaishi kwa muda mrefu kama `self` inavyofanya.
        &mut buffers[i]
    }
}