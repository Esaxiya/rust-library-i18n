use core::marker::PhantomData;
use core::ptr::NonNull;

/// Misali wani yanki ne na wasu bayanai na musamman, lokacin da ka san cewa sake jujjuyawar da dukkanin zuriyarsa (ma'ana, duk abubuwan nuni da nassoshin da aka samo daga gare ta) ba za a sake amfani da su a wani lokaci ba, bayan haka kuna so ku sake amfani da asali na asali na asali kuma .
///
///
/// Mai bin bashin yawanci yana ɗaukar wannan ɗimbin bashin a gare ku, amma wasu ikon sarrafawa waɗanda ke aiwatar da wannan tsarukan suna da rikitarwa ga mai tarawa ya bi.
/// `DormantMutRef` yana ba ka damar duba aron kanka, yayin da yake bayyana yanayin ɗimbinsa, da kuma killace lambar nuna alama da ake buƙata don yin hakan ba tare da halayyar da ba a bayyana ta ba.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Kama wani musamman ara, kuma nan da nan reborrow shi.
    /// Ga mai harhaɗawa, rayuwar sabon bayanin daidai yake da rayuwar tarihin asali, amma ku promise don amfani dashi don ɗan gajeren lokaci.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // KYAUTA: muna riƙe aro a cikin 'a ta hanyar `_marker`, kuma muna fallasa
        // kawai wannan ishara ce, don haka ta musamman ce.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Komawa ga lamuni na musamman wanda aka fara kamawa.
    ///
    /// # Safety
    ///
    /// Dole ne maɓallin ya sake ƙarewa, watau, bayanin da `new` ya dawo da shi da duk alamun da nassoshin da aka samo daga gare ta, ba za a sake amfani da su ba.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KYAUTA: yanayin tsaronmu yana nuna cewa wannan bayanin ya sake zama na musamman.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;