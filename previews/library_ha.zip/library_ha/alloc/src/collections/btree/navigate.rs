use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Na ɗan lokaci fitar da wani, madaidaici kwatankwacin wannan kewayon.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Nemo keɓaɓɓun gefunan ganyayyaki waɗanda ke iyakance iyakar kewayon itace.
    /// Ya dawo ko dai na madaidaitan abin rikewa a cikin bishiya ɗaya ko kuma wasu zaɓuɓɓukan wofi.
    ///
    /// # Safety
    ///
    /// Sai dai idan `BorrowType` shine `Immut`, kar a yi amfani da abubuwan da aka maimaita don ziyartar KV iri ɗaya sau biyu.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Daidai `(root1.first_leaf_edge(), root2.last_leaf_edge())` amma ya fi dacewa.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ya samo gefunan ganye masu keɓance takamaiman kewayon itace.
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar ta yi odar da maɓalli, kamar itacen da ke cikin `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // KYAUTA: nau'in bashin mu bashi canzawa.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Ya samo gefunan ganye masu iyaka kowane bishiya.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Ya raba tunani na musamman a cikin gefunan ganye masu keɓance kewayon da aka kayyade.
    /// Sakamakon shine nassoshi marasa mahimmanci waɗanda ke ba da maye gurbin (some), wanda dole ne a yi amfani da shi a hankali.
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar ta yi odar da maɓalli, kamar itacen da ke cikin `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Karku yi amfani da abubuwan da aka maimaita don ziyartar KV iri ɗaya sau biyu.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Ya raba tunani na musamman a cikin gefuna biyu na ganye wanda ke iyakance iyakar bishiyar.
    /// Sakamakon ba nassoshi ne na musamman da ke ba da izinin maye gurbi (na ƙimomin kawai), don haka dole ne a yi amfani da shi da kulawa.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Muna kwafin tushen NodeRef a nan-ba za mu taba ziyartar KV iri biyu ba, kuma ba za mu taba kawo karshen ambaton darajarmu ba.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Ya raba tunani na musamman a cikin gefuna biyu na ganye wanda ke iyakance iyakar bishiyar.
    /// Sakamakon ba nassoshi ne na musamman da ke ba da izinin maye gurbi da yawa, don haka dole ne a yi amfani da shi tare da matuƙar kulawa.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Muna kwafin tushen NodeRef a nan-ba za mu taba samun damar hakan ta hanyar da za ta mamaye bayanan nassoshin da aka samo daga asalin.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Bayar da ganyen edge, ya dawo da [`Result::Ok`] tare da rike zuwa KV makwabta a gefen dama, wanda yake ko dai a cikin kumburin ganye ɗaya ko kuma a kumburin kakannin.
    ///
    /// Idan ganye edge shine na ƙarshe a cikin bishiyar, ya dawo da [`Result::Err`] tare da tushen kumburi.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Bayar da ganyen edge, ya dawo da [`Result::Ok`] tare da rike zuwa KV makwabta a gefen hagu, wanda yake ko dai a cikin kumburin ganye iri ɗaya ko kuma a kumburin kakannin.
    ///
    /// Idan ganye edge shine na farko a cikin bishiyar, zai dawo da [`Result::Err`] tare da tushen kumburi.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Idan aka ba shi rikodin edge na ciki, ya dawo da [`Result::Ok`] tare da rike zuwa KV makwabta a gefen dama, wanda yake ko dai a cikin kumburin ciki ɗaya ko a cikin kumburin kakannin.
    ///
    /// Idan edge na ciki shine na ƙarshe a cikin itacen, ya dawo [`Result::Err`] tare da tushen kumburi.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// An ba da ganyen edge a cikin itace mai mutuwa, ya dawo da ganye na gaba edge a gefen dama, da maɓallin ƙimar maɓalli a tsakanin, waɗanda suke ko dai a cikin kumburin ganye ɗaya, a cikin kakannin kakanni, ko babu.
    ///
    ///
    /// Wannan hanyar kuma tana rarraba kowane node(s) wanda ya kai ƙarshen.
    /// Wannan yana nuna cewa idan babu sauran maɓallin ƙimar maɓalli guda ɗaya, dukkanin ragowar bishiyar za a raba su ne kuma babu abin da ya rage don dawowa.
    ///
    /// # Safety
    /// edge da aka bayar ba lallai ne abokin aikinsa `deallocating_next_back` ya dawo dashi ba.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Bayar da ganyen edge a cikin itace mai mutuwa, ya dawo da ganye na gaba edge a gefen hagu, da maɓallin maɓallin-maɓalli a tsakanin, waɗanda suke ko dai a cikin kumburin ganye ɗaya, a cikin kakannin kakanni, ko kuma babu.
    ///
    ///
    /// Wannan hanyar kuma tana rarraba kowane node(s) wanda ya kai ƙarshen.
    /// Wannan yana nuna cewa idan babu sauran maɓallin ƙimar maɓalli guda ɗaya, dukkanin ragowar bishiyar za a raba su ne kuma babu abin da ya rage don dawowa.
    ///
    /// # Safety
    /// edge da aka bayar ba lallai ne abokin aikinsa `deallocating_next` ya dawo dashi ba.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Yana raba tarin nodes daga ganye har zuwa tushe.
    /// Wannan ita ce kawai hanyar da za'a iya raba ragowar bishiya bayan `deallocating_next` da `deallocating_next_back` sun kasance suna niɓe a ɓangarorin biyu na bishiyar, kuma sun buga edge ɗaya.
    /// Kamar yadda aka yi nufin kawai a kira shi lokacin da aka dawo da duk maɓallan da ƙimomin, ba a yin tsabtace kowane ɗayan maɓallan ko ƙimar.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Matsar da ganyen edge zuwa na gaba na edge kuma ya dawo da nassoshi ga maɓallin da ƙimar tsakanin.
    ///
    ///
    /// # Safety
    /// Dole ne a sami wani KV a cikin hanyar da aka bi.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Matsar da ganyen edge rike zuwa na baya edge kuma ya dawo da nassoshi ga maɓallin da ƙimar tsakanin.
    ///
    ///
    /// # Safety
    /// Dole ne a sami wani KV a cikin hanyar da aka bi.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Matsar da ganyen edge zuwa na gaba na edge kuma ya dawo da nassoshi ga maɓallin da ƙimar tsakanin.
    ///
    ///
    /// # Safety
    /// Dole ne a sami wani KV a cikin hanyar da aka bi.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Yin wannan na ƙarshe ya fi sauri, bisa ga ma'auni.
        kv.into_kv_valmut()
    }

    /// Matsar da ganyen edge izuwa leaf na baya kuma ya dawo da nassoshi zuwa maɓallin da ƙimar tsakanin.
    ///
    ///
    /// # Safety
    /// Dole ne a sami wani KV a cikin hanyar da aka bi.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Yin wannan na ƙarshe ya fi sauri, bisa ga ma'auni.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Matsar da ganyen edge zuwa na gaba na edge kuma ya dawo da mabuɗin da ƙimar a tsakani, yana rarraba kowane kumburi da aka bari yayin barin edge mai dacewa a cikin mahaɗar mahaifa.
    ///
    /// # Safety
    /// - Dole ne a sami wani KV a cikin hanyar da aka bi.
    /// - Wancan KV baya dawo dashi daga takwaransa `next_back_unchecked` akan kowane kwafin abin da ake amfani dashi don keta bishiyar.
    ///
    /// Hanya madaidaiciya hanya don ci gaba tare da ɗaukakawar sabuntawa shine a gwada shi, sauke shi, sake kiran wannan hanyar dangane da yanayin amincin sa, ko kira takwaransa `next_back_unchecked` dangane da yanayin aminci.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Matsar da ganyen edge zuwa na baya na edge kuma ya dawo da mabuɗin da ƙimar a tsakani, yana rarraba kowane kumburi da aka bari yayin barin edge mai dacewa a cikin mahaɗar mahaifa.
    ///
    /// # Safety
    /// - Dole ne a sami wani KV a cikin hanyar da aka bi.
    /// - Wannan ganye edge ba abokin aikinsa `next_unchecked` ne ya dawo dashi a baya akan kowane kwafin abin da ake amfani dashi don keta bishiyar ba.
    ///
    /// Hanya madaidaiciya hanya don ci gaba tare da ɗaukakawar sabuntawa shine kwatanta shi, sauke shi, sake kiran wannan hanyar dangane da yanayin amincin sa, ko kira takwaransa `next_unchecked` dangane da yanayin amincin sa.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Yana dawo da ganyen edge na hagu a ciki ko ƙasan kumburi, a wata ma'anar, edge da kuke buƙata da farko lokacin da kuke gaba gaba (ko ƙarshe lokacin da kuke kewaya baya).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Ya dawo da ganyen edge mafi dacewa a ciki ko ƙasan kumburi, a takaice, edge ɗin da kuke buƙata na ƙarshe lokacin tafiya gaba (ko farko lokacin da kuke kewaya baya).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ziyartar node ganyayyaki da KVs na ciki saboda maɓallan hawa, da kuma ziyarci nodes na ciki gabaɗaya a cikin tsari na farko mai zurfi, ma'ana nodes na ciki suna gaban KVs na kowannensu da ƙananan yaransu.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Lissafin abubuwa a cikin itacen (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Ya dawo da ganyen edge mafi kusa da KV don kewayawa gaba.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Yana dawo da ganyen edge mafi kusa da KV don kewayawa baya.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}