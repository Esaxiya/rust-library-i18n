use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Adana kumburi mai yuwuwa ta haɗuwa tare ko sata daga ɗan'uwana.
    /// Idan ya kasance mai nasara amma a farashin ragewar mahaɗin mahaifa, ya dawo wannan kumburin mahaifa.
    /// Yana dawo da `Err` idan kumburin tushen fanko ne.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ya tanadi wata kumburi mai yuwuwa, kuma idan hakan ya haifar da kumburin iyayenta yayi ƙanƙani, zai iya sa hannun jari ya koma baya.
    /// Yana dawo da `true` idan ya gyara bishiyar, `false` idan bazai iya ba saboda asalin kumburin ya zama fanko.
    ///
    /// Wannan hanyar ba ta tsammanin magabatan sun riga sun kasance masu ƙarfi a kan shigarwa da panics idan ta haɗu da magabaci fanko.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Yana cire matakan wofi a saman, amma yana ajiye ganye mara komai idan bishiyar duka babu komai.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Adana hannun jari ko haɗar da kowane ƙananan ƙwayoyi a hannun dama na itacen.
    /// Sauran nodes ɗin, waɗanda ba tushen bane ko kuma edge na dama, dole ne sun riga sun sami aƙalla abubuwan MIN_LEN.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Symwararren launi na `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Ajiye kowane ƙananan ƙwayoyi a gefen dama na itacen.
    /// Sauran nodes ɗin, waɗanda ba tushen bane ko kuma ainihin edge, dole ne su kasance a shirye don sama da abubuwan MIN_LEN waɗanda aka sace.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Bincika idan mafi yawancin yara basu cika iko ba.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Muna bukatar sata.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Je zuwa ƙasa ƙasa.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Ya ba da hannun hagu, yana ɗaukar ɗayan dama bai cika cika ba, kuma an samar da ƙarin abubuwa don ba da damar haɗa 'ya'yanta bi da bi ba tare da zama masu ƙarfi ba.
    ///
    /// Ya dawo da yaron hagu.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` don kaucewa gyara idan haɗuwa ta faru a matakin gaba.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Ya ba da hannun dama ga yaron, yana zaton ɗa na hagu ba shi da ƙarfi, kuma an samar da ƙarin kayan don ba da damar haɗakar da ina inanta bi da bi ba tare da zama masu ƙarfi ba.
    ///
    /// Ya dawo duk inda yaron da ya dace ya ƙare.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` don kaucewa gyara idan haɗuwa ta faru a matakin gaba.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}