use core::intrinsics;
use core::mem;
use core::ptr;

/// Wannan ya maye gurbin ƙimar da ke bayan takamaiman bayani na `v` ta hanyar kiran aikin da ya dace.
///
///
/// Idan panic ya auku a cikin rufewar `change`, za a zub da dukkan aikin.
#[allow(dead_code)] // kiyaye azaman hoto kuma don amfanin future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Wannan ya maye gurbin ƙimar da ke bayan takamaiman bayani na `v` ta hanyar kiran aikin da ya dace, kuma ya dawo da sakamakon da aka samu a hanya.
///
///
/// Idan panic ya auku a cikin rufewar `change`, za a zub da dukkan aikin.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}