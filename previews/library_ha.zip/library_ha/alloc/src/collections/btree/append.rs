use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Sanya dukkan nau'i-nau'i masu darajar darajar daga haɗin ma'abota hawa biyu masu hawa, suna haɓaka canjin `length` akan hanya.Latterarshen yana sauƙaƙa wa mai kiran don kauce wa zubewa yayin da mai kula da digo ya firgita.
    ///
    /// Idan duk masu yin amfani da ita suna samar da maɓalli iri ɗaya, to wannan hanyar za ta saukad da ma'auratan daga mai ba da hagu kuma ta haɗa su daga maɓallin dama.
    ///
    /// Idan kanaso bishiyar ta ƙare da tsari mai tsauri, kamar na `BTreeMap`, duka masu yin tafiyar zasuyi amfani da maɓallan cikin tsawan tsayi, kowanne ya fi kowane maɓallan bishiyar girma, gami da kowane maɓallan da ke cikin itacen lokacin shiga.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Mun shirya don haɗa `left` da `right` cikin jeri jeri a cikin layi.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // A halin yanzu, muna gina bishiya daga jeri jeri a jere.
        self.bulk_push(iter, length)
    }

    /// Yana tura dukkan nau'i-nau'i masu darajar darajar ƙarshen itacen, yana haɓaka canjin `length` akan hanya.
    /// Thearshen yana sauƙaƙa wa mai kiran don kauce wa zubewa yayin da mai magana ya firgita.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Yi hankali ta hanyar dukkan nau'ikan darajar-darajar, tura su zuwa cikin nodes a matakin da ya dace.
        for (key, value) in iter {
            // Gwada tura maɓallin darajar maɓalli zuwa cikin kumburin ganye na yanzu.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Babu sauran sarari, haura ka tura can.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // An sami kumburi tare da sarari hagu, tura nan.
                                open_node = parent;
                                break;
                            } else {
                                // Koma sama.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Muna saman, ƙirƙirar sabon kumburi sannan mu tura can.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Tura maɓallin darajar maɓalli da sabon ƙauyen dama.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Sauka zuwa dama-mafi ganye kuma.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Lengthara tsawo kowane juzu'i, don tabbatar da taswirar ta sauke abubuwan da aka sanya ko da kuwa cigaban mai tantancewar ya firgita.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Mai magana don haɗa jerin jeri guda biyu zuwa ɗaya
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Idan maballan biyu sun daidaita, zai dawo da maɓallin darajar maɓallin daga asalin dama.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}