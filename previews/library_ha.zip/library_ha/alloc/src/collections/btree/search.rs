use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Boundaura da haɗaɗɗen nema, kamar `Bound::Included(T)`.
    Included(T),
    /// Keɓantaccen keɓaɓɓe don nema, kamar `Bound::Excluded(T)`.
    Excluded(T),
    /// Bounda'idar da ba za a iya haɗa ta ba, kamar `Bound::Unbounded`.
    AllIncluded,
    /// Exclusiveayyadadden haddi.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Yana neman maɓallin da aka bayar a cikin (ƙananan) bishiyar da kumburin ke jagoranta, a sake.
    /// Ya dawo da `Found` tare da rikewar KV mai dacewa, idan akwai.
    /// In ba haka ba, ya dawo da `GoDown` tare da rike da ganyen edge inda mabuɗin ke.
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar ta yi odar da maɓalli, kamar itacen da ke cikin `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Ya sauka zuwa kusurwa mafi kusa inda edge yayi daidai da ƙananan iyaka na zangon ya bambanta da edge wanda ya dace da babar sama, watau, kumburi mafi kusa wanda ke da aƙalla maɓalli ɗaya a cikin kewayon.
    ///
    ///
    /// Idan an samo shi, ya dawo da `Ok` tare da wannan kumburin, alamun edge guda biyu a ciki suna iyakance kewayon, da kuma iyakokin da suka dace don ci gaba da bincike a cikin ƙananan yara, idan kumburin na ciki ne.
    ///
    /// Idan ba'a samo shi ba, zai dawo da `Err` tare da ganye edge wanda yayi daidai da kewayon duka.
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar tayi odar ta maballin.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Bayyana waɗannan masu canji ya kamata a kauce musu.
        // Muna tsammanin iyakokin da `range` suka ruwaito sun kasance iri ɗaya, amma aiwatarwa na iya canzawa tsakanin kira (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Nemo edge a cikin kumburin da ke iyakance ƙananan iyaka na kewayon.
    /// Hakanan ya dawo da ƙananan da za ayi amfani da shi don ci gaba da bincike a cikin kumburin yaro, idan `self` na ciki ne.
    ///
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar tayi odar ta maballin.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Clone na `find_lower_bound_edge` don igiyar sama.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Yana neman maɓallin da aka bayar a cikin kumburin, ba tare da sake dawowa ba.
    /// Ya dawo da `Found` tare da rikewar KV mai dacewa, idan akwai.
    /// In ba haka ba, ya dawo da `GoDown` tare da makullin edge inda za a iya samun mabuɗin (idan kumburin na ciki ne) ko kuma inda za a saka mabuɗin.
    ///
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar ta yi odar da maɓalli, kamar itacen da ke cikin `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Ya dawo ko dai alamar KV a cikin kumburin da maɓallin ke (ko makamancin haka) ya kasance, ko jerin edge inda mabuɗin ke ciki.
    ///
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar ta yi odar da maɓalli, kamar itacen da ke cikin `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Nemo bayanan edge a cikin kumburin da ke iyakance ƙananan iyaka na kewayon.
    /// Hakanan ya dawo da ƙananan da za ayi amfani da shi don ci gaba da bincike a cikin kumburin yaro, idan `self` na ciki ne.
    ///
    ///
    /// Sakamakon yana da ma'ana ne kawai idan bishiyar tayi odar ta maballin.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Clone na `find_lower_bound_index` don igiyar sama.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}