use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Mahimmanci na mai magana wanda ya haɗu da fitowar masu tsauraran matakan hawa biyu, alal misali ƙungiya ko bambancin ra'ayi.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Alamar alamomi da sauri fiye da narkar da masu yin amfani da ita a cikin Peekable, mai yuwuwa saboda zamu iya samun ikon sanya FusedIterator daure.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Creatirƙira sabon tushe don mai yin amfani da hanyoyin haɗi guda biyu.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Ya dawo da abubuwa biyu masu zuwa wanda ya samo asali daga hanyoyin biyu da ake hade su.
    /// Idan duka zaɓuɓɓukan da aka dawo suna ƙunshe da ƙima, ƙimar daidai take kuma tana faruwa a duka hanyoyin.
    /// Idan ɗaya daga cikin zaɓuɓɓukan da aka dawo ya ƙunshi ƙima, ƙimar ba ta faruwa a ɗayan asalin ba (ko kuma asalin ba sa hawa sosai).
    ///
    /// Idan babu wani zaɓi da aka dawo da shi yana ƙunshe da ƙima, maimaitawa ya ƙare kuma kira mai zuwa zai dawo da guda biyu ɗin fanko.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Yana dawo da iyakoki biyu na sama don `size_hint` na ƙarshen mai magana.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}