//! An yi jerin gwano mai fifiko tare da tarin binary.
//!
//! Shigar da ƙara girma mafi girma suna da rikitaccen lokacin *O*(log(*n*)).
//! Duba mafi girman sashi shine *O*(1).Ana canza vector zuwa tarin binary ana iya yin shi a wuri, kuma yana da rikitarwa *O*(*n*).
//! Hakanan za'a iya jujjuya tarin binary zuwa tsararren vector a cikin-wuri, yana ba shi damar amfani da shi don *O*(*n*\*log(* n*)) a cikin wuri-wuri.
//!
//! # Examples
//!
//! Wannan babban misali ne wanda ke aiwatar da [Dijkstra's algorithm][dijkstra] don warware [shortest path problem][sssp] akan [directed graph][dir_graph].
//!
//! Yana nuna yadda ake amfani da [`BinaryHeap`] tare da nau'ikan al'ada.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // A fifiko jerin gwano dogara a kan `Ord`.
//! // A bayyane yake aiwatar da trait don haka layin ya zama ƙara-maɓi maimakon babban tsibi.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Lura cewa muna jujjuya odar akan farashi.
//!         // Idan an yi kunnen doki muna kwatanta matsayi, wannan matakin ya zama dole don aiwatar da `PartialEq` da `Ord` daidai.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` yana bukatar aiwatarwa shi ma.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Kowane kumburi yana wakilta azaman `usize`, don ɗan gajeren aiwatarwa.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra mafi gajeriyar hanya algorithm.
//!
//! // Farawa daga `start` kuma amfani da `dist` don bin hanyar mafi ƙarancin tazara ta yanzu zuwa kowane kumburi.Wannan aiwatarwar ba ingantaccen ƙwaƙwalwar ajiya bane domin tana iya barin maɓuɓɓugan abubuwa a cikin layi.
//! //
//! // Hakanan yana amfani da `usize::MAX` azaman ƙimar sintiri, don sauƙin aiwatarwa.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=mafi karancin tazarar yanzu daga `start` zuwa `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Muna kan `start`, tare da tsadar kuɗi
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Yi nazarin kan iyaka tare da ƙananan ƙididdigar farashi (min-heap) na farko
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // A madadin haka muna iya ci gaba da nemo dukkan gajerun hanyoyi
//!         if position == goal { return Some(cost); }
//!
//!         // Mai mahimmanci kamar yadda wataƙila mun riga mun sami hanya mafi kyau
//!         if cost > dist[position] { continue; }
//!
//!         // Ga kowane kumburi da za mu iya kaiwa, duba idan za mu iya samun hanya tare da rahusa mai rahusa ta hanyar wannan kumburin
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Idan haka ne, ƙara da shi zuwa kan iyakar kuma ci gaba
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Hutawa, yanzu mun sami hanya mafi kyau
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Ba za a iya cimma burin ba
//!     None
//! }
//!
//! fn main() {
//!     // Wannan shine jadawalin zane wanda zamuyi amfani dashi.
//!     // Lambobin kumburin sun yi daidai da jihohi daban-daban, kuma nauyin edge yana alamta kuɗin motsawa daga wata kumburi zuwa wancan.
//!     //
//!     // Lura cewa gefuna hanya ɗaya ce.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Jadawalin yana wakilta azaman jerin adjacency inda kowane index, yayi daidai da ƙimar kumburi, yana da jerin gefuna masu fita.
//!     // Aka zaba don inganci.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Kumburi 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // kumburi 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// An yi jerin gwano mai fifiko tare da tarin binary.
///
/// Wannan zai zama babban tsibi.
///
/// Kuskure ne na hankali don abu ya gyaru ta yadda odar kayan ta danganta ga kowane abu, kamar yadda `Ord` trait ya ƙaddara, ya canza yayin da yake cikin tarin.
///
/// Wannan yana yiwuwa ne kawai ta hanyar `Cell`, `RefCell`, yanayin duniya, I/O, ko lambar da ba ta amintacce.
/// Halin da ya haifar da irin wannan kuskuren tunanin ba a fayyace shi ba, amma ba zai haifar da halayyar da ba a bayyana ta ba.
/// Wannan na iya haɗawa da panics, sakamakon da ba daidai ba, zubar da ciki, ɓoyewar ƙwaƙwalwar ajiya, da rashin ƙarewa.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Nau'in rubutun yana ba mu damar barin sa hannu irin na bayyane (wanda zai zama `BinaryHeap<i32>` a cikin wannan misalin).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Zamu iya amfani da leke don kallon abu na gaba a cikin tsibi.
/// // A wannan halin, babu abubuwa a ciki har yanzu saboda haka bamu sami Babu.
/// assert_eq!(heap.peek(), None);
///
/// // Bari mu kara wasu maki ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Yanzu leke yana nuna abu mafi mahimmanci a cikin tsibirin.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Zamu iya duba tsawon tarin.
/// assert_eq!(heap.len(), 3);
///
/// // Zamu iya raba abubuwan a cikin tsibirin, kodayake an dawo dasu cikin tsari bazuwar.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Idan maimakon haka muka fito da waɗannan ƙididdigar, ya kamata su dawo cikin tsari.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Zamu iya share duk wasu abubuwa da suka rage.
/// heap.clear();
///
/// // Ya kamata tsibin ya zama fanko.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Ko dai `std::cmp::Reverse` ko aiwatar da al'ada `Ord` ana iya amfani dashi don sanya `BinaryHeap` min-heap.
/// Wannan ya sa `heap.pop()` ya dawo da ƙarami ƙimar maimakon mafi girma.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Valuesara darajar a cikin `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Idan muka fitar da waɗannan ƙididdigar yanzu, yakamata su dawo cikin tsarin baya.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Hadadden lokaci
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Imar `push` tsada ce mai tsammanin;takaddun hanyoyin suna ba da ƙarin cikakken bincike.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Tsarin da ke kunshe da canjin canjin magana zuwa abu mafi girma akan `BinaryHeap`.
///
///
/// Wannan `struct` an ƙirƙire ta hanyar hanyar [`peek_mut`] akan [`BinaryHeap`].
/// Duba bayanansa don ƙarin.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // KYAUTA: PeekMut an sake tsara shi kawai don tsibirin mara fanko.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // KYAUTA: PeekMut an tsara shi ne kawai don tsibin mara fanko
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // KYAUTA: PeekMut an tsara shi ne kawai don tsibin mara fanko
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Cire darajar peck daga dutsen kuma ya dawo da ita.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Esirƙira komai na `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Esirƙira komai na `BinaryHeap` azaman max-heap.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Irƙira komai na `BinaryHeap` tare da takamaiman ƙarfi.
    /// Wannan yana ƙaddamar da isasshen ƙwaƙwalwar ajiya don abubuwan `capacity`, don haka `BinaryHeap` ba za a sake sanya shi ba sai ya ƙunshi aƙalla ƙimomin da yawa.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Yana dawo da ambaton canzawa zuwa abu mafi girma a cikin tarin binary, ko `None` idan babu komai.
    ///
    /// Note: Idan darajar `PeekMut` ta zube, tsibirin na iya kasancewa a cikin halin rashin daidaituwa.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Hadadden lokaci
    ///
    /// Idan abu ya gyaru to mafi munin lokacin rikitarwa shine *O*(log(*n*)), in ba haka ba *O*(1) ne.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Ana cire abu mafi girma daga tarin binary ya dawo da shi, ko `None` idan babu komai.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Hadadden lokaci
    ///
    /// Mafi munin tsadar shari'ar `pop` akan tarin da ke dauke da abubuwan *n* shine *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // KYAUTA: !self.is_empty() na nufin self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Tura abu akan tarin binary.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Hadadden lokaci
    ///
    /// Kudin da ake tsammani na `push`, matsakaici akan kowane oda na abubuwan da ake turawa, kuma sama da adadin da aka tura, shine *O*(1).
    ///
    /// Wannan shi ne mafi m kudin tsarin awo a lokacin da turawa abubuwa da suke *ba* riga a wani An ware juna.
    ///
    /// Complexwarewar lokaci yana raguwa idan aka tura abubuwa cikin tsari mafi girma.
    /// A cikin mafi munin yanayi, ana tura abubuwa cikin tsari tsararru kuma farashin da aka sanya ta turawa shine *O*(log(*n*)) akan wani tarin da yake dauke da abubuwan *n*.
    ///
    /// Mafi munin tsadar halin *kira* guda zuwa `push` shine *O*(*n*).Mafi munin yanayi yana faruwa ne lokacin da ƙarfin aiki ya ƙare kuma yana buƙatar ƙimar girma.
    /// An sake sanya adadin kudin a cikin alkaluman da suka gabata.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // KYAUTA: Tunda mun tura sabon abu yana nufin hakan
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Cinye `BinaryHeap` kuma ya dawo da vector cikin tsari na (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // KYAUTA: `end` ya fito daga `self.len() - 1` zuwa 1 (duka an haɗa su),
            //  don haka koyaushe ingantaccen index ne don samun dama.
            //  Yana da lafiya don samun damar fitarwa na 0 (watau `ptr`), saboda
            //  1 <=ƙarshe <self.len(), wanda ke nufin self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // KYAUTA: `end` ya fito daga `self.len() - 1` zuwa 1 (duka an haɗa su) don haka:
            //  0 <1 <=ƙarshe <= self.len(), 1 <self.len() Wanda ke nufin 0 <ƙarewa da ƙarshe <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Aiwatar da sift_up da sift_down suna amfani da tubalan da basu da aminci don motsa wani abu daga cikin vector (barin baya da rami), canzawa tare da sauran kuma matsar da ɓangaren da aka cire ya dawo cikin vector a wurin ƙarshe na ramin.
    //
    // Ana amfani da nau'in `Hole` don wakiltar wannan, kuma tabbatar cewa ramin an sake cika shi a ƙarshen iyakar sa, koda akan panic.
    // Yin amfani da rami yana rage mahimmin abu idan aka kwatanta da amfani da swaps, wanda ya ƙunshi sau biyu da yawa motsi.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Dole ne mai kiran ya bada tabbacin cewa `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Fitar da ƙimar a `pos` kuma ƙirƙirar rami.
        // KYAUTA: Mai kiran ya tabbatar da cewa pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // KYAUTA: hole.pos()> fara>=0, wanda ke nufin hole.pos()> 0
            //  don haka hole.pos(), 1 ba zai iya malalawa ba.
            //  Wannan yana tabbatarwa iyayen <hole.pos() don haka yana da ingantaccen index kuma shima!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // KYAUTA: Kamar yadda yake a sama
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Dauki wani kashi a `pos` da kuma motsa shi saukar da tsibin, yayin da ta yara ne ya fi girma.
    ///
    ///
    /// # Safety
    ///
    /// Dole ne mai kiran ya bada tabbacin cewa `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // KYAUTA: Mai kiran ya ba da tabbacin cewa pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Madauki mara madaidaici: yaro==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // Kwatanta da mafi girma daga cikin yaran biyu SAFETY: yaro <ƙarshen, 1 <self.len() da yaro + 1 <ƙarshe <= self.len(), don haka suna da alamun aiki.
            //
            //  yaro==2 *hole.pos() + 1!= hole.pos() da yaro + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ko 2* hole.pos() + 2 na iya malalowa idan T shine ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // idan mun riga mun kasance cikin tsari, tsaya.
            // KYAUTA: yaro yanzu ya zama tsoho ko tsoho + 1
            //  Mun riga mun tabbatar da cewa duka biyun ne <self.len() and!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // KYAUTA: daidai yake da na sama.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // KYAUTA: &&gajeren hanya, wanda ke nufin a cikin
        //  yanayi na biyu ya riga ya zama gaskiya wancan yaron==ƙarshen, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // KYAUTA: an riga an tabbatar da yaro ya zama ingantaccen ma'auni kuma
            //  yaro==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Dole ne mai kiran ya bada tabbacin cewa `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // KYAUTA: pos <len yana da garantin mai kiran kuma
        //  a fili len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Auki abu a `pos` ka matsar dashi gab da dutsen, sannan ka tsabtace shi zuwa inda yake.
    ///
    ///
    /// Note: Wannan ya fi sauri idan aka san cewa babban abu ya kasance babba/ya kamata kusa da ƙasan.
    ///
    /// # Safety
    ///
    /// Dole ne mai kiran ya bada tabbacin cewa `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // KYAUTA: Mai kiran ya tabbatar da cewa pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Madauki mara madaidaici: yaro==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // KYAUTA: yaro <ƙarshe, 1 <self.len() da
            //  yaro + 1 <ƙarshe <= self.len(), saboda haka suna da alamun aiki.
            //  yaro==2 *hole.pos() + 1!= hole.pos() da yaro + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ko 2* hole.pos() + 2 na iya malalowa idan T shine ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // KYAUTA: Kamar yadda yake a sama
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // KYAUTA: yaro==ƙarshe, 1 <self.len(), saboda haka ingantaccen index ne
            //  da yaro==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // KYAUTA: pos shine matsayin cikin rami kuma an riga an tabbatar dashi
        //  ya zama ingantaccen index.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // KYAUTA: n yana farawa daga self.len()/2 kuma ya gangara zuwa 0.
            //  Abin sani kawai lokacin da! (N <self.len()) shine idan self.len() ==0, amma an cire shi ta yanayin madauki.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Matsar da dukkan abubuwan da ke cikin `other` zuwa `self`, suna barin `other` fanko.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` yana ɗaukar ayyukan O(len1 + len2) kuma game da kwatancen 2 *(len1 + len2) a cikin mafi munin yanayi yayin da `extend` ke ɗaukar ayyukan O(len2* log(len1)) kuma game da kwatancen 1 *len2* log_2(len1) a cikin mafi munin yanayi, ɗauka len1>= len2.
        // Don manyan tsibirai, maɓallin gicciye ba ya bi wannan tunanin kuma an ƙaddara shi da ƙarfi.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Ya dawo da mai magana wanda zai dawo da abubuwa cikin tsari mai yawa.
    /// Ana cire abubuwan da aka dawo da su daga asalin daddawa.
    /// Za a cire sauran abubuwan da suka rage a kan digo cikin tsaran oda.
    ///
    /// Note:
    /// * `.drain_sorted()` shine *O*(*n*\*log(* n*)); ya fi hankali fiye da `.drain()`.
    ///   Ya kamata ku yi amfani da ƙarshen don mafi yawan lokuta.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // yana cire dukkan abubuwa cikin tsari
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Yana riƙe abubuwa kawai da aka ambata a lokacin magana.
    ///
    /// A wasu kalmomin, cire duk abubuwan `e` kamar `f(&e)` ya dawo da `false`.
    /// Ana ziyartar abubuwan cikin tsari mara tsari (kuma ba a fayyace su ba).
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // kawai kiyaye har ma da lambobi
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Ya dawo da mai magana yana ziyartar duk ƙimomin da ke cikin vector, a cikin tsari ba da tsari ba.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Buga 1, 2, 3, 4 cikin tsari ba da tsari ba
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Ya dawo da mai magana wanda zai dawo da abubuwa cikin tsari mai yawa.
    /// Wannan hanyar tana cinye asalin tari.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Ya dawo da babban abu a cikin tarin binary, ko `None` idan babu komai.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Hadadden lokaci
    ///
    /// Kudin yana *O*(1) a cikin mafi munin yanayi.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Ya dawo da adadin abubuwan da tarin binary zai iya riƙe ba tare da sake rarraba su ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Yana ajiyar mafi ƙarancin ƙarfi don daidai abubuwan ƙarin `additional` da za a saka a cikin `BinaryHeap` da aka bayar.
    /// Babu komai idan ƙarfin ya riga ya isa.
    ///
    /// Lura cewa mai ba da kuɗin na iya ba tarin wuri fiye da yadda yake buƙata.
    /// Sabili da haka iya aiki ba za a dogara ga zama mafi ƙarancin daidai ba.
    /// Fi son [`reserve`] idan ana tsammanin shigarwar future.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya cika `usize`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Yana ajiyar iya aiki don aƙalla ƙarin abubuwa `additional` da za'a saka a cikin `BinaryHeap`.
    /// Mayididdigar na iya keɓe ƙarin sarari don kauce wa wuraren sake wurare da yawa.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya cika `usize`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Yi watsi da ƙarin ƙarfin gwargwadon iko.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Yi watsi da iya aiki tare da ƙarami.
    ///
    /// Capacityarfin zai kasance aƙalla babba kamar tsawonsa da ƙimar da aka bayar.
    ///
    ///
    /// Idan ƙarfin yanzu yana ƙasa da ƙananan iyaka, wannan ba komai bane.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Cinye `BinaryHeap` kuma ya dawo da ainihin vector a cikin tsari ba da tsari ba.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Zai buga a wani tsari
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Ya dawo da tsayin binary.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Ana dubawa idan tarin binary fanko ne.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Yana share tarin binary, yana dawo da mai sakewa akan abubuwan da aka cire.
    ///
    /// Ana cire abubuwan a cikin tsari ba tare da tsari ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Sauke dukkan abubuwa daga tarin binary.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Rami na wakiltar rami a yanki watau, fihirisa ba tare da inganci mai amfani ba (saboda an motsa shi daga ko an maimaita shi).
///
/// A cikin faduwa, `Hole` zai dawo da yanki ta hanyar cika matsayin rami tare da ƙimar da aka cire ta asali.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Irƙiri sabon `Hole` a index `pos`.
    ///
    /// Mara aminci saboda pos dole ne ya kasance cikin yanki bayanan.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // LAFIYA: pos yakamata ya kasance cikin yanki
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Ya dawo da tunani akan abinda aka cire.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Yana dawowa da ma'anar ma'anar a `index`.
    ///
    /// Ba shi da amintacce saboda ƙididdiga dole ne ya kasance cikin yanki bayanan kuma bai yi daidai da pos ba.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Matsar da rami zuwa sabon wuri
    ///
    /// Ba shi da amintacce saboda ƙididdiga dole ne ya kasance cikin yanki bayanan kuma bai yi daidai da pos ba.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // cika rami sake
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Mai magana akan abubuwan `BinaryHeap`.
///
/// Wannan `struct` an ƙirƙira shi ta [`BinaryHeap::iter()`].
/// Duba bayanansa don ƙarin.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Cire a madadin `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Mai maimaita mallakar abubuwa akan `BinaryHeap`.
///
/// Wannan `struct` aka halitta da [`BinaryHeap::into_iter()`] (bayar da `IntoIterator` trait).
/// Duba bayanansa don ƙarin.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Mai sharar ruwa akan abubuwan `BinaryHeap`.
///
/// Wannan `struct` an ƙirƙira shi ta [`BinaryHeap::drain()`].
/// Duba bayanansa don ƙarin.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Mai sharar ruwa akan abubuwan `BinaryHeap`.
///
/// Wannan `struct` an ƙirƙira shi ta [`BinaryHeap::drain_sorted()`].
/// Duba bayanansa don ƙarin.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Ana cire abubuwa masu tarin yawa cikin tsari.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Sabobincike `Vec<T>` zuwa `BinaryHeap<T>`.
    ///
    /// Wannan juzuwar yana faruwa a cikin wuri, kuma yana da rikitaccen lokacin *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Sabobincike `BinaryHeap<T>` zuwa `Vec<T>`.
    ///
    /// Wannan jujjuyawar baya buƙatar motsi ko bayanai, kuma yana da rikitaccen lokaci koyaushe.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Creatirƙira mai maimaita magana, ma'ana, wanda ke motsa kowane ƙimar daga tarin binary a cikin tsari na sabani.
    /// Ba za a iya amfani da tarin binary ba bayan kiran wannan.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Buga 1, 2, 3, 4 cikin tsari ba da tsari ba
    /// for x in heap.into_iter() {
    ///     // x yana da nau'in i32, ba &i32 ba
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}