//! Jerin layi mai ƙare biyu wanda aka aiwatar tare da maɓallin kewayawa mai girma.
//!
//! Wannan layin yana da *O*(1) amortized da ake cirewa daga ƙarshen duka akwatin.
//! Hakanan yana da alamun *O*(1) kamar vector.
//! Ba a buƙatar abubuwan da ke ƙunshe su zama na kwashewa ba, kuma za a iya aika sahu idan an aika da nau'in da ke ƙunshe da shi.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Mafi girman yiwuwar iko biyu

/// Jerin layi mai ƙare biyu wanda aka aiwatar tare da maɓallin kewayawa mai girma.
///
/// A "default" amfani na irin wannan a matsayin wani jerin gwano ne don amfani [`push_back`] don ƙara zuwa ga jerin gwano, da kuma [`pop_front`] cire daga jerin gwano.
///
/// [`extend`] da [`append`] suna turawa ta baya ta wannan hanyar, kuma yin aiki akan `VecDeque` yana zuwa gaba da baya.
///
/// Tunda `VecDeque` yana yin ajiyar zoben ringi, abubuwan da ke tattare da shi ba lallai ba ne a cikin ƙwaƙwalwar ajiya.
/// Idan kuna son samun damar abubuwan a matsayin yanki guda, kamar don ingantaccen tsari, zaku iya amfani da [`make_contiguous`].
/// Yana rotates da `VecDeque` sabõda haka, da abubuwa ba kunsa, da kuma dawo da wani mutable yanki zuwa yanzu-contiguous kashi jerin.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // wutsiya da kai sune alamomi a cikin shagon.
    // Wutsiyoyi koyaushe suna nuna farkon abin da za'a iya karantawa, Kai koyaushe yana nuna inda ya kamata a rubuta bayanai.
    //
    // Idan wutsiya==shugaban abin ajiyewa fanko.An bayyana tsawon ringbuffer a matsayin tazara tsakanin su biyun.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Gudanar da mai lalata duk abubuwan da ke cikin yanki lokacin da ya fadi (a al'adance ko yayin buɗewa).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // yi amfani da digo don [T]
            ptr::drop_in_place(front);
        }
        // RawVec yana kula da rarraba wuri
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Esirƙira komai na `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginally mafi dace
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally mafi dace
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Don nau'ikan nau'ikan sifili, koyaushe muna kan iyakar iyawa
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Juya ptr zuwa yanki
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Juya ptr zuwa yanki yanki
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Matsar da wani abu daga maƙallan
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Ya rubuta wani abu a cikin abin adanawa, yana motsa shi.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Yana dawowa `true` idan ma'ajin yana kan cikakken ƙarfin.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Mayar da bayanan a cikin mahimmin shafi don abin da aka ba da ma'anar ma'ana.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Mayar da fihirisa a cikin mahimmin shafi don abin da aka ba da ma'anar ma'ana + ƙara.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Mayar da fihirisa a cikin mahimmin shafi don abin da aka ba da ma'anar ma'ana, ƙara fahimta.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kwafa maɓallin ƙwaƙwalwar ajiya wacce aka ɗora daga src zuwa dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kwafa maɓallin ƙwaƙwalwar ajiya wacce aka ɗora daga src zuwa dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kwafa wata makarkata da za a iya nadawa daga ƙwaƙwalwar ajiyar dogon lokaci daga src zuwa ƙaddara.
    /// (abs(dst - src) + Len) dole ba fi girma fiye da cap() (Akwai dole ne ya zama a mafi daya m overlapping yankin tsakanin src da dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src baya nadewa, dst baya nadewa
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst kafin src, src baya kunsa, dst ya kunsa
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src kafin dst, src baya kunsa, dst ya nade
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst kafin src, src ya nade, dst baya nadewa
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src kafin dst, src ya kunsa, dst baya nadewa
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst kafin src, src ya nade, dst ya kunsa
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src kafin dst, src ya kunsa, dst ya nade
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs sassan kai da wutsiya don rike gaskiyar cewa kawai an sake sanya mu.
    /// Matsera domin shi ya dogara old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Matsar da mafi gajeriyar sanannen ɓangare na abin adon zobe TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Esirƙira komai na `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Irƙira komai na `VecDeque` tare da sarari don aƙalla abubuwan `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 tunda ringbuffer koyaushe yana barin sarari fanko
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Yana bayar da tunani game da ɓangaren a cikin bayanin da aka bayar.
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Samar da wani mutable tunani da rabi a ba index.
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Abubuwan sauyawa a fihirisa `i` da `j`.
    ///
    /// `i` kuma `j` na iya zama daidai.
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Panics
    ///
    /// Panics idan ɗayan ma'auni ya wuce iyaka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Ya dawo da adadin abubuwan da `VecDeque` zai iya riƙe ba tare da sake sanya wuri ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Yana ajiyar mafi ƙarancin ƙarfi don daidai abubuwan ƙarin `additional` da za a saka a cikin `VecDeque` da aka bayar.
    /// Babu komai idan ƙarfin ya riga ya isa.
    ///
    /// Lura cewa mai ba da kuɗin na iya ba tarin wuri fiye da yadda yake buƙata.
    /// Sabili da haka iya aiki ba za a dogara ga zama mafi ƙarancin daidai ba.
    /// Fi son [`reserve`] idan ana tsammanin shigarwar future.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya cika `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Yana ajiyar iya aiki don akalla abubuwa `additional` da za'a saka a cikin `VecDeque` da aka bayar.
    /// Mayididdigar na iya keɓe ƙarin sarari don kauce wa wuraren sake wurare da yawa.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya cika `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Yayi ƙoƙari don adana mafi ƙarancin ƙarfi don daidai abubuwan ƙarin `additional` da za a saka a cikin `VecDeque<T>` da aka bayar.
    ///
    /// Bayan kiran `try_reserve_exact`, ƙarfin zai fi girma ko daidaita da `self.len() + additional`.
    /// Babu komai idan ƙarfin ya riga ya isa.
    ///
    /// Lura cewa mai ba da kuɗin na iya ba tarin wuri fiye da yadda yake buƙata.
    /// Sabili da haka, ba za a dogara da ƙarfin iya zama daidai kaɗan.
    /// Fi son `reserve` idan ana tsammanin shigarwar future.
    ///
    /// # Errors
    ///
    /// Idan ƙarfin ya cika `usize`, ko kuma mai ba da rahoton ya faɗi kasawa, to an dawo da kuskure.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Yi ajiyar ƙwaƙwalwar ajiya, fita idan ba za mu iya ba
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Yanzu mun san wannan ba zai iya OOM(Out-Of-Memory) a tsakiyar aikinmu mai rikitarwa ba
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // mai rikitarwa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Yayi ƙoƙari don adana iya aiki don aƙalla ƙarin abubuwan da za a saka `additional` a cikin `VecDeque<T>` da aka bayar.
    /// Mayididdigar na iya keɓe ƙarin sarari don kauce wa wuraren sake wurare da yawa.
    /// Bayan kiran `try_reserve`, ƙarfin zai fi girma ko daidaita da `self.len() + additional`.
    /// Babu komai idan iyawa ya isa.
    ///
    /// # Errors
    ///
    /// Idan ƙarfin ya cika `usize`, ko kuma mai ba da rahoton ya faɗi kasawa, to an dawo da kuskure.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Yi ajiyar ƙwaƙwalwar ajiya, fita idan ba za mu iya ba
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Yanzu mun san cewa wannan ba zai iya ba OOM ba a tsakiyar aikinmu mai rikitarwa
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // mai rikitarwa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Yana rage damar `VecDeque` kamar yadda ya yiwu.
    ///
    /// Zai sauka ƙasa gwargwadon yadda zai yiwu zuwa tsawon amma mai raba shi yana iya sanar da `VecDeque` cewa akwai sarari don morean ƙarin abubuwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Rinarfafa damar `VecDeque` tare da ƙananan lada.
    ///
    /// Capacityarfin zai kasance aƙalla babba kamar tsawonsa da ƙimar da aka bayar.
    ///
    ///
    /// Idan ƙarfin yanzu yana ƙasa da ƙananan iyaka, wannan ba komai bane.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Bai kamata mu damu da ambaliya ba kamar yadda `self.len()` ko `self.capacity()` ba zasu taɓa zama `usize::MAX` ba.
        // +1 kamar yadda ringbuffer koyaushe yake barin sarari fanko.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Akwai sharuɗɗa guda uku na sha'awa:
            //   Dukkan abubuwa basa cikin iyakokin da ake so Abubuwa suna da rikitarwa, kuma kai ya fita daga iyakar da ake so Abubuwa ba su da rikitarwa, kuma wutsiya ba ta da iyaka da ake so
            //
            //
            // A kowane sauran lokuta, ba a taɓa tasirin matsayin abubuwa.
            //
            // Nuna cewa yakamata a motsa abubuwa a kan kai.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Matsar abubuwa daga fita daga so haddi (matsayi bayan target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Ya gajarta da `VecDeque`, yana kiyaye abubuwan farko na `len` kuma ya watsar da sauran.
    ///
    ///
    /// Idan `len` ya fi tsayi na VecDeque`, wannan ba shi da tasiri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Gudanar da mai lalata duk abubuwan da ke cikin yanki lokacin da ya fadi (a al'adance ko yayin buɗewa).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Lafiya saboda:
        //
        // * Duk wani yanki da aka wuce zuwa `drop_in_place` yana da inganci;shari'ar ta biyu tana da `len <= front.len()` kuma dawowa akan `len > self.len()` yana tabbatar da `begin <= back.len()` a cikin ta farko
        //
        // * Ana motsa shugaban VecDeque kafin kiran `drop_in_place`, don haka babu ƙimar da ta ragu sau biyu idan `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Tabbatar da na biyu da rabi ne ragu ko da wani destructor a farko daya panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Yana dawowa mai gabatarwa gaba-da-baya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Yana dawo da mai-bayani na gaba-da-baya wanda ya dawo da nassoshi masu sauyawa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // KYAUTA: An tabbatar da canzawa cikin aminci na `IterMut` saboda
        // `ring` mun ƙirƙira yanki ne wanda za'a iya raba shi tsawon rayuwa '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Yana dawo da wasu yan-biyu wadanda suka kunshi, cikin tsari, abubuwan da ke cikin `VecDeque`.
    ///
    /// Idan ana kiran [`make_contiguous`] a baya, duk abubuwan da ke cikin `VecDeque` zasu kasance a cikin yanki na farko kuma yanki na biyu zai zama fanko.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Yana dawo da wasu yan-biyu wadanda suka kunshi, cikin tsari, abubuwan da ke cikin `VecDeque`.
    ///
    /// Idan ana kiran [`make_contiguous`] a baya, duk abubuwan da ke cikin `VecDeque` zasu kasance a cikin yanki na farko kuma yanki na biyu zai zama fanko.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Yana dawo da adadin abubuwan a cikin `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Yana dawowa `true` idan `VecDeque` fanko ne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Creatirƙira mai magana wanda ke rufe kewayon da aka ƙayyade a cikin `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics idan farawa ya fi ƙarshen ƙarshen ko kuma idan ƙarshen ƙarshen ya fi tsayi na vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Cikakken kewayon ya rufe dukkan abubuwan da ke ciki
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Bayanin raba da muke da shi a cikin &self ana kiyaye shi a cikin '_ na Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Creatirƙira mai magana wanda ke rufe takamaiman zangon canzawa a cikin `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics idan farawa ya fi ƙarshen ƙarshen ko kuma idan ƙarshen ƙarshen ya fi tsayi na vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Cikakken kewayon ya rufe dukkan abubuwan da ke ciki
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // KYAUTA: An tabbatar da canzawa cikin aminci na `IterMut` saboda
        // `ring` mun ƙirƙira yanki ne wanda za'a iya raba shi tsawon rayuwa '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Irƙira mai sharar ruwa wanda ke cire takamaiman kewayon a cikin `VecDeque` kuma yana ba da abubuwan da aka cire.
    ///
    /// Lura 1: Ana cire kewayon abu koda kuwa ba'a shafan mai karantawa ba har zuwa ƙarshe.
    ///
    /// Bayani na 2: Ba'a tantance adadin abubuwan da aka cire daga maganan ba, idan ba a fadi darajar `Drain` ba, amma bashin da yake rike ya kare (misali, saboda `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics idan farawa ya fi ƙarshen ƙarshen ko kuma idan ƙarshen ƙarshen ya fi tsayi na vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // A cikakken kewayon kuranye duk abinda ke ciki
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Amintaccen ƙwaƙwalwar ajiya
        //
        // Lokacin da aka fara kirkirar Drain, asalin littafin zai gajarta ne don tabbatar da cewa babu wasu abubuwan da basu waye ba ko suke motsawa daga abubuwa idan mai lalata Drain ba zai taba gudu ba.
        //
        //
        // Drain zai ptr::read fitar da ƙimomin don cirewa.
        // Lokacin da aka gama, za a kwafa sauran bayanan don rufe ramin, kuma za a dawo da ƙimar head/tail daidai.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Abubuwan alfarma sun rabu kashi uku:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Muna adana drain_tail kamar self.head, da drain_head da self.head kamar after_tail da kuma bayan-head bi da bi a kan Drain.
        // Wannan kuma yana yanke tasiri mai tasiri kamar idan idan Drain ya zube, mun manta game da ɗimbin da za a iya motsawa bayan fara drain.
        //
        //
        //        Harshen H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" game da ƙimomin bayan fara drain har sai bayan drain ya cika kuma mai lalata Drain yana gudana.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Abu mai mahimmanci, kawai muna ƙirƙirar nassoshi da aka raba daga `self` nan kuma karanta daga ciki.
                // Ba mu rubuta zuwa `self` ba kuma ba za mu sake komawa ga bayanin canjin yanayi ba.
                // Saboda haka ɗan bayanan da muka ƙirƙira a sama, don `deque`, yana nan yana aiki.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Yana share `VecDeque`, yana cire duk ƙimomin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Yana dawo da `true` idan `VecDeque` ya ƙunshi abu daidai yake da ƙimar da aka bayar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Yana bayar da ishara zuwa ɓangaren gaba, ko `None` idan `VecDeque` fanko ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Yana bayar da ambaton maye gurbin abu na gaba, ko `None` idan `VecDeque` fanko ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Yana bayar da ishara zuwa ɓangaren baya, ko `None` idan `VecDeque` fanko ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Yana bayar da ambaton maye gurbin abu na baya, ko `None` idan `VecDeque` fanko ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Cire abu na farko kuma ya dawo dashi, ko `None` idan `VecDeque` fanko ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Cire abu na ƙarshe daga `VecDeque` kuma ya dawo dashi, ko `None` idan babu komai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Yana shirya kashi zuwa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Endsara wani ɓoye a bayan `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Shin yakamata muyi la'akari da `head == 0` da ma'ana
        // cewa `self` yana haɗuwa?
        self.tail <= self.head
    }

    /// Ana cire wani abu daga ko'ina cikin `VecDeque` kuma ya dawo da shi, ya maye gurbinsa da farkon abu.
    ///
    ///
    /// Wannan baya kiyaye oda, amma shine *O*(1).
    ///
    /// Dawowar `None` idan `index` ya wuce iyaka.
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Ana cire wani abu daga ko'ina cikin `VecDeque` kuma ya dawo da shi, ya maye gurbinsa da na ƙarshe.
    ///
    ///
    /// Wannan baya kiyaye oda, amma shine *O*(1).
    ///
    /// Dawowar `None` idan `index` ya wuce iyaka.
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Sakawa wani kashi a `index` cikin `VecDeque`, canjawa duk abubuwa da fihirisa fi ko daidai to `index` zuwa baya.
    ///
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Panics
    ///
    /// Panics idan `index` ne mafi girma daga 'VecDeque` ta tsawon
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Matsar da mafi ƙarancin abubuwa a cikin abin ajiye zobe kuma saka abun da aka bayar
        //
        // A mafi len/2, 1 abubuwa za a koma. O(min(n, n-i))
        //
        // Akwai manyan lamura guda uku:
        //  Abubuwan haɗin abubuwa ne
        //      - lamari na musamman lokacin da wutsiya yake 0 Abubuwa ba su da kyau kuma abin da ake sakawa yana cikin ɓangaren wutsiya Abubuwa ba su da rikitarwa kuma sakawa yana cikin sashin kai.
        //
        //
        // Ga kowane ɗayan waɗannan akwai ƙarin lamura biyu:
        //  Saka kusa da wutsiya Saka ya fi kusa da kai
        //
        // Maballin: H, self.head
        //      T, self.tail o, Ingantaccen element I, Saka kashi A, Abubuwan da yakamata ya kasance bayan batun sa M, Yana nuna motsi an motsa
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // mai rikitarwa, saka kusa da wutsiya:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // mai rikitarwa, saka kusa da wutsiya da wutsiya ita ce 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Mun riga mun motsa wutsiya, saboda haka muna kwafin abubuwan `index - 1` kawai.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // mai rikitarwa, saka kusa da kai:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // mara rikitarwa, saka kusa da wutsiya, ɓangaren wutsiya:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // mara rikitarwa, saka kusa da kai, sashin wutsiya:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kwafa abubuwa har zuwa sabon kai
                    self.copy(1, 0, self.head);

                    // kwafa kashi na karshe a cikin fanko a kasan buffer
                    self.copy(0, self.cap() - 1, 1);

                    // matsar da abubuwa daga idx zuwa karshen gaba ba tare da ^ element ba
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // mara rikitarwa, sakawa ya fi kusa da wutsiya, sashin kai, kuma yana kan sifila mara kyau a cikin maɓallin ciki:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kwafa abubuwa har zuwa sabuwar wutsiya
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kwafa kashi na karshe a cikin fanko a kasan buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // mara rikitarwa, saka kusa da wutsiya, sashin kai:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kwafa abubuwa har zuwa sabuwar wutsiya
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kwafa kashi na karshe a cikin fanko a kasan buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // matsar da abubuwa daga idx-1 don kawowa gaba ba tare da ^ element ba
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // mara rikitarwa, saka kusa da kai, sashin kai:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // Wataƙila an canza wutsiya don haka muna buƙatar sake kirgawa
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Ta kawar da dawo da rabi a `index` daga `VecDeque`.
    /// Kowane karshen da ya fi kusa da wurin cirewa za a matsar da shi don sanya sarari, kuma duk abubuwan da abin ya shafa za a tura su zuwa sabon matsayi.
    ///
    /// Dawowar `None` idan `index` ya wuce iyaka.
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Akwai manyan lamura guda uku:
        //  Abubuwan haɗin abubuwa sune abubuwa masu mahimmanci kuma cirewa yana cikin ɓangaren wutsiya Abubuwa basu da matsala kuma cirewa yana cikin ɓangaren kai
        //
        //      - lamari na musamman lokacin da abubuwa ke haɗuwa da fasaha, amma self.head =0
        //
        // Ga kowane ɗayan waɗannan akwai ƙarin lamura biyu:
        //  Saka kusa da wutsiya Saka ya fi kusa da kai
        //
        // Maballin: H, self.head
        //      T, self.tail o, Ingancin kashi x, Sinadarin alama don cirewa R, Yana nuna bangaren da ake cire M, Yana nuna alamar an motsa
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // mai rikitarwa, cire kusa da wutsiya:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // mai rikitarwa, cire kusa da kai:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // mara rikitarwa, cire kusa da wutsiya, ɓangaren wutsiya:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // mara rikitarwa, cire kusa da kai, sashin kai:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // mara rikitarwa, cire kusa da kai, sashin wutsiya:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // ko rashin fahimta, cire kusa da kai, sashin wutsiya:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // zana abubuwa a cikin ɓangaren wutsiya
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Yana hana ambaliyar ruwa.
                    if self.head != 0 {
                        // kwafa kashi na farko zuwa wuri mara kyau
                        self.copy(self.cap() - 1, 0, 1);

                        // matsar da abubuwa a cikin sashin kai baya
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // mara rikitarwa, cire kusa da wutsiya, sashin kai:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // zana abubuwa har zuwa idx
                    self.copy(1, 0, idx);

                    // kwafa kashi na karshe a cikin fanko mara amfani
                    self.copy(0, self.cap() - 1, 1);

                    // matsar da abubuwa daga wutsiya zuwa ƙarshen gaba, ban da na ƙarshe
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Ya raba `VecDeque` zuwa biyu a bayanin da aka bayar.
    ///
    /// Koma wani sabon kasaftawa `VecDeque`.
    /// `self` ya ƙunshi abubuwa `[0, at)`, kuma `VecDeque` da aka dawo yana ƙunshe da abubuwa `[at, len)`.
    ///
    /// Lura cewa damar `self` ba ta canza ba.
    ///
    /// Abubuwan da ke cikin layin 0 shine gaban layi.
    ///
    /// # Panics
    ///
    /// Panics idan `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` qarya a cikin farkon rabin.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // kawai dauki duka rabin na biyu.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` ya ta'allaka ne a rabi na biyu, yana buƙatar haɓaka abubuwan da muka tsallake a farkon rabin.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Tsaftacewa inda ƙarshen wuraren adana bayanai suke
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Matsar da dukkan abubuwan da ke cikin `other` zuwa `self`, suna barin `other` fanko.
    ///
    /// # Panics
    ///
    /// Panics idan sabon adadin abubuwan abubuwa a cikin kansa ya cika `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // mara kyau impl
        self.extend(other.drain(..));
    }

    /// Yana riƙe abubuwa kawai da aka ambata a lokacin magana.
    ///
    /// A wasu kalmomin, cire duk abubuwan `e` kamar `f(&e)` ya dawo ƙarya.
    /// Wannan hanyar tana aiki a wurin, tana ziyartar kowane abu daidai sau daya a cikin tsari na asali, kuma yana kiyaye tsari na abubuwan da aka riƙe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Ainihin tsari na iya zama da amfani don bin sahun waje, kamar fihirisa.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Wannan na iya panic ko zubar da ciki
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Ninka girman ma'auni sau biyu.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Yana gyara `VecDeque` a wuri don `len()` yayi daidai da `new_len`, ko dai ta cire abubuwa masu yawa daga baya ko kuma sanya abubuwan da aka samar ta hanyar kiran `generator` zuwa ta baya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Ya sake tsarawa ma'ajin ciki na wannan alƙawarin saboda haka yanki ne mai haɗuwa, wanda za'a dawo dashi.
    ///
    /// Wannan hanyar ba ta rarrabawa kuma baya canza tsari na abubuwan da aka saka.Yayin da yake dawo da yanki mai canzawa, ana iya amfani da wannan don tsara alƙawari.
    ///
    /// Da zarar ajiyar ciki ta haɗu, hanyoyin [`as_slices`] da [`as_mut_slices`] za su dawo da dukkanin abubuwan da ke cikin `VecDeque` a cikin yanki ɗaya.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Tsara abin da ke cikin wasiyya.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // rarrabe alƙawari
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // rarrabe shi a cikin tsari na baya
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Samun damar canzawa zuwa yanki mai juzu'i.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // yanzu muna iya tabbata cewa `slice` ƙunshi dukkan abubuwa na deque, yayin da har yanzu da ciwon marar sakewa samun `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // akwai isasshen sarari kyauta don kwafin wutsiya a lokaci guda, wannan yana nufin cewa da farko mun juya kan baya, sannan mu kwafe jelar zuwa daidai matsayin.
            //
            //
            // daga: DEFGH .... ABC
            // zuwa: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: A halin yanzu bamuyi la'akari ba .... ABCDEFGH
            // zama mai haɗuwa saboda `head` zai zama `0` a wannan yanayin.
            // Duk da yake wataƙila muna son canza wannan ba ƙaramin abu bane kamar yadda aan wurare suke tsammanin `is_contiguous` yana nufin cewa zamu iya yanka kawai ta amfani da `buf[tail..head]`.
            //
            //

            // akwai isasshen sarari kyauta don kwafa kan a tafi ɗaya, wannan yana nufin cewa da farko za mu karkatar da jelar zuwa gaba, sannan mu kwafa kan zuwa madaidaicin matsayi.
            //
            //
            // daga: FGH .... ABCDE
            // zuwa: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // Kyauta ya fi duka kai da wutsiya ƙanƙanta, wannan yana nufin dole ne a hankali "swap" wutsiya da kai.
            //
            //
            // daga: EFGHI ... ABCD ko HIJK.ABCDEFG
            // zuwa: ABCDEFGHI ... ko ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Babbar matsalar tana kama da wannan GHIJKLM ... ABCDEF, kafin kowane canji ABCDEFM ... GHIJKL, bayan wucewar sau 1 na swaps ABCDEFGHIJM ... KL, canza har sai edge na hagu ya isa shagon temp
                //                  - sannan sake kunna algorithm tare da sabon shagon (smaller) Wani lokaci ana samun shagon temp yayin da edge mai kyau ya kasance a ƙarshen buffer, wannan yana nufin mun buga madaidaiciyar oda tare da san sauyawa!
                //
                // E.g
                // EF..ABCD ABCDEF .., bayan sau hudu kawai muka gama
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Yana juya jerin gwanon `mid` mai hawa biyu zuwa hagu.
    ///
    /// Equivalently,
    /// - Rotates abu `mid` cikin farko matsayi.
    /// - Bayyana abubuwa na `mid` na farko kuma yana tura su zuwa ƙarshen.
    /// - Yana juya wurare `len() - mid` zuwa dama.
    ///
    /// # Panics
    ///
    /// Idan `mid` ya fi `len()` girma.
    /// Lura cewa `mid == len()` yayi _not_ panic kuma juyawa ne babu op.
    ///
    /// # Complexity
    ///
    /// Auki lokaci `*O*(min(mid, len() - mid))` kuma babu ƙarin sarari.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Yana juya jerin gwanon `k` mai ƙare biyu zuwa dama.
    ///
    /// Equivalently,
    /// - Juya abu na farko zuwa matsayin `k`.
    /// - Bayyana abubuwa na `k` na ƙarshe kuma yana tura su zuwa gaba.
    /// - Yana juya wurare `len() - k` zuwa hagu.
    ///
    /// # Panics
    ///
    /// Idan `k` ya fi `len()` girma.
    /// Lura cewa `k == len()` yayi _not_ panic kuma juyawa ne babu op.
    ///
    /// # Complexity
    ///
    /// Auki lokaci `*O*(min(k, len() - k))` kuma babu ƙarin sarari.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // KYAUTA: hanyoyin biyu masu zuwa suna buƙatar adadin juyawa
    // zama kasa da rabin tsawon deque.
    //
    // `wrap_copy` yana buƙatar `min(x, cap() - x) + copy_len <= cap()`, amma fiye da `min` bai fi rabin ƙarfin aiki ba, ba tare da la'akari da x ba, saboda haka yana da kyau a kira a nan saboda muna kira tare da wani abu ƙasa da rabin tsayi, wanda bai taɓa wuce rabin ƙarfin ba.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary ya binciko wannan nau'in `VecDeque` don abun da aka bayar.
    ///
    /// Idan an sami ƙimar to [`Result::Ok`] ya dawo, yana ɗauke da bayanan abubuwan da suka dace.
    /// Idan akwai wasanni da yawa, to za'a iya dawo da kowane ɗayan wasannin.
    /// Idan ba a sami ƙimar ba to [`Result::Err`] ya dawo, yana ɗauke da fihirisa inda za a saka abun da ya dace yayin kiyaye tsari.
    ///
    ///
    /// # Examples
    ///
    /// Ya duba jerin abubuwa hudu.
    /// Na farko an samo shi, tare da ƙayyadadden matsayi;na biyu da na uku ba a same su ba;na huɗu na iya daidaita kowane matsayi a cikin `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Idan kanaso ka saka abu acikin wani nau'ikan `VecDeque`, yayin rike tsari iri:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary yayi binciken wannan nau'in `VecDeque` tare da aikin kwatancen.
    ///
    /// Aikin kwatantawa ya kamata aiwatar da tsari daidai da nau'in tsari na tushen `VecDeque`, dawo da lambar oda wanda ke nuna ko hujjarta ita ce `Less`, `Equal` ko `Greater` fiye da maƙasudin da ake so.
    ///
    ///
    /// Idan an sami ƙimar to [`Result::Ok`] ya dawo, yana ɗauke da bayanan abubuwan da suka dace.Idan akwai wasanni da yawa, to za'a iya dawo da kowane ɗayan wasannin.
    /// Idan ba a sami ƙimar ba to [`Result::Err`] ya dawo, yana ɗauke da fihirisa inda za a saka abun da ya dace yayin kiyaye tsari.
    ///
    /// # Examples
    ///
    /// Ya duba jerin abubuwa hudu.Na farko an samo shi, tare da ƙayyadadden matsayi;na biyu da na uku ba a same su ba;na huɗu na iya daidaita kowane matsayi a cikin `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary yayi binciken wannan nau'in `VecDeque` tare da aikin hakar maɓalli.
    ///
    /// Ya ɗauka cewa an tsara `VecDeque` ta maɓalli, misali tare da [`make_contiguous().sort_by_key()`](#method.make_contiguous) ta amfani da aikin cire maɓallin ɗaya.
    ///
    ///
    /// Idan an sami ƙimar to [`Result::Ok`] ya dawo, yana ɗauke da bayanan abubuwan da suka dace.
    /// Idan akwai wasanni da yawa, to za'a iya dawo da kowane ɗayan wasannin.
    /// Idan ba a sami ƙimar ba to [`Result::Err`] ya dawo, yana ɗauke da fihirisa inda za a saka abun da ya dace yayin kiyaye tsari.
    ///
    /// # Examples
    ///
    /// Yana kallon jerin abubuwa huɗu a cikin wani nau'i-nau'i nau'i-nau'i wanda aka tsara ta abubuwan su na biyu.
    /// Na farko an samo shi, tare da ƙayyadadden matsayi;na biyu da na uku ba a same su ba;na huɗu na iya daidaita kowane matsayi a cikin `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Yana gyara `VecDeque` a wuri domin `len()` yayi daidai da new_len, ko dai ta cire abubuwa masu yawa daga baya ko ta hanyar sanya kwayoyi na `value` zuwa baya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Mayar da bayanan a cikin mahimmin shafi don abin da aka ba da ma'anar ma'ana.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // Girma koyaushe iko ne na 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Lissafa adadin abubuwan da suka rage don karantawa a cikin ma'aji
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // Girma koyaushe iko ne na 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Koyaushe divisible a uku sassan, misali: kai: [a b c|d e f] sauran: [0 1 2 3|4 5] gaban=3, tsakiyar=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Bazai yuwu ayi amfani da Hash::hash_slice akan yankan da aka dawo dasu ta hanyar as_slices ba saboda tsawan su na iya banbanta a wani yanayi iri daya.
        //
        //
        // Hasher kawai ke ba da tabbacin daidaito don daidai saitin kira daidai da hanyoyinta.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Cinye `VecDeque` a cikin gaba-da-baya mai ba da amsa abubuwa ta ƙimar su.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Wannan aikin ya zama daidai da ɗabi'a:
        //
        //      don abu a cikin iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Juya [`Vec<T>`] zuwa [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Wannan yana hana sake rarraba wuri inda zai yiwu, amma yanayin wannan yana da tsauri, kuma zai iya canzawa, don haka bai kamata a dogara da su ba sai dai idan `Vec<T>` ya fito daga `From<VecDeque<T>>` kuma ba'a sake sanya shi ba.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Babu wani kaso na ainihi ga ZST don damuwa game da iyawa, amma `VecDeque` ba zai iya ɗaukar tsawon tsawon kamar `Vec` ba.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Muna buƙatar sake girman idan ƙarfin ba ƙarfin mutum biyu bane, sun yi ƙanƙanta ko ba su da aƙalla sarari ɗaya kyauta.
            // Muna yin hakan yayin da yake cikin `Vec` don haka abubuwan zasu sauka akan panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Juya [`VecDeque<T>`] zuwa [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Wannan baya buƙatar sake kasaftawa, amma yana buƙatar yin motsi na bayanan *O*(*n*) idan madafun madauwari bai kasance a farkon rabon ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Wannan shine *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Wannan yana buƙatar sake tsara bayanai.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}