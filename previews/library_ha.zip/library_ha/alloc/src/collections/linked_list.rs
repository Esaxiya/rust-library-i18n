//! Lissafi mai alaƙa biyu tare da nodes ɗin mallaka.
//!
//! `LinkedList` yana ba da izinin turawa da abubuwan haɓakawa a kowane ƙarshen ƙarshen lokaci.
//!
//! NOTE: Kusan koyaushe yana da kyau a yi amfani da [`Vec`] ko [`VecDeque`] saboda kwantena masu tsararru galibi suna da sauri, sun fi ƙwarewar ƙwaƙwalwa, kuma sun fi amfani da cache ta CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Lissafi mai alaƙa biyu tare da nodes ɗin mallaka.
///
/// `LinkedList` yana ba da izinin turawa da abubuwan haɓakawa a kowane ƙarshen ƙarshen lokaci.
///
/// NOTE: Shi ne kusan ko da yaushe mafi alhẽri ga amfani da `Vec` ko `VecDeque` saboda tsararru-tushen kwantena ne kullum sauri, mafi memory m, da kuma yin amfani CPU cache.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Mai magana akan abubuwan `LinkedList`.
///
/// Wannan `struct` an ƙirƙira shi ta [`LinkedList::iter()`].
/// Duba bayanansa don ƙarin.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Cire a madadin `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Mai maimaita magana mai canzawa akan abubuwan `LinkedList`.
///
/// Wannan `struct` an ƙirƙira shi ta [`LinkedList::iter_mut()`].
/// Duba bayanansa don ƙarin.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Ba * kawai muke da cikakken jerin abubuwan anan ba, nassoshi game da kumburin `element` an gabatar dasu ta hanyar mai magana!Don haka yi hankali lokacin amfani da wannan;hanyoyin da ake kira dole ne su sani cewa za'a iya samun alamun nuna alama zuwa `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Mai maimaita mallakar abubuwa akan `LinkedList`.
///
/// Wannan `struct` an ƙirƙire ta hanyar hanyar [`into_iter`] akan [`LinkedList`] (wanda aka bayar ta `IntoIterator` trait).
/// Duba bayanansa don ƙarin.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// hanyoyin sirri
impl<T> LinkedList<T> {
    /// Yana ƙara kumburin da aka bayar a gaban jerin.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Wannan hanyar tana kulawa kada a ƙirƙiri nassoshi masu canzawa zuwa ɗumbin nodes, don kiyaye ingancin alamun nuni cikin `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Ba ƙirƙirar sababbin nassoshi na (unique!) mai canzawa wanda ke rufe `element` ba.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Cirewa da dawo da kumburi a gaban jerin.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Wannan hanyar tana kulawa kada a ƙirƙiri nassoshi masu canzawa zuwa ɗumbin nodes, don kiyaye ingancin alamun nuni cikin `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Ba ƙirƙirar sababbin nassoshi na (unique!) mai canzawa wanda ke rufe `element` ba.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Yana ƙara kumburin da aka bayar a ƙarshen jerin.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Wannan hanyar tana kulawa kada a ƙirƙiri nassoshi masu canzawa zuwa ɗumbin nodes, don kiyaye ingancin alamun nuni cikin `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Ba ƙirƙirar sababbin nassoshi na (unique!) mai canzawa wanda ke rufe `element` ba.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Cirewa da dawo da kumburi a ƙarshen jerin.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Wannan hanyar tana kulawa kada a ƙirƙiri nassoshi masu canzawa zuwa ɗumbin nodes, don kiyaye ingancin alamun nuni cikin `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Ba ƙirƙirar sababbin nassoshi na (unique!) mai canzawa wanda ke rufe `element` ba.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Yana cire haɗin ƙididdigar da aka ƙayyade daga jerin yanzu.
    ///
    /// Gargaɗi: wannan ba zai bincika cewa kumburin da aka bayar yana cikin jeri na yanzu ba.
    ///
    /// Wannan hanyar tana kulawa kada a ƙirƙiri nassoshi masu canzawa zuwa `element`, don tabbatar da ingancin alamun nuni.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // wannan shine namu yanzu, zamu iya ƙirƙirar &mut.

        // Ba ƙirƙirar sababbin nassoshi na (unique!) mai canzawa wanda ke rufe `element` ba.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // wannan kumburin shine kumburin kai
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // wannan kumburin shine kumburin wutsiya
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Yana rarraba jerin node tsakanin nodes biyu da ke akwai.
    ///
    /// Gargaɗi: wannan ba zai bincika cewa kumburin da aka bayar na mallakar jeri biyu ne ba.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Wannan hanyar tana kulawa kada a ƙirƙiri nassoshi masu canzawa da yawa zuwa duka nodes a lokaci guda, don kiyaye ingancin alamun nuni zuwa cikin `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Ya ware dukkan nodes daga jerin haɗi azaman jerin ƙidodi.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // A tsaga kumburi ne sabon shugaban kumburi daga kashi na biyu
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Gyara ptr na sashi na biyu
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Rabawar kumburi ita ce sabuwar kumburin juzu'i na ɓangaren farko kuma ya mallaki kan sashi na biyu.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Gyara ptr wutsiya na sashi na farko
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Esirƙira komai na `LinkedList<T>`.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Esirƙira komai na `LinkedList`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Matsar da dukkan abubuwa daga `other` zuwa ƙarshen jerin.
    ///
    /// Wannan yana sake amfani da dukkanin node daga `other` kuma yana tura su cikin `self`.
    /// Bayan wannan aikin, `other` ya zama fanko.
    ///
    /// Wannan aikin yakamata lissafa a cikin *O*(1) lokaci da *O*(1) memori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` Yana da kyau a nan saboda muna da damar keɓewa ga duka jerin sunayen.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Motsa duk abubuwa daga `other` zuwa za a fara daga jerin.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` Yana da kyau a nan saboda muna da damar keɓewa ga duka jerin sunayen.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Yana bayar da mai gabatarwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Yana bayar da mai gabatarwa gaba tare da nassoshi masu canzawa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Yana ba da siginan kwamfuta a gaba.
    ///
    /// Alamar tana nunawa ga "ghost" ba kayan aiki ba idan jerin komai.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Yana bayar da siginan siginan kwamfuta tare da ayyukan edita a gaba.
    ///
    /// Alamar tana nunawa ga "ghost" ba kayan aiki ba idan jerin komai.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Yana ba da siginan rubutu a ɓangaren baya.
    ///
    /// Alamar tana nunawa ga "ghost" ba kayan aiki ba idan jerin komai.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Yana samar da siginan kwamfuta tare da ayyukan gyara a ɓangaren baya.
    ///
    /// Alamar tana nunawa ga "ghost" ba kayan aiki ba idan jerin komai.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Yana dawowa `true` idan `LinkedList` fanko ne.
    ///
    /// Wannan aikin yakamata yayi lissafi a cikin *O*(1) lokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Ya dawo da tsawon `LinkedList`.
    ///
    /// Wannan aikin yakamata yayi lissafi a cikin *O*(1) lokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Cire dukkan abubuwa daga `LinkedList`.
    ///
    /// Wannan aikin ya kamata yayi lissafi a cikin *O*(*n*) lokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Yana dawo da `true` idan `LinkedList` ya ƙunshi abu daidai yake da ƙimar da aka bayar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Samar da wani tunani da gaban kashi, ko `None` idan jerin ne komai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Yana bayar da ambaton maye gurbin abu na gaba, ko `None` idan jerin komai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Yana bayar da ishara zuwa ɓangaren baya, ko `None` idan jerin komai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Yana bayar da ambaton maye gurbin abu na baya, ko `None` idan jerin komai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Yana daɗa farko a jerin.
    ///
    /// Wannan aikin yakamata yayi lissafi a cikin *O*(1) lokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Ta kawar da farko rabi da kuma dawo da shi, ko `None` idan jerin ne komai.
    ///
    ///
    /// Wannan aikin yakamata yayi lissafi a cikin *O*(1) lokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Endsara wani ɓangare zuwa ƙarshen jerin.
    ///
    /// Wannan aikin yakamata yayi lissafi a cikin *O*(1) lokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Cire abu na ƙarshe daga jeri ya dawo dashi, ko `None` idan babu komai.
    ///
    ///
    /// Wannan aikin yakamata yayi lissafi a cikin *O*(1) lokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Ya kasu jeri kashi biyu a inda aka nuna su.
    /// Ya dawo da komai bayan bayanan da aka bayar, gami da bayanan.
    ///
    /// Wannan aikin ya kamata yayi lissafi a cikin *O*(*n*) lokaci.
    ///
    /// # Panics
    ///
    /// Panics idan `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // A ƙasa, muna karkata zuwa ga mahaɗar 'i-1`th, ko dai daga farawa ko ƙarshen, gwargwadon abin da zai fi sauri.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // maimakon tsallakewa ta amfani da .skip() (wanda ke haifar da sabon tsari), muna tsallake da hannu don mu sami damar zuwa filin kai tsaye ba tare da dogaro da aiwatarwar cikakken Tsallake ba
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // Zai fi kyau farawa daga ƙarshe
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Cire maɓallin a layin da aka bayar kuma ya dawo da shi.
    ///
    /// Wannan aikin ya kamata yayi lissafi a cikin *O*(*n*) lokaci.
    ///
    /// # Panics
    /// Panics idan a>=bashi
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // A ƙasa, muna daidaita zuwa ga kumburi a cikin bayanan da aka bayar, ko dai daga farawa ko ƙarshen, gwargwadon wanda zai fi sauri.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Irƙira mai magana wanda ke amfani da ƙulli don ƙayyade idan ya kamata a cire wani abu.
    ///
    /// Idan ƙulli ya dawo na gaskiya, to an cire abun kuma ya ba da amfani.
    /// Idan ƙulli ya dawo na ƙarya, asalin zai kasance a cikin jeren kuma baza a bayar dashi ta mai magana ba.
    ///
    /// Lura cewa `drain_filter` yana baka damar canza kowane abu a cikin rufe matatar, ba tare da la'akari da ko ka zabi kiyayewa ko cire shi ba.
    ///
    ///
    /// # Examples
    ///
    /// Tsaga jerin a cikin maraice da rashin daidaito, sake amfani da jerin asali:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // kauce wa lamurran aro.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Ci gaba da madauki ɗaya da muke yi a ƙasa.Wannan yana gudana ne kawai lokacin da mai lalata ya firgita.
                // Idan wani panics wannan zai zubar.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Buƙatar rayuwa mara izini don samun 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Buƙatar rayuwa mara izini don samun 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Buƙatar rayuwa mara izini don samun 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Buƙatar rayuwa mara izini don samun 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Maimaita siginan kwamfuta akan `LinkedList`.
///
/// `Cursor` yana kama da maimaitawa, sai dai kawai yana iya neman gaba da gaba.
///
/// Masu siginan rubutu koyaushe suna hutawa tsakanin abubuwa biyu a cikin jerin, kuma suna nuna alama ta hanyar madauwari.
/// Don saukar da wannan, akwai wani nau'in "ghost" wanda ba shi da asali wanda yake samarda `None` tsakanin kai da wutsiyar jerin.
///
///
/// Lokacin da aka ƙirƙira su, masu siginan rubutu suna farawa daga gaban jerin, ko kuma abubuwan da basa cikin "ghost" idan babu komai a lissafin.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Mai siginan kwamfuta sama da `LinkedList` tare da ayyukan gyara.
///
/// `Cursor` kamar mai yin magana ne, sai dai kawai yana iya neman gaba-da-gaba, kuma zai iya amintar da jerin yayin amsar.
/// Wannan saboda rayuwar rayuwar abubuwan da take bayarwa suna da nasaba da rayuwarta, maimakon kawai jerin abubuwan.
/// Wannan yana nufin siginan sigari ba za su iya ba da abubuwa da yawa lokaci ɗaya ba.
///
/// Masu siginan rubutu koyaushe suna hutawa tsakanin abubuwa biyu a cikin jerin, kuma suna nuna alama ta hanyar madauwari.
/// Don saukar da wannan, akwai wani nau'in "ghost" wanda ba shi da asali wanda yake samarda `None` tsakanin kai da wutsiyar jerin.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Yana dawo da jadawalin matsayin siginan sigar a cikin `LinkedList`.
    ///
    /// Wannan ya dawo `None` idan mai siginan kwamfuta a halin yanzu yana nunawa ga "ghost" wanda ba shi da asali.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Matsar da siginan kwamfuta zuwa kashi na gaba na `LinkedList`.
    ///
    /// Idan sigar sigar tana nunawa ga "ghost" wanda ba shi da asali to wannan zai matsar da shi zuwa farkon abu na `LinkedList`.
    /// Idan yana nuni zuwa kashi na karshe na `LinkedList` to wannan zai matsar dashi zuwa maras sinadarin "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Ba mu da wani abu na yanzu;mai siginan kwamfuta yana zaune a farkon farawa Abu na gaba ya zama shugaban jerin
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Muna da abin da ya gabata, don haka bari mu tafi zuwa na gaba
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Matsar da siginan kwamfuta zuwa abin da ya gabata na `LinkedList`.
    ///
    /// Idan sigar siginar tana nunawa ga "ghost" wanda ba shi da asali to wannan zai matsar da shi zuwa kashi na ƙarshe na `LinkedList`.
    /// Idan yana nuna farkon kashi na `LinkedList` to wannan zai motsa shi zuwa "ghost" wanda ba shi da asali.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Babu halin yanzuMuna a farkon jerin.Ba da Amfani Babu kuma tsalle zuwa ƙarshen.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Da prev.Yi shi da kyau sannan ka tafi abin da ya gabata.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Ya dawo da ma'anar abin da siginan siginar ke nunawa a halin yanzu.
    ///
    /// Wannan ya dawo `None` idan mai siginan kwamfuta a halin yanzu yana nunawa ga "ghost" wanda ba shi da asali.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Yana dawowa da ma'ana ta gaba.
    ///
    /// Idan sigar sigar tana nunawa ga "ghost" wanda ba shi da asali to wannan ya dawo farkon kashi na `LinkedList`.
    /// Idan yana nuni zuwa kashi na karshe na `LinkedList` to wannan ya dawo `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Yana dawowa da ma'anar abin da ya gabata.
    ///
    /// Idan sigar sigar tana nunawa ga "ghost" wanda ba shi da asali to wannan ya dawo da kashi na ƙarshe na `LinkedList`.
    /// Idan yana nuna farkon kashi na `LinkedList` to wannan ya dawo `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Yana dawo da jadawalin matsayin siginan sigar a cikin `LinkedList`.
    ///
    /// Wannan ya dawo `None` idan mai siginan kwamfuta a halin yanzu yana nunawa ga "ghost" wanda ba shi da asali.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Matsar da siginan kwamfuta zuwa kashi na gaba na `LinkedList`.
    ///
    /// Idan sigar sigar tana nunawa ga "ghost" wanda ba shi da asali to wannan zai matsar da shi zuwa farkon abu na `LinkedList`.
    /// Idan yana nuni zuwa kashi na karshe na `LinkedList` to wannan zai matsar dashi zuwa maras sinadarin "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Ba mu da wani abu na yanzu;mai siginan kwamfuta yana zaune a farkon farawa Abu na gaba ya zama shugaban jerin
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Muna da abin da ya gabata, don haka bari mu tafi zuwa na gaba
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Matsar da siginan kwamfuta zuwa abin da ya gabata na `LinkedList`.
    ///
    /// Idan sigar siginar tana nunawa ga "ghost" wanda ba shi da asali to wannan zai matsar da shi zuwa kashi na ƙarshe na `LinkedList`.
    /// Idan yana nuna farkon kashi na `LinkedList` to wannan zai motsa shi zuwa "ghost" wanda ba shi da asali.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Babu halin yanzuMuna a farkon jerin.Ba da Amfani Babu kuma tsalle zuwa ƙarshen.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Da prev.Yi shi da kyau sannan ka tafi abin da ya gabata.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Ya dawo da ma'anar abin da siginan siginar ke nunawa a halin yanzu.
    ///
    /// Wannan ya dawo `None` idan mai siginan kwamfuta a halin yanzu yana nunawa ga "ghost" wanda ba shi da asali.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Yana dawowa da ma'ana ta gaba.
    ///
    /// Idan sigar sigar tana nunawa ga "ghost" wanda ba shi da asali to wannan ya dawo farkon kashi na `LinkedList`.
    /// Idan yana nuni zuwa kashi na karshe na `LinkedList` to wannan ya dawo `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Yana dawowa da ma'anar abin da ya gabata.
    ///
    /// Idan sigar sigar tana nunawa ga "ghost" wanda ba shi da asali to wannan ya dawo da kashi na ƙarshe na `LinkedList`.
    /// Idan yana nuna farkon kashi na `LinkedList` to wannan ya dawo `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Ya dawo da siginan karatun-kawai wanda yake nuni zuwa ga kashi na yanzu.
    ///
    /// Rayuwar `Cursor` da aka dawo tana ɗaure da ta `CursorMut`, wanda ke nufin ba zai iya raye `CursorMut` ba kuma cewa `CursorMut` na daskarewa tsawon rayuwar `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Yanzu ayyukan gyaran jerin

impl<'a, T> CursorMut<'a, T> {
    /// Abubuwan da ke sakawa a cikin `LinkedList` bayan na yanzu.
    ///
    /// Idan sigar siginar tana nunawa akan abubuwan da ba na element ba na "ghost" to ana saka sabon sinadarin a gaban `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Lissafin da ba shi da asali na "ghost" ya canza.
                self.index = self.list.len;
            }
        }
    }

    /// Abun da yake sakawa sabon abu a cikin `LinkedList` kafin na yanzu.
    ///
    /// Idan sigar siginar tana nunawa akan "ghost" wanda ba shi da asali sai a saka sabon abu a ƙarshen `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Cire kayan aikin yanzu daga `LinkedList`.
    ///
    /// Abubuwan da aka cire an dawo dashi, kuma maƙallan ya motsa don nunawa zuwa kashi na gaba a cikin `LinkedList`.
    ///
    ///
    /// Idan siginan yana nunawa a halin yanzu ba "ghost" ba element to babu wani abu da aka cire kuma `None` ya dawo.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Cire maɓallin yanzu daga `LinkedList` ba tare da rarraba raɗin jerin ba.
    ///
    /// A kumburi cewa an cire an koma a matsayin sabon `LinkedList` dauke da kawai wannan kumburi.
    /// Ana motsa siginan don nunawa zuwa kashi na gaba a cikin `LinkedList` na yanzu.
    ///
    /// Idan siginan yana nunawa a halin yanzu ba "ghost" ba element to babu wani abu da aka cire kuma `None` ya dawo.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Abubuwan da ke saka abubuwa daga `LinkedList` da aka bayar bayan na yanzu.
    ///
    /// Idan siginan yana nunawa akan abubuwan da ba na element na "ghost" ba to ana saka sabbin abubuwa a farkon `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Lissafin da ba shi da asali na "ghost" ya canza.
                self.index = self.list.len;
            }
        }
    }

    /// Saka abubuwan daga `LinkedList` da aka bayar kafin na yanzu.
    ///
    /// Idan siginan yana nunawa akan abubuwan da ba na element na "ghost" ba to ana saka sabbin abubuwa a ƙarshen `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Ya kasu jeri kashi biyu bayan abu na yanzu.
    /// Wannan zai dawo da sabon jerin abubuwa wanda ya kunshi komai bayan sigar sigar, tare da asalin asalin abubuwan da suke riƙe.
    ///
    ///
    /// Idan siginan yana nunawa a cikin maras amfani na "ghost" to duk abubuwan da ke cikin `LinkedList` suna motsawa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Bayanin ba-element na "ghost" ya canza zuwa 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Ya kasu jeri kashi biyu kafin abu na yanzu.
    /// Wannan zai dawo da sabon jerin abubuwa wanda ya kunshi komai a gaban mai siginan kwamfuta, tare da ainihin jerin abubuwan da suke riƙe komai bayan haka.
    ///
    ///
    /// Idan siginan yana nunawa a cikin maras amfani na "ghost" to duk abubuwan da ke cikin `LinkedList` suna motsawa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Wani mai gabatarwa ya kirkira ta hanyar kiran `drain_filter` akan LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` yana da kyau tare da ambaton sunayen `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ya cinye jerin a cikin kwatankwacin samar da abubuwa masu ƙima.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Tabbatar cewa `LinkedList` da masu karanta shi kawai suna da ma'ana a cikin sigogin nau'in su.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}