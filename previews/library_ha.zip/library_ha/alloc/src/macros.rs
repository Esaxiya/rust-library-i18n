/// Creatirƙira [`Vec`] mai ɗauke da muhawara.
///
/// `vec!` ba da damar ``Vec`s don bayyana tare da daidaitawa iri ɗaya kamar maganganun tsararru.
/// Akwai nau'i biyu na wannan macro:
///
/// - Createirƙira [`Vec`] wanda ke ƙunshe da jerin abubuwan da aka bayar:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Createirƙira [`Vec`] daga wani abu da girman da aka ba shi:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Note cewa sabanin tsararru maganganu wannan ginin kalma tana goyon bayan duk abubuwa da aiwatar da [`Clone`] da yawan abubuwa ba dole ba ne ya zama m.
///
/// Wannan zai yi amfani da `clone` don yin kwafin magana, don haka mutum ya yi hankali da amfani da wannan tare da nau'ikan da ke da aiwatar da `Clone` mara ƙima.
/// Misali, `vec![Rc::new(1);5] 'zai haifar da wani vector na biyar nassoshi guda boxed lamba darajar, ba biyar nassoshi nuna da kansa boxed integers.
///
///
/// Har ila yau, bayanin kula cewa `vec![expr; 0]` ne a yarda, da kuma samar da wani komai a vector.
/// Wannan har yanzu zai kimanta `expr`, duk da haka, kuma nan da nan ya sauke darajar da aka samu, saboda haka ku kula da illolin.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): tare da cfg(test) da muhimmi `[T]::into_vec` hanya, wanda ake bukata domin wannan Macro definition, ba samuwa.
// Madadin haka amfani da aikin `slice::into_vec` wanda kawai ake samu tare da cfg(test) NB duba tsarin slice::hack a cikin slice.rs don ƙarin bayani
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Irƙira `String` ta amfani da tsaka-tsakin maganganun lokacin gudu.
///
/// Hujja ta farko da `format!` ta karɓa itace zaren tsari.Wannan dole ne ya zama zaren zahiri.Stringarfin layin tsarawa yana cikin ƙunshin bayanan '{}'.
///
/// Ƙarin sigogi ya wuce zuwa `format!` maye gurbin `{}` s a cikin tsara kirtani a cikin tsari ba, sai dai idan suna ko positional sigogi an yi amfani da;duba [`std::fmt`] don ƙarin bayani.
///
///
/// Amfani gama gari ga `format!` shine haɗawa da haɗa igiyoyin kirtani.
/// Ana amfani da wannan yarjejeniya tare da [`print!`] da [`write!`] macros, ya danganta da makashin da aka nufa.
///
/// Don canza ƙima ɗaya zuwa kirtani, yi amfani da hanyar [`to_string`].Wannan zai yi amfani da tsarin trait Z0trax Z0trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics idan tsarin aiwatar da trait ya dawo da kuskure.
/// Wannan yana nuna aiwatarwa mara kyau tunda `fmt::Write for String` baya dawo da kuskure kansa.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// ASarfafa kumburin AST zuwa wata magana don inganta ganewar asali a cikin yanayin tsari.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}