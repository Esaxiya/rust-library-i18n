//! Yanke igiyar Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Nau'in `&str` shine ɗayan manyan nau'ikan maɗaura biyu, ɗayan kuma shine `String`.
//! Ba kamar takwararta ta `String` ba, an aro abubuwan da ke ciki.
//!
//! # Amfani na Asali
//!
//! Bayanin asali na zaren `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Anan mun bayyana mahimmin layi, wanda aka fi sani da yanki kirtani.
//! Lissafin zaren suna da tsayayyen rayuwa, wanda ke nufin zaren `hello_world` ya tabbata cewa zai iya aiki tsawon lokacin duk shirin.
//!
//! Zamu iya bayyane sararin rayuwar 'hello_world' kuma:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Yawancin amfani da wannan rukunin ana amfani dasu ne kawai a cikin jeren gwajin.
// Ya fi tsabta a kashe kashe kashedin da ba a amfani da shi fiye da gyara su.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` a cikin `Concat<str>` ba ma'ana a nan.
/// Wannan nau'in siga na trait ya wanzu ne kawai don kunna wani impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // madaukai tare da madaidaitan madaidaiciya suna aiki da sauri da sauri ƙware da shari'o'in tare da ƙananan tsayin mai raba
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // sabani ba-sifili girman faduwa
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Gyara shiga aiwatar da aiki duka biyu Vec<T>(T: Kwafa) da kuma vering na ciki vec a yanzu (2018-05-13) akwai kwaro mai nau'in rubutu da keɓancewa (duba batun #36262) Saboda wannan dalili SliceConcat<T>ba kwararre bane ga T: Kwafa da SliceConcat<str>ne kawai mai amfani da wannan aikin.
// An barshi a wuri don lokacin da aka gyara hakan.
//
// iyakoki don Kirtani-shiga sune S: B rance<str>kuma don Vec-join Borrow <[T]> [T] da str duka suna impl AsRef <[T]> ga wasu T
// => s.borrow().as_ref() kuma koyaushe muna da yanka
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // yanki na farko shine kadai ba tare da mai raba shi ba
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // lasafta cikakken jimillar abin da aka haɗa Vec idan lissafin `len` ya cika, za mu panic da tuni ƙwaƙwalwarmu ta ƙare kuma sauran ayyukan suna buƙatar duka Vec da aka riga aka keɓe don aminci
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // shirya baiti wanda ba a san shi ba
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kwafin mai raba kwafin da kuma yanka ba tare da haddi ba binciken samar da madaukai tare da hardcoded offsets ga kananan SEPARATOR ci gaba mai girma yiwu (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Implementationaƙarin aiwatar da bashi na iya dawo da yanka daban don lissafin tsayi da ainihin kwafin.
        //
        // Tabbatar ba mu bijirar uninitialized bytes zuwa ga mai kiran.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Hanyoyi don yanke kirtani.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Sabobincike `Box<str>` zuwa cikin `Box<[u8]>` ba tare da yin kwafa ko rarrabawa ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Yana maye gurbin duk matakan samfurin tare da wani zaren.
    ///
    /// `replace` ƙirƙiri sabon [`String`], kuma yana kwafin bayanan daga wannan igiyar yanki a ciki.
    /// Yayin yin hakan, yana ƙoƙari don nemo ashana na tsari.
    /// Idan ta sami wani, ya maye gurbinsu da yanki kirtani mai sauyawa.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Lokacin da samfurin bai daidaita ba:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Yana maye gurbin wasannin N na farko na tsari tare da wani zaren.
    ///
    /// `replacen` ƙirƙiri sabon [`String`], kuma yana kwafin bayanan daga wannan igiyar yanki a ciki.
    /// Yayin yin hakan, yana ƙoƙari don nemo ashana na tsari.
    /// Idan ta sami wani, zai maye gurbinsu da wani yanki na canzawa a mafi yawan lokutan `count`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Lokacin da samfurin bai daidaita ba:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Fatan rage lokutan sake kasaftawa
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ya dawo da ƙaramar ƙaramar kwatankwacin wannan yanki kirtani, a matsayin sabon [`String`].
    ///
    /// 'Lowercase' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `Lowercase`.
    ///
    /// Tunda wasu haruffa na iya faɗaɗa cikin haruffa da yawa yayin canza shari'ar, wannan aikin ya dawo da [`String`] maimakon gyara sigogin a cikin wuri.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Misali mai ban tsoro, tare da sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // amma a ƙarshen kalma, it's ne, ba σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Ba a canza harsuna ba tare da harka ba:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ taswira zuwa σ, sai dai a ƙarshen kalma inda aka zana taswira zuwa ς.
                // Wannan shine kawai (contextual) mai sharadi amma taswira mai zaman kanta a cikin `SpecialCasing.txt`, don haka sanya lambar ta da shi maimakon samun tsarin "condition" na yau da kullun.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // don ma'anar `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Ya dawo da babban harafin kwatankwacin wannan yanki, a matsayin sabon [`String`].
    ///
    /// 'Uppercase' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `Uppercase`.
    ///
    /// Tunda wasu haruffa na iya faɗaɗa cikin haruffa da yawa yayin canza shari'ar, wannan aikin ya dawo da [`String`] maimakon gyara sigogin a cikin wuri.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Ba a canza rubutun ba tare da harka ba:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Hali ɗaya na iya zama da yawa:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Sabobincike [`Box<str>`] zuwa cikin [`String`] ba tare da yin kwafa ko rarrabawa ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Halicci sabon [`String`] ta maimaita wani layi `n` sau.
    ///
    /// # Panics
    ///
    /// Wannan aikin zai panic idan ƙarfin zai cika.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic bisa ambaliya:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Ya dawo da kwafin wannan kirtani inda aka tsara kowane harafi zuwa ga babban matsayin sa na ASCII.
    ///
    ///
    /// Haruffan ASCII 'a' zuwa 'z' an tsara su zuwa 'A' zuwa 'Z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don ƙara girman darajar a wuri, yi amfani da [`make_ascii_uppercase`].
    ///
    /// Zuwa manyan haruffan ASCII ban da haruffan wadanda ba ASCII ba, yi amfani da [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() yana kiyaye UTF-8 mara canzawa.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Ya dawo da kwafin wannan layin inda aka tsara kowane harafi zuwa ga daidaitaccen ƙaramin rubutun ASCII.
    ///
    ///
    /// Haruffan ASCII 'A' zuwa 'Z' an tsara su zuwa 'a' zuwa 'z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don Ƙaramin baki da darajar a-wuri, amfani da [`make_ascii_lowercase`].
    ///
    /// Don ƙaramin haruffa ASCII ban da haruffan da ba ASCII ba, yi amfani da [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() yana kiyaye UTF-8 mara canzawa.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Yana canza yanki baiti zuwa akwatin kirtani ba tare da bincika cewa kirtani ya ƙunshi ingantaccen UTF-8 ba.
///
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}