//! Abubuwan raba APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Waɗannan su ne alamun sihiri don kiran mai ba da duniya.rustc yana haifar da su don kiran `__rg_alloc` da dai sauransu.
    // idan akwai sifa ta `#[global_allocator]` (lambar da ke faɗaɗa wannan sifa ta macro tana haifar da waɗannan ayyukan), ko kuma kiran tsoffin aiwatarwa a cikin libstd (`__rdl_alloc` da dai sauransu.)
    //
    // a cikin `library/std/src/alloc.rs`) in ba haka ba.
    // rustc fork na LLVM kuma shari'o'in musamman ne waɗannan sunaye masu aiki don samun damar inganta su kamar `malloc`, `realloc`, da `free`, bi da bi.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Mai rarraba ƙwaƙwalwar duniya.
///
/// Wannan nau'in yana aiwatar da [`Allocator`] trait ta hanyar tura kira zuwa ga mai rijista mai rijista tare da sifar `#[global_allocator]` idan akwai ɗaya, ko kuma tsoho na `std` crate.
///
///
/// Note: yayin da wannan nau'in ba shi da tabbas, ana iya samun damar ayyukan da yake bayarwa ta hanyar [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Raba memorywa memorywalwar ajiya tare da mai rarraba duniya.
///
/// Wannan aikin yana cigaba da kira zuwa ga hanyar [`GlobalAlloc::alloc`] na mai rabon rajista tare da sifaren `#[global_allocator]` idan akwai ɗaya, ko tsoho na `std` crate.
///
///
/// Wannan aikin ana sa ran raguwa saboda yarda da hanyar `alloc` na nau'in [`Global`] lokacin da ita da [`Allocator`] trait suka daidaita.
///
/// # Safety
///
/// Duba [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Share mahimmin tare da mai rarraba duniya.
///
/// Wannan aikin yana cigaba da kira zuwa ga hanyar [`GlobalAlloc::dealloc`] na mai rabon rajista tare da sifaren `#[global_allocator]` idan akwai ɗaya, ko tsoho na `std` crate.
///
///
/// Wannan aikin ana sa ran raguwa saboda yarda da hanyar `dealloc` na nau'in [`Global`] lokacin da ita da [`Allocator`] trait suka daidaita.
///
/// # Safety
///
/// Duba [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Sake saita ƙwaƙwalwar ajiya tare da mai rarraba duniya.
///
/// Wannan aikin yana cigaba da kira zuwa ga hanyar [`GlobalAlloc::realloc`] na mai rabon rajista tare da sifaren `#[global_allocator]` idan akwai ɗaya, ko tsoho na `std` crate.
///
///
/// Wannan aikin ana sa ran raguwa saboda yarda da hanyar `realloc` na nau'in [`Global`] lokacin da ita da [`Allocator`] trait suka daidaita.
///
/// # Safety
///
/// Duba [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Sanya ƙananan ƙwaƙwalwar ajiya tare da mai ba da duniya.
///
/// Wannan aikin yana cigaba da kira zuwa ga hanyar [`GlobalAlloc::alloc_zeroed`] na mai rabon rajista tare da sifaren `#[global_allocator]` idan akwai ɗaya, ko tsoho na `std` crate.
///
///
/// Wannan aikin ana sa ran raguwa saboda yarda da hanyar `alloc_zeroed` na nau'in [`Global`] lokacin da ita da [`Allocator`] trait suka daidaita.
///
/// # Safety
///
/// Duba [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // KYAUTA: `layout` ba sifili bane a girma,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // KYAUTA: Yayi daidai da `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // KYAUTA: `new_size` ba sifili bane kamar yadda `old_size` ya fi girma ko daidaita da `new_size`
            // kamar yadda ake bukata ta yanayin aminci.Wasu sharuɗɗan dole ne mai kiran ya kiyaye su
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` tabbas ana dubawa don `new_size >= old_layout.size()` ko wani abu makamancin haka.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KYAUTA: saboda `new_layout.size()` dole ne ya zama ya fi girma ko daidaita da `old_size`,
            // duka tsoffin da sabon rabewar ƙwaƙwalwar ajiya suna aiki don karantawa kuma yayi rubutu don `old_size` bytes.
            // Hakanan, saboda ba a raba tsohuwar rarrabuwa ba, ba zai iya rufe `new_ptr` ba.
            // Don haka, kira zuwa `copy_nonoverlapping` yana cikin aminci.
            // Dole ne mai kiran ya kiyaye yarjejeniyar aminci ga `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // KYAUTA: `layout` ba sifili bane a girma,
            // wasu sharuɗɗa dole ne mai kiran ya kiyaye su
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KYAUTA: duk sharadin dole ne mai kiran ya kiyaye shi
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KYAUTA: duk sharadin dole ne mai kiran ya kiyaye shi
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // KYAUTA: dole ne mai kiran ya kiyaye sharuɗɗa
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // KYAUTA: `new_size` ba sifili bane.Wasu sharuɗɗan dole ne mai kiran ya kiyaye su
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` tabbas ana dubawa don `new_size <= old_layout.size()` ko wani abu makamancin haka.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KYAUTA: saboda `new_size` dole ne ya zama ƙasa da ko daidaita da `old_layout.size()`,
            // duka tsoffin da sabon rabewar ƙwaƙwalwar ajiya suna aiki don karantawa kuma yayi rubutu don `new_size` bytes.
            // Hakanan, saboda ba a raba tsohuwar rarrabuwa ba, ba zai iya rufe `new_ptr` ba.
            // Don haka, kira zuwa `copy_nonoverlapping` yana cikin aminci.
            // Dole ne mai kiran ya kiyaye yarjejeniyar aminci ga `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Mai rarrabawa don alamomi na musamman.
// Dole ne wannan aikin ya kwance.Idan yayi, MIR codegen zaiyi kasa.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Wannan sa hannu ya zama daidai yake da `Box`, in ba haka ba ICE za ta faru.
// Lokacin da aka ƙara ƙarin ma'auni zuwa `Box` (kamar `A: Allocator`), dole ne a ƙara wannan a nan kuma.
// Misali idan aka canza `Box` zuwa `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, dole ne a canza wannan aikin zuwa `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` shima.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Mai kula da kuskuren kasafi

extern "Rust" {
    // Wannan alama ce ta sihiri don kiran mai sarrafa kuskuren duniya.
    // rustc ya samar da shi don kiran `__rg_oom` idan akwai `#[alloc_error_handler]`, ko kuma kiran tsoffin aiwatarwa da ke ƙasa da (`__rdl_oom`) in ba haka ba.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Abort kan kuskuren rabon ƙwaƙwalwar ko gazawar.
///
/// Masu kiran ƙwaƙwalwar ajiyar APIs da ke son zubar da lissafi saboda kuskuren rabewa ana ƙarfafa su kira wannan aikin, maimakon kiran kai tsaye `panic!` ko makamancin haka.
///
///
/// Tsohuwar ɗabi'ar wannan aikin ita ce a buga saƙo zuwa daidaitaccen kuskure kuma a kawar da aikin.
/// Ana iya maye gurbinsa tare da [`set_alloc_error_hook`] da [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Don raba gwajin `std::alloc::handle_alloc_error` ana iya amfani dashi kai tsaye.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // kira ta hanyar `__rust_alloc_error_handler` da aka kirkira

    // idan babu `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // idan akwai `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Sanya kwafin kwayoyi a cikin wajan da aka keɓance, ƙwaƙwalwar ajiya.
/// Amfani da `Box::clone` da `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Bayan an sanya *farko* na iya bawa mai haɓaka damar ƙirƙirar ƙwanƙwasa ƙimar a cikin-wuri, ƙetare gida da motsawa.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Koyaushe za mu iya yin kwafa a wuri, ba tare da taɓa haɗa da ƙimar gida ba.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}