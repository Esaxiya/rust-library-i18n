//! A kuzari-sized view cikin wani contiguous jerin, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Yanka ne a view cikin wani gungu na memory wakilta a matsayin mai Pointer kuma a tsawon.
//!
//! ```
//! // yankan Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coercing wani tsararru zuwa wani yanki
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Yankewa ko dai za'a iya canza su ko kuma za'a raba su.
//! Nau'in yanki da aka raba shine `&[T]`, yayin da nau'in yanki da za'a iya canzawa shine `&mut [T]`, inda `T` ke wakiltar nau'in nau'in.
//! Alal misali, za ka iya mutate da block na memory cewa wani mutable yanki na nuna:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ga wasu abubuwan da wannan kundin ya ƙunsa:
//!
//! ## Structs
//!
//! Akwai hanyoyi da yawa waɗanda ke da amfani don yanka, kamar [`Iter`], wanda ke wakiltar maimaitawa akan yanki.
//!
//! ## Trait Implementations
//!
//! Akwai aiwatarwa da yawa na traits gama-gari don yanka.Wasu misalai sun hada da:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], don yanka wanda nau'ikan nau'ikan sa shine [`Eq`] ko [`Ord`].
//! * [`Hash`] - don yanka wanda nau'ikan nau'ikan sa shine [`Hash`].
//!
//! ## Iteration
//!
//! Yankan suna aiwatar da `IntoIterator`.Mai magana yana ba da bayanai game da abubuwan yanki.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Yankin da ke canzawa yana ba da nassoshi masu canzawa zuwa abubuwan:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Wannan mai gabatarwar yana samarda bayanai da za'a iya canzawa game da abubuwan yankan, don haka yayin da nau'ikan nau'ikan yanki shine `i32`, nau'ikan nau'in maimaitawar shine `&mut i32`.
//!
//!
//! * [`.iter`] kuma [`.iter_mut`] sune bayyananniyar hanyoyi don dawo da masu amfani dasu.
//! * Methodsarin hanyoyin da suke dawo da masu sauyawa sune [`.split`], [`.splitn`], [`.chunks`], [`.windows`] da ƙari.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Yawancin amfani da wannan rukunin ana amfani dasu ne kawai a cikin jeren gwajin.
// Ya fi tsabta a kashe kashe kashedin da ba a amfani da shi fiye da gyara su.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Basic tsawo hanyoyin
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) da ake bukata domin aiwatar da `vec!` Macro a lokacin gwajin NB, ganin `hack` module a cikin wannan fayil don ƙarin bayani.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) da ake buƙata don aiwatar da `Vec::clone` yayin gwajin NB, duba ƙirar `hack` a cikin wannan fayil ɗin don ƙarin bayani.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Tare da cfg(test) `impl [T]` ba samuwa, wadannan uku ayyuka ne a zahiri hanyoyin da suke a `impl [T]` amma ba a `core::slice::SliceExt`, muna bukatar mu bayar da wadannan ayyuka na `test_permutations` gwajin
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Bai kamata mu ƙara sifa ta cikin layi ba saboda wannan ana amfani da shi a cikin `vec!` macro galibi kuma yana haifar da komar da turare.
    // Duba #71204 don tattaunawa da sakamakon turare.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // abubuwa da aka yiwa alama an fara su a cikin madauki da ke ƙasa
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ya zama dole don LLVM don cire iyakokin bincike kuma yana da codegen mafi kyau fiye da zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // an rarraba vec kuma an fara shi a sama zuwa aƙalla wannan tsayin.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // kasaftawa a sama tare da damar `s`, kuma fara zuwa `s.len()` a cikin ptr::copy_to_non_overlapping a ƙasa.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Dadin jikina da yanki.
    ///
    /// Wannan irin ne barga (watau, ya aikata ba daidai sake tsarawa abubuwa) da kuma *Ya*(*n*\*log(* n*)) m-harka.
    ///
    /// Lokacin da ya dace, an fi son rarrabe karko saboda yana da sauri fiye da daidaitaccen rarrabuwa kuma baya rarraba memba na taimako.
    /// Duba [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Algorithm na yanzu shine mai daidaitawa, mai daidaita yanayin haɗi wanda aka samo asali daga [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// An tsara shi don ya zama mai saurin gaske a cikin yanayin inda yanki ya kusan daidaitawa, ko ya ƙunshi jeri biyu ko fiye da aka jera ɗaya bayan ɗaya.
    ///
    ///
    /// Hakanan, yana ba da ajiyar ajiya na ɗan lokaci rabin girman `self`, amma don gajerun yanka ana amfani da nau'in shigar da ba kasaftawa ba maimakon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ya ware yanki tare da aikin kwatancen.
    ///
    /// Wannan irin ne barga (watau, ya aikata ba daidai sake tsarawa abubuwa) da kuma *Ya*(*n*\*log(* n*)) m-harka.
    ///
    /// Dole ne aikin kwatancen ya ayyana cikakken odar don abubuwan da ke cikin yanki.Idan oda bai zama cikakke ba, ba a bayyana oda abubuwan ba.
    /// Umarni shine tsari na duka idan ya kasance (ga duka `a`, `b` da `c`):
    ///
    /// * duka da antisymmetric: daidai ɗaya daga `a < b`, `a == b` ko `a > b` gaskiya ne, kuma
    /// * wucewa, `a < b` da `b < c` suna nuna `a < c`.Hakanan dole ne ya riƙe duka `==` da `>`.
    ///
    /// Misali, yayin da [`f64`] baya aiwatar da [`Ord`] saboda `NaN != NaN`, zamu iya amfani da `partial_cmp` azaman aikinmu idan muka san yanki bai ƙunshi `NaN` ba.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Lokacin da ya dace, an fi son rarrabe karko saboda yana da sauri fiye da daidaitaccen rarrabuwa kuma baya rarraba memba na taimako.
    /// Duba [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Algorithm na yanzu shine mai daidaitawa, mai daidaita yanayin haɗi wanda aka samo asali daga [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// An tsara shi don ya zama mai saurin gaske a cikin yanayin inda yanki ya kusan daidaitawa, ko ya ƙunshi jeri biyu ko fiye da aka jera ɗaya bayan ɗaya.
    ///
    /// Hakanan, yana ba da ajiyar ajiya na ɗan lokaci rabin girman `self`, amma don gajerun yanka ana amfani da nau'in shigar da ba kasaftawa ba maimakon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // baya kasawa
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ya ware yanki tare da aikin hakar maɓalli.
    ///
    /// Wannan nau'in yana da ƙarfi (ma'ana, baya sake tsara abubuwa daidai) da *O*(*m*\* * n *\* log(*n*)) mafi munin yanayi, inda maɓallin kewayawa shine *O*(*m*).
    ///
    /// Domin tsada key ayyuka (misali
    /// ayyukan da ba sauƙin samun dukiya ko ayyukan asali), [`sort_by_cached_key`](slice::sort_by_cached_key) na iya zama da sauri sosai, saboda baya rama maɓallan maɓallin.
    ///
    ///
    /// Lokacin da ya dace, an fi son rarrabe karko saboda yana da sauri fiye da daidaitaccen rarrabuwa kuma baya rarraba memba na taimako.
    /// Duba [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Algorithm na yanzu shine mai daidaitawa, mai daidaita yanayin haɗi wanda aka samo asali daga [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// An tsara shi don ya zama mai saurin gaske a cikin yanayin inda yanki ya kusan daidaitawa, ko ya ƙunshi jeri biyu ko fiye da aka jera ɗaya bayan ɗaya.
    ///
    /// Hakanan, yana ba da ajiyar ajiya na ɗan lokaci rabin girman `self`, amma don gajerun yanka ana amfani da nau'in shigar da ba kasaftawa ba maimakon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ya ware yanki tare da aikin hakar maɓalli.
    ///
    /// Yayin rarrabawa, ana kiran maɓallin aiki sau ɗaya kawai a kowane fanni.
    ///
    /// Wannan nau'in yana da ƙarfi (watau, baya sake tsara abubuwa daidai) da *O*(*m*\* * n *+* n *\* log(*n*)) mafi munin yanayi, inda maɓallin kewayawa *O*(*m*) .
    ///
    /// Don ayyuka masu maɓalli masu sauƙi (misali, ayyukan da suke isa ga dukiya ko ayyukan yau da kullun), da alama [`sort_by_key`](slice::sort_by_key) zai fi sauri.
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Tsarin algorithm na yanzu ya dogara ne akan [pattern-defeating quicksort][pdqsort] na Orson Peters, wanda ya haɗu da matsakaiciyar shari'ar saurin bazuwa tare da mafi saurin mummunan yanayi, yayin cimma daidaitaccen lokaci akan yanka tare da wasu alamu.
    /// Yana amfani da wasu ƙididdiga don kauce wa rikice-rikice, amma tare da tsayayyen seed don koyaushe samar da halayyar ƙaddara.
    ///
    /// A cikin mafi munin yanayi, algorithm yana ba da ajiyar ajiya na ɗan lokaci a cikin `Vec<(K, usize)>` tsawon yanki.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Taimakawa macro don ladaftar da vector ɗinmu ta hanyar ƙarami mai yuwuwa, don rage rarraba.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Abubuwan da ke cikin `indices` na musamman ne, kamar yadda aka lissafa su, don haka kowane nau'in zai zama mai karko dangane da yanki na asali.
                // Muna amfani da `sort_unstable` anan saboda yana buƙatar ƙarancin kason ƙwaƙwalwa.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kwafa `self` cikin sabon `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // A nan, `s` da `x` za a iya modified da kansa.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kwafa `self` cikin sabon `Vec` tare da mai rabawa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // A nan, `s` da `x` za a iya modified da kansa.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, duba samfurin `hack` a cikin wannan fayil ɗin don ƙarin bayani.
        hack::to_vec(self, alloc)
    }

    /// Sabobin tuba `self` cikin vector ba tare da kwayoyi masu ƙyalli ko rarrabawa ba.
    ///
    /// Sakamakon vector za'a iya juyar dashi cikin akwati ta hanyar `` Vec<T>Hanyar `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ba za a iya amfani da shi ba saboda an canza shi cikin `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, duba samfurin `hack` a cikin wannan fayil ɗin don ƙarin bayani.
        hack::into_vec(self)
    }

    /// Halicci vector ta maimaita wani yanki `n` sau.
    ///
    /// # Panics
    ///
    /// Wannan aikin zai panic idan ƙarfin zai cika.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic bisa ambaliya:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Idan `n` ya fi sifili girma, ana iya raba shi kamar `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` shine lambar da aka wakilta ta hagu '1' kaɗan na `n`, kuma `rem` shine sauran ɓangaren `n`.
        //
        //

        // Amfani da `Vec` don samun damar `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` maimaitawa ana yin ta ninka sau `buf` ``expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Idan `m > 0`, akwai sauran ragowa har zuwa ƙarshen hagu na '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` yana da damar `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 'expn`) maimaitawa an yi shi ta kwafin farkon maimaitawar `rem` daga `buf` kanta.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Wannan ba mai ruɓuwa bane tun daga `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` yayi daidai da `buf.capacity()` (``= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens wani yanki na `T` cikin ƙima guda `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens wani yanki na `T` cikin ƙima guda `Self::Output`, yana sanya mai ba da izini tsakanin kowannensu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens wani yanki na `T` cikin ƙima guda `Self::Output`, yana sanya mai ba da izini tsakanin kowannensu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Ya dawo da vector mai ɗauke da kwafin wannan yanki inda aka tsara kowane baiti zuwa ga babban yanayin ASCII.
    ///
    ///
    /// Haruffan ASCII 'a' zuwa 'z' an tsara su zuwa 'A' zuwa 'Z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don ƙara girman darajar a wuri, yi amfani da [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Ya dawo da vector mai ɗauke da kwafin wannan yanki inda aka tsara kowane baiti zuwa ga ƙaramin ƙaramin ASCII.
    ///
    ///
    /// Haruffan ASCII 'A' zuwa 'Z' an tsara su zuwa 'a' zuwa 'z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don Ƙaramin baki da darajar a-wuri, amfani da [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Fadada traits don yanka akan takamaiman nau'in bayanai
////////////////////////////////////////////////////////////////////////////////

/// Mataimaki trait don [`[T]: : concat`]](yanki::taro).
///
/// Note: ba a amfani da nau'in siga na `Item` a cikin wannan trait, amma yana ba da damar yin rikitarwa su zama na asali.
/// Ba tare da shi ba, mun sami wannan kuskuren:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Wannan saboda za'a iya samun nau'ikan `V` tare da ɗimbin yawa na `Borrow<[_]>`, kamar nau'ikan nau'ikan `T` da yawa zasu yi amfani da su:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Nau'in da aka samu bayan haɗuwa
    type Output;

    /// Aiwatar da [`[T]: : concat`](yanki::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Mataimaki trait don [`[T]: : shiga`](yanki::shiga)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Nau'in da aka samu bayan haɗuwa
    type Output;

    /// Aiwatar da [`[T]: : shiga`](yanki::shiga)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ingantaccen aiwatarwar trait don yanka
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // sauke wani abu a cikin manufa wanda ba za'a sake rubuta shi ba
        target.truncate(self.len());

        // target.len <= self.len saboda ɗankwalin da ke sama, saboda haka yankan anan koyaushe suna da iyaka.
        //
        let (init, tail) = self.split_at(target.len());

        // sake amfani da abubuwan da aka ƙunshe allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Abun da ake sakawa `v[0]` a cikin tsararren jerin `v[1..]` saboda duk `v[..]` ya zama tsararru.
///
/// Wannan shine tushen tsarin shigar da abubuwa.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Akwai hanyoyi uku da su aiwatar da sa a nan:
            //
            // 1. Musayar abubuwan da ke kusa da juna har sai na farkon ya kai inda ya nufa.
            //    Duk da haka, wannan hanya da muke kwafa data kusa fiye da wajibi ne.
            //    Idan abubuwa manyan tsare-tsare ne (masu tsada don kwafa), wannan hanyar zata yi jinkiri.
            //
            // 2. Yi fushi har sai an sami madaidaicin wuri don farkon abu.
            // Sa'annan ku sauya abubuwanda suke nasara dashi don sanya masa wuri kuma daga karshe sanya shi cikin sauran ramin.
            // Wannan hanya ce mai kyau.
            //
            // 3. Kwafa farkon abu a cikin canjin canjin lokaci.Iterate har da hakkin wuri domin shi an same shi.
            // Yayin da muke ci gaba, kwafa duk abubuwan da aka ratsa cikin ramin da ya gabace shi.
            // A ƙarshe, kwafa bayanai daga canji na ɗan lokaci zuwa sauran ramin.
            // Wannan hanyar tana da kyau sosai.
            // Alamar alamomi sun nuna aiki mafi kyau fiye da na 2nd.
            //
            // Duk hanyoyin da aka ƙayyade, kuma na 3 ya nuna kyakkyawan sakamako.Don haka muka zabi wancan.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // `hole`, wanda ke amfani da dalilai biyu: ana bin sahun tsaka-tsakin yanayi na aikin sakawa.
            // 1. Kare mutuncin `v` daga panics a cikin `is_less`.
            // 2. Cika sauran ramin a `v` a ƙarshe.
            //
            // Panic aminci:
            //
            // Idan `is_less` panics a kowane matsayi yayin aiwatarwa, `hole` zai fado kuma ya cika ramin a cikin `v` tare da `tmp`, don haka tabbatar da cewa `v` har yanzu yana riƙe da duk abin da ta fara riƙe shi sau ɗaya.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ya fadi kuma ta haka ne yayi kwafin `tmp` a cikin sauran ramin da yake cikin `v`.
        }
    }

    // Lokacin da ya ragu, kofe daga `src` cikin `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Haɗa marasa raguwa suna gudanar da `v[..mid]` da `v[mid..]` ta amfani da `buf` azaman ajiyar ɗan lokaci, kuma suna adana sakamakon cikin `v[..]`.
///
/// # Safety
///
/// Yankunan guda biyu dole su zama marasa fanko kuma `mid` dole ne ya kasance cikin iyakoki.
/// Buffer `buf` dole dogon isa ya riƙe wani kwafin na guntu yanki.
/// Hakanan, `T` bazai zama nau'in sifiri ba.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Tsarin haɗaka ya fara kwafin gajeren gudu zuwa `buf`.
    // Sannan yana gano sabuwar kwafin da aka kwafa da kuma wanda ya fi tsayi a gaba (ko baya), tare da gwada abubuwan da ba a taba daukarsu ba da kuma kwafin karami (ko mafi girma) a cikin `v`.
    //
    // Da zaran gajeren gudu ya gama cinyewa, aikin ya kan gama.Idan mafi tsayi ya fara cinyewa da farko, to dole ne mu kwafa duk abin da ya rage na gajeren gudu zuwa sauran ramin da yake cikin `v`.
    //
    // Intermediate jihar na tsari ne ko da yaushe sa ido ta hanyar `hole`, abin da hidima biyu dalilai:
    // 1. Kare mutuncin `v` daga panics a cikin `is_less`.
    // 2. Cika ragowar ramin a cikin `v` idan tsawan lokaci ya cinye da farko.
    //
    // Panic aminci:
    //
    // Idan `is_less` panics a kowane batu a lokacin tsari, `hole` za samun kika aika da cika rami a `v` da unconsumed iyaka a `buf`, ta haka ne tabbatar da cewa `v` har yanzu riqe kowane abu shi da farko da aka gudanar daidai sau daya.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Gudun hagu ya fi guntu
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Da farko, wadannan pointers nuna farkon su iri-iri.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Cinye karami gefen.
            // Idan daidai ne, fi son gudu na hagu don kiyaye kwanciyar hankali.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Gudun dama ya fi guntu
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Da farko, waɗannan bayanan suna nuna ƙarshen ƙarshen tsarinsu.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Cinye mafi girma gefe.
            // Idan daidai, fi son dama gudu don kula da kwanciyar hankali.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // A ƙarshe, an saukar da `hole`.
    // Idan gajeren gudu bai cika cinyewa ba, duk abin da ya rage yanzu za a kwafe shi cikin ramin a cikin `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Lokacin da aka sauke, kwafa zangon `start..end` zuwa `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ba nau'in sifiri bane, don haka yana da kyau a raba ta girmanta.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Wannan haɗin haɗin yana karɓar wasu ra'ayoyi (amma ba duka ba) daga TimSort, wanda aka bayyana dalla-dalla [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// A algorithm yana gano takamaiman saukowa da wanda baya sauka, wadanda ake kira da sunaye na halitta.Akwai tarin abubuwan jiran aiki waɗanda ba a haɗa su ba.
/// Kowane sabon samu gudu ne tura uwa da tari, sa'an nan kuma wasu nau'i-nau'i daga m runs an garwaya tẽku sai wadannan biyu invariants gamsu:
///
/// 1. ga kowane `i` a cikin `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. ga kowane `i` a cikin `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Masu canzawa suna tabbatar da cewa jimlar lokacin gudu shine *O*(*n*\*log(* n*)) mafi munin yanayi.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ana rarraba yanki har zuwa wannan tsawon ta amfani da nau'in sakawa.
    const MAX_INSERTION: usize = 20;
    // Very short runs ana mika ta amfani da sa irin wa span akalla wannan da yawa abubuwa.
    const MIN_RUN: usize = 10;

    // Kasawa yana da wani m hali a sifili-sized iri.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Shortananan tsararru suna daidaitawa a cikin wuri ta hanyar saka kayan don kaucewa rabe-raben.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Sanya wani abu don amfani dashi azaman ƙwaƙwalwar ƙwaƙwalwa.Mun ci gaba da tsayin 0 haka za mu iya ci gaba da shi m kofe na abinda ke ciki na `v` ba tare da risking da dtors yanã gudãna a kan kofe idan `is_less` panics.
    //
    // Lokacin haɗa abubuwa guda biyu da aka jera, wannan maɓallin yana riƙe da kwafin gajeren gudu, wanda koyaushe zai sami tsayi a mafi yawan `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Don gano abubuwan da ke gudana a cikin `v`, muna juye da shi baya.
    // Wannan na iya zama kamar baƙon shawara ne, amma la'akari da gaskiyar cewa haɗuwa sau da yawa tafi zuwa kishiyar shugabanci (forwards).
    // A cewar asowar, tattara abubuwa masu kyau gaba ne dan kadan sauri fiye da tattara abubuwa masu kyau na baya.
    // A ƙarshe, gano gudu ta hanyar ratse baya yana inganta aikin.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Nemo gaba na gaba, kuma juya shi idan yana sauka sosai.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Saka wasu ƙarin abubuwa cikin gudu idan yayi gajere.
        // Tsarin shigarwa ya fi sauri fiye da haɗuwa akan gajeren jerin, don haka wannan yana inganta ingantaccen aiki.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Tura wannan gudu akan tarin.
        runs.push(Run { start, len: end - start });
        end = start;

        // Haɗa wasu nau'i biyu na kusa da gudu don gamsar da masu canzawa.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // A ƙarshe, daidai gudu ɗaya dole ne ya kasance cikin tari.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Yayi nazarin tarin gudu da gano abubuwan gudu na gaba don haɗuwa.
    // Specificallyari musamman, idan an dawo da `Some(r)`, wannan yana nufin `runs[r]` da `runs[r + 1]` dole ne a haɗasu gaba.
    // Idan algorithm yaci gaba da gina sabon gudu maimakon, `None` ya dawo.
    //
    // TimSort sanannen sananne ne saboda aiwatarwar bugunsa, kamar yadda aka bayyana anan:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // A gist na labarin ne: dole ne mu aiwatar da invariants a saman hudu runs a kan tari.
    // Tilasta su a kan manyan ukun uku bai isa ba don tabbatar da cewa masu canzawa har yanzu zasu riƙe don *duk* gudu a cikin tari.
    //
    // Wannan aikin yana bincikar masu canzawa don samfuran saman guda huɗu.
    // Allyari akan haka, idan babban gudu ya fara a kan layin 0, koyaushe zai buƙaci haɗakar aiki har sai tarin ya gama rugujewa, don kammala tsarin.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}