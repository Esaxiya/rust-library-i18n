//! Kayan aiki don tsarawa da bugawa '' String`s.
//!
//! Wannan ƙirar ta ƙunshi tallafin lokacin gudu don haɓakar haɗin ginin [`format!`].
//! Wannan Macro aka aiwatar a cikin tarawa zuwa emit kira ga wannan a koyaushe domin format muhawara a Runtime cikin kirtani.
//!
//! # Usage
//!
//! A [`format!`] Macro ne aka yi nufi ga zama saba wa waɗanda tahowa daga C ta `printf`/`fprintf` ayyuka ko Python ta `str.format` aiki.
//!
//! Wasu misalai na [`format!`] tsawo ne:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" tare da manyan sifili
//! ```
//!
//! Daga wadannan, kana iya ganin cewa na farko da ya kasance hujjarsu ne mai format kirtani.Mai buƙata yana buƙata don wannan ya zama zaren zahiri;ba zai iya zama mai canzawa ya shiga ba (don aiwatar da ingancin aiki).
//! Mai tattarawa zaiyi amfani da kirtani mai tsar sannan ya tantance idan jerin maganganun da aka bayar sun dace da zuwa wannan igiyar.
//!
//! Don canza ƙima ɗaya zuwa kirtani, yi amfani da hanyar [`to_string`].Wannan zai yi amfani da tsarin trait Z0trax Z0trait.
//!
//! ## Sigogin matsayi
//!
//! Kowane tsara shawara da aka yarda su saka da darajar shaida shi ke referencing, kuma idan tsallake shi ne zaci su zama "the next argument".
//! Misali, layin fasalin `{} {} {}` zai dauki sigogi uku, kuma za'a tsara su a tsari iri daya yadda aka basu.
//! The format kirtani `{2} {1} {0}`, duk da haka, zai format muhawara a baya domin.
//!
//! Abubuwa na iya ɗan ɗan ɗanɗani da zarar ka fara cakuɗa nau'ikan masu tantance matsayin wuri biyu."next argument" mai tantancewa za a iya tunanin sa azaman mai maimaita magana a kan gardamar.
//! Duk lokacin da aka ga mai tantance "next argument", mai gabatarwar ya ci gaba.Wannan yana haifar da hali kamar haka:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Mai maganar ciki a kan mahawarar ba ta ci gaba ba a lokacin da aka ga `{}` na farko, don haka yana buga gardamar farko.Bayan an kai ga `{}` na biyu, mai gabatarwar ya ci gaba zuwa hujja ta biyu.
//! Ainihi, sigogin da suka fito fili suna sunan hujjarsu basa shafar sigogin da basa ambaton mahawara dangane da masu tantance matsayinsu.
//!
//! Ana buƙatar zaren tsari don amfani da duk maganganunta, in ba haka ba kuskure ne na tara lokaci.Mayila za ku koma zuwa ga wannan gardamar fiye da sau ɗaya a cikin zaren tsarin.
//!
//! ## Sigogi masu suna
//!
//! Rust kanta bashi da Python-kamar kwatankwacin sigogi mai suna zuwa aiki, amma [`format!`] macro shimfida shimfiɗa ce wacce ke ba shi damar yin amfani da sigogin mai suna.
//! An lissafa sigogin da aka ambata a ƙarshen jerin mahawarar kuma suna da haɗin ginin:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Misali, maganganun [`format!`] na gaba duk suna amfani da hujja mai suna:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ba shi da inganci a sanya sigogin matsayi (waɗanda ba su da sunaye) bayan jayayya waɗanda ke da sunaye.Kamar tare da sigogi na matsayi, ba shi da inganci don samar da sigogi masu suna waɗanda waɗanda ba a amfani da su ta hanyar zaren.
//!
//! # Tsarin Sigogi
//!
//! Kowane jayayyar da ake tsarawa ana iya canza ta da dama sigogin tsara abubuwa (daidai da `format_spec` a cikin [the syntax](#syntax)). Waɗannan sigogin suna shafar wakilcin kirtani na abin da ake tsara shi.
//!
//! ## Width
//!
//! ```
//! // Duk waɗannan buga "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Wannan siga ne don "minimum width" wanda tsarin zai ɗauka.
//! Idan igiyar ƙimar ba ta cika waɗannan haruffa da yawa ba, to za a yi amfani da abin ɗorawa da fill/alignment ya ƙayyade don ɗaukar sararin da ake buƙata (duba ƙasa).
//!
//! Hakanan ana iya bayar da ƙimar faɗin a matsayin [`usize`] a cikin jerin sigogi ta ƙara postfix `$`, yana mai nuna cewa gardama ta biyu ita ce [`usize`] da ke nuna nisa.
//!
//! Magana game da jayayya tare da daidaitawar dala ba ta shafi takaddar "next argument" ba, saboda haka yana da kyau koyaushe a koma zuwa mahawara ta matsayi, ko amfani da dalilan da aka ambata.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Yanayin cika zaɓi da daidaitawa ana bayar dasu kwatankwacin haɗin tare da ma'aunin [`width`](#width).Dole ne a bayyana shi kafin `width`, daidai bayan `:`.
//! Wannan yana nuna cewa idan ƙimar da aka tsara ta kasance ƙasa da `width` za a buga wasu ƙarin haruffa kewaye da shi.
//! Ciko ya zo a cikin waɗannan bambance-bambancen da ke gaba don daidaitawa daban-daban:
//!
//! * `[fill]<` - mahawara an haɗa ta hagu a cikin ginshikan `width`
//! * `[fill]^` - muhawarar tana daidaitawa a cikin ɗakunan `width`
//! * `[fill]>` - mahawara daidai-daidai take a cikin ginshikan `width`
//!
//! Tsohuwar [fill/alignment](#fillalignment) don abubuwan da ba na lambobi ba fili ne kuma ya daidaita.Tsoho don masu tsara lambobi kuma halin sarari ne amma tare da daidaitawa daidai.
//! Idan aka bayyana tutar `0` (duba ƙasa) don lambobi, to harafin cikawa shine `0`.
//!
//! Lura cewa maiyuwa baza a aiwatar da jeri ta wasu nau'ikan ba.Musamman, ba a aiwatar dashi gaba ɗaya don `Debug` trait.
//! Hanya mai kyau don tabbatar da aikin padding ita ce tsara shigarwar ku, sannan kushin wannan layin da aka samu don samun fitarku:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hello Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Duk waɗannan tutocin suna canza halayen mai tsara su.
//!
//! * `+` - Ana nufin wannan don nau'in lambobi kuma yana nuna cewa alamar koyaushe ya kamata a buga.Ba a taɓa buga alamun tabbatacce ta hanyar tsohuwa, kuma ana buga alamar mara kyau ta tsohuwa don `Signed` trait.
//! Wannan tutar tana nuna cewa ya kamata a buga madaidaiciyar alama (`+` ko `-`).
//! * `-` - A halin yanzu ba a yi amfani da shi ba
//! * `#` - Wannan tutar tana nuna cewa ya kamata a yi amfani da nau'in ɗab'i na "alternate".A madadin misalansa:
//!     * `#?` - kyawawan-buga tsarin [`Debug`]
//!     * `#x` - ya riga ya kawo hujja tare da `0x`
//!     * `#X` - ya riga ya kawo hujja tare da `0x`
//!     * `#b` - ya riga ya kawo hujja tare da `0b`
//!     * `#o` - ya riga ya kawo hujja tare da `0o`
//! * `0` - Ana amfani da wannan don nuna don nau'ikan adadin lamba cewa padding zuwa `width` yakamata a yi su duka tare da halayen `0` kuma kasancewa sanannun sa hannu.
//! Tsarin kamar `{:08}` zai samar da `00000001` don adadin `1`, yayin da wannan tsarin zai samar da `-0000001` don lambar `-1`.
//! Sanarwa cewa korau version yana daya m sifili fiye da kyau version.
//!         Lura cewa a kowane lokaci ana sanya sifiri bayan alamar (idan akwai) kuma kafin lambobin.Idan aka yi amfani da shi tare da tutar `#`, ana amfani da irin wannan ƙa'idar: za a saka sifili masu padding bayan prefix amma kafin lambobi.
//!         An saka kari a cikin fadin duka.
//!
//! ## Precision
//!
//! Don nau'ikan marasa adadi, ana iya ɗaukar wannan a matsayin "maximum width".
//! Idan layin da aka samu ya fi wannan nisa tsayi, to, an yanke shi zuwa wannan haruffa da yawa kuma ana fitar da wannan ƙimar da aka yanke tare da `fill`, `alignment` da `width` masu kyau idan an saita waɗannan matakan.
//!
//! Don nau'ikan nau'ikan, ba a kula da wannan.
//!
//! Don nau'ikan ma'amala masu shawagi, wannan yana nuna lambobi nawa bayan adadin adadi yakamata a buga.
//!
//! Akwai hanyoyi guda uku masu yuwuwa don tantance `precision` da ake so:
//!
//! 1. Lamba `.N`:
//!
//!    lamba `N` kanta ita ce madaidaiciya.
//!
//! 2. Lamba ko suna mai biyo bayan alamar dala `.N$`:
//!
//!    amfani da tsari *hujja*`N` (wanda dole ne ya kasance `usize`) azaman daidaito.
//!
//! 3. Alamar taurari `.*`:
//!
//!    `.*` nufin cewa wannan `{...}` ake dangantawa da *biyu* format bayanai maimakon daya: na farko shigar riqe da `usize` daidaici, da kuma na biyu riqe da darajar a buga su.
//!    Lura cewa a wannan yanayin, idan mutum yayi amfani da kirtani mai nauyin `{<arg>:<spec>.*}`, to, ɓangaren `<arg>` yana nufin* ƙimar * don bugawa, kuma `precision` dole ne ya shigo cikin shigarwar da ta gabaci `<arg>`.
//!
//! Alal misali, da wadannan da kira duk buga wannan abu `Hello x is 0.01000`:
//!
//! ```
//! // Sannu {arg 0 ("x")} shine {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Sannu {arg 1 ("x")} shine {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Sannu {arg 0 ("x")} shine {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Sannu {next arg ("x")} shine {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} ne {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Sannu {next arg ("x")} shine {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Duk da yake waɗannan:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! buga abubuwa daban-daban guda uku:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! A wasu shirye-shirye da harsuna, da hali na kirtani tsara ayyuka dogara da tsarin aiki ta wuri saitin.
//! Ayyukan tsararru waɗanda aka samar da ingantaccen ɗakin karatu na Rust ba su da wata ma'anar yanki kuma zai samar da sakamako iri ɗaya a kan dukkan tsarin ba tare da la'akari da tsarin mai amfani ba.
//!
//! Misali, lambar mai zuwa koyaushe zata buga `1.5` koda kuwa tsarin yanki yana amfani da mai raba adadi banda digo.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Za'a iya haɗa haruffan zahiri na `{` da `}` a cikin kirtani ta hanyar yi musu riga da halayya iri ɗaya.Misali, halin `{` ya tsere tare da `{{` kuma halin `}` ya tsere tare da `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Don taƙaitawa, a nan za ku iya samun cikakken nahawun tsarin kirtani.
//! An faɗi mahimman bayanai don harshen da aka yi amfani da su daga wasu yarukan, don haka kada ya zama baƙon abu sosai.An tsara maganganu tare da daidaitawa kamar Python, ma'ana cewa muhawara tana kewaye da `{}` maimakon C-like `%`.
//! Ainihin nahawu don tsara tsarin aiki shine:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! A nahawun da ke sama, `text` na iya ƙunsar kowane nau'in `'{'` ko `'}'`.
//!
//! # Tsarin traits
//!
//! Yayinda ake neman a tsara hujja da wani nau'in, a zahiri kuna neman cewa hujja tayi daidai da trait.
//! Wannan yana ba da damar nau'ikan nau'ikan zahiri da yawa ta hanyar `{:x}` (kamar [`i8`] da [`isize`]).Taswirar yankuna na yanzu zuwa traits shine:
//!
//! * *babu komai* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` 00 [`Debug`] tare da lambobi masu yawa na ƙananan hexadecimal
//! * `X?` 00 [`Debug`] tare da manyan lambobi na hexadecimal
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Abin da nufin wannan shi ne cewa wani irin shawara da aiwatar da [`fmt::Binary`][`Binary`] trait sannan za a tsara da `{:b}`.Implementations ana azurta wadannan traits ga yawan m iri da misali library kazalika.
//!
//! Idan babu takamaiman tsari (kamar a cikin `{}` ko `{:6}`), to tsarin trait da aka yi amfani da shi shine [`Display`] trait.
//!
//! Lokacin aiwatar da tsari trait don nau'in ku, lallai ne ku aiwatar da hanyar sa hannu:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // nau'in mu na al'ada
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Za a ƙaddamar da nau'in ku azaman `self` ta hanyar ishara, sannan aikin ya kamata ya fitar da fitarwa zuwa rafin `f.buf`.Yana da har zuwa kowane format trait aiwatar to daidai bi da nema tsara sigogi.
//! Valuesimar waɗannan sigogin za a jera su a cikin fannonin tsarin [`Formatter`].Don taimakawa tare da wannan, tsarin [`Formatter`] kuma yana ba da wasu hanyoyin taimako.
//!
//! Ari akan haka, dawo da darajar wannan aikin shine [`fmt::Result`] wanda shine nau'in laƙabi na (``Sakamakon ''`` <(), ``(`` std: : fmt::Error`] ''>``.
//! Tsarin aiwatarwa ya kamata ya tabbatar da cewa suna yada kurakurai daga [`Formatter`] (misali, yayin kiran [`write!`]).
//! Duk da haka, ya kamata su taba komawa kurakurai spuriously.
//! Wato, aiwatar da tsarin dole ne kuma yana iya dawo da kuskure kawai idan [`Formatter`] da aka wuce ya dawo da kuskure.
//! Wannan shi ne saboda ya saba wa abin da aikin sa hannu iya bayar da shawarar, kirtani Tsarin ne ma'asumi aiki.
//! Wannan aikin yana dawo da sakamako ne kawai saboda rubutawa zuwa asalin rafin na iya faduwa kuma dole ne ya samar da hanyar da za'a yada gaskiyar cewa kuskure ya faru ya dawo da tarin.
//!
//! Misali na aiwatar da tsara traits zai yi kama:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Theimar `f` tana aiwatar da `Write` trait, wanda shine abin da aka rubuta!macro yana jira.
//!         // Lura cewa wannan tsarin yayi watsi da tutoci da yawa da aka bayar don tsara kirtani.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits daban-daban suna ba da izinin nau'ikan fitarwa na nau'in.
//! // Ma'anar wannan tsarin shine a buga girman vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Girmama tutocin tsara abubuwa ta amfani da hanyar taimako `pad_integral` akan abun Formatter.
//!         // Duba takaddun hanyoyin don cikakkun bayanai, kuma ana iya amfani da aikin `pad` don kushin kirtani.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Wadannan tsara traits biyu suna da dalilai daban-daban:
//!
//! - [`fmt::Display`][`Display`] aiwatarwa sun tabbatar da cewa nau'in ana iya wakiltar su da aminci azaman zaren UTF-8 a kowane lokaci.Ba ** ba a tsammanin cewa kowane nau'in yana aiwatar da [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] yakamata a aiwatar da aiwatarwa don **duk** nau'ikan jama'a.
//!   Fitarwa zai yawanci wakilci ciki bayyana matsayin da aminci kamar yadda zai yiwu.
//!   Dalilin [`Debug`] trait shine don sauƙaƙe lalata lambar Rust.A mafi yawan lokuta, amfani da `#[derive(Debug)]` ya isa kuma an bada shawarar.
//!
//! Wasu misalan fitarwa daga duka traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros masu dangantaka
//!
//! Akwai wasu macros masu alaƙa a cikin dangin [`format!`].Waɗanda ake aiwatarwa a halin yanzu sune:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Wannan da [`writeln!`] sune macros guda biyu waɗanda ake amfani dasu don fitar da zaren tsararru zuwa takamaiman rafi.Ana amfani da wannan don hana tsaka-tsakin tsakaita na kirtani mai tsari kuma maimakon haka kai tsaye rubuta fitarwa.
//! A ƙarƙashin murfin, wannan aikin yana kiran aikin [`write_fmt`] wanda aka bayyana akan [`std::io::Write`] trait.
//! Misali amfani shine:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Wannan da [`println!`] suna fitar da fitarwa zuwa stdout.Hakanan ga [`write!`] macro, makasudin waɗannan macros shine don gujewa tsaka-tsakin matsakaita lokacin buga fitarwa.Misali amfani shine:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] da [`eprintln!`] macros suna kama da [`print!`] da [`println!`], bi da bi, sai dai suna fitar da abin da suke fitarwa zuwa stderr.
//!
//! ### `format_args!`
//!
//! Wannan macro ne mai ban sha'awa wanda aka yi amfani dashi don wucewa cikin aminci game da wani abu mai ban mamaki wanda ke kwatanta igiyar tsari.Wannan abun baya buƙatar kowane kaso mai tsoka don ƙirƙirar shi, kuma kawai yana ishara ne da bayanai akan tari.
//! A ƙarƙashin kaho, ana aiwatar da dukkan macros masu alaƙa dangane da wannan.
//! Da farko, wani misali amfani shine:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Sakamakon macro [`format_args!`] shine ƙimar nau'in [`fmt::Arguments`].
//! Wannan tsarin za'a iya ba shi zuwa ayyukan [`write`] da [`format`] a cikin wannan rukunin don aiwatar da zaren tsarukan.
//! Manufar wannan macro shine har ila yau ya kara hana raba matsakaita yayin ma'amala da igiyar tsarawa.
//!
//! Misali, laburaren shiga zai iya amfani da daidaitaccen tsarin rubutun, amma zai wuce cikin wannan tsarin har sai an tabbatar da inda yakamata ya fita.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// A `format` aiki daukan wani [`Arguments`] struct da kuma dawo da sakamakon wanda aka tsara kirtani.
///
///
/// Za'a iya ƙirƙirar misalin [`Arguments`] tare da [`format_args!`] macro.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Lura cewa amfani da [`format!`] na iya zama fifiko.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}