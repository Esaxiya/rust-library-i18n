#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Abubuwan da ke cikin sabon ƙwaƙwalwar ba su da ilimin.
    Uninitialized,
    /// Sabuwar ƙwaƙwalwar ajiyar ta tabbata ba za ta sami sifiri ba.
    Zeroed,
}

/// Utamfani mai ƙananan matakin don ƙarin rarrabawa ta hanyar kuskure, sake rarraba wuri, da kuma raba wurin ajiyar ƙwaƙwalwar ajiya a kan tarin ba tare da damuwa da duk al'amuran kusurwar da abin ya shafa ba.
///
/// Wannan nau'in yana da kyau don gina tsarin bayananku kamar Vec da VecDeque.
/// Musamman:
///
/// * Samar `Unique::dangling()` a sifili-sized iri.
/// * Samar `Unique::dangling()` a sifili-tsawon asusun tarayya.
/// * Zai kawar yantar `Unique::dangling()`.
/// * Kama duk ambaliyar cikin lissafin aiki (inganta su zuwa "capacity overflow" panics).
/// * Masu tsaro kan tsarin 32-bit wadanda suka ware sama da baiti isize::MAX.
/// * Masu kiyayewa daga wuce gona da iri tsawon ka.
/// * Kira `handle_alloc_error` for fallible asusun tarayya.
/// * Ya ƙunshi `ptr::Unique` kuma don haka yana ba mai amfani da duk fa'idodi masu alaƙa.
/// * Yana amfani da rarar da aka dawo daga mai rarraba don amfani da mafi girman damar da ake samu.
///
/// Wannan nau'in ba ya bincika ƙwaƙwalwar ajiyar da take gudanarwa.Idan aka sauke shi *zai '' kyauta ƙwaƙwalwar ajiyarta, amma ba* zaiyi * ƙoƙarin sauke abin da ke ciki ba.
/// Ya rage ga mai amfani da `RawVec` ya kula da ainihin abubuwan *da aka adana* a cikin `RawVec`.
///
/// Lura cewa yawan nau'ikan nau'ikan sifili bashi da iyaka, saboda haka `capacity()` koyaushe yana dawo da `usize::MAX`.
/// Wannan yana nufin cewa kana bukatar ka yi hankali lokacin da zagaye-tuntube irin wannan tare da wani `Box<[T]>`, tun `capacity()` ba zai haifar da da tsawon.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Wannan ya wanzu saboda `#[unstable]` ``const fn`s bazai dace da `min_const_fn` ba don haka baza'a iya kiransu a cikin '' min_const_fn`s ba
    ///
    /// Idan ka canza `RawVec<T>::new` ko masu dogaro, da fatan za a kula kada a gabatar da wani abu wanda zai keta `min_const_fn` da gaske.
    ///
    /// NOTE: Zamu iya gujewa wannan damfara da bincika daidaito tare da wasu sifofin `#[rustc_force_min_const_fn]` wanda ke buƙatar daidaitawa tare da `min_const_fn` amma ba lallai ba ne izinin kiran shi a cikin lambar `stable(...) const fn`/lambar mai amfani wanda baya ba `foo` lokacin da `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ya kasance.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Creatirƙirar babbar `RawVec` mai yiwuwa (a kan tsarin tsararru) ba tare da rarrabawa ba.
    /// Idan `T` yana da girma mai kyau, to wannan yana sanya `RawVec` tare da ƙarfin `0`.
    /// Idan `T` ba sifili ba ne, to yana yin `RawVec` tare da ƙarfin `usize::MAX`.
    /// Amfani don aiwatar da jinkirta kasaftawa.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Irƙira `RawVec` (a kan tsarin ƙasa) tare da madaidaicin ƙarfin aiki da buƙatun daidaitawa don `[T; capacity]`.
    /// Wannan yayi daidai da kiran `RawVec::new` lokacin da `capacity` shine `0` ko `T` ba girman sifili.
    /// Lura cewa idan `T` bashi da sifiri wannan yana nufin bazaku *sami*`RawVec` tare da damar da aka nema ba.
    ///
    /// # Panics
    ///
    /// Panics idan ƙarfin da aka nema ya wuce baiti `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Zubar da ciki akan OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kamar `with_capacity`, amma yana bada garantin ajiyar.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Sake gyara `RawVec` daga manuni da iyawa.
    ///
    /// # Safety
    ///
    /// `ptr` dole ne a sanya shi (a kan tsarin), kuma tare da `capacity` da aka bayar.
    /// `capacity` ba zai iya wuce `isize::MAX` don nau'ikan girma ba.(kawai damuwa ne akan tsarin 32-bit).
    /// ZST vectors na iya samun ƙarfin har zuwa `usize::MAX`.
    /// Idan `ptr` da `capacity` suka fito daga `RawVec`, to wannan tabbas zai tabbata.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Inyananan Vecs bebe ne.Tsallaka zuwa:
    // - 8 idan girman abu ya kasance 1, saboda duk masu raba tarin zasu iya tattara buƙatun ƙasa da baiti 8 zuwa aƙalla baiti 8.
    //
    // - 4 idan abubuwa matsakaita ne (<=1 KiB)
    // - 1 in ba haka ba, don kaucewa ɓata sarari da yawa don gajerun Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Kamar `new`, amma parameterized kan zabi na allocator ga koma `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` yana nufin "unallocated".nau'ikan sifili ba su kula ba.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Kamar `with_capacity`, amma an ƙaddara shi akan zaɓin mai rarrabawa don `RawVec` da aka dawo.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Kamar `with_capacity_zeroed`, amma an ƙaddara shi akan zaɓin mai rarrabawa don `RawVec` da aka dawo.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Sabobincike `Box<[T]>` zuwa `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Yana canza dukkan abin adon cikin `Box<[MaybeUninit<T>]>` tare da takamaiman `len`.
    ///
    /// Lura cewa wannan zai sake gyara duk wani canje-canje na `cap` da aka yi.(Duba bayanin nau'in don cikakkun bayanai.)
    ///
    /// # Safety
    ///
    /// * `len` dole ne ya zama ya fi girma ko daidaita da ƙarfin da aka nema kwanan nan, kuma
    /// * `len` dole ne ya zama ƙasa da ko daidaita da `self.capacity()`.
    ///
    /// Lura, cewa ƙarfin da aka nema da `self.capacity()` na iya bambanta, kamar yadda mai rarraba zai iya rarrabawa da kuma dawo da toshe mafi girman ƙwaƙwalwar ajiya fiye da yadda aka nema.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-duba rabin abin da ake bukata na aminci (ba za mu iya duba rabin ba).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Muna guje wa `unwrap_or_else` a nan saboda yana rufe adadin LLVM IR da aka samar.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Sake canzawa a `RawVec` daga mai nunawa, iya aiki, da kuma rarrabawa.
    ///
    /// # Safety
    ///
    /// A `ptr` dole ne a kasaftawa (via da ba allocator `alloc`), kuma da ba `capacity`.
    /// A `capacity` ba zai iya wuce `isize::MAX` for sized iri.
    /// (kawai damuwa ne akan tsarin 32-bit).
    /// ZST vectors na iya samun ƙarfin har zuwa `usize::MAX`.
    /// Idan `ptr` da `capacity` sun fito daga `RawVec` da aka kirkira ta hanyar `alloc`, to wannan tabbas zai tabbata.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Samun ɗan nuna alama zuwa farkon rabon.
    /// Lura cewa wannan `Unique::dangling()` ne idan `capacity == 0` ko `T` basu da girma.
    /// A cikin tsohon harka, dole ne ka yi hankali.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Samun da damar da kasafi.
    ///
    /// Wannan koyaushe zai zama `usize::MAX` idan `T` ba shi da girma.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Ya dawo da bayanin da aka raba zuwa mai ba da tallafi ga wannan `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Muna da rarar ƙwaƙwalwar ajiya, don haka zamu iya tsallake binciken lokaci don samun tsarin mu na yanzu.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Tabbatar cewa buffer ya ƙunshi aƙalla isasshen sarari don riƙe abubuwan `len + additional`.
    /// Idan ba ya riga ya da isasshen iya aiki, za reallocate isa sararin samaniya da dadi slack sarari don amortized *Ya*(1) halayya.
    ///
    /// Zai iyakance wannan ɗabi'ar idan da gaske zai haifar da ita ga panic.
    ///
    /// Idan `len` ya wuce `self.capacity()`, wannan na iya kasawa ga sararin da aka nema da gaske.
    /// Wannan shi ne ba da gaske unsafe, amma unsafe code *ku* rubuta cewa dogara a kan hali na wannan aiki na iya karya.
    ///
    /// Wannan ya dace don aiwatar da aikin turawa kamar `extend`.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya wuce by00 `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Zubar da ciki akan OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ajiye dã sun zubar waccan ko panicked idan Len wuce `isize::MAX` haka wannan shi ne hadari yi zũciyõyinsu, ba yanzu.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Daidai yake da `reserve`, amma ya dawo kan kurakurai maimakon firgita ko zubar da ciki.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Tabbatar cewa buffer ya ƙunshi aƙalla isasshen sarari don riƙe abubuwan `len + additional`.
    /// Idan bai riga ya faru ba, zai sake rarraba mafi ƙarancin adadin ƙwaƙwalwar ajiyar da ake buƙata.
    /// Gabaɗaya wannan zai zama daidai adadin ƙwaƙwalwar da ake buƙata, amma bisa ƙa'idar mai rabawar yana da 'yanci ya ba da fiye da abin da muka nema.
    ///
    ///
    /// Idan `len` ya wuce `self.capacity()`, wannan na iya kasawa ga sararin da aka nema da gaske.
    /// Wannan shi ne ba da gaske unsafe, amma unsafe code *ku* rubuta cewa dogara a kan hali na wannan aiki na iya karya.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya wuce by00 `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Zubar da ciki akan OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Daidai yake da `reserve_exact`, amma ya dawo kan kurakurai maimakon firgita ko zubar da ciki.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Yana rage rabon ƙasa zuwa adadin da aka kayyade.
    /// Idan adadin da aka ba shi 0 ne, a zahiri za a raba wurare gaba ɗaya.
    ///
    /// # Panics
    ///
    /// Panics idan adadin da aka bayar *ya fi girma* fiye da ƙarfin yanzu.
    ///
    /// # Aborts
    ///
    /// Zubar da ciki akan OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Ya dawo idan ma'ajin buƙata ya haɓaka don cika ƙarfin ƙarfin da ake buƙata.
    /// Yawanci ana amfani dashi don yin kira mai kira mai yuwuwa ba tare da saka `grow` ba.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Wannan hanya yawanci ana sanya ta sau da yawa.Don haka muna son ya zama ƙarami kamar yadda zai yiwu, don inganta lokutan tattarawa.
    // Amma kuma muna son yawancin abubuwan da ke ciki su zama na lissafi gwargwadon iko, don samar da lambar da ke gudana cikin sauri.
    // Saboda haka, wannan hanya ne a hankali rubuta sabõda haka, duk na code cewa ya dogara a kan `T` da yake a cikinta, alhãli kuwa kamar yadda da yawa daga cikin code cewa ba ya dogara ne a kan `T` kamar yadda zai yiwu ne a ayyuka da cewa su ne wadanda ba Generic kan `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Wannan an tabbatar da kiran riƙa.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Tun da mun koma damar `usize::MAX` lokacin `elem_size` ne
            // 0, zuwa nan dole yana nufin `RawVec` yayi yawa.
            return Err(CapacityOverflow);
        }

        // Babu wani abin da zamu iya yi game da waɗannan binciken, da baƙin ciki.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Wannan yana ba da tabbacin haɓakar haɓaka.
        // Neman sau biyu ba zai iya yawo ba saboda `cap <= isize::MAX` da nau'in `cap` shine `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ba na asali bane akan `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Theuntatawa akan wannan hanyar sunyi daidai da waɗanda suke akan `grow_amortized`, amma wannan hanyar yawanci ana sanya ta ne sau da yawa saboda haka bashi da mahimmanci.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Tunda mun dawo da ƙarfin `usize::MAX` lokacin da nau'in nau'in yake
            // 0, zuwa nan dole yana nufin `RawVec` yayi yawa.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ba na asali bane akan `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Wannan aikin yana wajen `RawVec` don rage lokacin tarawa.Duba sharhi a sama `RawVec::grow_amortized` don cikakkun bayanai.
// (Siffar `A` ba ta da mahimmanci, saboda yawan nau'ikan nau'ikan `A` da aka gani a aikace sun fi yawa fiye da adadin nau'ikan `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Bincika kuskuren anan don rage girman `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Mai rabawa yana duba daidaiton daidaito
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ya warware ƙwaƙwalwar ajiyar mallakar `RawVec`*ba tare da* ƙoƙarin sauke abin da ke ciki ba.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Babban aiki don kiyaye kuskuren kuskure.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Muna buƙatar tabbatar da masu zuwa:
// * Bamu taba ware abubuwa masu girman ba0000 `> isize::MAX` ba.
// * Ba mu cika `usize::MAX` ba kuma a zahiri muna ware kaɗan.
//
// A kan 64-bit kawai muna buƙatar bincika ambaliyar tunda ƙoƙarin raba baiti `> isize::MAX` tabbas zai gaza.
// A kan 32-bit da 16-bit muna buƙatar ƙara ƙarin tsaro don wannan idan muna gudana a kan wani dandamali wanda zai iya amfani da duk 4GB a sararin mai amfani, misali, PAE ko x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Centralaya daga cikin manyan ayyuka da ke da alhakin bayar da rahoto ƙimar ambaliyar.
// Wannan zai tabbatar da cewa lambar ƙira da ke da alaƙa da waɗannan panics ba ta da yawa saboda akwai wuri guda ɗaya wanda panics yake maimakon gungun a koyaushe.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}