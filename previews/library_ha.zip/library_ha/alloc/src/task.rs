#![stable(feature = "wake_trait", since = "1.51.0")]
//! Nau'uka da Traits don aiki tare da ayyukan asynchronous.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Aiwatar da farkawar aiki a kan mai zartarwa.
///
/// Ana iya amfani da wannan trait don ƙirƙirar [`Waker`].
/// Mai zartarwa na iya bayyana ma'anar wannan trait, kuma yayi amfani da hakan don gina Waker don wucewa zuwa ayyukan da aka zartar akan wannan mai zartarwa.
///
/// Wannan trait shine amintaccen-ƙwaƙwalwar ajiya kuma ergonomic madadin don gina [`RawWaker`].
/// Yana tallafawa tsarin zartarwa na gama gari wanda aka adana bayanan da aka yi amfani dasu don farka aiki a cikin [`Arc`].
/// Wasu masu aiwatarwa (musamman waɗanda ke cikin tsarin haɗin) ba za su iya amfani da wannan API ba, wanda shine dalilin da ya sa [`RawWaker`] ya kasance a matsayin madadin waɗancan tsarin.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Aikin `block_on` na asali wanda ke ɗaukar future kuma yana gudanar dashi zuwa ƙarshe akan zaren yanzu.
///
/// **Note:** Wannan misalin yana cinikin daidaito don sauki.
/// Don hana rufe lokaci, aiwatar da kayan aiki zai buƙaci ɗaukar matsakaiciyar kira zuwa `thread::unpark` gami da kiraye kiraye.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Mai farkawa wanda ya farka zaren yanzu lokacin da aka kira shi.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Gudun future zuwa kammala akan zaren yanzu.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Sanya future don haka za'a iya yin zabe.
///     let mut fut = Box::pin(fut);
///
///     // Ƙirƙirar sabon mahallin da za a wuce zuwa future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Gudun future zuwa ƙarshe.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Tashi wannan aikin.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Fita wannan aikin ba tare da cinye mai farkawa ba.
    ///
    /// Idan mai zartarwa ya goyi bayan hanya mafi arha ta farka ba tare da cinye mai farkawa ba, ya kamata ya rinjayi wannan hanyar.
    /// Ta hanyar tsoho, yana ɗaukar [`Arc`] kuma yana kiran [`wake`] akan clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // KYAUTA: Wannan amintacce ne saboda raw_waker yana ginawa cikin aminci
        // wani RawWaker daga Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ana amfani da wannan aikin sirri don gina RawWaker, maimakon
// shigar da wannan cikin cikin `From<Arc<W>> for RawWaker` impl, don tabbatar da cewa amincin `From<Arc<W>> for Waker` bai dogara da madaidaicin aikawar trait ba, maimakon haka duka biyun suna kiran wannan aikin kai tsaye da bayyane.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ara adadin ƙididdigar baka don haɗa shi.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Ka tashi ta darajar, matsar da Arc cikin aikin Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Tashi ta hanyar nuni, nade mai farkawa a ManuallyDrop don kaucewa faduwarsa
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Decrement da reference count na Arc kan drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}