#![stable(feature = "rust1", since = "1.0.0")]

//! Alamar-kirgawa mai kirdadon zare.
//!
//! Duba takardun [`Arc<T>`][Arc] don ƙarin bayani.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Limitayyadadden iyaka akan adadin nassoshi da za'a iya sanyawa zuwa `Arc`.
///
/// Samun sama da wannan iyaka zai zubar da shirin ku (duk da cewa ba lallai bane) a bayanan _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ba ya goyon bayan memory fences.
// Don gujewa rahotanni masu inganci na arc/rauni mai amfani da amfani da kayan atom don aiki tare maimakon haka.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Alamar-kirgawa mai ƙidayar zaren-aminci.'Arc' yana nufin 'Atomically Reference Counted'.
///
/// Nau'in `Arc<T>` yana ba da ikon mallakar nau'ikan nau'in `T`, wanda aka ware a cikin tsibi.Nemi [`clone`][clone] akan `Arc` yana samar da sabon misali na `Arc`, wanda ke nuni akan rabon wuri ɗaya a kan tulin matsayin tushen `Arc`, yayin haɓaka ƙididdigar tunani.
/// Lokacin da mai nuna alamar `Arc` na ƙarshe zuwa wani kason da aka ba shi ya lalace, ƙimar da aka adana a cikin wannan kason (wanda ake kira "inner value") shima ya ragu.
///
/// Rabawa nassoshi a Rust haramta maye gurbi da tsoho, da kuma `Arc` ne ba togiya: ba za ka iya kullum samu wani mutable tunani zuwa wani abu a ciki wani `Arc`.Idan kana buƙatar canzawa ta hanyar `Arc`, yi amfani da [`Mutex`][mutex], [`RwLock`][rwlock], ko ɗayan nau'ikan [`Atomic`][atomic].
///
/// ## Tsaron zare
///
/// Ba kamar [`Rc<T>`] ba, `Arc<T>` yana amfani da ayyukan atom don ƙididdigar ambatonsa.Wannan yana nufin cewa shi ne thread-lafiya.Rashin fa'ida shine ayyukan atomic sun fi tsada fiye da damar ƙwaƙwalwar ajiya.Idan baku raba rabon ƙididdigar da aka ƙididdige tsakanin zaren, la'akari da amfani da [`Rc<T>`] don ƙananan sama.
/// [`Rc<T>`] amintaccen tsoho ne, saboda mahaɗin zai kama kowane yunƙuri don aika [`Rc<T>`] tsakanin zaren.
/// Koyaya, laburaren na iya zaɓar `Arc<T>` don bawa masu amfani da ɗakin karatu sassauƙa.
///
/// `Arc<T>` za su aiwatar da [`Send`] da [`Sync`] muddin `T` ya aiwatar da [`Send`] da [`Sync`].
/// Me yasa ba za ku iya sanya nau'in `T` mara aminci ba a cikin `Arc<T>` don sanya shi mai zaren lafiya?Wannan na iya zama ɗan rashin fahimta da farko: bayan duk, ba batun batun zaren `Arc<T>` ba ne?Mabuɗin shine: `Arc<T>` ya sa aminci ya kasance da mallakar mallakan bayanai iri ɗaya, amma baya ƙara lafiyayyen zaren bayananta.
///
/// Yi la'akari da "Arc <" [``RefCell<T>`` '' ``.
/// [`RefCell<T>`] ba [`Sync`], kuma idan `Arc<T>` kasance ko da yaushe [`Send`], `Arc <` [`RefCell<T>zai kasance haka nan.
/// Amma to muna da matsala:
/// [`RefCell<T>`] ba zare lafiya ba;yana kiyaye lissafin lamuni ta hanyar amfani da ayyukan nukiliya.
///
/// A ƙarshe, wannan yana nufin cewa kuna iya buƙatar haɗa `Arc<T>` tare da wasu nau'ikan nau'in [`std::sync`], yawanci [`Mutex<T>`][mutex].
///
/// ## Karya hawan keke tare da `Weak`
///
/// Ana iya amfani da hanyar [`downgrade`][downgrade] don ƙirƙirar maɓallin [`Weak`] mara mallakar.Mai nuna alama na [`Weak`] na iya zama [`` haɓakawa '][haɓakawa] d zuwa `Arc`, amma wannan zai dawo da [`None`] idan darajar da aka adana a cikin rarar ta riga ta ragu.
/// A wasu kalmomin, masu nuna alama na `Weak` ba sa adana ƙimar cikin cikin rayayyar;Koyaya, suna *kiyaye* rabon (rayayyun shagon don ƙimar) a raye.
///
/// Ba za a sake rarraba zagayawa tsakanin masu nuna alamun `Arc` ba.
/// Saboda wannan dalili, ana amfani da [`Weak`] don fasa hawan keke.Misali, itace na iya samun alamomi masu ƙarfi na `Arc` daga mahaɗan mahaifa zuwa yara, da kuma alamomin [`Weak`] daga yara zuwa ga iyayensu.
///
/// # Nassoshin cloning
///
/// Samar da wani sabon tunani daga data kasance reference-kidaya akan an yi amfani da `Clone` trait aiwatar for [`Arc<T>`][Arc] da [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Abubuwan daidaitawa biyu da ke ƙasa daidai suke.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, da foo duk Arcs ne masu nuna wuri guda na ƙwaƙwalwar
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ta atomatik dereferences zuwa `T` (via da [`Deref`][deref] trait), don haka ba za ka iya kira `T` ta hanyoyin kan wani darajar da irin `Arc<T>`.Don kauce wa sunan arangama da `T` ta hanyoyin, da hanyoyin da `Arc<T>` kanta suna hade da ayyuka, da ake kira ta amfani da [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>'' Aiwatar da aiwatarwar traits kamar `Clone` ana iya kiranta ta amfani da cikakkiyar ingantaccen tsari.
/// Wasu mutane sun fi son amfani da cikakkun bayanai na tsari, yayin da wasu suka fi son amfani da tsarin kira kira.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Hanyar-kira ginin kalma
/// let arc2 = arc.clone();
/// // Cikakken tsari na dacewa
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ya aikata ba auto-dereference zuwa `T`, saboda ciki da darajar iya riga an kika aika.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Raba wasu bayanai da basa canzawa tsakanin zaren:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Lura cewa ba mu ** gudanar da waɗannan gwaje-gwajen a nan.
// Masu ginin windows ba sa jin daɗi idan zaren ya wuce babban zaren sannan ya fita a lokaci guda (wani abu na rufewa) don haka kawai mu guji wannan gaba ɗaya ta rashin tafiyar da waɗannan gwaje-gwajen.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Rarraba wani [`AtomicUsize`] mai canzawa:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Duba [`rc` documentation][rc_examples] don ƙarin misalai na ƙidayar tunani gaba ɗaya.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` sigar [`Arc`] ce wacce ke riƙe da abin da ba mallakar mallaka ga rarar sarrafawar.
/// A kasafi da aka isa da kiran [`upgrade`] a kan `Weak` akan, wanda ya koma wani [`Option`] '<`[`Arc`]'<T>>``.
///
/// Tunda bayanin `Weak` baya lissafa zuwa mallaki, bazai hana ƙimar da aka adana a cikin ragin ya ragu ba, kuma `Weak` kanta bata bada garantin game da ƙimar da ake samu ba.
///
/// Don haka yana iya dawowa [`None`] lokacin da (`` haɓakawa '] d.
/// Lura duk da haka cewa bayanin `Weak`*baya* hana kason kanta (shagon tallafawa) daga rarrabawa.
///
/// Nuni na `Weak` yana da amfani don adana ɗan lokaci zuwa rarar da [`Arc`] ke gudanarwa ba tare da hana ƙimar cikin sa ta ragu ba.
/// Hakanan ana amfani dashi don hana nassoshi madauwari tsakanin masu nuna alama na [`Arc`], tunda nassoshin mallakar juna ba zai taɓa bari a sauke ko [`Arc`] ba.
/// Alal misali, wata itãciya iya samun karfi [`Arc`] pointers daga iyaye nodes to yara, da kuma `Weak` pointers daga yara baya ga iyayensu.
///
/// Hanyar da aka saba don samo alamar `Weak` shine a kira [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Wannan `NonNull` ne don ba da damar inganta girman wannan nau'in a cikin lalura, amma ba lallai bane mai nuna alama mai inganci ba.
    //
    // `Weak::new` saita wannan zuwa `usize::MAX` ta yadda baya buƙatar rarraba sarari a kan tulin.
    // Wannan ba ƙimar da mai nuna alama zata taɓa samu ba saboda RcBox ya daidaita kusan 2.
    // Wannan zai yiwu ne kawai lokacin da `T: Sized`;unsized `T` never dangle.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Wannan shine repr(C) zuwa future-hujja akan yiwuwar sake dawo da filin, wanda zai iya tsangwama da in ba haka ba [into|from]_raw() mai aminci na nau'ikan ciki mai sauyawa.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // Ximar usize::MAX tana aiki azaman sintiri don na ɗan lokaci "locking" ikon haɓaka ra'ayoyi marasa ƙarfi ko rage masu ƙarfi;wannan da ake amfani da su kauce wa jinsi a `make_mut` da `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Ya gina sabon `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Fara rauni akan count a matsayin 1 wanda yake da rauni akan cewa ke gudanar da dukkan karfi pointers (kinda), ganin std/rc.rs for more info
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Ya gina sabon `Arc<T>` ta amfani da raunin rauni ga kansa.
    /// Yunƙurin hažaka da rauni tunani kafin wannan aikin ya dawo zai haifar da wani `None` darajar.
    /// Koyaya, ƙididdigar rauni zai iya zama cikin walwala da adana shi don adana shi zuwa wani lokaci na gaba.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Gina ciki a cikin yanayin "uninitialized" tare da raunin raunin guda.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Yana da muhimmanci ba mu daina ikon mallakar rauni akan, ko kuma ƙwaƙwalwar iya warware by lokacin `data_fn` ya dawo.
        // Idan da gaske muna son ƙetare ikon mallaka, za mu iya ƙirƙirar ƙarin alamomi mai rauni ga kanmu, amma wannan zai haifar da ƙarin sabuntawa zuwa ƙididdigar raunin rauni wanda ƙila ba dole ba in ba haka ba.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Yanzu zamu iya inganta darajar ciki da kuma juya raunin mu zuwa ƙaƙƙarfan tunani.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Rubutun da ke sama zuwa filin bayanan dole ne ya kasance bayyane ga kowane zaren da ke lura da ƙididdigar ƙarfi mara ƙarfi.
            // Saboda haka muna bukatar akalla "Release" ordering domin aiki tare da `compare_exchange_weak` a `Weak::upgrade`.
            //
            // "Acquire" ba a buƙatar oda.
            // Lokacin la'akari da yiwuwar halaye na `data_fn` kawai muna buƙatar kallon abin da zai iya yi tare da ambaton `Weak` mara haɓakawa:
            //
            // - Zai iya *haɗawa* da `Weak`, yana ƙaruwa da ƙididdigar rauni mai rauni.
            // - Zai iya sauke waɗancan kwayoyi masu faɗakarwa, yana rage ƙididdigar rarrabaccen ƙarfi (amma bai taɓa zuwa sifiri ba).
            //
            // Wadannan illolin basa tasiri mana ta kowace hanya, kuma babu wasu illolin da zasu iya yuwuwa da lambar kariya ita kadai.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Nassoshi masu ƙarfi yakamata su mallaki haɗin raunin rauni, saboda haka kar kuyi aiki da ɓarnar don tsoffin bayananmu na rauni.
        //
        mem::forget(weak);
        strong
    }

    /// Ya gina sabon `Arc` tare da abubuwan da basu waye ba.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Farawa da aka jinkirta:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ya gina sabon `Arc` tare da abubuwan da ba a san su ba, tare da ƙwaƙwalwar ajiyar cike da baiti `0`.
    ///
    ///
    /// Duba [`MaybeUninit::zeroed`][zeroed] don misalai na daidai da kuskure amfani da wannan hanyar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ya gina sabon `Pin<Arc<T>>`.
    /// Idan `T` ba yi `Unpin`, sa'an nan `data` za a liƙe a ƙwaƙwalwar ajiyar da kasa da za a koma.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Ya gina sabon `Arc<T>`, dawo da kuskure idan rashi ya kasa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Fara rauni akan count a matsayin 1 wanda yake da rauni akan cewa ke gudanar da dukkan karfi pointers (kinda), ganin std/rc.rs for more info
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Ya gina sabon `Arc` tare da abubuwan da ba a san su ba, yana dawo da kuskure idan rashi ya kasa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Farawa da aka jinkirta:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ya gina sabon `Arc` tare da abubuwan da ba a san su ba, tare da ƙwaƙwalwar ajiyar ta cika da baiti `0`, dawo da kuskure idan rarar ta gaza.
    ///
    ///
    /// Duba [`MaybeUninit::zeroed`][zeroed] don misalai na daidai da kuskure amfani da wannan hanyar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Koma ciki darajar, idan `Arc` yana daidai da daya da karfi tunani.
    ///
    /// In ba haka ba, ana dawo da [`Err`] tare da irin `Arc` ɗin da aka shigo dashi.
    ///
    ///
    /// Wannan zai yi nasara koda kuwa akwai ingantattun nassoshi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Sanya mai nuna alama mai tsabta don tsabtace bayanin mai ƙarfi mai rauni
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Yana gina sabon yanki da aka ƙididdige ƙirar atomatik tare da abubuwan da ba su waye ba.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Farawa da aka jinkirta:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Gina wani sabon atomically reference-kidaya yanki da uninitialized abinda ke ciki, tare da ƙwaƙwalwar ya cika da `0` bytes.
    ///
    ///
    /// Duba [`MaybeUninit::zeroed`][zeroed] don misalai na daidai da kuskure amfani da wannan hanyar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Sabobin tuba zuwa `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Kamar yadda yake tare da [`MaybeUninit::assume_init`], ya rage ga mai kiran don tabbatar da cewa ƙimar ciki tana cikin yanayin farawa.
    ///
    /// Kiran wannan lokacin da abun da ba'a gama kirkirarsa ba yana haifar da halin rashin bayyana.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Farawa da aka jinkirta:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Sabobin tuba zuwa `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kamar yadda yake tare da [`MaybeUninit::assume_init`], ya rage ga mai kiran don tabbatar da cewa ƙimar ciki tana cikin yanayin farawa.
    ///
    /// Kiran wannan lokacin da abun da ba'a gama kirkirarsa ba yana haifar da halin rashin bayyana.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Farawa da aka jinkirta:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Cinye `Arc`, yana dawo da manunin da aka nannade.
    ///
    /// Don kauce wa ƙwaƙwalwar zuba mauni dole canja baya zuwa wani `Arc` amfani [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Yana bayar da ɗan manunin bayanai zuwa bayanan.
    ///
    /// Counididdigar ba ta da tasiri ta kowace hanya kuma ba a cinye `Arc` ba.
    /// The Pointer ne inganci domin idan dai akwai karfi kirga a `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // KYAUTA: Wannan ba zai iya wucewa ta Deref::deref ko RcBoxPtr::inner ba saboda
        // ana buƙatar wannan don riƙe tabbatarwar raw/mut kamar misali
        // `get_mut` iya rubutu ta hanyar nunawa bayan an dawo da Rc ta hanyar `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Ya gina `Arc<T>` daga ma'anar ma'ana.
    ///
    /// Dole ne an dawo da maɓallin ɗan gajeren abu a baya ta hanyar kira zuwa [`Arc<U>::into_raw`][into_raw] inda `U` dole ne ya kasance daidai da daidaitawa kamar `T`.
    /// Wannan gaskiyane mara gaskiya idan `U` shine `T`.
    /// Lura cewa idan `U` ba `T` bane amma yana da girma da daidaitawa, wannan yana da mahimmanci kamar fassarar nassoshi na nau'uka daban-daban.
    /// Duba [`mem::transmute`][transmute] don ƙarin bayani game da waɗanne ƙuntatawa ake amfani da su a wannan yanayin.
    ///
    /// Mai amfani da `from_raw` dole ne ya tabbatar an faɗi takamaiman ƙimar `T` sau ɗaya kawai.
    ///
    /// Wannan aikin bashi da aminci saboda amfani mara kyau na iya haifar da rashin ƙwaƙwalwar ajiya, koda kuwa ba a sami damar dawo da `Arc<T>` da aka dawo ba.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Juya baya zuwa `Arc` don hana zubewa.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Callsarin kira zuwa `Arc::from_raw(x_ptr)` zai zama mara aminci.
    /// }
    ///
    /// // Waswa memorywalwar ajiya ta sami 'yanci lokacin da `x` ya wuce gona da iri a sama, don haka `x_ptr` yanzu yana walwala!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Karkata biya don nemo asalin ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Creatirƙirar sabon maɓallin [`Weak`] zuwa wannan rarar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Wannan Saukewa yayi daidai saboda muna bincika ƙimar a cikin CAS a ƙasa.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // bincika idan ƙarancin mai rauni a halin yanzu "locked";idan haka ne, juya.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: wannan code a halin yanzu watsi da yiwuwar ambaliya
            // cikin usize::MAX;gaba ɗaya Rc da Arc suna buƙatar daidaitawa don magance ambaliyar.
            //

            // Ba kamar na Clone() ba, muna buƙatar wannan don zama Sauke karatu don aiki tare da rubutun da yake zuwa daga `is_unique`, don haka abubuwan da suka faru kafin wannan rubutun su faru kafin wannan karatun.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Tabbatar cewa ba mu ƙirƙirar rauni ba
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Yana samun lambar masu nuna alama ta [`Weak`] zuwa wannan kason.
    ///
    /// # Safety
    ///
    /// Wannan hanya ta kanta ne mai lafiya, amma yin amfani da shi daidai bukatar karin kulawa.
    /// Wani zaren na iya canza raunin rauni a kowane lokaci, gami da yiwuwar kiran wannan hanyar da aiki da sakamakon.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Wannan bayanin tabbatacce ne saboda bamu raba `Arc` ko `Weak` tsakanin zaren.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Idan ƙididdigar rauni ya kasance a kulle a halin yanzu, ƙimar adadin ya kasance 0 kafin ɗaukar makullin.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Yana samun lambar masu alamun (`Arc`) mai ƙarfi zuwa wannan rarar.
    ///
    /// # Safety
    ///
    /// Wannan hanya ta kanta ne mai lafiya, amma yin amfani da shi daidai bukatar karin kulawa.
    /// Wani zaren na iya canza ƙimar ƙarfi a kowane lokaci, gami da yiwuwar kiran wannan hanyar da aiki da sakamakon.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Wannan bayanin tabbatacce ne saboda bamu raba `Arc` tsakanin zaren.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Theara ƙididdigar ƙaƙƙarfan ambaton akan `Arc<T>` da ke haɗuwa da mai bayarwa ta ɗaya.
    ///
    /// # Safety
    ///
    /// Dole ne a samo alamar ta hanyar `Arc::into_raw`, kuma alaƙar `Arc` mai alaƙa dole ne ta kasance mai inganci (watau
    /// countidaya mai ƙarfi dole ne ya zama aƙalla 1) na tsawon wannan hanyar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Wannan bayanin tabbatacce ne saboda bamu raba `Arc` tsakanin zaren.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Riƙe Arc, amma kar a taɓa taɓawa ta hanyar kunsawa a cikin ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Yanzu ƙara ragi, amma kada a sauke sabon rakodi ko dai
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Decrements da karfi reference count a kan `Arc<T>` hade da bayar da Pointer da daya.
    ///
    /// # Safety
    ///
    /// Dole ne a samo alamar ta hanyar `Arc::into_raw`, kuma alaƙar `Arc` mai alaƙa dole ne ta kasance mai inganci (watau
    /// strongidaya mai ƙarfi dole ne ya zama aƙalla 1) yayin kiran wannan hanyar.
    /// Ana iya amfani da wannan hanyar don sakin `Arc` na ƙarshe da ajiyar ajiya, amma ** bai kamata a kira shi ba bayan an saki `Arc` na ƙarshe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Wadanda assertions ne deterministic saboda mun ba shared da `Arc` tsakanin zaren.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Wannan rashin tsaro yana da kyau saboda yayin da wannan baka yake raye muna da tabbacin cewa mai nuna ciki yana aiki.
        // Bugu da ƙari, mun san cewa tsarin `ArcInner` da kansa `Sync` ne saboda bayanan da ke ciki `Sync` ne ma, saboda haka muna da kyau mu ba da lamuni mai canzawa ga waɗannan abubuwan.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Partangaren da bashi da cikakken layi na `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Rushe bayanan a wannan lokacin, kodayake ba za mu iya ba da kuɗin raba akwatin kanta ba (har ila yau akwai alamomi masu rauni waɗanda ke kwance).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Yarda da maras ƙarfi da aka tattara tare da dukkanin ƙa'idodin bayanai masu ƙarfi
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Koma `true` idan biyu `Arc`s nufi da wannan kasafi (a cikin jijiya kama [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Raba `ArcInner<T>` tare da isasshen sarari don ƙimar ciki mai yuwuwa inda ƙimar take da shimfidar wuri.
    ///
    /// Ana kiran aikin `mem_to_arcinner` tare da bayanan bayanai kuma dole ne ya dawo da mai (mai yuwuwa)-muni don `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Yi lissafin layout ta amfani da shimfidar darajar da aka bayar.
        // A baya can, ana lasafta shimfidawa akan furucin `&*(ptr as* const ArcInner<T>)`, amma wannan ya haifar da fassarar da ba daidai ba (duba #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Raba `ArcInner<T>` tare da isasshen sarari don ƙimar ciki mai yuwuwa inda ƙimar ta tanada shimfida, yana dawo da kuskure idan ragin ya kasa.
    ///
    ///
    /// Ana kiran aikin `mem_to_arcinner` tare da bayanan bayanai kuma dole ne ya dawo da mai (mai yuwuwa)-muni don `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Yi lissafin layout ta amfani da shimfidar darajar da aka bayar.
        // A baya can, ana lasafta shimfidawa akan furucin `&*(ptr as* const ArcInner<T>)`, amma wannan ya haifar da fassarar da ba daidai ba (duba #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Alizeaddamar da ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Ya ware `ArcInner<T>` tare da isasshen sarari don ƙimar ciki wanda ba a tantance shi ba.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Raba don `ArcInner<T>` ta amfani da ƙimar da aka bayar.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kwafi ƙimar matsayin baiti
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Yantar da kasafi ba tare da faduwa da abinda ke ciki
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ya raba `ArcInner<[T]>` tare da tsayin da aka bayar.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kwafi abubuwa daga yanki zuwa sabon Arc da aka kasaftawa <\[T\]>
    ///
    /// Ba amintacce saboda mai kiran dole ne ya karɓi mallaki ko ya ɗaure `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Ya gina `Arc<[T]>` daga mai magana wanda aka sani da girmansa.
    ///
    /// Ba a bayyana halaye ba idan girman ya zama ba daidai ba.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic tsaro yayin cloning T abubuwa.
        // A yayin panic, abubuwan da aka rubuta a cikin sabon ArcInner za a sauke su, sannan ƙwaƙwalwar ta sami 'yanci.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Nuni zuwa farkon kashi
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Duk a bayyane.Ka manta mai gadi saboda kar ya sake sabon ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Kwarewa trait amfani ga `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Ya sanya gwano na alamar `Arc`.
    ///
    /// Wannan ya haifar da wani mai nuna alama ga irin wannan kason, yana ƙaruwa da ƙididdigar ƙa'idodi mai ƙarfi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Amfani da annashuwa ordering ne ke nana a nan, kamar yadda ilimi na asali tunani hana sauran zaren daga karyata sharewa da abu.
        //
        // Kamar yadda aka bayyana a cikin [Boost documentation][1], canara takaddar tunani a koyaushe ana iya yi tare da memory_order_relaxed: Sabon nassoshi akan abu kawai za'a iya ƙirƙira shi daga bayanin da yake, kuma wucewa bayanin da ya kasance daga zaren ɗaya zuwa wani dole ne ya riga ya samar da duk wani aiki tare da ake buƙata.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Koyaya muna buƙatar kiyaye kan sake ragowa idan wani yana 'mem: : mantawa da Arcs.
        // Idan ba muyi haka ba ƙidayar na iya malalowa kuma masu amfani zasuyi amfani-bayan kyauta.
        // Mun racily saturate zuwa `isize::MAX` a kan zato cewa akwai ba ~2 biliyan zaren incrementing da reference count a lokaci daya.
        //
        // Wannan branch ba za a taɓa ɗaukarsa a cikin kowane shirin gaskiya ba.
        //
        // Mun zubar saboda irin wannan shirin ya lalace sosai, kuma bamu damu da tallafawa shi ba.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Yana sanya maye gurbi cikin `Arc` da aka bayar.
    ///
    /// Idan akwai wasu alamomin `Arc` ko [`Weak`] zuwa rabe-raben iri ɗaya, to `make_mut` zai ƙirƙiri wani sabon kaso kuma ya kira [`clone`][clone] akan ƙimar ciki don tabbatar da mallakar mallaka ta musamman.
    /// Wannan ne ma ake magana a kai a matsayin clone-on-write.
    ///
    /// Lura cewa wannan ya bambanta da halayyar [`Rc::make_mut`] wanda ke raba duk wasu alamomin `Weak`.
    ///
    /// Duba kuma [`get_mut`][get_mut], wanda zaiyi kasawa maimakon yin cloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ba za a haɗa komai ba
    /// let mut other_data = Arc::clone(&data); // Ba za ta haɗu da bayanan ciki ba
    /// *Arc::make_mut(&mut data) += 1;         // Clones bayanan ciki
    /// *Arc::make_mut(&mut data) += 1;         // Ba za a haɗa komai ba
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ba za a haɗa komai ba
    ///
    /// // Yanzu `data` da `other_data` suna nuni zuwa kasaftawa daban-daban.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Lura cewa muna riƙe duka ra'ayoyi masu ƙarfi da rauni mai rauni.
        // Sabili da haka, sake sakin bayanin namu mai karfi kawai ba, da kansa, zai haifar da ƙwaƙwalwar ajiyar.
        //
        // Yi amfani da Sayi don tabbatar da cewa mun ga kowane rubutu zuwa `weak` da ke faruwa kafin sakin saki (ma'ana, raguwa) zuwa `strong`.
        // Tunda muna riƙe da raunin rauni, babu damar ArcInner da kansa za'a iya raba shi.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Wani mai nuna alama mai karfi yana wanzu, saboda haka dole ne muyi clone.
            // - Addamar da ƙwaƙwalwar ajiya don ba da damar rubuta ƙimar adon kai tsaye.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Shaƙatawa ya isa cikin abin da ke sama saboda wannan asali abin haɓaka ne: koyaushe muna yin tsere tare da raguwar alamomi masu rauni.
            // Mafi munin yanayi, mun ƙare da sanya sabon Arc ba dole ba.
            //

            // Muka kuranye karshe karfi .Ya ce, amma akwai ƙarin rauni refs sauran.
            // Za mu matsar da abubuwan da ke ciki zuwa sabon Arc, kuma za mu ɓata sauran ragowar maɓallan.
            //

            // Note cewa shi ne, ba zai yiwu ga karanta na `weak` don samar usize::MAX (ie, kulle), tun da rauni count iya kawai za a kulle ta a thread tare da wani karfi tunani.
            //
            //

            // Nuna abubuwan da muke nunawa na rauni, don ta iya tsabtace ArcInner kamar yadda ake buƙata.
            //
            let _weak = Weak { ptr: this.ptr };

            // Za a iya satar bayanan kawai, abin da ya rage shi ne Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Mun kasance tafin kafa tunani na ko dai irin;yi karo da ƙarfin ƙarfin ƙidaya.
            //
            this.inner().strong.store(1, Release);
        }

        // Kamar yadda yake tare da `get_mut()`, rashin aminci yana da kyau saboda abin da muke tunani ya kasance na musamman ne don farawa, ko kuma ya zama ɗaya ne yayin da ake sarrafa abubuwan.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Yana dawo da ambaton canzawa zuwa cikin `Arc` da aka bayar, idan babu wasu alamun `Arc` ko [`Weak`] zuwa rabe ɗaya.
    ///
    ///
    /// Yana dawowa [`None`] in ba haka ba, saboda ba aminci ga canzawa darajar da aka raba ba.
    ///
    /// Dubi ma [`make_mut`][make_mut], wanda zai [`clone`][clone] ciki darajar idan akwai sauran pointers.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Wannan rashin tsaro yana da kyau saboda an tabbatar mana cewa mai komowa ya dawo shine kawai * mai nunawa wanda za'a sake dawo dashi zuwa T.
            // Our tunani count wanda tabbas zai zama 1 a wannan lokaci, kuma mun ake bukata da Arc da kanta ya zama `mut`, don haka muna dawo da kawai zai yiwu tunani da ciki data.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Ya dawo da ambaton canzawa cikin `Arc` da aka bayar, ba tare da wani rajistan ba.
    ///
    /// Duba kuma [`get_mut`], wanda ba shi da aminci kuma yana yin cak ɗin da ya dace.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Duk wasu alamomi na `Arc` ko [`Weak`] zuwa rabe-raben iri ɗaya dole ne a soke su tsawon lokacin da aka dawo aro.
    ///
    /// Wannan shi ne trivially al'amarin idan babu irin wannan pointers zama, misali nan da nan bayan `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Muna mai da hankali don kada * ba ƙirƙirar wani tunani wanda yake rufe filayen "count", saboda wannan zai iya zama laƙabi tare da samun dama ta kai tsaye ga ƙididdigar tunani (misali
        // ta `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Ayyade ko wannan bayanin na musamman ne (gami da raƙuman ruwa masu rauni) zuwa bayanan mai tushe.
    ///
    ///
    /// Lura cewa wannan yana buƙatar kulle ƙarancin ƙidayar lissafi.
    fn is_unique(&mut self) -> bool {
        // kulle ƙididdigar mai nuna rauni idan muka bayyana a matsayin wanda ke da rauni mai nuna alama.
        //
        // Alamar saye anan tabbatar da abin da ya faru-kafin dangantaka tare da kowane rubutu zuwa `strong` (musamman a cikin `Weak::upgrade`) kafin raguwar ƙimar `weak` (ta hanyar `Weak::drop`, wanda ke amfani da saki).
        // Idan ingantaccen mai bada shawara bai taba faduwa ba, CAS anan zaiyi kasa saboda haka bamu damu muyi aiki tare ba.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Wannan yana buƙatar zama `Acquire` don aiki tare tare da raguwar ƙirar `strong` a cikin `drop`-damar isa ce kawai ke faruwa yayin da kowane amma banda ƙarshen ƙarshe aka watsar.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // A saki write nan synchronizes tare da karanta a `downgrade`, yadda ya kamata hana sama karanta na `strong` daga faruwa bayan da ya rubuta su.
            //
            //
            self.inner().weak.store(1, Release); // saki da kulle
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Sauke `Arc`.
    ///
    /// Wannan zai rage ƙididdigar ƙididdiga mai ƙarfi.
    /// Idan ƙididdiga masu ƙarfi sun kai sifili to kawai sauran nassoshi (idan akwai) sune [`Weak`], saboda haka zamu `drop` ƙimar ciki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Baya buga komai
    /// drop(foo2);   // Buga "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Saboda `fetch_sub` ya riga ya kasance atomic, bamu buƙatar aiki tare da sauran zaren sai dai idan zamu share abun.
        // Irin wannan ma'anar ta shafi `fetch_sub` na ƙasa zuwa ƙimar `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ana buƙatar wannan shinge don hana sake dawo da amfani da bayanan da share bayanan.
        // Saboda yana da alama `Release`, raguwar ƙididdigar tunani yana aiki tare da wannan shinge na `Acquire`.
        // Wannan yana nufin cewa amfani da data faru kafin ragewa reference count, wanda ya faru kafin wannan shinge, wanda ya faru kafin shafewa na bayanai.
        //
        // Kamar yadda ya bayyana a cikin [Boost documentation][1],
        //
        // > Yana da mahimmanci a aiwatar da duk wata damar isa ga abu a ɗayan
        // > zare (ta hanyar bayanin da ake da shi) don *faruwa kafin* sharewa
        // > abun a wani zaren daban.Ana samun wannan ta hanyar "release"
        // > aiki bayan faduwa tunani (duk wata hanyar isa ga abu
        // > ta hanyar wannan bayanin dole ne ya faru a fili kafin), kuma an
        // > "acquire" aiki kafin share abun.
        //
        // A musamman, yayin da abinda ke ciki na wani Arc yawanci marar sakewa, yana yiwuwa a yi ciki ya rubuta zuwa ga wani abu kamar Mutex<T>.
        // Tunda ba'a sami Mutex ba lokacin da aka share shi, ba zamu iya dogaro da dabaru na aiki tare ba don yin rubutu a zaren A bayyane ga mai lalatawa da ke gudana a zaren B.
        //
        //
        // Har ila yau lura cewa Samun shinge a nan ana iya maye gurbinsa da anauke da kaya, wanda zai iya inganta aikin a cikin yanayi mai wahala.Duba [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Emoƙarin saukar da `Arc<dyn Any + Send + Sync>` zuwa nau'in kankare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Ya gina sabon `Weak<T>`, ba tare da rarraba kowane ƙwaƙwalwar ajiya ba.
    /// Kira [`upgrade`] akan ƙimar dawowa koyaushe yana ba [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Nau'in Taimako don ba da izinin samun damar yin la'akari da ƙididdigar ba tare da yin tabbaci game da filin bayanan ba.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Ya dawo da ɗan alamar abu a kan abin da `T` ya nuna ta wannan `Weak<T>`.
    ///
    /// The Pointer yana aiki ne kawai idan akwai wasu da karfi nassoshi.
    /// Mai nuna alama na iya yin ɗoyi, bai daidaita ba ko ma [`null`] in ba haka ba.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Dukansu suna nuna abu ɗaya
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Arfi a nan yana rayar da shi, don haka har yanzu muna iya samun damar abin.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Amma ba ƙari ba.
    /// // Zamu iya yin weak.as_ptr(), amma samun damar nunawa zai haifar da halayen da ba'a bayyana ba.
    /// // assert_eq! ("hello", amintacce {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Idan mai nuna yana nakuda, za mu mayar da mai tsaron tsaye.
            // Wannan ba zai iya zama adireshin biyan kuɗi mai inganci ba, saboda nauyin biyan kuɗi aƙalla yana daidaita kamar ArcInner (usize).
            ptr as *const T
        } else {
            // KIYAYEWAR: idan is_dangling dawo ƙarya, sa'an nan da Pointer ne dereferencable.
            // Za a iya sauke nauyin biya a wannan lokacin, kuma dole ne mu ci gaba da tabbatarwa, don haka yi amfani da magudi mai amfani.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Cinye `Weak<T>` kuma ya juye da shi a cikin ɗan alama.
    ///
    /// Wannan yana canza mai nuna alama mai rauni zuwa ma'ana mai ɗanɗano, yayin da yake adana ikon mallakar raunin ra'ayoyi guda ɗaya (ƙarancin rauni ba a canza shi ta wannan aikin).
    /// Ana iya juya shi zuwa cikin `Weak<T>` tare da [`from_raw`].
    ///
    /// A wannan hani na samun dama da manufa na akan matsayin da [`as_ptr`] nema.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Ya canza wani ɗan manunin da [`into_raw`] ya ƙirƙira a baya zuwa `Weak<T>`.
    ///
    /// Ana iya amfani da wannan don amintacciyar ƙa'ida (ta hanyar kiran [`upgrade`] daga baya) ko don rarraba raunin rauni ta hanyar sauke `Weak<T>`.
    ///
    /// Yana ɗaukar ikon mallakar raunin ra'ayoyi guda ɗaya (ban da alamomin da [`new`] ya ƙirƙira, saboda waɗannan ba su mallaki komai ba; hanyar har yanzu tana aiki akansu).
    ///
    /// # Safety
    ///
    /// Dole ne mai nuna alama ya samo asali daga [`into_raw`] kuma dole ne har yanzu ya mallaki tasirinsa mai rauni.
    ///
    /// An ba da izinin ƙidaya mai ƙarfi ya kasance 0 a lokacin kiran wannan.
    /// Koyaya, wannan yana ɗaukar ikon mallakar raunin rashi guda ɗaya wanda a halin yanzu aka wakilta azaman ɗan nuna alama (ƙididdigar rauni ba a canza shi ta wannan aikin ba) sabili da haka dole ne a haɗa shi tare da kiran da ya gabata zuwa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Rushewar rauni na ƙarshe.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Duba Weak::as_ptr don mahallin kan yadda aka samo bayanin shigar da bayanai.

        let ptr = if is_dangling(ptr as *mut T) {
            // Wannan shi ne wani dangling rauni.
            ptr as *mut ArcInner<T>
        } else {
            // In ba haka ba, an tabbatar mana cewa mai nuna alama ya fito ne daga Raunin da ba shi da wahala.
            // KYAUTA: data_offset ba lafiya a kira, kamar yadda ptr nassoshi na ainihi (mai yiwuwa ya ragu) T.
            let offset = unsafe { data_offset(ptr) };
            // Don haka, zamu juya baya ga samun RcBox duka.
            // KYAUTA: alamar ta samo asali ne daga Rauni, saboda haka wannan daidaitaccen hadari ne.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KIYAYEWAR: mu a yanzu sun gano ainihin rauni akan, don haka zai iya haifar da da mai rauni.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Attoƙarin haɓaka maɓallin `Weak` zuwa [`Arc`], jinkirta faduwar ƙimar ciki idan tayi nasara.
    ///
    ///
    /// Yana dawo da [`None`] idan aka sauke darajar ciki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hallaka dukkan alamomi masu ƙarfi.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Muna amfani da madauki na CAS don haɓaka ƙididdiga mai ƙarfi maimakon fetch_add saboda wannan aikin bazai taɓa ɗaukar ƙididdigar tunani daga sifili zuwa ɗaya ba.
        //
        //
        let inner = self.inner()?;

        // Sauke kaya saboda kowane rubutu na 0 wanda zamu iya lura dashi ya bar filin a cikin yanayin sifili na dindindin (don haka karatun "stale" na 0 yayi kyau), kuma duk wani ƙimar da aka tabbatar ta hanyar CAS ɗin da ke ƙasa.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Duba ra'ayoyi a cikin `Arc::clone` don me yasa muke yin hakan (don `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Saukewa yana da kyau don shari'ar rashin nasara saboda ba mu da wani tsammanin game da sabuwar jihar.
            // Sayi wajibi ne don shari'ar nasara don aiki tare da `Arc::new_cyclic`, lokacin da za'a iya ƙaddamar da ƙimar ciki bayan an riga an ƙirƙiri bayanan nassi na `Weak`.
            // A wannan yanayin, muna sa ran kiyaye ƙimar da aka fara.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null ya duba a sama
                Err(old) => n = old,
            }
        }
    }

    /// Yana samun lambar masu alamun (`Arc`) masu ƙarfi da ke nuna wannan kason.
    ///
    /// Idan an ƙirƙiri `self` ta amfani da [`Weak::new`], wannan zai dawo 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Samun wani kimantawa na yawan `Weak` pointers nuna wannan kasafi.
    ///
    /// Idan aka ƙirƙira `self` ta amfani da [`Weak::new`], ko kuma idan ba a sami sauran alamomi masu ƙarfi ba, wannan zai dawo 0.
    ///
    /// # Accuracy
    ///
    /// Saboda aiwatar da bayanai, da koma darajar iya zama a kashe ta 1 a ko dai shugabanci a lokacin da wasu zaren an sabawa wani `Arc`s ko`Weak`s nuna wannan kasafi.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Tun da mun lura cewa akwai aƙalla mai ƙarfi mai ƙarfi bayan karanta ƙididdigar rauni, mun sani cewa ƙaƙƙarfan ra'ayoyin ra'ayoyi (gabatar a duk lokacin da duk wani bayani mai ƙarfi ke raye) yana nan har yanzu lokacin da muka lura da ƙididdigar rauni, kuma saboda haka za mu iya cire shi cikin aminci.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Ya dawo da `None` lokacin da mai nunin yake yawo kuma babu wani kaso `ArcInner`, (ma'ana, lokacin da `Weak::new` ya ƙirƙiri wannan `Weak`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Muna mai da hankali don kada *ba* ƙirƙirar abin da zai rufe filin "data" ba, saboda ana iya canza filin a lokaci guda (misali, idan aka bar `Arc` na ƙarshe, za a sauke filin bayanan a wuri).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Koma `true` idan biyu `Weak`s nufi da wannan kasafi (kama da [`ptr::eq`]), ko idan da ba zamu nuna wa wani kasafi (saboda su aka halicce su da `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Tun da yake wannan kwantanta pointers yana nufin cewa `Weak::new()` zai daidaita juna, ko da yake ba su nuna wani kasafi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Kwatanta `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Yana yin gwano na nuna alama na `Weak` wanda ke nuni zuwa kason.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Dubi comments a Arc::clone() for me ya sa wannan ne annashuwa.
        // Wannan na iya amfani da fetch_add (yin watsi da makullin) saboda ƙarancin rauni ana kulle ne kawai inda babu wasu * alamu masu rauni a rayuwa.
        //
        // (Don haka ba za mu iya gudanar da wannan lambar a wannan yanayin ba).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Duba ra'ayoyi a cikin Arc::clone() don me yasa muke yin hakan (don mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ya gina sabon `Weak<T>`, ba tare da rarraba ƙwaƙwalwa ba.
    /// Kira [`upgrade`] akan ƙimar dawowa koyaushe yana ba [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Sauke alamar `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Baya buga komai
    /// drop(foo);        // Buga "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Idan muka gano cewa mun kasance na karshe rauni akan, sa'an nan ta lokaci zuwa deallocate da data gaba ɗaya.Dubi tattaunawa a Arc::drop() game da memory orderings
        //
        // Ba lallai ba ne a bincika yanayin kulle a nan, saboda ƙididdigar rauni za a iya kullewa idan akwai ƙarancin ƙwararraki mara ƙarfi, ma'ana cewa digo zai iya ci gaba ne kawai a kan wannan ragowar ragowar mai ƙarfi, wanda zai iya faruwa ne bayan an saki makullin.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Muna yin wannan ƙwarewar anan, kuma ba azaman ingantawa gabaɗaya akan `&T` ba, saboda hakan zai iya ƙara tsada ga dukkan matakan daidaito akan ragi.
/// Muna ɗauka cewa ``ana amfani da Arc`s don adana manyan ƙimomi, waɗanda ke jinkirin haɗawa, amma kuma suna da nauyi don bincika daidaito, wanda ke haifar da wannan kuɗin don biya cikin sauƙi.
///
/// Hakanan yana da damar samun kwafin `Arc` guda biyu, wanda ke nuna daidai, fiye da biyu&&T`s.
///
/// Zamu iya yin hakan ne kawai lokacin da `T: Eq` a matsayin `PartialEq` na iya zama da sassauci da gangan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Daidaitan for biyu `Arc`s.
    ///
    /// Arc's guda biyu daidai ne idan ƙimarsu ta ciki daidai take, koda kuwa an adana su a cikin rabon daban.
    ///
    /// Idan `T` shima ya aiwatar da `Eq` (wanda ke nuna rashin daidaito), biyu `` Arc '' da ke nuni zuwa rabe-raben duka daidai suke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Rashin daidaitaka don biyu `Arc`s.
    ///
    /// Abubuwa biyu na Arc ba daidai ba ne idan ƙimar cikin su ba daidai ba ce.
    ///
    /// Idan `T` shima ya aiwatar da `Eq` (wanda ke nuna rashin daidaito), biyu `` Arc '' da ke nuni zuwa ƙima ɗaya ba daidaito bane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Kwatanta kwatankwacin biyu ``Arc`s.
    ///
    /// Ana kwatanta su biyun ta hanyar kiran `partial_cmp()` akan ƙimomin su na ciki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kasa da kwatancen abubuwa biyu na Arc.
    ///
    /// Ana kwatanta su biyun ta hanyar kiran `<` akan ƙimomin su na ciki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Kasa da ko daidai da' kwatankwacin 'Arc`s guda biyu.
    ///
    /// Ana kwatanta su biyun ta hanyar kiran `<=` akan ƙimomin su na ciki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Mafi girma fiye da kwatancen abubuwa biyu na 'Arc`s.
    ///
    /// The biyu suna idan aka kwatanta da kiran `>` a kan su ciki dabi'u.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Mafi girma ko daidai da kwatancen' Arc`s guda biyu.
    ///
    /// Ana kwatanta su biyun ta hanyar kiran `>=` akan ƙimomin su na ciki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Kwatanta biyu ``Arc`s.
    ///
    /// Ana kwatanta su biyun ta hanyar kiran `cmp()` akan ƙimomin su na ciki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Irƙiri sabon `Arc<T>`, tare da ƙimar `Default` don `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Sanya yanki da aka kidaya yanki kuma cika shi ta hanyar sarrafa abubuwa '' v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Sanya `str` mai ƙididdigar tunani kuma kwafa `v` a ciki.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Sanya `str` mai ƙididdigar tunani kuma kwafa `v` a ciki.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Matsar da abin da aka yi dambe zuwa sabon, rabon da aka kirga.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Sanya yanki yanki da aka kirga kuma a motsa abubuwan `` v '' a ciki.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Bada Vec ɗin don yantar da ƙwaƙwalwar ajiyarsa, amma ba halakar da abinda ke ciki ba
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Eachauki kowane ɗayan a cikin `Iterator` kuma ya tattara shi cikin `Arc<[T]>`.
    ///
    /// # Halayen aiki
    ///
    /// ## A general hali
    ///
    /// A general hali, tattara a cikin `Arc<[T]>` aka yi ta farko tattara a cikin wani `Vec<T>`.Wannan shine, lokacin rubuta wadannan:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// wannan yana nuna kamar mun rubuta:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Saitin farko na kason ya faru anan.
    ///     .into(); // Raba na biyu don `Arc<[T]>` ya faru anan.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Wannan zai ware sau da yawa yadda ake bukata domin gina da `Vec<T>` sa'an nan shi zai ware da zarar for juya `Vec<T>` cikin `Arc<[T]>`.
    ///
    ///
    /// ## Masu ba da ma'anar tsayi
    ///
    /// Lokacin da ka `Iterator` aiwatar `TrustedLen` kuma shi ne na wani daidai size, guda kasafi za a yi don `Arc<[T]>`.Misali:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Raba guda kawai yake faruwa anan.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// trait na Musamman wanda aka yi amfani dashi don tarawa cikin `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Wannan shine batun don mai magana da `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // KYAUTA: Muna buƙatar tabbatar da cewa mai gabatarwar yana da tsayi daidai kuma muna da.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Komawa zuwa aiwatarwar al'ada.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Sami daidaituwa tsakanin `ArcInner` don biyan kuɗi a bayan mai nuna alama.
///
/// # Safety
///
/// Dole ne mai nunawa ya nuna (kuma yana da ingantaccen metadata don) misali mai inganci na T a baya, amma an yarda a sauke T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // A mayar da unsized darajar ƙarshen ArcInner.
    // Saboda RcBox ne repr(C), shi zai zama ko da yaushe na karshe filin a ƙwaƙwalwar ajiyar.
    // KYAUTA: tunda kawai nau'ikan da ba'a iya tantance su ba sune yanka, abubuwa trait,
    // da nau'ikan waje, abin da ake bukata na aminci a halin yanzu ya isa ya biya bukatun align_of_val_raw;wannan shi ne wani aiwatar daki-daki, daga cikin harshen da za su iya ba za a dogara a kan waje na std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}