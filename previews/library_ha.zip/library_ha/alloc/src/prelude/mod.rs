//! Rabon Prelude
//!
//! Manufar wannan tsarin shine don sauƙaƙa shigo da abubuwan da aka saba amfani dasu na `alloc` crate ta hanyar ƙara shigarwar duniya zuwa saman matakan:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;