use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Kwarewa trait amfani ga Vec::from_iter
///
/// ## Graphungiyar wakilan:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // A na kowa yanayin da ake wucewa a vector cikin wani aiki wanda nan da nan sake tattara a cikin wani vector.
        // Zamu iya gajarta wannan idan har IntoIter bai ci gaba ba sam.
        // Lokacin da aka ci gaba Hakanan zamu iya sake amfani da ƙwaƙwalwar ajiyar kuma matsar da bayanan zuwa gaba.
        // Amma mu kawai yi haka a lokacin da sakamakon Vec zai ba da karin sauran iya aiki fiye da samar da shi ta hanyar da Generic FromIterator aiwatar yi.
        //
        // Wannan ya rage mata ba ya zama tilas a matsayin Vec ta kasafi hali ne da ganganci unspecified.
        // Amma yana da wani ra'ayin mazan jiya zabi.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // dole ne ya wakilta zuwa spec_extend() tunda extend() da kanta ta wakilta zuwa takamaiman_tare da komai na Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Wannan yana amfani da `iterator.as_slice().to_vec()` tunda spec_extend dole ne ya ɗauki ƙarin matakai don yin tunani game da ƙarfin ƙarshe + tsawon kuma don haka ƙara yin aiki.
// `to_vec()` kai tsaye allocates da daidai adadin, kuma ya cika shi daidai.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): tare da cfg(test) hanyar `[T]::to_vec` ta asali, wacce ake buƙata don wannan ma'anar hanyar, ba ta samu.
    // Maimakon amfani da `slice::to_vec` aiki wanda shi ne samuwa ne kawai tare da cfg(test) NB ganin slice::hack module a slice.rs don ƙarin bayani
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}