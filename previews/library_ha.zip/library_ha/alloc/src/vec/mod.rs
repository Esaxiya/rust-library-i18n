//! Nau'in nau'ikan tsararru masu saurin girma tare da kayan aikin da aka ware, aka rubuta `Vec<T>`.
//!
//! Vectors suna da zane-zane na `O(1)`, tura murfin `O(1)` (zuwa ƙarshe) da `O(1)` pop (daga ƙarshen).
//!
//!
//! Vectors sun tabbatar da cewa basu taɓa raba fiye da baiti `isize::MAX` ba.
//!
//! # Examples
//!
//! Kuna iya ƙirƙirar [`Vec`] a bayyane tare da [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ko ta amfani da [`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // sifili goma
//! ```
//!
//! Kuna iya ƙimar [`push`] akan ƙarshen vector (wanda zai haɓaka vector kamar yadda ake buƙata):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Valuesimar faɗakarwa tana aiki iri ɗaya iri ɗaya:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors kuma suna tallafawa yin nuni (ta hanyar [`Index`] da [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Nau'in tsararru mai saurin girma, wanda aka rubuta azaman `Vec<T>` kuma aka furta 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// An samar da [`vec!`] macro don sanya farawa ta zama mafi dacewa:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Hakanan yana iya ƙaddamar da kowane nau'i na `Vec<T>` tare da ƙimar da aka bayar.
/// Wannan na iya zama mafi inganci fiye da aiwatar da kasaftawa da farawa a matakai daban-daban, musamman yayin fara vector na sifili:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Mai zuwa daidai yake, amma mai yiwuwa a hankali:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Don ƙarin bayani, duba [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Yi amfani da `Vec<T>` matsayin m tari:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Buga 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Nau'in `Vec` yana ba da damar samun damar ƙimomi ta hanyar nuni, saboda yana aiwatar da [`Index`] trait.Misali zai zama mafi bayyane:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // zai nuna '2'
/// ```
///
/// Koyaya yi hankali: idan kayi ƙoƙarin samun damar bayanin wanda baya cikin `Vec`, software ɗinka zai panic!Ba za ku iya yin wannan ba:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Yi amfani da [`get`] da [`get_mut`] idan kuna son bincika ko alamun suna cikin `Vec`.
///
/// # Slicing
///
/// `Vec` na iya zama mai canzawa.A gefe guda, yanka abubuwa ne kawai na karatu.
/// Don samun [slice][prim@slice], yi amfani da [`&`].Example:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... da kuma cewa ke nan!
/// // Hakanan zaka iya yin shi kamar haka:
/// let u: &[usize] = &v;
/// // ko kamar wannan:
/// let u: &[_] = &v;
/// ```
///
/// A cikin Rust, ya fi zama ruwan dare yankan yanki a matsayin muhawara maimakon vectors lokacin da kawai kuke son samar da damar karantawa.Wannan ke [`String`] da [`&str`].
///
/// # Acarfi da sake raba wuri
///
/// Capacityarfin vector shine adadin sarari da aka ware don kowane abubuwan future wanda za'a ƙara akan vector.Wannan ba za a rude shi da *tsayin* vector ba, wanda ke tantance adadin ainihin abubuwa a cikin vector.
/// Idan wani vector ta tsawon wuce iyãwarsa, iyãwarsa za ta atomatik a karu, amma da abubuwa za su yi da za a reallocated.
///
/// Misali, vector mai ƙarfin 10 da tsayi 0 zai zama vector mara komai tare da sarari don ƙarin abubuwa 10.Turawa 10 ko m abubuwa uwa da vector ba zai canza iyãwarsa ko hanyar reallocation faruwa.
/// Koyaya, idan tsayin vector ya ƙaru zuwa 11, dole ne ya sake sanya wuri, wanda zai iya yin jinkiri.A saboda wannan dalili, shi ne shawarar yin amfani da [`Vec::with_capacity`] a duk lokacin da zai yiwu ya saka yadda babban vector ana sa ran samun.
///
/// # Guarantees
///
/// Saboda ta wuce yarda da muhimman hakkokin yanayi, `Vec` ya sa da yawa daga tabbacin game da zane.Wannan na tabbatar da cewa yana da kamar yadda low-sama kamar yadda zai yiwu a general hali, kuma za a iya daidai nemi a m hanyoyi da unsafe code.Lura cewa waɗannan garanti suna komawa zuwa `Vec<T>` wanda bai cancanta ba.
/// Idan ƙarin irin sigogi suna kara (misali, don tallafa wa al'ada allocators), overriding su Predefinicións iya canza hali.
///
/// Mafi mahimmanci, `Vec` shine kuma koyaushe zai zama sau uku (alama, iya aiki, tsayi) sau uku.Babu ƙari, babu ƙasa.Umurnin waɗannan filayen kwata-kwata ba a bayyana su ba, kuma ya kamata ku yi amfani da hanyoyin da suka dace don gyara waɗannan.
/// Mai nunawa ba zai taɓa zama mara amfani ba, saboda haka wannan nau'in nullin-gyara ne.
///
/// Koyaya, mai nuna alama bazai nuna ainihin abin da aka ba shi ba.
/// Musamman, idan kun gina `Vec` tare da ƙarfin 0 ta hanyar [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], ko ta kiran [`shrink_to_fit`] akan Vec mara amfani, ba zai ba da ƙwaƙwalwa ba.Hakanan, idan kun adana nau'ikan sifili marasa girma a cikin `Vec`, ba zai ba su sarari ba.
/// *Lura cewa a cikin wannan yanayin `Vec` na iya ba da rahoton [`capacity`] na 0*.
/// `Vec` zai rarraba idan kuma kawai idan [`mem: : size_of::<T>`` '' () * capacity()> 0`.
/// Gabaɗaya, bayanan rabe-raben Vec suna da wayo sosai-idan kuna da niyyar ware ƙwaƙwalwar ajiya ta amfani da `Vec` kuma kuyi amfani da shi don wani abu dabam (ko dai ku wuce zuwa lambar da ba amintacciya ba, ko kuma ku girka tarin-ƙwaƙwalwar ajiyar ku), ku tabbata don rarraba wannan ƙwaƙwalwar ta amfani da `from_raw_parts` don dawo da `Vec` sannan sauke shi.
///
/// Idan `Vec`*yana da* rabewar ƙwaƙwalwa, to, ƙwaƙwalwar da yake nunawa tana kan dutsen (kamar yadda mai tsarawa ya tsara Rust an saita shi don amfani ta tsohuwa), kuma mai nuna maki zuwa [`len`] ya fara, abubuwa masu rikitarwa cikin tsari (abin da zaku duba idan kun tilasta shi zuwa yanki), sannan biye da ``'' damar`] ``, '' (`` len`] a hankalce ba a san shi ba, abubuwa masu rikitarwa.
///
///
/// A vector dauke da abubuwa `'a'` da `'b'` tare da damar 4 za a iya visualized matsayin kasa.Sashin sama shine tsarin `Vec`, ya ƙunshi mai nunawa zuwa kan rabon cikin tarin, tsayi da iyawa.
/// Partasan ɓangaren shine kasaftawa a kan tsibirin, maɓallin ƙwaƙwalwar ajiya mai rikitarwa.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** wakiltar memory cewa ba initialized, ganin [`MaybeUninit`].
/// - Note: ABI bashi da karko kuma `Vec` baya bada garantin game da shimfidar ƙwaƙwalwar sa (gami da tsarin filayen).
///
/// `Vec` ba zai yi wani "small optimization" inda abubuwa suna zahiri adana a kan tari saboda dalilai guda biyu:
///
/// * Zai sa ya zama da wahala ga lambar da ba amintacciya ta sarrafa `Vec` daidai.Abinda ke ciki na wani `Vec` zai ba su da wani barga adireshin idan shi aka kawai motsa, kuma zai zama mafi wuya ga sanin ko idan wani `Vec` ya zahiri kasaftawa ƙwaƙwalwar.
///
/// * Zai hukunta babban shari'ar, haifar da ƙarin branch akan kowane damar.
///
/// `Vec` ba zai taƙaita kansa kai tsaye ba, koda kuwa babu komai a ciki.Wannan yana tabbatar da cewa babu kason da ba dole ba ko rarraba wuraren kasuwanci zai faru.Bude wani `Vec` sannan cika shi zuwa daidai da wannan [`len`] bai haifar da kira ga mai raba shi ba.Idan kuna son 'yantar da ƙwaƙwalwar da ba a yi amfani da ku ba, yi amfani da [`shrink_to_fit`] ko [`shrink_to`].
///
/// [`push`] kuma [`insert`] zai taba (re) ware idan ruwaito iya aiki ne ya ishe.[`push`] da [`insert`]*zasu*(sake) rarraba idan [``len`] ''==`['' iya ''.Wannan ne, da ya ruwaito iya aiki ne gaba daya m, kuma za a iya dogara.Yana iya ma iya amfani da su da hannu yantar da ƙwaƙwalwar kasaftawa da wani `Vec` idan ake so.
/// Bulk sa hanyoyin *yiwu* reallocate, ko a lokacin da ba dole.
///
/// `Vec` baya bada garantin wani musamman girma dabarun lokacin reallocating a lokacin da ya cika, kuma idan [`reserve`] aka kira.A halin yanzu dabarun ne na asali, kuma shi iya tabbatar da kyawawa in yi amfani da wadanda ba m girma factor.Abin da dabarun da aka yi amfani da nufin mana garanti *Ya*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, da [`Vec::with_capacity(n)`][`Vec::with_capacity`], duk zasu samar da `Vec` tare da madaidaicin ƙarfin da aka nema.
/// Idan [``len`]] '==' ['iya aiki`],, (kamar yadda lamarin yake ga [`vec!`] macro), to za a iya canza `Vec<T>` zuwa kuma daga [`Box<[T]>`][owned slice] ba tare da sake kewayawa ko motsa abubuwan ba.
///
/// `Vec` ba zai sake sake rubuta wani bayanan da aka cire daga gare shi ba, amma kuma ba zai adana shi musamman ba.Memorywaƙwalwar da ba ta da ilimi shine sararin samaniya wanda zai iya amfani da shi yadda yake so.Gabaɗaya zai iya yin duk abin da ya fi dacewa ko kuma sauƙin aiwatarwa.Kar ka dogara da bayanan da aka cire don sharewa don dalilan tsaro.
/// Koda koda ka sauke `Vec`, za'a iya sake amfani dashi ta wani `Vec`.
/// Ko da kuwa ba za a fara tuna ƙwaƙwalwar `` Vec '' da farko ba, hakan na iya faruwa da gaske saboda mai ba da damar yin la'akari da wannan tasirin da dole ne a kiyaye shi.
/// Akwai wata harka wacce ba za mu fasa ba, duk da haka: ta amfani da lambar `unsafe` don rubutawa ga ƙarfin da ya wuce iyaka, sannan ƙara tsayi don daidaitawa, yana aiki koyaushe.
///
/// A halin yanzu, `Vec` baya bada garantin tsari wanda aka sauke abubuwa.
/// Umurnin ya canza a baya kuma yana iya sake canzawa.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Hanyoyin da suka dace
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Ya gina sabon, mara komai `Vec<T>`.
    ///
    /// vector ba zai rarraba ba har sai an tura abubuwa akan sa.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Ya gina sabon, mara komai `Vec<T>` tare da iyakantaccen iya aiki.
    ///
    /// vector zai iya riƙe abubuwan `capacity` daidai ba tare da sake sanya wuri ba.
    /// Idan `capacity` 0 ne, vector ba zai rarraba ba.
    ///
    /// Yana da mahimmanci a lura cewa kodayake vector da aka dawo yana da *iyawa* an bayyana, vector zai sami tsayin *sifili*.
    ///
    /// Domin bayani game da banbanci tsakanin tsawon da kuma iya aiki, duba *[Capacity da reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector bai ƙunshi abubuwa ba, kodayake yana da ƙarfin ƙari
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ana yin waɗannan duka ba tare da sake sanya wuri ba ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... amma wannan na iya sa vector reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Creatirƙira `Vec<T>` kai tsaye daga albarkatun haɗin wani vector.
    ///
    /// # Safety
    ///
    /// Wannan ba shi da aminci sosai, saboda yawan masu canzawa waɗanda ba a bincika su ba:
    ///
    /// * `ptr` yana buƙatar an rarraba shi a baya ta hanyar ``String`]/``Vec<T>`` (aƙalla, mai yiwuwa ya zama ba daidai ba idan ba haka ba).
    /// * `T` yana buƙatar samun girman girma da daidaitawa kamar abin da aka rarraba `ptr` da shi.
    ///   (`T` samun daidaitaccen tsari bai isa ba, daidaitawa yana buƙatar daidaita daidai don biyan buƙatun [`dealloc`] cewa dole ne a rarraba ƙwaƙwalwa kuma a raba shi da tsari ɗaya.)
    ///
    /// * `length` yana buƙatar zama ƙasa da ko daidai da `capacity`.
    /// * `capacity` bukatar ya zama da damar cewa akan aka kasaftawa tare.
    ///
    /// Qetare wadannan na iya haifar da matsaloli kamar barna a cikin allocator ta ciki data Tsarin.Alal misali shi ne **ba** lafiya a gina wani `Vec<u8>` daga wani akan wani C `char` tsararru da tsawon `size_t`.
    /// Hakanan ba shi da aminci a gina ɗayan daga `Vec<u16>` da tsayinsa, saboda mai rarraba yana kula da daidaitawa, kuma waɗannan nau'ikan iri biyu suna da daidaito iri-iri.
    /// An rarraba abin ajiyewa tare da jeri 2 (na `u16`), amma bayan juya shi zuwa cikin `Vec<u8>` za'a raba shi da jeri 1.
    ///
    /// A ikon mallakar `ptr` ne yadda ya kamata canjawa wuri zuwa `Vec<T>` wanda zai iya sa'an nan deallocate, reallocate ko canza abinda ke ciki na memory ishãra zuwa da Pointer a nufin.
    /// Tabbatar cewa babu wani abu da yake amfani da alamar bayan kiran wannan aikin.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Sabunta wannan lokacin da aka ƙarfafa vec_into_raw_parts.
    ///     // Hana masu ɓarnar `` v '' don haka muna cikin cikakken ikon rarrabawa.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Fitar da mahimman bayanai masu mahimmanci game da `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Wara rubutun ƙwaƙwalwa tare da 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sanya komai tare cikin Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Ya gina sabon, mara komai `Vec<T, A>`.
    ///
    /// vector ba zai rarraba ba har sai an tura abubuwa akan sa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Ya gina sabon, mara komai `Vec<T, A>` tare da iyakantaccen iya aiki tare da mai ba shi tanadin.
    ///
    /// vector zai iya riƙe abubuwan `capacity` daidai ba tare da sake sanya wuri ba.
    /// Idan `capacity` 0 ne, vector ba zai rarraba ba.
    ///
    /// Yana da mahimmanci a lura cewa kodayake vector da aka dawo yana da *iyawa* an bayyana, vector zai sami tsayin *sifili*.
    ///
    /// Domin bayani game da banbanci tsakanin tsawon da kuma iya aiki, duba *[Capacity da reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector bai ƙunshi abubuwa ba, kodayake yana da ƙarfin ƙari
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ana yin waɗannan duka ba tare da sake sanya wuri ba ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... amma wannan na iya sa vector reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Creatirƙira `Vec<T, A>` kai tsaye daga albarkatun haɗin wani vector.
    ///
    /// # Safety
    ///
    /// Wannan ba shi da aminci sosai, saboda yawan masu canzawa waɗanda ba a bincika su ba:
    ///
    /// * `ptr` yana buƙatar an rarraba shi a baya ta hanyar ``String`]/``Vec<T>`` (aƙalla, mai yiwuwa ya zama ba daidai ba idan ba haka ba).
    /// * `T` yana buƙatar samun girman girma da daidaitawa kamar abin da aka rarraba `ptr` da shi.
    ///   (`T` samun daidaitaccen tsari bai isa ba, daidaitawa yana buƙatar daidaita daidai don biyan buƙatun [`dealloc`] cewa dole ne a rarraba ƙwaƙwalwa kuma a raba shi da tsari ɗaya.)
    ///
    /// * `length` yana buƙatar zama ƙasa da ko daidai da `capacity`.
    /// * `capacity` bukatar ya zama da damar cewa akan aka kasaftawa tare.
    ///
    /// Qetare wadannan na iya haifar da matsaloli kamar barna a cikin allocator ta ciki data Tsarin.Alal misali shi ne **ba** lafiya a gina wani `Vec<u8>` daga wani akan wani C `char` tsararru da tsawon `size_t`.
    /// Hakanan ba shi da aminci a gina ɗayan daga `Vec<u16>` da tsayinsa, saboda mai rarraba yana kula da daidaitawa, kuma waɗannan nau'ikan iri biyu suna da daidaito iri-iri.
    /// An rarraba abin ajiyewa tare da jeri 2 (na `u16`), amma bayan juya shi zuwa cikin `Vec<u8>` za'a raba shi da jeri 1.
    ///
    /// A ikon mallakar `ptr` ne yadda ya kamata canjawa wuri zuwa `Vec<T>` wanda zai iya sa'an nan deallocate, reallocate ko canza abinda ke ciki na memory ishãra zuwa da Pointer a nufin.
    /// Tabbatar cewa babu wani abu da yake amfani da alamar bayan kiran wannan aikin.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Sabunta wannan lokacin da aka ƙarfafa vec_into_raw_parts.
    ///     // Hana masu ɓarnar `` v '' don haka muna cikin cikakken ikon rarrabawa.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Fitar da mahimman bayanai masu mahimmanci game da `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Wara rubutun ƙwaƙwalwa tare da 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sanya komai tare cikin Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Bayar da `Vec<T>` a cikin kayan haɗin sa.
    ///
    /// Dawo da raw mauni zuwa muhimmi data, da tsawon vector (a cikin abubuwa), da kuma kasaftawa damar da data (a cikin abubuwa).
    /// Waɗannan maganganu iri ɗaya ne a cikin tsari ɗaya kamar hujjojin zuwa [`from_raw_parts`].
    ///
    /// Bayan kiran wannan aikin, mai kiran yana da alhakin ƙwaƙwalwar ajiyar da `Vec` ta sarrafa a baya.
    /// Hanya guda daya da za a yi hakan ita ce ta maida mai nunawa, tsayi, da iyawa ya koma cikin `Vec` tare da aikin [`from_raw_parts`], wanda hakan zai ba mai halakarwa damar yin tsaftar.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Yanzu za mu iya yin canje-canje ga abubuwan da aka haɗa, kamar aikawa da ɗan madaidaicin maɓallin zuwa nau'in da ya dace.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Bayar da `Vec<T>` a cikin kayan haɗin sa.
    ///
    /// Mayar da ɗan manunin bayanai zuwa bayanan da ke tushe, tsawon vector (a cikin abubuwa), ƙarfin rabon bayanan (a cikin abubuwa), da kuma mai rarrabawa.
    /// Waɗannan maganganu iri ɗaya ne a cikin tsari ɗaya kamar hujjojin zuwa [`from_raw_parts_in`].
    ///
    /// Bayan kiran wannan aikin, mai kiran yana da alhakin ƙwaƙwalwar ajiyar da `Vec` ta sarrafa a baya.
    /// Hanya guda daya da za a yi hakan ita ce ta maida mai nunawa, tsayi, da iyawa ya koma cikin `Vec` tare da aikin [`from_raw_parts_in`], wanda hakan zai ba mai halakarwa damar yin tsaftar.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Yanzu za mu iya yin canje-canje ga abubuwan da aka haɗa, kamar aikawa da ɗan madaidaicin maɓallin zuwa nau'in da ya dace.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Ya dawo da adadin abubuwan da vector zai iya riƙe ba tare da sake sake wuri ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Yana ajiyar iya aiki don akalla abubuwa `additional` da za'a saka a cikin `Vec<T>` da aka bayar.
    /// Mayididdigar na iya keɓe ƙarin sarari don kauce wa wuraren sake wurare da yawa.
    /// Bayan kiran `reserve`, ƙarfin zai fi girma ko daidaita da `self.len() + additional`.
    /// Babu komai idan iyawa ya isa.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya wuce by00 `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Yana ajiyar mafi ƙarancin ƙarfi don daidai abubuwan ƙarin `additional` da za a saka a cikin `Vec<T>` da aka bayar.
    ///
    /// Bayan kiran `reserve_exact`, ƙarfin zai fi girma ko daidaita da `self.len() + additional`.
    /// Babu komai idan ƙarfin ya riga ya isa.
    ///
    /// Lura cewa mai ba da kuɗin na iya ba tarin wuri fiye da yadda yake buƙata.
    /// Sabili da haka, ba za a dogara da ƙarfin iya zama daidai kaɗan.
    /// Fi son `reserve` idan ana tsammanin shigarwar future.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya cika `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Yayi ƙoƙari don adana iya aiki don aƙalla ƙarin abubuwan da za a saka `additional` a cikin `Vec<T>` da aka bayar.
    /// Mayididdigar na iya keɓe ƙarin sarari don kauce wa wuraren sake wurare da yawa.
    /// Bayan kiran `try_reserve`, ƙarfin zai fi girma ko daidaita da `self.len() + additional`.
    /// Babu komai idan iyawa ya isa.
    ///
    /// # Errors
    ///
    /// Idan da damar yawo, ko da allocator rahoton wani gazawar, sa'an nan da wani kuskure da aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Yi ajiyar ƙwaƙwalwar ajiya, fita idan ba za mu iya ba
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Yanzu mun san cewa wannan ba zai iya ba OOM ba a tsakiyar aikinmu mai rikitarwa
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // mai rikitarwa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Yayi ƙoƙari don adana ƙananan ƙarfin don ainihin abubuwan `additional` da za a saka a cikin `Vec<T>` da aka bayar.
    /// Bayan kiran `try_reserve_exact`, capacityarfin zai fi girma ko daidaita da `self.len() + additional` idan ya dawo `Ok(())`.
    ///
    /// Babu komai idan ƙarfin ya riga ya isa.
    ///
    /// Lura cewa mai ba da kuɗin na iya ba tarin wuri fiye da yadda yake buƙata.
    /// Sabili da haka, ba za a dogara da ƙarfin iya zama daidai kaɗan.
    /// Fi son `reserve` idan ana tsammanin shigarwar future.
    ///
    /// # Errors
    ///
    /// Idan da damar yawo, ko da allocator rahoton wani gazawar, sa'an nan da wani kuskure da aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Yi ajiyar ƙwaƙwalwar ajiya, fita idan ba za mu iya ba
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Yanzu mun san cewa wannan ba zai iya ba OOM ba a tsakiyar aikinmu mai rikitarwa
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // mai rikitarwa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Yana rage ƙarfin vector sosai-sosai.
    ///
    /// Zai sauka ƙasa gwargwadon yadda zai yiwu zuwa tsawon amma mai raba shi yana iya sanar da vector cewa akwai sarari don wasu morean abubuwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Capacityarfin bai gaza tsayi ba, kuma babu abin da za a yi idan sun daidaita, saboda haka zamu iya guje wa lamarin panic a cikin `RawVec::shrink_to_fit` ta hanyar kiran sa da ƙarfin da ya fi ƙarfin kawai.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Yana rage ƙarfin vector tare da ƙananan lada.
    ///
    /// Capacityarfin zai kasance aƙalla babba kamar tsawonsa da ƙimar da aka bayar.
    ///
    ///
    /// Idan ƙarfin yanzu yana ƙasa da ƙananan iyaka, wannan ba komai bane.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Sanya vector zuwa [`Box<[T]>`][owned slice].
    ///
    /// Lura cewa wannan zai sauke duk iyawar wuce haddi.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Duk wani wuce gona da iri an cire shi:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Ya gajarta vector, yana kiyaye abubuwan farko na `len` kuma ya watsar da sauran.
    ///
    /// Idan `len` ya fi ƙarfin vector na yanzu, wannan ba shi da tasiri.
    ///
    /// Hanyar [`drain`] na iya yin koyi da `truncate`, amma yana sa a dawo da abubuwan da suka wuce haddi maimakon faduwa.
    ///
    ///
    /// Lura cewa wannan hanyar ba ta da tasiri a kan damar da aka ware na vector.
    ///
    /// # Examples
    ///
    /// Yanke wani biyar kashi vector zuwa biyu abubuwa:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Babu yankewa lokacin da `len` ya fi tsayin vector girma yanzu:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Yankewa lokacin da `len == 0` yayi daidai da kiran hanyar [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Wannan amintacce ne saboda:
        //
        // * yanki da aka wuce zuwa `drop_in_place` yana aiki;shari'ar `len > self.len` tana hana ƙirƙirar yanki mara inganci, kuma
        // * `len` na vector ya ragu kafin kiran `drop_in_place`, ta yadda ba za a sauke darajar sau biyu ba idan `drop_in_place` ya kasance panic sau ɗaya (idan panics sau biyu, shirin ya zubar).
        //
        //
        //
        unsafe {
            // Note: Da gangan ne wannan shine `>` kuma ba `>=` ba.
            //       Canza shi zuwa `>=` yana da tasiri mara tasiri a wasu yanayi.
            //       Dubi #78884 for more.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Cire wani yanki wanda ya ƙunshi duka vector.
    ///
    /// Daidaita zuwa `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Tsame wani mutable yanki na dukan vector.
    ///
    /// Daidai `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Ya dawo da ɗan manuni don ajiyar vector.
    ///
    /// Wajibi ne mai kiran ya tabbatar da cewa vector ya zarce mai nuna wannan aikin ya dawo, in ba haka ba zai ƙare da nuna datti.
    /// Gyara vector na iya haifar da sake sanya madogarar sa, wanda hakan zai kuma sanya duk wasu maganganun zuwa gare shi mara inganci.
    ///
    /// Wajibi ne mai kiran ya tabbatar cewa ba a rubuta memorin da mai nuna alamar (non-transitively) ya nuna ba (sai dai a cikin `UnsafeCell`) ta amfani da wannan alamar ko kuma duk wata alama da aka samo daga gare ta.
    /// Idan kana buƙatar canzawa abubuwan da ke cikin yanki, yi amfani da [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Muna inuwa ta hanyar yanki guda na suna don kaucewa wucewa ta `deref`, wanda ke haifar da matsakaiciyar tunani.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ya dawo da alamomin mai rikitarwa mara aminci zuwa ga ajiyar vector.
    ///
    /// Wajibi ne mai kiran ya tabbatar da cewa vector ya zarce mai nuna wannan aikin ya dawo, in ba haka ba zai ƙare da nuna datti.
    ///
    /// Gyara vector na iya haifar da sake sanya madogarar sa, wanda hakan zai kuma sanya duk wasu maganganun zuwa gare shi mara inganci.
    ///
    /// # Examples
    ///
    /// ```
    /// // Raba vector babba don abubuwa 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialize abubuwa via raw akan rubuta, sa'an nan saita tsayin.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Muna inuwa ta hanyar yanki guda na suna don kaucewa wucewa ta `deref_mut`, wanda ke haifar da matsakaiciyar tunani.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ya dawo da ma'anar mai rarrabawa.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Arfafa tsawon vector zuwa `new_len`.
    ///
    /// Wannan shi ne wani low-matakin aiki da kula da babu wani daga cikin al'ada invariants na da irin.
    /// A yadda aka saba canza tsawon vector ana yin shi ta amfani da ɗayan amintaccen aiki maimakon, kamar [`truncate`], [`resize`], [`extend`], ko [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` dole ne ya zama ƙasa da ko daidaita da [`capacity()`].
    /// - Abubuwan da ke `old_len..new_len` dole ne a fara su.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Wannan hanyar na iya zama mai amfani ga yanayin da vector ke aiki azaman ajiyar wasu lambobi, musamman akan FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Wannan dan karamin kwarangwal ne ga misalin doc;
    /// # // kar a yi amfani da wannan azaman farawa don ainihin laburare.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Per da FFI Hanyar ta daftarorin aiki, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // KYAUTA: Lokacin da `deflateGetDictionary` ya dawo `Z_OK`, yana riƙe da cewa:
    ///     // 1. `dict_length` abubuwa da aka initialized.
    ///     // 2.
    ///     // `dict_length` <=ƙarfin (32_768) wanda ke sa `set_len` amintacce don kira.
    ///     unsafe {
    ///         // Yi kiran FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... da sabunta tsawon abin da aka fara.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Duk da yake misali mai zuwa sauti ne, akwai ƙwaƙwalwar ajiya tun daga cikin vectors ba a 'yanta shi ba kafin kiran `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` fanko ne don haka babu abubuwan da suke buƙatar farawa.
    /// // 2. `0 <= capacity` koyaushe yana riƙe duk abin da `capacity` yake.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Yadda aka saba, a nan, wanda zai yi amfani da [`clear`] maimakon zuwa daidai jifa da abinda ke ciki da kuma haka ne, ba zuba memory.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Cire abu daga vector kuma ya dawo da shi.
    ///
    /// An maye gurbin abin da aka cire da kashi na ƙarshe na vector.
    ///
    /// Wannan baya kiyaye oda, amma shine O(1).
    ///
    /// # Panics
    ///
    /// Panics idan `index` ya wuce iyaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Muna maye gurbin kai [index] da kashi na karshe.
            // Lura cewa idan iyakokin da ke sama suka yi nasara dole ne ya kasance akwai ɓangare na ƙarshe (wanda zai iya zama kansa [index] kanta).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Abun da ake sakawa wani kashi a matsayin `index` cikin vector, canjawa duk abubuwa bayan shi ga dama.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // sarari ga sabon kashi
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // Ma'asumi Wurin da zai sanya sabon ƙimar
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Canja komai don yin sarari.
                // (Duplicating da `index`th kashi cikin biyu a jere wurare.)
                ptr::copy(p, p.offset(1), len - index);
                // Rubuta shi a ciki, sake sake rubutun farko na asalin 'index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Ta kawar da dawo da rabi a matsayin `index` cikin vector, canjawa duk abubuwa bayan shi zuwa hagu.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `index` ya wuce iyaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // wurin da muke dauka.
                let ptr = self.as_mut_ptr().add(index);
                // kwafe shi daga, unsafely ciwon kwafin darajar a kan tari, kuma a cikin vector a lokaci guda.
                //
                ret = ptr::read(ptr);

                // Shift kome saukar da cika a wannan tabo.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Yana riƙe abubuwa kawai da aka ambata a lokacin magana.
    ///
    /// A wasu kalmomin, cire duk abubuwan `e` kamar `f(&e)` ya dawo da `false`.
    /// Wannan hanyar tana aiki a wurin, tana ziyartar kowane abu daidai sau daya a cikin tsari na asali, kuma yana kiyaye tsari na abubuwan da aka riƙe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Saboda ana ziyartar abubuwa daidai sau ɗaya a cikin asalin tsari, ana iya amfani da jihar waje don yanke shawarar waɗanne abubuwan da za'a adana.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Guji biyu drop idan drop matsara ba kashe, tun lokacin da muka iya yin wasu ramuka a lokacin tsari.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-sarrafa len-> |-kusa da dubawa
        //                  | <-share cnt-> |
        //      | <-asali_len-> |Kiyaye: Abubuwan da aka tsara zasu dawo gaskiya.
        //
        // Rami: Matsakaicin ɓangaren rami ko aka sauke.
        // Wanda ba a duba ba: Ingantattun abubuwa.
        //
        // Wannan drop matsara za a kira a lokacin da predicate ko `drop` na kashi panicked.
        // Yana canza abubuwan da ba'a bincika ba don rufe ramuka da `set_len` zuwa madaidaicin tsayi.
        // A lokuta idan aka ambata kuma `drop` basu firgita ba, za'a inganta shi.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // KYAUTA: Bin abubuwan da ba'a bincika ba dole su zama masu inganci tunda bamu taba su ba.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // KYAUTA: Bayan cika ramuka, duk abubuwa suna cikin ƙwaƙwalwa mai haɗuwa.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // KYAUTA: Abubuwan da ba'a bincika ba dole ne ya zama mai aiki.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ci gaba da wuri don kaucewa faduwa sau biyu idan `drop_in_place` ya firgita.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // KYAUTA: Ba za mu sake taɓa wannan ɓangaren ba bayan mun faɗi.
                unsafe { ptr::drop_in_place(cur) };
                // Mun riga sun ci gaba da counter.
                continue;
            }
            if g.deleted_cnt > 0 {
                // KIYAYEWAR: `deleted_cnt`> 0, don haka rami Ramin dole ba zoba da halin yanzu kashi.
                // Mun yi amfani da kwafin for tafi, da kuma taba wannan kashi sake.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // All abu ne sarrafa.Ana iya inganta wannan zuwa `set_len` ta LLVM.
        drop(g);
    }

    /// Ana cire duka amma farkon abubuwan jere a cikin vector waɗanda ke warware ɗaya madannin.
    ///
    ///
    /// Idan an rarrabe vector, wannan yana cire duk abubuwan kwafin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Cire duka amma farkon abubuwan jere a cikin vector mai gamsar da dangantakar daidaito da aka bayar.
    ///
    /// A `same_bucket` aiki ne haƙĩƙa, sun shige nassoshi biyu abubuwa daga vector kuma dole ne sanin ko idan da abubuwa kwatanta daidaita.
    /// An wuce abubuwan ne ta hanyar ba daidai ba daga odar su a yanki, don haka idan `same_bucket(a, b)` ya dawo `true`, an cire `a`.
    ///
    ///
    /// Idan an rarrabe vector, wannan yana cire duk abubuwan kwafin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Endsara wani ɓoye a bayan tarin.
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya wuce by00 `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Wannan zai panic ko QDialogButtonBox idan za mu ware> isize::MAX bytes ko idan da tsawon increment zai anab for sifili-sized iri.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Cire abu na ƙarshe daga vector ya dawo dashi, ko [`None`] idan babu komai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Matsar da dukkan abubuwan da ke cikin `other` zuwa `Self`, suna barin `other` fanko.
    ///
    /// # Panics
    ///
    /// Panics idan adadin abubuwa a cikin vector sun cika `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Appends abubuwa to `Self` daga sauran buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Creatirƙira mai sharar ruwa wanda ke cire takamaiman kewayon a cikin vector kuma yana ba da abubuwan da aka cire.
    ///
    /// Lokacin da mai kunnawa ** ya fadi, duk abubuwan da ke cikin kewayon an cire su daga vector, koda kuwa mai karantawar bai cika cinyewa ba.
    /// Idan ba a sa mai amsawa ** ya bari ba (tare da [`mem::forget`] misali), ba a tantance adadin abubuwan da aka cire ba.
    ///
    /// # Panics
    ///
    /// Panics idan farawa ya fi ƙarshen ƙarshen ko kuma idan ƙarshen ƙarshen ya fi tsayi na vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Cikakken kewayon ya share vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Amintaccen ƙwaƙwalwar ajiya
        //
        // Lokacin da aka fara kirkirar Drain, zai rage tsawon tushen vector don tabbatar da cewa babu wasu abubuwan da basu waye ba ko kuma suka koma-baya idan mai lalata Drain bai taba gudu ba.
        //
        //
        // Drain zai ptr::read fitar da ƙimomin don cirewa.
        // Bayan an gama, sauran korar wutsiyar vec din za a kwafa ta baya don rufe ramin, kuma an mai da tsayin vector zuwa sabon tsayin.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // saita tsayin self.vec don farawa, don zama mai aminci idan har Drain ya zube
            self.set_len(start);
            // Yi amfani da aron a cikin IterMut don nuna halayyar aro na duka mai z0Drain0Z (kamar &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Yana share vector, yana cire duk ƙimomin.
    ///
    /// Lura cewa wannan hanyar ba ta da tasiri a kan damar da aka ware na vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Ya dawo da adadin abubuwa a cikin vector, wanda kuma ake kira da 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Yana dawo da `true` idan vector bai ƙunshi abubuwa ba.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ya kasu kashi biyu a cikin alamar da aka bayar.
    ///
    /// Ya dawo da sabon da aka ware vector dauke da abubuwan da ke cikin zangon `[at, len)`.
    /// Bayan kiran, asali vector za a bar dauke da abubuwa `[0, at)` da ta gabata damar canzawa.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // sabon vector iya dauka a kan asali buffer da kuma kauce wa kwafin
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Rashin aminci `set_len` kuma kwafe abubuwa zuwa `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ya daidaita girman `Vec` a cikin wuri don `len` yayi daidai da `new_len`.
    ///
    /// Idan `new_len` ya fi `len` girma, za a tsawaita `Vec` ta hanyar bambanci, tare da kowane ƙarin waƙa cike da sakamakon kiran ƙulli `f`.
    ///
    /// Valuesimar dawowa daga `f` zata ƙare a cikin `Vec` cikin odar da aka ƙirƙira su.
    ///
    /// Idan `new_len` bai kai `len` ba, to `Vec` an yanke shi kawai.
    ///
    /// Wannan hanyar tana amfani da ƙulli don ƙirƙirar sababbin ƙimomi akan kowane turawa.Idan kuna son [`Clone`] ƙimar da aka bayar, yi amfani da [`Vec::resize`].
    /// Idan kana son amfani da [`Default`] trait don samar da ƙimomi, zaka iya wuce [`Default::default`] azaman hujja ta biyu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Cinyewa da leaks na `Vec`, yana mai da maimaita canjin abin da ke ciki, `&'a mut [T]`.
    /// Lura cewa nau'in `T` dole ne ya wuce rayuwar da aka zaɓa ta `'a`.
    /// Idan nau'in kawai yana da nassoshi na tsaye, ko babu ko kaɗan, to ana iya zaɓar wannan ya zama `'static`.
    ///
    /// Wannan aikin yayi kama da aikin [`leak`][Box::leak] akan [`Box`] saidai babu wata hanya ta dawo da ƙwaƙwalwar da aka zube.
    ///
    ///
    /// Wannan aikin yafi amfani ga bayanan da ke rayuwa har zuwa ƙarshen rayuwar shirin.
    /// Sauke bayanan da aka dawo zai haifar da ƙwaƙwalwar ajiya.
    ///
    /// # Examples
    ///
    /// Amfani mai sauƙi:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Ya dawo da sauran ƙarfin kayayyakin vector azaman yanki na `MaybeUninit<T>`.
    ///
    /// A koma yanki za a iya amfani da su cika vector tare data (misali
    /// ta hanyar karantawa daga fayil) kafin yiwa bayanan alama kamar yadda aka fara ta amfani da hanyar [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Raba vector babba don abubuwa 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Cika abubuwan farko guda 3.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Yi alama abubuwan farko 3 na vector kamar yadda aka fara su.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ba a aiwatar da wannan hanyar cikin sharuddan `split_at_spare_mut`, don hana ɓata maimaita alamun nuni zuwa maƙerin.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Ya dawo da abun cikin vector azaman yanki na `T`, tare da ragowar damar karfin vector azaman yanki na `MaybeUninit<T>`.
    ///
    /// Za'a iya amfani da yanki na kayan damar da aka dawo dasu don cike vector da bayanai (misali ta hanyar karantawa daga fayil) kafin yiwa bayanan alama kamar yadda aka fara ta amfani da hanyar [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Note cewa wannan shi ne wani low-matakin API, abin da ya kamata a yi amfani da tare da kulawa ga ingantawa dalilai.
    /// Idan kana bukatar ka jimlar bayanai zuwa wani `Vec` za ka iya amfani da [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ko [`resize_with`], dangane da ainihin bukatun.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reserve ƙarin sarari babban isa ga 10 abubuwa.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Cika abubuwa 4 na gaba.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Yi alama abubuwan 4 na vector kamar yadda aka fara su.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ba a kula shi kuma don haka bai taba canzawa ba
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Tsaro: canza dawowa .2 (&mut amfani) ana ɗauka iri ɗaya da kiran `.set_len(_)`.
    ///
    /// Ana amfani da wannan hanyar don samun damar musamman ga duk sassan vec lokaci ɗaya a cikin `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` yana da tabbacin zama mai inganci don abubuwan `len`
        // - `spare_ptr` yana nuna ɗayan ɓangaren da ya wuce buffer, don haka baya haɗuwa da `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ya daidaita girman `Vec` a cikin wuri don `len` yayi daidai da `new_len`.
    ///
    /// Idan `new_len` ya fi `len` girma, za a tsawaita `Vec` ta hanyar bambanci, tare da kowane ƙarin rami da aka cika da `value`.
    ///
    /// Idan `new_len` bai kai `len` ba, to `Vec` an yanke shi kawai.
    ///
    /// Wannan hanyar tana buƙatar `T` don aiwatar da [`Clone`], don samun damar haɓaka darajar da aka wuce.
    /// Idan kuna buƙatar ƙarin sassauƙa (ko kuna son dogaro da [`Default`] maimakon [`Clone`]), yi amfani da [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones da append duk abubuwan a cikin yanki zuwa `Vec`.
    ///
    /// Iterates akan yanki `other`, clones kowane element, sa'annan ya sanya shi zuwa wannan `Vec`.
    /// `other` vector yana wucewa cikin tsari.
    ///
    /// Lura cewa wannan aikin yayi daidai da [`extend`] banda cewa ƙwararre ne don aiki tare da yanka maimakon.
    ///
    /// Idan kuma lokacin da Rust samun specialization wannan aiki zai iya zama deprecated (amma har yanzu akwai).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kwafin abubuwa daga kewayon `src` zuwa ƙarshen vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` tabbacin cewa ba iyaka yana aiki ga Indexing kai
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Wannan lambar ta daidaita `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Mika vector da `n` dabi'u, ta amfani da ba janareta.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Yi amfani da SetLenOnDrop don yin aiki a kusa da ɓarawo inda mai tarawa bazai fahimci shagon ta hanyar `ptr` ta hanyar self.set_len() ba da laƙabi.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Rubuta dukkan abubuwa banda na ƙarshe
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Mentara tsayi a kowane mataki idan har next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Za mu iya rubuta na karshe kashi kai tsaye ba tare da cloning sanadiyar
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len saita ta ikon yinsa
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Ana cire abubuwa da aka maimaita a jere a cikin vector bisa ga aiwatar da [`PartialEq`] trait.
    ///
    ///
    /// Idan an rarrabe vector, wannan yana cire duk abubuwan kwafin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Hanyoyi da ayyuka na ciki
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` bukatar ya zama m index
    /// - `self.capacity() - self.len()` dole ne ya zama `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len yana ƙaruwa ne kawai bayan farawa abubuwa
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - jagororin masu kira cewa src ingantaccen index ne
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element an ƙaddamar da shi kawai tare da `MaybeUninit::write`, saboda haka yana da kyau a ƙara bashi
            // - Len ne ta ƙara bayan kowane kashi hana leaks (ga batun #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - jagororin masu kira cewa `src` ingantaccen index ne
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Duk alamun bayanan an halicce su ne daga nassoshi yanki na musamman (`&mut [_]` `) don haka suna aiki kuma ba sa juyewa.
            //
            // - Abubuwan abubuwa sune: Kwafa saboda haka yana da kyau a kwafa su, ba tare da yin komai da ƙimar asali ba
            // - `count` ne daidai da Len na `source`, don haka tushen yana aiki ga `count` karanta
            // - `.reserve(count)` yana ba da tabbacin cewa `spare.len() >= count` don haka keɓaɓɓiyar aiki ta dace da rubutun `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - `copy_nonoverlapping` ne kawai ya fara kirkirar abubuwan
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Aiwatar da trait gama gari don Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): tare da cfg(test) hanyar `[T]::to_vec` ta asali, wacce ake buƙata don wannan ma'anar hanyar, ba ta samu.
    // Maimakon amfani da `slice::to_vec` aiki wanda shi ne samuwa ne kawai tare da cfg(test) NB ganin slice::hack module a slice.rs don ƙarin bayani
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // sauke duk abin da ba za a sake rubuta shi ba
        self.truncate(other.len());

        // self.len <= other.len saboda ɗankwalin da ke sama, saboda haka yankan anan koyaushe suna da iyaka.
        //
        let (init, tail) = other.split_at(self.len());

        // sake amfani da abubuwan da aka ƙunshe allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Halicci cinyewa iterator, cewa shi ne, wanda ya motsa kowane darajar daga cikin vector (daga farko zuwa karshen).
    /// A vector ba za a iya amfani da bayan kiran wannan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s yana da nau'in Kirtani, ba &String ba
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // Hanyar ganye wacce yawancin aiwatarwar SpecFrom/SpecExtend ke wakilta lokacin da basu da sauran abubuwan ingantawa don amfani
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Wannan shi ne yanayin ga wani janar iterator.
        //
        // Wannan aikin ya zama daidai da ɗabi'a:
        //
        //      don abu a iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ba zai iya yin ambaliya ba tunda da sai mun ware filin adireshin
                self.set_len(len + 1);
            }
        }
    }

    /// Irƙira mai maimaitawa wanda zai maye gurbin iyakokin da aka ƙayyade a cikin vector tare da mai ba da labarin `replace_with` kuma ya samar da abubuwan da aka cire.
    ///
    /// `replace_with` baya buƙatar tsayi ɗaya kamar na `range`.
    ///
    /// `range` an cire koda mai shayarwar ba a cinye shi har zuwa karshen.
    ///
    /// Shi ne unspecified nawa abubuwa suna cire daga vector idan `Splice` darajar da aka leaked.
    ///
    /// Mai amfani da shigarwar `replace_with` ana amfani dashi ne kawai lokacin da aka sauke darajar `Splice`.
    ///
    /// Wannan shi ne mafi kyau duka idan:
    ///
    /// * Wutsiya (abubuwa a cikin vector bayan `range`) fanko ne,
    /// * ko `replace_with` yã'yan m ko daidai abubuwa fiye da `range` ta tsawon
    /// * ko ƙananan igiyar `size_hint()` ɗinsa daidai ne.
    ///
    /// In ba haka ba, an ware vector na ɗan lokaci kuma ana motsa wutsiya sau biyu.
    ///
    /// # Panics
    ///
    /// Panics idan farawa ya fi ƙarshen ƙarshen ko kuma idan ƙarshen ƙarshen ya fi tsayi na vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Irƙira mai magana wanda ke amfani da ƙulli don ƙayyade idan ya kamata a cire wani abu.
    ///
    /// Idan ƙulli ya dawo na gaskiya, to an cire abun kuma ya ba da amfani.
    /// Idan ƙulli kõma ƙarya, kashi zai kasance a cikin vector kuma ba za a bada ta iterator.
    ///
    /// Amfani da wannan hanyar yayi daidai da lambar mai zuwa:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // lambar ka anan
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Amma `drain_filter` ya fi sauƙin amfani.
    /// `drain_filter` kuma ya fi inganci, saboda yana iya dawo da abubuwan da ke cikin jeri baya.
    ///
    /// Lura cewa `drain_filter` shima yana baka damar canza kowane abu a cikin rufe matatar, ba tare da la'akari da ko ka zabi kiyayewa ko cire shi ba.
    ///
    ///
    /// # Examples
    ///
    /// Tsaga tsararru zuwa maraice da rashin daidaito, sake amfani da kason asali:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Guard da mu yin leaked (zuba karawa)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Mika aiwatar da cewa kofe abubuwa daga nassoshi kafin turawa su uwa da Vec.
///
/// Wannan aiwatarwar takanasance na masu sarrafa yanki, inda yake amfani da [`copy_from_slice`] don haɗa dukkan yanki lokaci ɗaya.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Yana aiwatar da kwatancen vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Ana aiwatar da oda na vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // amfani drop for [T] amfani da albarkatun yanki koma zuwa abubuwa na vector kamar yadda mafi raunin dole irin;
            //
            // zai iya kauce wa tambayoyin inganci a wasu halaye
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec yana kula da rarraba wuri
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Esirƙira komai na `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: gwajin yana jan cikin libstd, wanda ke haifar da kurakurai a nan
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: gwajin yana jan cikin libstd, wanda ke haifar da kurakurai a nan
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Samun dukkan abubuwan da ke cikin `Vec<T>` azaman tsararru, idan girmansa yayi daidai da na tsararren da aka nema.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Idan tsayin bai daidaita ba, shigarwar zata dawo cikin `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Idan kun kasance daidai da kawai samun prefix na `Vec<T>`, zaku iya kiran [`.truncate(N)`](Vec::truncate) da farko.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // KYAUTA: `.set_len(0)` koyaushe sauti ne.
        unsafe { vec.set_len(0) };

        // KIYAYEWAR: A `Vec` ta Pointer ne ko da yaushe masu hada kai yadda ya kamata, da kuma
        // daidaitawar abubuwan da ake bukata daidai yake da abubuwa.
        // Mu bari a baya cewa muna da isasshen abubuwa.
        // Abubuwan ba zasu ninka sau biyu ba kamar yadda `set_len` ya fadawa `Vec` kada shima ya sauke su.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}