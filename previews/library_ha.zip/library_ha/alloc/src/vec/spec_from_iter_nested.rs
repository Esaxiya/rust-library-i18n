use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Wani specialization trait for Vec::from_iter zama dole to da hannu prioritize overlapping specializations ganin [`SpecFromIter`](super::SpecFromIter) domin cikakkun bayanai.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Bude fasalin farko, tunda vector za'a fadada shi akan wannan yanayin a kowane yanayi lokacin da baza'a iya komai a ciki ba, amma madauki a cikin extend_desugared() ba zai ga vector yana cike a cikin fewan madaidaicin madaukai ba.
        //
        // Saboda haka muka samu mafi alhẽri branch Hasashen.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // dole ne ya wakilta zuwa spec_extend() tunda extend() da kanta ta wakilta zuwa takamaiman_tare da komai na Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // dole ne ya wakilta zuwa spec_extend() tunda extend() da kanta ta wakilta zuwa takamaiman_tare da komai na Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}