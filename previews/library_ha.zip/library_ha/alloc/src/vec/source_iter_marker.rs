use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Kwarewa alama don tattara wani iterator bututun cikin wani Vec yayin reusing tushen kasafi, watau
/// aiwatar da bututun a wurin.
///
/// SourceIter iyaye trait ya zama dole don aikin ƙwarewa don samun damar rabon wanda za'a sake amfani dashi.
/// Amma bai wadatar da ƙwarewar ta kasance mai inganci ba.
/// Dubi ƙarin haddi a kan impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// A std-ciki SourceIter/InPlaceIterable traits suna kawai a aiwatar da sarƙoƙi na Adafta <Adapter<Adapter<IntoIter>>> (duk mallakar core/std).
// Boarin iyakoki akan aiwatarwar adaftan (bayan `impl<I: Trait> Trait for Adapter<I>`) ya dogara ne kawai akan wasu traits waɗanda aka riga aka yiwa alama azaman ƙwarewar traits (Kwafi, TrustedRandomAccess, FusedIterator).
//
// I.e. Alamar ba ta dogara da tsawon rayuwar nau'ikan wadatar mai amfani ba.Modulo kwafin kwafi, wanda sauran ƙwarewa da dama suka riga sun dogara dashi.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Requirementsarin buƙatun waɗanda ba za a iya bayyana su ta hanyar trait bounds ba.Mun dogara da kwalliya maimakon:
        // a) babu ZSTs saboda babu wani kason da za'a sake amfani dashi kuma mai lissafin lissafi zai panic b) girman wasa kamar yadda Alloc kwangila ya buƙata c) daidaita daidaito kamar yadda Alloc ya buƙata
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // koma baya ga ƙarin aiwatarwa na asali
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // amfani da-gwada tun
        // - shi vectorizes mafi kyau ga wasu iterator adaftan
        // - sabanin yawancin hanyoyin haɓaka na ciki, kawai ɗaukar hoto ne na &mut
        // - Yana ba mu damar sanya rubutun da aka rubuta ta cikin kayan ciki kuma mu dawo da shi a ƙarshe
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // gyare-gyare ya yi nasara, kar a sauke kansa
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // Bincika idan SourceIter kwangila ya kasance mai kiyayewa: idan ba su ba watakila ba ma iya kaiwa ga wannan batun
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // duba kwangilar InPlaceIterable.Wannan zai yiwu ne kawai idan mai gabatarwa ya ci gaba da nuna alamar kwata-kwata.
        // Idan ta yi amfani da damar da ba a kulle ba ta hanyar TrustedRandomAccess sannan mai nuna alamar zai kasance a matsayinsa na farko kuma ba za mu iya amfani da shi azaman tunani ba
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // sauke duk wasu ƙimomin da suka rage a wutsiyar asalin amma hana juyewar kason kanta sau ɗaya IntoIter ya wuce gona da iri idan digo panics sannan muma duk abubuwan da muka tara a cikin dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // Ba za a iya tabbatar da kwantiragin InPlaceIterable daidai a nan ba tunda try_fold yana da keɓaɓɓen magana ga maɓallin bayanin abin da kawai za mu iya yi shi ne bincika idan har yanzu yana cikin kewayo
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}