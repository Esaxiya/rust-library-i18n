use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Maimaitawa wanda ke amfani da ƙulli don ƙayyade idan ya kamata a cire wani abu.
///
/// Wannan tsarin an ƙirƙira shi ta [`Vec::drain_filter`].
/// Duba bayanansa don ƙarin.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Theididdigar abin da za a bincika ta kira na gaba zuwa `next`.
    pub(super) idx: usize,
    /// Adadin abubuwan da aka lalata (removed) har yanzu.
    pub(super) del: usize,
    /// Tsayin asali na `vec` kafin zubar ruwa.
    pub(super) old_len: usize,
    /// Gwajin gwajin tace
    pub(super) pred: F,
    /// Tutar da ke nuna panic ta auku a cikin tsinkayen gwajin tacewa.
    /// Ana amfani da wannan azaman alama a aiwatarwar digo don hana amfani da ragowar `DrainFilter`.
    /// Duk wani abu da ba'a sarrafa shi ba zai sake canzawa a cikin `vec`, amma babu wasu abubuwa da za a sake ko gwada su ta hanyar mai tantancewar tacewa.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Ya dawo da ma'anar mai rarrabawa.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Updateaukaka fihirisa *bayan* ana kiran magatakarda.
                // Idan aka sabunta bayanan kafin kuma mai bayanin panics, abun da ke wannan layin zai zube.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Wannan kyakkyawan yanayin rikicewa ne, kuma babu ainihin abin da ya dace a yi.
                        // Ba mu so mu ci gaba da kokarin kashe `pred`, don haka muna kawai backshift duk unprocessed abubuwa da kuma gaya wa vec cewa su har yanzu wanzu.
                        //
                        // Ana buƙatar murfin baya don hana digo biyu na ƙarshen nasarar abu mai ƙaranciya kafin panic a cikin tsinkayen.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Emoƙarin cinye sauran abubuwan da suka rage idan maganan matatar ba ta riga ta firgita ba.
        // Zamu koma baya ga duk sauran abubuwan da suka rage shin mun riga mun firgita ko kuma idan cin amfanin anan panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}