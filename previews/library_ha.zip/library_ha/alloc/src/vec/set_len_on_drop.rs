// Sanya tsawon vec lokacin da darajar `SetLenOnDrop` ta wuce gona da iri.
//
// Ma'anar ita ce: Filin tsayi a cikin SetLenOnDrop canji ne na gari wanda mai ingantawa zai gani baya laƙabi da kowane shaguna ta hanyar bayanan bayanan Vec.
// Wannan aiki ne don batun laƙabi da batun x00X
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}