//! A UTF-8 - mai aiki da kodin, madaidaiciyar zare.
//!
//! Wannan kundin yana dauke da nau'in [`String`], [`ToString`] trait don canzawa zuwa kirtani, da nau'ikan kuskuren da yawa wadanda zasu iya haifar da aiki tare da [``String`] s.
//!
//!
//! # Examples
//!
//! Akwai mahara hanyoyin da za a haifar da wani sabon [`String`] daga wani layi na zahiri:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Zaka iya ƙirƙirar sabon [`String`] daga wanda yake ta hanyar haɗawa tare
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Idan kana da vector na ingantattun baiti UTF-8, zaka iya yin [`String`] daga ciki.Hakanan zaku iya yin baya.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Mun san waɗannan baiti suna da inganci, don haka za mu yi amfani da `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// A UTF-8 - mai aiki da kodin, madaidaiciyar zare.
///
/// Nau'in `String` shine mafi yawan nau'in nau'in kirtani wanda yake da mallaka akan abubuwan da ke ciki.Yana da kusanci da takwaransa na aro, na farko [`str`].
///
/// # Examples
///
/// Kuna iya ƙirƙirar `String` daga [a literal string][`str`] tare da [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Kuna iya haɗawa da [`char`] zuwa `String` tare da hanyar [`push`], kuma ku haɗa da [`&str`] tare da hanyar [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Idan kana da vector na UTF-8 bytes, zaka iya ƙirƙirar `String` daga gareta tare da hanyar [`from_utf8`]:
///
/// ```
/// // wasu bytes, a cikin vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mun san waɗannan baiti suna da inganci, don haka za mu yi amfani da `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s ne ko da yaushe inganci UTF-8.Wannan yana da 'yan abubuwan, na farko wanda yake shi ne cewa idan kana bukatar wani maras UTF-8 kirtani, la'akari da [`OsString`].Yana da kama, amma ba tare da ƙuntatawa na UTF-8 ba.Na biyu abinda yake cewa ba za ka iya index cikin wani `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexing yana nufin zama aiki na lokaci-lokaci, amma tsarin UTF-8 baya bamu damar yin wannan.Bugu da ƙari kuma, shi ke ba share abin da irin abu da index kamata komawa: a byte, a codepoint, ko wani grapheme tari.
/// A [`bytes`] da [`chars`] hanyoyin koma iterators kan na farko da biyu, bi da bi.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s yi [`Deref`] '<Target=str>``, kuma don haka ku gaji dukkan hanyoyin ['' str`] ɗin.Bugu da kari, wannan yana nufin cewa zaku iya wucewa `String` zuwa aiki wanda ke daukar [`&str`] ta amfani da ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Wannan zai ƙirƙiri [`&str`] daga `String` kuma ya shigar da shi a ciki. Wannan jujjuyawar ba ta da tsada sosai, kuma don haka gaba ɗaya, ayyuka za su karɓi azaman gardama sai dai idan suna buƙatar `String` saboda wani takamaiman dalili.
///
/// A wasu lokuta Rust bashi da isasshen bayani don yin wannan juyarwar, wanda aka sani da tilastawa [`Deref`].A cikin misali mai zuwa zaren zaren [`&'a str`][`&str`] yana aiwatar da trait `TraitExample`, kuma aikin `example_func` yana ɗaukar duk abin da ke aiwatar da trait.
/// A wannan yanayin Rust zai bukatar sa biyu a fakaice Abubuwan Taɗi, wanda Rust ba da nufin su yi.
/// A dalilin wannan, misali mai zuwa ba zai tattara ba.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Akwai zaɓi biyu waɗanda zasu yi aiki maimakon.Na farko zai kasance canza layin `example_func(&example_string);` zuwa `example_func(example_string.as_str());`, ta amfani da hanyar [`as_str()`] don fito da zanen zaren da ke dauke da kirtani a bayyane.
/// Hanya ta biyu tana canza `example_func(&example_string);` zuwa `example_func(&*example_string);`.
/// A wannan yanayin da muke dereferencing a `String` zuwa [`str`][`&str`], sa'an nan referencing da [`str`][`&str`] baya ga [`&str`].
/// Hanya ta biyu ita ce karin magana, amma duk da haka suna aiki don yin juzuwar jujjuya maimakon dogaro da jujjuyawar juyawa.
///
/// # Representation
///
/// A `String` aka yi sama da uku aka gyara: a mauni zuwa wasu bytes, a tsawon, da kuma damar.Mai nuna alama yana nuni zuwa maɓallin ajiyar ciki na `String` yana amfani dashi don adana bayanansa.A tsawon shi ne yawan bytes a halin yanzu adana a cikin buffer, da kuma iya aiki ne da girman da buffer a bytes.
///
/// Kamar wannan, tsawon koyaushe zai zama ƙasa da ko daidai da damar.
///
/// Ana adana wannan maƙallan koyaushe akan tarin.
///
/// Za ka iya dubi wadannan da [`as_ptr`], [`len`], kuma [`capacity`] hanyoyin:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Sabunta wannan lokacin da aka ƙarfafa vec_into_raw_parts.
/// // Tsayar da faduwa bayanan Kirtani ta atomatik
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // labarin yana da goma sha tara bytes
/// assert_eq!(19, len);
///
/// // Zamu iya sake gina Kirtani daga ptr, lamuni, da iyawa.
/// // Wannan duk ba shi da aminci saboda muna da alhakin tabbatar da abubuwan haɗin suna aiki:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Idan `String` yana da isasshen ƙarfin, ƙara abubuwa zuwa gare shi ba zai sake rarrabawa ba.Misali, la'akari da wannan shirin:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Wannan zai fitar da waɗannan masu zuwa:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Da farko, ba mu da ƙwaƙwalwar da aka ware kwata-kwata, amma yayin da muke haɗawa da kirtani, yana ƙara ƙarfinta yadda ya dace.Idan muka maimakon amfani da [`with_capacity`] Hanyar ware daidai damar da farko:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Mun ƙare tare da fitarwa daban-daban:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// A nan, akwai wani bukatar ware karin memory cikin madauki.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Errorimar kuskure mai yuwuwa yayin canza `String` daga UTF-8 byte vector.
///
/// Wannan nau'in nau'in kuskure ne don hanyar [`from_utf8`] akan [`String`].
/// An tsara ta ta wannan hanyar don kauce wa sanya wurare a hankali: hanyar [`into_bytes`] za ta ba da baiti vector wanda aka yi amfani da shi a yunƙurin sauyawa.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Nau'in [`Utf8Error`] wanda [`std::str`] ya bayar yana wakiltar kuskuren da zai iya faruwa yayin canza yanki na [`u8`] zuwa [`&str`].
/// A wannan ma'anar, analog ne zuwa `FromUtf8Error`, kuma zaku iya samun ɗaya daga `FromUtf8Error` ta hanyar hanyar [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// // wasu baiti marasa inganci, a cikin vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// A yiwu kuskure darajar idan tana mayar da `String` daga UTF-16 byte yanki.
///
/// Wannan nau'in nau'in kuskure ne don hanyar [`from_utf16`] akan [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Irƙirar sabon fanko `String`.
    ///
    /// Ganin cewa `String` fanko ce, wannan ba zai ware wani na farko buffer.Duk da yake wannan yana nufin cewa wannan aikin na farko bashi da tsada sosai, yana iya haifar da kasada mai yawa daga baya lokacin da kuka ƙara bayanai.
    ///
    /// Idan kuna da ra'ayin adadin bayanan da `String` zai rike, yi la'akari da hanyar [`with_capacity`] don hana sake rabon abu da yawa.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Irƙiri sabon fanko `String` tare da keɓaɓɓiyar damar.
    ///
    /// String`s suna da abin adanawa na ciki don riƙe bayanan su.
    /// Da damar da yake da tsawon cewa buffer, kuma za a iya tuhumar neman a rika tare da [`capacity`] Hanyar.
    /// Wannan hanyar tana haifar da `String` mara amfani, amma wanda ke da madaidaiciyar maɓalli wanda zai iya ɗaukar baiti `capacity`.
    /// Wannan yana da amfani lokacin da zaku iya haɗa tarin bayanai zuwa `String`, rage adadin wuraren da ake buƙata ya yi.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Idan ba iya aiki ne `0`, babu kasafi za su faru, da kuma wannan hanya ne m ga [`new`] Hanyar.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Kirtani ya ƙunshi chars, duk da cewa yana da ƙarfin ƙarin
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ana yin waɗannan duka ba tare da sake sanya wuri ba ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... amma wannan na iya sanya kirtani ya sake zama
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): tare da cfg(test) hanyar `[T]::to_vec` ta asali, wacce ake buƙata don wannan ma'anar hanyar, ba ta samu.
    // Tunda bamu buƙatar wannan hanyar don dalilan gwaji, kawai zan tuttura shi NB duba tsarin slice::hack a cikin slice.rs don ƙarin bayani
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Yana canza vector na baiti zuwa `String`.
    ///
    /// Ana yin kirtani ([`String`]) daga bytes ([`u8`]), kuma vector na baiti ([`Vec<u8>`]) ana yin sa ne da baiti, don haka wannan aikin ya canza tsakanin su biyun.
    /// Ba duk yanyan bishi bane suke da inganci ``String`s, duk da haka: `String` yana buƙatar yana da inganci UTF-8.
    /// `from_utf8()` cak don tabbatar da cewa bytes ne m UTF-8, sa'an nan ya aikata ta hira.
    ///
    /// Idan kun tabbata cewa byte yanki na aiki UTF-8 ne, kuma baku son jawo sama da binciken inganci, akwai sigar mara lafiya ta wannan aikin, [`from_utf8_unchecked`], wanda ke da halaye iri ɗaya amma ya tsallake rajistan.
    ///
    ///
    /// Wannan hanyar za ta kula da ba kwafe vector, don ingancin aiki.
    ///
    /// Idan kana bukatar wani [`&str`] maimakon a `String`, la'akari da [`str::from_utf8`].
    ///
    /// Kuskuren wannan hanyar shine [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Koma [`Err`] idan yanki ne ba UTF-8 tare da bayanin yadda ya dalilin da ya sa bayar da bytes ba UTF-8.vector da kuka motsa shima an haɗa shi.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // wasu bytes, a cikin vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Mun san waɗannan baiti suna da inganci, don haka za mu yi amfani da `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Baiti mara daidai:
    ///
    /// ```
    /// // wasu baiti marasa inganci, a cikin vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Duba takardu don [`FromUtf8Error`] don ƙarin bayani kan abin da zaku iya yi da wannan kuskuren.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Ya canza yanki yanki na baiti zuwa kirtani, gami da haruffa marasa inganci.
    ///
    /// Kirtani ake yi na bytes ([`u8`]), da kuma wani yanki na bytes ([`&[u8]`][byteslice]) aka yi da bytes, don haka wannan aiki sabobin tuba tsakanin biyu.Ba duk yankakken yanki ba ne igiya masu inganci, duk da haka: ana buƙatar igiyoyin su zama masu inganci UTF-8.
    /// A yayin wannan sauyawar, `from_utf8_lossy()` zai maye gurbin kowane tsarin UTF-8 mara inganci tare da [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], wanda yayi kama da wannan:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Idan ka tabbata cewa byte yanki ne m UTF-8, kuma ba ka so don jawo wa kansu sama na hira, akwai wani unsafe version na wannan aiki, [`from_utf8_unchecked`], wanda yana da guda hali amma skips da cak.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Wannan aiki ya kõma mai [`Cow<'a, str>`].Idan mu byte yanki ne da inganci UTF-8, sa'an nan mu bukatar saka maye haruffa, wanda zai canza girman da kirtani, da kuma inganta, ya bukatar wani `String`.
    /// Amma idan yana da riga inganci UTF-8, ba mu bukatar wani sabon kasafi.
    /// Wannan nau'in dawowa yana ba mu damar ɗaukar shari'un biyu.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // wasu bytes, a cikin vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Baiti mara daidai:
    ///
    /// ```
    /// // wasu baiti masu inganci
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Karanta wani UTF-16-shigar wanda ke aiki vector `v` cikin wani `String`, ya dawo [`Err`] idan `v` ƙunshi wani ba daidai ba data.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ba a yin wannan ta hanyar tattara: : <Result<_, _>> () saboda dalilan aiwatarwa.
        // FIXME: za a iya sauƙaƙa aikin a yayin da aka rufe #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decirƙira yanki U0-16-wanda aka sanya masa lamba `v` a cikin `String`, yana maye gurbin bayanai marasa inganci da [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Ba kamar [`from_utf8_lossy`] wanda ya koma wani [`Cow<'a, str>`], `from_utf16_lossy` kõma a `String` tun da UTF-16 zuwa UTF-8 hira bukatar ƙwaƙwalwar kasafi.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Bayar da `String` a cikin kayan haɗin sa.
    ///
    /// Dawo da raw mauni zuwa muhimmi data, da tsawon da kirtani (a cikin bytes), da kuma kasaftawa damar da data (a cikin bytes).
    /// Waɗannan maganganu iri ɗaya ne a cikin tsari ɗaya kamar hujjojin zuwa [`from_raw_parts`].
    ///
    /// Bayan kiran wannan aikin, mai kiran yana da alhakin ƙwaƙwalwar ajiyar da `String` ta sarrafa a baya.
    /// Hanya guda daya da za a yi hakan ita ce ta maida mai nunawa, tsayi, da iyawa ya koma cikin `String` tare da aikin [`from_raw_parts`], wanda hakan zai ba mai halakarwa damar yin tsaftar.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Halicci sabon `String` daga wani tsawon, iya aiki, da kuma akan.
    ///
    /// # Safety
    ///
    /// Wannan ba shi da aminci sosai, saboda yawan masu canzawa waɗanda ba a bincika su ba:
    ///
    /// * Needswaƙwalwar ajiyar a `buf` tana buƙatar a baya an raba ta ta hanyar mai rarrabawa ɗaya daidaitaccen ɗakin karatu yana amfani dashi, tare da daidaitawar da ake buƙata daidai 1.
    /// * `length` yana buƙatar zama ƙasa da ko daidai da `capacity`.
    /// * `capacity` yana buƙatar zama daidai darajar.
    /// * Baiti na `length` na farko a `buf` yana buƙatar zama mai inganci UTF-8.
    ///
    /// Keta waɗannan na iya haifar da matsaloli kamar lalata tsarin bayanan mai rabawa.
    ///
    /// Mallakar `buf` an canza shi yadda yakamata zuwa `String` wanda daga nan zai iya raba wuri, sake sanya wuri ko canza abubuwan da ke cikin ƙwaƙwalwar da mai nunin yake nunawa yadda yake so.
    /// Tabbatar cewa babu wani abu da yake amfani da alamar bayan kiran wannan aikin.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Sabunta wannan lokacin da aka ƙarfafa vec_into_raw_parts.
    ///     // Tsayar da faduwa bayanan Kirtani ta atomatik
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Yana canza vector na baiti zuwa `String` ba tare da bincika cewa kirtani ya ƙunshi ingantaccen UTF-8 ba.
    ///
    /// Duba sigar aminci, [`from_utf8`], don ƙarin bayani.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci saboda baya duba cewa baiti da aka wuce zuwa gare shi ingantacce ne UTF-8.
    /// Idan wannan tauyewa an keta, da zai iya haddasa memory unsafety al'amurran da suka shafi tare da future masu amfani da `String`, kamar yadda sauran na misali library tabbatar da cewa `String`s ne m UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // wasu bytes, a cikin vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Sabobincike `String` zuwa byte vector.
    ///
    /// Wannan yana cinye `String`, don haka ba mu buƙatar yin kwafin abin da ke ciki ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Tsame wani layi yanki dauke da dukan `String`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Sabobin tuba a `String` cikin wani mutable kirtani yanki.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Yana amfani da yanki da aka ba da shi zuwa ƙarshen wannan `String`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Ya dawo da wannan ƙarfin 'Kirtani', a cikin baiti.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Tabbatar cewa wannan ƙarfin String` din aƙalla baiti `additional` ya fi girma fiye da tsayinsa.
    ///
    /// Mayila ana iya ƙaruwa ta fiye da baiti `additional` idan ya ga dama, don hana sake wuraren wurare da yawa.
    ///
    ///
    /// Idan baku son wannan halin na "at least", duba hanyar [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya cika [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Wannan na iya ba ainihin ƙaruwa ba:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s yanzu yana da tsayi na 2 da damar 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Tunda muna da ƙarin damar 8, muna kiran wannan ...
    /// s.reserve(8);
    ///
    /// // ... ba ya ƙaruwa da gaske.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Tabbatar cewa wannan ƙarfin `` Kirtani '' `additional` bytes ya fi girma fiye da tsayinsa.
    ///
    /// Yi la'akari da amfani da hanyar [`reserve`] sai dai idan kun san mafi kyau fiye da wanda aka ba shi.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics idan sabon ƙarfin ya cika `usize`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Wannan na iya ba ainihin ƙaruwa ba:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s yanzu yana da tsayi na 2 da damar 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Tunda muna da ƙarin damar 8, muna kiran wannan ...
    /// s.reserve_exact(8);
    ///
    /// // ... ba ya ƙaruwa da gaske.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Yayi ƙoƙari don adana iya aiki don aƙalla ƙarin abubuwan da za a saka `additional` a cikin `String` da aka bayar.
    /// Mayididdigar na iya keɓe ƙarin sarari don kauce wa wuraren sake wurare da yawa.
    /// Bayan kiran `reserve`, ƙarfin zai fi girma ko daidaita da `self.len() + additional`.
    /// Babu komai idan iyawa ya isa.
    ///
    /// # Errors
    ///
    /// Idan da damar yawo, ko da allocator rahoton wani gazawar, sa'an nan da wani kuskure da aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Yi ajiyar ƙwaƙwalwar ajiya, fita idan ba za mu iya ba
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Yanzu mun san cewa wannan ba zai iya ba OOM ba a tsakiyar aikinmu mai rikitarwa
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Yayi ƙoƙari don adana mafi ƙarancin ƙarfi don daidai abubuwan ƙarin `additional` da za a saka a cikin `String` da aka bayar.
    ///
    /// Bayan kiran `reserve_exact`, ƙarfin zai fi girma ko daidaita da `self.len() + additional`.
    /// Babu komai idan ƙarfin ya riga ya isa.
    ///
    /// Lura cewa mai ba da kuɗin na iya ba tarin wuri fiye da yadda yake buƙata.
    /// Sabili da haka, ba za a dogara da ƙarfin iya zama daidai kaɗan.
    /// Fi son `reserve` idan ana tsammanin shigarwar future.
    ///
    /// # Errors
    ///
    /// Idan da damar yawo, ko da allocator rahoton wani gazawar, sa'an nan da wani kuskure da aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Yi ajiyar ƙwaƙwalwar ajiya, fita idan ba za mu iya ba
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Yanzu mun san cewa wannan ba zai iya ba OOM ba a tsakiyar aikinmu mai rikitarwa
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Arfafa ƙarfin wannan `String` don daidaita tsayinsa.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Rinarfafa ƙarfin wannan `String` tare da ƙananan layi.
    ///
    /// Capacityarfin zai kasance aƙalla babba kamar tsawonsa da ƙimar da aka bayar.
    ///
    ///
    /// Idan ƙarfin yanzu yana ƙasa da ƙananan iyaka, wannan ba komai bane.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Ya shafi [`char`] da aka bayar zuwa ƙarshen wannan `String`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Yana dawo da yanki byte na wannan kayan 'Kirtani'.
    ///
    /// Kuskuren wannan hanyar shine [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Shortens wannan `String` zuwa kayyade tsawon.
    ///
    /// Idan `new_len` ya fi tsayin ƙarfin kirtani na yanzu, wannan ba shi da tasiri.
    ///
    ///
    /// Ka lura da cewa wannan hanya yana da wani sakamako a kan kasaftawa damar da kirtani
    ///
    /// # Panics
    ///
    /// Panics idan `new_len` ba karya a kan wani [`char`] iyaka.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Ta kawar da karshe hali daga kirtani buffer da kuma dawo da shi.
    ///
    /// Koma [`None`] idan wannan `String` ne komai.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Cire [`char`] daga wannan `String` a matsayin baiti kuma ya dawo da shi.
    ///
    /// Wannan aikin *O*(*n*) ne, saboda yana buƙatar yin kwafin kowane abu a cikin maƙallin.
    ///
    /// # Panics
    ///
    /// Panics idan `idx` ya fi girma ko daidai da tsayin `` Kirtani '', ko kuma idan bai kwanta a kan iyakar [`char`] ba.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Cire dukkan matakan wasan kwaikwayon `pat` a cikin `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Yayi daidai za a gano da kuma cire iteratively, don haka a lokuta inda alamu zoba, kawai na farko juna za a iya cire:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // KYAUTA: farawa da ƙarewa zasu kasance akan iyakokin baiti utf8 ta kowace
        // abubuwan bincike
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Yana riƙe da haruffan da mai zancen ya ayyana kawai.
    ///
    /// A wasu kalmomin, cire duk haruffa `c` kamar `f(c)` ya dawo da `false`.
    /// Wannan hanya aiki a wurin, da ziyartar kowane hali daidai sau daya a cikin na asali domin, kuma ya tserar da oda na riƙe haruffa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Ainihin tsari na iya zama da amfani don bin sahun waje, kamar fihirisa.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Nuna idx zuwa char na gaba
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Abun da ake sakawa a halin cikin wannan `String` a byte matsayi.
    ///
    /// Wannan aikin *O*(*n*) ne saboda yana buƙatar yin kwafin kowane abu a cikin maɓallin ajiyewa.
    ///
    /// # Panics
    ///
    /// Panics idan `idx` ne ya fi girma fiye da `String` ta tsawon, ko idan ba karya a kan wani [`char`] iyaka.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Abun da ake sakawa kirtani a cikin wannan `String` din a wani bigire.
    ///
    /// Wannan aikin *O*(*n*) ne saboda yana buƙatar yin kwafin kowane abu a cikin maɓallin ajiyewa.
    ///
    /// # Panics
    ///
    /// Panics idan `idx` ne ya fi girma fiye da `String` ta tsawon, ko idan ba karya a kan wani [`char`] iyaka.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Ya dawo da bayanin maye gurbin abubuwan da ke cikin wannan `String`.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci saboda baya duba cewa baiti da aka wuce zuwa gare shi ingantacce ne UTF-8.
    /// Idan wannan tauyewa an keta, da zai iya haddasa memory unsafety al'amurran da suka shafi tare da future masu amfani da `String`, kamar yadda sauran na misali library tabbatar da cewa `String`s ne m UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Dawo da tsawon wannan `String`, a bytes, ba [`char`] s ko graphemes.
    /// A wasu kalmomin, shi bazai abin da wani mutum ya wadãtu da tsawon da kirtani.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Ya dawo `true` idan wannan `String` yana da tsayin sifili, kuma `false` ba haka ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ya raba kirtani zuwa biyu a ma'aunin byte da aka bayar.
    ///
    /// Koma wani sabon kasaftawa `String`.
    /// `self` yana da baiti `[0, at)`, kuma `String` da aka dawo yana da baiti `[at, len)`.
    /// `at` dole ne ya kasance a kan iyakar lambar lambar UTF-8.
    ///
    /// Lura cewa damar `self` ba ta canza ba.
    ///
    /// # Panics
    ///
    /// Panics idan `at` baya kan iyakar lambar lambar `UTF-8`, ko kuma idan ya wuce ƙarshen lambar lambar kirtani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncates wannan `String`, cire duk abubuwan da ke ciki.
    ///
    /// Duk da yake wannan yana nufin `String` zai sami tsayin sifili, baya taɓa ƙarfinsa.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Irƙira mai sharar ruwa wanda ke cire takamaiman kewayon a cikin `String` kuma yana samar da `chars` da aka cire.
    ///
    ///
    /// Note: An cire kewayon kayan aiki koda kuwa ba'a cinye maganan har zuwa ƙarshe.
    ///
    /// # Panics
    ///
    /// Panics idan masomin ko karshen aya ba karya a kan wani [`char`] iyaka, ko idan suka yi daga haddi.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Cire zangon har zuwa the daga kirtani
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Cikakken kewayawa yana share kirtani
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Amintaccen ƙwaƙwalwar ajiya
        //
        // Sigar Kirtani na Drain bashi da al'amuran tsaro na ƙwaƙwalwar ajiyar vector.
        // Bayanai kawai bayyane ne bayyananne.
        // Saboda cire zangon yana faruwa a Drop, idan mai zafin Drain ya malalo, cirewar ba zai faru ba.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Auki lamuni guda biyu.
        // Ba za a sami damar shigar da Kirtani na &mut ba har sai an gama maimaita shi, a Drop.
        let self_ptr = self as *mut _;
        // KIYAYEWAR: `slice::range` da `is_char_boundary` yi da ya dace haddi cak.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Ta kawar da kayyade range a cikin kirtani, da kuma maye gurbin shi tare da ba kirtani.
    /// A ba kirtani ba ya bukatar ya zama guda tsawon matsayin zangon.
    ///
    /// # Panics
    ///
    /// Panics idan masomin ko karshen aya ba karya a kan wani [`char`] iyaka, ko idan suka yi daga haddi.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Sauya zangon har zuwa β daga kirtani
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Amintaccen ƙwaƙwalwar ajiya
        //
        // Replace_range ba shi da ƙwaƙwalwar aminci al'amurran da suka shafi wata vector Splice.
        // na sigar vector.Bayanai kawai bayyane ne bayyananne.

        // GARGADI: liningirƙirar wannan canjin zai zama mara kyau (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // GARGADI: liningirƙirar wannan canjin zai zama mara kyau (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Amfani `range` sake zai zama unsound (#81138) Muna zaton haddi ya ruwaito ta hanyar `range` zama guda, amma wani fito na fito aiwatar iya canza tsakanin kira
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Ya canza wannan `String` ɗin zuwa cikin ``'' Box`] ``<`['' str`]` `>.
    ///
    /// Wannan zai sauke duk wani damar da ta wuce kima.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Yana dawo da yanki na baiti (``u8`) wanda aka yi ƙoƙari ya juya zuwa `String`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // wasu baiti marasa inganci, a cikin vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Ya mayar da baiti da aka yi ƙoƙari ya canza zuwa `String`.
    ///
    /// Wannan hanya da aka kame a kauce wa kasafi.
    /// Zai cinye kuskure, yana motsa fitar da baiti, don haka kwafin baiti baya buƙatar a yi su.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // wasu baiti marasa inganci, a cikin vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Kawo wani `Utf8Error` don samun ƙarin bayanai game da hira gazawar.
    ///
    /// Nau'in [`Utf8Error`] wanda [`std::str`] ya bayar yana wakiltar kuskuren da zai iya faruwa yayin canza yanki na [`u8`] zuwa [`&str`].
    /// A wannan ma'ana, yana da wani analogue zuwa `FromUtf8Error`.
    /// Dubi takaddun sa don ƙarin cikakkun bayanai game da amfani da shi.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // wasu baiti marasa inganci, a cikin vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // baiti na farko baya aiki anan
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Saboda muna yin aiki akan 'String`s, zamu iya kaucewa aƙalla kaso ɗaya ta hanyar samun zaren farko daga mai karantawa kuma mu haɗa shi da duk kirtani masu zuwa.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Saboda muna iterating kan shanu, za mu iya (potentially) guje wa a kalla daya kasafi da samun da farko abu da kuma appending to shi duka da m abubuwa.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Abin da aka sauƙaƙa don ba da damar buga shi don `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Esirƙira komai na `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Ana aiwatar da mai ba da sabis na `+` don haɗa igiyoyin biyu.
///
/// Wannan yana jan cikin `String` a kan hagu-hannun gefen kuma sake amfani da buffer (girma da shi idan ya cancanta).
/// Wannan ne yake aikata don kauce wa allocating wani sabon `String` kuma kwashe dukan abinda ke ciki a kowane aiki, wanda zai kai ga *Ya*(*n*^ 2) yanã gudãna lokaci a lõkacin da gina wani *n*-byte kirtani ta maimaita concatenation.
///
///
/// Kirtani a gefen dama yana aro ne kawai;ana kwafin abubuwan da ke ciki cikin `String` da aka dawo da su.
///
/// # Examples
///
/// Haɗa biyu `` Kirtani '' yana ɗaukar na farko da daraja kuma ya karɓi na biyu:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` an motsa kuma ba za a iya amfani da shi a nan ba.
/// ```
///
/// Idan kana son ci gaba da amfani da `String` na farko, zaka iya haɗa shi ka haɗa shi da mai ɗumbin maimakon:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` har yanzu yana aiki a nan.
/// ```
///
/// Concatenating `&str` yanka za a iya yi ta hanyar mayar da farko zuwa `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Ana aiwatar da mai aiki na `+=` don haɗawa zuwa `String`.
///
/// Wannan yana da halayya iri ɗaya da hanyar [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Nau'in laƙabi na [`Infallible`].
///
/// Wannan laƙabin ya kasance don dacewar baya, kuma mai yiwuwa a ƙarshe rage shi.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait don canza ƙima zuwa `String`.
///
/// Wannan trait ana aiwatar dashi ta atomatik don kowane nau'i wanda ke aiwatar da [`Display`] trait.
/// Saboda haka, `ToString` bai kamata a aiwatar dashi kai tsaye ba:
/// [`Display`] kamata a aiwatar a maimakon, da kuma ka samu `ToString` aiwatar for free.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Sabobin da aka bayar zuwa `String`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// A cikin wannan aiwatarwar, hanyar `to_string` panics idan aiwatarwar `Display` ta dawo da kuskure.
/// Wannan yana nuna kuskuren aiwatar da `Display` tunda `fmt::Write for String` baya dawo da kuskure kansa.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Jagora gama gari shine kada ayi jigilar ayyuka na yau da kullun.
    // Koyaya, cire `#[inline]` daga wannan hanyar yana haifar da koma baya na rashin kulawa.
    // See <https://github.com/rust-lang/rust/pull/74852>, na karshe ƙoƙari kokarin cire shi.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Sabobincike `&mut str` zuwa `String`.
    ///
    /// An rarraba sakamakon a kan dutsen.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: gwajin yana jan cikin libstd, wanda ke haifar da kurakurai a nan
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Sabobin tuba da aka boxed `str` yanki zuwa wani `String`.
    /// Sanannen abu ne cewa yanki ne na `str`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Sabobin tuba da aka `String` zuwa boxed `str` yanki da cewa mallakar.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Sabobin da zaren yanki a cikin bambancin aro.
    /// Ba a yin rarar tarin abubuwa, kuma ba a kofe zaren ba.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Sabobinda Kirtani cikin Nau'in mallaka.
    /// Ba a yin rarar tarin abubuwa, kuma ba a kofe zaren ba.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Sabobin bayanan Kirtani zuwa bambance bambancen bashi.
    /// Ba a yin rarar tarin abubuwa, kuma ba a kofe zaren ba.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Sabobin tuba da aka `String` zuwa vector `Vec` cewa riko da dabi'u na irin `u8`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Mai fadada ruwa don `String`.
///
/// Wannan tsarin an ƙirƙira shi ta hanyar hanyar [`drain`] akan [`String`].
/// Duba bayanansa don ƙarin.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Za'ayi amfani dashi azaman&'amut Kirtani a cikin mai lalatawa
    string: *mut String,
    /// Fara ɓangare don cirewa
    start: usize,
    /// Ofarshen ɓangare don cirewa
    end: usize,
    /// Yankin sauran zangon da za a cire
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Yi amfani da Vec::drain.
            // "Reaffirm" ana duba iyakokin don kaucewa sake shigar da lambar panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Koma sauran (sub) kirtani na wannan iterator a matsayin yanki.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: rashin damuwa AsRef yana motsawa ƙasa lokacin daidaitawa.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment lokacin da tabbatar da dorewar `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>na Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> don Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}