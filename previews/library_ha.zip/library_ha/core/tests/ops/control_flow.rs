use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Wannan ba farfajiyar farfajiyar ƙasa ba ce, amma yana taimakawa sanya `?` arha a tsakanin su, koda kuwa LLVM ba koyaushe zai iya cin gajiyarta ba a yanzu.
    //
    // (Sakamakon baƙin ciki da zaɓi zaɓi bai dace ba, don haka ControlFlow ba zai iya daidaita duka ba.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}