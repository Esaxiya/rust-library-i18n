use core::task::Poll;

#[test]
fn poll_const() {
    // gwajin da cewa hanyoyin da `Poll` ne mai amfani a cikin wani const mahallin

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}