use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri yayi jinkiri sosai
fn exact_sanity_test() {
    // Wannan gwajin ya ƙare abin da kawai zan iya ɗauka shi ne batun kusurwa game da aikin ɗakunan karatu na `exp2`, wanda aka bayyana a duk lokacin da muke amfani da C.
    // A cikin VS 2013 wannan aikin yana da matsala kamar yadda wannan gwajin ya kasa yayin haɗi, amma tare da VS 2015 kwaron ya bayyana tsayayyen yayin gwajin yana da kyau.
    //
    // A kwaro ya zama alama wani bambanci a samu darajar `exp2(-1057)`, inda a VS 2013 ta kõma da wani biyu tare da bit juna 0x2 kuma a VS 2015 ta kõma 0x20000.
    //
    //
    // Domin yanzu kawai watsi da wannan gwajin gaba ɗaya a kan MSVC kamar yadda shi ke gwada da sauran wurare ta wata hanya, kuma muna ba super sha'awar gwada kowane dandali ta exp2 aiwatar.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}