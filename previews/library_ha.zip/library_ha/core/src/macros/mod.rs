#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Tana zuwa ko dai `$crate::panic::panic_2015` ko `$crate::panic::panic_2021` dangane da edition na kira.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Yana tabbatar da cewa maganganu biyu daidai suke da juna (ta amfani da [`PartialEq`]).
///
/// A panic, wannan Macro zai buga da dabi'u na maganganu da su cire kuskure wakilci.
///
///
/// Kamar [`assert!`], wannan macro yana da nau'i na biyu, inda za'a iya samar da saƙon panic na al'ada.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Sake buɗe hanyoyin da ke ƙasa suna da niyya.
                    // Idan ba tare da su ba, an fara aiwatar da tsarin karbar bashi tun kafin a kimanta darajojin, wanda hakan ke haifar da sannu a hankali.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Sake buɗe hanyoyin da ke ƙasa suna da niyya.
                    // Idan ba tare da su ba, an fara aiwatar da tsarin karbar bashi tun kafin a kimanta darajojin, wanda hakan ke haifar da sannu a hankali.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Yana tabbatar da cewa maganganu biyu basu daidaita da juna ba (ta amfani da [`PartialEq`]).
///
/// A panic, wannan Macro zai buga da dabi'u na maganganu da su cire kuskure wakilci.
///
///
/// Kamar [`assert!`], wannan macro yana da nau'i na biyu, inda za'a iya samar da saƙon panic na al'ada.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Sake buɗe hanyoyin da ke ƙasa suna da niyya.
                    // Idan ba tare da su ba, an fara aiwatar da tsarin karbar bashi tun kafin a kimanta darajojin, wanda hakan ke haifar da sannu a hankali.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Sake buɗe hanyoyin da ke ƙasa suna da niyya.
                    // Idan ba tare da su ba, an fara aiwatar da tsarin karbar bashi tun kafin a kimanta darajojin, wanda hakan ke haifar da sannu a hankali.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Shelanta cewa wata Boolean magana ne `true` a Runtime.
///
/// Wannan zai kira [`panic!`] macro idan ba za'a iya kimanta bayanin da aka bayar ba zuwa `true` a lokacin gudu.
///
/// Kamar [`assert!`], wannan Macro ma yana da na biyu version, inda wani al'ada panic saƙo za a iya bayar.
///
/// # Uses
///
/// Ba kamar [`assert!`] ba, ana amfani da bayanan `debug_assert!` kawai a cikin ingantattun abubuwan gini ta tsohuwa.
/// An gyara ginawa ba zai kashe `debug_assert!` kalamai sai `-C debug-assertions` an shige zuwa tarawa.
/// Wannan yana sanya `debug_assert!` amfani ga cak waɗanda suke da tsada sosai don kasancewa a cikin ginin sakewa amma yana iya taimakawa yayin ci gaba.
/// Sakamakon fadada `debug_assert!` koyaushe irin sahihi ne.
///
/// Tabbatarwa mara izini yana ba da damar shirin a cikin halin rashin daidaito ya ci gaba da gudana, wanda zai iya samun sakamakon da ba zato ba tsammani amma ba ya gabatar da rashin tsaro muddin wannan kawai ya faru ne a cikin amintaccen lambar.
///
/// A yi kudin na assertions, duk da haka, shi ne ma'auni a general.
/// Sauya [`assert!`] tare da `debug_assert!` ana ƙarfafa shi ne kawai bayan an kammala aikin sosai, kuma mafi mahimmanci, kawai a cikin amintaccen lambar!
///
/// # Examples
///
/// ```
/// // da panic sako ga wadannan assertions ne stringified darajar da magana ba.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // aiki mai sauqi qwarai
/// debug_assert!(some_expensive_computation());
///
/// // tabbatar da tare da wata al'ada saƙo
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Yana tabbatar da cewa maganganu biyu daidai suke da juna.
///
/// A panic, wannan Macro zai buga da dabi'u na maganganu da su cire kuskure wakilci.
///
/// Ba kamar [`assert_eq!`] ba, ana amfani da bayanan `debug_assert_eq!` kawai a cikin ingantattun abubuwan gini ta tsohuwa.
/// An gyara ginawa ba zai kashe `debug_assert_eq!` kalamai sai `-C debug-assertions` an shige zuwa tarawa.
/// Wannan ya sa `debug_assert_eq!` amfani ga cak cewa sun yi tsada ya zama ba a saki ginawa amma iya zama taimako a lokacin ci gaba.
///
/// A sakamakon fadada `debug_assert_eq!` ne ko da yaushe irin bari.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Yana tabbatar da cewa maganganu biyu basu daidaita da juna ba.
///
/// A panic, wannan Macro zai buga da dabi'u na maganganu da su cire kuskure wakilci.
///
/// Ba kamar [`assert_ne!`] ba, ana amfani da bayanan `debug_assert_ne!` kawai a cikin ingantattun abubuwan gini ta tsohuwa.
/// Ingantaccen gini ba zai aiwatar da bayanan `debug_assert_ne!` ba sai dai idan an miƙa `-C debug-assertions` zuwa mai tarawa.
/// Wannan ya sa `debug_assert_ne!` amfani ga cak cewa sun yi tsada ya zama ba a saki ginawa amma iya zama taimako a lokacin ci gaba.
///
/// A sakamakon fadada `debug_assert_ne!` ne ko da yaushe irin bari.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Koma ko ba magana matches wani daga cikin ba alamu.
///
/// Kamar a `match` magana, da abin kwaikwaya za a iya optionally bi ta `if` kuma mai tsaro magana cewa yana da damar yin amfani da sunayen daure da juna.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Cire sakamako ko kuma yada kuskuren sa.
///
/// A `?` sadarwarka da aka kara don maye gurbin `try!` kuma ya kamata a yi amfani maimakon.
/// Bugu da ƙari, `try` kalma ce da aka tanada a cikin Rust 2018, don haka idan dole ne ku yi amfani da shi, kuna buƙatar amfani da [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` yayi daidai da ba [`Result`].Idan akwai bambancin `Ok`, magana tana da darajar darajar da aka nade.
///
/// A hali na `Err` bambance-bambancen, shi retrieves ciki kuskure.`try!` sa'an nan ya yi aikin hira ta amfani da `From`.
/// Wannan yana ba da canjin atomatik tsakanin kurakurai na musamman da ƙari na gaba ɗaya.
/// Sakamakon kuskuren da aka haifar ana nan da nan ya dawo.
///
/// Saboda farkon sama, `try!` iya kawai a yi amfani a cikin ayyuka da cewa komawa [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // The fi so Hanyar sauri dawo Kurakurai
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // A baya Hanyar sauri dawo Kurakurai
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Wannan yayi daidai da:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Yana rubuta bayanan da aka tsara a cikin abin adanawa.
///
/// Wannan macro ta karɓi 'writer', zaren tsari, da jerin jayayya.
/// Muhawara za a tsara bisa ga kayyade format kirtani da sakamakon za a wuce zuwa marubuci.
/// A marubuci na iya zama wani darajar da `write_fmt` Hanyar.kullum wannan zo daga wani aiwatar da ko dai da [`fmt::Write`] ko [`io::Write`] trait.
/// Macro dawo da abin da `write_fmt` Hanyar dawo.fiye da [`fmt::Result`], ko wani [`io::Result`].
///
/// Dubi [`std::fmt`] don ƙarin bayani a kan format kirtani cakude.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A koyaushe iya shigo biyu `std::fmt::Write` da `std::io::Write` da kuma kira `write!` a kan abubuwa aiwatar da ko dai, kamar yadda abubuwa ba yawanci yi duka biyu.
///
/// Duk da haka, da a koyaushe dole shigo da traits tsallakar da haka su sunayen yi ba rikici:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // yana amfani da fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // yana amfani da io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Wannan Macro za a iya amfani da a `no_std` setups da.
/// A cikin saitin `no_std` kuna da alhakin aiwatar da bayanan abubuwan da aka gyara.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Rubuta bayanan da aka tsara a cikin ma'aji, tare da sabon layin da aka saka.
///
/// A kan dukkan dandamali, sabon layin shine LINE FEED mai halin (`\n`/`U+000A`) shi kaɗai (babu ƙarin CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Don ƙarin bayani, duba [`write!`].Don bayani game da tsarin rubutun kirtani, duba [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A koyaushe iya shigo biyu `std::fmt::Write` da `std::io::Write` da kuma kira `write!` a kan abubuwa aiwatar da ko dai, kamar yadda abubuwa ba yawanci yi duka biyu.
/// Duk da haka, da a koyaushe dole shigo da traits tsallakar da haka su sunayen yi ba rikici:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // yana amfani da fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // yana amfani da io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Nuna unreachable code.
///
/// Wannan shi ne amfani da wani lokaci da cewa tarawa ba zai iya sanin cewa wasu code shi ne unreachable.Misali:
///
/// * Daidaita makamai tare da yanayin tsaro.
/// * Madaukai waɗanda ke ƙarewa da ƙarfi.
/// * Iterators cewa kuzari ƙarasa.
///
/// Idan ya tabbatar da dalilin da cewa code ne unreachable ya tabbatar da ba daidai ba, da shirin nan da nan terminates da [`panic!`].
///
/// A unsafe takwaransa na wannan Macro ne [`unreachable_unchecked`] aiki, wanda zai haifar da maras bayyani hali idan code ne kai.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Wannan koyaushe [`panic!`].
///
/// # Examples
///
/// Dace da makamai:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // tattara kuskure idan an yi sharhi akai
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // daya daga cikin matalautan implementations na x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Nuna unimplemented code ta panicking da sako na "not implemented".
///
/// Wannan damar your code to irin-rajistan shiga, wanda ke da amfani idan kana prototyping ko aiwatar da wani trait cewa bukatar mahara hanyoyin da ba ka shirya na amfani da duk.
///
/// Bambanci tsakanin `unimplemented!` da [`todo!`] ne cewa yayin da `todo!` bayyana wani niyyar aiwatar da ayyuka daga baya kuma da sakon ne "not yet implemented", `unimplemented!` sa babu wannan da'awar.
/// Sakon ta shine "not implemented".
/// Hakanan wasu IDEs zasu yi alama `` todo! '' S.
///
/// # Panics
///
/// Wannan nufin ko da yaushe [`panic!`] saboda `unimplemented!` ne kawai a shorthand for `panic!` da tsayayyen, takamaiman saƙo.
///
/// Kamar `panic!`, wannan macro tana da nau'i na biyu don nuna ƙimar al'ada.
///
/// # Examples
///
/// Ka ce muna da trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Muna son aiwatar da `Foo` don 'MyStruct', amma saboda wasu dalilai kawai yana da ma'anar aiwatar da aikin `bar()`.
/// `baz()` kuma `qux()` zai har yanzu bukatar da za a fassara shi a mu aiwatar da `Foo`, amma ba za mu iya amfani da `unimplemented!` a cikin ma'anar don ba da damar mu code to tara.
///
/// Mun har yanzu so a yi shirin mu daina gudu idan unimplemented hanyoyin da ake kai.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Babu ma'ana ga `baz` a `MyStruct`, don haka ba mu da wata ma'ana a nan sam.
/////
///         // Wannan zai nuna "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Muna da wasu dabaru nan, mun iya ƙara wani sako zuwa unimplemented!nuna mu tsallake.
///         // Wannan zai nuna: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Nuna ba a kare ba code.
///
/// Wannan zai iya zama da amfani idan kana prototyping kuma kawai neman a yi your code typecheck.
///
/// Bambanci tsakanin [`unimplemented!`] da `todo!` ne cewa yayin da `todo!` bayyana wani niyyar aiwatar da ayyuka daga baya kuma da sakon ne "not yet implemented", `unimplemented!` sa babu wannan da'awar.
/// Sakon ta shine "not implemented".
/// Hakanan wasu IDEs zasu yi alama `` todo! '' S.
///
/// # Panics
///
/// Wannan koyaushe [`panic!`].
///
/// # Examples
///
/// Ga misalin wasu lambar ci gaba mai gudana.Muna da trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Muna son aiwatar da `Foo` akan ɗayan nau'in mu, amma kuma muna son yin aiki akan kawai `bar()` na farko.Domin mu code to tara, muna bukatar mu yi `baz()`, don haka ba za mu iya amfani da `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // aiwatarwa ya tafi nan
///     }
///
///     fn baz(&self) {
///         // bari ba damu game da aiwatar da baz() a yanzu
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // mu ba har ma da yin amfani da baz(), don haka wannan shi ne m.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Ma'anar gina-in macros.
///
/// Mafi yawa daga cikin Macro Properties (kwanciyar hankali, Ganuwar, da dai sauransu) da ake dauka daga tushen code nan, tare da togiya na fadada ayyuka ta hanyar mayar da Macro bayanai cikin jimloli, wadanda ayyuka suna bayar da mai tarawa.
///
///
pub(crate) mod builtin {

    /// Yana haifar da tattarawa don kasawa tare da kuskuren kuskuren lokacin da aka ci karo.
    ///
    /// Ya kamata a yi amfani da wannan macro lokacin da crate ke amfani da dabarun tattara abubuwa don samar da mafi kyawun saƙonnin kuskure don yanayin kuskure.
    ///
    /// Yana da mai tarawa-matakin nau'i na [`panic!`], amma fitarda wani kuskure a lokacin *tari* maimakon a *Runtime*.
    ///
    /// # Examples
    ///
    /// Misalan waɗannan misalai guda biyu sune yanayin macros da `#[cfg]`.
    ///
    /// Emit mafi tarawa kuskure idan wani Macro an shige daidai ba dabi'u.
    /// Ba tare da karshe branch, da mai tarawa zai har yanzu emit wani kuskure, amma kuskure ta sakon zai ba ambaci biyu inganci dabi'u.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emit tarawa kuskure idan daya daga wani adadin siffofin ne ba samuwa.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yana gina sigogi don ɗayan maƙerin-tsarin kirtani.
    ///
    /// Wannan Macro ayyuka da shan mai tsara kirtani na zahiri dauke da `{}` ga kowane ƙarin shaida wuce.
    /// `format_args!` shirya ƙarin sigogi don tabbatar da cewa ana iya fassara fitowar azaman kirtani kuma yana iya yin takaddama cikin nau'i guda.
    /// Duk wani darajar da aiwatarwa da [`Display`] trait za a iya wuce zuwa `format_args!`, kamar yadda za a iya wani [`Debug`] aiwatar a wuce zuwa `{:?}` a cikin tsara kirtani.
    ///
    ///
    /// Wannan macro tana samar da darajar nau'in [`fmt::Arguments`].Wannan darajar za a iya wuce zuwa macros cikin [`std::fmt`] domin yin amfani madosa.
    /// All sauran Tsarin macros ([`format!`], [`write!`], [`println!`], da dai sauransu) an proxied ta hanyar wannan daya.
    /// `format_args!`, sabanin ta samu macros, zai kawar tula asusun tarayya.
    ///
    /// Za ka iya amfani da [`fmt::Arguments`] darajar da cewa `format_args!` kõma a `Debug` da `Display` riƙa kamar yadda gani a kasa.
    /// A misali ma nuna cewa `Debug` da `Display` format to wannan abu: da fassara format kirtani a `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Don ƙarin bayani, duba takardun a [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Same kamar yadda `format_args`, amma in ji wani newline a karshen.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Duba yanayin canjin yanayi a tattara lokaci.
    ///
    /// Wannan Macro zai fadada zuwa tamanin da mai suna yanayi m at tara lokaci, samar da gwaggwabar riba nuna irin `&'static str`.
    ///
    ///
    /// Idan ba a bayyana maɓallin muhalli ba, to za a fitar da kuskuren tattarawa.
    /// Don ba emit a tara kuskure ne, amfani da [`option_env!`] Macro maimakon.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Za ka iya siffanta sakon kuskuren ta wucewa a kirtani a matsayin na biyu siga:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Idan ba a bayyana mahalli na `documentation` ba, zaku sami kuskuren mai zuwa:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optionally Duba wani yanayi m at tara lokaci.
    ///
    /// Idan mai suna yanayi m ne ba a tara lokaci, wannan zai fadada a cikin wani furci na irin `Option<&'static str>` wanda darajar ne `Some` na tamanin da yanayi m.
    /// Idan yanayi m ba ba, to, wannan zai fadada zuwa `None`.
    /// Dubi [`Option<T>`][Option] don ƙarin bayani a kan irin wannan.
    ///
    /// Ba a taɓa ɓatar da kuskuren lokaci lokacin amfani da wannan macro ba tare da la'akari da ko canjin yanayi ya kasance ko a'a.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates identifiers cikin daya ganowa.
    ///
    /// Wannan Macro daukan wani yawan wakafi-rabu identifiers, kuma concatenates su duka a cikin daya, samar da gwaggwabar riba mai magana da shi ne wani sabon ganowa.
    /// Lura cewa kiwon lafiya da ke sa shi irin wannan Macro ba zai iya kama gida canji.
    /// Hakanan, a matsayin ƙa'idar ƙa'ida, ana ba da izinin macros kawai a cikin abu, sanarwa ko matsayin bayyanawa.
    /// Wannan yana nufin yayin da za ka iya amfani da wannan Macro for nufin data kasance canji, ayyuka ko kayayyaki da dai sauransu, ba za ka iya ayyana wani sabon daya tare da shi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_asters! (sabo, mai daɗi, suna) { }//ba za a iya amfani da shi ta wannan hanyar ba!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ataddamar da wallafe-wallafe a cikin yanki madaidaiciya yanki.
    ///
    /// Wannan Macro daukan wani yawan wakafi-rabu literals, samar da gwaggwabar riba nuna irin `&'static str` wanda wakiltar duk na literals zaman masu alaƙa bar-to-dama.
    ///
    ///
    /// Ingantaccen bayani game da mahimman bayanai don daidaitawa.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tana zuwa line lamba a kan abin da aka kira.
    ///
    /// Tare da [`column!`] da [`file!`], wadannan macros samar debugging bayanai ga developers game da wuri a cikin Madogararsa.
    ///
    /// The fadada magana yana da irin `u32` kuma shi ne 1-tushen, don haka na farko line a kowane fayil evaluates zuwa 1, na biyu zuwa 2, da dai sauransu.
    /// Wannan ya yi daidai da kuskure saƙonnin da kowa compilers ko rare Editocin.
    /// A koma layi ne *Ba dole ba ne* da layi na `line!` kiran kanta, amma maimakon na farko Macro kiran manyan har zuwa kiran da `line!` Macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Tana da shafi yawan at wanda shi an kirãyi.
    ///
    /// Tare da [`line!`] da [`file!`], wadannan macros samar debugging bayanai ga developers game da wuri a cikin Madogararsa.
    ///
    /// The fadada magana yana da irin `u32` kuma shi ne 1-tushen, don haka na farko shafi a kowane layi evaluates zuwa 1, na biyu zuwa 2, da dai sauransu.
    /// Wannan ya yi daidai da kuskure saƙonnin da kowa compilers ko rare Editocin.
    /// Shafin da aka dawo ba *ba lallai bane* layin kiran `column!` kansa, amma maimakon kiran macro na farko wanda zai kai ga kiran na `column!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Tana da sunan fayil a wadda ta an kirãyi.
    ///
    /// Tare da [`line!`] da [`column!`], wadannan macros samar debugging bayanai ga developers game da wuri a cikin Madogararsa.
    ///
    /// The fadada magana yana rubuta `&'static str`, da kuma mayar da fayil ba rõƙon `file!` Macro kanta, amma maimakon na farko Macro kiran manyan har zuwa kiran da `file!` Macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Yanke hujjojinsa.
    ///
    /// Wannan macro ɗin zai samar da nau'in nau'in nau'in `&'static str` wanda shine haɓaka dukkan tokens da aka wuce zuwa macro.
    /// Ba a sanya takunkumi kan aiwatar da kiran kiran macro kanta ba.
    ///
    /// Lura cewa fadada sakamakon shigarwar tokens na iya canzawa a cikin future.Ya kamata ka yi hankali idan ka dõgara a kan fitarwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ya hada da wani UTF-8 shigar wanda ke aiki fayil a matsayin kirtani.
    ///
    /// Fayil ɗin yana kusa da fayil na yanzu (daidai da yadda ake samun kayayyaki).
    /// A bayar da hanyar da aka fassara a cikin wani dandali na musamman hanya a tara lokaci.
    /// Saboda haka, misali, addu'ace da Windows hanya dauke da backslashes `\` zai ba tara daidai a kan Unix.
    ///
    ///
    /// Wannan macro zata bada bayanin nau'in `&'static str` wanda shine abinda ke cikin fayil din.
    ///
    /// # Examples
    ///
    /// Da alama akwai fayiloli guda biyu a cikin wannan kundin adireshin tare da abubuwan da ke gaba:
    ///
    /// Fayil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fayil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Tattara bayanan 'main.rs' kuma yanã gudãna sakamakon binary zai buga "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ya hada da fayil azaman ishara zuwa tsarin baiti.
    ///
    /// Fayil ɗin yana kusa da fayil na yanzu (daidai da yadda ake samun kayayyaki).
    /// A bayar da hanyar da aka fassara a cikin wani dandali na musamman hanya a tara lokaci.
    /// Saboda haka, misali, addu'ace da Windows hanya dauke da backslashes `\` zai ba tara daidai a kan Unix.
    ///
    ///
    /// Wannan Macro zai samar nuna irin `&'static [u8; N]` wanda shi ne abinda ke ciki na fayil.
    ///
    /// # Examples
    ///
    /// Da alama akwai fayiloli guda biyu a cikin wannan kundin adireshin tare da abubuwan da ke gaba:
    ///
    /// Fayil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fayil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Tattara bayanan 'main.rs' kuma yanã gudãna sakamakon binary zai buga "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tana zuwa wani layi cewa wakiltar na yanzu module hanya.
    ///
    /// A halin yanzu module hanya za a iya tunanin yadda matsayi na kayayyaki manyan baya har zuwa na crate root.
    /// Sashin farko na hanyar da aka dawo shine sunan crate a halin yanzu ana tattara shi.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Yana kimanta haɗuwa da alaƙa na tutocin daidaitawa a lokacin tarawa.
    ///
    /// Bugu da kari ga `#[cfg]` sifa, wannan Macro aka bayar don ba da damar Boolean magana kimantawa na sanyi flags.
    /// Wannan akai-akai take kaiwa zuwa kasa duplicated code.
    ///
    /// Aikin da aka gabatar wa wannan macro daidai yake da sifar [`cfg`].
    ///
    /// `cfg!`, sabanin `#[cfg]`, ba ya cire wani code da kawai bincika to gaskiya ko karya.
    /// Alal misali, duk tubalan a wani if/else magana bukatar zama inganci idan `cfg!` da ake amfani da yanayin, ko da kuwa abin da `cfg!` ne kimantawa.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses fayil a matsayin magana ko wani abu bisa ga mahallin.
    ///
    /// Fayil aka located dangi zuwa yanzu fayil (kamar wancan zuwa yadda kayayyaki da ake samu).An fassara hanyar da aka bayar ta hanyar takamaiman hanyar dandamali a tattara lokaci.
    /// Saboda haka, misali, addu'ace da Windows hanya dauke da backslashes `\` zai ba tara daidai a kan Unix.
    ///
    /// Amfani da wannan macro galibi ra'ayi ne mara kyau, saboda idan fayil ɗin ya ɓace azaman magana, za a sanya shi a cikin lambar da ke kewaye ba da tsabta ba.
    /// Wannan zai iya haifar da canji ko ayyuka zama daban-daban daga abin da fayil sa ran idan akwai canji ko ayyuka da cewa suna da wannan sunan a halin yanzu fayil.
    ///
    ///
    /// # Examples
    ///
    /// Da alama akwai fayiloli guda biyu a cikin wannan kundin adireshin tare da abubuwan da ke gaba:
    ///
    /// Fayil 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fayil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Tattara abubuwa 'main.rs' da gudanar da sakamakon binary zai buga "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Shelanta cewa wata Boolean magana ne `true` a Runtime.
    ///
    /// Wannan zai kira [`panic!`] macro idan ba za'a iya kimanta bayanin da aka bayar ba zuwa `true` a lokacin gudu.
    ///
    /// # Uses
    ///
    /// Ana tabbatar da tabbatarwar koyaushe a cikin cire kuskure da sake ginin, kuma ba za a iya kashe shi ba.
    /// See [`debug_assert!`] for assertions cewa ba sa cikin saki gina ta tsohuwa.
    ///
    /// Matsera code iya dogara a kan `assert!` don tilasta gudu-lokaci invariants cewa, idan keta zai iya haifar da unsafety.
    ///
    /// Sauran amfani-lokuta na `assert!` sun hada da gwajin da kuma tilasta gudu-lokaci invariants a hadari code (wanda take hakkin ba zai iya haifar da unsafety).
    ///
    ///
    /// # Custom Saƙonni
    ///
    /// Wannan Macro yana da wani biyu tsari, inda wani al'ada panic saƙo za a iya bayar da ko ba tare da muhawara don tsara.
    /// Dubi [`std::fmt`] domin ginin kalma domin wannan form.
    /// Bayanin da aka yi amfani dashi azaman mahawara ta tsari za a kimanta ne kawai idan furucin ya gaza.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // da panic sako ga wadannan assertions ne stringified darajar da magana ba.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // aiki mai sauqi qwarai
    ///
    /// assert!(some_computation());
    ///
    /// // tabbatar da tare da wata al'ada saƙo
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Línea taro.
    ///
    /// Karanta [unstable book] don amfanin.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-style-line taro.
    ///
    /// Karanta [unstable book] don amfanin.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Uleungiyar layi mai layi-matakin Module.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Kwafi shige tokens cikin misali fitarwa.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Sa ko disables burbushi aiki amfani ga debugging sauran macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Sifa Macro amfani da su yi amfani samu macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Sanya fasalin macro da aka sanya wa aiki don juya shi zuwa gwajin naúrar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Sifa Macro amfani da wani aiki a juya shi a cikin nasa tarihin gwajin.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// An aiwatar daki-daki, daga cikin `#[test]` da `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Sifa Macro amfani da wani a tsaye don yin rijista da shi a matsayin duniya allocator.
    ///
    /// Dubi ma [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Yana kiyaye abun da aka yi amfani da shi idan hanyar da ta wuce tana da sauƙi, kuma tana cire shi in ba haka ba.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Tana duk `#[cfg]` da `#[cfg_attr]` halaye a cikin code gutsure shi ke amfani da su.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Cikakken aikin aiwatarwa na mai rikodin `rustc`, kar a yi amfani da shi.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Cikakken aikin aiwatarwa na mai rikodin `rustc`, kar a yi amfani da shi.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}