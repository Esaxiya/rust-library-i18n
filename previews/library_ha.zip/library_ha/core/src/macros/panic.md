Panics yanzu thread.

Wannan damar da wani shirin karbi nan da nan da kuma samar da feedback zuwa ga mai kiran da shirin.
`panic!` Ya kamata a yi amfani a lokacin da mai shirin kai wani unrecoverable jihar.

Wannan Macro ne cikakken hanya zuwa siffantãwa yanayi a misali code, kuma a gwaje-gwaje.
`panic!` An hankali daura da `unwrap` Hanyar biyu [`Option`][ounwrap] da [`Result`][runwrap] enums.
Dukansu implementations kira `panic!` lokacin da aka tsayar da su ga [`None`] ko [`Err`] bambance-bambancen karatu.

Lokacin amfani `panic!()` za ka iya saka wani layi dangi, da cewa an gina ta amfani da [`format!`] cakude.
Wannan dangi ne used lokacin da alura da panic cikin kiran Rust thread, haifar da thread zuwa panic gaba ɗaya.

The hali na default `std` hook, watau
da code cewa gudanar kai tsaye bayan da panic da aka ambaci, shi ne ya buga sakon dangi zuwa `stderr` tare da file/line/column bayanai na `panic!()` kira.

Za ka iya override da panic hook amfani [`std::panic::set_hook()`].
Ciki da hook a panic za a iya isa ga matsayin `&dyn Any + Send`, wanda ya ƙunshi ko dai wani `&str` ko `String` for yau da kullum `panic!()` addu'a ne.
Don panic da darajar da wani sauran irin, [`panic_any`] za a iya amfani da su.

[`Result`] enum shine mafi kyawun mafita don murmurewa daga kurakurai fiye da amfani da `panic!` macro.
Ya kamata ayi amfani da wannan macro don gujewa ci gaba ta amfani da ƙimomin da ba daidai ba, kamar daga asalin waje.
Cikakken bayani game da sarrafa kuskure ana samunsu a cikin [book].

Duba kuma macro [`compile_error!`], don haɓaka kurakurai yayin tattarawa.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Aiwatarwa a halin yanzu

Idan babban thread panics zai tsaya duk zaren da kuma kawo karshen shirin da code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





