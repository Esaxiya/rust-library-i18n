//! Yana bayyana ma'anar mai mallakar `IntoIter` don tsararru.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Mai magana da darajar [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Wannan ne tsararru muna iterating kan.
    ///
    /// Abubuwa da index `i` inda `alive.start <= i < alive.end` ba a bada tukuna, kuma suna da inganci tsararru shigarwar.
    /// Abubuwan da ke da alamomi `i < alive.start` ko `i >= alive.end` an riga an samar dasu kuma dole ne a sake samun su!Wadanda matattu abubuwa ma iya zama a cikin gaba daya uninitialized jihar!
    ///
    ///
    /// Saboda haka da invariants ne:
    /// - `data[alive]` ne rai (watau ya ƙunshi aiki abubuwa)
    /// - `data[..alive.start]` kuma `data[alive.end..]` sun mutu (watau an riga an karanta abubuwan kuma dole ne a sake taɓa su!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Abubuwan da ke cikin `data` waɗanda ba a ba da izini ba tukuna.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Halicci sabon iterator kan ba `array`.
    ///
    /// *Fadakarwa*: wannan hanyar na iya kaskantar da ita a cikin future, bayan [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Nau'in `value` shine `i32` a nan, maimakon `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // KIYAYEWAR: The canja nan ne ainihin lafiya.A Docs na `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` yana da tabbacin samun girma da daidaito iri ɗaya
        // > kamar yadda `T`.
        //
        // Takaddun ɗin har ma suna nuna transmute daga tsararrun `MaybeUninit<T>` zuwa tsararren `T`.
        //
        //
        // Tare da wannan, wannan ƙaddamarwa ya gamsar da masu canzawa.

        // FIXME(LukasKalbertodt): a zahiri amfani da `mem::transmute` a nan, da zarar ya yi aiki tare da haɗin gwaninta:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Har zuwa wannan, za mu iya amfani da `mem::transmute_copy` don ƙirƙirar ɗan kwafi kaɗan a matsayin nau'I na daban, sannan a manta da `array` don kada a sauke shi.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Koma wani marar sakewa yanki na duk abubuwa da cewa ba a bada tukuna.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // KYAUTA: Mun san cewa duk abubuwan da ke cikin `alive` an fara su da kyau.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Koma wani mutable yanki na duk abubuwa da cewa ba a bada tukuna.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // KYAUTA: Mun san cewa duk abubuwan da ke cikin `alive` an fara su da kyau.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Samun na gaba index daga gaban.
        //
        // Xara `alive.start` ta 1 yana kula da mai canzawa game da `alive`.
        // Duk da haka, saboda wannan canji, na wani dan gajeren lokaci, da da rai zone ba `data[alive]` babu kuma, amma `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Karanta kashi daga tsararru.
            // KIYAYEWAR: `idx` ne wani index cikin tsohon "alive" yankin na
            // tsararruKaranta wannan abun yana nufin cewa `data[idx]` ana ɗaukarsa matacce ne a yanzu (watau kar a taɓa).
            // Kamar yadda `idx` shi ne farkon na rai-zone, da rai zone ne yanzu `data[alive]` sake, tanadi duk invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Samun na gaba index daga baya.
        //
        // Ragewar `alive.end` ta 1 yana kula da mai canzawa game da `alive`.
        // Koyaya, saboda wannan canjin, a ɗan gajeren lokaci, yankin mai rai ba `data[alive]` ba kuma, amma `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Karanta kashi daga tsararru.
            // KIYAYEWAR: `idx` ne wani index cikin tsohon "alive" yankin na
            // tsararruKaranta wannan abun yana nufin cewa `data[idx]` ana ɗaukarsa matacce ne a yanzu (watau kar a taɓa).
            // Kamar yadda `idx` ya kasance ƙarshen yanki mai rai, yankin mai rai yanzu ya sake `data[alive]`, yana maido da duk masu canzawa.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // KIYAYEWAR: Wannan shi ne hadari: `as_mut_slice` kõma daidai da sub-yanki
        // na abubuwa da cewa ba a koma daga tukuna kuma cewa zama da za a kika aika.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ba zai taɓa ambaliya ba saboda rayayye `` mai rai. Farawa <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// A iterator lalle rahoton daidai tsawon.
// Adadin abubuwan "alive" (wanda har yanzu za'a samar dashi) shine tsawon zangon `alive`.
// Wannan zangon ya ragu a tsayi a cikin ko dai `next` ko `next_back`.
// An ko da yaushe decremented ta 1 a cikin wadanda hanyoyin, amma kawai idan `Some(_)` aka mayar da su.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Note, ba mu da gaske bukatar dace da ainihin wannan rai iyaka, don haka za mu iya kawai clone cikin biya diyya 0 la'akari da inda `self` ne.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone duk abubuwa masu rai.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Rubuta clone a cikin sabon tsararru, sannan kuma sabunta zangon sa na rayuwa.
            // Idan cloning panics, za mu daidai sauke baya abubuwa.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kawai buga da abubuwa da aka ba bada tukuna: ba za mu iya samun damar bada abubuwa babu kuma.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}