//! A `Clone` trait for iri da cewa ba zai iya zama 'jabu kofe'.
//!
//! A Rust, wasu sauki iri ne "implicitly copyable" da kuma lokacin da ka sanya musu ko wuce su kamar yadda muhawara, da mai karɓar zai samu wani kwafin, da barin asali darajar a wurin.
//! Wadannan iri ba ya bukatar kasafi kwafa da ba su da finalizers (ie, ba su dauke da mallakar kwalaye, ko aiwatar da [`Drop`]), don haka da mai tarawa gan su cheap da kuma lafiya ga kwafa.
//!
//! Ga wasu iri kofe dole ne a sanya baro-baro, ta al'ada aiwatar da [`Clone`] trait da kuma kiran da [`clone`] Hanyar.
//!
//! [`clone`]: Clone::clone
//!
//! Basic amfani misali:
//!
//! ```
//! let s = String::new(); // Nau'in kirtani yana amfani da Clone
//! let copy = s.clone(); // don haka za mu iya sanya shi
//! ```
//!
//! Don sauƙaƙe aiwatar da Clone trait, zaku iya amfani da `#[derive(Clone)]`.Example:
//!
//! ```
//! #[derive(Clone)] // mu ƙara clone trait zuwa Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // kuma yanzu za mu iya clone shi!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait gama gari don ƙarfin kwafin abu a bayyane.
///
/// Ya bambanta daga [`Copy`] a cikin wannan [`Copy`] a fakaice kuma bashi da tsada sosai, yayin da `Clone` koyaushe bayyane yake kuma yana iya zama ko mai tsada.
/// Domin tilasta wadannan halaye, Rust ba ka damar reimplement [`Copy`], amma za ka iya reimplement `Clone` da gudu sabani code.
///
/// Tun `Clone` ne mafi general fiye da [`Copy`], za ka iya ta atomatik yi wani abu [`Copy`] zama `Clone` da.
///
/// ## Derivable
///
/// Wannan trait za a iya amfani da `#[derive]` idan duk filayen ne `Clone`.The `derive`d aiwatar da [`Clone`] kira [`clone`] a kan kowane filin.
///
/// [`clone`]: Clone::clone
///
/// Domin a Generic struct, `#[derive]` aiwatar `Clone` yanaye ta ƙara daure `Clone` a kan Generic sigogi.
///
/// ```
/// // `derive` aiwatar da Clone don Karatu<T>lokacin da T yake Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ta yaya zan iya aiwatar da `Clone`?
///
/// Nau'in da suke [`Copy`] kamata da maras muhimmanci aiwatar da `Clone`.Formari bisa ƙa'ida:
/// idan `T: Copy`, `x: T`, kuma `y: &T`, sa'an nan `let x = y.clone();` ne daidai da `let x = *y;`.
/// Aiwatarwa da hannu yakamata yayi taka tsantsan don kiyaye wannan mara canzawa;koda yake, lambar da ba amintacciya ba dole ta dogara da ita don tabbatar da lafiyar ƙwaƙwalwar ajiya.
///
/// Misali shine tsarin tsari wanda yake rike da alamar aiki.A wannan halin, aiwatar da `Clone` ba za a iya `` samu 'ba, amma ana iya aiwatar da shi azaman:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementarin masu aiwatarwa
///
/// Baya ga [implementors listed below][impls], nau'ikan masu zuwa suna aiwatar da `Clone`:
///
/// * Nau'in kayan aiki (watau, nau'ikan nau'ikan da aka ayyana kowane aiki)
/// * Nau'in alamomin aiki (misali, `fn() -> i32`)
/// * Nau'ukan tsararru, ga dukkan masu girma, idan nau'ikan abun shima yana aiwatar da `Clone` (misali, `[i32; 123456]`)
/// * Tuple iri, idan kowane bangaren kuma aiwatar da `Clone` (misali, `()`, `(i32, bool)`)
/// * Ƙulli iri, idan sun kama wani darajar daga yanayi ko idan dukan irin wannan kama dabi'u yi `Clone` kansu.
///   Note cewa canji kama da raba tunani ko da yaushe yi `Clone` (ko da referent ya aikata ba), yayin da canji kama da mutable reference taba yi `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Ya dawo da kwafin ƙimar.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str aiwatar da Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Aikin kwafa-aiki daga `source`.
    ///
    /// `a.clone_from(&b)` shi ne daidai da `a = b.clone()` a aiki, amma za a iya overridden to sake amfani da albarkatun da na `a` don kauce wa ba dole ba asusun tarayya.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Samu Macro da samar da wani impl na trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): wadannan structs ana amfani kawai da#[samu] a tabbatar da cewa kowane bangaren na wani irin aiwatarwa clone ko Kwafi.
//
//
// Waɗannan ƙa'idodin ba za su taɓa bayyana a cikin lambar mai amfani ba.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Aiwatar da `Clone` don nau'ikan gargajiya.
///
/// Implementations cewa ba za a iya bayyana a Rust aka aiwatar a `traits::SelectionContext::copy_clone_conditions()` a `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Rabawa nassoshi za a iya cloned, amma mutable nassoshi *ba zai iya*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Rabawa nassoshi za a iya cloned, amma mutable nassoshi *ba zai iya*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}