// watsi da-shirya-filelength Wannan fayil kusan na musamman kunshi da definition of `Iterator`.
// Ba za mu iya raba abin da a cikin mahara fayiloli.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Hanyar ma'amala don ma'amala da masu sarrafawa.
///
/// Wannan shi ne babban iterator trait.
/// Don ƙarin game da manufar iterators kullum, don Allah ganin [module-level documentation].
/// A musamman, kana iya sani yadda za a [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Nau'in abubuwan da ake sanya musu aiki.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Na cigaba da iterator da kuma dawo da gaba darajar.
    ///
    /// Koma [`None`] lokacin iteration an gama.
    /// Mutane daya-daya iterator implementations iya zabi a ci gaba iteration, kuma haka kiran `next()` sake iya ko ba ƙarshe fara dawo [`Some(Item)`] sake a wasu batu.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // A kira zuwa next() dawo da gaba darajar ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... sannan kuma Babu wanda sau ɗaya ya wuce.
    /// assert_eq!(None, iter.next());
    ///
    /// // More kira iya ko ba koma `None`.A nan, su ko da yaushe so.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Koma haddi a kan sauran tsawon na iterator.
    ///
    /// Musamman, `size_hint()` kõma a tuple inda na farko kashi ne ƙananan ɗaure ciki daidai, da kuma na biyu da rabi ne babba a ɗaure.
    ///
    /// Rabin na biyu na abin da aka dawo dashi shi ne ``'' zaɓi ']`` ``' '' '' '' '' ''.
    /// A [`None`] nan nufin cewa ko dai akwai wani da aka sani babba ɗaure ciki daidai, ko da na sama a ɗaure shi ne ya fi girma fiye [`usize`].
    ///
    /// # aiwatar rubutu
    ///
    /// An ba da tilasta cewa an iterator aiwatar da ake samu da ayyana yawan abubuwa.A buggy iterator iya samar da kasa da ƙananan daure ko fiye da babba daure na abubuwa.
    ///
    /// `size_hint()` ne da farko za a yi nufin amfani ga optimizations kamar ta ke sarari ga abubuwa na iterator, amma dole ne ba za a amince da su misali, ƙetare haddi cak a unsafe code.
    /// Rashin aiwatar da `size_hint()` bai kamata ya haifar da take hakkin aminci ba.
    ///
    /// Wannan ce, da aiwatar kamata samar da wani daidai hakkin, saboda in ba haka ba zai zama wani take hakkin da trait ta yarjejeniya.
    ///
    /// The default aiwatar dawo `(0,` [`None`] ')` wanda shi ne daidai ga wani iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Misali mafi rikitarwa:
    ///
    /// ```
    /// // Har ma lambobi daga sifili zuwa goma.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mun iya iterate daga sifili zuwa sau goma.
    /// // Sanin cewa shi ta biyar daidai da ba zai yiwu ba tare da aiwatar da filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Bari mu ƙara biyar mafi lambobin da chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // yanzu duka iyakokin an kara su da biyar
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Dawo `None` ga wani babba a ɗaure:
    ///
    /// ```
    /// // wani iyaka iterator ya ba babba daure da kuma matsakaicin yiwu ƙananan mamaye
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Cinye mai maimaitawa, yana ƙidaya yawan maimaitawa yana dawo dashi.
    ///
    /// Wannan hanya za ta kira [`next`] akai-akai har sai [`None`] aka ci karo, ya dawo da yawan sau da shi ga [`Some`].
    /// Note cewa [`next`] ya za a kira a kalla sau daya ko idan iterator ba shi da wani abubuwa.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Hali Ya Zube
    ///
    /// A Hanyar ya aikata ba tsaron da yawo, don haka kirgawa abubuwa na wani iterator tare da fiye da [`usize::MAX`] abubuwa ko dai na samar da ba daidai ba sakamakon ko panics.
    ///
    /// Idan an kunna bayanan tabbatarwa, panic yana da tabbaci.
    ///
    /// # Panics
    ///
    /// Wannan aiki ƙarfin panic idan iterator yana da fiye da [`usize::MAX`] abubuwa.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Jan cikin iterator, ya dawo da na karshe kashi.
    ///
    /// Wannan hanyar za ta kimanta mai har sai ta dawo [`None`].
    /// Duk da yake yin haka, shi yana ajiye turbar halin yanzu kashi.
    /// Bayan [`None`] aka koma, `last()` zai sa'an nan koma na karshe kashi ya gani ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Na cigaba da iterator da `n` abubuwa.
    ///
    /// Wannan hanyar za ta tsallake abubuwan `n` da sauri ta hanyar kiran [`next`] har zuwa sau `n` har sai an sami [`None`].
    ///
    /// `advance_by(n)` zai dawo [`Ok(())`][Ok] idan iterator nasarar cigaba ne ta hanyar `n` abubuwa, ko [`Err(k)`][Err] idan [`None`] aka ci karo da, inda `k` ne yawan abubuwa da iterator ne ci-gaba da kafin yanã gudãna daga abubuwa (watau
    /// da tsawon iterator).
    /// Lura cewa `k` ne ko da yaushe kasa da `n`.
    ///
    /// Kira `advance_by(0)` ba cinye wani abubuwa da kuma ko da yaushe ya kõmo [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` kawai aka tsallake
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Ya dawo da ``n`th element na maimaita magana.
    ///
    /// Kamar mafi yawan Indexing ayyukan, count farawa daga sifili, saboda haka `nth(0)` dawo da farko darajar, `nth(1)` na biyu, da sauransu.
    ///
    /// Note cewa duk gabanin abubuwa, kazalika da koma rabi, za a cinye daga iterator.
    /// Wannan yana nufin cewa gabanin abubuwa za a jefar, da kuma cewa ya kira `nth(0)` mahara sau a kan wannan iterator zai koma daban-daban abubuwa.
    ///
    ///
    /// `nth()` zai dawo [`None`] idan `n` ne fi ko daidai to da tsawon iterator.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Kira `nth()` sau da yawa baya sake maimaita maimaitawa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Dawo `None` idan akwai kasa da `n + 1` abubuwa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Halitta wani iterator fara a wannan batu, amma da fatar da ba adadin a kowane iteration.
    ///
    /// Lura 1: Sashin farko na mai maimaitawa koyaushe za'a dawo dashi, ba tare da la'akari da matakin da aka bayar ba.
    ///
    /// Note 2: A lokacin nan ne, watsi da abubuwa ana ja ba gyarawa.
    /// `StepBy` yayi kamar jerin `next(), nth(step-1), nth(step-1),…`, amma kuma yana da 'yanci yin hali kamar jerin
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Wace hanya aka yi amfani da iya canza ga wasu iterators for yi dalilai.
    /// Na biyu hanya zai ci gaba da iterator a baya, kuma mai yiwuwa ta cinye mafi abubuwa.
    ///
    /// `advance_n_and_return_first` daidai yake da:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// A Hanyar zai panic idan ba mataki ne `0`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Aukan masu amfani guda biyu kuma ƙirƙirar sabon mai magana akan duka biyun a jere.
    ///
    /// `chain()` zai dawo da sabon mai magana wanda zai fara aiwatar da shi akan dabi'u daga na farkon sannan kuma akan dabi'u daga na biyu.
    ///
    /// A wasu kalmomin, shi ya danganta biyu iterators tare, a cikin sarkar.🔗
    ///
    /// [`once`] ne fiye da amfani ga daidaita guda darajar cikin sarkar na sauran nau'o'in iteration.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tun da ya kasance hujjarsu zuwa `chain()` amfani [`IntoIterator`], za mu iya wuce wani abu da za a iya tuba a cikin wani [`Iterator`], ba kawai wani [`Iterator`] kanta.
    /// Alal misali, yanka (`&[T]`) yi [`IntoIterator`], kuma haka za a iya wuce zuwa `chain()` kai tsaye:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Idan ka yi aiki tare da Windows API, za ka iya so su maida [`OsStr`] zuwa `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' biyu iterators cikin guda iterator na nau'i-nau'i.
    ///
    /// `zip()` dawo da wani sabon iterator cewa zai iterate kan biyu sauran iterators, ya dawo a tuple inda na farko kashi zo daga farko iterator, da kuma na biyu kashi zo daga biyu iterator.
    ///
    ///
    /// A wasu kalmomin, shi zips biyu iterators tare, a cikin wani guda.
    ///
    /// Idan ko dai iterator kõma [`None`], [`next`] daga zipped iterator zai koma [`None`].
    /// Idan na farko iterator kõma [`None`], `zip` zai gajarta da'ira da `next` ba za a kira a karo na biyu iterator.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tunda hujja zuwa `zip()` tana amfani da [`IntoIterator`], zamu iya wuce duk wani abu da za'a iya canza shi zuwa [`Iterator`], ba kawai [`Iterator`] kanta ba.
    /// Misali, yanka (`&[T]`) aiwatar [`IntoIterator`], don haka ana iya wuce shi zuwa `zip()` kai tsaye:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ana amfani dashi sau da yawa don zana abin da ba shi da iyaka zuwa mai iyaka.
    /// Wannan yana aiki saboda mai iyakancewa zai dawo [`None`], yana ƙare zik din.Bugawa tare da `(0..)` na iya yin kama da [`enumerate`] sosai:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Halicci sabon iterator wanda sanya wani kwafin `separator` tsakanin m abubuwa na asali iterator.
    ///
    /// A hali `separator` ba yi [`Clone`] ko bukatun da za a lissafta kowane lokaci, yi amfani da [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Abu na farko daga `a`.
    /// assert_eq!(a.next(), Some(&100)); // A SEPARATOR.
    /// assert_eq!(a.next(), Some(&1));   // Abu na gaba daga `a`.
    /// assert_eq!(a.next(), Some(&100)); // A SEPARATOR.
    /// assert_eq!(a.next(), Some(&2));   // Abu na karshe daga `a`.
    /// assert_eq!(a.next(), None);       // Mai gama aikin ya gama.
    /// ```
    ///
    /// `intersperse` na iya zama da amfani ƙwarai don shiga abubuwan mai magana ta amfani da abu na yau da kullun:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Creatirƙiri sabon mai magana wanda zai sanya wani abu wanda `separator` ya ƙirƙira tsakanin abubuwa kusa da maɓallin asalin.
    ///
    /// The ƙulli za a kira daidai da zarar kowane lokaci da wani abu da aka sanya tsakanin biyu m abubuwa daga muhimmi iterator.
    /// musamman, da ƙulli ba kira idan tamkar iterator da ake samu kasa da biyu abubuwa da kuma bayan na karshe abu ne bada.
    ///
    ///
    /// Idan iterator ta abu aiwatarwa [`Clone`], shi yana iya zama da sauki don amfani [`intersperse`].
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Abu na farko daga `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // A SEPARATOR.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Abu na gaba daga `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // A SEPARATOR.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // A karshe kashi daga daga `v`.
    /// assert_eq!(it.next(), None);               // Mai gama aikin ya gama.
    /// ```
    ///
    /// `intersperse_with` za a iya amfani da su a yanayi inda da SEPARATOR bukatar a lissafta:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Ulli zai iya maye gurbin mahallin don ƙirƙirar abu.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Daukan wani ƙulli, kuma halitta wani iterator wanda ya kira da cewa ƙulli a kan kowane kashi.
    ///
    /// `map()` canza daya iterator cikin wani, ta hanyar da shaida:
    /// wani abu da aiwatar da [`FnMut`].Yana samar da wani sabon iterator wanda ya kira wannan ƙulli a kan kowane kashi na asali iterator.
    ///
    /// Idan kai ne mai kyau a tunanin a iri, za ka iya tunanin `map()` kamar wannan:
    /// Idan kana da wani iterator cewa ba ku da abubuwa na wasu irin `A`, kuma kana so wani iterator wasu sauran irin `B`, za ka iya amfani da `map()`, wucewa a ƙulli cewa daukan wani `A` da kuma dawo da wani `B`.
    ///
    ///
    /// `map()` ne conceptually kama wani [`for`] madauki.Koyaya, kamar yadda `map()` ya kasance malalaci, ana amfani dashi mafi kyau lokacin da kuna aiki tare da sauran masu ba da hanya.
    /// Idan kuna yin wasu nau'ikan madaidaici don sakamako na gefe, ana ɗauka karin magana ne don amfani da [`for`] fiye da `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Idan kana yin wasu irin gefen sakamako, fi son [`for`] zuwa `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // kar a yi haka:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // shi ba zai ko kashe, kamar yadda shi ne m.Rust zai yi muku gargaɗi game da wannan.
    ///
    /// // Maimakon haka, yi amfani for:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Yana kiran ƙulli akan kowane ɓangaren mai maimaita magana.
    ///
    /// Wannan daidai ne da yin amfani da wani [`for`] madauki a kan iterator, ko da yake `break` da `continue` ba zai yiwu daga wani ƙulli.
    /// Yana kullum mafi idiomatic yi amfani da `for` madauki, amma `for_each` iya zama mafi m lokacin da sarrafa abubuwa a karshen ƙara iterator sarƙoƙi.
    ///
    /// A wasu lokuta `for_each` iya zama da sauri fiye da madauki, domin shi zai yi amfani da ciki iteration a kan adaftan kamar `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Domin irin wannan karamin misali, a `for` madauki iya zama sabta, amma `for_each` iya zama fin so su ci gaba da wani aikin style tare da ƙara iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Irƙira mai magana wanda ke amfani da ƙulli don ƙayyade idan ya kamata a samar da wani abu.
    ///
    /// Idan aka ba wani abu to rufewa dole ne ya dawo da `true` ko `false`.A koma iterator zai samar kawai abubuwa ga wanda ƙulli kõma gaskiya.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Saboda ƙulli wuce zuwa `filter()` daukan wani tunani, kuma da yawa iterators iterate kan nassoshi, wannan take kaiwa zuwa wani yiwu rudani halin da ake ciki, inda da irin ƙulli ne biyu da tunani:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // bukatar biyu * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yana ta kowa zuwa maimakon amfani da destructuring a kan shawara don su washe kayan tafi daya:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // biyu&kuma *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ko duka biyu:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // biyu &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// daga wadannan yadudduka.
    ///
    /// Lura cewa `iter.filter(f).next()` ne daidai da `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Esirƙira mai maimaitawa wanda ke tacewa da taswirori.
    ///
    /// Maimaitawar da aka dawo da ita kawai ta sami darajar `` darajar '' wanda abin da aka kawo ya dawo da `Some(value)`.
    ///
    /// `filter_map` za a iya amfani da su don yin sarƙoƙi na [`filter`] da [`map`] mafi taƙaitaccen.
    /// A misali a kasa nuna yadda wani `map().filter().map()` za a iya taqaitaccen zuwa guda kira zuwa `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ga misali iri ɗaya, amma tare da [`filter`] da [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Irƙira mai magana wanda ke ba da ƙididdigar ƙididdigar yanzu da ƙimar ta gaba.
    ///
    /// Maimaitawa ya dawo ya samar da nau'ikan nau'i-nau'i `(i, val)`, inda `i` shine ƙididdigar halin yanzu kuma `val` shine ƙimar da mai maimaita ya dawo.
    ///
    ///
    /// `enumerate()` yana riƙe ƙidayarsa azaman [`usize`].
    /// Idan kana so ka lissafa ta a daban-daban sized lamba, da [`zip`] aiki na samar da irin wannan aiki.
    ///
    /// # Hali Ya Zube
    ///
    /// A Hanyar ya aikata ba tsarħwa da yawo, don haka enumerating fiye [`usize::MAX`] abubuwa ko dai na samar da ba daidai ba sakamakon ko panics.
    /// Idan an kunna bayanan tabbatarwa, panic yana da tabbaci.
    ///
    /// # Panics
    ///
    /// A koma iterator iya panic idan ya-a-koma index zai anab a [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Esirƙira mai ƙira wanda zai iya amfani da [`peek`] don kallon ɓangaren mai zuwa na maimaitawar ba tare da cinye shi ba.
    ///
    /// In ji wani [`peek`] Hanyar zuwa wani iterator.Duba bayanansa don ƙarin bayani.
    ///
    /// Note cewa muhimmi iterator ne har yanzu sun ci gaba a lokacin da [`peek`] aka kira a karo na farko: Domin dawo da gaba da rabi, [`next`] aka kira a kan muhimmi iterator, Saboda haka duk wani gefen effects (watau
    ///
    /// wani abu, wanin debo gaba darajar) na [`next`] Hanyar da za su faru.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() bari mu gani cikin future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // za mu iya peek() mahara sau, da iterator so ba gaba
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // bayan da iterator aka gama, don haka ne peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Creatirƙira mai magana wanda abubuwa [`` tsallake '' bisa la'akari da wanda aka ambata.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` daukan wani ƙulli a matsayin shaida.Zai kira wannan ƙulli akan kowane ɗayan maɓallin, kuma watsi da abubuwa har sai ya dawo `false`.
    ///
    /// Bayan `false` aka koma, `skip_while()`'s aiki ne a kan, da kuma sauran abubuwa suna bada.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Saboda ƙulli ya wuce zuwa `skip_while()` yana ɗauke da tunani, kuma yawancin masu magana suna jinkirtawa a kan nassoshi, wannan yana haifar da yanayi mai rikitarwa, inda nau'in gardamar rufewa yake nuni biyu:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // bukatar biyu * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tsayawa bayan wani na farko `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // alhali kuwa wannan zai zama ƙarya, tunda mun riga mun sami ƙarya, ba a sake amfani da skip_while() ba
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Halitta wani iterator cewa da ake samu abubuwa dangane da wani predicate.
    ///
    /// `take_while()` daukan wani ƙulli a matsayin shaida.Yana zai kira wannan ƙulli a kan kowane kashi na iterator, da kuma samar da abubuwa yayin ta kõma `true`.
    ///
    /// Bayan `false` aka koma, `take_while()`'s aiki ne a kan, da kuma sauran abubuwa suna watsi.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Saboda ƙulli wuce zuwa `take_while()` daukan wani tunani, kuma da yawa iterators iterate kan nassoshi, wannan take kaiwa zuwa wani yiwu rudani halin da ake ciki, inda da irin ƙulli ne biyu da tunani:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // bukatar biyu * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tsayawa bayan wani na farko `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Muna da karin abubuwa da suke kasa da sifiri, amma tun da mun riga samu wani ƙarya, take_while() ba a amfani da wani karin
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Saboda `take_while()` bukatar ya dubi darajar domin ganin idan ya kamata a hada da ko ba, cinyewa iterators za su ga cewa shi ne cire:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` baya nan, saboda an cinye shi don ganin ko tsawa zai daina, amma ba a sake sa shi cikin mai ba da labarin ba.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Halitta wani iterator cewa duka da ake samu abubuwa dangane da wani predicate da maps.
    ///
    /// `map_while()` ɗaukar rufewa a matsayin takaddama.
    /// Yana zai kira wannan ƙulli a kan kowane kashi na iterator, da kuma samar da abubuwa yayin ta kõma [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ga misali iri ɗaya, amma tare da [`take_while`] da [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tsayawa bayan wani na farko [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Muna da karin abubuwa da zai dace da a u32 (4, 5), amma `map_while` koma `None` for `-3` (a matsayin `predicate` koma `None`) da kuma `collect` tsaya a nan ba na farko `None` ci karo.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Saboda `map_while()` bukatar ya dubi darajar domin ganin idan ya kamata a hada da ko ba, cinyewa iterators za su ga cewa shi ne cire:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` baya nan, saboda an cinye shi don ganin ko tsawa zai daina, amma ba a sake sa shi cikin mai ba da labarin ba.
    ///
    /// Note cewa sabanin [`take_while`] wannan iterator ne **ba** Fused.
    /// Hakanan ba'a bayyana abin da wannan mai maimaita ya dawo ba bayan an dawo da [`None`] na farko.
    /// Idan kana bukatar Fused iterator, yi amfani da [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Halitta wani iterator cewa skips farko `n` abubuwa.
    ///
    /// Bayan da suka kasance cinyewa, da sauran abubuwa suna bada.
    /// Maimakon overriding wannan hanya kai tsaye, maimakon override da `nth` Hanyar.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Halitta wani iterator cewa bãyar da farko `n` abubuwa.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ne sau da yawa amfani da wani iyaka iterator, su sa shi guntun:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Idan akwai abubuwan da basu kasa da `n` ba, `take` zai iyakance kansa zuwa girman mai magana kamar haka:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An iterator adaftan kama [`fold`] cewa riko da ciki jiha da kuma samar da wani sabon iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` daukan biyu muhawara: an sa hannu darajar da tsaba da ciki a jihar, da kuma wani ƙulli tare da biyu muhawara, na farko da kasancewa wani mutable tunani da ciki jiha da kuma na biyu mai iterator kashi.
    ///
    /// The ƙulli iya sanya zuwa ciki jiha zuwa rabo jihar tsakanin iterations.
    ///
    /// A iteration, da ƙulli za a iya amfani da kowane kashi na iterator da kuma dawowar darajar daga ƙulli, wani [`Option`], aka bada ta iterator.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // kowane abu, zamu ninka jihar da kashi
    ///     *state = *state * x;
    ///
    ///     // to, za mu bayar da ƙarancin jihar
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Irƙira mai magana wanda ke aiki kamar taswira, amma yana daidaita shimfidar gidaje.
    ///
    /// A [`map`] adaftan da amfani sosai, amma kawai a lokacin da ƙulli shaida samar dabi'u.
    /// Idan samar da wani iterator maimakon, da akwai wani karin Layer na indirection.
    /// `flat_map()` zai cire wannan karin layin a karan kansa.
    ///
    /// Kuna iya tunanin `flat_map(f)` a matsayin kwatankwacin ma'anar ma'anar ", taswira", sannan kuma (`` daidaita '' shiga kamar yadda yake a `map(f).flatten()`.
    ///
    /// Wata hanyar tunani game da `flat_map()`: [`map`] 's ƙulli dawo daya abu domin kowane kashi, da kuma `flat_map()`'s ƙulli dawo da wani iterator ga kowane kashi.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() kõmo wani iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Halitta wani iterator cewa flattens nested tsarin.
    ///
    /// Wannan na da amfani a lokacin da kana da wani iterator na iterators ko wani iterator abubuwa da za a iya juya a cikin iterators kuma kana so ka cire daya matakin na indirection.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Taswira sannan kuma shimfidawa:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() kõmo wani iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Zaka kuma iya sake rubutawa wannan cikin sharuddan [`flat_map()`], wanda shi ne fin so a cikin wannan al'amarin tun da shi ake bayyana niyyar mafi fili:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() kõmo wani iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening kawai kawar da daya matakin na nesting a lokaci:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// A nan mun ga cewa `flatten()` ba yi da wani "deep" shafa.
    /// Maimakon haka, kawai daya matakin na nesting an cire.Wannan shi ne, idan ka `flatten()` wani uku-girma tsararru, sakamakon zai zama biyu-girma da kuma ba daya-girma.
    /// Don samun wani daya-girma tsarin, dole ka `flatten()` sake.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Halitta wani iterator wanda ƙare bayan na farko [`None`].
    ///
    /// Bayan mai magana ya dawo [`None`], kiran future na iya ko ba zai iya ba da [`Some(T)`] ba.
    /// `fuse()` yana daidaita mai magana, yana tabbatar da cewa bayan anyi [`None`], zai dawo da [`None`] koyaushe.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // Maimaitawa wanda ke canzawa tsakanin Wasu da Babu
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // idan yana da ko da, Some(i32), kuma Babu
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // za mu iya ganin mai yi mana magana yana kai da komo
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Duk da haka, da zarar mun fis shi ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // shi zai dawo `None` bayan a karon farko.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Ya aikata wani abu da kowanne kashi na wani iterator, wucewa da darajar on.
    ///
    /// Lokacin amfani iterators, za ku ji sau da yawa Sarkar dama daga gare su tare.
    /// Duk da yake aiki a wannan code, ka iya so su bincika abin da ke faruwa a sassa daban-daban a cikin bututun.Don yin hakan, saka kira zuwa `inspect()`.
    ///
    /// Yana da mafi kowa ga `inspect()` da za a yi amfani da matsayin debugging kayan aiki fiye da ta wanzu a cikin karshe code, amma aikace-aikace na iya samun shi da amfani a wasu yanayi a lokacin da kurakurai bukatar da za a shigad da ake jefar.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // wannan iterator jerin ne hadaddun.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // bari ta ƙara wasu inspect() kira don gudanar da bincike da abin da ke faruwa
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Wannan zai buga:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Rakodin kurakurai kafin yin watsi da su:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Wannan zai buga:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Rowsaddamar da mai magana, maimakon cinye shi.
    ///
    /// Wannan na da amfani domin ba da damar da ake ji iterator adaftan yayin da har yanzu rikewa ikon mallakar na asali iterator.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // idan muka sake kokarin amfani da shi, ba zai yi aiki ba.
    /// // Wadannan layi ba "kuskure: yin amfani da koma darajar: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // bari mu sake gwadawa
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // maimakon, mun ƙara a cikin .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // yanzu wannan ne kawai lafiya:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Canza wani iterator cikin tarin.
    ///
    /// `collect()` iya daukar wani abu iterable, da kuma juya shi a cikin wani dacewa tarin.
    /// Wannan shi ne daya daga cikin mafi iko da hanyoyin da misali library, a yi amfani da wani iri-iri riƙa.
    ///
    /// Mafi kyawun tsari wanda aka yi amfani da `collect()` shine juya jujjuya ɗaya zuwa wani.
    /// Ka dauki wani tarin, kira [`iter`] a kan shi, aikata wani gungu na rikirkida, sa'an nan `collect()` a karshen.
    ///
    /// `collect()` kuma iya haifar da misalin iri cewa ba su da hankula collections.
    /// Alal misali, a [`String`] za a iya gina daga [`char`] s, da kuma wani iterator na [`Result<T, E>`][`Result`] abubuwa za a iya tattara a cikin `Result<Collection<T>, E>`.
    ///
    /// Duba misalan da ke ƙasa don ƙarin.
    ///
    /// Saboda `collect()` ne don haka general, shi zai iya sa matsaloli da irin hasashe.
    /// Kamar wannan, `collect()` yana ɗayan fewan lokacin da zaku ga rubutun da ake kira 'turbofish': `::<>`.
    /// Wannan taimaka da hasashe algorithm fahimta musamman wanda tarin kana kokarin tattara zuwa.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Lura cewa muna buƙatar `: Vec<i32>` a gefen hagu.Wannan saboda zamu iya tattarawa a cikin, misali, [`VecDeque<T>`] a maimakon:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Amfani da 'turbofish' maimakon annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Saboda `collect()` yana damuwa ne kawai game da abin da kuke tarawa a ciki, har yanzu kuna iya amfani da alamar alama, `_`, tare da turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Amfani `collect()` yi [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Idan kana da wani jerin [`Result<T, E>'][`` Sakamakon' 's, zaku iya amfani da `collect()` don ganin ko ɗayansu ya gaza:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // yake ba mu da farko kuskure
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // yake ba mu da jerin amsoshin
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Jan wani iterator, samar da biyu collections daga gare ta.
    ///
    /// A predicate ya wuce zuwa `partition()` iya komawa `true`, ko `false`.
    /// `partition()` kõmo biyu, duk da abubuwa ga wanda ya koma `true`, da kuma duk na abubuwa domin wanda shi koma `false`.
    ///
    ///
    /// Duba kuma [`is_partitioned()`] da [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders da abubuwa na wannan iterator *a-wuri* bisa ga ba predicate, irin wannan cewa dukan waɗanda cewa sama `true` riga dukan waɗanda cewa sama `false`.
    ///
    /// Ya dawo da adadin abubuwan abubuwa `true` da aka samo.
    ///
    /// Ba a kiyaye tsarin dangi na abubuwan da aka raba.
    ///
    /// Dubi ma [`is_partitioned()`] da [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Shãmaki a-wuri tsakanin evens da kuma rashin daidaito
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: kamata mu damu game da count ambaliya?Iyakar hanyar da fiye da
        // `usize::MAX` nassoshi masu canzawa suna tare da ZSTs, waɗanda basu da amfani ga bangare ...

        // Wadannan ayyukan rufewar "factory" suna wanzuwa don kaucewa samun daidaito a cikin `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Akai-akai sami farko `false` da kuma musanya shi da na karshe `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Cak idan abubuwa na wannan iterator ake shãmakancẽwa ne bisa ga ba predicate, irin wannan cewa dukan waɗanda cewa sama `true` riga dukan waɗanda cewa sama `false`.
    ///
    ///
    /// Duba kuma [`partition()`] da [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ko dai duk abubuwa sun gwada `true`, ko sashin farko ya tsaya a `false` kuma mun bincika cewa babu sauran abubuwa `true` bayan haka.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// An iterator Hanyar abin da ya shafi wani aiki, muddin ta kõma nasarar, samar da guda, wasan karshe darajar.
    ///
    /// `try_fold()` daukan biyu muhawara: an sa hannu darajar, da kuma fitattu da ba da biyu muhawara: wani 'accumulator', da kuma wani kashi.
    /// Theulli ko dai ya dawo cikin nasara, tare da ƙimar da mai tarawa ya kamata ya samu na gaba, ko kuma ya dawo da gazawa, tare da ƙimar kuskure da aka watsa shi ga mai kiran nan da nan (short-circuiting).
    ///
    ///
    /// Da farko darajar ne da darajar da accumulator zai yi a kan na farko da kira.Idan da ake ji da ƙulli nasara kan kowane kashi na iterator, `try_fold()` dawo da karshe accumulator matsayin nasara.
    ///
    /// Nadawa ne amfani duk lokacin da ka yi wani tarin wani abu, da kuma son nuna guda darajar daga gare shi.
    ///
    /// # Lura ga Masu Aiwatarwa
    ///
    /// Da dama daga cikin sauran (forward) hanyoyin da default implementations cikin sharuddan da wannan daya, don haka kokarin aiwatar da wannan baro-baro idan ta iya yi wani abu mafi alhẽri daga da default `for` madauki aiwatar.
    ///
    /// A musamman, kokarin da wannan kira `try_fold()` a ciki sassa daga wanda wannan iterator aka hada.
    /// Idan mahara kira da ake bukata, da `?` sadarwarka iya zama m for chaining da accumulator darajar tare, amma hattara wani invariants cewa bukatar da za a tsayar da wadanda farkon ya dawo.
    /// Wannan shi ne wani `&mut self` hanya, don haka iteration bukatar ya zama resumable bayan bugawa da wani kuskure a nan.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jimlar da aka bincika duka abubuwan da aka tsara
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Wannan adadin yana cika lokacin da ake ƙara abubuwan 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Saboda shi gajere ne, sauran abubuwan har yanzu ana samunsu ta hanyar mai sarrafa su.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Hanyar maimaitawa wanda ke amfani da aiki mai faɗuwa ga kowane abu a cikin maimaitawar, tsayawa a kuskuren farko da dawo da kuskuren.
    ///
    ///
    /// Wannan kuma za a iya tunanin yadda fallible nau'i na [`for_each()`] ko matsayin stateless version of [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ya ɗan gajarta, don haka sauran abubuwan har yanzu suna cikin maimaitawa:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Ninki kowane abu a cikin tarawa ta hanyar amfani da aiki, yana dawo da sakamako na karshe.
    ///
    /// `fold()` daukan biyu muhawara: an sa hannu darajar, da kuma fitattu da ba da biyu muhawara: wani 'accumulator', da kuma wani kashi.
    /// The ƙulli dawo da darajar da cewa accumulator ya kamata da na gaba iteration.
    ///
    /// Theimar farko ita ce darajar da mai tarawa zai samu akan kiran farko.
    ///
    /// Bayan ake ji wannan ƙulli a kowane kashi na iterator, `fold()` dawo da accumulator.
    ///
    /// Wannan aiki ne, wani lokacin kira 'reduce' ko 'inject'.
    ///
    /// Nadawa ne amfani duk lokacin da ka yi wani tarin wani abu, da kuma son nuna guda darajar daga gare shi.
    ///
    /// Note: `fold()`, da kuma irin hanyoyin da cewa kẽta dukan iterator, ba ƙarasa for iyaka iterators, ko da a kan traits ga wanda a sakamakon ne determinable a guntun lokaci.
    ///
    /// Note: [`reduce()`] za a iya amfani da su yi amfani da farko rabi a matsayin na farko da darajar, idan accumulator irin da abu irin ne guda.
    ///
    /// # Lura ga Masu Aiwatarwa
    ///
    /// Da dama daga cikin sauran (forward) hanyoyin da default implementations cikin sharuddan da wannan daya, don haka kokarin aiwatar da wannan baro-baro idan ta iya yi wani abu mafi alhẽri daga da default `for` madauki aiwatar.
    ///
    ///
    /// A musamman, kokarin da wannan kira `fold()` a ciki sassa daga wanda wannan iterator aka hada.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // Jimlar dukkanin abubuwan da aka tsara
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Bari muyi tafiya cikin kowane mataki na maimaitawa anan:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Sabili da haka, sakamakonmu na ƙarshe, `6`.
    ///
    /// Yana ta kowa ga mutanen da suka yi amfani da iterators da yawa don amfani mai `for` madauki da jerin abubuwan da za a gina up sakamakon.Waɗannan za a iya juya su cikin `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // domin madauki:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // su ma iri daya ne
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Rage abubuwa zuwa guda ɗaya, ta hanyar maimaita amfani da rage aiki.
    ///
    /// Idan iterator ne komai, ya kõma [`None`].in ba haka ba, ya dawo da sakamakon ragin.
    ///
    /// Ga masu amfani da aƙalla kashi ɗaya, wannan daidai yake da [`fold()`] tare da farkon ɓangaren mai amsawa a matsayin ƙimar farko, yana jujjuya kowane abu mai zuwa a ciki.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Nemo matsakaicin darajar:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Gwaje-gwaje idan kowane kashi na iterator matches a predicate.
    ///
    /// `all()` daukan wani ƙulli cewa kõma `true` ko `false`.Yana shafi wannan ƙulli a kowane kashi na iterator, kuma idan sun koma duk `true`, sa'an nan don haka ya aikata `all()`.
    /// Idan wani daga gare su dawo `false`, ta kõma `false`.
    ///
    /// `all()` ne short-circuiting.a wasu kalmomin, zai daina aiki da zarar ya sami `false`, saboda ba komai abin da ya faru, sakamakon kuma zai zama `false`.
    ///
    ///
    /// An komai iterator kõma `true`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Tsayawa a farko `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // za mu iya har yanzu amfani da `iter`, kamar yadda akwai more abubuwa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Gwaje-gwaje idan wani kashi na iterator matches a predicate.
    ///
    /// `any()` daukan wani ƙulli cewa kõma `true` ko `false`.Yana shafi wannan ƙulli a kowane kashi na iterator, kuma idan wani daga gare su dawo `true`, sa'an nan don haka ya aikata `any()`.
    /// Idan duk suka dawo da `false`, ya dawo `false`.
    ///
    /// `any()` gajere ne;a cikin wasu kalmomi, shi zai daina sarrafa da zaran ya sami wani `true`, ba cewa ko da abin da abu ya faru, sakamakon zai zama `true`.
    ///
    ///
    /// Wani mai magana bashi da komai ya dawo `false`.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Tsayawa a farkon `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // za mu iya har yanzu amfani da `iter`, kamar yadda akwai more abubuwa.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Searches ga wani kashi na wani iterator cewa kosad da wani predicate.
    ///
    /// `find()` yana ɗaukar ƙulli wanda ya dawo da `true` ko `false`.
    /// Yana amfani da wannan ƙulli ga kowane ɓangaren maimaitawa, kuma idan ɗayansu ya dawo `true`, to, `find()` ya dawo [`Some(element)`].
    /// Idan duk suka dawo da `false`, ya dawo [`None`].
    ///
    /// `find()` ne short-circuiting.a cikin wasu kalmomi, shi zai daina sarrafa da zaran ƙulli kõma `true`.
    ///
    /// Saboda `find()` daukan wani tunani, kuma da yawa iterators iterate kan nassoshi, wannan take kaiwa zuwa wani yiwu rudani halin da ake ciki inda da shaida ne a biyu reference.
    ///
    /// Kuna iya ganin wannan tasirin a cikin misalan ƙasa, tare da `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Tsayawa a farkon `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // za mu iya har yanzu amfani da `iter`, kamar yadda akwai more abubuwa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Lura cewa `iter.find(f)` ne daidai da `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Shafi aiki da abubuwa na iterator da kuma dawo da farko ba m sakamakon.
    ///
    ///
    /// `iter.find_map(f)` shi ne daidai da `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Shafi aiki da abubuwa na iterator da kuma dawo da farko gaskiya sakamakon ko na farko kuskure.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Searches ga wani kashi a cikin wani iterator, ya dawo ta index.
    ///
    /// `position()` yana ɗaukar ƙulli wanda ya dawo da `true` ko `false`.
    /// Yana amfani da wannan ƙulli ga kowane ɓangaren maimaitawa, kuma idan ɗayansu ya dawo `true`, to `position()` ya dawo [`Some(index)`].
    /// Idan duk su koma `false`, ta kõma [`None`].
    ///
    /// `position()` gajere ne;a cikin wasu kalmomi, shi zai daina sarrafa da zaran ya sami wani `true`.
    ///
    /// # Hali Ya Zube
    ///
    /// Hanyar ba ta kariya game da ambaliyar ruwa, don haka idan akwai abubuwa fiye da [`usize::MAX`] waɗanda ba su dace da abubuwa, to ko dai ya samar da sakamako mara kyau ko panics.
    ///
    /// Idan an kunna bayanan tabbatarwa, panic yana da tabbaci.
    ///
    /// # Panics
    ///
    /// Wannan aikin zai iya panic idan mai karantawa yana da abubuwa sama da `usize::MAX` waɗanda basu dace da abubuwa ba.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Tsayawa a farkon `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // za mu iya har yanzu amfani da `iter`, kamar yadda akwai more abubuwa.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Abubuwan da aka dawo da su ya dogara da yanayin maimaitawa
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Bincike don wani abu a cikin mai gabatarwa daga dama, yana dawo da bayanansa.
    ///
    /// `rposition()` yana ɗaukar ƙulli wanda ya dawo da `true` ko `false`.
    /// Yana shafi wannan ƙulli a kowane kashi na iterator, fara daga na ƙarshe, kuma idan daya daga cikinsu ya koma `true`, sa'an nan `rposition()` kõma [`Some(index)`].
    ///
    /// Idan duk su koma `false`, ta kõma [`None`].
    ///
    /// `rposition()` gajere ne;a cikin wasu kalmomi, shi zai daina sarrafa da zaran ya sami wani `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Tsayawa a farkon `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // za mu iya har yanzu amfani da `iter`, kamar yadda akwai more abubuwa.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Babu buƙatar bincika ƙari a nan, saboda `ExactSizeIterator` yana nuna cewa yawan abubuwan sun dace cikin `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Koma matsakaicin kashi na wani iterator.
    ///
    /// Idan abubuwa da yawa sunyi daidai daidai, an dawo da kashi na ƙarshe.
    /// Idan iterator ne komai, [`None`] aka mayar da su.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Koma da ƙaramar kashi na wani iterator.
    ///
    /// Idan dama abubuwa ne daidai da m, na farko kashi ne mayar da ku.
    /// Idan iterator ne komai, [`None`] aka mayar da su.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Ya dawo da abun da ke ba da matsakaicin darajar daga aikin da aka ƙayyade.
    ///
    ///
    /// Idan abubuwa da yawa sunyi daidai daidai, an dawo da kashi na ƙarshe.
    /// Idan iterator ne komai, [`None`] aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Ya dawo da abun da ke ba da matsakaicin darajar game da aikin kwatancen da aka ayyana.
    ///
    ///
    /// Idan abubuwa da yawa sunyi daidai daidai, an dawo da kashi na ƙarshe.
    /// Idan iterator ne komai, [`None`] aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ya dawo da abun da ke ba da ƙarami ƙimar daga aikin da aka ƙayyade.
    ///
    ///
    /// Idan dama abubuwa ne daidai da m, na farko kashi ne mayar da ku.
    /// Idan iterator ne komai, [`None`] aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Dawo da kashi cewa ya ba da mafi ƙarancin darajar tare da girmamawa ga ajali kwatanta aiki.
    ///
    ///
    /// Idan dama abubuwa ne daidai da m, na farko kashi ne mayar da ku.
    /// Idan iterator ne komai, [`None`] aka mayar da su.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Reverses wani iterator ta shugabanci.
    ///
    /// Yawancin lokaci, iterators iterate daga hagu zuwa dama.
    /// Bayan amfani da `rev()`, wani mai maimaitawa zai sanya shi daga dama zuwa hagu.
    ///
    /// Wannan yana yiwuwa ne kawai idan iterator yana da karshe, haka `rev()` aiki ne kawai a kan [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Sabobinda mai maimaita nau'i-nau'i ya zama na kwantena guda biyu.
    ///
    /// `unzip()` jan wani dukan iterator nau'i-nau'i, samar da biyu collections: daya daga hagu abubuwa na nau'i-nau'i, kuma daya daga dama abubuwa.
    ///
    ///
    /// Wannan aikin shine, a wata ma'ana, kishiyar [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Halitta wani iterator wanda kofe duk da abubuwa.
    ///
    /// Wannan yana da amfani lokacin da kake da maimaici akan `&T`, amma kana buƙatar mai lafazin akan `T`.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kofe daidai yake da .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Halitta wani iterator wanda [`clone`] s duk da abubuwa.
    ///
    /// Wannan yana da amfani lokacin da kake da maimaici akan `&T`, amma kana buƙatar mai lafazin akan `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned daidai yake da .map(|&x| x), don lambobi
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Mayar da wani iterator karshe.
    ///
    /// Maimakon tsayawa a [`None`], da iterator za maimakon fara sake, daga farkon.Bayan iterating sake, shi zai fara a farkon sake.Da kuma.
    /// Da kuma.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sididdigar abubuwan mai magana.
    ///
    /// Eachauki kowane ɗayan, ƙara su tare, kuma ya dawo da sakamakon.
    ///
    /// An komai iterator dawo da sifili darajar da irin.
    ///
    /// # Panics
    ///
    /// Lokacin da kiran `sum()` da wani m lamba type ake mayar, wannan hanya za ta panic idan ƙidãyar yawo da kuma cire kuskure assertions ake sa.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates bisa dukan iterator, ya riɓaɓɓanya duk abubuwa
    ///
    /// An komai iterator dawo da daya darajar da irin.
    ///
    /// # Panics
    ///
    /// Lokacin da kiran `product()` da wani m lamba type ake mayar, Hanyar zai panic idan ƙidãyar yawo da kuma cire kuskure assertions ake sa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) kwatankwacin abubuwan wannan [`Iterator`] da na wani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) kwantanta da abubuwa na wannan [`Iterator`] tare da wadanda na wani tare da girmamawa ga ajali kwatanta aiki.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) kwatankwacin abubuwan wannan [`Iterator`] da na wani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) kwantanta da abubuwa na wannan [`Iterator`] tare da wadanda na wani tare da girmamawa ga ajali kwatanta aiki.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Dayyade idan abubuwan wannan [`Iterator`] sun daidaita da na wani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Dayyade idan abubuwan wannan [`Iterator`] sun daidaita da na wani dangane da aikin daidaitaccen aikin.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Dayyade idan abubuwan wannan [`Iterator`] basu daidaita da na wani ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Kayyade idan abubuwa na wannan [`Iterator`] ne [lexicographically](Ord#lexicographical-comparison) kasa fiye da wadanda na wani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Yana ƙayyade idan abubuwan wannan [`Iterator`] sun kasance [lexicographically](Ord#lexicographical-comparison) ƙasa da ɗaya ko kuma daidai da na wani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Kayyade idan abubuwa na wannan [`Iterator`] ne [lexicographically](Ord#lexicographical-comparison) mafi girma fiye da wadanda na wani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Kayyade idan abubuwa na wannan [`Iterator`] ne [lexicographically](Ord#lexicographical-comparison) fi ko daidai to wadanda na wani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Cak idan abubuwa na wannan iterator ana ana jerawa.
    ///
    /// Wannan shi ne, domin kowane kashi `a` da wadannan kashi `b`, `a <= b` dole rike.Idan iterator yã'yan daidai sifili ko daya da rabi, `true` aka mayar da su.
    ///
    /// Lura cewa idan `Self::Item` `PartialOrd` ne kawai, amma ba `Ord` ba, ma'anar da ke sama tana nuna cewa wannan aikin ya dawo da `false` idan duk abubuwa biyu masu jere basa misaltawa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Cak idan abubuwa na wannan iterator ana ana jerawa amfani da ba comparator aiki.
    ///
    /// Maimakon amfani da `PartialOrd::partial_cmp`, wannan aikin yana amfani da aikin `compare` da aka bayar don ƙayyade odar abubuwa biyu.
    /// Baya ga cewa, yana da daidai da [`is_sorted`].duba bayanansa don ƙarin bayani.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Cak idan abubuwa na wannan iterator ana ana jerawa amfani da ba key hakar aiki.
    ///
    /// Maimakon na gwada iterator ta abubuwa kai tsaye, wannan aiki kwantanta da mabuɗan abubuwa, kamar yadda ƙaddara da `f`.
    /// Baya ga cewa, yana da daidai da [`is_sorted`].duba bayanansa don ƙarin bayani.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Duba [TrustedRandomAccess]
    // Sunan da baƙon abu shine don kaucewa haɗuwar suna a cikin ƙudurin hanya duba #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}