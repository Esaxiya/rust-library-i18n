/// An iterator cewa ya san ainihin tsawon.
///
/// Da yawa [`` Mai maganar '' ba su san sau nawa za su yi magana ba, amma wasu sun sani.
/// Idan wani iterator san yadda sau da yawa shi zai iya iterate, samar da dama ga cewa bayanai iya zama da amfani.
/// Misali, idan kanaso ka juya baya, kyakkyawar farawa shine sanin inda karshen yake.
///
/// Lokacin aiwatar da wani `ExactSizeIterator`, dole ne ka kuma yi [`Iterator`].
/// Lokacin yin haka, aiwatar da [`Iterator::size_hint`]*dole ne* dawo da madaidaicin girman maimaitawa.
///
/// Hanyar [`len`] tana da aiwatarwa ta asali, saboda haka yawanci bai kamata ku aiwatar da ita ba.
/// Duk da haka, ka iya samar da wani karin performant aiwatar da ba tsoho ba, don haka overriding shi a wannan yanayin sa hankali.
///
///
/// Lura cewa wannan trait trait ce mai aminci kuma saboda hakan *baya* kuma * bazai iya ba da tabbacin cewa tsawon da aka dawo daidai bane.
/// Wannan yana nufin cewa lambar `unsafe`**kada ta kasance** ta dogara da daidaituwar [`Iterator::size_hint`].
/// A m da kuma unsafe [`TrustedLen`](super::marker::TrustedLen) trait ya ba da wannan ƙarin garanti.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// // mai iyaka range san daidai da yadda sau da dama za iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// A cikin [module-level docs], mun aiwatar da [`Iterator`], `Counter`.
/// Bari mu aiwatar da `ExactSizeIterator` a gare shi kuma:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Mun iya lissafi da sauran yawan iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Kuma yanzu zamu iya amfani dashi!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Koma ainihin tsawon na iterator.
    ///
    /// Aiwatarwar ya tabbatar da cewa mai maimaitawar zai dawo daidai da `len()` fiye da darajar [`Some(T)`], kafin dawowa [`None`].
    ///
    /// Wannan hanya tana da tsoffin aiwatarwa, saboda haka yawanci kada ku aiwatar da ita kai tsaye.
    /// Koyaya, idan kuna iya samar da ingantaccen aiwatarwa, kuna iya yin hakan.
    /// Duba takardun [trait-level] don misali.
    ///
    /// Wannan aikin yana da tabbaci iri ɗaya kamar aikin [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // mai iyaka range san daidai da yadda sau da dama za iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Wannan ikirarin na kare kansa ne, amma yana duba marasa tabbas
        // garanti ta hanyar trait.
        // Idan wannan trait sun rust-ciki, za mu iya amfani da debug_assert !;assert_eq!Za a duba duk Rust mai amfani implementations ma.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Koma `true` idan iterator ne komai.
    ///
    /// Wannan hanyar tana da tsoffin aiwatarwa ta amfani da [`ExactSizeIterator::len()`], don haka baku buƙatar aiwatar da shi da kanku.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}