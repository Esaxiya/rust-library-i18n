use crate::ops::{ControlFlow, Try};

/// An iterator iya amfanin ƙasa abubuwa daga duka iyakar.
///
/// Wani abu da aiwatarwa `DoubleEndedIterator` yana daya karin damar kan wani abu da aiwatarwa [`Iterator`]: da ikon ma dauki `Item`s daga baya, kazalika da gaban.
///
///
/// Yana da muhimmanci a lura da cewa biyu baya da kuma fitar aiki a kan wannan fanni, da kuma aikata ba giciye: iteration ne a kan lokacin da suka hadu a tsakiyar.
///
/// A irin wannan fashion zuwa [`Iterator`] yarjejeniya, da zarar wani `DoubleEndedIterator` kõma [`None`] daga [`next_back()`], ya kira ta sake iya ko ba taba komawa [`Some`] sake.
/// [`next()`] kuma [`next_back()`] suna musanyawa don wannan dalili.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Cire da dawo da wani abu daga ƙarshen maimaitawa.
    ///
    /// Yana dawowa `None` lokacin da babu sauran abubuwa.
    ///
    /// Takardun [trait-level] sun ƙunshi ƙarin bayanai.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// The abubuwa bada da `DoubleEndedIterator` ta hanyoyin iya bambanta daga wadanda bada ta [`Iterator`] 's hanyoyin:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Ci gaban mai yin bayani daga baya ta abubuwan `n`.
    ///
    /// `advance_back_by` ne baya version of [`advance_by`].Wannan hanyar za ta tsallake abubuwan `n` da ke farawa daga baya ta hanyar kiran [`next_back`] har zuwa sau `n` har sai an sami [`None`].
    ///
    /// `advance_back_by(n)` zai dawo da [`Ok(())`] idan mai yin nasarar yayi nasarar cigaba ta abubuwan `n`, ko [`Err(k)`] idan aka sadu da [`None`], inda `k` shine adadin abubuwan da mai aikin ya ci gaba ta hanyar gabanin abubuwan da suke gudana (watau
    /// da tsawon iterator).
    /// Lura cewa `k` ne ko da yaushe kasa da `n`.
    ///
    /// Kira `advance_back_by(0)` ba cinye wani abubuwa da kuma ko da yaushe ya kõmo [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // kawai `&3` aka tsalle
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Ya dawo da ``n`th element daga ƙarshen mai karantawa.
    ///
    /// Wannan shi ne da gaske da juyawa version of [`Iterator::nth()`].
    /// Kodayake kamar yawancin ayyukan nunawa, lissafin yana farawa daga sifili, don haka `nth_back(0)` ya dawo da farkon darajar daga ƙarshe, `nth_back(1)` na biyu, da sauransu.
    ///
    ///
    /// Lura cewa duk abubuwa tsakanin karshen da koma rabi za a cinye, ciki har da mayar da rabi.
    /// Wannan kuma yana nufin cewa kiran `nth_back(0)` mahara sau a kan wannan iterator zai koma daban-daban abubuwa.
    ///
    /// `nth_back()` zai dawo [`None`] idan `n` ne fi ko daidai to da tsawon iterator.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Kira `nth_back()` mahara sau ba baya da iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Dawo `None` idan akwai kasa da `n + 1` abubuwa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Wannan shi ne fasalin baya na [`Iterator::try_fold()`]: yana ɗaukar abubuwa farawa daga bayan maɓallin.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Saboda shi gajere ne, sauran abubuwan har yanzu ana samunsu ta hanyar mai sarrafa su.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator Hanyar da ta rage iterator ta abubuwa zuwa guda, karshe darajar, fara daga baya.
    ///
    /// Wannan ne kuma baya da version of [`Iterator::fold()`]: yana daukan abubuwa fara daga baya na iterator.
    ///
    /// `rfold()` daukan biyu muhawara: an sa hannu darajar, da kuma fitattu da ba da biyu muhawara: wani 'accumulator', da kuma wani kashi.
    /// The ƙulli dawo da darajar da cewa accumulator ya kamata da na gaba iteration.
    ///
    /// Theimar farko ita ce darajar da mai tarawa zai samu akan kiran farko.
    ///
    /// Bayan amfani da wannan ƙulli ga kowane ɓangaren maimaitawa, `rfold()` ya dawo da mai tarawa.
    ///
    /// Wannan aiki ne, wani lokacin kira 'reduce' ko 'inject'.
    ///
    /// Nadawa ne amfani duk lokacin da ka yi wani tarin wani abu, da kuma son nuna guda darajar daga gare shi.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // Naira Miliyan Xari da dukkan abubuwa na
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Wannan misalin yana gina kirtani, farawa da ƙimar farawa kuma yana ci gaba da kowane ɗayan abubuwa daga baya har zuwa gaba:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Searches ga wani kashi na wani iterator daga baya cewa kosad da wani predicate.
    ///
    /// `rfind()` yana ɗaukar ƙulli wanda ya dawo da `true` ko `false`.
    /// Yana shafi wannan ƙulli a kowane kashi na iterator, da suka fara a karshen, kuma idan wani daga gare su dawo `true`, sa'an nan `rfind()` kõma [`Some(element)`].
    /// Idan duk suka dawo da `false`, ya dawo [`None`].
    ///
    /// `rfind()` ne short-circuiting.a cikin wasu kalmomi, shi zai daina sarrafa da zaran ƙulli kõma `true`.
    ///
    /// Saboda `rfind()` yana ɗaukar bayani, kuma yawancin masu yin magana suna jinkirtawa a kan nassoshi, wannan yana haifar da yiwuwar rikicewa inda takaddar ta zama magana biyu.
    ///
    /// Kuna iya ganin wannan tasirin a cikin misalan ƙasa, tare da `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Tsayawa a farkon `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // za mu iya har yanzu amfani da `iter`, kamar yadda akwai more abubuwa.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}