/// Mai maimaita magana wanda koyaushe yana ci gaba da samar da `None` idan ya gaji.
///
/// Kira na gaba a kan mai magana wanda aka sake dawo da `None` sau ɗaya tabbas zai dawo da [`None`] kuma.
/// Wannan trait yakamata ya aiwatar da duk masu amfani da shi waɗanda ke nuna halayyar wannan saboda yana ba da damar inganta [`Iterator::fuse()`].
///
///
/// Note: Gabaɗaya, yakamata kuyi amfani da `FusedIterator` a cikin iyakokin yanki idan kuna buƙatar mai magana mai haɗi.
/// Madadin haka, ya kamata kawai ku kira [`Iterator::fuse()`] akan mai magana.
/// Idan mai amfani ya riga an hade shi, ƙarin [`Fuse`] mai nadewa zai zama ba-op ba tare da azabtarwa ba.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Mai magana wanda yayi rahoton cikakken tsayi ta amfani da size_hint.
///
/// A iterator rahoton wani size ambato inda shi ne ko dai daidai (ƙananan daure shi ne daidai babba daure), ko babba a ɗaure shi ne [`None`].
///
/// Dole ne babba ya kasance [`None`] ne kawai idan ainihin tsinkayen tsayi ya fi [`usize::MAX`] girma.
/// A wannan yanayin, ƙananan igiya dole ne ya zama [`usize::MAX`], wanda ya haifar da [`Iterator::size_hint()`] na `(usize::MAX, None)`.
///
/// A iterator dole nuna daidai da adadin abubuwa da shi ya ruwaito ko diverge kafin kai karshen.
///
/// # Safety
///
/// Wannan trait dole ne kawai da za a aiwatar a lokacin da kwangila da aka tsayar.
/// Masu amfani da wannan trait dole ne su binciki babban haɗin [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// An iterator cewa a lokacin da samar da gwaggwabar riba da wani abu zai sun riƙi akalla daya kashi daga ta muhimmi [`SourceIter`].
///
/// Kira duk wata hanyar da zata ciyarda mai bada labari, misali
/// [`next()`] ko [`try_fold()`], tabbacin cewa ga kowane mataki a kalla daya tamanin da iterator ta tamkar tushen an koma daga da kuma sakamakon da iterator sarkar za a iya saka a wurinsa, dauka tsarin saka na tushen damar irin wannan sa.
///
/// A wasu kalmomin wannan trait nuna cewa an iterator bututun za a iya tattara a wuri.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}