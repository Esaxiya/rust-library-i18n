use crate::{iter::FusedIterator, ops::Try};

/// Mai maimaitawa wanda yake maimaitawa har abada.
///
/// Wannan `struct` an ƙirƙire ta hanyar hanyar [`cycle`] akan [`Iterator`].
/// Duba bayanansa don ƙarin.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // mai sake zagayowar ko dai fanko ne ko iyaka
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // cikakken iterate yanzu iterator.
        // wannan shi ne zama dole saboda `self.iter` iya komai ko da `self.orig` ba
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // Kammala cikakken zagaye, lura da yadda mai aikin keken ya kasance fanko ko babu.
        // muna buƙatar dawowa da wuri idan akwai wani mai magana a ciki don hana madauki mara iyaka
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Babu `fold` override, saboda `fold` ba shi da ma'ana ga `Cycle`, kuma ba za mu iya yin wani abu da ya fi tsoho ba.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}