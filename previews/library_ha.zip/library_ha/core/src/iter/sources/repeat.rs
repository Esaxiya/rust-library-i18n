use crate::iter::{FusedIterator, TrustedLen};

/// Irƙiri sabon mai magana wanda zai sake maimaita abu guda.
///
/// A `repeat()` aiki mayar da guda darajar kan kuma a sake.
///
/// Iyaka iterators kamar `repeat()` sukan yi amfani da adaftan kamar [`Iterator::take()`], domin sanya su guntun.
///
/// Idan nau'ikan nau'ikan abin da kuke buƙata bai aiwatar da `Clone` ba, ko kuma idan ba kwa son adana maimaita abu a cikin ƙwaƙwalwa, a maimakon haka za ku iya amfani da aikin [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::iter;
///
/// // lambar huɗu 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, har yanzu hudu
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Za guntun da [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // misali na karshe sun yi yawa da yawa.Bari muyi hudu kawai.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... kuma yanzu mun gama
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Mai maimaitawa wanda yake maimaita wani abu har abada.
///
/// Wannan `struct` aka halitta da [`repeat()`] aiki.Duba bayanansa don ƙarin.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}