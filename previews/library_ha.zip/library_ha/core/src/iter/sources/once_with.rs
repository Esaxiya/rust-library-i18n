use crate::iter::{FusedIterator, TrustedLen};

/// Creatirƙira mai maimaitawa wanda cikin kasala yana haifar da ƙima daidai sau ɗaya ta hanyar kiran ƙulli da aka bayar.
///
/// Ana amfani da wannan don daidaita janareta mai daraja ɗaya zuwa cikin [`chain()`] na wasu nau'ikan sakewa.
/// Watakila kana da wani iterator cewa inuwõyi kusan kome da kome, amma kana bukatar wani karin musamman hali.
/// Watakila kana da wani aiki wanda aiki a kan iterators, amma ku kawai bukatar aiwatar daya darajar.
///
/// Ba kamar [`once()`], wannan aiki zai kasala samar da darajar a kan request.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::iter;
///
/// // daya ne loneliest yawan
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // daya kawai, abin da muke samu kenan
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining tare da wani iterator.
/// Bari mu ce muna so mu sanya kowane fayil na kundin adireshin `.foo`, amma har da fayil ɗin daidaitawa,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // muna buƙatar canzawa daga mai maimaita DirEntry-s zuwa maɓallin PathBufs, don haka muna amfani da taswira
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // yanzu, mu iterator kawai don mu jeri fayil
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // Sarkar biyu iterators tare cikin daya babban iterator
/// let files = dirs.chain(config);
///
/// // wannan zai bamu dukkan fayiloli a cikin .foo da .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// An iterator cewa yã'yan guda kashi na irin `A` da ake ji da bayar ƙulli `F: FnOnce() -> A`.
///
///
/// Wannan `struct` aka halitta da [`once_with()`] aiki.
/// Duba bayanansa don ƙarin.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}