use crate::fmt;

/// Halicci sabon iterator inda kowane iteration kira bayar ƙulli `F: FnMut() -> Option<T>`.
///
/// Wannan damar samar da wani al'ada iterator tare da wani hali ba tare da amfani da mafi verbose ginin kalma na samar da wani kwazo irin da kuma aiwatar da [`Iterator`] trait ga shi.
///
/// Note cewa `FromFn` iterator ba sa zaton game da hali na ƙulli, sabili da haka conservatively ba yi [`FusedIterator`], ko override [`Iterator::size_hint()`] daga ta default `(0, None)`.
///
///
/// Theulli na iya amfani da kame-kame da muhalli don bin diddigin jihar a duk faɗin abubuwan da aka saba.Dangane da yadda ake amfani da iterator, wannan na iya bukatar tantancewa da [`move`] keyword a kan ƙulli.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Let ta sake aiwatar da counter iterator daga [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Mentara yawanmu.Wannan shine dalilin da yasa muka fara sifili.
///     count += 1;
///
///     // Duba ka gani ko mun gama kirgawa ko a'a.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// An iterator inda kowane iteration kira bayar ƙulli `F: FnMut() -> Option<T>`.
///
/// Wannan `struct` an ƙirƙira shi ta hanyar aikin [`iter::from_fn()`].
/// Duba bayanansa don ƙarin.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}