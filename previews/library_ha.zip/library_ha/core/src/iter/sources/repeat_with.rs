use crate::iter::{FusedIterator, TrustedLen};

/// Halicci sabon iterator cewa ya mayar da abubuwa na irin `A` karshe da ake ji da bayar ƙulli, da repeater, `F: FnMut() -> A`.
///
/// A `repeat_with()` aiki kira repeater kan kuma a sake.
///
/// Iyaka iterators kamar `repeat_with()` sukan yi amfani da adaftan kamar [`Iterator::take()`], domin sanya su guntun.
///
/// Idan kashi irin na iterator kana bukatar aiwatarwa [`Clone`], kuma shi ne OK don kiyaye tushen kashi a ƙwaƙwalwar, ya kamata ka maimakon amfani da [`repeat()`] aiki.
///
///
/// An iterator samar da `repeat_with()` ba [`DoubleEndedIterator`].
/// Idan kana bukatar `repeat_with()` komawa wani [`DoubleEndedIterator`], don Allah bude wani GitHub batun bayanin your amfani hali.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::iter;
///
/// // bari mu zaton muna da wasu darajar da irin wannan ba `Clone` ko wanda ba ka so su yi a cikin memory kawai duk da haka, domin shi ne tsada:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // wani musamman darajar har abada:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Amfani da maye gurbi da za guntun:
///
/// ```rust
/// use std::iter;
///
/// // Daga sifiri zuwa na uku ikon biyu:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... kuma yanzu mun gama
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// An iterator cewa ya mayar da abubuwa na irin `A` karshe da ake ji da bayar ƙulli `F: FnMut() -> A`.
///
///
/// Wannan `struct` an ƙirƙira shi ta hanyar aikin [`repeat_with()`].
/// Duba bayanansa don ƙarin.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}