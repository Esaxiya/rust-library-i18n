//! Posarfafawa na waje.
//!
//! Idan kun sami kanku tare da tarin wasu nau'ikan, kuma kuna buƙatar yin aiki akan abubuwan da aka faɗi tarin, da sauri zaku shiga cikin 'iterators'.
//! Iterators suna dauke da amfani a idiomatic Rust code, don haka yana da daraja da zama saba da su.
//!
//! Kafin bayanin more, bari magana game da yadda wannan module ne tsari:
//!
//! # Organization
//!
//! Wannan tsarin an tsara shi ta hanyar nau'i:
//!
//! * [Traits] ne da zuciyar rabo: wadannan traits ayyana irin iterators wanzu da kuma abin da za ka iya yi tare da su.Hanyoyin waɗannan traits sun cancanci saka ƙarin lokacin karatu a ciki.
//! * [Functions] samar da wasu hanyoyi masu taimako don ƙirƙirar wasu masanan masu amfani.
//! * [Structs] ne sau da yawa samu iri da hanyoyi daban-daban a kan wannan a koyaushe ta traits.Za ku ji yawanci so a dubi Hanyar cewa halitta da `struct`, maimakon `struct` kanta.
//! Don samun cikakken bayani game da dalilin, duba '[Aiwatar da Mai Magana](#aiwatarwa-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Shi ke nan!Bari mu tono masu yin amfani da shi.
//!
//! # Iterator
//!
//! The zuciya da ruhi na wannan module ne [`Iterator`] trait.Jigon [`Iterator`] yayi kama da wannan:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Mai magana yana da hanya, [`next`], wanda idan aka kira shi, ya dawo da wani ``zaɓi '' '<Item>``.
//! [`next`] zai dawo [`Some(Item)`] muddin akwai abubuwa, kuma da zarar sun yi duk an gaji, zai koma `None` da ya nuna cewa iteration an gama.
//! Mutane daya-daya iterators iya zabi a ci gaba iteration, kuma haka kiran [`next`] sake iya ko ba ƙarshe fara dawo [`Some(Item)`] sake a wani matsayi (misali, ga [`TryIter`]).
//!
//!
//! Cikakkiyar ma'anar ta "` `Iterator '' 'ta hada da wasu sauran hanyoyin kuma, amma su hanyoyi ne na asali, wadanda aka gina su a saman [`next`], don haka sai a same su kyauta.
//!
//! Iterators ne ma composable, kuma shi ta kowa da sarkar su tare yin karin hadaddun siffofin aiki.Dubi [Adapters](#adapters) sashe a kasa don ƙarin bayani.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Hanyoyi guda uku
//!
//! Akwai uku na kowa hanyoyin wanda zai iya haifar da iterators daga tarin:
//!
//! * `iter()`, wanda iterates kan `&T`.
//! * `iter_mut()`, wanda ke maimaitawa a kan `&mut T`.
//! * `into_iter()`, wanda iterates kan `T`.
//!
//! Abubuwa daban-daban a cikin ɗakunan karatu na yau da kullun na iya aiwatar da ɗaya ko fiye daga cikin ukun, inda ya dace.
//!
//! # Aiwatar Iterator
//!
//! Samar da wani iterator na naka ya shafi matakai biyu: da samar da wani `struct` rike da iterator ta jihar, sa'an nan aiwatar [`Iterator`] ga cewa `struct`.
//! Wannan shi ne dalilin da ya sa da akwai da yawa `struct`s a cikin wannan module: akwai daya ga kowane iterator da iterator adaftan.
//!
//! Bari mu yi wani iterator mai suna `Counter` wanda kirga daga `1` zuwa `5`:
//!
//! ```
//! // Na farko, tsarin:
//!
//! /// Maimaitawa wanda ya kirga daga daya zuwa biyar
//! struct Counter {
//!     count: usize,
//! }
//!
//! // muna so mu count zuwa fara a daya, saboda haka bari mu ƙara new() Hanyar to taimako.
//! // Wannan ba ya zama tilas, amma shi ne ya dace.
//! // Lura cewa mun fara `count` a sifili, zamu ga dalilin da yasa a aiwatar da `next()`'s a ƙasa.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sa'an nan, za mu yi `Iterator` domin mu `Counter`:
//!
//! impl Iterator for Counter {
//!     // zamu kasance muna ƙidaya tare da amfani
//!     type Item = usize;
//!
//!     // next() ne kawai ake bukata Hanyar
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Mentara yawanmu.Wannan shine dalilin da yasa muka fara sifili.
//!         self.count += 1;
//!
//!         // Duba ka gani ko mun gama kirgawa ko a'a.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Kuma yanzu zamu iya amfani dashi!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Kira [`next`] ta wannan hanyar yana samun maimaitawa.Rust yana da wani gina wanda za a iya kira [`next`] a kan iterator, har ya kai gare shi `None`.Bari mu wuce wannan gaba.
//!
//! Hakanan ku lura cewa `Iterator` yana samar da tsoffin aiwatar da hanyoyi kamar `nth` da `fold` waɗanda ke kiran `next` a ciki.
//! Duk da haka, shi ne kuma zai yiwu a rubuta wani al'ada aiwatar da hanyoyin kamar `nth` da `fold` idan an iterator iya lissafta su da nagarta sosai ba tare da kiran `next`.
//!
//! # `for` madaukai da `IntoIterator`
//!
//! Rust ta `for` madauki ginin kalma shi ne ainihin sugar for iterators.Ga misali na asali na `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Wannan zai buga lambobin daya ta hanyar biyar, kowane a kan nasu line.Amma za ku lura da wani abu a nan: ba mu kira wani abu a kan mu vector, don samar da wani iterator.Abin da ya bada?
//!
//! Akwai wani trait a misali library ga tana mayar da wani abu a cikin wani iterator: [`IntoIterator`].
//! Wannan trait yana da hanya ɗaya, [`into_iter`], wanda ke canza abin da ake aiwatar da [`IntoIterator`] zuwa mai magana.
//! Bari mu dauki wani look at cewa `for` madauki sake, da kuma abin da mai tarawa sabobin tuba da shi zuwa cikin:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars wannan cikin:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Da farko, za mu kira `into_iter()` a kan darajar.Bayan haka, zamu dace a kan maimaitawar da ya dawo, yana kiran [`next`] sama da ƙari har sai mun ga `None`.
//! A wannan batu, mun `break` daga cikin madauki, kuma muna aikata iterating.
//!
//! Akwai daya more dabara bit a nan: da misali library ƙunshi wani ban sha'awa aiwatar da [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! A wasu kalmomin, duk ['Iterator'] suna aiwatar da [`IntoIterator`], ta hanyar dawowa da kansu kawai.Wannan yana nufin abubuwa biyu:
//!
//! 1. Idan kuna rubuta [`Iterator`], zaku iya amfani dashi tare da madauki `for`.
//! 2. Idan kana da samar da wani tarin, aiwatar da [`IntoIterator`] domin shi zai ba da damar ka tarin da za a yi amfani da tare da `for` madauki.
//!
//! # Yin magana ta hanyar tunani
//!
//! Tunda [`into_iter()`] ya ɗauki `self` da ƙima, ta amfani da madauki na `for` don ɗaukar hoto akan tarin yana cin wannan tarin.Sau da yawa, kana iya iterate kan tarin ba tare da cin shi.
//! Yawancin tarin suna ba da hanyoyi waɗanda ke ba da ma'amala a kan nassoshi, waɗanda ake kira `iter()` da `iter_mut()` bi da bi:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` An har yanzu mallakar wannan aiki.
//! ```
//!
//! Idan tarin irin `C` samar `iter()`, shi yawanci ma aiwatar da `IntoIterator` for `&C`, tare da an aiwatar da cewa kawai ya kira `iter()`.
//! Hakanan, tarin `C` wanda ke ba da `iter_mut()` gabaɗaya yana aiwatar da `IntoIterator` don `&mut C` ta hanyar tura wakilai zuwa `iter_mut()`.Wannan yana ba da damar taƙaitacciyar hanya:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // wannan kamar yadda `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // wannan kamar yadda `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Duk da yake tarin yawa suna ba da `iter()`, ba duka ke ba `iter_mut()` ba.
//! Misali, sauya makullin [`HashSet<T>`] ko [`HashMap<K, V>`] na iya sanya tarin a cikin rashin daidaituwa idan maɓallan maɓallin sun canza, saboda haka waɗannan tarin suna ba da `iter()` kawai.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Ayyuka waɗanda suke ɗaukar [`Iterator`] kuma suka dawo da wani [`Iterator`] ana kiran su 'adapters adarator', tunda suna sigar adafta
//! pattern'.
//!
//! Masu daidaita adawar yau da kullun sun haɗa da [`map`], [`take`], da [`filter`].
//! Don ƙarin, duba takaddun su.
//!
//! Idan adaftan adaftan panics, mai amsawar zai kasance a cikin yanayin da ba a bayyana ba (amma mai ƙwaƙwalwar ajiya).
//! Wannan jiha ne ma ba tabbas zai zauna guda fadin versions na Rust, don haka ya kamata ka guji dogaro a kan daidai dabi'u koma ta wani iterator wanda panicked.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (da iterator [adapters](#adapters)) ne *m*. Wannan yana nufin cewa kawai samar da wani iterator ba _do_ dukan yawa. Babu wani abu da ya faru da gaske har sai da ka kira [`next`].
//! Wannan shi ne wani lokacin da wani tushe na rikice a lokacin da samar da wani iterator kawai domin ta illa.
//! Alal misali, [`map`] Hanyar kira wani ƙulli a kan kowane kashi yana iterates kan:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Wannan ba zai buga wani dabi'u, kamar yadda muka halitta da wani iterator, maimakon yin amfani da shi.A tarawa za ka yi gargaɗi da mu game da irin wannan hali:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! A idiomatic hanyar rubuta wani [`map`] domin ta gefen effects ne don amfani mai `for` madauki ko kira [`for_each`] Hanyar:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Wani kowa hanyar kimanta wani iterator ne don amfani da [`collect`] Hanyar don samar da wani sabon tarin.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators ba su da ya zama iyaka.A matsayin misali, zangon buɗewa yana da maimaita magana mara iyaka:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Yana da na kowa yin amfani da [`take`] iterator adaftan juya wani iyaka iterator cikin wani guntun daya:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Wannan zai buga lambobin `0` ta hanyar `4`, kowannensu akan layinsa.
//!
//! Ka tuna cewa hanyoyin kan iyaka iterators, har ma da wadanda for wanda a sakamakon za a iya ƙaddara shifran riyadiyah a cikin guntun lokaci, ba ƙarasa.
//! Musamman, hanyoyi kamar [`min`], wanda a cikin gaba ɗaliban buƙata kewaya kowane ɓangare a cikin mai karantawa, mai yiwuwa ba za su dawo cikin nasara ga kowane mai ba da izini mara iyaka ba.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Haba dai!An iyaka madauki!
//! // `ones.min()` yana haifar da madauki mara iyaka, don haka ba za mu kai ga wannan batun ba!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;