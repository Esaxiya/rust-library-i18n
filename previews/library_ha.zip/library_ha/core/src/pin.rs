//! Nau'ukan da ke lika bayanai zuwa wurinta a ƙwaƙwalwar.
//!
//! Yana da amfani wani lokacin a sami abubuwa waɗanda aka tabbatar ba za su motsa ba, ta yadda ma'anarsu ba ta canzawa, don haka ana iya dogaro da su.
//! Babban misali na irin wannan yanayin shine gina tunanin kai tsaye, kamar yadda motsa abu tare da nuna kansa zuwa kansa zai warware su, wanda zai iya haifar da halin da ba a bayyana ba.
//!
//! A wani babban matakin, [`Pin<P>`] yana tabbatar da cewa mai nuna alama na kowane nau'in alama na `P` yana da tabbataccen wuri a cikin ƙwaƙwalwar ajiya, ma'ana ba za a iya motsa shi a wani wuri ba kuma ba za a iya raba ƙwaƙwalwar sa har sai ya faɗi.Muna cewa mai gabatarwa shine "pinned".Abubuwa suna samun saukin ganewa yayin tattauna nau'ikan da suka haɗu tare da bayanan da ba a saka su ba;[see below](#projections-and-structural-pinning) don ƙarin bayani.
//!
//! Ta tsohuwa, kowane iri a cikin Rust masu motsi ne.
//! Rust yana ba da izinin wuce dukkan nau'ikan ta hanyar-ƙima, kuma nau'ikan-wayayyun waƙoƙi na yau da kullun kamar [`Box<T>`] da `&mut T` suna ba da damar sauyawa da motsa ƙimomin da suke ƙunshe da su: zaku iya fita daga cikin [`Box<T>`], ko kuna iya amfani da [`mem::swap`].
//! [`Pin<P>`] ya kunsa nau'in nuna alama `P`, don haka [`Pin`]``<` ['' Box`] ''<T>> ayyuka kamar na yau da kullun
//!
//! [`Box<T>`]: when a [``Pin`] '' <`['' Box`] ''<T>> `` ya fadi, haka ma abubuwan da ke ciki, kuma memori ya samu
//!
//! sharewajeHakazalika, [`Pin`]`<&mut T>`` yana da yawa kamar `&mut T`.Koyaya, [`Pin<P>`] baya barin abokan ciniki da gaske su sami [`Box<T>`] ko `&mut T` don sanya bayanai, wanda ke nuna cewa baza ku iya amfani da ayyuka kamar [`mem::swap`] ba:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` yana buƙatar `&mut T`, amma ba za mu iya samun sa ba.
//!     // Mun makale, ba za mu iya musanya abubuwan da ke cikin waɗannan bayanan ba.
//!     // Zamu iya amfani da `Pin::get_unchecked_mut`, amma wannan ba shi da haɗari saboda dalili:
//!     // ba a ba mu izinin amfani da shi don motsa abubuwa daga cikin `Pin` ba.
//! }
//! ```
//!
//! Yana da kyau a sake faɗi cewa [`Pin<P>`]*baya* canza gaskiyar cewa mai tarawa na Rust yayi la'akari da kowane nau'i mai motsi.[`mem::swap`] ya kasance mai iya yuwuwa ga kowane `T`.Madadin haka, [`Pin<P>`] yana hana wasu *ƙimomin*(waɗanda aka nusar da su ta hanyar zane-zane a cikin [`Pin<P>`]) motsawa ta hanyar hana yiwuwar kiran hanyoyin da ke buƙatar `&mut T` akan su (kamar [`mem::swap`]).
//!
//! [`Pin<P>`] ana iya amfani dashi don kunsa kowane nau'in alama na `P`, kuma don haka yana hulɗa da [`Deref`] da [`DerefMut`].A [`Pin<P>`] inda `P: Deref` yakamata a ɗauka azaman "`P`-style pointer" zuwa `P::Target` wanda aka saka-don haka, wani (``Pin`] '' <`[` `Box`] ''<T>> ``alama ce mai mallakar `T`, kuma [`` Pin`] '' <`['' Rc`] ''<T>>`` Alamar-ƙidaya ce mai ƙididdigewa zuwa `T` da aka ɗauka.
//! Don daidaito, [`Pin<P>`] ya dogara ne da aiwatarwar [`Deref`] da [`DerefMut`] ba don matsawa daga yanayin su na `self` ba, kuma kawai zai dawo mai nunawa ne zuwa bayanan da aka liƙa lokacin da aka kira su akan maɓallin da aka liƙa.
//!
//! # `Unpin`
//!
//! Yawancin nau'ikan koyaushe ana motsi da yardar kaina, koda lokacin da aka liƙa, saboda basu dogara da samun adreshin adreshin ba.Wannan ya hada da dukkan nau'ikan nau'ikan (kamar [`bool`], [`i32`], da nassoshi) gami da nau'ikan da ke dauke da wadannan nau'ikan.Nau'o'in da basu damu da pinning ba suna aiwatar da [`Unpin`] auto-trait, wanda ya soke tasirin [`Pin<P>`].
//! Na `T: Unpin`, [``Pin`] '' <`[` `Box`] ''<T>> ``kuma [`Box<T>`] suna aiki daidai, kamar yadda suke yi '' 'Pin`]' <&mut T> `` da `&mut T`.
//!
//! Lura cewa pinning da [`Unpin`] kawai suna shafar mai nuna-don rubuta `P::Target`, ba alamar nuna alama `P` kanta da ta kunsa cikin [`Pin<P>`] ba.Misali, ko babu ko [`Box<T>`] shine [`Unpin`] bashi da wani tasiri akan halayyar [`Pin`]``` `''<T>>`` (a nan, `T` shine mai nuni-don bugawa).
//!
//! # Misali: tsarin kai tsaye
//!
//! Kafin mu shiga cikin cikakkun bayanai don bayyana garanti da zaɓin da ke tattare da `Pin<T>`, zamu tattauna wasu misalai game da yadda za ayi amfani da shi.
//! Jin kyauta zuwa [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Wannan tsarin nusar da kai ne saboda yanki yanki yana nuni zuwa filin bayanan.
//! // Ba za mu iya sanar da mai tarawa game da hakan tare da isharar yau da kullun ba, saboda ba za a iya bayyana wannan samfurin tare da ƙa'idodin lamunin aro ba.
//! //
//! // Madadin haka zamuyi amfani da dan manuni mai mahimmanci, kodayake wanda aka san ba wofi bane, kamar yadda muka sani yana nuna kirtani.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Don tabbatar da cewa bayanan basa motsawa lokacin da aikin ya dawo, mun sanya shi a cikin tsibin inda zai tsaya har tsawon rayuwar abin, kuma hanyar da za a iya samunta ita ce ta hanyar nuna ta zuwa gare ta.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // zamu kirkiri mahimmin bayani ne da zarar bayanan sun kare in ba haka ba da tuni ya motsa kafin ma mu fara
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // mun san wannan ba shi da aminci saboda gyaran filin ba ya motsa duk tsarin
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Yakamata mai nuna alama ya nuna daidai wurin, muddin dai tsarin bai motsa ba.
//! //
//! // A halin yanzu, muna da 'yanci don matsawa mai nunawa a kusa.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Tunda nau'in mu baya aiwatar da Unpin, wannan zai kasa tattarawa:
//! // bari mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Misali: jerin abubuwa masu alaƙa biyu
//!
//! A cikin jerin haɗin haɗi mai sau biyu, tarin ba ainihin keɓance ƙwaƙwalwar ajiya don abubuwan da kanta ba.
//! Abokan ciniki ne ke sarrafa rarar, kuma abubuwa zasu iya rayuwa akan madaidaiciyar madaidaiciya wacce ke rayuwa ƙasa da yadda tarin yake yi.
//!
//! Don yin wannan aikin, kowane ɓangare yana da alamomi ga wanda ya gabace shi da kuma magajinsa a cikin jerin.Za'a iya ƙara abubuwa lokacin da aka liƙa su kawai, saboda matsar da abubuwan da ke kewaye da su zai lalata ma'anar.Bugu da ƙari, aiwatar da [`Drop`] na jerin abubuwan haɗin da aka haɗa za su daidaita abubuwan alamomin magabata da magajin don cire kansa daga jerin.
//!
//! Abu mai mahimmanci, dole ne mu iya dogaro da kiran [`drop`].Idan za a iya rarraba wani abu ko kuma ya zama ba zai iya aiki ba tare da kiran [`drop`] ba, masu nunin da ke ciki daga abubuwan da ke kusa da shi za su zama marasa aiki, wanda zai karya tsarin bayanan.
//!
//! Saboda haka, yin pinning shima yana zuwa tare da garantin mai dangantaka da ``drop`].
//!
//! # `Drop` guarantee
//!
//! Dalilin yin pinning shine don iya dogaro da sanya wasu bayanai a ƙwaƙwalwa.
//! Don yin wannan aikin, ba kawai ƙuntata bayanan aka ƙayyade ba;musayar wuri, sake sakewa, ko kuma rashin ingancin ƙwaƙwalwar da aka yi amfani da ita don adana bayanan an taƙaita, kuma.
//! A dunkule, don bayanan da aka zana dole ne ka kula da rashin tabbas cewa *ƙwaƙwalwar ajiyarta ba zata lalace ba ko sake maimaitawa daga lokacin da aka sanya shi har sai lokacin da aka kira [`drop`]*.Sau ɗaya kawai [`drop`] ya dawo ko panics, ana iya sake amfani da ƙwaƙwalwar.
//!
//! Waƙwalwar ajiya na iya zama "invalidated" ta hanyar rarraba wuri, amma kuma ta maye gurbin [`Some(v)`] ta [`None`], ko kiran [`Vec::set_len`] zuwa "kill" wasu abubuwan kashe na vector.Ana iya sake maimaita shi ta amfani da [`ptr::write`] don sake rubuta shi ba tare da kiran mai lalata farkon ba.Babu ɗayan wannan da aka ba izinin ƙididdigar bayanai ba tare da kiran [`drop`] ba.
//!
//! Wannan shi ne ainihin irin garantin cewa jerin haɗin intrusive daga sashin da ya gabata yana buƙatar aiki daidai.
//!
//! Lura cewa wannan garantin baya *ba* yana nufin cewa ƙwaƙwalwar ajiya baya zubowa!Har yanzu yana da kyau gabaɗaya kada a kira [`drop`] akan abin da aka ɗauke shi (misali, har yanzu zaka iya kiran [`mem::forget`] akan [``Pin`] '' <`['' Box`] ''<T>> ``) A cikin misalin jeri mai alaƙa biyu, wannan ɓangaren zai ci gaba da kasancewa cikin jeren.Koyaya baza ku iya kyauta ko sake amfani da ma'ajiyar ba tare da kira [`` drop`] *.
//!
//! # `Drop` implementation
//!
//! Idan nau'in ku yana amfani da zane (kamar misalai biyun da ke sama), dole ne ku yi hankali lokacin aiwatar da [`Drop`].Aikin [`drop`] yana ɗaukar `&mut self`, amma ana kiran wannan *koda kuwa an sa nau'in ku a baya*!Kamar dai an kira mai tarawa kai tsaye [`Pin::get_unchecked_mut`].
//!
//! Wannan ba zai taɓa haifar da matsala a cikin lambar kariya ba saboda aiwatar da nau'in da ya dogara da liƙa yana buƙatar lambar tsaro, amma ku sani yanke shawara don yin amfani da ƙwanƙwasa a cikin nau'ikanku (misali ta aiwatar da wasu ayyuka a kan [``Pin`] '' <&Kai> ``ko [`` Pin`] ''&&Kai Kai>``) yana da sakamako game da aiwatar da ku na [`Drop`] kuma: idan da wani nau'in nau'ikanku za a iya tsinke shi, dole ne ku ɗauki [`Drop`] kamar ɗaukar a fili Kai> ``.
//!
//!
//! Misali, zaku iya aiwatar da `Drop` kamar haka:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` Yana da kyau saboda mun san cewa ba a sake amfani da wannan ƙimar bayan faduwa.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Ainihin lambar digo tana zuwa nan.
//!         }
//!     }
//! }
//! ```
//!
//! Aikin `inner_drop` yana da nau'in da [`drop`]*yakamata* ya samu, don haka wannan yana tabbatar da cewa bakayi amfani da `self`/`this` ba da gangan ba ta hanyar da ta dace da zane.
//!
//! Bugu da ƙari, idan nau'in ku `#[repr(packed)]`, mai tarawa zai motsa filaye kai tsaye don ya sami damar sauke su.Yana iya ma yin hakan don filayen da zasu faru daidai.Sakamakon haka, ba za ku iya amfani da shinge tare da nau'in `#[repr(packed)]` ba.
//!
//! # Tsinkaya da Tsarin Gida
//!
//! Lokacin aiki tare da ginshiƙai masu ma'ana, tambaya ta taso ta yaya mutum zai sami damar zuwa filayen wannan tsarin a cikin hanyar da take ɗaukar kawai (``Pin`] `` <&mut Struct> ''.
//! Hanyar da aka saba amfani da ita ita ce a rubuta hanyoyin taimako (wanda ake kira *tsinkaya*) wanda ya juya [``Pin`] '' <&mut Struct> ``zuwa batun filin, amma wane nau'in ya kamata wannan nuni ya kasance?Shin [`` Pin`] '' <&mut Field>`` ko `&mut Field`?
//! Irin wannan tambayar ta taso tare da filayen `enum`, kuma yayin la'akari da nau'ikan container/wrapper kamar [`Vec<T>`], [`Box<T>`], ko [`RefCell<T>`].
//! (Wannan tambaya ta shafi duka abubuwan da ake iya canzawa da kuma waɗanda aka yi tarayya a kansu, kawai muna amfani da mafi yawan al'amuran da suka fi dacewa na maye gurbin maye gurbin anan don zane.)
//!
//! Ya nuna cewa a zahiri ga marubucin tsarin bayanan ne zai yanke shawara ko tsinkayen da aka yi wa wani fanni ya juya [`Pin`]`<&mut Struct> '' zuwa (`` Pin`] '' <&mut Field>`ko `&mut Field`.Akwai wasu saka ko da yake, da kuma mafi muhimmanci tauyewa ne *daidaito*:
//! kowane fanni na iya zama *ko dai* an tsara shi zuwa bayanin da aka liƙa,*ko* cire cirewa a matsayin ɓangare na tsinkayen.
//! Idan duka biyun an yi su a filin daya, to hakan zai zama mara kyau!
//!
//! A matsayinka na marubucin tsarin bayanai zaka yanke hukunci game da kowane fanni ko sanya "propagates" zuwa wannan filin ko a'a.
//! Pinning wanda yake yadawa ana kiransa "structural", saboda yana bin tsarin nau'in.
//! A cikin ƙananan ƙananan, muna bayyana abubuwan da za a yi don kowane zaɓi.
//!
//! ## Pinning *ba* tsari bane don `field`
//!
//! Yana iya zama kamar ba abu ne mai rikitarwa ba cewa filin abin da aka sassaka ba za a iya sanya shi ba, amma wannan shine mafi kyawun zaɓi: idan ba a taɓa ƙirƙirar Filin (``Pin`] ''&<&mut> ba, babu abin da zai iya yin kuskure!Don haka, idan kun yanke hukunci cewa wasu fagen ba su da tsarin yin gini, duk abin da ya kamata ku tabbatar shi ne cewa ba za ku taɓa ƙirƙirar abin da aka ambata a wannan filin ba.
//!
//! Eldsungiyoyi ba tare da zane-zane ba na iya samun hanyar tsinkaya wanda ke juya [``Pin`] '' <&mut Struct> `` zuwa `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Wannan yana da kyau saboda ba a taɓa ɗaukar `field` a haɗe ba.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Hakanan kuna iya `impl Unpin for Struct`*koda kuwa* nau'in `field` ba [`Unpin`] bane.Abin da wancan nau'in ke tunani game da liƙawa bai dace ba yayin da ba a taɓa ƙirƙirar Fil na [``Pin`] '' <&mut> ba.
//!
//! ## Pinning *shine* tsari don `field`
//!
//! Sauran zaɓin shine yanke shawarar cewa liƙawa shine "structural" don `field`, ma'ana cewa idan aka nitsar da tsarin to haka filin yake.
//!
//! Wannan yana ba da damar rubuta tsinkaye wanda ke haifar da (``Pin`] '' <&mut Field> ``, saboda haka shaida cewa an fille filin:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Wannan yana da kyau saboda `field` an like lokacin da `self` yake.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Koyaya, pinning na tsari yana zuwa da aan ƙarin buƙatun:
//!
//! 1. Tsarin dole ne ya zama [`Unpin`] kawai idan duk fannonin tsarin [`Unpin`] ne.Wannan shine tsoffin, amma [`Unpin`] amintacce ne trait, don haka a matsayina na marubucin tsarin aikin ku ne ba * don ƙara abu kamar `impl<T> Unpin for Struct<T>`.
//! (Lura cewa ƙara aikin tsinkaye yana buƙatar lambar tsaro, don haka gaskiyar cewa [`Unpin`] amintacciya ce trait ba ta karya ƙa'idar cewa kawai ku damu da ɗayan wannan ba idan kuna amfani da `` mara lafiya ''.)
//! 2. Mai halakar da tsarin dole ne ya kawar da fannonin tsari daga hujjarsa.Wannan shine ainihin ma'anar da aka ɗauka a cikin [previous section][drop-impl]: `drop` ya ɗauki `&mut self`, amma tsarin (kuma don haka yankuna) mai yiwuwa an riga an sanya shi a baya.
//!     Dole ne ku tabbatar da cewa baku motsa wani yanki a cikin aiwatarwar ku na [`Drop`].
//!     Musamman, kamar yadda aka bayyana a baya, wannan yana nufin cewa tsarin ku dole ne *bazai* zama `#[repr(packed)]` ba.
//!     Duba wannan sashin don yadda zaka rubuta [`drop`] ta hanyar da mai tarawa zai iya taimaka maka ba da gangan fasa shinge ba.
//! 3. Dole ne ku tabbata cewa kun goyi bayan [`Drop` guarantee][drop-guarantee]:
//!     da zarar an liƙa tsarinka, ƙwaƙwalwar da ke ƙunshe da abin ba za a sake rubutawa ko rarraba ta ba tare da kiran ɓarnataccen abun ciki ba.
//!     Wannan na iya zama wayo, kamar yadda [`VecDeque<T>`] ya shaida: mai lalata [`VecDeque<T>`] na iya kasa kiran [`drop`] akan dukkan abubuwa idan ɗayan masu lalata panics.Wannan ya keta garantin [`Drop`], saboda yana iya haifar da sanya abubuwa cikin tsari ba tare da an kira mai lalata su ba.([`VecDeque<T>`] bashi da tsinkayen tsinkaye, don haka wannan baya haifar da rashin ƙarfi.)
//! 4. Kada ku bayar da wasu ayyuka waɗanda zasu iya haifar da fitar da bayanai daga filayen tsari lokacin da aka faranta nau'in ku.Misali, idan tsarin ya ƙunshi [`Option<T>`] kuma akwai aiki na 'ɗauka' tare da nau'in `fn(Pin<&mut Struct<T>>) -> Option<T>`, ana iya amfani da wannan aikin don matsar da `T` daga cikin `Struct<T>` da aka ɗauka-wanda ke nufin yin pinning ba zai iya zama tsari ga filin da ke riƙe da wannan ba bayanai.
//!
//!     Don ƙarin rikitaccen misali na matsar da bayanai daga nau'in keɓaɓɓe, yi tunanin idan [`RefCell<T>`] yana da hanyar `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Sannan zamu iya yin haka:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Wannan bala'i ne, yana nufin za mu fara fara gano abubuwan da ke cikin [`RefCell<T>`] (ta amfani da `RefCell::get_pin_mut`) sannan mu matsar da wannan abun ta amfani da bayanan canjin da muka samu daga baya.
//!
//! ## Examples
//!
//! Ga nau'ikan kamar [`Vec<T>`], duka damar (ƙirar tsari ko a'a) suna da ma'ana.
//! [`Vec<T>`] tare da zane-zane na tsari yana iya samun hanyoyin `get_pin`/`get_pin_mut` don samun nassoshin da aka liƙa akan abubuwa.Koyaya, ba zai iya *ba* damar ƙira [`pop`][Vec::pop] a kan [`Vec<T>`] wanda aka ɗauka ba saboda hakan zai motsa abubuwan da aka ƙayyade (bisa tsari)!Hakanan bazai iya ba da izinin [`push`][Vec::push] ba, wanda zai iya sake rarrabawa kuma don haka ma ya motsa abubuwan da ke ciki.
//!
//! [`Vec<T>`] ba tare da zane-zane ba zai iya `impl<T> Unpin for Vec<T>`, saboda ba a taɓa ƙunshin abubuwan ciki ba kuma [`Vec<T>`] kanta tana da kyau tare da motsa shi kuma.
//! A wancan lokacin pinning kawai bashi da tasiri akan vector kwata-kwata.
//!
//! A cikin ɗakunan karatu na yau da kullun, nau'ikan alamomin gabaɗaya ba su da aikin yin gini, don haka ba sa bayar da tsinkayen tsinkaye.Wannan shine dalilin da yasa `Box<T>: Unpin` ya riƙe duk `T`.
//! Yana da ma'anar yin hakan don alamun nuna alama, saboda motsawar `Box<T>` ba ainihin motsa `T` ba: [`Box<T>`] na iya zama mai motsi kyauta (aka `Unpin`) koda kuwa `T` ba.A zahiri, koda [``Pin`] '' <`[` `Box`] ''<T>> ``da ('' Pin`] `<&mut T>` `koyaushe [`Unpin`] ne da kansu, saboda wannan dalili: an liƙa abin da ke ciki (na `T`), amma masu nunin kansu za a iya motsa su ba tare da motsa bayanan da aka liƙa ba.
//! Ga duka [`Box<T>`] da [``Pin`] '' <`('' Box`] ''<T>>,, ko an liƙa abun cikin gaba ɗaya ya dogara ne akan ko an nuna mai nunin, ma'ana liƙawa ba * tsari bane.
//!
//! Lokacin aiwatar da mai haɗawa na [`Future`], yawanci kuna buƙatar ƙwanƙwasa tsarin don ƙwanƙwasa futures, kamar yadda kuke buƙatar samun alamomin da aka lika musu don kiran [`poll`].
//! Amma idan mahaɗan ku yana ƙunshe da duk wani bayanan da baya buƙatar sanyawa, zaku iya sanya waɗancan filayen ba tsari kuma saboda haka samun damar yin amfani dasu da yardar kaina ta hanyar ambaton maye gurbi koda kuwa kuna da [``Pin`] ''&&Kai Kai> (kamar kamar yadda yake a cikin aiwatarwar ku na [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Alamar da aka manna.
///
/// Wannan shine mai nadewa a kusa da wani irin nuni wanda yasa wannan manunin "pin" ya zama kimarta a wurin, yana hana kimar da wannan mai nunin ya nusar da ita motsi sai dai in ta aiwatar da [`Unpin`].
///
///
/// *Dubi takaddun [`pin` module] don bayani game da tsunduma.*
///
/// [`pin` module]: self
///
// Note: `Clone` wanda ke ƙasa yana haifar da rashin ƙarfi kamar yadda zai yiwu a aiwatar
// `Clone` don nassoshi masu canzawa.
// Duba <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> don ƙarin bayani.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ba a samo aiwatarwar da ke ƙasa ba don guje wa lamuran sauti.
// `&self.pointer` kada ya kasance mai isa ga aiwatarwar trait mara amana.
//
// Duba <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> don ƙarin bayani.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Gina sabon `Pin<P>` a kusa da manuni zuwa wasu bayanai na nau'in da ke aiwatar da [`Unpin`].
    ///
    /// Ba kamar `Pin::new_unchecked` ba, wannan hanyar ba amintacciya ba ce saboda mai nuna alamar `P` ya yi rubutu zuwa nau'in [`Unpin`], wanda zai soke garantin lamuni.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // KYAUTA: ƙimar da aka nuna ita ce `Unpin`, don haka ba shi da buƙatu
        // a kusa da fil.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Yana kwance wannan `Pin<P>` yana dawo da maɓallin nuni.
    ///
    /// Wannan yana buƙatar cewa bayanan da ke cikin wannan `Pin` ɗin [`Unpin`] ne don haka za mu iya yin biris da masu canzawa yayin narkar da shi.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Gina sabon `Pin<P>` a kusa da zancen zuwa wasu bayanai na nau'ikan da zai iya ko ba zai iya aiwatar da `Unpin` ba.
    ///
    /// Idan `pointer` ya ɓace zuwa nau'in `Unpin`, yakamata ayi amfani da `Pin::new`.
    ///
    /// # Safety
    ///
    /// Wannan maginin bashi da hadari saboda baza mu iya bada tabbacin cewa bayanan da `pointer` ya nuna an fakaresu ba, ma'ana ba za a motsa bayanan ba ko kuma lalata bayanansa har sai ya fadi.
    /// Idan `Pin<P>` da aka gina bai bada garantin cewa bayanan `P` ya nuna ba, wannan ya keta yarjejeniyar API kuma yana iya haifar da halin da ba a bayyana ba a ayyukan (safe) na gaba.
    ///
    /// Ta amfani da wannan hanyar, kuna yin promise game da aiwatarwar `P::Deref` da `P::DerefMut`, idan sun wanzu.
    /// Mafi muhimmanci, dole ne su ba motsa daga su `self` muhawara: `Pin::as_mut` da `Pin::as_ref` zai kira `DerefMut::deref_mut` da `Deref::deref`*a kan pinned akan* da kuma sa ran wadannan hanyoyi don riqi pinning invariants.
    /// Haka kuma, ta hanyar kiran wannan hanyar ku promise cewa ambaton bayanan `P` ba zai sake motsawa daga sake ba;musamman, bazai yiwu ba a sami `&mut P::Target` sannan a fita daga waccan maganar (ta amfani da, misali [`mem::swap`]).
    ///
    ///
    /// Misali, kiran `Pin::new_unchecked` akan `&'a mut T` bashi da hadari saboda yayin da kake iya sanya shi tsawon rayuwar da aka baka `'a`, baka da iko kan ko an ajiye shi a kunne da zarar `'a` ya ƙare:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Wannan yana nufin ma'anar `a` ba za ta taɓa motsawa ba.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adireshin `a` ya canza zuwa `` b '' slot slot, don haka `a` ya motsa duk da cewa a baya mun sanya shi!Mun karya yarjejeniyar kwangilar API.
    /////
    /// }
    /// ```
    ///
    /// Aima'i, sau ɗaya an liƙa shi, dole ne ya kasance a haɗe har abada (sai dai idan nau'insa ya aiwatar da `Unpin`).
    ///
    /// Hakanan, kiran `Pin::new_unchecked` akan `Rc<T>` ba shi da hadari saboda ana iya samun laƙabi zuwa wannan bayanan waɗanda ba sa ƙarƙashin takunkumin shinge:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Wannan yana nufin ma'anar mai tsinkewa ba zata sake motsawa ba.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Yanzu, idan `x` shine kawai abin tunani, muna da maɓallin juyawa game da bayanan da muka ɗora a sama, wanda zamu iya amfani da shi don matsar da shi kamar yadda muka gani a misalin da ya gabata.
    ///     // Mun karya yarjejeniyar kwangilar API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Samu takamaiman bayanin da aka raba daga wannan manunin.
    ///
    /// Wannan hanya ce ta gama gari don zuwa daga `&Pin<Pointer<T>>` zuwa `Pin<&T>`.
    /// Yana da aminci saboda, a matsayin ɓangare na kwangilar `Pin::new_unchecked`, mai fashin baki ba zai iya motsawa bayan an ƙirƙiri `Pin<Pointer<T>>` ba.
    ///
    /// "Malicious" ana aiwatar da aiwatar da `Pointer::Deref` ta hanyar kwangilar `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // KYAUTA: duba takardu akan wannan aikin
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Yana kwance wannan `Pin<P>` yana dawo da maɓallin nuni.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci.Dole ne ka tabbatar da cewa za ka ci gaba da za mu bi da Pointer `P` kamar yadda pinned bayan ka kira wannan aikin, don haka da cewa invariants a kan `Pin` irin za a iya tsayar.
    /// Idan lambar da ke amfani da sakamakon `P` ba ta ci gaba da kula da masu canzawa ba wanda ya keta yarjejeniyar API kuma yana iya haifar da halin da ba a bayyana ba a ayyukan (safe) na gaba.
    ///
    ///
    /// Idan bayanan tushen shine [`Unpin`], yakamata ayi amfani da [`Pin::into_inner`] maimakon.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Samun bayanin da za'a iya canzawa daga wannan manunin.
    ///
    /// Wannan hanya ce ta gama gari don zuwa daga `&mut Pin<Pointer<T>>` zuwa `Pin<&mut T>`.
    /// Yana da aminci saboda, a matsayin ɓangare na kwangilar `Pin::new_unchecked`, mai fashin baki ba zai iya motsawa bayan an ƙirƙiri `Pin<Pointer<T>>` ba.
    ///
    /// "Malicious" ana aiwatar da aiwatar da `Pointer::DerefMut` ta hanyar kwangilar `Pin::new_unchecked`.
    ///
    /// Wannan hanyar tana da amfani yayin yin kira da yawa zuwa ayyukan da ke cinye nau'in nau'in.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // yi wani abu
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` cinye `self`, don haka sake sake `Pin<&mut Self>` ta hanyar `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // KYAUTA: duba takardu akan wannan aikin
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Sanya sabon ƙimar ga ƙwaƙwalwar ajiyar bayanan da aka liƙa.
    ///
    /// Wannan sake rubuta bayanan da aka liƙa, amma hakan yana da kyau: mai lalata shi yana gudana kafin a sake rubuta shi, don haka ba a keta garantin shinge ba.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Yana gina sabon fil ta zana taswirar ƙimar ciki.
    ///
    /// Misali, idan kanaso ka sami `Pin` na filin wani abu, zaka iya amfani da wannan don samun damar zuwa wannan filin a layin layi daya.
    /// Koyaya, akwai hanyoyi da yawa tare da waɗannan "pinning projections";
    /// duba takaddun [`pin` module] don ƙarin bayani kan wannan batun.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci.
    /// Dole ne ku tabbatar da cewa bayanan da kuka dawo ba zasu motsa ba muddin ƙimar gardama ba ta motsa (misali, saboda yana ɗaya daga cikin fannonin wannan ƙimar), kuma kuma ba ku fita daga hujjar da kuka karɓa ba aikin ciki.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // KYAUTA: kwangilar aminci ga `new_unchecked` dole ne ta kasance
        // tsayar da kira.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Samun bayanin da aka raba daga fil.
    ///
    /// Wannan amintacce ne saboda ba zai yiwu a fita daga bayanin da aka raba ba.
    /// Yana iya zama kamar akwai batun anan tare da canjin ciki: a zahiri,* * mai yuwuwa ne * don motsa `T` daga cikin `&RefCell<T>`.
    /// Koyaya, wannan ba matsala bane tunda dai babu wani `Pin<&T>` wanda yake nuni akan wannan bayanan, kuma `RefCell<T>` bazai baka damar ƙirƙirar abin da aka liƙa akan abubuwan da ke ciki ba.
    ///
    /// Duba tattaunawa akan ["pinning projections"] don ƙarin bayani.
    ///
    /// Note: `Pin` kuma yana aiwatar da `Deref` zuwa maƙasudin, wanda za'a iya amfani dashi don samun damar ƙimar ciki.
    /// Koyaya, `Deref` kawai yana ba da ishara wanda ke rayuwa har tsawon lokacin rancen na `Pin`, ba rayuwar `Pin` kanta ba.
    /// Wannan hanyar tana ba da damar juya `Pin` zuwa cikin tunani tare da rayuwa irin ta `Pin` ta asali.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ya canza wannan `Pin<&mut T>` ɗin zuwa `Pin<&T>` tare da rayuwa iri ɗaya.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Samu takamaiman canjin bayanai zuwa cikin wannan `Pin`.
    ///
    /// Wannan yana buƙatar cewa bayanan cikin wannan `Pin` shine `Unpin`.
    ///
    /// Note: `Pin` kuma yana aiwatar da `DerefMut` zuwa bayanan, wanda za'a iya amfani dashi don samun damar ƙimar ciki.
    /// Koyaya, `DerefMut` kawai yana ba da ishara wanda ke rayuwa har tsawon lokacin rancen na `Pin`, ba rayuwar `Pin` kanta ba.
    ///
    /// Wannan hanyar tana ba da damar juya `Pin` zuwa cikin tunani tare da rayuwa irin ta `Pin` ta asali.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Samu takamaiman canjin bayanai zuwa cikin wannan `Pin`.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci.
    /// Dole ne ku tabbatar cewa ba za ku taɓa fitar da bayanan ba daga maɓallin canjin da kuka karɓa lokacin da kuka kira wannan aikin, don a iya tabbatar da masu canzawa a kan nau'in `Pin`.
    ///
    ///
    /// Idan bayanan tushen shine `Unpin`, yakamata ayi amfani da `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Gina sabon fil ta zana taswirar ƙimar ciki.
    ///
    /// Misali, idan kanaso ka sami `Pin` na filin wani abu, zaka iya amfani da wannan don samun damar zuwa wannan filin a layin layi daya.
    /// Koyaya, akwai hanyoyi da yawa tare da waɗannan "pinning projections";
    /// duba takaddun [`pin` module] don ƙarin bayani kan wannan batun.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci.
    /// Dole ne ku tabbatar da cewa bayanan da kuka dawo ba zasu motsa ba muddin ƙimar gardama ba ta motsa (misali, saboda yana ɗaya daga cikin fannonin wannan ƙimar), kuma kuma ba ku fita daga hujjar da kuka karɓa ba aikin ciki.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // KYAUTA: mai kiran yana da alhakin rashin motsi da
        // darajar daga wannan tunani.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // KYAUTA: kamar yadda aka tabbatar da darajar `this` ba ta da shi
        // An motsa, wannan kiran zuwa `new_unchecked` yana cikin aminci.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Samo bayanin da aka sanya daga tsaye.
    ///
    /// Wannan yana da aminci, saboda an aro `T` don rayuwar `'static`, wanda baya ƙarewa.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // KYAUTA: 'a'idar bashi zata bada tabbacin bayanan ba zasu kasance ba
        // moved/invalidated har sai ya fadi (wanda ba ya taba).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Samo bayanin kula mai canzawa daga man tsaye.
    ///
    /// Wannan yana da aminci, saboda an aro `T` don rayuwar `'static`, wanda baya ƙarewa.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // KYAUTA: 'a'idar bashi zata bada tabbacin bayanan ba zasu kasance ba
        // moved/invalidated har sai ya fadi (wanda ba ya taba).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: wannan yana nufin cewa duk wani impl na `CoerceUnsized` wanda ke ba da damar tilastawa daga
// wani nau'in da ke haifar da `Deref<Target=impl !Unpin>` zuwa nau'in da ke nuna `Deref<Target=Unpin>` ba shi da kyau.
// Duk wani irin wannan tasirin zai iya zama mara kyau don wasu dalilai, kodayake, don haka muna buƙatar kulawa kawai don ƙin yarda da irin wannan tasirin zuwa cikin std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}