//! Hanyoyi don ƙirƙirar `str` daga yanki yanki.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Sabo da wani yanki na bytes zuwa kirtani yanki.
///
/// Ana yin zaren zaren ([`&str`]) da bytes ([`u8`]), kuma ana yin baiti ([`&[u8]`][byteslice]) da baiti, don haka wannan aikin yana canzawa tsakanin su biyun.
/// Ba duk yanyan bishi bane yankan kirtani masu inganci, kodayake: [`&str`] yana buƙatar yayi inganci UTF-8.
/// `from_utf8()` cak don tabbatar da cewa bytes ne m UTF-8, sa'an nan ya aikata ta hira.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Idan kun tabbata cewa byte yanki na aiki UTF-8 ne, kuma baku son jawo sama da binciken inganci, akwai sigar mara lafiya ta wannan aikin, [`from_utf8_unchecked`], wanda ke da halaye iri ɗaya amma ya tsallake rajistan.
///
///
/// Idan kuna buƙatar `String` maimakon `&str`, la'akari da [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Saboda zaku iya keɓe-`[u8; N]`, kuma zaku iya ɗaukar [`&[u8]`][byteslice] daga ciki, wannan aikin hanya ɗaya ce don samun keɓaɓɓen zare.Akwai misalin wannan a ɓangaren misalai da ke ƙasa.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Yana dawo da `Err` idan yanki bai zama UTF-8 ba tare da bayanin dalilin da yasa aka kawo yanki ba UTF-8 ba.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::str;
///
/// // wasu bytes, a cikin vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mun san wadannan baiti suna da inganci, don haka kawai yi amfani da `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Baiti mara daidai:
///
/// ```
/// use std::str;
///
/// // wasu baiti marasa inganci, a cikin vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Duba takardu don [`Utf8Error`] don ƙarin bayani kan nau'ikan kurakurai da za a iya dawo da su.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // wasu baiti, a cikin jeri-wanda aka ware tsararru
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Mun san wadannan baiti suna da inganci, don haka kawai yi amfani da `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // KYAUTA: Kamar kawai an gudanar da inganci.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Yana canza yanki mai canzawa na bytes zuwa yanki yanki mai canzawa.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" azaman mai canzawa vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Kamar yadda muka sani waɗannan baiti suna da inganci, zamu iya amfani da `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Baiti mara daidai:
///
/// ```
/// use std::str;
///
/// // Wasu baiti marasa inganci a cikin vector mai canzawa
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Duba takardu don [`Utf8Error`] don ƙarin bayani kan nau'ikan kurakurai da za a iya dawo da su.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // KYAUTA: Kamar kawai an gudanar da inganci.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Sabobin tuba wani yanki na bytes zuwa wani layi yanki ba tare da dubawa cewa kirtani ya ƙunshi aiki UTF-8.
///
/// Duba sigar aminci, [`from_utf8`], don ƙarin bayani.
///
/// # Safety
///
/// Wannan aikin bashi da aminci saboda baya duba cewa baiti da aka wuce zuwa gare shi ingantacce ne UTF-8.
/// Idan aka keta wannan ƙuntatawa, sakamakon ba a bayyana ma'anar sa ba, kamar yadda sauran Rust suka ɗauka cewa ''&str`] suna da inganci UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::str;
///
/// // wasu bytes, a cikin vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // KYAUTA: mai kira dole ne ya bada tabbacin cewa bytes `v` suna aiki UTF-8.
    // Hakanan yana dogara da `&str` da `&[u8]` suna da tsari iri ɗaya.
    unsafe { mem::transmute(v) }
}

/// Ya canza wani yanki na baiti zuwa yanki kirtani ba tare da bincika cewa kirtani ya ƙunshi ingantaccen UTF-8 ba;fasali mai canzawa.
///
///
/// Duba sigar mara canzawa, [`from_utf8_unchecked()`] don ƙarin bayani.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // KIYAYEWAR: mai kiran dole ne tabbacin cewa bytes `v`
    // suna da inganci UTF-8, ta haka ne da simintin zuwa `*mut str` shi ne hadari.
    // Hakanan, rubutun da aka nuna yana da aminci saboda wannan maɓallin ya fito ne daga ishara wanda aka tabbatar da ingancin rubutun.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}