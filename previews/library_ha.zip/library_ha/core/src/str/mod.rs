//! Kirtani magudi.
//!
//! Don ƙarin bayani, duba samfurin [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. wuce iyaka
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. fara <=ƙarshe
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. kan iyaka
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // sami halin
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` dole ne ƙasa da lamuni da kuma iyakar iyaka
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Ya dawo da tsawon `self`.
    ///
    /// Wannan tsayin yana cikin baiti, ba '' char` 's ko graphemes ba.
    /// A wasu kalmomin, shi bazai abin da wani mutum ya wadãtu da tsawon da kirtani.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // Fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Yana dawowa `true` idan `self` yanada tsayin baiti.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Yana duba cewa `` index '' byte shine baiti na farko a cikin jerin lambar lambar UTF-8 ko ƙarshen kirtani.
    ///
    ///
    /// Farkon da ƙarshen kirtani (lokacin da '' index== self.len()`) ake ɗaukar su a iyakoki.
    ///
    /// Dawowar `false` idan `index` ya fi `self.len()` girma.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // farkon `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // baiti na biyu na `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // baiti na uku na `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 da bashi koyaushe suna da kyau.
        // Gwaji don 0 a bayyane saboda ta iya inganta aikin duba cikin sauƙi kuma tsallake bayanan kirtani na karatun wannan lamarin.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Wannan bitan tsafin sihiri ne kwatankwacin: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Sabobin da zaren yanki zuwa yanki byte.
    /// Don canza yanki byte yanki a cikin yanki kirtani, yi amfani da aikin [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // KIYAYYA: sauti mai kyau saboda muna jujjuya nau'ikanmu guda biyu tare da tsari iri daya
        unsafe { mem::transmute(self) }
    }

    /// Ya canza yanki yanki mai canzawa zuwa yanki byte yanki.
    ///
    /// # Safety
    ///
    /// Wajibi ne mai kiran ya tabbatar cewa abun cikin yanki yana da inganci UTF-8 kafin aro ya ƙare kuma amfani da tushen `str`.
    ///
    ///
    /// Amfani da `str` wanda abubuwan da ke ciki basu da inganci UTF-8 ba halayya ce mara kyau.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // KYAUTA: castan wasa daga `&str` zuwa `&[u8]` suna da aminci tunda `str`
        // yana da tsari iri ɗaya kamar na `&[u8]` (kawai libstd ne zai iya yin wannan garantin).
        // Rubutun maɓallin yana da aminci tunda ya fito daga maɓallin canjin yanayi wanda aka tabbatar da ingancinsa don rubutu.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Sabobin da zaren yanki zuwa mai nuna alama.
    ///
    /// Kamar yadda kirtani yanka ne wani yanki na bytes, da raw akan maki wani [`u8`].
    /// Wannan manunin zai nuna farkon baiti na yanki kirtani.
    ///
    /// Dole ne mai kiran ya tabbatar da cewa wanda aka dawo da shi ba a rubuta masa ba.
    /// Idan kana buƙatar canzawa abubuwan da ke cikin yanki kirtani, yi amfani da [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Sabobin da za'a iya canzawa zuwa kirtani.
    ///
    /// Kamar yadda kirtani yanka ne wani yanki na bytes, da raw akan maki wani [`u8`].
    /// Wannan manunin zai nuna farkon baiti na yanki kirtani.
    ///
    /// Hakkin ku ne ku tabbatar cewa kawai zaren ya yanke ne ta yadda zai ci gaba da aiki UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Yana dawo da ofan kasuwa na `str`.
    ///
    /// Wannan shine madadin rashin tsoro don nuna alama akan `str`.
    /// Yana dawo da [`None`] duk lokacin da aikin daidaita daidaiton zai panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // fihirisa ba a kan iyakokin jerin UTF-8 ba
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // wuce iyaka
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Yana dawo da mutaramar canzawa ta `str`.
    ///
    /// Wannan shine madadin rashin tsoro don nuna alama akan `str`.
    /// Yana dawo da [`None`] duk lokacin da aikin daidaita daidaiton zai panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // madaidaicin tsayi
    /// assert!(v.get_mut(0..5).is_some());
    /// // wuce iyaka
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Ya dawo da sabon rajista na `str`.
    ///
    /// Wannan ita ce hanyar da ba a bincika ba don sanya alama akan `str`.
    ///
    /// # Safety
    ///
    /// Masu kiran wannan aikin suna da alhakin cewa waɗannan sharuɗɗan sun gamsu:
    ///
    /// * A lokacin da na fara index dole ba ƙetare kawo karshen index.
    /// * Exididdiga dole ne su kasance cikin iyakokin asalin yanki;
    /// * Exididdiga dole ne suyi kwance akan iyakokin jerin UTF-8.
    ///
    /// Idan ba haka ba, yanki da aka dawo da shi zai iya yin amfani da ƙwaƙwalwar da ba ta da amfani ko kuma ya keta waɗanda ba a san su ba ta hanyar nau'in `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `get_unchecked`;
        // yanki ba zai yiwu ba saboda `self` amintacce ne.
        // Maɓallin da aka dawo yana da aminci saboda abubuwan da aka samu na `SliceIndex` dole ne su tabbatar da cewa hakan ne.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Ya dawo da ablean musayar da ba za'a iya canzawa ba, na `str`.
    ///
    /// Wannan ita ce hanyar da ba a bincika ba don sanya alama akan `str`.
    ///
    /// # Safety
    ///
    /// Masu kiran wannan aikin suna da alhakin cewa waɗannan sharuɗɗan sun gamsu:
    ///
    /// * A lokacin da na fara index dole ba ƙetare kawo karshen index.
    /// * Exididdiga dole ne su kasance cikin iyakokin asalin yanki;
    /// * Exididdiga dole ne suyi kwance akan iyakokin jerin UTF-8.
    ///
    /// Idan ba haka ba, yanki da aka dawo da shi zai iya yin amfani da ƙwaƙwalwar da ba ta da amfani ko kuma ya keta waɗanda ba a san su ba ta hanyar nau'in `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `get_unchecked_mut`;
        // yanki ba zai yiwu ba saboda `self` amintacce ne.
        // Maɓallin da aka dawo yana da aminci saboda abubuwan da aka samu na `SliceIndex` dole ne su tabbatar da cewa hakan ne.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Creatirƙira yanki daga kirtani daga yanki, kewaye da rajistar tsaro.
    ///
    /// Wannan gaba ɗaya ba'a bada shawarar, yi amfani da taka tsantsan!Don amintaccen madadin duba [`str`] da [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Wannan sabon yanki yana zuwa daga `begin` zuwa `end`, gami da `begin` amma banda `end`.
    ///
    /// Don samun yanki madaidaicin yanki kirtani, duba hanyar [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Masu kiran wannan aikin suna da alhakin cewa an cika wadatar sharuɗɗa uku:
    ///
    /// * `begin` Dole ne ku ƙẽtare `end`.
    /// * `begin` kuma `end` dole ne ya zama matsayin baiti a cikin yanki kirtani.
    /// * `begin` kuma `end` dole ne ya kwanta akan iyakokin jerin UTF-8.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `get_unchecked`;
        // yanki ba zai yiwu ba saboda `self` amintacce ne.
        // Maɓallin da aka dawo yana da aminci saboda abubuwan da aka samu na `SliceIndex` dole ne su tabbatar da cewa hakan ne.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Creatirƙira yanki daga kirtani daga yanki, kewaye da rajistar tsaro.
    /// Wannan gaba ɗaya ba'a bada shawarar, yi amfani da taka tsantsan!Don amintaccen madadin duba [`str`] da [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Wannan sabon yanki yana zuwa daga `begin` zuwa `end`, gami da `begin` amma banda `end`.
    ///
    /// Don samun wani marar sakewa kirtani yanki maimakon, ganin [`slice_unchecked`] Hanyar.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Masu kiran wannan aikin suna da alhakin cewa an cika wadatar sharuɗɗa uku:
    ///
    /// * `begin` Dole ne ku ƙẽtare `end`.
    /// * `begin` kuma `end` dole ne ya zama matsayin baiti a cikin yanki kirtani.
    /// * `begin` kuma `end` dole ne ya kwanta akan iyakokin jerin UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `get_unchecked_mut`;
        // yanki ba zai yiwu ba saboda `self` amintacce ne.
        // Maɓallin da aka dawo yana da aminci saboda abubuwan da aka samu na `SliceIndex` dole ne su tabbatar da cewa hakan ne.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Raba yanki zaren guda biyu zuwa biyu a manuniya.
    ///
    /// Hujjar, `mid`, yakamata ta zama baiti daga farkon kirtani.
    /// Dole ne kuma ya kasance a kan iyakar lambar lambar UTF-8.
    ///
    /// Abubuwan da aka yanka guda biyu sun dawo daga farkon yanki zaren zuwa `mid`, kuma daga `mid` zuwa ƙarshen zaren.
    ///
    /// Don samun yanka kirtani mai canzawa maimakon, duba hanyar [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics idan `mid` ba a kan wani UTF-8 code batu iyaka, ko idan yana da karshen na karshe code batu na kirtani yanki.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary cak cewa index din yana cikin [0, .len()]
        if self.is_char_boundary(mid) {
            // KIYAYEWAR: kawai bari cewa `mid` ne a kan wani char iyaka.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Raba yanki igiyar zaren canzawa zuwa biyu a kan fihirisa.
    ///
    /// Hujjar, `mid`, yakamata ta zama baiti daga farkon kirtani.
    /// Dole ne kuma ya kasance a kan iyakar lambar lambar UTF-8.
    ///
    /// Abubuwan da aka yanka guda biyu sun dawo daga farkon yanki zaren zuwa `mid`, kuma daga `mid` zuwa ƙarshen zaren.
    ///
    /// Don samun yanka kirtani mara canzawa maimakon, duba hanyar [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics idan `mid` ba a kan wani UTF-8 code batu iyaka, ko idan yana da karshen na karshe code batu na kirtani yanki.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary cak cewa index din yana cikin [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // KIYAYEWAR: kawai bari cewa `mid` ne a kan wani char iyaka.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ya dawo da mai magana akan sashin kirtani.
    ///
    /// Kamar yadda yanki kirtani ya kunshi ingantaccen UTF-8, zamu iya yin amfani da shi ta hanyar yanki kirji ta [`char`].
    /// Wannan hanyar ta dawo da irin wannan.
    ///
    /// Yana da mahimmanci a tuna cewa [`char`] yana wakiltar caimar sikelin Unicode, kuma maiyuwa bai dace da ra'ayinku na menene 'character' ba.
    ///
    /// Rashin hankali akan gungu na grapheme na iya zama ainihin abin da kuke so.
    /// Ba a samar da wannan aikin ta ingantaccen ɗakin karatu na Rust, bincika crates.io maimakon.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Ka tuna, [``char`] mai yiwuwa bai dace da fahimtarka game da haruffa ba:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ba 'y̆' ba
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Ya dawo da mai magana a kan [`` char '' na yanki kirtani, da matsayinsu.
    ///
    /// Kamar yadda yanki kirtani ya kunshi ingantaccen UTF-8, zamu iya yin amfani da shi ta hanyar yanki kirji ta [`char`].
    /// Wannan hanyar ta dawo da maimaita duka waɗannan '' char '] ɗin, da matsayinsu na baiti.
    ///
    /// Mai yin magana yana ba da 'ya'yan itace.Matsayin shine na farko, [`char`] shine na biyu.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Ka tuna, [``char`] mai yiwuwa bai dace da fahimtarka game da haruffa ba:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ba (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // lura da 3 anan, halin karshe ya dauki bytes biyu
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Mai yin magana akan baiti na yanki kirtani.
    ///
    /// Kamar yadda yanki kirtani ya kunshi jerin baiti, zamu iya zagayawa ta hanyar kirtani ta baiti.
    /// Wannan hanyar ta dawo da irin wannan.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Ya raba yanki kirtani ta sararin samaniya.
    ///
    /// Maimaitawar da aka dawo zai dawo da yankan kirtani wadanda sune kananan yankuna na kirtani na asali, wanda ya rabu da kowane adadin farar fili.
    ///
    ///
    /// 'Whitespace' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `White_Space`.
    /// Idan kawai kuna son raba kan sararin samaniya na ASCII a maimakon haka, yi amfani da [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Dukkan nau'ikan sararin samaniya ana la'akari dasu:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Ya raba yanki kirtani ta sararin samaniya ASCII.
    ///
    /// Maimaitawar da aka dawo zai dawo da yankan kirtani wadanda sune kananan yankuna na asalin kirtani, an raba su da kowane adadin filin sararin ASCII.
    ///
    ///
    /// Don raba ta Unicode `Whitespace` maimakon haka, yi amfani da [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Duk nau'ikan sararin samaniya na ASCII ana la'akari dasu:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Mai magana akan layin kirtani, kamar yadda ake yanke kirtani.
    ///
    /// Lines sun ƙare tare da ko dai sabon layi (`\n`) ko dawo da karusa tare da layin layi na (`\r\n`).
    ///
    /// Linearshen layin ƙarshe zaɓi ne.
    /// Kirtani mai ƙarewa tare da ƙarshen layin ƙarshe zai dawo da layuka iri ɗaya azaman madaidaici iri ɗaya ba tare da ƙarshen layi na ƙarshe ba.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Ba a buƙatar ƙarshen layin ƙarshe:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Mai magana akan layin kirtani.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Ya dawo da mai magana na `u16` akan layin da aka sanya azaman UTF-16.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Koma `true` idan ba kwaikwaya yayi daidai da sub-yanki na wannan kirtani yanki.
    ///
    /// Yana dawowa `false` idan baiyi ba.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Yana dawo da `true` idan tsarin da aka bashi yayi daidai da kari na wannan yanki.
    ///
    /// Yana dawowa `false` idan baiyi ba.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Yana dawo da `true` idan tsarin da aka bashi yayi daidai da kari na wannan layin.
    ///
    /// Yana dawowa `false` idan baiyi ba.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Koma cikin byte index of harafin farkon wannan kirtani yanki wanda yayi daidai da juna.
    ///
    /// Yana dawowa [`None`] idan tsarin bai daidaita ba.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Complexarin hadaddun alamu ta amfani da salon mara ma'ana da rufewa:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ba gano abin kwaikwaya ba:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Yana dawo da ma'aunin ma'auni don yanayin farkon wasan mafi dacewa na abin kwaikwaya a cikin wannan yanki kirtani.
    ///
    /// Yana dawowa [`None`] idan tsarin bai daidaita ba.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Complexarin hadaddun alamu tare da rufewa:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ba gano abin kwaikwaya ba:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Mai yin magana a kan ginshiƙan wannan zaren zaren, ya rabu da haruffan da suka dace da juna.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo zai zama [`DoubleEndedIterator`] idan samfurin ya ba da damar bincika baya kuma binciken forward/reverse ya samar da abubuwa iri ɗaya.
    /// Wannan gaskiya ne ga, misali, [`char`], amma ba don `&str` ba.
    ///
    /// Idan juna damar a baya search amma ta sakamakon iya bambanta daga wata gaba search, da [`rsplit`] Hanyar za a iya amfani da su.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Idan samfurin ya zama yanki na chars, raba akan kowane abin da ya faru na kowane ɗayan haruffa:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Complexarin tsari mai rikitarwa, ta amfani da ƙulli:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Idan kirtani ya ƙunshi maɓuɓɓugan maɓuɓɓuka masu yawa, za ku ƙare tare da kirtani mara amfani a cikin fitarwa:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Contiguous separators rabu da komai kirtani.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Masu raba a farkon ko ƙarshen kirtani suna makwabtaka da layu mara amfani.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Lokacin da aka yi amfani da zaren mara amfani azaman mai raba shi, yana raba kowane hali a cikin layin, tare da farkon da ƙarshen zaren.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Masu rarrabuwar kawuna na iya haifar da halaye na ban mamaki yayin da aka yi amfani da sararin samaniya azaman mai raba.Wannan lambar daidai ce:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ yayi muku:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Yi amfani da [`split_whitespace`] don wannan ɗabi'ar.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Mai yin magana a kan ginshiƙan wannan zaren zaren, ya rabu da haruffan da suka dace da juna.
    /// Ya bambanta daga mai sarrafawa wanda `split` ya samar a cikin wannan `split_inclusive` ya bar ɓangaren da aka daidaita a matsayin mai ƙare maɓallin.
    ///
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Idan kashi na karshe na zaren ya yi daidai, za a ɗauki wannan ɓangaren azaman mai kawo ƙarshen abin da ya gabata.
    /// Wannan maɓallin zai zama abu na ƙarshe da mai maimaitawa ya dawo da shi.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Maimaita magana a kan maɓallan maɓallin keɓaɓɓen zaren, an raba shi da haruffan da suka dace da juna kuma an ba da shi ta baya.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo yana buƙatar samfurin ya goyi bayan bincike baya, kuma zai zama [`DoubleEndedIterator`] idan bincike na forward/reverse ya samar da abubuwa iri ɗaya.
    ///
    ///
    /// Don yin aiki daga gaba, ana iya amfani da hanyar [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Complexarin tsari mai rikitarwa, ta amfani da ƙulli:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Mai yin magana akan maɓuɓɓugan ɓangaren zaren da aka bayar, ya rabu da haruffan da suka dace da juna.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ya yi daidai da [`split`], sai dai an tsallake abin da yake bi idan ba komai.
    ///
    /// [`split`]: str::split
    ///
    /// Ana iya amfani da wannan hanyar don bayanan kirtani wanda shine _terminated_, maimakon _separated_ ta hanyar tsari.
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo zai zama [`DoubleEndedIterator`] idan samfurin ya ba da damar bincika baya kuma binciken forward/reverse ya samar da abubuwa iri ɗaya.
    /// Wannan gaskiya ne ga, misali, [`char`], amma ba don `&str` ba.
    ///
    /// Idan tsarin ya ba da damar bincika baya amma sakamakonsa na iya bambanta da binciken da aka tura, za a iya amfani da hanyar [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Maimaita magana akan ginshiƙan `self`, rabu da haruffan da suka dace da tsari kuma sun sami tsari mai kyau.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ya yi daidai da [`split`], sai dai an tsallake abin da yake bi idan ba komai.
    ///
    /// [`split`]: str::split
    ///
    /// Ana iya amfani da wannan hanyar don bayanan kirtani wanda shine _terminated_, maimakon _separated_ ta hanyar tsari.
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo yana buƙatar samfurin ya goyi bayan binciken baya, kuma zai ƙare sau biyu idan bincike forward/reverse ya samar da abubuwa iri ɗaya.
    ///
    ///
    /// Don yin aiki daga gaba, ana iya amfani da hanyar [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Mai magana a kan ginshiƙan ɓangaren igiyar da aka bayar, ta rabu da tsari, an taƙaita shi don dawowa a mafi yawan abubuwan `n`.
    ///
    /// Idan aka dawo da maɓallan `n`, maɓallin keɓaɓɓe (maɓallin ``n`th) '' zai ƙunshi sauran kirtani.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Ba za a ƙarasa mai amsawar sau biyu ba, saboda ba ta da fa'ida don tallafawa.
    ///
    /// Idan samfurin ya ba da damar neman baya, za a iya amfani da hanyar [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Complexarin tsari mai rikitarwa, ta amfani da ƙulli:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Mai magana a kan ginshiƙan wannan igiyar zaren, ya rabu da juna, farawa daga ƙarshen zaren, an taƙaita shi zuwa dawowa a mafi yawan abubuwan `n`.
    ///
    ///
    /// Idan aka dawo da maɓallan `n`, maɓallin keɓaɓɓe (maɓallin ``n`th) '' zai ƙunshi sauran kirtani.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Ba za a ƙarasa mai amsawar sau biyu ba, saboda ba ta da fa'ida don tallafawa.
    ///
    /// Don rabuwa daga gaba, ana iya amfani da hanyar [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Complexarin tsari mai rikitarwa, ta amfani da ƙulli:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Ya raba zaren a farkon faruwar abin da aka ayyana kuma ya dawo da kari kafin iyakancewa da kari bayan iyakancewa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ya raba kirtani a kan abin da ya faru na ƙarshe na mai iyakance kuma ya dawo da kari kafin iyakancewa da kari bayan iyakancewa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Maimaita magana a kan tsaka-tsakin tsaka-tsakin abin zane a cikin yanki da aka bayar.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo zai zama [`DoubleEndedIterator`] idan samfurin ya ba da damar bincika baya kuma binciken forward/reverse ya samar da abubuwa iri ɗaya.
    /// Wannan gaskiya ne ga, misali, [`char`], amma ba don `&str` ba.
    ///
    /// Idan tsarin ya ba da damar bincika baya amma sakamakonsa na iya bambanta da binciken da aka tura, za a iya amfani da hanyar [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Mai yin magana a kan tsaka-tsakin matakala na abin kwaikwaya a cikin wannan zaren zaren, ya ba da tsari baya.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo yana buƙatar samfurin ya goyi bayan bincike baya, kuma zai zama [`DoubleEndedIterator`] idan bincike na forward/reverse ya samar da abubuwa iri ɗaya.
    ///
    ///
    /// Don yin aiki daga gaba, ana iya amfani da hanyar [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Mai magana akan abin da bai dace da juna ba a cikin wannan zanen da kuma alamun da wasan ya fara a ciki.
    ///
    /// Don matakan `pat` a cikin `self` waɗanda suka zowaya, ana iya dawo da alamun da ya dace da wasan farko.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo zai zama [`DoubleEndedIterator`] idan samfurin ya ba da damar bincika baya kuma binciken forward/reverse ya samar da abubuwa iri ɗaya.
    /// Wannan gaskiya ne ga, misali, [`char`], amma ba don `&str` ba.
    ///
    /// Idan tsarin ya ba da damar bincika baya amma sakamakonsa na iya bambanta da binciken da aka tura, za a iya amfani da hanyar [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // farkon `aba` kawai
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Mai magana akan rashin daidaitaccen wasan kwaikwayon tsakanin `self`, ya samar da tsari ta hanyar baya tare da alamun wasan.
    ///
    /// Don matakan `pat` tsakanin `self` wanda ya ruɓe, kawai alamun da suka dace da wasan ƙarshe ne aka dawo.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Halin haɓaka
    ///
    /// Maimaitawar da aka dawo yana buƙatar samfurin ya goyi bayan bincike baya, kuma zai zama [`DoubleEndedIterator`] idan bincike na forward/reverse ya samar da abubuwa iri ɗaya.
    ///
    ///
    /// Don yin aiki daga gaba, ana iya amfani da hanyar [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // kawai `aba` na ƙarshe
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Dawo da kirtani yanki da manyan da kuma trailing farin cire.
    ///
    /// 'Whitespace' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Yana dawo da yanki kirtani tare da jagorancin sararin sararin samaniya.
    ///
    /// 'Whitespace' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// `start` a cikin wannan mahallin yana nufin matsayi na farko na wannan igiyar baiti;domin a bar-to-dama da harshen Turanci kamar ko Rasha, wannan zai zama gefen hagu, da kuma ga dama-to-bar harsuna kamar Larabci, ko Hebrew, wannan zai zama gefen dama.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Yana dawo da yanki kirtani tare da cire filin fari.
    ///
    /// 'Whitespace' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// `end` a cikin wannan mahallin yana nufin matsayi na ƙarshe na wannan igiyar baiti;don yare hagu-dama kamar Ingilishi ko Rasha, wannan zai zama gefen dama, kuma harsunan dama zuwa hagu kamar Larabci ko Ibrananci, wannan zai zama gefen hagu.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Yana dawo da yanki kirtani tare da jagorancin sararin sararin samaniya.
    ///
    /// 'Whitespace' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// 'Left' a cikin wannan mahallin yana nufin matsayi na farko na wannan igiyar baiti;ga yare kamar Larabci ko Ibrananci waɗanda suke 'dama zuwa hagu' maimakon 'hagu zuwa dama', wannan zai zama gefen _right_, ba hagu ba.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Yana dawo da yanki kirtani tare da cire filin fari.
    ///
    /// 'Whitespace' an bayyana shi gwargwadon sharuɗɗan Unicode wanda aka Coreaukaka Mahimman Abubuwan `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// 'Right' a cikin wannan mahallin yana nufin karshe matsayi na cewa byte kirtani.ga yare kamar Larabci ko Ibrananci waɗanda suke 'dama zuwa hagu' maimakon 'hagu zuwa dama', wannan zai zama gefen _left_, ba dama ba.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Yana dawo da yanki na kirtani tare da dukkan kari da kuma kari wanda yayi daidai da tsarin da aka cire sau da yawa.
    ///
    /// [pattern] na iya zama [`char`], yanki na '' char`] s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Complexarin tsari mai rikitarwa, ta amfani da ƙulli:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Ka tuna farkon wasan da aka sani, gyara shi a ƙasa idan
            // wasan karshe ya banbanta
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // KYAUTA: `Searcher` sananne ne don dawo da ingantattun fihirisa.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Ya dawo da yanki na kirtani tare da dukkan kari da suka dace da tsarin da aka cire sau da yawa.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// `start` a cikin wannan mahallin yana nufin matsayi na farko na wannan igiyar baiti;domin a bar-to-dama da harshen Turanci kamar ko Rasha, wannan zai zama gefen hagu, da kuma ga dama-to-bar harsuna kamar Larabci, ko Hebrew, wannan zai zama gefen dama.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // KYAUTA: `Searcher` sananne ne don dawo da ingantattun fihirisa.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Ya mayar da yanki kirtani tare da cire prefix.
    ///
    /// Idan kirtani ya fara da tsarin `prefix`, zai dawo da mahimmin bayan prefix, wanda aka nannade cikin `Some`.
    /// Ba kamar `trim_start_matches` ba, wannan hanyar tana cire prefix ɗin sau ɗaya.
    ///
    /// Idan kirtani ba ya fara tare da `prefix`, ya kõma `None`.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Koma kirtani yanki da kari na baya baki cire.
    ///
    /// Idan kirtani ya ƙare da fasalin `suffix`, ya dawo da maɓallin a gaban ɗarin, wanda aka nannade cikin `Some`.
    /// Ba kamar `trim_end_matches` ba, wannan hanyar tana cire karin daidai sau ɗaya.
    ///
    /// Idan kirtani bai ƙare da `suffix` ba, ya dawo `None`.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Ya dawo da yanki na kirtani tare da dukkan siffofin da suka dace da tsarin da aka cire sau da yawa.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// `end` a cikin wannan mahallin yana nufin matsayi na ƙarshe na wannan igiyar baiti;don yare hagu-dama kamar Ingilishi ko Rasha, wannan zai zama gefen dama, kuma harsunan dama zuwa hagu kamar Larabci ko Ibrananci, wannan zai zama gefen hagu.
    ///
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Complexarin tsari mai rikitarwa, ta amfani da ƙulli:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // KYAUTA: `Searcher` sananne ne don dawo da ingantattun fihirisa.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Ya dawo da yanki na kirtani tare da dukkan kari da suka dace da tsarin da aka cire sau da yawa.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// 'Left' a cikin wannan mahallin yana nufin matsayi na farko na wannan igiyar baiti;ga yare kamar Larabci ko Ibrananci waɗanda suke 'dama zuwa hagu' maimakon 'hagu zuwa dama', wannan zai zama gefen _right_, ba hagu ba.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Ya dawo da yanki na kirtani tare da dukkan siffofin da suka dace da tsarin da aka cire sau da yawa.
    ///
    /// [pattern] na iya zama `&str`, [`char`], yanki na `` char '' s, ko aiki ko ƙulli wanda ke yanke hukunci idan hali yayi daidai.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Kirtani jerin baiti ne.
    /// 'Right' a cikin wannan mahallin yana nufin karshe matsayi na cewa byte kirtani.ga yare kamar Larabci ko Ibrananci waɗanda suke 'dama zuwa hagu' maimakon 'hagu zuwa dama', wannan zai zama gefen _left_, ba dama ba.
    ///
    ///
    /// # Examples
    ///
    /// Alamu masu sauki:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Complexarin tsari mai rikitarwa, ta amfani da ƙulli:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses wannan kirtani yanki cikin wani irin.
    ///
    /// Saboda `parse` gabaɗaya ne, yana iya haifar da matsaloli game da nau'in rubutu.
    /// Kamar wannan, `parse` yana ɗayan fewan lokacin da zaku ga rubutun da ake kira 'turbofish': `::<>`.
    ///
    /// Wannan yana taimakawa fahimtar algorithm fahimtar takamaiman nau'in nau'in da kuke ƙoƙarin fassarawa ciki.
    ///
    /// `parse` na iya zurfafa cikin kowane nau'i wanda ke aiwatar da [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Zai dawo da [`Err`] idan ba zai yuwu a fassara wannan zaren yanki a cikin nau'in da ake so ba.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Amfani na asali
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Amfani da 'turbofish' maimakon bayyana `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Kasa yin tunani:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Duba idan duk haruffa a cikin wannan layin suna cikin zangon ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Zamu iya kula da kowane byte a matsayin hali a nan: duk haruffa multibyte suna farawa da baiti wanda baya cikin zangon ascii, saboda haka zamu tsaya can tuni.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Dubawa cewa kirtani guda biyu wasan ASCII ne maras ma'ana.
    ///
    /// Yayi daidai da `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, amma ba tare da kasaftawa da yin kwafin zamani ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Sanya wannan layin zuwa babban yanayin ASCII wanda yake daidai a cikin wuri.
    ///
    /// Haruffan ASCII 'a' zuwa 'z' an tsara su zuwa 'A' zuwa 'Z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don dawo da sabon darajar ƙarami ba tare da gyaggyara wanda yake ba, yi amfani da [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // KYAUTA: aminci saboda mun canza nau'ikanmu guda biyu tare da tsari iri ɗaya.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Sanya wannan layin zuwa matsayinta na ƙaramar ASCII daidai-a wuri.
    ///
    /// Haruffan ASCII 'A' zuwa 'Z' an tsara su zuwa 'a' zuwa 'z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don komawa wani sabon lowercased darajar ba tare da gyara da data kasance daya, yi amfani da [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // KYAUTA: aminci saboda mun canza nau'ikanmu guda biyu tare da tsari iri ɗaya.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Mayar da mai magana wanda ya tsere wa kowane layin a cikin `self` tare da [`char::escape_debug`].
    ///
    ///
    /// Note: kawai kalmomin rubutu na grapheme waɗanda suka fara zaren za su tsere.
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Mayar da mai magana wanda ya tsere wa kowane layin a cikin `self` tare da [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Koma wani iterator cewa tsere kowane char a `self` da [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Halicci komai str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Irƙirar fanko mai canzawa str
    #[inline]
    fn default() -> Self {
        // KIYAYEWAR: The komai kirtani ne m UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Nau'in suna, nau'in fn na zamani
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // KYAUTA: ba lafiya
        unsafe { from_utf8_unchecked(bytes) }
    };
}