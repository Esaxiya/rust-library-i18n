//! A koyaushe don aiki tare da bayanan aro.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait for aron data.
///
/// A Rust, shi ne na kowa ya samar da daban-daban wakilci na wani irin for daban-daban amfani lokuta.
/// Alal misali, ajiya wuri da kuma management ga darajar za a iya musamman zaba a matsayin dace don keɓaɓɓen amfani via akan iri kamar [`Box<T>`] ko [`Rc<T>`].
/// Beyond wadannan Generic wrappers cewa za a iya amfani da wani irin, wasu iri samar tilas fuskoki dabam-dabam bayar da yiwuwar m aiki.
/// Misali ga irin wannan shine [`String`] wanda ke ƙara ikon miƙa kirtani zuwa na asali [`str`].
/// Wannan na bukatar kiyaye ƙarin bayani ba dole ba ga wani sauki, marar sakewa kirtani.
///
/// Wadannan iri samar da damar yin muhimmi data ta hanyar nassoshi da irin wannan bayanai.Suna ce ya zama 'aro a matsayin' cewa irin.
/// Alal misali, a [`Box<T>`] za a iya aro a matsayin `T` yayin wani [`String`] za a iya aro a matsayin `str`.
///
/// Nau'in bayyana cewa su za a iya aro a matsayin wasu irin `T` ta hanyar aiwatar `Borrow<T>`, samar da wani tunani da wata `T` a trait ta [`borrow`] Hanyar.A irin shi ne free aro kamar yadda da dama daban-daban.
/// Idan yana nufin ya mutably ara matsayin da irin-kyale tamkar data za a modified, shi zai iya bugu da žari yi [`BorrowMut<T>`].
///
/// Bugu da ari, a lokacin da samar da implementations domin ƙarin traits, shi bukatar a yi la'akari ko su yi mu'amala m ga waɗanda na tamkar irin matsayin sakamako na aiki a matsayin misali na cewa tamkar irin.
/// Generic code yawanci yana amfani da `Borrow<T>` a lõkacin da ta dogara a kan m hali na wadannan ƙarin trait implementations.
/// Wadannan traits za su iya bayyana a matsayin ƙarin trait bounds.
///
/// A musamman `Eq`, `Ord` da `Hash` dole ne m ga aro da kuma mallakar dabi'u: `x.borrow() == y.borrow()` kamata ba wannan sakamakon a matsayin `x == y`.
///
/// Idan lambar jaka kawai ke buƙatar yin aiki don kowane nau'i wanda zai iya ba da ishara zuwa nau'in `T` mai alaƙa, yana da kyau koyaushe a yi amfani da [`AsRef<T>`] saboda yawancin nau'ikan na iya aiwatar da shi cikin aminci.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// A matsayin data tarin, [`HashMap<K, V>`] mallaki duka biyu makullin da kuma dabi'u.Idan ainihin maɓallan mabuɗin an lulluɓe shi cikin nau'in sarrafa abubuwa na wasu nau'ikan, yakamata, duk da haka, har yanzu zai yiwu a bincika ƙima ta amfani da bayanin maɓallin kewayawa.
/// Alal misali, idan key shi ne wani layi, to, shi ne wata ila adana tare da zanta map a matsayin [`String`], yayin da shi ya zama mai yiwuwa a bincika amfani da wani [`&str`][`str`].
/// Saboda haka, `insert` bukatar ya yi aiki a kan wani `String` yayin `get` bukatar ya zama iya amfani da `&str`.
///
/// Dan kadan Sauki, da dacewa sassa na `HashMap<K, V>` look kamar wannan:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // an tsallake filaye
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// A duka zanta taswirar ne Generic kan wani key irin `K`.Saboda waɗannan maɓallan da aka adana tare da zanta map, irin wannan yana da su mallaka da key ta data.
/// Lokacin shigar da maɓallin ƙirar maɓalli, ana ba da taswirar irin wannan `K` kuma yana buƙatar nemo madaidaicin guga gami da bincika idan mabuɗin ya riga ya kasance bisa ga wannan `K`.Yana haka na bukatar `K: Hash + Eq`.
///
/// Lokacin neman ƙima a cikin taswirar, kodayake, samun gabatarwa zuwa `K` azaman mabuɗin don bincika zai buƙaci ƙirƙirar irin wannan ƙimar da koyaushe.
/// Domin kirtani keys, wannan yana nufin a `String` darajar bukatar a halitta kawai ga search for lokuta inda kawai a `str` ne akwai.
///
/// Maimakon haka, `get` Hanyar ne Generic kan irin muhimmi key data, da ake kira `Q` a cikin hanyar sa hannu a sama.Ya bayyana cewa `K` ya ara a matsayin `Q` ta hanyar buƙatar `K: Borrow<Q>`.
/// Ta ƙarin buƙatar `Q: Hash + Eq`, yana nuna alamun da ake buƙata cewa `K` da `Q` suna da aiwatarwar `Hash` da `Eq` traits waɗanda ke samar da sakamako iri ɗaya.
///
/// Aiwatar da `get` ya dogara ne musamman akan aiwatarwa iri ɗaya na `Hash` ta hanyar ƙayyade bokitin hash ɗin maɓallin ta hanyar kiran `Hash::hash` akan ƙimar `Q` duk da cewa ya shigar da maɓallin bisa ƙimar hash da aka lissafa daga ƙimar `K`.
///
///
/// Sakamakon haka, taswirar hash ta karye idan `K` na narkar da ƙimar `Q` yana samar da zanta daban da ta `Q`.Alal misali, kaga kana da wani irin abin da shigar wani layi amma kwantanta ascii haruffa kyalewa su hali:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Saboda ƙimomi biyu daidai suna buƙatar samar da ƙimar hash iri ɗaya, aiwatar da `Hash` yana buƙatar yin watsi da shari'ar ASCII, ma:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Iya `CaseInsensitiveString` yi `Borrow<str>`?Yana lalle iya samar da wani tunani da wata kirtani yanki via ta dauke mallakar kirtani.
/// Amma saboda aiwatar da `Hash` ya bambanta, yana nuna halaye daban da na `str` sabili da haka dole ne, a zahiri, aiwatar da `Borrow<str>`.
/// Idan shi yana so ya ba da damar wasu damar zuwa muhimmi `str`, shi iya yi da cewa via `AsRef<str>` wanda ba ya gudanar da wani karin bukatun.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutably yiwo aro daga wani mallakar darajar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait for mutably aron data.
///
/// A matsayin abokin zama ga [`Borrow<T>`] wannan trait yana ba da damar wani nau'in aro a matsayin nau'in asali ta hanyar samar da alamar maye gurbi.
/// Duba [`Borrow<T>`] don ƙarin bayani kan lamuni a matsayin wani nau'in.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Daidaita lamuni daga ƙimar da aka mallaka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}