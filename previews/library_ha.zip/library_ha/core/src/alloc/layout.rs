use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Duk da yake ana amfani da wannan aikin a wuri guda kuma ana iya faɗakar da aiwatar da shi, yunƙurin da ya gabata na yin hakan ya sa rustc ya zama a hankali:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Tsari na toshe ƙwaƙwalwar ajiya.
///
/// Misali na `Layout` yayi bayanin takamaiman fasalin ƙwaƙwalwar ajiya.
/// Kuna gina `Layout` sama azaman shigarwa don bawa mai rabawa.
///
/// All shimfidu da wani Associated size kuma wani ikon-na-biyu jeri.
///
/// (Lura cewa shimfidawa *ba* ake buƙata don samun girman sifili ba, kodayake `GlobalAlloc` yana buƙatar cewa duk buƙatun ƙwaƙwalwar ajiya ba sifili ba cikin girma.
/// A kira dole ne ko dai tabbatar da cewa yanayi kamar wannan ne ya sadu, amfani da takamaiman allocators da looser bukatun, ko amfani da mafi m `Allocator` dubawa.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // size na nema block na memory, auna a bytes.
    size_: usize,

    // jeri na nema block na memory, auna a bytes.
    // muna tabbatar da cewa wannan koyaushe iko ne na-biyu, saboda API kamar `posix_memalign` na buƙatarsa kuma yana da ƙuntatawa mai dacewa don ɗorawa masu ginin Layout.
    //
    //
    // (Koyaya, bamu buƙatar daidaitawa daidai== sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Ya gina `Layout` daga `size` da `align` da aka bayar, ko ya dawo da `LayoutError` idan ɗayan waɗannan sharuɗɗan ba su cika ba:
    ///
    /// * `align` kada ya zama sifili,
    ///
    /// * `align` dole ne ya zama iko biyu,
    ///
    /// * `size`, lokacin da taso keya up to mafi kusa mahara na `align`, dole ne ba ambaliya (ie, da taso darajar dole ne ta zama ƙasa fi ko daidai to `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Ikon-na-biyu yakan haifar da mayar!=0.)

        // Taso up size ne:
        //   size_rounded_up=(size + mayar, 1)&! (A mayar, 1).
        //
        // Mun sani daga sama cewa daidaitawa!=0.
        // Idan ƙara (A mayar, 1) ba sunã zubar, sa'an nan Ƙididdigar up zai zama lafiya.
        //
        // Conversely,&-masking tare! (A mayar, 1) za su debewa kashe kawai low-domin-ragowa.
        // Don haka idan ambaliyar ta faru tare da jimlar,&&-mask ba zai iya rage isa don warware wannan ambaliya ba.
        //
        //
        // A sama yana nuna cewa bincika ƙarancin ambaton abu mai mahimmanci ne kuma ya isa.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // KYAUTA: yanayin `from_size_align_unchecked` ya kasance
        // bari a sama.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Creatirƙiri shimfidawa, kewaye da duk cak.
    ///
    /// # Safety
    ///
    /// Wannan aiki ne unsafe kamar yadda ba ya tabbatar da preconditions daga [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // KYAUTA: mai kira dole ne ya tabbatar cewa `align` ya fi sifili girma.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Mafi ƙarancin girma a cikin baiti don toshe ƙwaƙwalwar wannan shimfidar.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Jeri mafi ƙanƙan baiti don toshe ƙwaƙwalwar wannan shimfidar.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Ya gina `Layout` mai dacewa don riƙe ƙimar nau'in `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // KIYAYEWAR: da mayar tabbas ne ta Rust ya zama wani ikon biyu da kuma
        // Girman + daidaita daidaituwa an tabbatar da dacewa a cikin sararin adireshinmu.
        // A sakamakon amfani da zũciyõyinsu, constructor nan don kauce wa sa code cewa panics idan aka ba gyara da kyau isa.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Yana samar da shimfiɗa wanda ke bayanin rikodin da za'a iya amfani dashi don rarraba tsarin tallafawa don `T` (wanda zai iya zama trait ko wani nau'in da ba'a zana shi kamar yanki).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KYAUTA: duba ma'ana a cikin `new` don me yasa wannan ke amfani da bambancin da ba shi da hadari
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Yana samar da shimfiɗa wanda ke bayanin rikodin da za'a iya amfani dashi don rarraba tsarin tallafawa don `T` (wanda zai iya zama trait ko wani nau'in da ba'a zana shi kamar yanki).
    ///
    /// # Safety
    ///
    /// Wannan aikin yana da aminci in kira idan yanayi mai zuwa ya riƙe:
    ///
    /// - Idan `T` shine `Sized`, wannan aikin yana da lafiya koyaushe.
    /// - Idan unsized wutsiya na `T` ne:
    ///     - a [slice], to tsayin wutsiyar yanki dole ne ya zama adadi mai mahimmanci, kuma girman *duka ƙimar*(tsayin daka mai ƙarfi + prefix mai cikakken girma) dole ne ya dace da `isize`.
    ///     - wani [trait object], sa'an nan da vtable ɓangare na akan dole nuna mai aiki vtable ga irin `T` samu daga wani unsizing coersion, da kuma girman da *dukan darajar*(tsauri wutsiya tsawon + statically sized prefix) dole shige a `isize`.
    ///
    ///     - wani (unstable) [extern type], to, wannan aikin ne ko da yaushe lafiya kira, amma iya panic ko in ba haka ba koma da ba daidai ba da darajar, kamar yadda da extern irin ta layout ba a sani.
    ///     Wannan halayyar iri ɗaya ce kamar [`Layout::for_value`] akan tunani zuwa wutsiyar nau'in waje.
    ///     - in ba haka ba, ba a yarda da ra'ayin mazan jiya ya kira wannan aikin ba.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // KIYAYEWAR: mun wuce tare da abubuwan da ake bukata na wadannan ayyuka zuwa ga mai kiran
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KYAUTA: duba ma'ana a cikin `new` don me yasa wannan ke amfani da bambancin da ba shi da hadari
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Irƙira `NonNull` wanda yake walƙiya, amma ya dace sosai don wannan shimfidar.
    ///
    /// Lura cewa ƙimar maƙallan na iya wakiltar mai nuna alama mai inganci, wanda ke nufin wannan ba za a yi amfani da shi azaman darajar sentinel "not yet initialized" ba.
    /// Nau'ikan da kasala ke kasaftawa dole ne su bi diddigin farawa ta wasu hanyoyin.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // KIYAYEWAR: A mayar wanda tabbas zai zama maras sifili
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Esirƙira faifai mai bayyana rikodin wanda zai iya riƙe ƙimar daidaitattun layi ɗaya kamar `self`, amma wannan ma an daidaita shi zuwa daidaitawar `align` (an auna shi cikin baiti).
    ///
    ///
    /// Idan `self` riga ya gana da wajabta jeri, sa'an nan ya koma `self`.
    ///
    /// Ka lura da cewa wannan hanya ba ya ƙara wani padding da sauran size, ko da kuwa ko da koma layout yana da wani daban-daban jeri.
    /// A wasu kalmomin, idan `K` yana size 16, `K.align_to(32)` za *har yanzu* da size 16.
    ///
    /// Koma wani kuskure idan hade da `self.size()` da ba `align` warware yanayi da aka lissafa a [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Ya dawo adadin padding dole ne mu saka bayan `self` don tabbatar da cewa adireshin da ke gaba zai gamsar da `align` (an auna shi cikin baiti).
    ///
    /// misali, idan `self.size()` ne 9, sa'an nan `self.padding_needed_for(4)` kõma 3, domin wannan shi ne m yawan bytes na padding ake bukata don samun wata 4-hada kai adireshin (dauka cewa m memory block yana farawa a wata 4-hada kai adireshin).
    ///
    ///
    /// Theimar dawowar wannan aikin ba ta da ma'ana idan `align` ba ƙarfi-na-biyu bane.
    ///
    /// Note cewa mai amfani na koma darajar bukatar `align` su zama kasa ko ta daidaita da jeri na fara adireshin ga dukan kasaftawa block na memory.Daya hanyar zuwa gamsar da wannan tauyewa ne don tabbatar da `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Valueididdigar ƙimar ita ce:
        //   len_rounded_up=(len + tsara, 1)&! (tsara, 1);
        // sannan kuma zamu dawo da banbancin rami: `len_rounded_up - len`.
        //
        // Muna amfani da ilimin lissafi mai amfani a ko'ina:
        //
        // 1. A mayar wanda tabbas zai zama> 0, don haka mayar, 1 ne ko da yaushe m.
        //
        // 2.
        // `len + align - 1` iya anab da a mafi `align - 1`, don haka da&-mask da `!(align - 1)` zai tabbatar da cewa a cikin hali na ambaliya, `len_rounded_up` za kanta zama 0.
        //
        //    Don haka padding ɗin da aka dawo, lokacin da aka ƙara shi zuwa `len`, yana samar da 0, wanda ke ba da gamsarwa daidaita daidaiton `align`.
        //
        // (Tabbas, yunƙurin raba tubalan ƙwaƙwalwar ajiyar da girmanta da padding ya cika ta hanyar da ke sama ya kamata ya sa mai rabawar ya haifar da kuskure ko yaya.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Halicci layout da Ƙididdigar da girman wannan layout har zuwa wani mahara na layout ta jeri.
    ///
    ///
    /// Wannan yayi daidai da ƙara sakamakon `padding_needed_for` zuwa girman layout na yanzu.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Wannan ba zai iya cika ruwa ba.Ciro daga maras canjawa na Layout:
        // > `size`, lokacin da aka tattara zuwa kusan mafi kusa na `align`,
        // > dole ne ya cika ambaliya (ma'ana, ƙimar da ta kewaya dole ne ta kasance ƙasa da
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Creatirƙira faifai wanda ke bayanin rikodin don abubuwan `n` na `self`, tare da madaidaicin adadin padding tsakanin kowannensu don tabbatar da cewa kowane misali an bashi girmansa da daidaitawarsa.
    /// A nasara, ya kõma `(k, offs)` inda `k` ne layout na tsararru da `offs` ne nesa tsakanin farkon kowane kashi a cikin tsararru.
    ///
    /// A ilmin lissafi ambaliya, ya kõma `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Wannan ba zai iya cika ruwa ba.Ciro daga maras canjawa na Layout:
        // > `size`, lokacin da aka tattara zuwa kusan mafi kusa na `align`,
        // > dole ne ya cika ambaliya (ma'ana, ƙimar da ta kewaya dole ne ta kasance ƙasa da
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // KYAUTA: self.align an riga an san cewa yana da inganci kuma an riga an raba_size
        // padded riga.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Halicci layout kwatanta rikodin ga `self` bi ta `next`, ciki har da wani zama dole padding tabbatar da cewa `next` za a yadda ya kamata hada kai, amma *babu trailing padding*.
    ///
    /// Domin daidaita tsarin wakilcin C `repr(C)`, yakamata ku kira `pad_to_align` bayan ƙaddamar da shimfidawa tare da duk fannoni.
    /// (Babu wata hanyar da zata dace da tsarin wakilcin Rust na asali `repr(Rust)`, as it is unspecified.)
    ///
    /// Lura cewa jeri na sakamakon layout zai zama matsakaicin daga waɗanda na `self` da `next`, domin tabbatar da jeri na biyu sassa.
    ///
    /// Koma `Ok((k, offset))`, inda `k` ne layout na zaman masu alaƙa rikodi da kuma `offset` ne zumunta wuri, a bytes, na farko daga cikin `next` saka a cikin zaman masu alaƙa rikodin (dauka cewa rikodin kanta farawa a biya diyya 0).
    ///
    ///
    /// A ilmin lissafi ambaliya, ya kõma `LayoutError`.
    ///
    /// # Examples
    ///
    /// Don ƙididdige fasalin tsarin `#[repr(C)]` da kuma rarar filayen daga shimfidar filayen ta:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ka tuna, domin kammala tare da `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // gwada cewa yana aiki
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Halicci layout kwatanta rikodin ga `n` lokutta na `self`, ba tare da wani padding tsakanin kowane misali.
    ///
    /// Lura cewa, ba kamar `repeat` ba, `repeat_packed` baya bada garantin cewa lokuta da aka maimaita na `self` zasu dace daidai, koda kuwa misalin da aka bayar na `self` yayi daidai.
    /// A wasu kalmomin, idan layout koma ta `repeat_packed` ake amfani da su ware wani tsararru, shi ba bayar da tabbacin cewa duk abubuwa a cikin tsararru za a yadda ya kamata hada kai.
    ///
    /// A ilmin lissafi ambaliya, ya kõma `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Halicci layout kwatanta rikodin ga `self` bi ta `next` ba tare da wani ƙarin padding tsakanin biyu.
    /// Tunda ba a saka padding ba, daidaitawar `next` ba shi da mahimmanci, kuma ba a haɗa shi * kwata-kwata a cikin shimfidar sakamakon.
    ///
    ///
    /// A ilmin lissafi ambaliya, ya kõma `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Creatirƙiri shimfidawa mai bayyana rikodin don `[T; n]`.
    ///
    /// A ilmin lissafi ambaliya, ya kõma `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// A sigogi da aka ba `Layout::from_size_align` ko wasu sauran `Layout` constructor ba gamsar da rubuce saka.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (muna buƙatar wannan don ƙaddamar da Kuskuren trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}