//! Abubuwan raba APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Kuskuren `AllocError` yana nuna gazawar kasawa wanda zai iya kasancewa saboda ƙarancin albarkatu ko kuma wani abu ba daidai ba yayin haɗa mahawarar shigarwar da aka bayar tare da wannan mai rarraba.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (muna buƙatar wannan don ƙaddamar da Kuskuren trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Aiwatar da `Allocator` na iya rarrabawa, girma, raguwa, da kuma rarraba wasu tubalan bayanan da aka bayyana ta hanyar [`Layout`][].
///
/// `Allocator` an tsara shi don aiwatarwa akan ZSTs, nassoshi, ko masu nuna alama saboda samun mai raba kamar `MyAlloc([u8; N])` ba za a iya motsawa ba, ba tare da sabunta alamomin zuwa ƙwaƙwalwar da aka ware ba.
///
/// Ba kamar [`GlobalAlloc`][] ba, ana ba da izinin raba sifa a cikin `Allocator`.
/// Idan wani tamkar allocator ba ya goyon bayan wannan (kamar jemalloc) ko komawa a null akan (kamar `libc::malloc`), wannan dole ne a kama ta aiwatar.
///
/// ### A halin yanzu kasaftawa memori
///
/// Wasu daga cikin hanyoyin suna buƙatar cewa a sami toshe ƙwaƙwalwar ajiya *a halin yanzu kasaftawa* ta hanyar mai rarrabawa.Wannan yana nufin cewa:
///
/// * Adireshin farawa don wannan toshewar ƙwaƙwalwar an dawo da shi a baya ta [`allocate`], [`grow`], ko [`shrink`], kuma
///
/// * ba a raba ma'adanin ƙwaƙwalwar ba daga baya, inda aka raba tubalan kai tsaye ta hanyar wucewa zuwa [`deallocate`] ko an canza su ta hanyar wucewa zuwa [`grow`] ko [`shrink`] wanda ya dawo da `Ok`.
///
/// Idan `grow` ko `shrink` sun koma `Err`, da ya wuce akan rage m.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Fitwaƙwalwar ajiya
///
/// Wasu hanyoyin suna buƙatar faifai *dacewa* da toshe ƙwaƙwalwar.
/// Abin da ake nufi da layout zuwa "fit" ƙwaƙwalwar block nufin (ko equivalently, domin a ƙwaƙwalwar block to "fit" wani layout) ne cewa wadannan yanayi dole ne rike:
///
/// * Dole ne a raba bulo ɗin tare da daidaitawa iri ɗaya kamar [`layout.align()`], kuma
///
/// * A bayar da [`layout.size()`] dole ne fada a cikin kewayon `min ..= max`, inda:
///   - `min` shine girman shimfidawa kwanan nan da aka yi amfani dashi don ba da toshe, kuma
///   - `max` ne m ainihin girman koma daga [`allocate`], [`grow`], ko [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Memory tubalan koma daga wani allocator dole nuna inganci ƙwaƙwalwar ajiya da kuma riƙe su tushe har sai da misali, da dukan ta kwafi masu kunnen doki an kika aika,
///
/// * cloning ko matsar da mai kasaftawa bazai lalata ayyukan tubalan da aka dawo dasu daga wannan mai ba da ba.A cloned allocator dole hali kamar guda allocator, da kuma
///
/// * wani mauni zuwa žwažwalwar block wanda shi ne [*currently allocated*] iya wuce zuwa wani Hanyar da allocator.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Attoƙarin rarraba wani toshe na ƙwaƙwalwa.
    ///
    /// A nasara, ya kõma a [`NonNull<[u8]>`][NonNull] ganawa da size da kuma jeri tabbacin na `layout`.
    ///
    /// Gilashin da aka dawo na iya samun girma fiye da yadda `layout.size()` ya bayyana, kuma yana iya ko ba zai fara abubuwan da ke ciki ba.
    ///
    /// # Errors
    ///
    /// Dawo `Err` nuna cewa ko dai memory ne tikis ko `layout` ba ya hadu allocator ta size ko jeri saka.
    ///
    /// Implementations suna karfafa su koma `Err` a kan memory sha maimakon panicking ko aborting, amma wannan ba wani m da ake bukata.
    /// (Musamman: shi ne *doka* da su aiwatar da wannan trait ɗabaƙõƙĩ a wani muhimmi 'yan qasar kasafi library cewa aborts a kan memory ci.)
    ///
    /// Abokan ciniki da ke son zubar da lissafi saboda kuskuren rarrabawa ana ƙarfafa su kira aikin [`handle_alloc_error`], maimakon kiran kai tsaye `panic!` ko makamancin haka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behaves kamar `allocate`, amma kuma tabbatar da cewa da koma memory ne sifili-initialized.
    ///
    /// # Errors
    ///
    /// Dawo `Err` nuna cewa ko dai memory ne tikis ko `layout` ba ya hadu allocator ta size ko jeri saka.
    ///
    /// Implementations suna karfafa su koma `Err` a kan memory sha maimakon panicking ko aborting, amma wannan ba wani m da ake bukata.
    /// (Musamman: shi ne *doka* da su aiwatar da wannan trait ɗabaƙõƙĩ a wani muhimmi 'yan qasar kasafi library cewa aborts a kan memory ci.)
    ///
    /// Abokan ciniki da ke son zubar da lissafi saboda kuskuren rarrabawa ana ƙarfafa su kira aikin [`handle_alloc_error`], maimakon kiran kai tsaye `panic!` ko makamancin haka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // KIYAYEWAR: `alloc` kõma mai inganci memory block
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Keɓaɓɓiyar ƙwaƙwalwar ajiyar da `ptr` ta ambata.
    ///
    /// # Safety
    ///
    /// * `ptr` dole nuna a fakaice wani gungu na memory [*currently allocated*] via wannan allocator, da kuma
    /// * `layout` dole ne [*fit*] wannan toshe na ƙwaƙwalwar ajiya.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Oƙarin faɗaɗa toshe ƙwaƙwalwar.
    ///
    /// Koma wani sabon [`NonNull<[u8]>`][NonNull] dauke da wani akan kuma ainihin girman da kasaftawa ƙwaƙwalwar.Mai nuna alama ya dace da riƙe bayanan da `new_layout` ya bayyana.
    /// Don cika wannan, mai rarraba zai iya faɗaɗa kason da `ptr` ya ambata don dacewa da sabon shimfidar.
    ///
    /// Idan wannan ya dawo `Ok`, to an mallaki ikon toshewar ƙwaƙwalwar ajiya da aka ambata ta `ptr` zuwa wannan mai rarrabawa.
    /// Thewaƙwalwar na iya ko ba a sake shi ba, kuma ya kamata a yi la'akari da rashin amfani sai dai idan an sake mayar da shi ga mai kiran ta hanyar ƙimar dawowar wannan hanyar.
    ///
    /// Idan wannan hanyar ta dawo da `Err`, to ba a canja ikon mallakar ƙwaƙwalwar ajiya zuwa wannan mai rarrabawa ba, kuma ba a canza abubuwan da ke cikin toshewar ƙwaƙwalwar ba.
    ///
    /// # Safety
    ///
    /// * `ptr` dole ne ya nuna toshe ƙwaƙwalwar [*currently allocated*] ta wannan mai rarrabawa.
    /// * `old_layout` Dole ne [*fit*] cewa block na memory (The `new_layout` shaida bukatar ba su dace da shi.).
    /// * `new_layout.size()` dole ne ya zama ya fi girma ko daidai da `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Koma `Err` idan sabon layout ba ya sadu da allocator ta size da kuma jeri constraints na allocator, ko idan girma in ba haka ba ya kasa.
    ///
    /// Implementations suna karfafa su koma `Err` a kan memory sha maimakon panicking ko aborting, amma wannan ba wani m da ake bukata.
    /// (Musamman: shi ne *doka* da su aiwatar da wannan trait ɗabaƙõƙĩ a wani muhimmi 'yan qasar kasafi library cewa aborts a kan memory ci.)
    ///
    /// Abokan ciniki da ke son zubar da lissafi saboda kuskuren rarrabawa ana ƙarfafa su kira aikin [`handle_alloc_error`], maimakon kiran kai tsaye `panic!` ko makamancin haka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KIYAYEWAR: saboda `new_layout.size()` dole fi ko daidai to
        // `old_layout.size()`, duka tsoffin da sabon rabewar ƙwaƙwalwar ajiya suna aiki don karantawa kuma yayi rubutu don `old_layout.size()` bytes.
        // Hakanan, saboda ba a raba tsohuwar rarrabuwa ba, ba zai iya rufe `new_ptr` ba.
        // Don haka, kira zuwa `copy_nonoverlapping` yana cikin aminci.
        // Dole ne mai kiran ya kiyaye yarjejeniyar aminci ga `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Nuna halaye kamar `grow`, amma kuma yana tabbatar da cewa an saita sababbin abubuwan zuwa sifili kafin a dawo dasu.
    ///
    /// Blockwaƙwalwar ajiyar ƙwaƙwalwar za ta ƙunshi abubuwan da ke biyowa bayan nasarar nasara zuwa
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` ana kiyaye su daga asali na asali.
    ///   * Bytes `old_layout.size()..old_size` ko dai za a kiyaye shi ko kuma a ɓata shi, gwargwadon aiwatar da mai raba shi.
    ///   `old_size` yana nufin girman maƙallan ƙwaƙwalwar ajiya kafin kiran `grow_zeroed`, wanda zai iya zama girma fiye da girman da aka buƙaci asali lokacin da aka keɓe shi.
    ///   * Bytes `old_size..new_size` ake zeroed.`new_size` yana nufin girman toshe ƙwaƙwalwar da aka dawo da shi ta kiran `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` dole ne ya nuna toshe ƙwaƙwalwar [*currently allocated*] ta wannan mai rarrabawa.
    /// * `old_layout` Dole ne [*fit*] cewa block na memory (The `new_layout` shaida bukatar ba su dace da shi.).
    /// * `new_layout.size()` dole ne ya zama ya fi girma ko daidai da `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Koma `Err` idan sabon layout ba ya sadu da allocator ta size da kuma jeri constraints na allocator, ko idan girma in ba haka ba ya kasa.
    ///
    /// Implementations suna karfafa su koma `Err` a kan memory sha maimakon panicking ko aborting, amma wannan ba wani m da ake bukata.
    /// (Musamman: shi ne *doka* da su aiwatar da wannan trait ɗabaƙõƙĩ a wani muhimmi 'yan qasar kasafi library cewa aborts a kan memory ci.)
    ///
    /// Abokan ciniki da ke son zubar da lissafi saboda kuskuren rarrabawa ana ƙarfafa su kira aikin [`handle_alloc_error`], maimakon kiran kai tsaye `panic!` ko makamancin haka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // KIYAYEWAR: saboda `new_layout.size()` dole fi ko daidai to
        // `old_layout.size()`, duka tsoffin da sabon rabewar ƙwaƙwalwar ajiya suna aiki don karantawa kuma yayi rubutu don `old_layout.size()` bytes.
        // Hakanan, saboda ba a raba tsohuwar rarrabuwa ba, ba zai iya rufe `new_ptr` ba.
        // Don haka, kira zuwa `copy_nonoverlapping` yana cikin aminci.
        // Dole ne mai kiran ya kiyaye yarjejeniyar aminci ga `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Kokarin ji ƙyama da memory block.
    ///
    /// Koma wani sabon [`NonNull<[u8]>`][NonNull] dauke da wani akan kuma ainihin girman da kasaftawa ƙwaƙwalwar.Mai nuna alama ya dace da riƙe bayanan da `new_layout` ya bayyana.
    /// Don cim ma wannan, da allocator iya ji ƙyama da kasafi nusar da `ptr` ya dace da sabon layout.
    ///
    /// Idan wannan ya dawo `Ok`, to an mallaki ikon toshewar ƙwaƙwalwar ajiya da aka ambata ta `ptr` zuwa wannan mai rarrabawa.
    /// Thewaƙwalwar na iya ko ba a sake shi ba, kuma ya kamata a yi la'akari da rashin amfani sai dai idan an sake mayar da shi ga mai kiran ta hanyar ƙimar dawowar wannan hanyar.
    ///
    /// Idan wannan hanyar ta dawo da `Err`, to ba a canja ikon mallakar ƙwaƙwalwar ajiya zuwa wannan mai rarrabawa ba, kuma ba a canza abubuwan da ke cikin toshewar ƙwaƙwalwar ba.
    ///
    /// # Safety
    ///
    /// * `ptr` dole ne ya nuna toshe ƙwaƙwalwar [*currently allocated*] ta wannan mai rarrabawa.
    /// * `old_layout` Dole ne [*fit*] cewa block na memory (The `new_layout` shaida bukatar ba su dace da shi.).
    /// * `new_layout.size()` dole ne ya zama ƙasa da ko daidaita da `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Koma `Err` idan sabon layout ba ya sadu da allocator ta size da kuma jeri constraints na allocator, ko idan ƙunci in ba haka ba ya kasa.
    ///
    /// Implementations suna karfafa su koma `Err` a kan memory sha maimakon panicking ko aborting, amma wannan ba wani m da ake bukata.
    /// (Musamman: shi ne *doka* da su aiwatar da wannan trait ɗabaƙõƙĩ a wani muhimmi 'yan qasar kasafi library cewa aborts a kan memory ci.)
    ///
    /// Abokan ciniki da ke son zubar da lissafi saboda kuskuren rarrabawa ana ƙarfafa su kira aikin [`handle_alloc_error`], maimakon kiran kai tsaye `panic!` ko makamancin haka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KIYAYEWAR: saboda `new_layout.size()` dole ƙananan fi ko daidai to
        // `old_layout.size()`, biyu da haihuwa da kuma sabon memory kasafi ne m for karanta da kuma rubuta wa `new_layout.size()` bytes.
        // Hakanan, saboda ba a raba tsohuwar rarrabuwa ba, ba zai iya rufe `new_ptr` ba.
        // Don haka, kira zuwa `copy_nonoverlapping` yana cikin aminci.
        // Dole ne mai kiran ya kiyaye yarjejeniyar aminci ga `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Creatirƙira adaftan "by reference" don wannan misalin na `Allocator`.
    ///
    /// A koma adaftan kuma aiwatar da `Allocator` kuma za kawai ranta wannan.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KYAUTA: dole ne mai kiran ya kiyaye yarjejeniyar aminci
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KYAUTA: dole ne mai kiran ya kiyaye yarjejeniyar aminci
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KYAUTA: dole ne mai kiran ya kiyaye yarjejeniyar aminci
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KYAUTA: dole ne mai kiran ya kiyaye yarjejeniyar aminci
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}