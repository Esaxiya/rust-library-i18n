use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// A memory allocator cewa za a iya rijista a matsayin misali library ta tsoho, ta hanyar `#[global_allocator]` sifa.
///
/// Wasu daga cikin hanyoyin suna buƙatar cewa a sami toshe ƙwaƙwalwar ajiya *a halin yanzu kasaftawa* ta hanyar mai rarrabawa.Wannan yana nufin cewa:
///
/// * Adireshin farawa don wannan toshewar ƙwaƙwalwar ajiyar an dawo dashi a baya ta hanyar kiran baya zuwa hanyar rarraba kamar `alloc`, kuma
///
/// * Ba a sake rarraba toshe ƙwaƙwalwar ba daga baya, inda aka jujjuya tubalan ko dai ta hanyar wucewa zuwa hanyar musayar yarjejeniya kamar `dealloc` ko ta hanyar wucewa zuwa hanyar sake raba wuri wanda zai dawo da maɓallin da ba wofi ba.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// A `GlobalAlloc` trait ne `unsafe` trait ga yawan dalilai, da kuma implementors dole ne tabbatar da cewa sun bi zuwa wadannan kwangiloli:
///
/// * Halin da ba'a bayyana shi bane idan masu raba duniya suka kwance.Ana iya ɗaga wannan ƙuntatawa a cikin future, amma a halin yanzu panic daga ɗayan waɗannan ayyukan na iya haifar da rashin ƙwaƙwalwar ajiya.
///
/// * `Layout` tambayoyi da lissafi gabaɗaya dole su zama daidai.Masu kira wannan trait an yarda ka dõgara a kan kwangiloli a tsare a kowane hanya, da kuma implementors dole ne a tabbatar da irin wannan kwangila zama gaskiya.
///
/// * Za ka iya ba ka dõgara a kan asusun tarayya a zahiri faruwa, ko idan akwai bayyane heap asusun tarayya a cikin Madogararsa.
/// A dab'i iya gane sauran asusun tarayya cewa shi zai iya ko dai kashe gaba ɗaya ko motsawa zuwa ga tari, kuma haka gũrinta ba da allocator.
/// Mai ba da damar zai iya ɗauka cewa rabon ba zai iya yin kuskure ba, don haka lambar da aka saba amfani da ita ta gaza saboda gazawar masu rabewa na iya aiki ba zato ba tsammani saboda mai haɓakawa ya yi aiki a kan buƙatar rabon.
/// More concretely, da wadannan code misali ne unsound, ba tare da la'akari da ko da al'ada allocator damar kirgawa da yawa asusun tarayya sun faru.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Lura cewa abubuwan ingantawa da aka ambata a sama ba shine kawai ingantawa wanda za'a iya amfani dashi ba.Gabaɗaya baku dogara da rarar kuɗi da ke faruwa ba idan ana iya cire su ba tare da canza halin shirin ba.
///   Ko rabon gado ya faru ko a'a baya cikin halayyar shirin, koda kuwa za'a iya gano shi ta hanyar mai rabon wanda yake bibiyar kasafi ta hanyar bugawa ko kuma yana da wata illa.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Raba memorywa memorywalwar ajiya kamar yadda aka bayyana ta `layout` da aka bayar.
    ///
    /// Yana dawo da manuni zuwa sabon ƙwaƙwalwar da aka ware, ko kuma ya ɓace don nuna gazawar rarrabawa.
    ///
    /// # Safety
    ///
    /// Wannan aiki ne unsafe saboda maras bayyani hali zai iya haifar idan mai kira ba a tabbatar da cewa `layout` yana ba sifili size.
    ///
    /// (Traaramin subtraits na iya samar da wasu takamaiman iyakoki kan ɗabi'a, misali, tabbatar da adireshin sintiri ko maɓallin null a cikin martani game da neman rarar girman sifili.)
    ///
    /// Blockarin ƙwaƙwalwar ajiyar da aka ware na iya ko ba za'a iya farawa ba.
    ///
    /// # Errors
    ///
    /// Dawo a null akan nuna cewa ko dai memory ne tikis ko `layout` ba ya sadu da wannan allocator ta size ko jeri saka.
    ///
    /// Ana ƙarfafa aiwatarwa don dawowa wofi a kan ƙarancin ƙwaƙwalwar maimakon zubar da ciki, amma wannan ba ƙaƙƙarfan buƙata bane.
    /// (Musamman: shi ne *doka* da su aiwatar da wannan trait ɗabaƙõƙĩ a wani muhimmi 'yan qasar kasafi library cewa aborts a kan memory ci.)
    ///
    /// Abokan ciniki da ke son zubar da lissafi saboda kuskuren rarrabawa ana ƙarfafa su kira aikin [`handle_alloc_error`], maimakon kiran kai tsaye `panic!` ko makamancin haka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Saka maɓallin ƙwaƙwalwar ajiya a cikin maɓallin `ptr` da aka bayar tare da wanda aka bayar na `layout`.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci saboda halin da ba'a bayyana ba zai iya haifar idan mai kiran bai tabbatar da duk waɗannan abubuwa masu zuwa ba:
    ///
    ///
    /// * `ptr` - dole ne ya nuna toshe ƙwaƙwalwar ajiyar da aka keɓe ta wannan mai rarrabawa,
    ///
    /// * `layout` dole ne su kasance guda layout da aka yi amfani ware cewa block na memory.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Behaves kamar `alloc`, amma kuma tabbatar da cewa da abinda ke ciki an saita zuwa sifili kafin ake mayar da su.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci ga irin dalilan da `alloc` yake.
    /// Duk da haka kasaftawa block na memory tabbas ne za a initialized.
    ///
    /// # Errors
    ///
    /// Mayar da maɓallin null yana nuna cewa ko dai ƙwaƙwalwar ajiya ta ƙare ko `layout` ba ta haɗu da girman mai raba ko ƙuntatawa, kamar yadda yake a cikin `alloc`.
    ///
    /// Abokan ciniki da ke son zubar da lissafi saboda kuskuren rarrabawa ana ƙarfafa su kira aikin [`handle_alloc_error`], maimakon kiran kai tsaye `panic!` ko makamancin haka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // KIYAYEWAR: aminci kwangila ga `alloc` dole ne a tsayar da kira.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // KIYAYEWAR: kamar yadda kasafi nasara, da yankin daga `ptr`
            // na girman `size` tabbas zai zama mai inganci don rubutu.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Ji ƙyama ko girma a block na memory da ba `new_size`.
    /// An bayyana toshiyar ta hanyar nuna alamar `ptr` da `layout`.
    ///
    /// Idan wannan ya dawo da maɓallin da ba wofi ba, to an mallaki ikon toshewar ƙwaƙwalwar ajiya wanda aka ambata ta `ptr` zuwa wannan mai rarrabawa.
    /// Waƙwalwar na iya zama ko ba a raba shi ba, kuma ya kamata a yi la'akari da rashin amfani (sai dai idan ba shakka an sake mayar da shi ga mai kiran ta hanyar ƙimar dawo da wannan hanyar).
    /// Sabuwar kason memorin an kasafta shi tare da `layout`, amma tare da `size` da aka sabunta zuwa `new_size`.
    /// Wannan sabon layout kamata a yi amfani a lokacin da deallocating sabon memory block da `dealloc`.
    /// Range `0..min(layout.size(), new_size) `` na sabon toshe ƙwaƙwalwar yana da tabbacin yana da ƙimomi iri ɗaya da asalin toshe.
    ///
    /// Idan wannan hanyar dawo null, sa'an nan ikon mallakar ƙwaƙwalwar block ba a canjawa wuri zuwa wannan allocator, da kuma abinda ke ciki na memory block ne mai sãkẽwa ba.
    ///
    /// # Safety
    ///
    /// Wannan aikin bashi da aminci saboda halin da ba'a bayyana ba zai iya haifar idan mai kiran bai tabbatar da duk waɗannan abubuwa masu zuwa ba:
    ///
    /// * `ptr` - dole ne a raba shi a halin yanzu ta wannan mai rarraba,
    ///
    /// * `layout` - dole ne ya kasance shimfida ɗaya ce wacce aka yi amfani da ita don ba da wannan toshewar ƙwaƙwalwar,
    ///
    /// * `new_size` dole ne ya zama ya fi sifili girma.
    ///
    /// * `new_size`, lokacin da taso keya up to mafi kusa mahara na `layout.align()`, dole ne ba ambaliya (ie, da taso darajar dole ne kasa da `usize::MAX`).
    ///
    /// (Traaramin subtraits na iya samar da wasu takamaiman iyakoki kan ɗabi'a, misali, tabbatar da adireshin sintiri ko maɓallin null a cikin martani game da neman rarar girman sifili.)
    ///
    /// # Errors
    ///
    /// Ya dawo babu komai idan sabon salo bai hadu da ƙuntatawa masu daidaitawa da daidaitawa ba, ko kuma idan sake rarraba wuri ya gaza.
    ///
    /// Implementations suna karfafa su koma null a kan memory sha maimakon panicking ko aborting, amma wannan ba wani m da ake bukata.
    /// (Musamman: shi ne *doka* da su aiwatar da wannan trait ɗabaƙõƙĩ a wani muhimmi 'yan qasar kasafi library cewa aborts a kan memory ci.)
    ///
    /// Abokan ciniki fata zuwa QDialogButtonBox ƙidãyar a mayar da martani ga wani reallocation kuskure ana karfafa su kira [`handle_alloc_error`] aiki, maimakon kai tsaye kiran `panic!` ko kama.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // KIYAYEWAR: mai kiran dole ne tabbatar da cewa `new_size` ya aikata ba ambaliya.
        // `layout.align()` ya zo daga `Layout` kuma don haka an tabbatar da cewa yana aiki.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // KYAUTA: mai kira dole ne ya tabbatar cewa `new_layout` ya fi sifili girma.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // KIYAYEWAR: a baya kasaftawa block ba zai iya zoba da sabuwar kasaftawa block.
            // Dole ne mai kiran ya kiyaye yarjejeniyar aminci ga `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}