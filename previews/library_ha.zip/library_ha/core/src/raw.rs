#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Ya ƙunshi fassarorin tsari don tsarawar mai tarawa nau'ikan gini.
//!
//! Ana iya amfani da su azaman makamar hanyar wucewa cikin lamba mara aminci don sarrafa ɗanyen wakilci kai tsaye.
//!
//!
//! Bayanin su koyaushe ya dace da ABI wanda aka bayyana a cikin `rustc_middle::ty::layout`.
//!

/// Wakilin abin trait kamar `&dyn SomeTrait`.
///
/// Wannan tsarin yana da tsari iri ɗaya kamar iri kamar `&dyn SomeTrait` da `Box<dyn AnotherTrait>`.
///
/// `TraitObject` yana da tabbacin dacewa da shimfidu, amma ba nau'in abubuwa bane na trait (misali, filayen basa samun dama kai tsaye akan `&dyn SomeTrait`) kuma baya sarrafa wannan shimfidar (canza ma'anar ba zai canza fasalin `&dyn SomeTrait` ba).
///
/// An tsara shi ne kawai don amfani dashi ta lambar mara aminci wanda ke buƙatar yin amfani da ƙananan matakan ƙasa.
///
/// Babu wata hanyar da za a koma ga duk abubuwan trait gaba ɗaya, don haka hanya ɗaya kawai don ƙirƙirar ƙirar wannan nau'in ita ce tare da ayyuka kamar [`std::mem::transmute`][transmute].
/// Hakanan, hanya guda ɗaya don ƙirƙirar abin trait na gaskiya daga ƙimar `TraitObject` yana tare da `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Haɗa abu na trait tare da nau'ikan da ba a dace ba-wanda inda vtable bai dace da nau'in ƙimar abin da mai nuna bayanan yake ba-da alama zai iya haifar da halin da ba a bayyana ba.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // misali trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // bari da mai tarawa yin trait abu
/// let object: &dyn Foo = &value;
///
/// // kalli danyen wakilci
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // mai nuna bayanai shine adireshin `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // gina sabon abu, yana nuna wani `i32` daban, tare da taka tsantsan don amfani da `i32` vtable daga `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // yakamata yayi aiki kamar muna gina abu trait daga `other_value` kai tsaye
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}