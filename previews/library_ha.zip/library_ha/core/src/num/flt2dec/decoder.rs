//! Ya yanke mahimmin darajar shawagi a cikin sassan kowane mutum da jeren kuskure.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Odididdigar ƙayyadaddun ƙayyadaddun ƙaddara, kamar cewa:
///
/// - Matsayi na asali yayi daidai da `mant * 2^exp`.
///
/// - Duk wani lamba daga `(mant - minus)*2^exp` zuwa `(mant + plus)* 2^exp` zai zagaya zuwa ƙimar asali.
/// Yankin yana kunshe ne kawai lokacin da `inclusive` shine `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// A sikeli mantissa.
    pub mant: u64,
    /// Kewayon kuskuren ƙasa.
    pub minus: u64,
    /// Matsayin kuskure na sama.
    pub plus: u64,
    /// Abubuwan da aka raba a cikin tushe 2.
    pub exp: i16,
    /// Gaskiya lokacin da kewayon kuskure ya haɗa duka.
    ///
    /// A cikin IEEE 754, wannan gaskiya ne lokacin da asalin mantissa ta kasance.
    pub inclusive: bool,
}

/// Odimar da ba a sa hannu ba.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, ko dai tabbatacce ko mara kyau.
    Infinite,
    /// Sifili, ko dai tabbatacce ko mara kyau.
    Zero,
    /// Arshen lambobi tare da ƙarin filayen da aka ƙaddara.
    Finite(Decoded),
}

/// Nau'in mahimmin abu mai iyo wanda za'a iya ``yanke hukunci`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Mafi ƙarancin tabbataccen ƙimar darajar.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Yana dawo da alama (gaskiya lokacin da ba daidai ba) da ƙimar `FullDecoded` daga lambar da aka bayar mai iyo.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // maƙwabta: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode koyaushe yana kiyaye mai sarrafawa, saboda haka an auna mantissa don ƙananan halittu.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // maƙwabta: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // inda maxmant=mara kyau * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // maƙwabta: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}