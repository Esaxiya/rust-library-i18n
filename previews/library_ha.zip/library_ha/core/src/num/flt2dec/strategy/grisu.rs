//! Rust daidaitawa na Grisu3 algorithm wanda aka bayyana a cikin "Bugun Lambobin Shawagi-Point sauri da sauri tare da Masu haɗawa" [^ 1].
//! Yana amfani da kusan 1KB na tebur da aka riga aka gama aikin, kuma bi da bi, yana da sauri sosai don yawancin abubuwan shigarwa.
//!
//! [^1]: Florian Loitsch2010. Bugun lambobi suna shawagi da sauri kuma
//!   daidai tare da lambobi.SIGPLAN Ba.45, 6 (Yuni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// duba bayanai a cikin `format_shortest_opt` don ma'ana.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* ina, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// An ba `x > 0`, ya dawo da `(k, 10^k)` kamar `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Aiwatar da gajeriyar hanya don Grisu.
///
/// Yana dawo da `None` lokacin da zai dawo da wakilci mara sanadi in ba haka ba.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // muna buƙatar aƙalla rago uku na ƙarin daidaito

    // fara da daidaitattun ƙimomi tare da mai raba kayan
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // sami kowane `cached = 10^minusk` irin wannan `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // tunda `plus` ya daidaita, wannan yana nufin `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // an ba da zaɓin mu na `ALPHA` da `GAMMA`, wannan yana sanya `plus * cached` cikin `[4, 2^32)`.
    //
    // a bayyane yake kyawawa ne don a kara girman `GAMMA - ALPHA`, don haka ba za mu buƙaci ikon ajiya da yawa na 10 ba, amma akwai wasu lamuran:
    //
    //
    // 1. muna son kiyaye `floor(plus * cached)` a cikin `u32` tunda yana buƙatar rashi mai tsada.
    //    (wannan ba abin gujewa bane da gaske, ana buƙatar saura don kimantawa daidai.)
    // 2.
    // saura `floor(plus * cached)` ana ta ninka shi 10, kuma kada ya cika ruwa.
    //
    // na farko ya ba `64 + GAMMA <= 32`, yayin da na biyu ya ba `10 * 2^-ALPHA <= 2^64`;
    // -60 kuma -32 shine iyakar iyaka tare da wannan ƙuntatawa, kuma V8 suma suna amfani dasu.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // sikelin fps.wannan yana ba da kuskuren mafi girma na 1 ulp (wanda aka tabbatar daga Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-ainihin kewayon debewa
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // sama da `minus`, `v` da `plus` an ƙididdige *ƙididdigar*(kuskure <1 ulp).
    // kamar yadda ba mu san kuskuren yana da kyau ko mara kyau ba, muna amfani da kusanci biyu da aka tazara daidai kuma muna da kuskuren mafi girma na ulps 2.
    //
    // "unsafe region" lokaci ne mai sassauƙa wanda muke farawa da farko.
    // "safe region" tazara ce ta ra'ayin mazan jiya wanda kawai muke karɓa.
    // za mu fara da madaidaicin repr a cikin yankin da ba shi da hadari, kuma mu yi ƙoƙari mu sami mafi kusa repr zuwa `v` wanda shi ma yana cikin yankin mai aminci.
    // idan ba za mu iya ba, mu daina.
    //
    let plus1 = plus.f + 1;
    // bari plus0 = plus.f, 1;//kawai don bayani bari minus0 = minus.f + 1;//kawai don bayani
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // mai raba kaya

    // raba `plus1` zuwa ɓangarori masu mahimmanci da ƙananan abubuwa.
    // an tabbatar da bangarori masu mahimmanci don dacewa a cikin u32, tunda ikon ƙarfin ajiya yana tabbatar da `plus < 2^32` kuma daidaitaccen `plus.f` koyaushe ƙasa da `2^64 - 2^4` saboda ƙimar daidaitacciyar buƙata.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // lissafa mafi girma `10^max_kappa` bai fi `plus1` ba (saboda haka `plus1 < 10^(max_kappa+1)`).
    // wannan babban igiyar `kappa` ce a ƙasa.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: idan `k` shine mafi girman lamba
    // `0 <= y mod 10^k <= y - x`,              to, `V = floor(y / 10^k) * 10^k` yana cikin `[x, y]` kuma ɗayan mafi gajerun wakilci (tare da mafi ƙarancin lambobi masu mahimmanci) a cikin wannan kewayon.
    //
    //
    // sami tsayin lambar `kappa` tsakanin `(minus1, plus1)` kamar yadda Theorem 6.2 yake.
    // Za'a iya ɗaukar ka'idar 6.2 don ware `x` ta hanyar buƙatar `y mod 10^k < y - x` maimakon.
    // '
    //
    let delta1 = plus1 - minus1;
    // bari delta1int=(delta1>> e) kamar yadda amfani;//kawai don bayani
    let delta1frac = delta1 & ((1 << e) - 1);

    // sanya sassa masu mahimmanci, yayin bincika don daidaito a kowane mataki.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // lambobi har yanzu da za a fassara
    loop {
        // koyaushe muna da aƙalla lambobi guda ɗaya da zamu iya bayarwa, azaman masu canzawa na `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (yana bin wannan `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // raba `remainder` da `10^kappa`.duka ana auna su ta hanyar `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; mun sami daidai `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // sikelin 10 ^ kappa ya koma hannun mai talla
            return round_and_weed(
                // KYAUTA: mun ƙaddamar da wannan ƙwaƙwalwar a sama.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // karya madauki lokacin da muka sanya dukkan lambobi masu mahimmanci.
        // ainihin adadin lambobi shine `max_kappa + 1` azaman `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // mayar da marasa aiki
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ba da sassan ɓangare, yayin bincika don daidaito a kowane mataki.
    // wannan lokacin mun dogara da yawaitawa, saboda rashi zai rasa madaidaici.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // lamba na gaba ya zama mai mahimmanci kamar yadda muka gwada hakan kafin mu ɓarke, inda `m = max_kappa + 1` (#na lambobi a cikin ɓangaren haɗin):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ba zai ambaliya ba, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // raba `remainder` da `10^kappa`.
        // duka ana auna su ta hanyar `2^e / 10^kappa`, don haka na biyun a bayyane yake.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // a fakaice mai rarrabuwa
            return round_and_weed(
                // KYAUTA: mun ƙaddamar da wannan ƙwaƙwalwar a sama.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // mayar da marasa aiki
        kappa -= 1;
        remainder = r;
    }

    // mun kirkiro dukkan lambobi masu mahimmanci na `plus1`, amma ba tabbata ba idan shine mafi kyau duka.
    // misali, idan `minus1` ya kasance 3.14153 ... kuma `plus1` shine 3.14158 ..., akwai mafi ƙarancin wakilci 5 daga 3.14154 zuwa 3.14158 amma muna da mafi girma kawai.
    // dole ne muyi nasarar rage lamba ta karshe sannan mu duba idan wannan shine mafi kyaun repr.
    // akwai aƙalla 'yan takara 9 (..1 zuwa ..9), saboda haka wannan yana da sauri sauri.(Yanayin "rounding")
    //
    // aikin yana dubawa idan wannan "optimal" repr a zahiri yana cikin zangon ulp, kuma kuma, yana yiwuwa cewa "second-to-optimal" repr a zahiri zai iya zama mafi kyau saboda kuskuren zagaye.
    // a kowane hali wannan ya dawo `None`.
    // (Yanayin "weeding")
    //
    // duk mahawara anan ana auna ta da darajar (amma a bayyane) ta `k`, don haka:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (da ma, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (da ma, `threshold > plus1v` daga waɗanda ba su da tabbas)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // samar da kusanci biyu zuwa `v` (ainihin `plus1 - v`) a cikin ulps 1.5.
        // sakamakon da aka samu ya kamata ya zama mafi kusanci wakilci ga duka biyun.
        //
        // a nan ana amfani da `plus1 - v` tunda ana yin lissafi game da `plus1` don kauce wa overflow/underflow (saboda haka sunayen da aka sauya suna).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // rage lambar ƙarshe kuma tsaya a mafi kusancin wakilci zuwa `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // muna aiki tare da kimanin lambobi `w(n)`, wanda da farko daidai yake da `plus1 - plus1 % 10^kappa`.-bayan kunna madauki jiki `n` sau, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // mun saita `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (don haka `` saura= plus1w(0)`) don sauƙaƙe rajista.
            // Lura cewa `plus1w(n)` koyaushe yana ƙaruwa.
            //
            // muna da yanayi guda uku da zamu tsaida.ɗayansu zai sa madauki ya kasa ci gaba, amma muna da aƙalla wakilci mai inganci guda ɗaya sananne ya fi kusa da `v + 1 ulp` duk da haka.
            // za mu nuna su kamar TC1 ta hanyar TC3 don taƙaitawa.
            //
            // TC1: `w(n) <= v + 1 ulp`, watau, wannan shine repr na ƙarshe wanda zai iya zama mafi kusa.
            // wannan yayi daidai da `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // haɗe tare da TC2 (wanda ke bincika idan `w(n+1)` is valid), wannan yana hana yiwuwar ambaliya akan lissafin `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, watau, repr na gaba tabbas baya zagaye zuwa `v`.
            // wannan yayi daidai da `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // gefen hagu na iya malala, amma mun san `threshold > plus1v`, don haka idan TC1 ƙarya ne, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` kuma za mu iya gwada lafiya idan `threshold - plus1w(n) < 10^kappa` a maimakon haka.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, watau, repr na gaba shine
            // ba kusa da `v + 1 ulp` fiye da repr na yanzu.
            // aka ba `z(n) = plus1v_up - plus1w(n)`, wannan ya zama `abs(z(n)) <= abs(z(n+1))`.sake ɗaukar cewa TC1 ƙarya ne, muna da `z(n) > 0`.muna da lokuta biyu da za mu yi la'akari da su:
            //
            // - lokacin da `z(n+1) >= 0`: TC3 ya zama `z(n) <= z(n+1)`.
            // yayin da `plus1w(n)` ke ƙaruwa, `z(n)` ya zama yana raguwa kuma wannan ƙarya ne bayyananne.
            // - lokacin da `z(n+1) < 0`:
            //   - TC3a: sharadin shine `plus1v_up < plus1w(n) + 10^kappa`.zaton TC2 karya ne, `threshold >= plus1w(n) + 10^kappa` don haka ba zai iya malalo ba.
            //   - TC3b: TC3 ya zama `z(n) <= -z(n+1)`, watau, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 da aka ƙi bashi yana ba `plus1v_up > plus1w(n)`, don haka ba zai iya malalo ko ya cika ba idan aka haɗa shi da TC3a.
            //
            // saboda haka, ya kamata mu tsaya lokacin `TC1 || TC2 || (TC3a && TC3b)`.mai zuwa daidai yake da akasin haka, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // mafi guntu repr ba zai iya ƙarewa tare da `0` ba
                plus1w += ten_kappa;
            }
        }

        // bincika idan wannan wakilcin shine ma kusancin wakilci zuwa `v - 1 ulp`.
        //
        // wannan daidai yake da yanayin ƙarshe na `v + 1 ulp`, tare da maye gurbin duk `plus1v_up` da `plus1v_down` maimakon.
        // ambaliya mai cikakken tsari daidai yake riƙe.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // yanzu muna da kusancin wakilci zuwa `v` tsakanin `plus1` da `minus1`.
        // wannan yana da sassaucin ra'ayi, kodayake, saboda haka mun ƙi kowane `w(n)` ba tsakanin `plus0` da `minus0` ba, watau, `plus1 - plus1w(n) <= minus0` ko `plus1 - plus1w(n) >= plus0`.
        // muna amfani da gaskiyar cewa `threshold = plus1 - minus1` da `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Tsarin mafi guntu ga aiwatarwa don Grisu tare da dawowar faduwar gaba.
///
/// Wannan ya kamata a yi amfani da shi don mafi yawan lokuta.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // KYAUTA: Mai aron bashi bashi da hankalin da zai bamu damar amfani da `buf`
    // a cikin branch na biyu, saboda haka muna yin ragowar rayuwa anan.
    // Amma muna sake amfani da `buf` ne kawai idan `format_shortest_opt` ya dawo da `None` don haka wannan yana da kyau.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Tabbatacce kuma tsayayyen yanayin aiwatarwa don Grisu.
///
/// Yana dawo da `None` lokacin da zai dawo da wakilci mara sanadi in ba haka ba.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // muna buƙatar aƙalla rago uku na ƙarin daidaito
    assert!(!buf.is_empty());

    // daidaita da sikelin `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // raba `v` zuwa ɓangarori masu mahimmanci da ɓangare.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // duka tsohuwar `v` da sabuwar `v` (wanda aka auna ta `10^-k`) suna da kuskuren <1 ulp (Theorem 5.1).
    // kamar yadda ba mu san kuskuren yana da kyau ko mara kyau ba, muna amfani da ƙididdiga biyu da aka tazara daidai kuma muna da kuskuren mafi girma na ulps 2 (daidai da gajeriyar harka).
    //
    //
    // makasudin shine gano madaidaitan jerin lambobin lambobi wadanda suka saba da duka `v - 1 ulp` da `v + 1 ulp`, don haka muna da karfin gwiwa.
    // idan wannan ba zai yiwu ba, ba mu san wanne ne ya dace da `v` ba, don haka sai mu ba da baya mu koma baya.
    //
    // `err` an bayyana shi azaman `1 ulp * 2^e` a nan (daidai yake da gyambon ciki a cikin `vfrac`), kuma za mu auna shi duk lokacin da `v` ya samu sikeli.
    //
    //
    //
    let mut err = 1;

    // lissafa mafi girma `10^max_kappa` bai fi `v` ba (saboda haka `v < 10^(max_kappa+1)`).
    // wannan babban igiyar `kappa` ce a ƙasa.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // idan muna aiki tare da iyakan lambar ƙarshe, muna buƙatar rage gajiya kafin ainihin ma'ana don kaucewa zagaye biyu.
    //
    // Lura cewa dole ne mu sake fadada abin adana lokacin tattara abubuwa ya faru!
    let len = if exp <= limit {
        // oops, ba za mu iya samar da lambobi *ɗaya* ba.
        // wannan yana yiwuwa idan, ka ce, mun sami wani abu kamar 9.5 kuma ana zagaye shi zuwa 10.
        //
        // bisa ka'ida zamu iya kiran `possibly_round` nan da nan tare da fanken fanko, amma saka `max_ten_kappa << e` ta 10 na iya haifar da ambaliyar.
        //
        // don haka muna zama maras kyau a nan kuma muna faɗaɗa kewayon kuskure da kashi 10.
        // wannan zai kara adadin karya mara kyau, amma kawai,*sosai* kadan;
        // Abin sani kawai yana iya zama sananne yayin da mantissa ya fi girma fiye da rago 60.
        //
        // KYAUTA: `len=0`, saboda haka wajibcin ƙaddamar da wannan ƙwaƙwalwar ajiyar abu ne mai sauƙi.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // sa sassa masu mahimmanci.
    // Kuskuren gabaɗaya ɓangare ne, don haka ba ma buƙatar bincika shi a cikin wannan ɓangaren.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // lambobi har yanzu da za a fassara
    loop {
        // koyaushe muna da aƙalla lambobi guda ɗaya don ba da canji:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (yana bin wannan `remainder = vint % 10^(kappa+1)`)
        //
        //

        // raba `remainder` da `10^kappa`.duka ana auna su ta hanyar `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // shin buffer ta cika?gudanar da zagayen wucewa tare da saura.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // KYAUTA: mun ƙaddamar da `len` da yawa bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // karya madauki lokacin da muka sanya dukkan lambobi masu mahimmanci.
        // ainihin adadin lambobi shine `max_kappa + 1` azaman `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // mayar da marasa aiki
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ba da kashi-kashi.
    //
    // bisa mahimmanci zamu iya ci gaba zuwa lambar da take akwai ta ƙarshe kuma bincika daidaito.
    // rashin alheri muna aiki tare da adadi mai yawa, don haka muna buƙatar wasu ma'auni don gano ambaliyar.
    // V8 yana amfani da `remainder > err`, wanda ya zama ƙarya lokacin da farkon mahimman lambobin `i` na `v - 1 ulp` da `v` suka bambanta.
    // duk da haka wannan ya ƙi da yawa in ba haka ba ingantaccen labari.
    //
    // tunda lokaci na gaba yana da cikakkiyar gano ambaliyar ruwa, maimakon haka muna amfani da tsayayyar ma'auni:
    // za mu ci gaba har `err` ya wuce `10^kappa / 2`, don haka kewayon tsakanin `v - 1 ulp` da `v + 1 ulp` tabbas ya ƙunshi wakilai zagaye biyu ko fiye.
    //
    // wannan daidai yake da kwatancen farko guda biyu daga `possibly_round`, don tunani.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // marasa canzawa, inda `m = max_kappa + 1` (#na lambobi a cikin ɓangaren haɗin):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ba zai ambaliya ba, `2^e * 10 < 2^64`
        err *= 10; // ba zai ambaliya ba, `err * 10 < 2^e * 5 < 2^64`

        // raba `remainder` da `10^kappa`.
        // duka ana auna su ta hanyar `2^e / 10^kappa`, don haka na biyun a bayyane yake.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // shin buffer ta cika?gudanar da zagayen wucewa tare da saura.
        if i == len {
            // KYAUTA: mun ƙaddamar da `len` da yawa bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // mayar da marasa aiki
        remainder = r;
    }

    // ƙarin lissafi bashi da amfani (tabbas `possibly_round` ya faɗi), saboda haka mun daina.
    return None;

    // mun kirkiri dukkan lambobin da aka nema na `v`, wanda yakamata ya zama daidai da lambobin daidai na `v - 1 ulp`.
    // yanzu muna bincika idan akwai wakilci na musamman da `v - 1 ulp` da `v + 1 ulp` suka raba;wannan na iya zama iri ɗaya ne da adadin da aka samar, ko zuwa sigar da aka ƙididdige ta waɗancan lambobi.
    //
    // idan zangon ya ƙunshi wakilai da yawa na tsayi ɗaya, ba za mu iya tabbata ba kuma ya kamata mu dawo da `None` a maimakon haka.
    //
    // duk mahawara anan ana auna ta da darajar (amma a bayyane) ta `k`, don haka:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // KYAUTA: dole ne a fara baiti na `len` na farko na `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (don tunani, layin dige yana nuna ainihin ƙimar yiwuwar wakilci a cikin lambar da aka bayar na lambobi.)
        //
        //
        // kuskure ya yi yawa sosai cewa akwai aƙalla wakilai guda uku masu yuwuwa tsakanin `v - 1 ulp` da `v + 1 ulp`.
        // ba za mu iya tantance wanne ne daidai ba.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // a zahiri, 1/2 ulp ya isa gabatar da wakilai biyu masu yuwuwa.
        // (ka tuna cewa muna buƙatar wakilci na musamman don duka `v - 1 ulp` da `` v + 1 ulp ''.) wannan ba zai cika ba, kamar yadda `ulp < ten_kappa` daga binciken farko.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       :---10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // idan `v + 1 ulp` ya fi kusa da wakilcin da aka yi ƙasa (wanda ya rigaya a cikin `buf`), to za mu iya dawowa cikin aminci.
        // Lura cewa `v - 1 ulp`*na iya* zama ƙasa da wakilcin yanzu, amma kamar `1 ulp < 10^kappa / 2`, wannan yanayin ya isa:
        // tazara tsakanin `v - 1 ulp` da wakilcin yanzu ba za su iya wuce `10^kappa / 2` ba.
        //
        // yanayin yayi daidai da `remainder + ulp < 10^kappa / 2`.
        // tunda wannan yana iya malalo cikin sauƙin, fara bincika idan `remainder < 10^kappa / 2`.
        // mun riga mun tabbatar da cewa `ulp < 10^kappa / 2`, don haka matuƙar `10^kappa` bai cika ambaliya ba bayan haka, bincike na biyu yana da kyau.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // KYAUTA: mai kiranmu ya ƙaddamar da wannan ƙwaƙwalwar.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------saura------> |:
        //   :                          |   :
        //   :---10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // a ɗaya hannun, idan `v - 1 ulp` ya fi kusa da wakilcin da aka tara, ya kamata mu tattara mu dawo.
        // saboda wannan dalili ba ma buƙatar bincika `v + 1 ulp`.
        //
        // yanayin yayi daidai da `remainder - ulp >= 10^kappa / 2`.
        // kuma zamu fara dubawa idan `remainder > ulp` (lura cewa wannan ba `remainder >= ulp` bane, tunda `10^kappa` baya sifili).
        //
        // Har ila yau, lura cewa `remainder - ulp <= 10^kappa`, don haka rajistan na biyu bai cika ambaliya ba.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // KYAUTA: mai kiran namu tabbas ya fara tunanin.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // kawai kara wani adadi lokacin da aka nema mana madaidaicin madaidaici.
                // Har ila yau, muna buƙatar bincika wannan, idan asalin buffer ya kasance fanko, za a iya ƙara ƙarin lambar lokacin da `exp == limit` (edge case).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // KYAUTA: mu da mai kiran mu mun fara tunanin.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // in ba haka ba muna cikin halaka (watau, wasu ƙimomi tsakanin `v - 1 ulp` da `v + 1 ulp` suna zagaye wasu kuma suna zagaye) kuma sun daina.
        //
        None
    }
}

/// Tabbatacce kuma tsayayyen yanayin aiwatarwa don Grisu tare da draback fallback.
///
/// Wannan ya kamata a yi amfani da shi don mafi yawan lokuta.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // KYAUTA: Mai aron bashi bashi da hankalin da zai bamu damar amfani da `buf`
    // a cikin branch na biyu, saboda haka muna yin ragowar rayuwa anan.
    // Amma muna sake amfani da `buf` ne kawai idan `format_exact_opt` ya dawo da `None` don haka wannan yana da kyau.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}