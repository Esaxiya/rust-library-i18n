//! Kusan kai tsaye (amma an daidaita shi sosai) Rust fassarar Hoto na 3 na "Bugun Lambobin Shawagi da sauri da sauri" [^ 1].
//!
//!
//! [^1]: Burger, RG da Dybvig, RK 1996. Buga lambobi masu shawagi
//!   da sauri kuma daidai.SIGPLAN Ba.31, 5 (Mayu. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// an riga an kidaya jeri na 'Lambobi`s na 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// mai amfani ne kawai lokacin da `x < 16 * scale`;`scaleN` ya zama `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Tsarin mafi guntu aiwatarwa don Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // lambar `v` don tsara shine sananne shine:
    // - daidai yake da `mant * 2^exp`;
    // - wanda `(mant - 2 *minus)* 2^exp` ya riga ya gabata a cikin nau'in asali;kuma
    // - sannan `(mant + 2 *plus)* 2^exp` a cikin nau'in asali.
    //
    // a sarari, `minus` da `plus` ba za su iya zama sifili ba.(don rashin iyaka, muna amfani da ƙimar waje-waje.) kuma muna ɗauka cewa aƙalla lambobi ɗaya ne ke samarwa, ma'ana, `mant` ba zai iya zama sifili ba.
    //
    // wannan kuma yana nufin cewa kowane lamba tsakanin `low = (mant - minus)*2^exp` da `high = (mant + plus)* 2^exp` zasuyi taswira zuwa wannan lambar maki daidai, tare da hadaddun lokacin da asalin mantissa ya kasance (ma'ana, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` shine `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // kimanta `k_0` daga abubuwan asali na gamsarwa `10^(k_0-1) < high <= 10^(k_0+1)`.
    // an ƙididdige ƙuntataccen `k` mai gamsarwa `10^(k-1) < high <= 10^k` daga baya.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // maida `{mant, plus, minus} * 2^exp` zuwa siffar kason saboda haka:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // raba `mant` da `10^k`.yanzu `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // gyara lokacin `mant + plus > scale` (ko `>=`).
    // a zahiri ba ma gyara `scale`, tunda za mu iya tsallake narkarwar farko a maimakon haka.
    // yanzu `scale < mant + plus <= scale * 10` kuma a shirye muke don samar da lambobi.
    //
    // Lura cewa `d[0]`*na iya* zama sifili, lokacin da `scale - plus < mant < scale`.
    // a cikin wannan harka Ƙididdigar-up yanayin (`up` kasa) za a jawo nan da nan.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // yayi daidai da hawa `scale` ta 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // keɓaɓɓe `(2, 4, 8) * scale` don tsara ƙarni.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // mara iyaka, inda `d[0..n-1]` lambobi ne da aka samar har yanzu:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (don haka `mant / scale < 10`) inda `d[i..j]` taƙaitacciyar hanyar `` d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // samar da lamba daya: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // wannan shine saukakakken bayani game da gyangyadin Dragon algorithm.
        // yawancin tsaka-tsakin tsaka-tsakin abubuwa da kuma jayayya jayayya an tsallake don saukakawa.
        //
        // fara da canzawa mara canzawa, kamar yadda muka sabunta `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ɗauka cewa `d[0..n-1]` shine mafi ƙarancin wakilci tsakanin `low` da `high`, watau, `d[0..n-1]` ya gamsar da duka waɗannan masu biyowa amma `d[0..n-2]` baya:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: lambobi zagaye zuwa `v`);kuma
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (lambar ƙarshe ta yi daidai).
        //
        // yanayin na biyu ya sauƙaƙa zuwa `2 * mant <= scale`.
        // warware masu canzawa dangane da `mant`, `low` da `high` suna samar da saukakkiyar siga ta yanayin farko: `-plus < mant < minus`.
        // tun `-plus < 0 <= mant`, muna da mafi ƙanƙan wakilci lokacin da `mant < minus` da `2 * mant <= scale`.
        // (tsohon ya zama `mant <= minus` lokacin da ainihin mantissa ya kasance.)
        //
        // lokacin da na biyu bai riƙe ba (`` 2 * mant> sikelin ''), muna buƙatar ƙara lamba ta ƙarshe.
        // wannan ya isa don maido da wannan yanayin: mun riga mun san cewa tsararran lambobi sun tabbatar da `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // a wannan yanayin, yanayin farko ya zama `-plus < mant - scale < minus`.
        // tun `mant < scale` bayan ƙarni, muna da `scale < mant + plus`.
        // (kuma, wannan ya zama `scale <= mant + plus` lokacin da ainihin mantissa ya kasance.)
        //
        // a takaice:
        // - tsayawa da zagaye `down` (adana lambobi yadda yake) lokacin da `mant < minus` (ko `<=`).
        // - tsayawa da zagaye `up` (ƙara lambar ƙarshe) lokacin da `scale < mant + plus` (ko `<=`).
        // - ci gaba da samar da akasin haka.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // muna da mafi ƙarancin wakilci, ci gaba zuwa zagaye

        // mayar da marasa aiki.
        // wannan yana sa algorithm ya ƙare koyaushe: `minus` da `plus` koyaushe suna ƙaruwa, amma `mant` an yankakke modulo `scale` kuma an gyara `scale`.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // tarawa yana faruwa lokacin da) kawai yanayin haɓakawa ya jawo, ko ii) duka yanayin biyu sun jawo kuma ƙulla karya fifita abubuwan da aka fi so.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // idan tarawa ya canza tsawon, mai fitarwar shima ya canza.
        // da alama wannan yanayin yana da matukar wahala a gamsar dashi (mai yuwuwa ba zai yiwu ba), amma kawai muna cikin aminci da daidaito anan.
        //
        // KYAUTA: mun ƙaddamar da wannan ƙwaƙwalwar a sama.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // KYAUTA: mun ƙaddamar da wannan ƙwaƙwalwar a sama.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Tabbatacce kuma tsayayyen yanayin aiwatarwa don Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // kimanta `k_0` daga abubuwan asali na gamsarwa `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // raba `mant` da `10^k`.yanzu `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // gyara lokacin `mant + plus >= scale`, inda `plus / scale = 10^-buf.len() / 2`.
    // don kiyaye madaidaiciyar girman bignum, a zahiri muna amfani da `mant + floor(plus) >= scale`.
    // a zahiri ba ma gyara `scale`, tunda za mu iya tsallake narkarwar farko a maimakon haka.
    // sake tare da gajeren tsarin algorithm, `d[0]` na iya zama sifili amma daga ƙarshe za'a tattara shi.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // yayi daidai da hawa `scale` ta 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // idan muna aiki tare da iyakan lambar ƙarshe, muna buƙatar rage gajiya kafin ainihin ma'ana don kaucewa zagaye biyu.
    //
    // Lura cewa dole ne mu sake fadada abin adana lokacin tattara abubuwa ya faru!
    let mut len = if k < limit {
        // oops, ba za mu iya samar da lambobi *ɗaya* ba.
        // wannan yana yiwuwa idan, ka ce, mun sami wani abu kamar 9.5 kuma ana zagaye shi zuwa 10.
        // mun dawo da fanko mara amfani, banda shari'ar da ta biyo baya wanda ke faruwa yayin `k == limit` kuma dole ne ya samar da lamba daya daidai.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // keɓaɓɓe `(2, 4, 8) * scale` don tsara ƙarni.
        // (wannan na iya zama mai tsada, don haka kar a kirga su lokacin da fanfin fanko babu komai.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // bin lambobi duk sifiri ne, mun tsaya anan kar ayi * kar ayi kokarin zagayawa!maimakon haka, cika sauran lambobi.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // KYAUTA: mun ƙaddamar da wannan ƙwaƙwalwar a sama.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // Ƙididdigar up idan muka dakatar a tsakiyar lambobi idan da wadannan lambobi ne daidai 5000 ..., duba kafin lambar da kuma kokarin zagaye to ko da (ie, kauce wa Ƙididdigar up lokacin da kafin lambar ne ko da).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // KYAUTA: `buf[len-1]` an fara shi.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // idan tarawa ya canza tsawon, mai fitarwar shima ya canza.
        // amma an nemi takamaiman lambobi, don haka kar a canza abin da ake ajiyewa ...
        // KYAUTA: mun ƙaddamar da wannan ƙwaƙwalwar a sama.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... sai dai idan an nema mana madaidaiciyar madaidaiciya maimakon.
            // Har ila yau, muna buƙatar bincika wannan, idan asalin buffer ya kasance fanko, za a iya ƙara ƙarin lambar lokacin da `k == limit` (edge case).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // KYAUTA: mun ƙaddamar da wannan ƙwaƙwalwar a sama.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}