//! Mai ƙididdigar mai ba da labari.

/// Nemo `k_0` irin wannan `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Ana amfani da wannan don kimanta `k = ceil(log_10 (mant * 2^exp))`;
/// gaskiya `k` shine `k_0` ko `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits idan mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) sabili da haka wannan koyaushe yana yin la'akari (ko daidai ne), amma ba yawa ba.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}