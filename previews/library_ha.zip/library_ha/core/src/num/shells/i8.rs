//! Antsorewa don nau'in lamba-sa hannun 8-bit.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Sabuwar lamba yakamata yayi amfani da abubuwan haɗin da ke haɗe kai tsaye a kan nau'in zamanin.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }