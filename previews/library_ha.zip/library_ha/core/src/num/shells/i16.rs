//! Constorewa don nau'in lamba-sa hannun 16-bit.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Sabuwar lamba yakamata yayi amfani da abubuwan haɗin da ke haɗe kai tsaye a kan nau'in zamanin.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }