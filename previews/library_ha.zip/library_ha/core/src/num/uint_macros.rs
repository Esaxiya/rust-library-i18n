macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Ananan ƙimar da za'a iya wakilta ta wannan nau'in adadin.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Valueimar mafi girma da za a iya wakilta ta wannan nau'in adadin.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Girman wannan nau'in lamba a cikin ragowa.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Canza yanki yanki na kirtani a cikin asalin da aka bayar zuwa lamba.
        ///
        /// Ana sa ran zaren ya zama zaɓi na `+` na zaɓi biyo bayan lambobi.
        ///
        /// Jagoranci da bin bayan fili yana wakiltar kuskure.
        /// Lambobi rukuni ne na waɗannan haruffa, ya dogara da `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Wannan aikin panics idan `radix` baya cikin kewayon daga 2 zuwa 36.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Yana dawo da adadin su a cikin wakilcin binary na `self`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Ya dawo da adadin sifili a cikin wakilcin binary na `self`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Yana dawo da adadin manyan sifili a cikin wakilcin binary na `self`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Ya dawo da adadin sifili masu biyo baya a cikin wakilcin binary na `self`.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Ya dawo da adadin manyan a wakilcin binary na `self`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Ya dawo da adadin waɗanda ke tafe a cikin wakilcin binary na `self`.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Yana canza ragin zuwa hagu ta wani takamaiman adadin, `n`, yana nade abubuwan da aka yanke zuwa ƙarshen adadin da aka samu.
        ///
        ///
        /// Lura cewa wannan ba aiki iri ɗaya bane da mai canzawa na `<<`!
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Canja ragin zuwa hannun dama ta wani takamaiman adadin, `n`, yana nade ragowar da aka yanke zuwa farkon adadin da ya haifar.
        ///
        ///
        /// Lura cewa wannan ba aiki iri ɗaya bane da mai canzawa na `>>`!
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Ya juya tsarin baiti na adadin.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// bari m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Ya juyar da odar ragowa a cikin adadin.
        /// Mafi ƙarancin mahimmanci ya zama mafi mahimmanci mahimmanci, na biyu mafi ƙarancin mahimmanci ya zama na biyu mafi mahimmancin mahimmanci, da dai sauransu.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// bari m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Sake canza lamba daga babban endian zuwa endianness ɗin mai niyya.
        ///
        /// A kan babban endian wannan ba-op.
        /// A kan karamin endian ana canza bytes.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// idan cfg! (manufa_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } kuma {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Canza adadin daga ƙaramin endian zuwa endianness ɗin mai niyya.
        ///
        /// A kan ƙananan endian wannan ba-op.
        /// A kan babban endian ana canzawa bytes.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// idan cfg! (manufa_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } kuma {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Ya canza `self` zuwa babban endian daga maƙasudin maƙasudin.
        ///
        /// A kan babban endian wannan ba-op.
        /// A kan karamin endian ana canza bytes.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// idan cfg! (manufa_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } kuma { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ko ba zama ba?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Ya canza `self` zuwa ɗan endian daga maƙasudin maƙasudin.
        ///
        /// A kan ƙananan endian wannan ba-op.
        /// A kan babban endian ana canzawa bytes.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// idan cfg! (manufa_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } kuma { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Karin adadin lamba.
        /// Lissafi `self + rhs`, dawo da `None` idan ambaliyar ta faru.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Karin adadin lambaUtesididdiga `self + rhs`, idan aka ɗauki ambaliyar ba zata iya faruwa ba.
        /// Wannan yana haifar da halayyar da ba a bayyana ta ba lokacin da
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Nutsin lamba da aka duba.
        /// Lissafi `self - rhs`, dawo da `None` idan ambaliyar ta faru.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ragowar yawan adadin lamba.Utesididdiga `self - rhs`, idan aka ɗauki ambaliyar ba zata iya faruwa ba.
        /// Wannan yana haifar da halayyar da ba a bayyana ta ba lokacin da
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Ckedididdigar adadin lamba.
        /// Lissafi `self * rhs`, dawo da `None` idan ambaliyar ta faru.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ba a tantance yawan adadin lamba ba.Utesididdiga `self * rhs`, ɗauka zub da ruwa ba zai iya faruwa ba.
        /// Wannan yana haifar da halayyar da ba a bayyana ta ba lokacin da
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Rarraba adadin lamba.
        /// Lissafi `self / rhs`, dawowa `None` idan `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // KYAUTA: duba ta sifili an bincika a sama kuma nau'ikan da ba'a sanya hannu ba basu da sauran
                // gazawar halaye don rabo
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Binciken Euclidean.
        /// Lissafi `self.div_euclid(rhs)`, dawowa `None` idan `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Ragowar lamba ta rage.
        /// Lissafi `self % rhs`, dawowa `None` idan `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // KYAUTA: duba ta sifili an bincika a sama kuma nau'ikan da ba'a sanya hannu ba basu da sauran
                // gazawar halaye don rabo
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Duba Euclidean modulo.
        /// Lissafi `self.rem_euclid(rhs)`, dawowa `None` idan `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Duba rashin amincewa.Lissafi `-self`, dawowa `None` sai dai idan 'kai==
        /// 0`.
        ///
        /// Lura cewa yin watsi da kowane lamba mai kyau zai cika.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Duba matsawa hagu.
        /// Lissafin `self << rhs`, dawo da `None` idan `rhs` ya fi girma ko daidai da adadin ragowa a cikin `self`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Duba canzawa dama.
        /// Lissafin `self >> rhs`, dawo da `None` idan `rhs` ya fi girma ko daidai da adadin ragowa a cikin `self`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Duba ƙari.
        /// Lissafi `self.pow(exp)`, dawo da `None` idan ambaliyar ta faru.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // tun exp!=0, a ƙarshe dole ne exp ɗin ya zama 1.
            // Yi ma'amala da ƙarshen ƙarshe na mai fitarwar daban, tunda ƙwanƙwasa tushe daga baya ba shi da mahimmanci kuma yana iya haifar da ambaliyar da ba a buƙata.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Uraara adadin adadi.
        /// Ididdiga `self + rhs`, saturating a ƙididdigar lambobi maimakon ambaliyar.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Rarraba adadin lambobi.
        /// Ididdiga `self - rhs`, saturating a ƙididdigar lambobi maimakon ambaliyar.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Satarfafa adadin lambobi.
        /// Ididdiga `self * rhs`, saturating a ƙididdigar lambobi maimakon ambaliyar.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Uraarfafa adadin adadin.
        /// Ididdiga `self.pow(exp)`, saturating a ƙididdigar lambobi maimakon ambaliyar.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Raara (modular) ƙari.
        /// Utesididdiga `self + rhs`, kunsawa a iyakar nau'in.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Wrapping (modular) ragi.
        /// Utesididdiga `self - rhs`, kunsawa a iyakar nau'in.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Nadawa (modular) yawa.
        /// Utesididdiga `self * rhs`, kunsawa a iyakar nau'in.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// Lura cewa ana raba wannan misalin tsakanin nau'ikan lamba.
        /// Wanne ya bayyana dalilin da yasa ake amfani da `u8` a nan.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Ragewa (modular) rabo.Utesididdiga `self / rhs`.
        /// Raba rabo kan nau'ikan da ba'a sanya hannu ba daidai rabo ne na al'ada.
        /// Babu yadda za ayi kunsa ya taba faruwa.
        /// Wannan aikin ya wanzu, don haka ana lissafin duk ayyukan a cikin ayyukan nadewa.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Rage kungiyar Euclidean.Utesididdiga `self.div_euclid(rhs)`.
        /// Raba rabo kan nau'ikan da ba'a sanya hannu ba daidai rabo ne na al'ada.
        /// Babu yadda za ayi kunsa ya taba faruwa.
        /// Wannan aikin ya wanzu, don haka ana lissafin duk ayyukan a cikin ayyukan nadewa.
        /// Tunda, don tabbatattun lambobi, duk ma'anar rarrabuwa daidai take, wannan daidai yake da `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Raara (modular) saura.Utesididdiga `self % rhs`.
        /// Wididdigar ragowar lissafi akan nau'ikan da ba'a sanya hannu ba shine kawai ragowar lissafi na yau da kullun.
        ///
        /// Babu yadda za ayi kunsa ya taba faruwa.
        /// Wannan aikin ya wanzu, don haka ana lissafin duk ayyukan a cikin ayyukan nadewa.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Rage Euclidean modulo.Utesididdiga `self.rem_euclid(rhs)`.
        /// Wididdigar ƙirar ƙirar a kan nau'ikan da ba a sanya hannu ba shine kawai lissafin saura.
        /// Babu yadda za ayi kunsa ya taba faruwa.
        /// Wannan aikin ya wanzu, don haka ana lissafin duk ayyukan a cikin ayyukan nadewa.
        /// Tunda, don tabbatattun lambobi, duk ma'anar rarrabuwa daidai take, wannan daidai yake da `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Ragewa (modular) ƙi.
        /// Utesididdiga `-self`, kunsawa a iyakar nau'in.
        ///
        /// Tunda nau'ikan da ba sa hannun hannu ba su da daidaitattun kwatancen duk aikace-aikacen wannan aikin za su nade (ban da `-0`).
        /// Don ƙimomin da suka ƙasa da matsakaiciyar nau'in da aka sa hannu sakamakon ya yi daidai da jefa ƙimar daidai sa hannu.
        ///
        /// Duk wasu ƙimomi masu girma suna daidai da `MAX + 1 - (val - MAX - 1)` inda `MAX` shine madaidaicin nau'in sa hannu.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// Lura cewa ana raba wannan misalin tsakanin nau'ikan lamba.
        /// Wanne ya bayyana dalilin da yasa ake amfani da `i8` a nan.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-kyauta kaɗan sauyawa-hagu;
        /// ya samar da `self << mask(rhs)`, inda `mask` ya cire duk wani yanki mai tsada na `rhs` wanda zai haifar da sauyawa zuwa wucewar saurin nau'in.
        ///
        /// Lura cewa wannan ba * daidai yake da juya-hagu ba;RHS na juyawa-hagu an iyakance shi zuwa kewayon nau'in, maimakon ragin da aka canza daga LHS ana dawo dashi zuwa ƙarshen.
        /// Nau'in adadi na adadi duk suna aiwatar da aikin [`rotate_left`](Self::rotate_left), wanda yana iya zama abin da kuke so a maimakon haka.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // KIYAYEWA: kwalliyar da ake yi wa irin wannan yana tabbatar da cewa ba mu canzawa
            // wuce iyaka
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-kyauta sauyawa-dama-dama;
        /// ya samar da `self >> mask(rhs)`, inda `mask` ya cire duk wani yanki mai tsada na `rhs` wanda zai haifar da sauyawa zuwa wucewar saurin nau'in.
        ///
        /// Lura cewa wannan *ba* daidai yake da juya-daidai ba;RHS na sauyawa-dama an taƙaita shi zuwa kewayon nau'in, maimakon ragin da aka canza daga LHS ana mayar dashi zuwa ƙarshen.
        /// Nau'in adadi na adadi duk suna aiwatar da aikin [`rotate_right`](Self::rotate_right), wanda yana iya zama abin da kuke so a maimakon haka.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // KIYAYEWA: kwalliyar da ake yi wa irin wannan yana tabbatar da cewa ba mu canzawa
            // wuce iyaka
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Ragewa (modular) fadadawa.
        /// Utesididdiga `self.pow(exp)`, kunsawa a iyakar nau'in.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // tun exp!=0, a ƙarshe dole ne exp ɗin ya zama 1.
            // Yi ma'amala da ƙarshen ƙarshe na mai fitarwar daban, tunda ƙwanƙwasa tushe daga baya ba shi da mahimmanci kuma yana iya haifar da ambaliyar da ba a buƙata.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Yana kirga `self` + `rhs`
        ///
        /// Yana dawo da plearin additionarin tare da boolean yana nuna ko za a yi ambaliyar lissafi.
        /// Idan da an yi ambaliya zai faru to an dawo da darajar da aka nannade.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Yana kirga `self`, `rhs`
        ///
        /// Yana dawo da plean tsaga na cirewa tare da lean littafin yana nuna ko wani lissafi zai cika.
        /// Idan da an yi ambaliya zai faru to an dawo da darajar da aka nannade.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ana kirga yawan N01X da `rhs`.
        ///
        /// Yana dawo da plean riɓaɓɓanya na ninki biyu tare da alaƙa mai nuna ko ƙididdigar lissafi zai faru.
        /// Idan da an yi ambaliya zai faru to an dawo da darajar da aka nannade.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// Lura cewa ana raba wannan misalin tsakanin nau'ikan lamba.
        /// Wanne ya bayyana dalilin da yasa ake amfani da `u32` a nan.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Yana kirga mai rarraba lokacin da aka raba `self` da `rhs`.
        ///
        /// Ya dawo da plean tsaga mai rarrabuwa tare da lean wasa wanda ke nuna ko za ayi lissafin lissafi.
        /// Lura cewa don adadin da ba sa hannun sa hannu ya cika ba, don haka ƙima ta biyu koyaushe `false`.
        ///
        /// # Panics
        ///
        /// Wannan aikin zai panic idan `rhs` shine 0.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Yana kirga adadin divisionungiyar Euclidean `self.div_euclid(rhs)`.
        ///
        /// Ya dawo da plean tsaga mai rarrabuwa tare da lean wasa wanda ke nuna ko za ayi lissafin lissafi.
        /// Lura cewa don adadin da ba sa hannun sa hannu ya cika ba, don haka ƙima ta biyu koyaushe `false`.
        /// Tunda, don tabbatattun lambobi, duk ma'anar rarrabuwa daidai take, wannan daidai yake da `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Wannan aikin zai panic idan `rhs` shine 0.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Yana kirga ragowar lokacin da aka raba `self` da `rhs`.
        ///
        /// Ya dawo da pleayan ofan abin da ya saura bayan ya raba tare da lean bulean yana nuna ko za a yi ambaliyar lissafi.
        /// Lura cewa don adadin da ba sa hannun sa hannu ya cika ba, don haka ƙima ta biyu koyaushe `false`.
        ///
        /// # Panics
        ///
        /// Wannan aikin zai panic idan `rhs` shine 0.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Ya kirga sauran `self.rem_euclid(rhs)` kamar na Euclidean ne.
        ///
        /// Yana dawo da plean ƙirar modulo bayan ya rarraba tare da boolean yana nuna ko za a yi ambaliyar lissafi.
        /// Lura cewa don adadin da ba sa hannun sa hannu ya cika ba, don haka ƙima ta biyu koyaushe `false`.
        /// Tunda, don tabbatattun lambobi, duk ma'anar rarrabuwa daidai take, wannan aikin yayi daidai da `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Wannan aikin zai panic idan `rhs` shine 0.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Bata son kai a cikin yanayi mai cika ruwa.
        ///
        /// Ya dawo da `!self + 1` ta hanyar amfani da ayyukan kunsa don dawo da ƙimar da ke wakiltar ƙarancin wannan ƙimar da ba a sa hannu ba.
        /// Lura cewa don tabbatattun ƙa'idodin da ba'a sanya hannu ba suna faruwa koyaushe, amma ƙyamar 0 baya cikawa.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Sauya kai tsaye ta ragowa `rhs`.
        ///
        /// Ya dawo da plean kamannin jujjuyar juzu'in kai tare da booan littafin mai nuna ko ƙimar sauyawa ta fi girma ko daidai da adadin ragojin.
        /// Idan ƙimar sauyawa ta yi yawa, to ƙima an rufe mashi (N-1) inda N shine adadin ragowa, kuma ana amfani da wannan ƙimar don aiwatarwa.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Yana canza kai tsaye ta ragin `rhs`.
        ///
        /// Ya dawo da plean kamannin jujjuyar juzu'in kai tare da booan littafin mai nuna ko ƙimar sauyawa ta fi girma ko daidai da adadin ragojin.
        /// Idan ƙimar sauyawa ta yi yawa, to ƙima an rufe mashi (N-1) inda N shine adadin ragowa, kuma ana amfani da wannan ƙimar don aiwatarwa.
        ///
        /// # Examples
        ///
        /// Amfani na asali
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Raaukaka kai zuwa ikon `exp`, ta amfani da ƙari ta hanyar squaring.
        ///
        /// Yana dawo da plean tsada na adadin tare da bool yana nuna ko ambaliyar ta faru.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, gaskiya ne));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Spaceara sarari don adana sakamakon ambaliyar_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // tun exp!=0, a ƙarshe dole ne exp ɗin ya zama 1.
            // Yi ma'amala da ƙarshen ƙarshe na mai fitarwar daban, tunda ƙwanƙwasa tushe daga baya ba shi da mahimmanci kuma yana iya haifar da ambaliyar da ba a buƙata.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Raaukaka kai zuwa ikon `exp`, ta amfani da ƙari ta hanyar squaring.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // tun exp!=0, a ƙarshe dole ne exp ɗin ya zama 1.
            // Yi ma'amala da ƙarshen ƙarshe na mai fitarwar daban, tunda ƙwanƙwasa tushe daga baya ba shi da mahimmanci kuma yana iya haifar da ambaliyar da ba a buƙata.
            //
            //
            acc * base
        }

        /// Yi rarraba Euclidean.
        ///
        /// Tunda, don tabbatattun lambobi, duk ma'anar rarrabuwa daidai take, wannan daidai yake da `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Wannan aikin zai panic idan `rhs` shine 0.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Yana kirga ragowar ragowar `self (mod rhs)`.
        ///
        /// Tunda, don tabbatattun lambobi, duk ma'anar rarrabuwa daidai take, wannan daidai yake da `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Wannan aikin zai panic idan `rhs` shine 0.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Ya dawo `true` idan kuma idan `self == 2^k` na wasu `k`.
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Ya dawo daya kasa da na gaba mai iko biyu.
        // (Na 8u8 na gaba mai iko biyu shine 8u8 kuma na 6u8 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Wannan hanyar ba zata iya yin ambaliya ba, kamar yadda yake a cikin shari'o'in wuce gona da iri na `next_power_of_two` maimakon haka ya ƙare dawo da matsakaicin darajar nau'in, kuma zai iya dawo da 0 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // KYAUTA: Saboda `p > 0`, ba zai iya ƙunsar manyan siffofin ba.
            // Wannan yana nufin sauyawa koyaushe yana da iyaka, kuma wasu masu sarrafawa (kamar su intel pre-haswell) suna da ingantattun abubuwan ctlz mafi kyau yayin da gardamar ta kasance ba sifili.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Ya dawo da ƙarami mafi ƙarfi na biyu mafi girma ko daidai da `self`.
        ///
        /// Lokacin da darajar dawowa ta cika (watau, `self > (1 << (N-1))` na nau'in `uN`), shi panics a yanayin cire kuskure kuma ƙimar dawowa ta nannade zuwa 0 a cikin yanayin saki (yanayin da kawai hanya zata iya dawowa 0).
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Ya dawo da ƙarami mafi ƙarfi na biyu mafi girma ko daidai da `n`.
        /// Idan ƙarfin gaba na biyu ya fi girman ƙimar nau'in, `None` zai dawo, in ba haka ba ikon nan biyu ya nade cikin `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Ya dawo da ƙarami mafi ƙarfi na biyu mafi girma ko daidai da `n`.
        /// Idan ƙarfin gaba na biyu ya fi girman ƙimar nau'in, ƙimar dawowa ta nannade zuwa `0`.
        ///
        ///
        /// # Examples
        ///
        /// Amfani na asali:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Mayar da wakilcin ƙwaƙwalwar wannan lambar a matsayin tsararren baiti a cikin babban tsari mai girma (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Maido da wakilcin ƙwaƙwalwar wannan lambar a matsayin tsararren baiti a tsari kaɗan-kaɗan.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Maido da wakilcin ƙwaƙwalwar wannan lambar a matsayin tsararren baiti a tsarin baiti na asali.
        ///
        /// Kamar yadda ake amfani da asalin asalin dandamali na manufa, lambar da za a iya amfani da ita za ta yi amfani da [`to_be_bytes`] ko [`to_le_bytes`], kamar yadda ya dace, a maimakon haka.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, idan cfg! (manufa_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } kuma {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // KYAUTA: sauti ne saboda yawancin lambobi tsofaffin bayanan zamani ne saboda haka koyaushe zamu iya
        // musanya su zuwa tsararru na baiti
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // KYAUTA: lambobi ne tsofaffin bayanan zamani saboda haka koyaushe zamu iya canza su zuwa
            // tsararru na bytes
            unsafe { mem::transmute(self) }
        }

        /// Maido da wakilcin ƙwaƙwalwar wannan lambar a matsayin tsararren baiti a tsarin baiti na asali.
        ///
        ///
        /// [`to_ne_bytes`] ya kamata a fifita akan wannan a duk lokacin da zai yiwu.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// bari bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, idan cfg! (manufa_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } kuma {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // KYAUTA: lambobi ne tsofaffin bayanan zamani saboda haka koyaushe zamu iya canza su zuwa
            // tsararru na bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Irƙiri ƙimar lamba tsakanin enan asalin endian daga wakilcinta azaman baiti mai girma a babban endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// amfani da std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * labari=hutawa;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Createirƙiri ƙimar lamba na asalin ƙasar daga wakilcin ta azaman baiti a ƙaramin endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// amfani da std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * labari=hutawa;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Irƙiri ƙimar adadin adadi na asali daga wakilcin ƙwaƙwalwar ajiyarta azaman ƙididdigar byte a cikin asalin ƙasar.
        ///
        /// Yayinda ake amfani da asalin asalin dandamali na manufa, ƙaramar lamba mai yiwuwa tana son amfani da [`from_be_bytes`] ko [`from_le_bytes`], kamar yadda ya dace a maimakon haka.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } kuma {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// amfani da std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * labari=hutawa;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // KYAUTA: sauti ne saboda yawancin lambobi tsofaffin bayanan zamani ne saboda haka koyaushe zamu iya
        // transmute zuwa gare su
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // KYAUTA: lambobi ne tsofaffin bayanan zamani don haka koyaushe zamu iya canza musu hoto
            unsafe { mem::transmute(bytes) }
        }

        /// Sabon lamba ya kamata ya fi son amfani
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Ya dawo da ƙarami ƙimar da za'a iya wakilta ta wannan nau'in adadin.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Sabon lamba ya kamata ya fi son amfani
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Ya dawo mafi girman ƙimar da za'a iya wakilta ta wannan nau'in adadin.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}