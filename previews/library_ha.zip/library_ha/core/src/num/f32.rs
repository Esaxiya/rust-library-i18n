//! Specificayyadaddun abubuwan da ke daidai da nau'in ma'amala iri ɗaya na `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Ana bayar da lambobi masu mahimmanci na lissafi a cikin ƙananan ƙananan ƙananan `consts`.
//!
//! Ga masu daidaitaccen bayanin kai tsaye a cikin wannan rukunin (kamar yadda ya bambanta da waɗanda aka bayyana a cikin ƙananan ƙananan `consts`), sabon lambar ya kamata maimakon amfani da haɗin haɗin da aka bayyana kai tsaye akan nau'in `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix ko tushe na wakilcin ciki na `f32`.
/// Yi amfani da [`f32::RADIX`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // hanyar da aka nufa
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Adadin lambobi masu mahimmanci a cikin tushe 2.
/// Yi amfani da [`f32::MANTISSA_DIGITS`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // hanyar da aka nufa
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Kimanin adadin lambobi masu mahimmanci a cikin tushe 10.
/// Yi amfani da [`f32::DIGITS`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // hanyar da aka nufa
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] darajar `f32`.
/// Yi amfani da [`f32::EPSILON`] maimakon.
///
/// Wannan shine bambanci tsakanin `1.0` da lambar girma mai zuwa ta gaba.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // hanyar da aka nufa
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Mafi ƙarancin darajar `f32`.
/// Yi amfani da [`f32::MIN`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // hanyar da aka nufa
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Malaramar tabbatacciyar ƙimar `f32`.
/// Yi amfani da [`f32::MIN_POSITIVE`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // hanyar da aka nufa
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Iteimar `f32` mafi girma.
/// Yi amfani da [`f32::MAX`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // hanyar da aka nufa
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Greateraya mafi girma fiye da mafi ƙarancin ƙarfin ikon al'ada na 2 mai ba da haske.
/// Yi amfani da [`f32::MIN_EXP`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // hanyar da aka nufa
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Matsakaicin yuwuwar ikon 2 mai amfani.
/// Yi amfani da [`f32::MAX_EXP`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // hanyar da aka nufa
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Mafi qarancin yuwuwar ikon al'ada na mai fitar da 10.
/// Yi amfani da [`f32::MIN_10_EXP`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // hanyar da aka nufa
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Matsakaicin yuwuwar ikon mai fitar da 10.
/// Yi amfani da [`f32::MAX_10_EXP`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // hanyar da aka nufa
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ba Lambar (NaN) ba.
/// Yi amfani da [`f32::NAN`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // hanyar da aka nufa
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Yi amfani da [`f32::INFINITY`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // hanyar da aka nufa
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Finarancin mara kyau (−∞).
/// Yi amfani da [`f32::NEG_INFINITY`] maimakon.
///
/// # Examples
///
/// ```rust
/// // hanya mara kyau
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // hanyar da aka nufa
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Basic lissafi constants.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: maye gurbinsu da daidaitattun lissafi daga cmath.

    /// Archimedes 'akai (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Cikakken da'irar akai (τ)
    ///
    /// Daidaita zuwa 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Lambar Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Radix ko tushe na wakilcin ciki na `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Adadin lambobi masu mahimmanci a cikin tushe 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Kimanin adadin lambobi masu mahimmanci a cikin tushe 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] darajar `f32`.
    ///
    /// Wannan shine bambanci tsakanin `1.0` da lambar girma mai zuwa ta gaba.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Mafi ƙarancin darajar `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Malaramar tabbatacciyar ƙimar `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Iteimar `f32` mafi girma.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Greateraya mafi girma fiye da mafi ƙarancin ƙarfin ikon al'ada na 2 mai ba da haske.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Matsakaicin yuwuwar ikon 2 mai amfani.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Mafi qarancin yuwuwar ikon al'ada na mai fitar da 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Matsakaicin yuwuwar ikon mai fitar da 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ba Lambar (NaN) ba.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Finarancin mara kyau (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Yana dawowa `true` idan wannan ƙimar `NaN` ce.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Ba a samo `abs` a bayyane a cikin libcore ba saboda damuwar da ake nunawa, don haka wannan aiwatarwa don amfani ne na sirri a ciki.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Yana dawowa `true` idan wannan ƙimar tabbatacciya mara iyaka ce ko mara kyau mara kyau, kuma `false` in ba haka ba.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Yana dawowa `true` idan wannan lambar bata da iyaka ko kuma `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Babu buƙatar ɗaukar NaN daban: idan kai NaN ne, kwatancen ba gaskiya bane, daidai yadda ake so.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Yana dawo da `true` idan lambar ta kasance [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Imomi tsakanin `0` da `min` sune norananan.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Yana dawo da `true` idan lambar ba sifili bace, mara iyaka, [subnormal], ko `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Imomi tsakanin `0` da `min` sune norananan.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Ya dawo da rukunin fili na lambar.
    /// Idan za a gwada dukiya guda ɗaya kawai, to ya fi sauri amfani da takamaiman abin da aka ambata a maimakon haka.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Yana dawo da `true` idan `self` yana da kyakkyawar alama, gami da `+0.0`, `` NaN's tare da alamar tabbatacciya da ƙarancin iyaka.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Yana dawo da `true` idan `self` yana da alamar mara kyau, gami da `-0.0`, `` NaN's tare da alamar mara kyau mara kyau da rashin iyaka.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 yana cewa: isSignMinus(x) gaskiya ne idan kuma kawai idan x yana da alamar mara kyau.
        // isSignMinus ya shafi sifili da NaNs ma.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Xauki (inverse) na lamba na lamba, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Sabobin tuba zuwa digiri.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Yi amfani da madaidaici don mafi daidaito.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Sabobin tuba zuwa radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Yana dawo da iyakar lambobin biyu.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Idan ɗayan hujjojin NaN ne, to an dawo da ɗayan gardamar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Ya dawo da ƙaramar lambobin biyu.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Idan ɗayan hujjojin NaN ne, to an dawo da ɗayan gardamar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Zagayewa zuwa sifili kuma ya canza zuwa kowane nau'in lamba mai mahimmanci, ɗauka cewa ƙimar ta ƙayyade kuma ta dace da wannan nau'in.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Mustimar dole ne:
    ///
    /// * Ba zama `NaN` ba
    /// * Ba iyaka
    /// * Kasance mai wakilci a cikin nau'in dawowa na `Int`, bayan yanke ɓangaren ɓangarenta
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutation zuwa `u32`.
    ///
    /// Wannan a halin yanzu yayi daidai da `transmute::<f32, u32>(self)` akan duk dandamali.
    ///
    /// Duba `from_bits` don tattaunawa game da damar wannan aikin (kusan babu matsala).
    ///
    /// Lura cewa wannan aikin ya banbanta da simintin `as`, wanda ke ƙoƙarin adana ƙimar *adadi*, kuma ba ƙimar ƙimar ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ba jingina!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // KYAUTA: `u32` tsohuwar datatype ce don haka koyaushe zamu iya juya ta zuwa gare shi
        unsafe { mem::transmute(self) }
    }

    /// Raw transmutation daga `u32`.
    ///
    /// Wannan a halin yanzu yayi daidai da `transmute::<u32, f32>(v)` akan duk dandamali.
    /// Ya bayyana cewa wannan yana da sauki šaukuwa, saboda dalilai biyu:
    ///
    /// * Fulawa da Ints suna da yanayi iri ɗaya a duk dandamali masu goyan baya.
    /// * IEEE-754 takamaimai yake tsara tsarin shimfidar ruwa.
    ///
    /// Koyaya akwai faɗakarwa guda ɗaya: kafin samfurin 2008 na IEEE-754, yadda ake fassara sign siginar NaN ba a bayyana takamamme ba.
    /// Yawancin dandamali (musamman x86 da ARM) sun ɗauki fassarar da aka daidaita ta ƙarshe a cikin 2008, amma wasu ba su (musamman MIPS).
    /// Sakamakon haka, duk alamun NaNs akan MIPS ba NaNs marasa nutsuwa akan x86, kuma akasin haka.
    ///
    /// Maimakon ƙoƙarin adana siginar-giciye-dandamali, wannan aiwatarwar tana son adana ainihin abubuwan.
    /// Wannan yana nufin cewa duk wani tsarin biyan kudi da aka sanya a cikin NaNs za'a kiyaye koda kuwa sakamakon wannan hanyar an aika shi akan hanyar sadarwa daga inji x86 zuwa na MIPS.
    ///
    ///
    /// Idan sakamakon wannan hanyar ta hanyar gine-ginen da ya samar da su ne kawai yake sarrafa su, to babu wata damuwa ta kai komo.
    ///
    /// Idan shigarwar ba NaN bane, to babu damuwa game da ɗaukar hoto.
    ///
    /// Idan baku damu da sigina ba (mai yuwuwa), to babu damuwa game da sigina.
    ///
    /// Lura cewa wannan aikin ya banbanta da simintin `as`, wanda ke ƙoƙarin adana ƙimar *adadi*, kuma ba ƙimar ƙimar ba.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // KYAUTA: `u32` tsohuwar dataty ce kawai don haka zamu iya jujjuyashi daga gareshi
        // Ya nuna cewa batutuwan tsaro tare da sNaN sun wuce gona da iri!Wayyo!
        unsafe { mem::transmute(v) }
    }

    /// Mayar da wakilcin ƙwaƙwalwar ajiyar wannan lambar lamba a matsayin tsararren baiti a cikin babban-endian (network) byte tsari.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Mayar da wakilcin ƙwaƙwalwar ajiyar wannan lambar lamba a matsayin tsararren baiti a cikin tsari kaɗan-kaɗan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Maido da wakilcin ƙwaƙwalwar ajiyar wannan lambar shawagi a matsayin tsararren baiti a tsarin baiti na asali.
    ///
    /// Kamar yadda ake amfani da asalin asalin dandamali na manufa, lambar da za a iya amfani da ita za ta yi amfani da [`to_be_bytes`] ko [`to_le_bytes`], kamar yadda ya dace, a maimakon haka.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Maido da wakilcin ƙwaƙwalwar ajiyar wannan lambar shawagi a matsayin tsararren baiti a tsarin baiti na asali.
    ///
    ///
    /// [`to_ne_bytes`] ya kamata a fifita akan wannan a duk lokacin da zai yiwu.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // KYAUTA: `f32` tsohuwar datatype ce don haka koyaushe zamu iya juya ta zuwa gare shi
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Createirƙiri darajar ma'amala daga wakilcinta azaman kayan baiti a babban endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Createirƙiri ƙimar ma'amala daga wakilcinta azaman kayan baiti a ƙaramin endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Createirƙiri darajar ma'amala daga wakilcinta azaman kayan baiti a asalin ƙasar endian.
    ///
    /// Yayinda ake amfani da asalin asalin dandamali na manufa, ƙaramar lamba mai yiwuwa tana son amfani da [`from_be_bytes`] ko [`from_le_bytes`], kamar yadda ya dace a maimakon haka.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Ya dawo da oda tsakanin kai da wasu ƙimomin.
    /// Ba kamar daidaitaccen kwatancen kwatankwacin lambobin maki mai shawagi ba, wannan kwatancen koyaushe yana samar da odar daidai da jimlar odar umarni kamar yadda aka bayyana a cikin IEEE 754 (bita ta 2008) daidaitaccen maki.
    /// Ana ba da umarnin ƙimar ƙa'idodi masu zuwa:
    /// - Mara kyau shuru NaN
    /// - Sigina mara kyau
    /// - Inarancin mara kyau
    /// - Lambobi marasa kyau
    /// - Lambobi marasa kyau na al'ada
    /// - Mara kyau sifili
    /// - Tabbatacce sifili
    /// - Lambobi marasa kyau na yau da kullun
    /// - Lambobi masu kyau
    /// - Tabbatacce mara iyaka
    /// - Sigina mai kyau NaN
    /// - Na'am mai kyau NaN
    ///
    /// Lura cewa wannan aikin koyaushe baya yarda da aiwatarwar [`PartialOrd`] da [`PartialEq`] na `f32`.Musamman, suna ɗaukar mummunan da sifili mai kyau kamar daidai, yayin da `total_cmp` ba ya ɗauka.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Idan ya kasance mara kyau, juya duk ragowar sai dai alamar don cimma daidaitaccen tsari azaman cikakkun masu haɗa lamba biyu
        //
        // Me yasa wannan yake aiki?IEEE 754 shawagi ya kunshi filaye uku:
        // Shiga bit, mai nunawa da mantissa.Saitin masu bayyanawa da filayen mantissa gabaɗaya suna da dukiyar cewa odar su kaɗan daidai take da lambar adadi inda aka bayyana girman.
        // Ba a bayyana girman a kan ƙimar NaN ba, amma IEEE 754 totalOrder yana ƙayyade ƙimar NaN ɗin kuma don bin ƙa'idodin kaɗan.Wannan yana haifar da oda da aka bayyana a cikin sharhin doc.
        // Koyaya, wakilcin girma daidai yake da lambobi marasa kyau da tabbatacce-kawai alamar alamar ta bambanta.
        // Don sauƙaƙe abubuwan hawa a matsayin lambobi da aka sanya hannu, muna buƙatar jujjuya ɓangaren da kuma mantissa rago idan akwai lambobi marasa kyau.
        // Mun canza lambobin yadda yakamata zuwa nau'in "two's complement".
        //
        // Don yin jujjuyawar, zamu gina maski da XOR akan sa.
        // Muna yin lissafin abin rufe fuska na "all-ones except for the sign bit" daga ƙimomin da aka sanya hannu a kan sa hannun dama: sa hannun dama yana faɗaɗa lambar, don haka muke "fill" mask ɗin tare da alamun alamar, sannan mu juya zuwa wanda ba a sa hannu ba don tura ƙarin sifili ɗaya.
        //
        // A kan kyawawan dabi'u, abin rufe fuska ba komai, don haka ba komai bane.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Untata ƙima zuwa wani tazara sai dai idan NaN ne.
    ///
    /// Dawowa `max` idan `self` ya fi `max` girma, kuma `min` idan `self` bai kai `min` ba.
    /// In ba haka ba wannan ya dawo `self`.
    ///
    /// Lura cewa wannan aikin yana dawo da NaN idan ƙimar farko ta kasance NaN kuma.
    ///
    /// # Panics
    ///
    /// Panics idan `min > max`, `min` NaN ne, ko `max` NaN ne.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}