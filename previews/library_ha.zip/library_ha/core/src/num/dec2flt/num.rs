//! Ayyuka masu amfani don bignums waɗanda basu da ma'ana da yawa don juya cikin hanyoyin.

// FIXME Sunan wannan rukunin ya ɗan ɓata rai, tunda sauran matakan suma suna shigo da `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Gwada ko yanke duk ƙananan ragin ƙasa da `ones_place` yana gabatar da kuskuren dangi ƙasa, daidai, ko mafi girma fiye da 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Idan duk sauran ragowar basu sifiri ba, to= 0.5 ULP ne, in ba haka ba> 0.5 Idan babu sauran ragowa (half_bit==0), na ƙasa shima ya dawo daidai.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Sabobin zaren ASCII wanda yake dauke da adadi goma kawai zuwa `u64`.
///
/// Ba ya yin bincike game da ambaliyar ko haruffa marasa inganci, don haka idan mai kiran bai yi hankali ba, sakamakon ya zama na bogi kuma zai iya panic (duk da cewa ba zai zama `unsafe` ba).
/// Bugu da ƙari, ana kula da kirtani mara kyau azaman sifili.
/// Wannan aikin ya wanzu saboda
///
/// 1. amfani da `FromStr` akan `&[u8]` yana buƙatar `from_utf8_unchecked`, wanda ba shi da kyau, kuma
/// 2. hada abubuwa sakamakon `integral.parse()` da `fractional.parse()` yafi rikitarwa fiye da wannan aikin gaba daya.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Sabobin da wani nau'in lambar ASCII a cikin bignum.
///
/// Kamar `from_str_unchecked`, wannan aikin ya dogara da na'urar fassarar don cire lambar da ba lamba ba.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Cire zane a cikin adadin 64 kaɗan.Panics idan lambar tayi yawa.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Cire 'yan kewayon ragowa.

/// Fihirisa 0 ce mafi ƙarancin mahimmanci kuma zangon yana buɗe rabi kamar yadda aka saba.
/// Panics idan aka nemi cire karin rago fiye da dacewa da nau'in dawowa.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}