//! Daban-daban algorithms daga takarda.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Adadin mahimmin ragowa a cikin Fp
const P: u32 = 64;

// Muna kawai adana mafi kyawun kusanci ga *duk* masu bayyanawa, don haka za'a iya tsallake mai canzawa "h" da yanayin haɗi.
// Wannan cinikin yana yin kilogram guda biyu na sarari.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// A mafi yawan gine-ginen gine-ginen, ayyukan nuna ruwa suna da girman girman bayyane, sabili da haka ƙididdigar lissafi ana ƙaddara ne bisa tsarin aiki.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// A kan x86, ana amfani da x87 FPU don ayyukan shawagi idan ba a sami kari na SSE/SSE2 ba.
// x87 FPU yana aiki tare da rarar 80 na daidaito ta tsoho, wanda ke nufin cewa ayyukan za su zagaye zuwa 80 ragowa wanda zai haifar da zagaye biyu don faruwa yayin da aka wakilci ƙimomi kamar
//
// 32/64 bit tasowa dabi'u.Don shawo kan wannan, ana iya saita kalmar sarrafa FPU ta yadda za a yi lissafi a daidaitaccen abin da ake so.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Tsarin da aka yi amfani dashi don adana asalin asalin kalmar sarrafa FPU, don haka za'a iya dawo da shi lokacin da aka sauke tsarin.
    ///
    ///
    /// x87 FPU rajista ce mai ragowa 16 wacce filayenta kamar haka:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Ana samun takaddun dukkan filayen a cikin Manhajar Mai Haɓaka Software na IA-32 Architectures Software (Volume 1).
    ///
    /// Filin da kawai ya dace da lambar mai zuwa shine PC, Precision Control.
    /// Wannan filin yana ƙayyade daidaitattun ayyukan da FPU ke yi.
    /// Ana iya saita shi zuwa:
    ///  - 0b00, daidaitaccen daidaito watau, 32-ragowa
    ///  - 0b10, madaidaicin madaidaici watau, 64-ragowa
    ///  - 0b11, madaidaicin madaidaici watau, 80-ragowa (yanayin tsoho) Theimar 0b01 an adana kuma bai kamata ayi amfani da ita ba.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // KYAUTA: an binciki umarnin `fldcw` don iya aiki daidai da
        // kowane `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Muna amfani da rubutun ATT don tallafawa LLVM 8 da LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Ya sanya madaidaiciyar filin FPU zuwa `T` kuma ya dawo da `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Yi lissafin ƙimar don filin Tabbatar da daidaito wanda ya dace da `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 ragowa
            8 => 0x0200, // 64 ragowa
            _ => 0x0300, // tsoho, 80 ragowa
        };

        // Sami asalin asalin kalmar sarrafawa don dawo da ita daga baya, lokacin da aka watsar da tsarin `FPUControlWord` KYAUTA: ana bincikar koyarwar `fnstcw` don samun damar yin aiki daidai da kowane `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Muna amfani da rubutun ATT don tallafawa LLVM 8 da LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Saita kalmar sarrafawa zuwa daidaiton da ake so.
        // Ana samun wannan ta hanyar ɓoye tsohuwar ƙima (ragowa 8 da 9, 0x300) da maye gurbin ta da madaidaicin tutar da aka lissafa a sama.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Hanyar sauri ta Bellerophon ta amfani da adadi mai yawa na inji da iyo.
///
/// Ana cire wannan a cikin wani keɓaɓɓen aiki don haka za a iya ƙoƙarinta kafin gina bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Muna kwatanta ainihin darajar zuwa MAX_SIG kusa da ƙarshen, wannan kawai sauri ne, mai ƙin yarda (kuma yana 'yantar da sauran lambar daga damuwa da ambaliyar ruwa).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Hanyar sauri mai mahimmanci ya dogara da lissafin lissafin zuwa adadin adadin ragowa ba tare da wani tsaka-tsakin zagaye ba.
    // A kan x86 (ba tare da SSE ko SSE2 ba) wannan yana buƙatar madaidaicin madaidaicin ɗakunan x87 FPU don canzawa kai tsaye zuwa bitar 64/32.
    // Aikin `set_precision` yana kula da saita madaidaiciya akan gine-ginen da ke buƙatar saita shi ta hanyar sauya yanayin duniya (kamar kalmar sarrafawa ta x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Batun e <0 ba za a iya ninke shi zuwa cikin sauran branch ba.
    // Ikon mara kyau yana haifar da sake maimaita juzu'i a cikin binary, waɗanda aka zagaye, wanda ke haifar da hakikanin (kuma wani lokacin mahimmin abu ne!) Kuskure a sakamakon ƙarshe.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon lambar mara amfani ce da aka tabbatar ta hanyar binciken ƙididdiga mara ƙima.
///
/// Yana zagaye `` f '' zuwa ga shawagi mai ma'ana 64 kuma yana ninka shi ta mafi kyaun kusancin `10^e` (a cikin yanayin mahimmin iyo).Wannan ya isa sau da yawa don samun sakamako daidai.
/// Koyaya, lokacin da sakamakon ya kusa zuwa tsakanin rabin ruwan dake kusa da (ordinary), kuskuren hadewar fili daga ninka kusan biyu yana nufin sakamakon na iya kashe ta yan yan kadan.
/// Lokacin da wannan ya faru, Algorithm R na canzawa yana gyara abubuwa sama.
///
/// Hannun hannu-wavy "close to halfway" an yi shi daidai ta hanyar nazarin adadi a cikin takarda.
/// A cikin kalmomin Clinger:
///
/// > Slop, wanda aka bayyana a cikin raka'a mafi mahimmanci kaɗan, yana da cikakkiyar iyaka ga kuskure
/// > tarawa a yayin lissafin maki na kusan zuwa f * 10 ^ e.(Slop ne
/// > ba a ɗaure don kuskuren gaskiya ba, amma yana da bambanci tsakanin kusancin z da
/// > mafi kyawun kimantawa wanda ke amfani da raunin rami mai mahimmanci.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Shari'ar abs(e) <log5(2^N) suna cikin fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Shin gangaren ya isa ya kawo canji lokacin zagawa zuwa n ragowa?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Tsarin lissafi wanda ke inganta kusancin maki na `f * 10^e`.
///
/// Kowane ɗawainiya yana samun raka'a ɗaya a wuri na ƙarshe kusa, wanda tabbas yana ɗaukar tsayi mai yawa don haɗuwa idan `z0` ya kasance a hankali.
/// Sa'ar al'amarin shine, lokacin da aka yi amfani dashi azaman baya ga Bellerophon, kusancin farawa yana kashe ta akasari ULP ɗaya.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Nemi lambobi masu kyau `x`, `y` kamar `x / y` daidai yake `(f *10^e) / (m* 2^k)`.
        // Wannan ba kawai yana guje ma'amala da alamun `e` da `k` ba, muna kuma kawar da ikon abubuwa biyu na kowa zuwa `10^e` da `2^k` don sanya ƙananan lambobin.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // An rubuta wannan ɗan wahala saboda ƙananan mu ba sa goyan bayan lambobi marasa kyau, don haka muke amfani da cikakken darajar alamar alamar.
        // Licationara tare da m_digits ba za ta iya malalowa ba.
        // Idan `x` ko `y` suna da girma wanda yakamata mu damu da ambaliyar, to suma sunada girma da `make_ratio` ya rage kaso ta hanyar ^ 64 ko fiye.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Kada ku sake buƙatar x, adana clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Har yanzu ana buƙatar y, yi kwafi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Idan aka ba `x = f` da `y = m` inda `f` ke wakiltar lambobin shigar da lambobi kamar yadda aka saba kuma `m` shine mahimmancin kusancin maki mai iyo, sanya ragin `x / y` daidai da `(f *10^e) / (m* 2^k)`, mai yuwuwa an rage ta da ƙarfi biyu duka suna da juna.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, sai dai kawai mun rage rabe-raben da wasu karfin biyu.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Wannan ba zai iya yin ambaliya ba saboda yana buƙatar tabbatacce `e` da mara kyau `k`, wanda kawai zai iya faruwa ne don ƙimar kusan kusan 1, wanda ke nufin cewa `e` da `k` za su kasance ƙananan kaɗan.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Wannan ma ba zai iya malala ba, duba sama.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), sake ragewa ta hanyar iko na mutane biyu.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// A fahimta, Algorithm M ita ce hanya mafi sauki don sauya adadi zuwa shawagi.
///
/// Muna kirkirar rabo wanda yayi daidai da `f * 10^e`, sa'annan mu jefa a iko biyu har sai ya bada ma'ana ta ruwa mai inganci.
/// Yanayin binaryar `k` shine adadin lokutan da muka ninka numerator ko denominator da biyu, watau, a kowane lokaci `f *10^e` yayi daidai da `(u / v)* 2^k`.
/// Lokacin da muka gano mahimmanci, kawai zamu buƙaci zagaye ta hanyar bincika ragowar ɓangaren, wanda aka yi cikin ayyukan taimako a ƙasa.
///
///
/// Wannan algorithm din yana da jinkiri sosai, koda tare da ingantawa wanda aka bayyana a cikin `quick_start()`.
/// Koyaya, shine mafi sauƙi daga cikin algorithms ɗin don daidaitawa don ambaliya, ambaliyar ruwa, da ƙananan sakamako.
/// Wannan aiwatarwar ya ɗauki lokacin da Bellerophon da Algorithm R suka mamaye.
/// Gano ambaliyar ruwa da ambaliyar abu ne mai sauƙi: Rukunin har yanzu ba shi da mahimmancin kewayo, amma har yanzu an kai ga mai nuna minimum/maximum.
/// Game da ambaliyar ruwa, kawai zamu dawo mara iyaka.
///
/// Gudanar da ambaliyar ruwa da ƙananan abubuwa suna da wahala.
/// Babbar matsala guda ɗaya ita ce, tare da ƙaramar mai bayyanawa, ƙimar har yanzu tana da girma don mahimmanci.
/// Duba underflow() don cikakkun bayanai.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME mai yiwuwa ingantawa: gama gari big_to_fp domin muyi daidai da fp_to_float(big_to_fp(u)) a nan, kawai ba tare da zagaye biyu ba.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Dole ne mu tsaya a mafi karancin mai fitar da kaya, idan muka jira har zuwa `k < T::MIN_EXP_INT`, to da mun wuce kashi biyu kenan.
            // Abun takaici wannan yana nufin dole ne mu keɓance lambobi na yau da kullun tare da ƙaramar mai magana.
            // FIXME ya sami mafi kyawun tsari, amma gudanar da gwajin `tiny-pow10` don tabbatar da cewa daidai yake!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Tsallake kan mafi yawan maganganun Algorithm M ta hanyar duba ɗan tsayin.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Lengthan ɗan kaɗan ƙididdigar tushe ne na logarithm, kuma log(u / v) = log(u), log(v).
    // Isididdigar ta kashe a mafi akasari 1, amma koyaushe ƙarancin kimantawa ne, saboda haka kuskure akan log(u) da log(v) suna da alamar iri ɗaya kuma sun soke (idan dukansu babba ne).
    // Saboda haka kuskure don log(u / v) galibi ɗaya ne.
    // Matsayin makasudi shine ɗayan da u/v ke cikin maɓallin kewayawa.Don haka yanayin ƙarewarmu shine log2(u / v) kasancewa mai mahimmancin ragowa, plus/minus ɗaya.
    // FIXME Idan aka kalli bit na biyu na iya inganta kimantawa kuma a guji wasu ƙarin rarrabuwa.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Flowarɓar ruwa ko al'ada.Bar shi zuwa babban aiki.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // ZuwaBar shi zuwa babban aiki.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ratio ba mahimmanci ne a cikin kewayon tare da ƙaramar mai fitar da shi ba, don haka muna buƙatar ƙididdige rarar wuce gona da iri tare da daidaita mai bayyana shi daidai.
    // Hakikanin darajar yanzu tana kama da wannan:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(wakiltar rem)
    //
    // Sabili da haka, lokacin da ragin da aka zagaya ya kasance!= 0.5 ULP, suna yanke shawarar zagayen da kansu.
    // Lokacin da suke daidai kuma abin da ya rage ba sifili ba ne, ƙimar har yanzu tana buƙatar haɗawa.
    // Sai kawai lokacin da ragowar abubuwan da aka ƙaddara sune 1/2 kuma ragowar ba sifili, muna da rabin-har ma halin da ake ciki.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Taron zagaye-zuwa-ko da, obfuscated ta hanyar yin zagaye dangane da ragowar rabo.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}