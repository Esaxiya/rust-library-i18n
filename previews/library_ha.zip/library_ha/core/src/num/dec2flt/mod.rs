//! Ana canza igiyoyin adadi zuwa lambobin ma'amala na bin IEEE 754.
//!
//! # Bayanin matsala
//!
//! An bamu kirtani na goma kamar `12.34e56`.
//! Wannan kirtani ya kunshi (`12`) mai hadewa, da kashi-kashi (`34`), da kuma wadanda ke fitar da sassan (`56`).Duk sassan zaɓi ne kuma ana fassara su azaman sifiri lokacin ɓacewa.
//!
//! Muna neman lambar IEEE 754 mai iyo wacce ke kusa da ainihin ƙimar faya-fayel.
//! Sanannen abu ne cewa yawancin igiyoyin goma ba su da wakilcin karewa a tushe na biyu, saboda haka muna zagaye zuwa raka'o'in 0.5 a wuri na ƙarshe (a wata ma'anar, haka kuma mai yiwuwa).
//! Iesulla, ƙayyadaddun ƙayyadaddun lambobi daidai rabin-tsaka-tsakin tsakanin biranen ruwa guda biyu a jere, ana warware su ta hanyar dabarun rabin-har ma, wanda kuma aka sani da zagayen banki.
//!
//! Ba lallai ba ne a faɗi, wannan yana da wuya sosai, a game da ƙwarewar aiwatarwa da kuma cikin ma'anar hawan CPU da aka ɗauka.
//!
//! # Implementation
//!
//! Na farko, muna watsi da alamu.Ko kuma a'a, mun cire shi a farkon farkon aikin juyawa kuma sake amfani da shi a ƙarshen.
//! Wannan daidai ne a duk shari'o'in edge tunda abubuwan hawa na IEEE suna daidaitawa game da sifili, ƙyama ɗaya kawai zai juye farkon.
//!
//! Sa'annan zamu cire ma'anar adadi ta hanyar daidaitawa mai nunawa: A fahimta, `12.34e56` ya juya zuwa `1234e54`, wanda muke bayyana shi da lamba mai lamba `f = 1234` da lamba `e = 54`.
//! Ana amfani da wakilcin `(f, e)` kusan dukkanin lambar da ta wuce matakin ɓoyewa.
//!
//! Daga nan sai mu gwada dogon layi na ci gaba mafi girma da tsada na musamman ta amfani da adadi na inji da ƙarami, lambobi masu tsattsauran ra'ayi (farkon `f32`/`f64`, sannan nau'in da ke da ma'ana 64 kaɗan, `Fp`).
//!
//! Lokacin da duk waɗannan suka kasa, sai mu ciji harsashin kuma muyi amfani da sauƙi mai sauƙi amma mai saurin jinkiri wanda ya haɗa da ƙididdigar `f * 10^e` sosai da yin bincike mai sassauƙa don mafi kyawun kimantawa.
//!
//! Ainihi, wannan tsarin da ɗanta suna aiwatar da algorithms ɗin da aka bayyana a:
//! "How to Read Floating Point Numbers Accurately" na William D.
//! Clinger, akwai akan layi: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Bugu da kari, akwai ayyuka masu taimako da yawa da ake amfani da su a cikin takarda amma babu su a cikin Rust (ko kuma aƙalla a cikin ainihin).
//! Versionab'inmu yana da ƙari tare da buƙatar ɗaukar ambaliyar ruwa da ambaliyar ruwa da kuma sha'awar ɗaukar lambobi marasa kyau.
//! Bellerophon da Algorithm R suna da matsala tare da ambaliyar ruwa, ƙananan abubuwa, da ambaliyar ruwa.
//! Mun canza sheka zuwa Algorithm M (tare da gyare-gyaren da aka bayyana a sashe na 8 na takarda) da kyau kafin abubuwan shiga su shiga cikin yankin mai mahimmanci.
//!
//! Wani yanayin da ke buƙatar kulawa shi ne `` RawFloat '' trait wanda kusan duk ayyukan ke tsara shi.Mutum na iya tunanin cewa ya isa ya bugu zuwa `f64` kuma ya jefa sakamakon zuwa `f32`.
//! Abin takaici wannan ba duniyar da muke rayuwa a ciki ba, kuma wannan ba shi da alaƙa da amfani da tushe zagaye biyu ko rabi-har ma da zagaye.
//!
//! Yi la'akari da misali iri biyu `d2` da `d4` waɗanda ke wakiltar nau'in adadi tare da lambobi goma da goma lambobi goma kowannensu kuma ɗauki "0.01499" azaman shigarwa.Bari muyi amfani da rabi-rabi.
//! Tafiya kai tsaye zuwa lambobi goma na bada `0.01`, amma idan muka fara zagaye zuwa huɗu na farko, zamu sami `0.0150`, wanda aka zagaya zuwa `0.02`.
//! Wannan ƙa'idar ta shafi sauran ayyukan kuma, idan kuna son daidaiton 0.5 ULP kuna buƙatar yin *komai* a cikakke madaidaiciya kuma zagaye *daidai sau ɗaya, a ƙarshen*, ta hanyar yin la'akari da duk ragin da aka yanke lokaci ɗaya.
//!
//! FIXME: Kodayake wasu narkar da lambar ya zama dole, wataƙila ana iya haɗa sassan ɓangaren lambar ta yadda za a maimaita ƙaramar lambar.
//! Partsananan ɓangarorin algorithms sun kasance masu zaman kansu daga nau'in jirgi don fitarwa, ko kawai yana buƙatar isa ga constan kaɗan, waɗanda za'a iya shigar dasu azaman sigogi.
//!
//! # Other
//!
//! Juyin ya kamata *ba* panic ba.
//! Akwai tabbaci da bayyananniyar panics a cikin lambar, amma bai kamata a jawo su ba kawai suna aiki ne azaman binciken lafiya na ciki.Duk wani panics yakamata a ɗauke shi bug.
//!
//! Akwai gwaje-gwajen naúra amma ba su isa sosai don tabbatar da daidaito ba, kawai suna rufe percentagean ƙananan kuskuren kurakurai.
//! Akwai manyan gwaje-gwaje masu yawa a cikin kundin adireshin `src/etc/test-float-parse` azaman rubutun Python.
//!
//! Bayani akan yawan ambaliyar ruwa: Yawancin ɓangarorin wannan fayil ɗin suna yin lissafi tare da maƙerin adadi na `e`.
//! Ainihi, muna matsar da ƙayyadaddun adadi a kusa: Kafin lambar adadi ta farko, bayan lambar adadi na ƙarshe, da sauransu.Wannan na iya malalowa idan aka yi sakaci.
//! Mun dogara da jujjuyawar karamar hanya don kawai isar da isassun ƙananan maɓuɓɓuka, inda "sufficient" ke nufin "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Ana karɓar manyan masu magana, amma ba mu yin lissafi da su, kai tsaye ana juya su zuwa {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Wadannan biyun suna da nasu gwajin.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Sabobinda kirtani a cikin tushe 10 zuwa iyo.
            /// Yana karɓar mai fitar da gwani na zaɓi.
            ///
            /// Wannan aikin yana karɓar zaren kamar
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', ko daidai, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', ko, daidai da, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Jagoranci da bin bayan fili yana wakiltar kuskure.
            ///
            /// # Grammar
            ///
            /// Duk layin da ke bin nahawun [EBNF] na gaba zai haifar da dawo da [`Ok`]:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Sanann kwari
            ///
            /// A wasu yanayi, wasu layin da yakamata ya haifar da madaidaiciya a maimakon su dawo da kuskure.
            /// Duba [issue #31407] don cikakkun bayanai.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Kirtani
            ///
            /// # Komawa darajar
            ///
            /// `Err(ParseFloatError)` idan zaren bai wakilci ingantaccen lamba ba.
            /// In ba haka ba, `Ok(n)` inda `n` shine lambar maki mai iyo wanda `src` ya wakilta.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Kuskure wanda za'a iya dawo dashi lokacin da yake juye juye.
///
/// Ana amfani da wannan kuskuren azaman nau'in kuskure don aiwatarwar [`FromStr`] don [`f32`] da [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Ya raba kirtani na goma zuwa alama da sauran, ba tare da bincika ko tabbatar da sauran ba.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Idan kirtani ba shi da inganci, ba za mu taɓa amfani da alamar ba, don haka ba ma buƙatar inganta a nan.
        _ => (Sign::Positive, s),
    }
}

/// Sabobinda adadi na adadi zuwa lambar mahimmin iyo.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Babban mahimmin aiki don tsarin juzu'I zuwa-shawagi: Tsara dukkan abubuwan da aka tsara kafin su kuma gano wacce algorithm yakamata yayi ainihin tuban.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift fitar da maki goma
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 an iyakance shi zuwa rago 1280, wanda ke fassara zuwa kusan lambobi 385.
    // Idan muka wuce wannan, zamu fadi, don haka zamuyi kuskure kafin kusantowa (a cikin 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Yanzu mai ba da gaskiya ya dace a cikin 16 kaɗan, wanda aka yi amfani dashi a cikin duk manyan hanyoyin algorithms.
    let e = e as i16;
    // FIXME Wadannan iyakokin sun kasance masu ra'ayin mazan jiya.
    // Bincike mafi kyau game da yanayin gazawar Bellerophon na iya ba da izinin amfani da shi a cikin ƙarin yanayi don saurin sauri.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Kamar yadda aka rubuta, wannan yana inganta sosai (duba #27130, kodayake yana nufin tsohuwar sigar lambar).
// `inline(always)` aiki ne na wannan.
// Akwai shafukan kira guda biyu kawai gabaɗaya kuma baya sanya girman lambar muni.

/// Tsiri sifiri inda zai yiwu, koda lokacin da wannan yana buƙatar canzawa
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Gyara waɗannan siffofin ba ya canza komai amma yana iya ba da damar hanzarin sauri (<lambobi 15).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Sauƙaƙe lambobi na nau'i 0.0 ... x da x ... 0.0, daidaita daidaiton mai jituwa daidai.
    // Wannan bazai zama koyaushe nasara ba (mai yiwuwa ya tura wasu lambobi daga hanyar sauri), amma yana sauƙaƙa da sauran sassan sosai (musamman, kimanta girman ƙimar).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Ya dawo da madaidaiciyar ƙazamar datti a kan girman (log10) na mafi girman ƙimar da Algorithm R da Algorithm M za su lissafa yayin aiki a kan adadin da aka bayar.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Ba mu da damuwa da yawa game da ambaliya a nan saboda trivial_cases() da parser, wanda ke tace mana mafi kyawun shigarwar abubuwa.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // A cikin yanayin e>=0, duka algorithms suna lissafi game da `f * 10^e`.
        // Algorithm R ya ci gaba da yin wasu ƙididdiga masu rikitarwa tare da wannan amma zamu iya yin watsi da hakan don babbar iyaka saboda shima yana rage ɓangaren a gabani, don haka muna da abubuwan adanawa da yawa a can.
        //
        f_len + (e as u64)
    } else {
        // Idan e <0, Algorithm R yayi kusan abu ɗaya, amma Algorithm M ya banbanta:
        // Yana ƙoƙari ya sami lambar tabbatacce k irin wannan `f << k / 10^e` yana da mahimmancin kewayo.
        // Wannan zai haifar da kusan `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Shigar da daya haifar da wannan shine 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Gano ambaliyar bayyanannu da ambaliyar ba tare da duban lambobin goma ba.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Babu sifiri amma simplify() ya cire su
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Wannan kusan ƙimar ɗanɗano na ceil(log10(the real value)).
    // Ba mu da damuwa da yawa game da ambaliya a nan saboda tsawon shigarwar ya yi kadan (a kalla idan aka kwatanta da 2 ^ 64) kuma mai binciken ya riga ya sarrafa masu bayyanawa wadanda cikakken darajar su ta fi 10 ^ 18 (wanda har yanzu 10 ^ 19 ya rage na 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}