//! Tabbatarwa da bazuwar kirtani mai lamba guda iri:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! A takaice dai, daidaitaccen daidaitaccen tsari, tare da keɓaɓɓu biyu: Babu alamar, kuma babu kula da "inf" da "NaN".Wadannan ana sarrafa su ta aikin direba (super::dec2flt).
//!
//! Kodayake fahimtar ingantattun kayan aiki abu ne mai sauƙi, amma wannan rukunin dole ne ya ƙi ƙididdiga mara amfani mara iyaka, ba panic ba, kuma yin bincike da yawa waɗanda sauran matakan suka dogara da su ba panic (ko ambaliya) bi da bi.
//!
//! Don sanya abubuwa cikin damuwa, duk abin da ke faruwa a wucewa guda akan shigarwar.
//! Don haka, yi hankali lokacin gyaggyara komai, kuma sake dubawa tare da sauran matakan.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Sassan abubuwa masu ban sha'awa na kirtani na goma.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Yankin goma, an tabbatar da cewa yana da ƙasa da lambar goma goma.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Ana dubawa idan kirtani mai shigar da lamba lambar madaidaiciyar lamba ce kuma idan haka ne, gano wuri mai mahimmin, ɓangaren ɓangaren, da kuma abin da ke cikin sa.
/// Ba ya rike alamu.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Babu lambobi kafin 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Muna buƙatar aƙalla lambobi guda ɗaya kafin ko bayan batun.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Tattalin shara bayan ɓangaren ɓangare
            }
        }
        _ => Invalid, // Tallan shara bayan lambar farko
    }
}

/// Yana sassaka lambar adadi har zuwa farkon halin ba haruffa ba.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Haɓaka masu haɓaka da bincika kuskure.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Tallan dattin kaya bayan mai bayyanawa
    }
    if number.is_empty() {
        return Invalid; // Komai fanko
    }
    // A wannan lokacin, tabbas muna da ingantaccen igiyar lambobi.Yana iya yin tsayi da yawa don sanya shi cikin `i64`, amma idan yana da girma, shigarwar ba ta da siffa ko rashin iyaka.
    // Tunda kowace sifili a cikin lambobi goma kawai ke daidaita mai fitar da ta hanyar +/-1, a exp=10 ^ 18 shigarwar zata zama 17 exabyte (!) na sifili don samun kusanci kusa da zama mai iyaka.
    //
    // Wannan ba ainihin shari'ar amfani muke buƙata ba.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}