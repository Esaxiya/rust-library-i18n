//! Fidari da yawa akan IEEE 754 mai nutsuwa.Lambobi marasa kyau ba'a buƙata ba.
//! Lambobin shawagi na al'ada suna da wakilcin canonical kamar (frac, exp) irin wannan ƙimar 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) inda N shine adadin ragowa.
//!
//! Nananan abubuwa sun ɗan bambanta kuma baƙon abu, amma ƙa'ida ɗaya take aiki.
//!
//! Anan, duk da haka, muna wakiltar su azaman (sig, k) tare da f tabbatacce, irin wannan ƙimar f *
//! 2 <sup>e</sup> .Bayan sanya "hidden bit" a bayyane, wannan yana canza mai ba da hanya ta hanyar abin da ake kira matsawar mantissa.
//!
//! Sanya wata hanya, yawanci ana rubuta ruwa kamar (1) amma anan ana rubuta su kamar (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Muna kiran (1) da wakilcin juzu'i **da (2)** wakilcin wakilci **.
//!
//! Ayyuka da yawa a cikin wannan kundin suna ɗaukar lambobin al'ada ne kawai.Hanyoyin dec2flt suna ɗaukar ta madaidaiciya madaidaiciyar hanya gaba ɗaya (Algorithm M) don ƙananan ƙananan da yawa.
//! Wannan algorithm din yana buƙatar next_float() kawai wanda ke ɗaukar ƙananan ƙananan abubuwa da sifili.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Mataimaki trait don kaucewa kwafin asali duk lambar canzawa don `f32` da `f64`.
///
/// Duba sharhi na doc na mahaifa don me yasa wannan ya zama dole.
///
/// Shin **ba zai taɓa faruwa** a aiwatar dashi ba don wasu nau'ikan ko amfani dashi a waje da ƙirar dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Nau'in amfani da `to_bits` da `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Yana aiwatar da ɗan transmutation zuwa lamba.
    fn to_bits(self) -> Self::Bits;

    /// Yana aiwatar da ɗan transmutation daga lamba.
    fn from_bits(v: Self::Bits) -> Self;

    /// Ya mayar da rukunin wannan lambar ta faɗi.
    fn classify(self) -> FpCategory;

    /// Yana dawo da mantissa, mai bayyana kuma sa hannu azaman lamba.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Ya yanke shawarar taso kan ruwa.
    fn unpack(self) -> Unpacked;

    /// Casts daga ƙaramin lamba wanda za'a iya wakiltar shi daidai.
    /// Panic idan ba za a iya wakiltar lambar ba, ɗayan lambar a cikin wannan rukunin yana tabbatar da cewa ba za ta taɓa barin hakan ta faru ba.
    fn from_int(x: u64) -> Self;

    /// Samun darajar 10 <sup>e</sup> daga tebur da aka riga aka lissafta.
    /// Panics don `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Abin da sunan ya ce.
    /// Ya fi sauƙi ga lambar wuya fiye da jujjuyawar ma'ana da fatan LLVM koyaushe ya ninka shi.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Mai ra'ayin mazan jiya da ke kan lambobi goma na kayan masarufi waɗanda ba za su iya samar da ambaliyar ruwa ko sifili ko
    /// subnormals.Wataƙila maƙasudin mai iyaka na ƙimar ƙa'idar al'ada, saboda haka sunan.
    const MAX_NORMAL_DIGITS: usize;

    /// Lokacin da lambar adadi mafi mahimmanci tana da darajar wuri mafi girma daga wannan, tabbas lambar tana zagaye zuwa rashin iyaka.
    ///
    const INF_CUTOFF: i64;

    /// Lokacin da lambar adadi mafi mahimmanci tana da darajar wuri ƙasa da wannan, tabbas lambar tana zagaye zuwa sifili.
    ///
    const ZERO_CUTOFF: i64;

    /// Adadin ragowa a cikin kayan aiki.
    const EXP_BITS: u8;

    /// Yawan ragowa a cikin mahimmancin,*gami da* ɓoyayyen ɓoyayyen.
    const SIG_BITS: u8;

    /// Yawan ragowa a cikin mahimmanci,*ban da* ɓoyayyen ɓoyayyen.
    const EXPLICIT_SIG_BITS: u8;

    /// Matsakaicin mai wakiltar doka a cikin wakilcin yanki.
    const MAX_EXP: i16;

    /// Mafi qarancin mai wakilcin doka a cikin wakilcin kason, ban da abubuwan da ke ƙasa.
    const MIN_EXP: i16;

    /// `MAX_EXP` don wakilcin haɗin kai, watau, tare da sauyawa da ake amfani da shi.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` wanda ke aiki (ma'ana, tare da nuna bambanci)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` don wakilcin haɗin kai, watau, tare da sauyawa da ake amfani da shi.
    const MIN_EXP_INT: i16;

    /// Matsakaicin matsakaicin mahimmanci a cikin wakilci na asali.
    const MAX_SIG: u64;

    /// Ananan mahimmancin mahimmanci a cikin wakilci na asali.
    const MIN_SIG: u64;
}

// Mafi yawa aiki don #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Yana dawo da mantissa, mai bayyana kuma sa hannu azaman lamba.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Masu nuna ra'ayi masu nuna bambanci + canzawa mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe bai tabbata ba ko `as` ya zagaye daidai akan duk dandamali.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Yana dawo da mantissa, mai bayyana kuma sa hannu azaman lamba.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Masu nuna ra'ayi masu nuna bambanci + canzawa mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe bai tabbata ba ko `as` ya zagaye daidai akan duk dandamali.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Sabobincin `Fp` zuwa nau'in mashigar ruwa mafi kusa da na'urar.
/// Ba ya rike sakamako mara kyau.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f shine bit 64, don haka xe yana da canjin mantissa na 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Kewaya 64-bit mai mahimmanci ga rarar T::SIG_BITS tare da rabi-har ma.
/// Baya rike ambaliyar mai wuce gona da iri.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Daidaita canjin mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Kuskuren `RawFloat::unpack()` don lambobin al'ada.
/// Panics idan mahimmin abu ko mai bayyanawa baya aiki don lambobin da aka daidaita.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Cire ɓoyayyen ɓoye
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Daidaita mai nunawa don nuna bambanci da canzawar mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Bar alamar bit a 0 ("+"), lambobinmu duka tabbatattu ne
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Gina al'ada.An ba da izinin mantissa na 0 kuma yana gina sifili.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Expididdigar mai bayyana shine 0, alamar alamar 0 ce, saboda haka dole ne mu sake fassara fassarar.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Kimanta bignum tare da Fp.Zagaye tsakanin 0.5 ULP tare da rabi-har ma.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Mun yanke duk wasu ragowa kafin zancen `start`, watau, mun canza daidai ta hanyar adadin `start`, saboda haka wannan ma shine bayin da muke buƙata.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Zagaye (half-to-even) ya dogara da ragin da aka yanke.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Ya sami mafi girman lambar lamba a cikin ruwa mafi ƙanƙanta fiye da gardamar.
/// Ba ya ɗaukar subnormals, sifili, ko mai ba da ambaliyar ruwa.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Nemo mafi ƙanƙan maɓallin kewayawa fiye da yadda ake gardama.
// Wannan aikin yana cike, watau, next_float(inf) ==inf.
// Ba kamar yawancin lambobi a cikin wannan tsarin ba, wannan aikin yana ɗaukar sifili, ƙananan abubuwa, da rashin iyaka.
// Koyaya, kamar kowane sauran lambobi anan, baya ma'amala da NaN da lambobin marasa kyau.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Wannan yana da kyau ya zama gaskiya, amma yana aiki.
        // 0.0 an tsara shi azaman kalmar sifili.Nananan abubuwa suna 0x000m ... m inda m yake mantissa.
        // Musamman, mafi karancin abin alaƙa shine 0x0 ... 01 kuma babba shine 0x000F ... F.
        // Mafi ƙarancin lambar al'ada ita ce 0x0010 ... 0, don haka wannan shari'ar kusurwar tana aiki da kyau.
        // Idan kari yayi ambaliyar mantissa, kayan da aka kawo ya kara mai yadda ake so, kuma ragowar mantissa sun zama sifili.
        // Saboda abin da aka ɓoye na ɓoye, wannan ma shine ainihin abin da muke so!
        // A ƙarshe, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}