#![stable(feature = "futures_api", since = "1.36.0")]

//! Ynimar rashin daidaituwa.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Wannan irin da ake bukata domin:
///
/// a) Janareto ba za su iya aiwatar da `for<'a, 'b> Generator<&'a mut Context<'b>>` ba, saboda haka muna buƙatar wucewa dan nuna alama (duba <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raw pointers da `NonNull` ba `Send` ko `Sync`, don haka abin da zai sa kowane guda future non-Send/Sync kazalika, kuma ba mu so da.
///
/// Yana kuma simplifies da Hir ragewan na `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Kunsa janareto a cikin future.
///
/// Wannan aiki ya kõma mai `GenFuture` a ƙasa, amma boyewa shi a `impl Trait` ba mafi kuskure saƙonni (`impl Future` maimakon `GenFuture<[closure.....]>`).
///
// Wannan shine `const` don kaucewa ƙarin kurakurai bayan mun dawo daga `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Mun dogara da gaskiyar cewa async/await futures mara motsi ne don ƙirƙirar lamuni na kai-tsaye a cikin janareta mai tushe.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // KIYAYEWAR: Safe saboda mun yi !Unpin + !Drop, kuma wannan shi ne kawai a filin tsinkaya.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ci Gaba da janareta, sunã mãsu jũyãwa da `&mut Context` cikin wani `NonNull` raw akan.
            // A `.await` Ragewan za a amince jefa cewa baya ga wani `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // KIYAYEWAR: mai kiran dole ne tabbacin cewa `cx.0` ne mai aiki akan
    // hakan ya cika dukkan buƙatun don fassarar canzawa.
    unsafe { &mut *cx.0.as_ptr().cast() }
}