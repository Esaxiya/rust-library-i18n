#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future wakiltar wani asynchronous ƙidãyar.
///
/// future ƙima ce wacce maiyuwa ba ta gama aikin sarrafa kwamfuta ba tukuna.
/// Wannan irin "asynchronous value" sa ya yiwu a thread ci gaba da yin amfani aiki yayin da shi jira don darajar zama available.
///
///
/// # A `poll` Hanyar
///
/// A core Hanyar future, `poll`,*yunkurin* warware future cikin wani karshe darajar.
/// Wannan hanyar ba ta toshewa idan ƙimar ba a shirye take ba.
/// Madadin haka, an tsara aikin da za a farka lokacin da zai yiwu a sami ci gaba ta hanyar sake jefa kuri'a.
/// `context` da aka wuce zuwa hanyar `poll` na iya samar da [`Waker`], wanda shine makama don farka aikin yanzu.
///
/// Lokacin amfani da future, gabaɗaya baza ku kira `poll` kai tsaye ba, amma maimakon `.await` ƙimar.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Nau'in darajar da aka samar akan kammalawa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Oƙarin warware future zuwa ƙimar ƙarshe, yin rijistar aikin yanzu don farkawa idan ƙimar ba ta riga ta samo ba.
    ///
    /// # Komawa darajar
    ///
    /// Wannan aikin ya dawo:
    ///
    /// - [`Poll::Pending`] idan future bai riga ya shirya ba
    /// - [`Poll::Ready(val)`] tare da sakamakon `val` wannan future idan ta gama nasara.
    ///
    /// Da zarar wani future ya gama, abokan ciniki ya kamata ba `poll` shi a sake.
    ///
    /// Lokacin da future bai riga ya shirya ba, `poll` ya dawo da `Poll::Pending` kuma ya adana ɗigon [`Waker`] da aka kwafa daga [`Context`] na yanzu.
    /// Wannan [`Waker`] ana farkawa da zarar future na iya samun ci gaba.
    /// Alal misali, a future jiran wani soket zama zaa iya karanta zai kira `.clone()` a kan [`Waker`] da kuma adana shi.
    /// Lokacin da sigina zo da sauran wurare na nuna cewa soket ne zaa iya karanta, [`Waker::wake`] ake kira da soket future ta aiki da aka farkar damu.
    /// Da zarar an farka aiki, yakamata ayi ƙoƙari don sake `poll` future, wanda ƙila ko ba zai iya samar da ƙima na ƙarshe ba.
    ///
    /// Note cewa a mahara kira don `poll`, kawai [`Waker`] daga [`Context`] ya wuce zuwa mafi yawan 'yan kira ya kamata a shirya sami wakeup.
    ///
    /// # Halayen gudu
    ///
    /// Futures kadai ne *inert*;dole ne su zama *rayayye*`poll`ed yi ci gaba, ma'ana cewa kowane lokaci na yanzu aiki ne woken sama, shi ya kamata rayayye sake `poll` a lokacin futures cewa shi har yanzu yana da wani amfani a.
    ///
    /// Ba a kiran aikin `poll` akai-akai a cikin madaidaiciyar madauki-maimakon haka, ya kamata a kira shi lokacin da future ya nuna cewa a shirye yake don ci gaba (ta hanyar kiran `wake()`).
    /// Idan kana saba da `poll(2)` ko `select(2)` syscalls a kan Unix shi ta kamata a lura da cewa futures yawanci yi *ba* sha guda matsaloli na "all wakeups must poll all events".su ne mafi kamar `epoll(4)`.
    ///
    /// An aiwatar da `poll` kamata ku yi jihãdi ga komawa da sauri, kuma ya kamata ba toshe.Komawa da sauri yana hana ɗora faren zaren ko makullan faruwar lamarin.
    /// Idan aka sani gaba da lokaci da cewa kira zuwa `poll` iya kawo karshen sama shan wani dan lokaci, aikin da ya kamata a offloaded zuwa thread pool (ko wani abu mai kama) don tabbatar da cewa `poll` iya komawa da sauri.
    ///
    /// # Panics
    ///
    /// Da zarar wani future ya kammala (koma `Ready` daga `poll`), ya kira ta `poll` Hanyar sake yiwu panic, toshe har abada, ko yi wa wasu irin matsaloli.`Future` trait bai sanya buƙatu akan tasirin irin wannan kiran ba.
    /// Duk da haka, a matsayin `poll` Hanyar ba da alama `unsafe`, Rust ta saba dokokin tambaya: kira dole ba sa maras bayyani hali (memory cin hanci da rashawa, ba daidai ba yin amfani da `unsafe` ayyuka, ko da kamar), ko da kuwa da future ta jiha.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}