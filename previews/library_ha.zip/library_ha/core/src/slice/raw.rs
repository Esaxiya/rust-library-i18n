//! Ayyuka na kyauta don ƙirƙirar `&[T]` da `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forms yanki daga manuni da kuma tsayi.
///
/// A `len` shaida ne yawan **abubuwa**, ba da yawan bytes.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `data` dole ne ya zama [valid] don karantawa don `len * mem::size_of::<T>()` da yawa bytes, kuma dole ne a daidaita shi da kyau.Wannan yana nufin musamman:
///
///     * Dukan kewayon ƙwaƙwalwar wannan yanki dole ne a ƙunshe cikin abu guda da aka ware!
///       Yankuna ba zai taba yin fadin abubuwa da yawa ba.Duba [below](#incorrect-usage) don misali ba daidai ba la'akari da wannan.
///     * `data` dole ne ya zama ba wofi kuma ya kasance mai daidaitacce koda don yanka-sifili.
///     Aya daga cikin dalilan wannan shine cewa ingantaccen tsarin shimfida lissafi na iya dogaro da nassoshi (gami da yanka kowane tsayi) ana daidaita su kuma basa zama mara amfani don bambanta su da sauran bayanan.
///     Kuna iya samo maɓallin da za a iya amfani dashi azaman `data` don yanke-tsayin tsaka mai amfani da [`NonNull::dangling()`].
///
/// * `data` Dole nuna `len` jere yadda ya kamata initialized dabi'u na irin `T`.
///
/// * Waƙwalwar ajiyar da aka ambata ta yanki yanki da aka dawo ba dole bane a canza ta na tsawon rayuwar `'a`, sai dai a cikin `UnsafeCell`.
///
/// * A duka size `len * mem::size_of::<T>()` na yanki dole ba fi girma fiye da `isize::MAX`.
///   Duba takardun aminci na [`pointer::offset`].
///
/// # Caveat
///
/// Rayuwa ga yanki yanki da aka dawo ana nuna shi daga amfanin sa.
/// Don hana mummunan amfani da bazata, ana ba da shawarar a ɗaura tsawon rayuwa ga kowane tushen rayuwa yana da aminci a cikin mahallin, kamar ta hanyar samar da aikin mataimaki wanda ke ɗaukar tsawon rayuwar darajar mai gida ga yanki, ko ta bayyananniyar bayani.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // bayyana wani yanki for guda kashi
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Amfani mara kyau
///
/// Aikin `join_slices` mai zuwa shine **mara kyau** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Bayanin da ke sama yana tabbatar da `fst` da `snd` suna da alaƙa, amma har yanzu ana iya ƙunsar su cikin _different allocated objects_, ta yadda ƙirƙirar wannan yanki hali ne da ba a bayyana shi ba.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` kuma `b` abubuwa ne da aka ware daban ...
///     let a = 42;
///     let b = 27;
///     // ... wanda duk da haka za'a iya shimfida shi cikin tunani: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Yana aiwatar da aiki iri ɗaya kamar [`from_raw_parts`], sai dai an dawo da yanki mai canzawa.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `data` dole ne ya zama [valid] don duka karatu da rubutu don `len * mem::size_of::<T>()` da yawa bytes, kuma dole ne a daidaita shi da kyau.Wannan yana nufin musamman:
///
///     * Dukan kewayon ƙwaƙwalwar wannan yanki dole ne a ƙunshe cikin abu guda da aka ware!
///       Yankuna ba zai taba yin fadin abubuwa da yawa ba.
///     * `data` dole ne ya zama ba wofi kuma ya kasance mai daidaitacce koda don yanka-sifili.
///     Aya daga cikin dalilan wannan shine cewa ingantaccen tsarin shimfida lissafi na iya dogaro da nassoshi (gami da yanka kowane tsayi) ana daidaita su kuma basa zama mara amfani don bambanta su da sauran bayanan.
///
///     Kuna iya samo maɓallin da za a iya amfani dashi azaman `data` don yanke-tsayin tsaka mai amfani da [`NonNull::dangling()`].
///
/// * `data` Dole nuna `len` jere yadda ya kamata initialized dabi'u na irin `T`.
///
/// * Ba za a sami damar yin amfani da ƙwaƙwalwar ajiyar da aka dawo da ita ta hanyar kowane abin nunawa ba (wanda ba a samo daga dawo da darajar ba) na tsawon rayuwar `'a`.
///   Dukansu damar karatu da rubutu duk an hana su.
///
/// * A duka size `len * mem::size_of::<T>()` na yanki dole ba fi girma fiye da `isize::MAX`.
///   Duba takardun aminci na [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Sabobin tuba zuwa ga yanki na tsayi 1 (ba tare da kwafa ba).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Sabobin tuba zuwa ga yanki na tsayi 1 (ba tare da kwafa ba).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}