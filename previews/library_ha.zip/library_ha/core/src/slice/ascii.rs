//! Ayyuka akan ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Duba idan duk bytes a cikin wannan yanki suna cikin zangon ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Dubawa cewa yanka biyu wasa ne na rashin jituwa na ASCII.
    ///
    /// Yayi daidai da `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, amma ba tare da kasaftawa da yin kwafin zamani ba.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ya canza wannan yanki zuwa matsayin ASCII wanda yake daidai a cikin wuri.
    ///
    /// Haruffan ASCII 'a' zuwa 'z' an tsara su zuwa 'A' zuwa 'Z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don dawo da sabon darajar ƙarami ba tare da gyaggyara wanda yake ba, yi amfani da [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Ya canza wannan yanki zuwa ƙaramin ƙaramin rubutun ASCII wanda yake daidai a cikin wuri.
    ///
    /// Haruffan ASCII 'A' zuwa 'Z' an tsara su zuwa 'a' zuwa 'z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don dawo da sabon ƙimar ƙarami ba tare da gyaggyara wanda yake ba, yi amfani da [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Yana dawo da `true` idan kowane baiti a cikin kalmar `v` ba nonascii bane (>=128).
/// Snarfed daga `../str/mod.rs`, wanda yayi wani abu makamancin haka don ingancin utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Ingantaccen gwajin ASCII wanda zai yi amfani da ayyukan amfani-da-lokaci maimakon ayyukan lokaci-lokaci (idan zai yiwu).
///
/// Abubuwan da muke amfani dasu anan suna da sauki.Idan `s` yayi gajarta, kawai zamu bincika kowane baiti kuma za'ayi dashi.In ba haka ba:
///
/// - Karanta kalma ta farko tare da lodin da ba a daidaita ba.
/// - Daidaita maɓallin, karanta kalmomi masu zuwa har zuwa ƙare tare da lodi masu daidaito.
/// - Karanta `usize` na ƙarshe daga `s` tare da ɗaukar mara izini.
///
/// Idan ɗayan waɗannan ɗayan nauyin ya samar da wani abu wanda `contains_nonascii` (above) ya dawo gaskiya, to, mun san amsar ba ta da gaskiya.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Idan ba za mu sami komai ba daga aiwatar da kalma-at-a-lokaci, koma baya zuwa madaidaiciyar madauki.
    //
    // Hakanan muna yin wannan don gine-ginen inda `size_of::<usize>()` bai isa jeri na `usize` ba, saboda baƙon lamari ne na edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Kullum muna karanta kalma ta farko mara daidaituwa, ma'ana `align_offset` shine
    // 0, za mu sake karanta wannan ƙimar sake don daidaitawa karatu.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // KYAUTA: Muna tabbatar da `len < USIZE_SIZE` a sama.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Mun bincika wannan a sama, da ɗan fakaice.
    // Lura cewa `offset_to_aligned` shine `align_offset` ko `USIZE_SIZE`, duka biyun an bincika su a sarari a sama.
    //
    debug_assert!(offset_to_aligned <= len);

    // KYAUTA: word_ptr shine (yayi daidaito sosai) amfani da ptr da muke amfani dashi don karanta
    // tsakiyar yanki na yanki.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` shine ma'aunin baiti na `word_ptr`, wanda aka yi amfani dashi don bincika ƙarshen madauki.
    let mut byte_pos = offset_to_aligned;

    // Binciken Paranoia game da daidaitawa, tunda muna shirin yin jigilar kayan aiki marasa daidaito.
    // A aikace wannan yakamata ya zama ba zai yiwu ba hana shinge a cikin `align_offset` kodayake.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Karanta kalmomi masu zuwa har zuwa kalmar daidaitawa ta ƙarshe, ban da kalma mai haɗawa ta ƙarshe da kanta da za a yi a binciken wutsiya daga baya, don tabbatar da cewa wutsiya koyaushe `usize` ɗaya ce mafi yawa don ƙarin branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity duba cewa karatun yana cikin iyaka
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Kuma wannan tunaninmu game da `byte_pos` ya riƙe.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // KYAUTA: Mun san cewa `word_ptr` yayi daidai (saboda
        // `` align_offset '), kuma mun san cewa muna da isassun baiti tsakanin `word_ptr` da ƙarshe
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // KYAUTA: Mun san `byte_pos <= len - USIZE_SIZE`, wanda ke nufin hakan
        // bayan wannan `add`, `word_ptr` zai kasance a mafi-wuce-ƙarshen.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Binciken hankali don tabbatar akwai ainihin `usize` kawai ya rage.
    // Wannan yakamata a tabbatar dashi ta hanyar yanayin madauki.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // KYAUTA: Wannan ya dogara da `len >= USIZE_SIZE`, wanda muke bincika farkon farawa.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}