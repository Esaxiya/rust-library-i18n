// Aiwatar da asali an ɗauke shi daga rust-memchr.
// Hakkin mallaka 2015 Andrew Gallant, bluss da Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Yi amfani da yanke jiki.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Yana dawo da `true` idan `x` ya ƙunshi kowane baiti.
///
/// Daga *Batutuwa na Kwarewa*, J. Arndt:
///
/// "Manufar ita ce a cire guda daga kowane baiti sannan a nemi baiti inda rancen ya yadu har zuwa mafi mahimmanci
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Ya dawo da bayanan farko wanda yayi daidai da baiti `x` a cikin `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Hanyar sauri don ƙananan yanka
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Yi hoto don ƙimar baiti ɗaya ta karanta kalmomin `usize` guda biyu a lokaci guda.
    //
    // Raba `text` a cikin sassa uku
    // - ɓangaren farko wanda ba a daidaita ba, kafin kalmar farko tayi daidai a cikin rubutu
    // - jiki, duba ta kalmomi 2 a lokaci guda
    // - bangaren da ya rage, <2 size size

    // bincika har zuwa wani hada kai iyaka
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // bincika jikin rubutun
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // KYAUTA: tsaranin lokaci yana tabbatar da nisan akalla 2 * usize_bytes
        // tsakanin biya da ƙarshen yanki.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // karya idan akwai ma'aunin daidaitawa
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Nemo baiti bayan ma'anar madaurin jiki ya tsaya.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Ya dawo da bayanan da ya gabata wanda ya yi daidai da baiti `x` a cikin `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Yi hoto don ƙimar baiti ɗaya ta karanta kalmomin `usize` guda biyu a lokaci guda.
    //
    // Raba `text` a sassa uku:
    // - wutsiya mara daidaituwa, bayan kalma ta ƙarshe daidaitaccen adireshin a cikin rubutu,
    // - jiki, ana bincika shi da kalmomi 2 a lokaci guda,
    // - na farko sauran bytes, <2 kalma size.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Muna kiran wannan don kawai a sami tsayin kari da kari.
        // A tsakiyar koyaushe muna aiwatar da ɓangarori biyu lokaci guda.
        // KYAUTA: turawa `[u8]` zuwa `[usize]` yana da aminci sai dai banbancin girma wanda `align_to` ke kulawa dashi.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Binciko jikin rubutun, tabbatar ba zamu tsallake min_aligned_offset ba.
    // daidaitawa koyaushe yana daidaita, don haka gwada `>` kawai ya isa kuma yana hana yuwuwar ambaliyar.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // KYAUTA: ƙaddamarwa yana farawa daga len, suffix.len(), idan dai ya fi girma
        // min_aligned_offset (prefix.len()) ragowar sauran shine aƙalla 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Karya idan akwai ma'aunin daidaitawa.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Nemo baiti kafin ma'anar madaurin jiki ya tsaya.
    text[..offset].iter().rposition(|elt| *elt == x)
}