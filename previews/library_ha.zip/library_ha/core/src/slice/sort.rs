//! Yanke yanki
//!
//! Wannan rukunin yana ƙunshe da tsarin algorithm bisa tsarin Orson Peters na saurin lalacewa, wanda aka buga a: <https://github.com/orlp/pdqsort>
//!
//!
//! Sortirƙirar rashin daidaito ya dace da libcore saboda ba ya ba da ƙwaƙwalwar ajiya, sabanin yadda muke aiwatar da ƙayyadaddun tsari.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Lokacin da ya ragu, kofe daga `src` cikin `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // KYAUTA: Wannan ajin masu taimako ne.
        //          Da fatan za a koma amfani da shi don daidaito.
        //          Hakanan, dole ne mutum ya tabbata cewa `src` da `dst` ba su haɗuwa kamar yadda `ptr::copy_nonoverlapping` ya buƙata ba.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Yana canza farkon abu zuwa dama har sai yaci karo da wani abu mafi girma ko daidai.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KIYAYEWAR: The unsafe ayyukan kasa ya shafi Indexing ba tare da wani mamaye rajistan shiga (`get_unchecked` da `get_unchecked_mut`)
    // da kuma kwafin ƙwaƙwalwa (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Mun bincika girman jeri zuwa>=2.
    //  2. Duk bayanan da zamuyi shine koyaushe tsakanin {0 <= index < len} mafi yawa.
    //
    // b.Kwafin ƙwaƙwalwa
    //  1. Muna karɓar bayanai zuwa nassoshi waɗanda aka tabbatar suna aiki.
    //  2. Ba za su iya haɗawa ba saboda mun sami alamomi zuwa ƙididdigar bambancin yanki.
    //     Wato, `i` da `i-1`.
    //  3. Idan yanki yayi daidai, abubuwan suna daidaita sosai.
    //     Hakkin mai kiran ne ya tabbatar yanki ya dace sosai.
    //
    // Duba ra'ayoyin da ke ƙasa don ƙarin bayani.
    unsafe {
        // Idan abubuwa biyu na farko basu da tsari ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Karanta farkon abu a cikin canjin da aka ware.
            // Idan aikin kwatancen mai zuwa panics, `hole` zai ragu kuma a atomatik sake rubuta abun cikin yanki.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Matsar da ``i`-th element ɗaya wuri zuwa hagu, don haka juya ramin zuwa dama.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ya fadi kuma ta haka ne yayi kwafin `tmp` a cikin sauran ramin da yake cikin `v`.
        }
    }
}

/// Yana canza kashi na karshe zuwa hagu har sai yaci karo da wani abu karami ko daidai.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KIYAYEWAR: The unsafe ayyukan kasa ya shafi Indexing ba tare da wani mamaye rajistan shiga (`get_unchecked` da `get_unchecked_mut`)
    // da kuma kwafin ƙwaƙwalwa (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Mun bincika girman jeri zuwa>=2.
    //  2. Duk bayanan da zamuyi shine koyaushe tsakanin `0 <= index < len-1` mafi yawa.
    //
    // b.Kwafin ƙwaƙwalwa
    //  1. Muna karɓar bayanai zuwa nassoshi waɗanda aka tabbatar suna aiki.
    //  2. Ba za su iya haɗawa ba saboda mun sami alamomi zuwa ƙididdigar bambancin yanki.
    //     Wato, `i` da `i+1`.
    //  3. Idan yanki yayi daidai, abubuwan suna daidaita sosai.
    //     Hakkin mai kiran ne ya tabbatar yanki ya dace sosai.
    //
    // Duba ra'ayoyin da ke ƙasa don ƙarin bayani.
    unsafe {
        // Idan abubuwa biyu na ƙarshe basuda oda ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Karanta kashi na karshe a cikin canjin da aka ware.
            // Idan aikin kwatancen mai zuwa panics, `hole` zai ragu kuma a atomatik sake rubuta abun cikin yanki.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Matsar da ``i`-th element ɗaya wuri zuwa dama, don haka juya ramin zuwa hagu.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ya fadi kuma ta haka ne yayi kwafin `tmp` a cikin sauran ramin da yake cikin `v`.
        }
    }
}

/// Partially dadin jikina wani yanki da canjawa da dama daga-daga-domin abubuwa a kusa da.
///
/// Yana dawo da `true` idan an daidaita yanki a ƙarshen.Wannan aikin shine *O*(*n*) mafi munin yanayi.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Matsakaicin matsakaicin adadin ma'auratan da ke kusa da su waɗanda za a sauya su.
    const MAX_STEPS: usize = 5;
    // Idan yanki yayi kasa da wannan, kar a canza komai.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // KYAUTA: Mun riga mun bayyana a sarari duba `i < len`.
        // Duk bayanan mu na gaba shine kawai a cikin zangon `0 <= index < len`
        unsafe {
            // Nemo abubuwa biyu masu zuwa kusa da wadanda basu da tsari.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Mun gama?
        if i == len {
            return true;
        }

        // Kada ku canza abubuwa akan gajeren tsararru, wannan yana da tsadar aiki.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Musayar abubuwan da aka samo.Wannan yana sanya su cikin tsari daidai.
        v.swap(i - 1, i);

        // Canja ƙarami zuwa hagu.
        shift_tail(&mut v[..i], is_less);
        // Canja mafi girman abu zuwa dama.
        shift_head(&mut v[i..], is_less);
    }

    // Ba a iya sarrafa yanki a cikin iyakantattun matakai ba.
    false
}

/// Yanke yanki ta amfani da nau'in sakawa, wanda shine *O*(*n*^ 2) mafi munin yanayi.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Nau'in `v` ta amfani da daddawa, wanda ke tabbatar da *O*(*n*\*log(* n*)) mafi munin yanayi.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Wannan tarin binary yana mutunta mara iyaka `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // 'Ya'yan `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Zabi mafi yaro.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Tsaya idan mai canzawa ya riƙe a `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Musayar `node` tare da babban yaro, matsa mataki ɗaya ƙasa, kuma ci gaba da siftacewa.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Gina tarin a cikin layi.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Fitar da abubuwa mafi ƙaranci daga tulin.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Rabobi `v` zuwa abubuwa masu ƙarancin `pivot`, sannan abubuwan da suka fi girma ko daidai da `pivot`.
///
///
/// Ya dawo da adadin abubuwan da suka kasa da `pivot`.
///
/// Ana yin rabuwa-da-toshe don rage farashin ayyukan ayyukan reshe.
/// An gabatar da wannan ra'ayin a cikin takarda [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Adadin abubuwa a cikin toshewar al'ada.
    const BLOCK: usize = 128;

    // Rarraba algorithm ya maimaita matakai masu zuwa har sai an kammala:
    //
    // 1. Gano wani shinge daga gefen hagu don gano abubuwan da suka fi girma ko daidai da madogara.
    // 2. Gano wani toshe daga gefen dama don gano abubuwan da suka fi ƙanƙan-nesa.
    // 3. Musayar abubuwan da aka gano tsakanin gefen hagu da dama.
    //
    // Muna adana masu canji masu zuwa don ginshiƙan abubuwa:
    //
    // 1. `block` - Yawan abubuwa a cikin toshe
    // 2. `start` - Fara nunawa cikin tsararrun `offsets`.
    // 3. `end` - Poarshen alama a cikin tsararren `offsets`.
    // 4. `` abubuwan gyarawa, Fihirisar abubuwan da ba oda a cikin shingen.

    // Toshe na yanzu a gefen hagu (daga `l` zuwa `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Toshe na yanzu a gefen dama (daga `r.sub(block_r)` to `r`).
    // KYAUTA: Takaddun shaida don .add() musamman sun ambaci cewa `vec.as_ptr().add(vec.len())` koyaushe yana da lafiya '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Lokacin da muka sami VLAs, gwada ƙirƙirar tsararru ɗaya na tsayin `min(v.len(), 2 * BLOCK) `` a maimakon haka
    // fiye da tsayayyun-tsararru iri biyu masu tsayin `BLOCK`.VLAs na iya zama mafi inganci-inganci.

    // Yana dawo da adadin abubuwa tsakanin masu nuni `l` (inclusive) da `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // An gama mu tare da raba-to-block lokacin da `l` da `r` suka kusanto.
        // Sannan zamuyi wasu ayyukan facin-kaya don raba ragowar abubuwan da ke tsakanin.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Adadin abubuwan da suka rage (har yanzu ba a kwatanta su da pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Daidaita girman masu toshewa ta yadda hagu da dama dama ba zasu zoba, amma daidaita sosai don rufe sauran ragowar.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Sanya abubuwa `block_l` daga gefen hagu.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // KYAUTA: Ayyuka marasa aminci a ƙasa sun haɗa da amfani da `offset`.
                //         Dangane da yanayin aikin da ake buƙata, muna gamsar dasu saboda:
                //         1. `offsets_l` an rarraba shi, kuma don haka ana ɗaukar shi daban abun da aka ware.
                //         2. Aikin `is_less` ya dawo da `bool`.
                //            Fitar `bool` ba zai taɓa cika `isize` ba.
                //         3. Mun bada tabbacin cewa `block_l` zai zama `<= BLOCK`.
                //            Ari da, `end_l` an fara saita shi zuwa farkon alamar `offsets_` wanda aka ayyana akan tarin.
                //            Don haka, mun san cewa koda a cikin mafi munin yanayi (duk kiraye-kirayen na `is_less` sun dawo ƙarya) za mu kasance mafi yawan 1 byte wucewa ƙarshe.
                //        Wani aiki mara aminci a nan shine ƙaddamar da `elem`.
                //        Koyaya, `elem` shine farkon mai nuna alama ga yanki wanda yake aiki koyaushe.
                unsafe {
                    // Kwatancen mara tushe.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Sanya abubuwa `block_r` daga gefen dama.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // KYAUTA: Ayyuka marasa aminci a ƙasa sun haɗa da amfani da `offset`.
                //         Dangane da yanayin aikin da ake buƙata, muna gamsar dasu saboda:
                //         1. `offsets_r` an rarraba shi, kuma don haka ana ɗaukar shi daban abun da aka ware.
                //         2. Aikin `is_less` ya dawo da `bool`.
                //            Fitar `bool` ba zai taɓa cika `isize` ba.
                //         3. Mun bada tabbacin cewa `block_r` zai zama `<= BLOCK`.
                //            Ari da, `end_r` an fara saita shi zuwa farkon alamar `offsets_` wanda aka ayyana akan tarin.
                //            Don haka, mun san cewa koda a cikin mafi munin yanayi (duk kiraye-kirayen na `is_less` ya dawo gaskiya) za mu kasance a mafi akasari 1 wuce ƙarshen.
                //        Wani aiki mara aminci a nan shine ƙaddamar da `elem`.
                //        Koyaya, `elem` ya kasance farkon `1 *sizeof(T)` ya wuce ƙarshen kuma mun rage shi ta `1* sizeof(T)` kafin isa gare shi.
                //        Ari da, an tabbatar da cewa `block_r` ya ƙasa da `BLOCK` kuma `elem` saboda haka a mafi yawancin yana nuna farkon yanki.
                unsafe {
                    // Kwatancen mara tushe.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Adadin abubuwanda basuda oda domin yin musaya tsakanin bangaren hagu da dama.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Maimakon swapping daya biyu a lokacin, shi ne ya fi dacewa a yi a cyclic permutation.
            // Wannan bai dace sosai da sauyawa ba, amma yana samar da irin wannan sakamakon ta amfani da ƙananan ayyukan ƙwaƙwalwa.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Duk abubuwanda basuda oda a cikin hagu an motsa su.Matsar zuwa toshe na gaba.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // All fitar da-na-domin abubuwa a dama block aka koma.Motsa zuwa bulon da ya gabata.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Abinda ya rage yanzu shine mafi yawan toshe ɗaya (ko dai hagu ko dama) tare da abubuwanda basuda tsari waɗanda suke buƙatar motsawa.
    // Waɗannan abubuwan da suka rage ana iya sauya su zuwa ƙarshen cikin toshe su.
    //

    if start_l < end_l {
        // Hannun hagu ya kasance.
        // Matsar da sauran abubuwanda ba-oda ba zuwa hannun dama na dama.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Tsarin dama ya kasance.
        // Matsar da sauran abubuwanda ba-tsari ba zuwa hagu na hagu.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Babu wani abin da za mu yi, mun gama.
        width(v.as_mut_ptr(), l)
    }
}

/// Rabobi `v` zuwa abubuwa masu ƙarancin `v[pivot]`, sannan abubuwan da suka fi girma ko daidai da `v[pivot]`.
///
///
/// Ya dawo da plean fuloti:
///
/// 1. Adadin abubuwan da suka gaza `v[pivot]`.
/// 2. Gaskiya ne idan an riga an raba `v`.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Sanya pivot a farkon yanki.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Karanta ginshiƙan cikin maɓallin keɓaɓɓen wuri don inganci.
        // Idan aikin kwatancen mai zuwa panics, za a rubuta mabuɗin ta atomatik cikin yanki.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Nemo abubuwa biyun farko wadanda basuda tsari.
        let mut l = 0;
        let mut r = v.len();

        // KYAUTA: Rashin aminci a ƙasa ya haɗa da nuna jeri.
        // Na farkon: Mun riga munyi iyakan dubawa anan tare da `l < r`.
        // Na na biyu: Da farko muna da `l == 0` da `r == v.len()` kuma mun bincika `l < r` ɗin a kowane aiki na nuni.
        //                     Daga nan mun san cewa `r` dole ne ya zama aƙalla `r == l` wanda aka nuna yana da inganci daga na farkon.
        unsafe {
            // Nemo na farko kashi fi ko daidai to da pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Nemo ɓangaren ƙarshe wanda ya fi ƙanƙani da mahimmanci.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ya fita daga sarari kuma ya rubuta ginshiƙan (wanda shine maɓallin keɓaɓɓen ajiya) ya koma cikin yanki inda yake a da.
        // Wannan matakin yana da mahimmanci wajen tabbatar da aminci!
        //
    };

    // Sanya ginshiƙi tsakanin sassan biyu.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Rabobi `v` cikin abubuwa daidai da `v[pivot]` sannan abubuwa da suka fi `v[pivot]` suka biyo baya.
///
/// Yana dawo da adadin abubuwan daidai da pivot.
/// An ɗauka cewa `v` ba ya ƙunsar abubuwan da suka fi ƙanƙanta.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Sanya pivot a farkon yanki.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Karanta ginshiƙan cikin maɓallin keɓaɓɓen wuri don inganci.
    // Idan aikin kwatancen mai zuwa panics, za a rubuta mabuɗin ta atomatik cikin yanki.
    // KYAUTA: Nuni a nan yana da inganci saboda an samo shi daga nuni zuwa yanki.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Yanzu bangare na yanki.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // KYAUTA: Rashin aminci a ƙasa ya haɗa da nuna jeri.
        // Na farkon: Mun riga munyi iyakan dubawa anan tare da `l < r`.
        // Na na biyu: Da farko muna da `l == 0` da `r == v.len()` kuma mun bincika `l < r` ɗin a kowane aiki na nuni.
        //                     Daga nan mun san cewa `r` dole ne ya zama aƙalla `r == l` wanda aka nuna yana da inganci daga na farkon.
        unsafe {
            // Nemo farkon abin da ya fi mahimmanci.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Nemo kashi na ƙarshe daidai yake da pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Mun gama?
            if l >= r {
                break;
            }

            // Musayar samfuran da aka samo guda biyu wadanda basuda tsari.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Mun sami abubuwan `l` daidai da pivot.1ara 1 don asusu don ginshiƙin kanta.
    l + 1

    // `_pivot_guard` ya fita daga sarari kuma ya rubuta ginshiƙan (wanda shine maɓallin keɓaɓɓen ajiya) ya koma cikin yanki inda yake a da.
    // Wannan matakin yana da mahimmanci wajen tabbatar da aminci!
}

/// Ya watsu wasu abubuwa a kusa cikin ƙoƙari na karya fasalin da ka iya haifar da rashin daidaiton ra'ayoyi cikin sauri.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom lambar janareta daga takarda "Xorshift RNGs" ta George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Dauki bazuwar lambobin modulo wannan lambar.
        // Lambar ta yi daidai da `usize` saboda `len` bai fi `isize::MAX` girma ba.
        let modulus = len.next_power_of_two();

        // Wasu candidatesan takarar masu mahimmanci zasu kasance a kusa da wannan layin.Bari mu bazu su.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Haɗa lambar bazuwar modulo `len`.
            // Koyaya, don gujewa ayyuka masu tsada mun fara ɗauka ɗaukar modulo ikon biyu, sannan ragewa ta `len` har sai ya dace da zangon `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` tabbas zai zama ƙasa da `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Zaɓi maɓalli a cikin `v` kuma ya dawo da fihirisar da `true` idan mai yiwuwa an riga an tsara yanki.
///
/// Abubuwan da ke cikin `v` za'a iya sake dawo dasu cikin aikin.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mafi qarancin tsayi don zaɓar hanyar tsaka-tsaki.
    // Gajerun yankakke suna amfani da hanya mai sauƙi ta tsakiya-zuwa-uku.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Matsakaicin adadin swaps wanda za'a iya aiwatarwa a wannan aikin.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Indididdiga uku kusa da abin da za mu zaɓi maɓalli.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Ya kirga adadin yawan swaps din da muke shirin yi yayin tantance fihiriso.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps fihirisa sab thatda haka, `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swaps fihirisa sab thatda haka, `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Nemo tsakiyar `v[a - 1], v[a], v[a + 1]` kuma yana adana bayanan a cikin `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Nemo matsakaita a cikin unguwannin `a`, `b`, da `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Nemo tsakiyan tsakanin `a`, `b`, da `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Matsakaicin adadin swaps aka yi.
        // Chances ne yanki ke saukowa ko mafi yawa yana saukowa, saboda haka juyawa zai iya taimakawa wajen daidaita shi da sauri.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Nau'i `v` recursively.
///
/// Idan yanki yana da wanda ya gabace shi a cikin asalin tsari, an kayyade shi azaman `pred`.
///
/// `limit` shine adadin abubuwanda basu dace ba kafin canzawa zuwa `heapsort`.
/// Idan sifili, wannan aiki zai nan da nan canzawa zuwa heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ana rarraba yanki har zuwa wannan tsawon ta amfani da nau'in sakawa.
    const MAX_INSERTION: usize = 20;

    // Gaskiya ne idan rabuwa ta ƙarshe ta kasance daidai gwargwado.
    let mut was_balanced = true;
    // Gaskiya ne idan rabuwa ta ƙarshe bai sake abubuwa ba (an riga an raba yanki).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Ana gajarta gajeren yanka ta amfani da nau'in sakawa.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Idan da yawa bad pivot zabi aka sanya, kawai fada a mayar da heapsort domin tabbacin `O(n * log(n))` m-harka.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Idan rabuwa ta ƙarshe ta kasance ba ta da daidaito ba, gwada ƙoƙarin warware alamu a cikin yanki ta hanyar jujjuya wasu abubuwa a kusa.
        // Da fatan za mu zaɓi mafi mahimman abu a wannan lokacin.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Zabi wani pivot da kuma kokarin yin cinta ko yanki An riga ana jerawa.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Idan rabuwa ta ƙarshe ta daidaita da kyau kuma ba ta canza abubuwa ba, kuma idan maɓallin keɓaɓɓen ya annabta yanki da alama an riga an riga an daidaita shi ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Gwada gano abubuwa da yawa daga cikin tsari da sauya su zuwa gyara wurare.
            // Idan yanki ya ƙare ana jerawa gaba ɗaya, mun gama.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Idan mabuɗin da aka zaɓa ya yi daidai da wanda ya gabace shi, to, shi ne mafi ƙanƙan abu a cikin yanki.
        // Raba yanki cikin abubuwa daidai da kuma abubuwan da suka fi pivot girma.
        // Wannan shari'ar galibi ana buga ta yayin da yanki ya ƙunshi abubuwa masu yawa.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ci gaba da rarrabe abubuwa mafi girma daga kan pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Raba yanki.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Raba yanki zuwa `left`, `pivot`, da `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Komawa cikin guntun gefe kawai don rage yawan adadin kiraye-kirayen da kuma cinye wuri mara kyau.
        // To kawai ci gaba tare da gefen da ya fi tsayi (wannan yana kama da sake dawowa wutsiya).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Nau'in `v` ta amfani da saurin saurin tsari, wanda shine *O*(*n*\*log(* n*)) mafi munin yanayi.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kasawa yana da wani m hali a sifili-sized iri.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Iyakance adadin bangarorin da basu daidaita ba zuwa `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Don yanka har zuwa wannan tsawon yana da wataƙila da sauri don sauƙaƙe su.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Zaɓi ginshiƙi
        let (pivot, _) = choose_pivot(v, is_less);

        // Idan mabuɗin da aka zaɓa ya yi daidai da wanda ya gabace shi, to, shi ne mafi ƙanƙan abu a cikin yanki.
        // Raba yanki cikin abubuwa daidai da kuma abubuwan da suka fi pivot girma.
        // Wannan shari'ar galibi ana buga ta yayin da yanki ya ƙunshi abubuwa masu yawa.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Idan mun wuce bayanan mu, to muna da kyau.
                if mid > index {
                    return;
                }

                // In ba haka ba, ci gaba da rarrabe abubuwan da suka fi pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Raba yanki zuwa `left`, `pivot`, da `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Idan tsakiyar==fihirisa, to mun gama, tunda partition() ya bada tabbacin cewa dukkan abubuwa bayan tsakiya sun fi girma ko daidai da tsakiyar.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Kasawa ba shi da halayyar ma'ana a kan nau'ikan sifofi iri-iri.Kayi komai.
    } else if index == v.len() - 1 {
        // Nemo max kashi kuma sanya shi a cikin matsayi na ƙarshe na tsararru.
        // Muna da 'yanci muyi amfani da `unwrap()` a nan saboda mun san v bazai zama fanko ba.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Nemo ƙaramin abu ka sanya shi a farkon yanayin tsararrun.
        // Muna da 'yanci muyi amfani da `unwrap()` a nan saboda mun san v bazai zama fanko ba.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}