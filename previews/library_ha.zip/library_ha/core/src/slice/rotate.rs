// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Yana juya kewayon `[mid-left, mid+right)` don wannan nau'in a `mid` ya zama farkon abu.Daidai, yana juya zangon abubuwan `left` zuwa hagu ko abubuwan `right` zuwa dama.
///
/// # Safety
///
/// Wajan da aka ayyana dole ne ya zama mai aiki don karatu da rubutu.
///
/// # Algorithm
///
/// Ana amfani da algorithm 1 don ƙananan ƙimar `left + right` ko don babban `T`.
/// Abubuwan suna motsawa zuwa matsayinsu na ƙarshe ɗayan lokaci farawa daga `mid - left` kuma suna haɓaka ta hanyar `right` matakan modulo `left + right`, irin wannan ne kawai ake buƙata na ɗan lokaci.
/// Daga bisani, mun zo da baya a `mid - left`.
/// Koyaya, idan `gcd(left + right, right)` ba 1 bane, matakan da ke sama sun tsallake abubuwa.
/// Misali:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Sa'a, da yawan tsalle a kan abubuwa tsakanin kammala abubuwa ne ko da yaushe daidaita, don haka ba za mu iya kawai biya diyya mu fara matsayi, kuma mafi yi akai-akai (jimlar yawan akai-akai ne `gcd(left + right, right)` value).
///
/// Sakamakon ƙarshe shine cewa dukkan abubuwa an kammala su sau ɗaya kuma sau ɗaya kawai.
///
/// Ana amfani da algorithm 2 idan `left + right` babba ne amma `min(left, right)` karami ne don ya dace da ma'aji.
/// A `min(left, right)` abubuwa suna kofe uwa da buffer, `memmove` ne amfani da wasu, da kuma wadanda a kan buffer aka koma baya a cikin rami a kan kishiyar sashi na inda suka samo asali.
///
/// Algorithms ɗin da za'a iya tantance su da kyau sama da yadda `left + right` ya isa.
/// Algorithm 1 ana iya tantance shi ta hanyar cuwa-cuwa da kuma yin zagaye da yawa lokaci guda, amma akwai 'yan kaɗan zagaye a matsakaita har zuwa `left + right` yana da girma, kuma mafi munin yanayi na zagaye ɗaya koyaushe yana wurin.
/// Madadin haka, algorithm 3 yayi amfani da sauya abubuwa na abubuwa `min(left, right)` har sai an bar ƙaramar matsalar juyawa.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// lokacin da `left < right` sauyawa yake faruwa daga hagu maimakon.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algorithms na ƙasa na iya kasa idan ba a bincika waɗannan shari'o'in ba
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks ya nuna cewa matsakaicin aiki don canjin canjin ya fi kyau har zuwa kusan `left + right == 32`, amma mafi munin yanayin aiki ya karye har kusan 16.
            // 24 da aka zaba a matsayin tsakiyar ƙasa.
            // Idan girman `T` ya fi na 4 ``usize`s girma, wannan algorithm ɗin ya kuma zarce sauran matakan.
            //
            //
            let x = unsafe { mid.sub(left) };
            // farkon zagayen farko
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` za a iya samu kafin hannu da kirga `gcd(left + right, right)`, amma shi ne sauri yi daya madauki wanda calculates da GCD matsayin gefen sakamako, to, yin Sauran bantara
            //
            //
            let mut gcd = right;
            // alamomi sun nuna cewa ya fi sauri a sauya musayar bayanai ta hanya gaba daya maimakon karanta daya na wucin gadi sau daya, yin kwafa a baya, sannan rubuta wancan na wucin gadi a karshen.
            // Wannan yana yiwuwa ne saboda gaskiyar canzawa ko maye gurbin amfani da adreshin ƙwaƙwalwa ɗaya kawai a cikin madauki maimakon buƙatar sarrafa abubuwa biyu.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // maimakon haɓaka `i` sannan kuma bincika idan yana waje da iyakoki, muna bincika idan `i` zai fita waje da kan iyakan gaba.
                // Wannan yana hana kowane nuni na zane ko `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // karshen zagayen farko
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // wannan sharadin dole ne ya kasance anan idan `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // gama chunk tare da ƙarin zagaye
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ba nau'in sifiri bane, don haka yana da kyau a raba ta girmanta.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 `[T; 0]` anan shine tabbatar da cewa wannan ya dace daidai da T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Akwai wata hanyar musanya wacce take tattare da gano inda musanya ta ƙarshe ta wannan algorithm ɗin zata kasance, kuma musanyawa ta amfani da wannan ƙwanƙwasa na ƙarshe maimakon musanya ɓangarorin da suke kusa da su kamar yadda wannan algorithm yake yi, amma wannan hanyar har yanzu tana da sauri.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}