//! Macros wanda masu amfani da yanki ke amfani dashi.

// Liningirƙirarar_komai da len yana haifar da babban canji
macro_rules! is_empty {
    // Hanyar da muke saka tsawon tsayin ZST, wannan yana aiki duka don ZST da wanda ba ZST ba.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Don kawar da wasu shingen bincike (duba `position`), muna lissafin tsayin ta wata hanyar da ba zata.
// (An gwada ta `` codegen/yanki-matsayi-haddi-duba '')
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // wasu lokuta ana amfani dasu a cikin wani shinge mara aminci

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Wannan _cannot_ yana amfani da `unchecked_sub` saboda mun dogara da kunsa don wakiltar tsayin dogon ZST yan iterators.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Mun san cewa `start <= end`, don haka zai iya yin fiye da `offset_from`, wanda ke buƙatar ma'amala a ciki.
            // Ta hanyar kafa tutoci masu dacewa a nan za mu iya gaya wa LLVM wannan, wanda ke taimaka masa cire rajistan shiga na iyaka.
            // KYAUTA: Ta hanyar nau'in canzawa, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ta hanyar gaya ma LLVM cewa alamomin sun banbanta da madaidaitan nau'in girman nau'in, zai iya inganta `len() == 0` ƙasa zuwa `start == end` maimakon `(end - start) < size`.
            //
            // KYAUTA: Ta hanyar nau'in mara canzawa, masu nuna alama suna daidaita don haka
            //         tazara tsakanin su dole ne ya zama girman girman mai yawa
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// A raba definition na `Iter` da `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Yana dawo da farkon abu kuma yana motsa farkon mai fassarar gaba 1.
        // Improveswarai inganta aikin idan aka kwatanta shi da aikin da aka zayyana.
        // Dole ne mai yin rubutun ya zama fanko.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Yana dawo da abu na ƙarshe kuma yana motsa ƙarshen mai ba da baya zuwa 1.
        // Improveswarai inganta aikin idan aka kwatanta shi da aikin da aka zayyana.
        // Dole ne mai yin rubutun ya zama fanko.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Shrinks da iterator lokacin da T ne ZST, da motsi ƙarshen iterator da baya da `n`.
        // `n` dole ne ya wuce `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Aikin mataimaki don ƙirƙirar yanki daga maimaitawa.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // KYAUTA: an kirkiro mai maimaita ne daga yanki tare da nunawa
                // `self.ptr` da tsawon `len!(self)`.
                // Wannan yana tabbatar da cewa duk abubuwan da ake buƙata na `from_raw_parts` sun cika.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Aikin Taimako don matsar da farkon mai gabatarwar ta abubuwan `offset`, yana dawo da tsohon farawa.
            //
            // Ba amintacce saboda ƙimar dole ne ya wuce `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // KYAUTA: mai kiran ya tabbatar da cewa `offset` bai wuce `self.len()` ba,
                    // don haka wannan sabon alamar yana cikin `self` kuma don haka an tabbatar dashi mara aiki.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Aikin Taimako don matsawa ƙarshen maimaitawar baya ta abubuwan `offset`, dawo da sabon ƙarshen.
            //
            // Ba amintacce saboda ƙimar dole ne ya wuce `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // KYAUTA: mai kiran ya tabbatar da cewa `offset` bai wuce `self.len()` ba,
                    // wanda aka tabbatar ba zai cika `isize` ba.
                    // Hakanan, sakamakon mai nunawa yana cikin iyakokin `slice`, wanda ke cika sauran buƙatun don `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // za a iya aiwatar da shi da yanka, amma wannan yana hana iyakokin bincike

                // KYAUTA: Kiraye-kiraye na `assume` ba su da aminci tunda fara nuna alama
                // dole ne ya zama mara banza, kuma yanka akan wadanda ba ZSTs ba dole ne su sami maɓallin nuna mara ƙarewa.
                // A kira zuwa `next_unchecked!` shi ne hadari tun da muka duba idan iterator ne komai na farko.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Wannan mai maganar yanzu babu komai.
                    if mem::size_of::<T>() == 0 {
                        // Dole ne muyi shi ta wannan hanyar kamar yadda `ptr` bazai taɓa zama 0 ba, amma `end` na iya zama (saboda kunsawa).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // KYAUTA: ƙarshe ba zai iya zama 0 ba idan T ba ZST bane saboda ptr ba 0 bane kuma ƙarshe>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // KYAUTA: Muna kan iyaka.`post_inc_start` yayi daidai don ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Munyi watsi da aiwatar da tsoho, wanda ke amfani da `try_fold`, saboda wannan sauƙin aiwatarwa yana samar da ƙarancin LLVM IR kuma yana da sauri don tattarawa.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Munyi watsi da aiwatar da tsoho, wanda ke amfani da `try_fold`, saboda wannan sauƙin aiwatarwa yana samar da ƙarancin LLVM IR kuma yana da sauri don tattarawa.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Munyi watsi da aiwatar da tsoho, wanda ke amfani da `try_fold`, saboda wannan sauƙin aiwatarwa yana samar da ƙarancin LLVM IR kuma yana da sauri don tattarawa.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Munyi watsi da aiwatar da tsoho, wanda ke amfani da `try_fold`, saboda wannan sauƙin aiwatarwa yana samar da ƙarancin LLVM IR kuma yana da sauri don tattarawa.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Munyi watsi da aiwatar da tsoho, wanda ke amfani da `try_fold`, saboda wannan sauƙin aiwatarwa yana samar da ƙarancin LLVM IR kuma yana da sauri don tattarawa.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Munyi watsi da aiwatar da tsoho, wanda ke amfani da `try_fold`, saboda wannan sauƙin aiwatarwa yana samar da ƙarancin LLVM IR kuma yana da sauri don tattarawa.
            // Hakanan, `assume` yana guje wa bincika iyaka.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // KYAUTA: an tabbatar mana da kasancewa cikin iyakoki ta hanyar madauki mara iyaka:
                        // lokacin da `i >= n`, `self.next()` ya dawo da `None` kuma madauki ya karye.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Munyi watsi da aiwatar da tsoho, wanda ke amfani da `try_fold`, saboda wannan sauƙin aiwatarwa yana samar da ƙarancin LLVM IR kuma yana da sauri don tattarawa.
            // Hakanan, `assume` yana guje wa bincika iyaka.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // KYAUTA: `i` dole ne ya zama ƙasa da `n` tunda yana farawa a `n`
                        // kuma yana raguwa ne kawai.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // KYAUTA: mai kira dole ne ya bada tabbacin cewa `i` ya wuce iyaka
                // yanki mai tushe, don haka `i` ba zai iya mamaye `isize` ba, kuma ana ba da tabbaci ga nassoshi don komawa zuwa wani ɓangare na yanki kuma don haka an tabbatar da cewa yana da inganci.
                //
                // Hakanan ku lura cewa mai kiran ya kuma tabbatar mana da cewa ba a sake kiran mu da irin wannan jarin ba, kuma babu wasu hanyoyin da zasu isa ga wannan kudin da ake kira, saboda haka yana da inganci don maganar da aka dawo ta zama mai rikitarwa a yanayin
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // za a iya aiwatar da shi da yanka, amma wannan yana hana iyakokin bincike

                // KYAUTA: Kiraye-kiraye na `assume` ba su da aminci tunda farkon nuna alama dole ne ya zama ba komai,
                // kuma yanka a kan wadanda ba ZSTs ba dole ne su kasance suna nuna ƙarshen ƙarshen mara amfani.
                // Kira zuwa `next_back_unchecked!` yana cikin aminci tunda mun bincika idan mai magana bai fara komai ba.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Wannan mai maganar yanzu babu komai.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // KYAUTA: Muna kan iyaka.`pre_dec_end` yayi daidai har ma don ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}