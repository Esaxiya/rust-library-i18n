// ignore-tidy-filelength

//! Gudanar da yanki da magudi.
//!
//! Don ƙarin bayani duba [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Tsarin membobin membobin rust, an ɗauke su daga rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Wannan aikin na jama'a ne kawai saboda babu wata hanyar da za a iya hada kayan gwajin.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Yana dawo da adadin abubuwan da ke cikin yanki.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // KYAUTA: sauti mai kyau saboda mun rarraba filin tsawon azaman amfani (wanda dole ne ya zama)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // KYAUTA: wannan yana da aminci saboda `&[T]` da `FatPtr<T>` suna da tsari iri ɗaya.
            // `std` ne kawai ke iya yin wannan garantin.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Sauya tare da `crate::ptr::metadata(self)` lokacin da wancan ya daidaita.
            // Ya zuwa wannan rubutun wannan yana haifar da kuskuren "Const-stable functions can only call other const-stable functions".
            //

            // KYAUTA: Samun damar ƙimar daga ƙungiyar `PtrRepr` amintacce ne tun * const T
            // da kuma PtrComponents<T>suna da shimfidar ƙwaƙwalwar ajiya iri ɗaya.
            // std ne kawai ke iya yin wannan garantin.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Yana dawowa `true` idan yanki yanada tsayin 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Yana dawo da farkon farkon yanki, ko `None` idan babu komai.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ya dawo da alamar nuna alama ga yanki na farko na yanki, ko `None` idan babu komai a ciki.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ya dawo na farko da duk sauran abubuwan yankan, ko `None` idan babu komai.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ya dawo na farko da duk sauran abubuwan yankan, ko `None` idan babu komai.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ya dawo na ƙarshe da duk sauran abubuwan yanki, ko `None` idan babu komai.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ya dawo na ƙarshe da duk sauran abubuwan yanki, ko `None` idan babu komai.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ya dawo da ɓangaren ƙarshe na yanki, ko `None` idan babu komai.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ya dawo da alamar nuna alama ga abu na ƙarshe a yanki.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Mayar da magana zuwa ga wani abu ko ƙarami dangane da nau'in fihirisar.
    ///
    /// - Idan aka ba shi matsayi, ya dawo da ma'anar abin da ke wannan matsayin ko `None` idan ya wuce iyaka.
    ///
    /// - Idan aka ba shi kewayo, zai dawo da ƙaramin kamfanin da ya dace da wannan zangon, ko `None` idan ya wuce iyaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Yana dawo da ambaton canzawa zuwa wani abu ko ƙarami dangane da nau'in fihirisa (duba [`get`]) ko `None` idan ƙididdigar ta wuce iyaka.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Ya dawo da tunani zuwa ga wani abu ko ƙarami, ba tare da yin duba iyaka ba.
    ///
    /// Don amintaccen madadin duba [`get`].
    ///
    /// # Safety
    ///
    /// Kira wannan hanyar tare da ma'aunin wuce gona da iri shine *[halin da ba a bayyana ba]* koda kuwa ba ayi amfani da abin da ya haifar ba.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // KYAUTA: mai kira dole ne ya kiyaye yawancin bukatun aminci don `get_unchecked`;
        // yanki ba zai yiwu ba saboda `self` amintacce ne.
        // Maɓallin da aka dawo yana da aminci saboda abubuwan da aka samu na `SliceIndex` dole ne su tabbatar da cewa hakan ne.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Yana dawo da ambaton canjin yanayi zuwa wani abu ko ƙarami, ba tare da yin iyakar binciken ba.
    ///
    /// Don amintaccen madadin duba [`get_mut`].
    ///
    /// # Safety
    ///
    /// Kira wannan hanyar tare da ma'aunin wuce gona da iri shine *[halin da ba a bayyana ba]* koda kuwa ba ayi amfani da abin da ya haifar ba.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // KYAUTA: mai kira dole ne ya bi ƙa'idodin aminci don `get_unchecked_mut`;
        // yanki ba zai yiwu ba saboda `self` amintacce ne.
        // Maɓallin da aka dawo yana da aminci saboda abubuwan da aka samu na `SliceIndex` dole ne su tabbatar da cewa hakan ne.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Yana dawo da ɗan manunin manuni zuwa maɓallin ajiyar yanki.
    ///
    /// Wajibi ne mai kiran ya tabbatar cewa yanki ya fi mai nunawa wannan aikin damar dawowa, in ba haka ba zai ƙare da nuna shara.
    ///
    /// Wajibi ne mai kiran ya tabbatar cewa ba a rubuta memorin da mai nuna alamar (non-transitively) ya nuna ba (sai dai a cikin `UnsafeCell`) ta amfani da wannan alamar ko kuma duk wata alama da aka samo daga gare ta.
    /// Idan kana buƙatar canzawa abubuwan da ke cikin yanki, yi amfani da [`as_mut_ptr`].
    ///
    /// Gyara kwantena da wannan yanki ya ambata zai iya sa a sake saita abin da yake ajiyewa, wanda hakan kuma zai sa duk wasu alamu da ke nuna ba su da inganci.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Yana dawo da maɓallin canjin yanayi mai aminci zuwa maɓallin ajiyar yanki.
    ///
    /// Wajibi ne mai kiran ya tabbatar cewa yanki ya fi mai nunawa wannan aikin damar dawowa, in ba haka ba zai ƙare da nuna shara.
    ///
    /// Gyara kwantena da wannan yanki ya ambata zai iya sa a sake saita abin da yake ajiyewa, wanda hakan kuma zai sa duk wasu alamu da ke nuna ba su da inganci.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Ya dawo da alamomi biyu masu ma'ana wanda ya shafi yanki.
    ///
    /// Yankin da aka dawo ya bude rabin, wanda ke nufin cewa mai nuna karshen zai nuna *daya ya wuce* bangaren karshe na yanki.
    /// Wannan hanya, wani komai a yanki da aka wakilta biyu daidai pointers, da kuma bambanci tsakanin biyu pointers wakiltar girman da yanki.
    ///
    /// Duba [`as_ptr`] don gargadi akan amfani da waɗannan alamomin.A karshen akan bukatar karin hankali, kamar yadda ba ya nuna wani inganci kashi a cikin yanki.
    ///
    /// Wannan aikin yana da amfani don ma'amala tare da abubuwan musayar waje waɗanda suke amfani da alamomi guda biyu don komawa zuwa kewayon abubuwa a cikin ƙwaƙwalwa, kamar yadda yake a C++ .
    ///
    ///
    /// Hakanan yana iya zama da amfani a bincika idan mai nuna alama zuwa wani ɓangare yana nufin ɓangaren wannan yanki:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // KYAUTA: `add` a nan yana da aminci, saboda:
        //
        //   - Dukkanin bayanan suna cikin abu guda, kamar yadda yake nuna abu kai tsaye shima yana kirgawa.
        //
        //   - Girman yanki bai fi girma fiye da baiti isize::MAX ba, kamar yadda aka lura a nan:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Babu kunsawa a ciki, saboda yankan baya rufe ƙarshen adireshin adireshin.
        //
        // Duba takaddun shaida na pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ya dawo da alamomin can can biyu marasa aminci waɗanda suka shafi yanki.
    ///
    /// Yankin da aka dawo ya bude rabin, wanda ke nufin cewa mai nuna karshen zai nuna *daya ya wuce* bangaren karshe na yanki.
    /// Wannan hanya, wani komai a yanki da aka wakilta biyu daidai pointers, da kuma bambanci tsakanin biyu pointers wakiltar girman da yanki.
    ///
    /// Duba [`as_mut_ptr`] don gargadi akan amfani da waɗannan alamomin.
    /// Inarshen alamomin yana buƙatar ƙarin taka tsantsan, saboda ba ya nusar da wani ingantaccen abu a cikin yanki.
    ///
    /// Wannan aikin yana da amfani don ma'amala tare da abubuwan musayar waje waɗanda suke amfani da alamomi guda biyu don komawa zuwa kewayon abubuwa a cikin ƙwaƙwalwa, kamar yadda yake a C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // KYAUTA: Duba as_ptr_range() a sama don me yasa `add` a nan lafiya.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Sauya abubuwa biyu a cikin yanki.
    ///
    /// # Arguments
    ///
    /// * a, Fihirisar farkon sinadari
    /// * b, Fihirisar kashi na biyu
    ///
    /// # Panics
    ///
    /// Panics idan `a` ko `b` sun wuce iyaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ba za a iya karɓar lamuni guda biyu masu canzawa daga vector ba, don haka maimakon amfani da mahimman alamun.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // KYAUTA: `pa` da `pb` an halicce su daga nassoshi masu canzawa da aminci
        // zuwa abubuwa a cikin yanki kuma sabili da haka an ba da tabbacin su zama masu inganci kuma masu daidaito.
        // Lura cewa samun damar abubuwan da ke bayan `a` da `b` an bincika kuma zai panic lokacin da bai wuce iyaka ba.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ya juya tsarin abubuwa a cikin yanki, a wuri.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Don ƙananan nau'ikan, duk mutumin da ya karanta a hanyar da aka saba yayi rashin aiki.
        // Zamu iya yin mafi kyau, idan aka bamu ingantaccen load/store, ta hanyar ɗora babban yanki da juya rajista.
        //

        // Fi dacewa LLVM zai yi wannan a gare mu, kamar yadda ya sani fiye da yadda muka yi ko unaligned karanta ne m (tun da canje-canje tsakanin daban-daban hannu versions, misali) da kuma abin da mafi kyau bantara size zai zama.
        // Abun takaici, kamar na LLVM 4.0 (2017-05) kawai yana kwance madauki, don haka muna buƙatar yin wannan da kanmu.
        // (Tsinkaya: baya baya da matsala saboda bangarorin za su iya daidaita daban-zai kasance, lokacin da tsayin ba shi da kyau-don haka babu wata hanyar fitar da gaba da bayanta don amfani da daidaitaccen SIMD a tsakiya.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Yi amfani da yanayin llvm.bswap don juya u8s a cikin amfani
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // KYAUTA: Akwai abubuwa da yawa don bincika anan:
                //
                // - Note cewa `chunk` ne ko dai 4 ko 8 saboda da cfg rajistan shiga sama.Don haka `chunk - 1` tabbatacce ne.
                // - Nunawa tare da index `i` yayi kyau kamar yadda madauki rajistan ya tabbatar
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Nunawa tare da index `ln - i - chunk = ln - (i + chunk)` yayi kyau:
                //   - `i + chunk > 0` ne trivially gaskiya.
                //   - Duba madauki ya tabbatar:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, saboda haka ragi ba ya ambaliya.
                // - `read_unaligned` da `write_unaligned` kira suna lafiya:
                //   - `pa` maki zuwa index `i` inda `i < ln / 2 - (chunk - 1)` (duba sama) da `pb` maki zuwa index `ln - i - chunk`, don haka duka biyu aƙalla `chunk` yawancin baiti nesa da ƙarshen `self`.
                //
                //   - Duk wani tunanin da aka fara yana da inganci `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Yi amfani da juyawa-zuwa-16 don juya u16s a cikin u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // KYAUTA: Za'a iya karanta u32 mara daidaituwa daga `i` idan `i + 1 < ln`
                // (kuma a bayyane yake `i < ln`), saboda kowane yanki yanki ne 2 kuma muna karanta 4.
                //
                // `i + chunk - 1 < ln / 2` # yayin yanayin
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Tunda yana ƙasa da tsayin da aka raba 2, to lallai ne ya zama yana da iyaka.
                //
                // Wannan kuma yana nufin cewa ana girmama yanayin `0 < i + chunk <= ln` koyaushe, yana tabbatar da za a iya amfani da alamar `pb` lafiya.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // KYAUTA: `i` bai kai rabin tsayin yanki ba saboda haka
            // samun dama ga `i` da `ln - i - 1` amintacce ne (`i` yana farawa daga 0 kuma ba zai ci gaba fiye da `ln / 2 - 1` ba).
            // Abubuwan da aka samo na `pa` da `pb` saboda haka suna da inganci kuma suna daidaita, kuma ana iya karanta su daga kuma rubuta su.
            //
            //
            unsafe {
                // Matsera canza su kauce wa haddi duba a hadari canza.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Ya dawo da mai magana akan yanki.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Ya dawo da mai magana wanda zai ba da damar gyaggyara kowane ƙimar.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Ya dawo da mai yin magana akan dukkan nau'ikan windows na tsawon `size`.
    /// A windows zoba.
    /// Idan yanki ya fi guntu fiye da `size`, mai maimaitawar ba zai sake dawo da martaba ba.
    ///
    /// # Panics
    ///
    /// Panics idan `size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Idan yanki ya fi guntu fiye da `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Yana dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga farkon yanki.
    ///
    /// Can guntun ne yanka kuma ba su zoba.Idan `chunk_size` bai raba tsawon yanki ba, to ɓangaren ƙarshe ba zai sami tsawon `chunk_size` ba.
    ///
    /// Duba [`chunks_exact`] don bambance-bambancen wannan mai ba da labarin wanda ya dawo da abubuwan da suka dace da abubuwan `chunk_size` koyaushe, da [`rchunks`] don mai maimaita iri ɗaya amma farawa a ƙarshen yanki.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Yana dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga farkon yanki.
    ///
    /// Thean guntun yankan ne masu juyawa, kuma basa haɗuwa.Idan `chunk_size` ba raba tsawon na yanki, sa'an nan na karshe bantara ba zai yi tsawon `chunk_size`.
    ///
    /// Duba [`chunks_exact_mut`] don bambance-bambancen wannan mai ba da labarin wanda ya dawo da abubuwan da suka dace da abubuwan `chunk_size` koyaushe, da [`rchunks_mut`] don mai maimaita iri ɗaya amma farawa a ƙarshen yanki.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Yana dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga farkon yanki.
    ///
    /// Can guntun ne yanka kuma ba su zoba.
    /// Idan `chunk_size` ba raba tsawon na yanki, sa'an nan na karshe har zuwa `chunk_size-1` abubuwa za a tsallake da za a iya dawo da na'urar daga `remainder` aiki na iterator.
    ///
    ///
    /// Saboda kowane yanki da ke da abubuwan `chunk_size` daidai, mai harhadawa na iya sauƙaƙe lambar da aka samu fiye da ta [`chunks`].
    ///
    /// Duba [`chunks`] don bambancin wannan mai magana wanda shima ya dawo da ragowar a matsayin ƙaramin ƙarami, da [`rchunks_exact`] don mai maimaita abu ɗaya amma farawa a ƙarshen yanki.
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Yana dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga farkon yanki.
    ///
    /// Thean guntun yankan ne masu juyawa, kuma basa haɗuwa.
    /// Idan `chunk_size` bai raba tsawon yanki ba, to daga karshe har zuwa abubuwan `chunk_size-1` za'a tsallake kuma za'a iya dawo dasu daga aikin `into_remainder` na mai magana.
    ///
    ///
    /// Saboda kowane yanki da ke da abubuwan `chunk_size` daidai, mai harhadawa na iya sauƙaƙe lambar da aka samu fiye da ta [`chunks_mut`].
    ///
    /// Duba [`chunks_mut`] don bambancin wannan mai magana wanda shima ya dawo da ragowar a matsayin ƙaramin ƙarami, da [`rchunks_exact_mut`] don mai maimaita abu ɗaya amma farawa a ƙarshen yanki.
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Ya raba yanki a cikin yanki na 'N`-element arrays, a zaton cewa babu sauran.
    ///
    ///
    /// # Safety
    ///
    /// Ana iya kiran wannan lokacin kawai
    /// - Yankin ya kasu daidai cikin ``N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // KIYAYE: 1-element chunks basu da sauran
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // KYAUTA: Tsawon yanki (6) ya ninka na 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Waɗannan ba su da kyau:
    /// // bari yankakku: &[[_;5]]= slice.as_chunks_unchecked()//The yanki tsawon ba ninkin 5 bari chunks:&[[_;0]]= slice.as_chunks_unchecked()//Ba a yarda da gutsure-tsalle masu tsayin daka ba
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KYAUTA: Halinmu shine ainihin abin da ake buƙata don kiran wannan
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KYAUTA: Mun jefa yanki na abubuwan `new_len * N` a ciki
        // yanki na `new_len` abubuwa da yawa na abubuwan `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Ya raba yanki a cikin yanki na 'N`-element arrays, farawa daga farkon yanki, da kuma wani yanki da ya rage da tsayinsa kasa da `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `N` ya kasance 0. Wannan binciken zai yiwu a canza shi zuwa tattara kuskuren lokaci kafin wannan hanyar ta daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // KYAUTA: Mun riga mun firgita don sifili, kuma an tabbatar da shi ta hanyar gini
        // cewa tsawon na subslice ke ninkin N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Ya raba yanki a cikin yanki na 'N`-element arrays, farawa a ƙarshen yanki, da kuma wani yanki da ya rage da tsayin da yake ƙasa da `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `N` ya kasance 0. Wannan binciken zai yiwu a canza shi zuwa tattara kuskuren lokaci kafin wannan hanyar ta daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // KYAUTA: Mun riga mun firgita don sifili, kuma an tabbatar da shi ta hanyar gini
        // cewa tsawon na subslice ke ninkin N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Yana dawo da mai magana akan abubuwan `N` na yanki a lokaci ɗaya, yana farawa daga farkon yanki.
    ///
    /// Hunungiyoyin sune bayanan tsararru kuma ba sa juyewa.
    /// Idan `N` bai raba tsawon yanki ba, to daga karshe har zuwa abubuwan `N-1` za'a tsallake kuma za'a iya dawo dasu daga aikin `remainder` na mai maimaitawa.
    ///
    ///
    /// Wannan hanyar ita ce daidai da [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics idan `N` ya kasance 0. Wannan binciken zai yiwu a canza shi zuwa tattara kuskuren lokaci kafin wannan hanyar ta daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Ya raba yanki a cikin yanki na 'N`-element arrays, a zaton cewa babu sauran.
    ///
    ///
    /// # Safety
    ///
    /// Ana iya kiran wannan lokacin kawai
    /// - Yankin ya kasu daidai cikin ``N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // KIYAYE: 1-element chunks basu da sauran
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // KYAUTA: Tsawon yanki (6) ya ninka na 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Waɗannan ba su da kyau:
    /// // bari yankakku: &[[_;5]]= slice.as_chunks_unchecked_mut()//Tsawon yanki ba ninkin ba ne na 5 bari yankakku:&[[_;0]]= slice.as_chunks_unchecked_mut()//Zero-tsawon chunks an taba yarda
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KYAUTA: Halinmu shine ainihin abin da ake buƙata don kiran wannan
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KYAUTA: Mun jefa yanki na abubuwan `new_len * N` a ciki
        // yanki na `new_len` abubuwa da yawa na abubuwan `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Ya raba yanki a cikin yanki na 'N`-element arrays, farawa daga farkon yanki, da kuma wani yanki da ya rage da tsayinsa kasa da `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `N` ya kasance 0. Wannan binciken zai yiwu a canza shi zuwa tattara kuskuren lokaci kafin wannan hanyar ta daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // KYAUTA: Mun riga mun firgita don sifili, kuma an tabbatar da shi ta hanyar gini
        // cewa tsawon na subslice ke ninkin N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Ya raba yanki a cikin yanki na 'N`-element arrays, farawa a ƙarshen yanki, da kuma wani yanki da ya rage da tsayin da yake ƙasa da `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `N` ya kasance 0. Wannan binciken zai yiwu a canza shi zuwa tattara kuskuren lokaci kafin wannan hanyar ta daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // KYAUTA: Mun riga mun firgita don sifili, kuma an tabbatar da shi ta hanyar gini
        // cewa tsawon na subslice ke ninkin N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Yana dawo da mai magana akan abubuwan `N` na yanki a lokaci ɗaya, yana farawa daga farkon yanki.
    ///
    /// Hunasusoshin suna da nassoshi tsararrun abubuwa kuma basa cikawa.
    /// Idan `N` bai raba tsawon yanki ba, to daga karshe har zuwa abubuwan `N-1` za'a tsallake kuma za'a iya dawo dasu daga aikin `into_remainder` na mai magana.
    ///
    ///
    /// Wannan hanyar ita ce daidai da [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics idan `N` ya kasance 0. Wannan binciken zai yiwu a canza shi zuwa tattara kuskuren lokaci kafin wannan hanyar ta daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Ya dawo da mai magana akan abin da ya rufe akan windows na abubuwan `N` na yanki, farawa a farkon yanki.
    ///
    ///
    /// Wannan kwatankwacin jimlar [`windows`].
    ///
    /// Idan `N` ya fi girman yanki, ba zai dawo da windows ba.
    ///
    /// # Panics
    ///
    /// Panics idan `N` shine 0.
    /// Wannan rajistan zai fi yiwuwa a canza shi zuwa tattara kuskuren lokaci kafin wannan hanyar ta daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Ya dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga ƙarshen yanki.
    ///
    /// Can guntun ne yanka kuma ba su zoba.Idan `chunk_size` bai raba tsawon yanki ba, to ɓangaren ƙarshe ba zai sami tsawon `chunk_size` ba.
    ///
    /// Duba [`rchunks_exact`] don bambance-bambancen wannan mai ba da labarin wanda ya dawo da rarar abubuwan abubuwan `chunk_size` koyaushe daidai, da [`chunks`] don mai maimaita abu ɗaya amma farawa a farkon yanki.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Ya dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga ƙarshen yanki.
    ///
    /// Thean guntun yankan ne masu juyawa, kuma basa haɗuwa.Idan `chunk_size` ba raba tsawon na yanki, sa'an nan na karshe bantara ba zai yi tsawon `chunk_size`.
    ///
    /// Duba [`rchunks_exact_mut`] don bambance-bambancen wannan mai ba da labarin wanda ya dawo da rarar abubuwan abubuwan `chunk_size` koyaushe daidai, da [`chunks_mut`] don mai maimaita abu ɗaya amma farawa a farkon yanki.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Ya dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga ƙarshen yanki.
    ///
    /// Can guntun ne yanka kuma ba su zoba.
    /// Idan `chunk_size` ba raba tsawon na yanki, sa'an nan na karshe har zuwa `chunk_size-1` abubuwa za a tsallake da za a iya dawo da na'urar daga `remainder` aiki na iterator.
    ///
    /// Saboda kowane yanki da ke da abubuwan `chunk_size` daidai, mai harhadawa na iya sauƙaƙe lambar da aka samu fiye da ta [`chunks`].
    ///
    /// Duba [`rchunks`] don bambance-bambancen wannan mai magana wanda kuma ya dawo da ragowar a matsayin ƙaramin ƙarami, da [`chunks_exact`] don mai maimaita abu ɗaya amma farawa a farkon yanki.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Ya dawo da mai magana akan abubuwan `chunk_size` na yanki a lokaci ɗaya, yana farawa daga ƙarshen yanki.
    ///
    /// Thean guntun yankan ne masu juyawa, kuma basa haɗuwa.
    /// Idan `chunk_size` bai raba tsawon yanki ba, to daga karshe har zuwa abubuwan `chunk_size-1` za'a tsallake kuma za'a iya dawo dasu daga aikin `into_remainder` na mai magana.
    ///
    /// Saboda kowane yanki da ke da abubuwan `chunk_size` daidai, mai harhadawa na iya sauƙaƙe lambar da aka samu fiye da ta [`chunks_mut`].
    ///
    /// Duba [`rchunks_mut`] don bambance-bambancen wannan mai magana wanda kuma ya dawo da ragowar a matsayin ƙaramin ƙarami, da [`chunks_exact_mut`] don mai maimaita abu ɗaya amma farawa a farkon yanki.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `chunk_size` shine 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Yana dawo da wani mai magana akan yanki wanda yake samarda abubuwanda basuda jujjuya abubuwa ta amfani da magatakarda don raba su.
    ///
    /// An kira wanda aka ambata a abubuwa biyu da ke bin kawunansu, yana nufin ana kiran mai duba a kan `slice[0]` da `slice[1]` sannan a kan `slice[1]` da `slice[2]` da sauransu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ana iya amfani da wannan hanyar don cire samfuran da aka tsara:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Yana dawo da wani mai magana akan yanki wanda yake samarda abubuwa masu jujjuyawar abubuwa ta amfani da magatakarda don raba su.
    ///
    /// An kira wanda aka ambata a abubuwa biyu da ke bin kawunansu, yana nufin ana kiran mai duba a kan `slice[0]` da `slice[1]` sannan a kan `slice[1]` da `slice[2]` da sauransu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ana iya amfani da wannan hanyar don cire samfuran da aka tsara:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Ya raba yanki ɗaya zuwa biyu a kan fihirisa.
    ///
    /// Na farko zai ƙunshi dukkan fihirisa daga `[0, mid)` (ban da index `mid` kanta) kuma na biyun zai ƙunshi dukkan fihirisa daga `[mid, len)` (ban da index `len` kanta).
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // KYAUTA: `[ptr; mid]` da `[mid; len]` suna cikin `self`, wanda
        // cika bukatun `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Ya raba yanki mai canzawa zuwa biyu a kan fihirisa.
    ///
    /// Na farko zai ƙunshi dukkan fihirisa daga `[0, mid)` (ban da index `mid` kanta) kuma na biyun zai ƙunshi dukkan fihirisa daga `[mid, len)` (ban da index `len` kanta).
    ///
    ///
    /// # Panics
    ///
    /// Panics idan `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // KYAUTA: `[ptr; mid]` da `[mid; len]` suna cikin `self`, wanda
        // cika bukatun `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Ya raba yanki biyu zuwa biyu a kan ma'auni, ba tare da yin binciken iyaka ba.
    ///
    /// Na farko zai ƙunshi dukkan fihirisa daga `[0, mid)` (ban da index `mid` kanta) kuma na biyun zai ƙunshi dukkan fihirisa daga `[mid, len)` (ban da index `len` kanta).
    ///
    ///
    /// Don amintaccen madadin duba [`split_at`].
    ///
    /// # Safety
    ///
    /// Kira wannan hanyar tare da ma'aunin wuce gona da iri shine *[halin da ba a bayyana ba]* koda kuwa ba ayi amfani da abin da ya haifar ba.Da mai kira yana tabbatar da cewa `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // KYAUTA: Mai kira ya bincika wannan `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Ya raba yanki mai canzawa zuwa biyu a kan fihirisa, ba tare da bincika iyaka ba.
    ///
    /// Na farko zai ƙunshi dukkan fihirisa daga `[0, mid)` (ban da index `mid` kanta) kuma na biyun zai ƙunshi dukkan fihirisa daga `[mid, len)` (ban da index `len` kanta).
    ///
    ///
    /// Don amintaccen madadin duba [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Kira wannan hanyar tare da ma'aunin wuce gona da iri shine *[halin da ba a bayyana ba]* koda kuwa ba ayi amfani da abin da ya haifar ba.Da mai kira yana tabbatar da cewa `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // KYAUTA: Mai kira ya bincika wannan `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` kuma `[mid; len]` ba overlapping, don haka dawo a mutable tunani ne m.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Ya dawo da mai magana akan abubuwan da aka raba su ta hanyar abubuwan da suka dace da `pred`.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Idan farkon abu ya yi daidai, yanki mara komai zai zama farkon abu da mai magana zai dawo.
    /// Hakanan, idan abu na ƙarshe a cikin yanki ya yi daidai, yanki mara komai zai zama abu na ƙarshe da mai magana zai dawo da shi:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Idan abubuwa biyu da suka dace suka kasance kusa da kai tsaye, za a sami yanki mara dadi a tsakaninsu:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Ya dawo da mai magana akan abubuwan da za'a iya canzawa wadanda abubuwa suka dace da `pred`.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Ya dawo da mai magana akan abubuwan da aka raba su ta hanyar abubuwan da suka dace da `pred`.
    /// Abubuwan da suka dace sun ƙunshe ne a ƙarshen ƙaramin aikin da ya gabata azaman mai ƙarshe.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Idan ɓangaren ƙarshe na yanki ya yi daidai, wannan ɓangaren za a yi la'akari da ƙarshen mai yanki.
    ///
    /// Wannan yanki shine zai zama abu na karshe da mai gabatarwar ya dawo dashi.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Ya dawo da mai magana akan abubuwan da za'a iya canzawa wadanda abubuwa suka dace da `pred`.
    /// Abubuwan da suka dace sun kasance a cikin ƙaramin ƙaramin aiki azaman mai ƙarshe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Koma wani iterator kan subslices rabu da abubuwa da suka yi daidai `pred`, da suka fara a karshen na yanki da kuma aiki da baya.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kamar yadda yake tare da `split()`, idan abu na farko ko na ƙarshe ya dace, yanki mara komai zai zama abu na farko (ko na ƙarshe) wanda mai maimaitawar ya dawo dashi.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Ya dawo da mai magana akan ƙananan hanyoyin da za'a iya canzawa wanda abubuwa suka dace da `pred`, farawa a ƙarshen yanki da kuma aiki a baya.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Ya dawo da mai magana akan abubuwan da aka raba su ta hanyar abubuwan da suka dace da `pred`, iyakance ga dawowa a mafi yawan abubuwan `n`.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// Abu na karshe da aka dawo dashi, idan akwai, zai ƙunshi sauran ɓangaren.
    ///
    /// # Examples
    ///
    /// Print da yanki tsaga da zarar ta lambobin raba su da 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Ya dawo da mai magana akan abubuwan da aka raba su ta hanyar abubuwan da suka dace da `pred`, iyakance ga dawowa a mafi yawan abubuwan `n`.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// Abu na karshe da aka dawo dashi, idan akwai, zai ƙunshi sauran ɓangaren.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Ya dawo da mai magana akan abubuwan da aka raba su ta hanyar abubuwan da suka dace da `pred` iyakance zuwa dawowa a mafi yawan abubuwan `n`.
    /// Wannan yana farawa a ƙarshen yanki kuma yana aiki a baya.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// Abu na karshe da aka dawo dashi, idan akwai, zai ƙunshi sauran ɓangaren.
    ///
    /// # Examples
    ///
    /// Buga ɓangaren raba sau ɗaya, farawa daga ƙarshe, ta lambobin da za a iya rarraba su 3 (watau, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Ya dawo da mai magana akan abubuwan da aka raba su ta hanyar abubuwan da suka dace da `pred` iyakance zuwa dawowa a mafi yawan abubuwan `n`.
    /// Wannan yana farawa a ƙarshen yanki kuma yana aiki a baya.
    /// Abubuwan da ya dace bai ƙunshi cikin ƙaramin yanki ba.
    ///
    /// Abu na karshe da aka dawo dashi, idan akwai, zai ƙunshi sauran ɓangaren.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Yana dawo da `true` idan yanki ya ƙunshi abu tare da ƙimar da aka bayar.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Idan baka da `&T`, amma kawai `&U` irin wannan `T: Borrow<U>` (misali
    /// Kirtani: aro<str>``), zaku iya amfani da `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // yanki na `String`
    /// assert!(v.iter().any(|e| e == "hello")); // bincika tare da `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Yana dawo da `true` idan `needle` prefix ne na yanki.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Koyaushe yana dawo da `true` idan `needle` fansa ce mara komai:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Yana dawowa `true` idan `needle` shine mafi mahimmancin yanki.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Koyaushe yana dawo da `true` idan `needle` fansa ce mara komai:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Ya dawo da ƙaramin yanki tare da cire prefix ɗin da aka cire.
    ///
    /// Idan yanki ya fara da `prefix`, zai dawo da ƙaramin yanki bayan prefix ɗin, wanda aka nannade cikin `Some`.
    /// Idan `prefix` fanko ne, kawai ya dawo da yanki na asali.
    ///
    /// Idan yanki bai fara da `prefix` ba, zai dawo da `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Wannan aikin zai buƙaci sake rubutawa idan kuma yaushe SlicePattern ya zama mai ƙwarewa.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Ya dawo da icean kasuwa tare da cire fiarin
    ///
    /// Idan yanki ya ƙare da `suffix`, ya dawo da ƙaramar kafin raƙuman, an nannade shi a cikin `Some`.
    /// Idan `suffix` fanko ne, kawai ya dawo da yanki na asali.
    ///
    /// Idan yanki ba ya kawo karshen tare da `suffix`, ya kõma `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Wannan aikin zai buƙaci sake rubutawa idan kuma yaushe SlicePattern ya zama mai ƙwarewa.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary binciko wannan yanki yanki don wani kashi.
    ///
    /// Idan an sami ƙimar to [`Result::Ok`] ya dawo, yana ɗauke da bayanan abubuwan da suka dace.
    /// Idan akwai wasanni da yawa, to za'a iya dawo da kowane ɗayan wasannin.
    /// Idan ba a sami ƙimar ba to [`Result::Err`] ya dawo, yana ɗauke da fihirisa inda za a saka abun da ya dace yayin kiyaye tsari.
    ///
    ///
    /// Duba kuma [`binary_search_by`], [`binary_search_by_key`], da [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ya duba jerin abubuwa hudu.
    /// Na farko an samo shi, tare da ƙayyadadden matsayi;na biyu da na uku ba a same su ba;na huɗu na iya daidaita kowane matsayi a cikin `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Idan kana son saka abu a cikin vector iri-iri, yayin rike tsari iri:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary yana bincika wannan yanki yanki tare da aikin kwatancen.
    ///
    /// Aikin kwatantawa ya kamata aiwatar da tsari daidai da nau'in tsari na yanki, dawo da lambar oda wacce ke nuna ko hujjarta ita ce `Less`, `Equal` ko `Greater` abin da ake so.
    ///
    ///
    /// Idan an sami ƙimar to [`Result::Ok`] ya dawo, yana ɗauke da bayanan abubuwan da suka dace.Idan akwai wasanni da yawa, to za'a iya dawo da kowane ɗayan wasannin.
    /// Idan ba a sami ƙimar ba to [`Result::Err`] ya dawo, yana ɗauke da fihirisa inda za a saka abun da ya dace yayin kiyaye tsari.
    ///
    /// Duba kuma [`binary_search`], [`binary_search_by_key`], da [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ya duba jerin abubuwa hudu.Na farko an samo shi, tare da ƙayyadadden matsayi;na biyu da na uku ba a same su ba;na huɗu na iya daidaita kowane matsayi a cikin `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // KYAUTA: ana kiran lafiya ta waɗannan maɓallan:
            // - `mid >= 0`
            // - `mid < size`: `mid` yana iyakance ta hanyar `[left; right)` ɗaure.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Dalilin da yasa muke amfani da ikon sarrafa if/else maimakon wasa shine saboda ayyukan kwatancen rashin daidaito, wanda yake da matukar damuwa.
            //
            // Wannan shine x86 asm na u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary ya binciki wannan tsararren yanki tare da aikin hakar maɓalli.
    ///
    /// Ya ɗauka cewa an rarraba yanki ta maɓalli, misali tare da [`sort_by_key`] ta amfani da aikin hakar maɓalli iri ɗaya.
    ///
    /// Idan an sami ƙimar to [`Result::Ok`] ya dawo, yana ɗauke da bayanan abubuwan da suka dace.
    /// Idan akwai wasanni da yawa, to za'a iya dawo da kowane ɗayan wasannin.
    /// Idan ba a sami ƙimar ba to [`Result::Err`] ya dawo, yana ɗauke da fihirisa inda za a saka abun da ya dace yayin kiyaye tsari.
    ///
    ///
    /// Duba kuma [`binary_search`], [`binary_search_by`], da [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Yana kallon jerin abubuwa huɗu a cikin wani nau'i-nau'i nau'i-nau'i wanda aka tsara ta abubuwan su na biyu.
    /// Na farko an samo shi, tare da ƙayyadadden matsayi;na biyu da na uku ba a same su ba;na huɗu na iya daidaita kowane matsayi a cikin `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // An kyale Lint rustdoc::broken_intra_doc_links kamar yadda `slice::sort_by_key` ke cikin crate `alloc`, kuma saboda wannan bai wanzu ba yayin gina `core`.
    //
    // haɗin haɗin zuwa crate: #74481.Tunda ana rikodin abubuwan ƙira kawai a cikin libstd (#73423), wannan baya haifar da ɓata hanyoyin haɗin gwiwa a aikace.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ya ware yanki, amma maiyuwa ba zai iya kiyaye tsari na abubuwan daidai ba.
    ///
    /// Wannan nau'ikan ba shi da tabbas (watau, na iya sake sake tsara abubuwa daidai), a cikin-wuri (watau, baya rarrabawa), kuma *O*(*n*\*log(* n*)) mafi munin yanayi.
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Tsarin algorithm na yanzu ya dogara ne akan [pattern-defeating quicksort][pdqsort] na Orson Peters, wanda ya haɗu da matsakaiciyar shari'ar saurin bazuwa tare da mafi saurin mummunan yanayi, yayin cimma daidaitaccen lokaci akan yanka tare da wasu alamu.
    /// Yana amfani da wasu ƙididdiga don kauce wa rikice-rikice, amma tare da tsayayyen seed don koyaushe samar da halayyar ƙaddara.
    ///
    /// Yawanci yana da sauri fiye da daidaitaccen rarrabuwa, sai dai a cikin wasu lamuran musamman, misali, lokacin da yanki ya ƙunshi jerin jeri da yawa waɗanda aka haɗa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ya ware yanki tare da aikin kwatanta, amma maiyuwa ba zai iya kiyaye tsari na abubuwan daidai ba.
    ///
    /// Wannan nau'ikan ba shi da tabbas (watau, na iya sake sake tsara abubuwa daidai), a cikin-wuri (watau, baya rarrabawa), kuma *O*(*n*\*log(* n*)) mafi munin yanayi.
    ///
    /// Dole ne aikin kwatancen ya ayyana cikakken odar don abubuwan da ke cikin yanki.Idan oda bai zama cikakke ba, ba a bayyana oda abubuwan ba.Umarni shine tsari na duka idan ya kasance (ga duka `a`, `b` da `c`):
    ///
    /// * duka da antisymmetric: daidai ɗaya daga `a < b`, `a == b` ko `a > b` gaskiya ne, kuma
    /// * wucewa, `a < b` da `b < c` suna nuna `a < c`.Hakanan dole ne ya riƙe duka `==` da `>`.
    ///
    /// Misali, yayin da [`f64`] baya aiwatar da [`Ord`] saboda `NaN != NaN`, zamu iya amfani da `partial_cmp` azaman aikinmu idan muka san yanki bai ƙunshi `NaN` ba.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Tsarin algorithm na yanzu ya dogara ne akan [pattern-defeating quicksort][pdqsort] na Orson Peters, wanda ya haɗu da matsakaiciyar shari'ar saurin bazuwa tare da mafi saurin mummunan yanayi, yayin cimma daidaitaccen lokaci akan yanka tare da wasu alamu.
    /// Yana amfani da wasu ƙididdiga don kauce wa rikice-rikice, amma tare da tsayayyen seed don koyaushe samar da halayyar ƙaddara.
    ///
    /// Yawanci yana da sauri fiye da daidaitaccen rarrabuwa, sai dai a cikin wasu lamuran musamman, misali, lokacin da yanki ya ƙunshi jerin jeri da yawa waɗanda aka haɗa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // baya kasawa
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ya ware yanki tare da aikin hakar maɓalli, amma maiyuwa ba zai iya kiyaye tsari na abubuwan daidai ba.
    ///
    /// Wannan nau'in ba shi da tabbas (watau, na iya sake sake tsara abubuwa daidai), a-wuri (watau, baya rarrabawa), da kuma *O*(m\* * n *\* log(*n*)) mafi munin yanayi, inda maɓallin kewayawa yake *O*(*m*).
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Tsarin algorithm na yanzu ya dogara ne akan [pattern-defeating quicksort][pdqsort] na Orson Peters, wanda ya haɗu da matsakaiciyar shari'ar saurin bazuwa tare da mafi saurin mummunan yanayi, yayin cimma daidaitaccen lokaci akan yanka tare da wasu alamu.
    /// Yana amfani da wasu ƙididdiga don kauce wa rikice-rikice, amma tare da tsayayyen seed don koyaushe samar da halayyar ƙaddara.
    ///
    /// Saboda dabarun kiran maballin, [`sort_unstable_by_key`](#method.sort_unstable_by_key) na iya zama ya fi hankali fiye da [`sort_by_cached_key`](#method.sort_by_cached_key) a cikin yanayin inda aikin maɓallin ke da tsada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sake sarrafa yanki kamar yadda abun yake a `index` ya kasance a matsayi na ƙarshe.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Sake sarrafa yanki tare da aikin mai gwadawa kamar yadda abun yake a `index` ya kasance a matsayi na ƙarshe na ƙarshe.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Sake sarrafa yanki tare da aikin hakar maɓalli kamar abin da yake a `index` yana kan matsayinsa na ƙarshe.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Sake sarrafa yanki kamar yadda abun yake a `index` ya kasance a matsayi na ƙarshe.
    ///
    /// Wannan sake sake fasalin yana da ƙarin dukiyar cewa kowane ƙima a matsayin `i < index` zai zama ƙasa da ko daidaita da kowane ƙima a matsayi na `j > index`.
    /// Allyari, wannan sake sake fasalin ba shi da tabbas (watau
    /// kowane adadin abubuwa daidai zasu iya ƙarewa a matsayin `index`), a cikin-wuri (watau
    /// baya kasaftawa), kuma *O*(*n*) mafi munin yanayi.
    /// Wannan aikin ana kuma/san shi da "kth element" a cikin wasu ɗakunan karatu.
    /// Yana dawo da ninki uku na waɗannan ƙimomin masu zuwa: duk abubuwan da ke ƙasa da ɗaya a maɓallin da aka bayar, ƙimar da ke cikin maɓallin da aka bayar, kuma duk abubuwan da suka fi wanda yake a cikin bayanan da aka bayar.
    ///
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Algorithm na yanzu yana dogara ne akan yanki mai saurin zaɓi na irin wannan saurin saurin algorithm wanda aka yi amfani dashi don [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics lokacin `index >= len()`, ma'ana shi ko da yaushe panics a kan komai a yanka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Nemo tsakiyan
    /// v.select_nth_unstable(2);
    ///
    /// // An tabbatar mana da cewa yanki zai zama ɗayan masu zuwa, gwargwadon yadda muke tsara abubuwan da aka ƙayyade.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Sake sarrafa yanki tare da aikin mai gwadawa kamar yadda abun yake a `index` ya kasance a matsayi na ƙarshe na ƙarshe.
    ///
    /// Wannan reordering yana da ƙarin dukiya da wani darajar a matsayin `i < index` zai zama kasa fi ko daidai to wani darajar a matsayin `j > index` amfani da comparator aiki.
    /// Allyari, wannan sake daidaitawa ba shi da tabbas (watau kowane adadin abubuwa daidai zai iya ƙarewa a matsayin `index`), a cikin wuri (watau ba ya rarrabawa), da kuma *O*(*n*) mafi munin yanayi.
    /// Wannan aikin ana kiran shi "kth element" a cikin wasu ɗakunan karatu.
    /// Yana dawo da ninki uku na waɗannan ƙimomin masu zuwa: duk abubuwan da ke ƙasa da ɗaya a cikin bayanan da aka bayar, ƙimar da ke cikin maɓallin da aka bayar, da kuma duk abubuwan da suka fi wanda yake a cikin bayanan da aka bayar, ta yin amfani da aikin kwatancen da aka bayar.
    ///
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Algorithm na yanzu yana dogara ne akan yanki mai saurin zaɓi na irin wannan saurin saurin algorithm wanda aka yi amfani dashi don [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics lokacin `index >= len()`, ma'ana shi ko da yaushe panics a kan komai a yanka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Nemo tsakiyan kamar an sassara yanki yadda yake sauka.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // An tabbatar mana da cewa yanki zai zama ɗayan masu zuwa, gwargwadon yadda muke tsara abubuwan da aka ƙayyade.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Sake sarrafa yanki tare da aikin hakar maɓalli kamar abin da yake a `index` yana kan matsayinsa na ƙarshe.
    ///
    /// Wannan sake sake fasalin yana da ƙarin dukiyar cewa kowane ƙima a matsayi na `i < index` zai zama ƙasa da ko daidai da kowane ƙima a matsayi `j > index` ta amfani da aikin hakar maɓallin.
    /// Allyari, wannan sake daidaitawa ba shi da tabbas (watau kowane adadin abubuwa daidai zai iya ƙarewa a matsayin `index`), a cikin wuri (watau ba ya rarrabawa), da kuma *O*(*n*) mafi munin yanayi.
    /// Wannan aikin ana kiran shi "kth element" a cikin wasu ɗakunan karatu.
    /// Yana dawo da ninki uku na waɗannan ƙimomin masu zuwa: duk abubuwan da ke ƙasa da ɗaya a ma'aunin da aka bayar, ƙimar da ke cikin maɓallin da aka bayar, da kuma duk abubuwan da suka fi wanda yake a ƙididdigar da aka bayar, ta yin amfani da aikin hakar maɓallin da aka bayar.
    ///
    ///
    /// # Aiwatarwa a halin yanzu
    ///
    /// Algorithm na yanzu yana dogara ne akan yanki mai saurin zaɓi na irin wannan saurin saurin algorithm wanda aka yi amfani dashi don [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics lokacin `index >= len()`, ma'ana shi ko da yaushe panics a kan komai a yanka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Mayar da matsakaiciyar kamar dai an jera jeri daidai gwargwado.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // An tabbatar mana da cewa yanki zai zama ɗayan masu zuwa, gwargwadon yadda muke tsara abubuwan da aka ƙayyade.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Matsar da duk abubuwan da aka maimaita a jere zuwa ƙarshen yanki bisa ga aiwatarwar [`PartialEq`] trait.
    ///
    ///
    /// Ya dawo da yanka biyu.Na farkon ba ya dauke da abubuwa da aka maimaita a jere.
    /// Na biyun ya ƙunshi duk abubuwan kwafin a cikin wani takamaiman tsari.
    ///
    /// Idan yanki ya daidaita, yanki na farko da ya dawo baya dauke da kwafin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Motsa duk amma na farko na jere abubuwa zuwa karshen yanki gamsarwa a ba daidaici aboki.
    ///
    /// Ya dawo da yanka biyu.Na farkon ba ya dauke da abubuwa da aka maimaita a jere.
    /// Na biyun ya ƙunshi duk abubuwan kwafin a cikin wani takamaiman tsari.
    ///
    /// A `same_bucket` aiki ne haƙĩƙa, sun shige nassoshi biyu abubuwa daga yanki da kuma dole ne sanin ko idan da abubuwa kwatanta daidaita.
    /// Ana wuce abubuwan a gaban tsari daga tsarinsu a yanki, don haka idan `same_bucket(a, b)` ya dawo da `true`, ana motsa `a` a ƙarshen yanki.
    ///
    ///
    /// Idan yanki ya daidaita, yanki na farko da ya dawo baya dauke da kwafin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Kodayake muna da magana mai canzawa zuwa `self`, ba za mu iya yin canje-canje ba gaira ba dalili.Kiran `same_bucket` na iya panic, saboda haka dole ne mu tabbatar cewa yanki yana cikin aiki a kowane lokaci.
        //
        // Hanyar da zamu bi da wannan ita ce ta amfani da sauyi;Muna sanya shi a kan dukkan abubuwan, muna canzawa yayin da muke tafiya don haka a karshen abubuwan da muke son kiyayewa su ne a gaba, kuma wadanda muke so mu ki su ne a baya.
        // Zamu iya raba yanki.
        // Wannan aikin har yanzu shine `O(n)`.
        //
        // Misali: Muna farawa a cikin wannan jihar, inda `r` ke wakiltar "na gaba
        // karanta "kuma `w` na wakiltar" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Gwada self[r] da kai [w-1], wannan ba wani Kwafin, don haka mu musanya self[r] da self[w] (babu sakamako kamar yadda r==w) sa'an nan increment biyu r kuma w, da barin mu tare da:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Kwatanta self[r] da kai [w-1], wannan ƙimar ba ita ce riba ba, saboda haka mun haɓaka `r` amma mun bar komai baya canzawa:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Gwada self[r] da kai [w-1], wannan ba wani Kwafin, don haka canza self[r] da self[w] da kuma gaba r kuma w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ba wani abu ba, maimaita:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Kwafin, advance r. End na yanki.Raba a w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // KYAUTA: yanayin `while` ya tabbatar da `next_read` da `next_write`
        // basu kai `len` ba, saboda haka suna cikin `self`.
        // `prev_ptr_write` yana nuna abu ɗaya kafin `ptr_write`, amma `next_write` yana farawa daga 1, don haka `prev_ptr_write` bai taɓa ƙasa da 0 ba kuma yana cikin yanki.
        // Wannan ya cika abubuwan da ake buƙata don ƙaddamar da `ptr_read`, `prev_ptr_write` da `ptr_write`, kuma don amfani da `ptr.add(next_read)`, `ptr.add(next_write - 1)` da `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` Hakanan yana ƙaruwa a mafi sau ɗaya a kowane madauki a mafi akasarin ma'anar babu wani abu da ake tsallake lokacin da zai buƙaci a sauya shi.
        //
        // `ptr_read` kuma `prev_ptr_write` taba nuna wa wannan kashi.Ana buƙatar wannan don `&mut *ptr_read`, `&mut* prev_ptr_write` don zama mai aminci.
        // Bayanin shine kawai `next_read >= next_write` gaskiya ne, saboda haka `next_read > next_write - 1` shima yayi yawa.
        //
        //
        //
        //
        //
        unsafe {
            // Guji bincika iyakoki ta amfani da ɗan zane.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Matsar da duka amma na farkon jerin abubuwa zuwa ƙarshen yanki wanda ya warware zuwa maɓalli ɗaya.
    ///
    ///
    /// Ya dawo da yanka biyu.Na farkon ba ya dauke da abubuwa da aka maimaita a jere.
    /// Na biyun ya ƙunshi duk abubuwan kwafin a cikin wani takamaiman tsari.
    ///
    /// Idan yanki ya daidaita, yanki na farko da ya dawo baya dauke da kwafin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Yana juya yanki a wuri kamar yadda abubuwan farko na `mid` na yanki suka motsa zuwa ƙarshen yayin da abubuwan `self.len() - mid` na ƙarshe suka matsa zuwa gaba.
    /// Bayan kiran `rotate_left`, rukunin da ya gabata a index `mid` zai zama farkon element a yanki.
    ///
    /// # Panics
    ///
    /// Wannan aikin zai panic idan `mid` ya fi tsayin yanki.Lura cewa `mid == self.len()` yayi _not_ panic kuma juyawa ne babu op.
    ///
    /// # Complexity
    ///
    /// Lineauki layi (a lokacin `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Juya wani sashe:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // KYAUTA: Zangon `[p.add(mid) - mid, p.add(mid) + k)` yana da sauƙi
        // inganci don karatu da rubutu, kamar yadda `ptr_rotate` ya buƙata.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Yana juya yanki a wuri kamar yadda abubuwan farko na `self.len() - k` na yanki suka motsa zuwa ƙarshen yayin da abubuwan `k` na ƙarshe suka matsa zuwa gaba.
    /// Bayan kiran `rotate_right`, rukunin da ya gabata a index `self.len() - k` zai zama farkon element a yanki.
    ///
    /// # Panics
    ///
    /// Wannan aikin zai panic idan `k` ya fi tsayin yanki.Lura cewa `k == self.len()` yayi _not_ panic kuma juyawa ne babu op.
    ///
    /// # Complexity
    ///
    /// Lineauki layi (a lokacin `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Juya wani sashe:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // KYAUTA: Zangon `[p.add(mid) - mid, p.add(mid) + k)` yana da sauƙi
        // inganci don karatu da rubutu, kamar yadda `ptr_rotate` ya buƙata.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Cika `self` tare da abubuwa ta hanyar cloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Cika `self` tare da abubuwan da aka dawo ta hanyar kiran ƙulli akai-akai.
    ///
    /// Wannan hanyar tana amfani da ƙulli don ƙirƙirar sababbin ƙimomi.Idan kuna son [`Clone`] ƙimar da aka bayar, yi amfani da [`fill`].
    /// Idan kana son amfani da [`Default`] trait don samar da ƙimomi, zaka iya wuce [`Default::default`] azaman mahawara.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kwafin abubuwan daga `src` zuwa `self`.
    ///
    /// Tsawon `src` dole ne ya zama daidai da `self`.
    ///
    /// Idan `T` ya aiwatar da `Copy`, zai iya zama mafi cikawa don amfani da [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Wannan aiki zai panic idan yanka biyu da daban-daban tsawo.
    ///
    /// # Examples
    ///
    /// Cloning abubuwa biyu daga yanki zuwa wani:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Saboda yankan ya zama suna da tsayi iri ɗaya, mun yanki tushen tushe daga abubuwa huɗu zuwa biyu.
    /// // Zai panic idan ba muyi haka ba.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ya tilasta cewa za'a iya samun sauƙaƙe guda ɗaya kawai ba tare da wani nassoshi mai canzawa zuwa takamaiman takamaiman bayanai a cikin wani fanni ba.
    /// Saboda wannan, yunƙurin amfani da `clone_from_slice` akan yanki ɗaya zai haifar da tarin gazawa:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Don aiki a kusa da wannan, zamu iya amfani da [`split_at_mut`] don ƙirƙirar-ananan yanki biyu daga yanki:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Ana kwashe dukkan abubuwa daga `src` zuwa `self`, ta amfani da memcpy.
    ///
    /// Tsawon `src` dole ne ya zama daidai da `self`.
    ///
    /// Idan `T` baya aiwatar da `Copy`, yi amfani da [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Wannan aiki zai panic idan yanka biyu da daban-daban tsawo.
    ///
    /// # Examples
    ///
    /// Kwashe abubuwa biyu daga yanki zuwa wani:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Saboda yankan ya zama suna da tsayi iri ɗaya, mun yanki tushen tushe daga abubuwa huɗu zuwa biyu.
    /// // Zai panic idan ba muyi haka ba.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ya tilasta cewa za'a iya samun sauƙaƙe guda ɗaya kawai ba tare da wani nassoshi mai canzawa zuwa takamaiman takamaiman bayanai a cikin wani fanni ba.
    /// Saboda wannan, yunƙurin amfani da `copy_from_slice` akan yanki ɗaya zai haifar da tarin gazawa:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Don aiki a kusa da wannan, zamu iya amfani da [`split_at_mut`] don ƙirƙirar-ananan yanki biyu daga yanki:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // An saka hanyar lambar panic cikin aikin sanyi don kar ta mamaye shafin kira.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // KYAUTA: `self` yana aiki don abubuwan `self.len()` ta ma'ana, kuma `src` ya kasance
        // duba don samun tsayi iri ɗaya.
        // Yankan ba za su iya juyewa ba saboda nassoshi masu canzawa suna keɓantattu.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kwafa abubuwa daga wani yanki na yanki zuwa wani bangare na kanta, ta amfani da memmove.
    ///
    /// `src` shine zangon tsakanin `self` don kwafa daga.
    /// `dest` shine farkon jerin kewayon tsakanin `self` don kwafa zuwa, wanda zai sami tsayi iri ɗaya da `src`.
    /// Rukunonin biyu na iya haɗuwa.
    /// Arshen jeri biyu dole ne ya zama ƙasa da ko daidaita da `self.len()`.
    ///
    /// # Panics
    ///
    /// Wannan aikin zai panic idan ɗayan zangon ya wuce ƙarshen yanki, ko kuma idan ƙarshen `src` ya kasance kafin farawa.
    ///
    ///
    /// # Examples
    ///
    /// Kwashe baiti huɗu a cikin yanki:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // KYAUTA: an riga an bincika yanayin `ptr::copy` a sama,
        // kamar yadda waɗanda suke na `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Ya sauya dukkan abubuwa a cikin `self` tare da waɗanda ke cikin `other`.
    ///
    /// Tsawon `other` dole ne ya zama daidai da `self`.
    ///
    /// # Panics
    ///
    /// Wannan aiki zai panic idan yanka biyu da daban-daban tsawo.
    ///
    /// # Example
    ///
    /// Musayar abubuwa biyu a fadin yanka:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust yana aiwatar da cewa ba za a iya samun sauƙaƙe guda ɗaya zuwa takamaiman yanki na bayanai a cikin wani keɓaɓɓen yanki ba.
    ///
    /// Saboda wannan, yunƙurin amfani da `swap_with_slice` akan yanki ɗaya zai haifar da tarin gazawa:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Don yin aiki a kusa da wannan, zamu iya amfani da [`split_at_mut`] don ƙirƙirar ƙananan yankuna masu canzawa guda biyu daga yanki:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // KYAUTA: `self` yana aiki don abubuwan `self.len()` ta ma'ana, kuma `src` ya kasance
        // duba don samun tsayi iri ɗaya.
        // Yankan ba za su iya juyewa ba saboda nassoshi masu canzawa suna keɓantattu.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Aiki don lissafin tsaka-tsakin tsakiya da yanki mai biye don `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Abin da za mu yi game da `rest` shine gano abin da yawa na 'U`s da za mu iya sanyawa a cikin mafi ƙarancin adadin' T`s.
        //
        // Kuma nawa T`s muke buƙata ga kowane irin "multiple".
        //
        // Yi la'akari da misali T=u8 U=u16.Sannan zamu iya sanya 1 U a cikin 2 Ts.Mai sauki.
        // Yanzu, la'akari da misali akwati inda girman_of: :<T>=16, girman_of::<U>=24.</u>
        // Zamu iya sanya 2 Us a madadin kowane 3 Ts a cikin yanki `rest`.
        // A bit more wuya.
        //
        // Formula don lissafin wannan shine:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Fadada da sauƙaƙa:
        //
        // Mu=girman_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=girman_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Sa'ar al'amarin shine tunda duk wannan abin-akai akai ne ... aiwatarwa anan ba damuwa!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // Har ila yau, ya kamata mu sanya wannan `const fn` (kuma mu koma zuwa algorithm mai sake dawowa idan za mu yi) saboda dogaro da llvm don nuna alama duk wannan yana da kyau, yana ba ni damuwa.
            //
            //

            // KIYAYEWAR: `a` da `b` suna bari ya zama maras sifili dabi'u.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // cire dukkan abubuwan 2 daga b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // KYAUTA: `b` an bincika ya zama ba sifili.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Dauke da wannan ilimin, zamu iya samun 'U`s nawa zamu iya dacewa!
        let us_len = self.len() / ts * us;
        // Da yawa ``T`s '' zasu kasance a cikin yanki mai zuwa!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Canja yanki zuwa yanki na wani nau'in, tabbatar ana daidaita nau'ikan.
    ///
    /// Wannan hanya tsãgewar ƙwãyar yanki cikin uku jinsin yanka: prefix, daidai hada kai tsakiya yanki na wani sabon nau'in, da kuma kari na baya baki yanki.
    /// Hanyar na iya sanya tsakiyar yanki mafi girman tsayin da zai yiwu ga nau'in da aka bayar da yanki, amma aikin algorithm kawai ya kamata ya dogara da hakan, ba daidaitorsa ba.
    ///
    /// Ya halatta a dawo da dukkan bayanan shigarwar azaman kari ko kari kari.
    ///
    /// Wannan hanyar ba ta da wata ma'ana yayin da nau'ikan shigar da abubuwa `T` ko kayan aikin da aka fitar na `U` ba su da girma kuma za su dawo da asalin yanki ba tare da raba komai ba.
    ///
    /// # Safety
    ///
    /// Wannan hanyar ita ce ainihin `transmute` game da abubuwan da ke cikin yanki na tsakiya da aka dawo, don haka duk tsoffin ƙofofin da suka shafi `transmute::<T, U>` suma suna aiki anan.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Lura cewa yawancin wannan aikin zasu kasance masu kima akai,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // rike ZST musamman, wanda shine-kar a rike su kwata-kwata.
            return (self, &[], &[]);
        }

        // Na farko, nemo a wane lokaci muka raba tsakanin yanki na farko da na 2.
        // Sauƙi tare da ptr.align_offset.
        let ptr = self.as_ptr();
        // KIYAYEWAR: Dubi cikin `align_to_mut` Hanyar ga cikakken aminci comment.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // KYAUTA: yanzu `rest` yayi daidai, saboda haka `from_raw_parts` da ke ƙasa yana da kyau,
            // tun da mai kira tabbacin cewa za mu iya canja `T` zuwa `U` amince.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Canja yanki zuwa yanki na wani nau'in, tabbatar ana daidaita nau'ikan.
    ///
    /// Wannan hanya tsãgewar ƙwãyar yanki cikin uku jinsin yanka: prefix, daidai hada kai tsakiya yanki na wani sabon nau'in, da kuma kari na baya baki yanki.
    /// Hanyar na iya sanya tsakiyar yanki mafi girman tsayin da zai yiwu ga nau'in da aka bayar da yanki, amma aikin algorithm kawai ya kamata ya dogara da hakan, ba daidaitorsa ba.
    ///
    /// Ya halatta a dawo da dukkan bayanan shigarwar azaman kari ko kari kari.
    ///
    /// Wannan hanyar ba ta da wata ma'ana yayin da nau'ikan shigar da abubuwa `T` ko kayan aikin da aka fitar na `U` ba su da girma kuma za su dawo da asalin yanki ba tare da raba komai ba.
    ///
    /// # Safety
    ///
    /// Wannan hanyar ita ce ainihin `transmute` game da abubuwan da ke cikin yanki na tsakiya da aka dawo, don haka duk tsoffin ƙofofin da suka shafi `transmute::<T, U>` suma suna aiki anan.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Lura cewa yawancin wannan aikin zasu kasance masu kima akai,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // rike ZST musamman, wanda shine-kar a rike su kwata-kwata.
            return (self, &mut [], &mut []);
        }

        // Na farko, nemo a wane lokaci muka raba tsakanin yanki na farko da na 2.
        // Sauƙi tare da ptr.align_offset.
        let ptr = self.as_ptr();
        // KYAUTA: Anan muna tabbatar da cewa zamuyi amfani da alamomi masu daidaito ga U don
        // sauran hanyar.Ana yin wannan ta hanyar wucewa mai nunawa zuwa&[T] tare da daidaitawa da aka tsara don U.
        // `crate::ptr::align_offset` ana kiransa tare da daidaitaccen mai nuna alama kuma mai inganci `ptr` (ya zo ne daga nuni zuwa `self`) kuma tare da girman da yake iko ne na biyu (tunda yana zuwa ne daga daidaiton U), yana mai gamsar da ƙuntatattun lafiyarsa.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ba za mu iya sake amfani da `rest` ba bayan wannan, wannan zai ɓata sunan sa na `mut_ptr`!KYAUTA: duba ra'ayoyi don `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Ana dubawa idan an daidaita abubuwan da ke wannan yanki.
    ///
    /// Wato, ga kowane element `a` da mai biye dashi `b`, `a <= b` dole ne ya riƙe.Idan yanki ya samar da sifili daidai ko wani abu, `true` ya dawo.
    ///
    /// Lura cewa idan `Self::Item` `PartialOrd` ne kawai, amma ba `Ord` ba, ma'anar da ke sama tana nuna cewa wannan aikin ya dawo da `false` idan duk abubuwa biyu masu jere basa misaltawa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Ana dubawa idan an daidaita abubuwan wannan yanki ta amfani da aikin kwatancen da aka ba su.
    ///
    /// Maimakon amfani da `PartialOrd::partial_cmp`, wannan aikin yana amfani da aikin `compare` da aka bayar don ƙayyade odar abubuwa biyu.
    /// Baya ga cewa, yana da daidai da [`is_sorted`].duba bayanansa don ƙarin bayani.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Ana dubawa idan an daidaita abubuwan wannan yanki ta amfani da aikin hakar maɓallin da aka bayar.
    ///
    /// Madadin kwatanta abubuwan yanki kai tsaye, wannan aikin yana kwatanta mabuɗan abubuwan, kamar yadda `f` ya ƙaddara.
    /// Baya ga cewa, yana da daidai da [`is_sorted`].duba bayanansa don ƙarin bayani.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Yana dawo da fihirisin batun bangare daidai gwargwadon wanda aka bayar (wanda ya nuna farkon abin da ya shafi bangare na biyu).
    ///
    /// Yankin an zaci za a raba shi ne gwargwadon yadda aka bayar.
    /// Wannan yana nufin cewa dukkan abubuwan da mai tantancewar ya dawo gaskiya ne a farkon yanki kuma duk abubuwan da mai hasashen ya dawo na ƙarya suke a ƙarshe.
    ///
    /// Misali, [7, 15, 3, 5, 4, 12, 6] an raba shi a karkashin magatakarda x% 2!=0 (duk lambobin da basu dace ba suna farawa, duk ma a karshen).
    ///
    /// Idan ba a raba wannan yanki ba, sakamakon da aka dawo ba a bayyana shi ba kuma ba shi da ma'ana, saboda wannan hanyar tana yin wani bincike na binaryar.
    ///
    /// Duba kuma [`binary_search`], [`binary_search_by`], da [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // KIYAYEWAR: Lokacin `left < right`, `left <= mid < right`.
            // Saboda haka `left` koyaushe yana ƙaruwa kuma `right` koyaushe yana raguwa, kuma an zaɓi ɗayansu.A cikin waɗannan halaye `left <= right` ya gamsu.Saboda haka idan `left < right` a cikin mataki, `left <= right` ya gamsu a mataki na gaba.
            //
            // Saboda haka muddin `left != right`, `0 <= left < right <= len` ya gamsu kuma idan wannan lamarin `0 <= mid < len` ya gamsu shima.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Muna buƙatar bayyana su a bayyane zuwa tsayi iri ɗaya
        // don sauƙaƙawa ga mai ƙyatarwa don ɗaukar iyakokin bincike.
        // Amma tunda ba za a dogara da shi ba kuma muna da ƙwarewar ƙwarewa don T: Kwafi.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Irƙirar fankar fanko
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Irƙira yanki mara fa'ida
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Alamu a yanka, a halin yanzu, kawai amfani da `strip_prefix` da `strip_suffix`.
/// A wani zancen future, muna fatan gabatar da `core::str::Pattern` gaba ɗaya (wanda a lokacin rubuce-rubuce ya iyakance ga `str`) zuwa yanka, sannan kuma wannan trait za'a maye gurbinsa ko a soke shi.
///
pub trait SlicePattern {
    /// Nau'in nau'in nau'in yanki ana daidaita shi.
    type Item;

    /// A halin yanzu, masu amfani da `SlicePattern` suna buƙatar yanki.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}