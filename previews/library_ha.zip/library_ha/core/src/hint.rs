#![stable(feature = "core_hint", since = "1.27.0")]

//! Alamu ga mai tara abubuwa waɗanda ke shafar yadda za a fitar da ko kuma inganta kodin.
//! Alamu na iya tara lokaci ko lokacin gudu.

use crate::intrinsics;

/// Sanar da mai tarawa cewa wannan batu a cikin code bai samu ba, kunna kara optimizations.
///
/// # Safety
///
/// Kai wannan aikin ne gaba daya *maras bayyani hali*(UB).A musamman, da mai tarawa tabbatar da cewa duk UB dole ne ta taba faruwa, sabili da haka zai kawar da dukkan rassan da cewa isar wa mai kira zuwa `unreachable_unchecked()`.
///
/// Kamar kowane yanayi na UB, idan wannan zato ya zama ba daidai ba, watau, kiran `unreachable_unchecked()` a zahiri ana iya samun sa a tsakanin dukkan hanyoyin sarrafa iko, mai harhaɗa zai yi amfani da dabarun ingantawa mara kyau, kuma wani lokaci ma zai iya lalata lambobin da ba shi da alaƙa, yana haifar da wahala-to-cire kuskure matsaloli.
///
///
/// Amfani da wannan aikin kawai a lokacin da za ka iya tabbatar da cewa code ba zai kira shi.
/// In ba haka ba, yi la'akari da amfani da [`unreachable!`] macro, wanda ba ya ba da damar haɓaka amma panic zai yi yayin aiwatar da shi.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` ne ko da yaushe m (ba sifili), Saboda haka `checked_div` zai taba komawa `None`.
/////
///     // Saboda haka, kuma branch ne unreachable.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // KIYAYEWAR: aminci kwangila ga `intrinsics::unreachable` dole ne
    // mai goyon bayan mai kiran.
    unsafe { intrinsics::unreachable() }
}

/// Amfani da umarnin inji don yiwa siginar sigina alama cewa yana aiki a cikin ɓoye-madauki na jira ("makullin juyawa").
///
/// A kan samun da juya-madauki siginar da processor iya inganta ta hali da, misali, ikon ceto ko ya sauya sheka hyper-zaren.
///
/// Wannan aikin ya bambanta da [`thread::yield_now`] wanda ke samarwa kai tsaye ga mai tsara tsarin, yayin da `spin_loop` baya hulɗa da tsarin aiki.
///
/// A kowa yin amfani al'amarin ga `spin_loop` aka aiwatar a daure kaffa kadi a CAS madauki a aiki tare primitives.
/// Don kauce wa matsaloli kamar fifiko inversion, shi ne karfi da shawarar cewa juya madauki da aka kare bayan wani guntun adadin iterations da ya dace tarewa syscall aka yi.
///
///
/// **Lura**: A kan dandamali waɗanda basa goyan bayan karɓar alamomin wannan aikin ba ya yin komai kwata-kwata.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // A raba atomic darajar da zaren zai yi amfani ga daidaita
/// let live = Arc::new(AtomicBool::new(false));
///
/// // A wani bango thread za mu ƙarshe kafa darajar
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Yi wasu ayyuka, sa'annan ƙimar ta rayu
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Back a kan mu a halin yanzu thread, mu jira ga darajar su zama sa
/// while !live.load(Ordering::Acquire) {
///     // The juya madauki ne da ambato ga CPU da cewa muna jiran, amma tabbas ba ga tsawo sosai
/////
///     hint::spin_loop();
/// }
///
/// // The darajar yanzu kafa
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // KYAUTA: `cfg` attr yana tabbatar da cewa kawai muna aiwatar da wannan ne akan maƙasudin x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // KYAUTA: `cfg` attr yana tabbatar da cewa kawai muna aiwatar da wannan ne akan maƙasudin x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // KYAUTA: `cfg` attr yana tabbatar da cewa kawai muna aiwatar da wannan ne akan maƙasudin aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // KIYAYEWAR: da `cfg` attr tabbatar da cewa mu ne kawai kashe wannan a hannu hari
            // tare da goyon baya ga v6 fasalin.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// An asalin aikin da *__ alamu __* ga tarawa zama maximally pessimistic game da abin da `black_box` iya yi.
///
/// Ba kamar [`std::convert::identity`], a Rust tarawa yana karfafa su ɗauka cewa `black_box` iya amfani da `dummy` a wani yiwu m hanyar cewa Rust code da aka yarda su ba tare da gabatar da maras bayyani hali a kira lamba.
///
/// Wannan dukiyar sa `black_box` amfani ga rubutu code a cikin abin da wasu optimizations ba so, kamar asowar.
///
/// Lura duk da haka, cewa `black_box` kawai (kuma za'a iya kasancewa) ana bayar dashi akan tushen "best-effort".Har zuwa abin da shi zai iya toshe optimisations iya bambanta dangane a kan dandamali da kuma code-Gen backend amfani.
/// Shirye-shiryen ba za su iya dogaro da `black_box` don *daidaito* ta kowace hanya ba.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Muna buƙatar "use" muhawara ta wata hanya LLVM ba zai iya gabatarwa ba, kuma a kan maƙasudin da ke tallafawa shi yawanci za mu iya yin amfani da taron layi don yin wannan.
    // LLVM ta fassarar línea taro ne da cewa yana da, da kyau, a baki akwatin.
    // Wannan ba shine mafi girman aiwatarwa ba tunda yana iya ɓata fiye da yadda muke so, amma yana da kyau sosai.
    //
    //

    #[cfg(not(miri))] // Wannan shi ne kawai da ambato, don haka shi ne m zuwa ƙetare a Miri.
    // KYAUTA: taron layi na cikin gida ba komai bane.
    unsafe {
        // FIXME: Ba za a iya amfani da `asm!` saboda shi ba ya goyon bayan MIPS da sauran fannonin tsarin gine-gine.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}