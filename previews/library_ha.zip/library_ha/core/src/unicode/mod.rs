#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// A version of [Unicode](http://www.unicode.org/) cewa Unicode sassa na `char` da `str` hanyoyin su ne bisa.
///
/// Sabbin nau'ikan Unicode ana sake su akai-akai kuma daga baya duk hanyoyin da ke cikin ingantaccen ɗakin karatu dangane da Unicode ana sabunta su.
/// Saboda haka halayyar wasu hanyoyin `char` da `str` da ƙimar wannan dorewar suna canzawa akan lokaci.
/// Wannan *ba* ɗauke shi a matsayin raunin canji.
///
/// An yi bayanin tsarin lambobi a cikin [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Don amfani a liballoc, ba a sake fitarwa a cikin libstd ba.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;