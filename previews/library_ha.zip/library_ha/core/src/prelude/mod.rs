//! Libungiyar lib0 prelude
//!
//! An tsara wannan rukunin don masu amfani da libcore waɗanda basu da alaƙa da libstd kuma.
//! An shigo da wannan ƙirar ta tsoho lokacin da ake amfani da `#![no_std]` daidai da daidaitaccen ɗakunan karatu na prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Siffar 2015 ta ainihin prelude.
///
/// Dubi [module-level documentation](self) for more.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Siffar 2018 ta ainihin prelude.
///
/// Dubi [module-level documentation](self) for more.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Tsarin 2021 na ainihin prelude.
///
/// Dubi [module-level documentation](self) for more.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Moreara ƙarin abubuwa.
}