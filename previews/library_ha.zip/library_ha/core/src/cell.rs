//! Shareable lambobi masu canzawa
//!
//! Rust amincin ƙwaƙwalwar ajiya ya dogara da wannan ƙa'idar: Idan aka ba da abu `T`, zai yiwu kawai a sami ɗayan masu zuwa:
//!
//! - Samun dama marar sakewa nassoshi (`&T`) da abu (wanda kuma aka sani a matsayin **aliasing**).
//! - Samun daya mutable reference (`&mut T`) zuwa ga abu (wanda kuma aka sani a matsayin **mutability**).
//!
//! Ana aiwatar da wannan ta mai tarawa na Rust.Koyaya, akwai yanayi inda wannan ƙa'idar ba ta da sassauƙa.Wani lokaci ana buƙata don samun nassoshi da yawa akan abu kuma duk da haka canza shi.
//!
//! Shareable mutable kwantena zama a yarda mutability a wani sarrafawa hanya, ko da a gaban aliasing.Dukansu [`Cell<T>`] da [`RefCell<T>`] damar yin wannan a guda-threaded hanya.
//! Koyaya, babu `Cell<T>` ko `RefCell<T>` masu aminci a zaren (ba sa aiwatar da [`Sync`]).
//! Idan kana bukatar ka yi aliasing da kuma maye gurbi tsakanin mahara zaren yana yiwuwa a yi amfani da [`Mutex<T>`], [`RwLock<T>`] ko [`atomic`] iri.
//!
//! Valimar nau'ikan `Cell<T>` da `RefCell<T>` na iya canzawa ta hanyar nassoshi da aka raba (watau
//! da na kowa `&T` irin) ne, alhãli kuwa mafi Rust iri za a iya mutated ta musamman (`&mut T`) nassoshi.
//! Mun ce `Cell<T>` da `RefCell<T>` suna ba da 'canjin ciki', ya bambanta da nau'ikan nau'ikan Rust waɗanda ke nuna 'maye gurbin gado'.
//!
//! Nau'ukan salula sun zo cikin dandano biyu: `Cell<T>` da `RefCell<T>`.`Cell<T>` yana aiwatar da canjin ciki ta hanyar motsa ƙimomi cikin da fita daga cikin `Cell<T>`.
//! Don amfani da nassoshi maimakon ƙimomi, dole ne mutum yayi amfani da nau'in `RefCell<T>`, samun makullin rubutu kafin canzawa.`Cell<T>` yana ba da hanyoyi don dawo da canza ƙimar ciki ta yanzu:
//!
//!  - Domin iri da aiwatar da [`Copy`], da [`get`](Cell::get) Hanyar retrieves yanzu ciki darajar.
//!  - Domin iri da aiwatar da [`Default`], da [`take`](Cell::take) Hanyar maye gurbin na yanzu ciki darajar da [`Default::default()`] da kuma dawo da maye gurbin darajar.
//!  - Ga kowane iri, hanyar [`replace`](Cell::replace) ta maye gurbin ƙimar ciki ta yanzu kuma ta dawo da darajar da aka maye gurbin kuma hanyar [`into_inner`](Cell::into_inner) ta cinye `Cell<T>` kuma ta dawo da ƙimar ciki.
//!  Ari, hanyar [`set`](Cell::set) ta maye gurbin ƙimar ciki, ta watsar da ƙimar da aka sauya.
//!
//! `RefCell<T>` yana amfani da rayuwar Rust don aiwatar da 'lamuni mai ƙarfi', tsari wanda mutum zai iya neman damar wucin gadi, keɓancewa, mai canzawa zuwa ƙimar ciki.
//! Borrows don ``RefCell<T>`S ana sa ido 'a Runtime', sabanin Rust ta 'yan qasar tunani iri wanda aka gaba ɗaya sa ido statically, a tara lokaci.
//! Saboda rancen `RefCell<T>` yana da ƙarfi yana yiwuwa a yunƙurin aron ƙimar da tuni ta aro ta mutably;lokacin da wannan zai faru da shi results a thread panic.
//!
//! # Lokacin da za a zaɓi canjin yanayin ciki
//!
//! Canjin yanayin da aka fi gado, inda dole ne mutum ya sami dama ta musamman don canza ƙima, ɗayan mahimman abubuwan harshe ne waɗanda ke ba Rust damar yin tunani mai ƙarfi game da nuna alama ta hanyar nunawa, ta hana hana haɗari kwari.
//! Saboda haka, sun gaji mutability aka fĩfĩta, da kuma ciki mutability ne da wani abu na karshe mafaka.
//! Tunda nau'ikan tantanin halitta suna ba da damar maye gurbi a inda ba za a hana shi ba kodayake, akwai lokutan da sauyawar ciki zai dace, ko ma *dole* a yi amfani da shi, misali
//!
//! * Gabatar da canjin yanayin 'inside' na wani abu mara canzawa
//! * Bayanin aiwatarwa na hanyoyin dabaru-dabaru.
//! * Mutating implementations na [`Clone`].
//!
//! ## Gabatar da canjin yanayin 'inside' na wani abu mara canzawa
//!
//! Yawancin nau'ikan alamun nuna kaifin baki, gami da [`Rc<T>`] da [`Arc<T>`], suna ba da kwantena waɗanda za a iya rufe su kuma a raba su tsakanin ɓangarori da yawa.
//! Saboda ƙimomin da ke ƙunshe na iya zama-mahaɗa-yawa, ana iya aron su tare da `&`, ba `&mut` ba.
//! Ba tare da ƙwayoyin halitta ba zai zama ba zai yuwu ba a canza bayanai a cikin waɗannan masanan masu ma'ana kwata-kwata.
//!
//! Yana da matukar kowa sa'an nan zuwa saka `RefCell<T>` cikin shared akan iri to reintroduce mutability:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Irƙiri sabon toshe don ƙayyade ikon aro mai ƙarfi
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Note cewa idan muka yi ba bari baya ranta na cache fada daga ikon yinsa, sa'an nan da m ranta zai sa wani mashahurin thread panic.
//!     //
//!     // Wannan shine babbar haɗarin amfani da `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Ka lura da cewa wannan misali yana amfani da `Rc<T>` kuma ba `Arc<T>`.`RefCell<T>`S ne ga guda-Threaded tatsuniyoyinsu.Yi la'akari da amfani da [`RwLock<T>`] ko [`Mutex<T>`] idan kuna buƙatar raba daidaituwa a cikin yanayi mai yawa.
//!
//! ## Bayanin aiwatarwa na hanyoyin dabaru-dabaru
//!
//! Lokaci-lokaci shi yana iya zama kyawawa ba ya bijirar a wani API cewa akwai maye gurbi faruwa "under the hood".
//! Wannan na iya zama saboda Azancin da aiki ne marar sakewa, amma misali, caching sojojin da aiwatar da su na yin maye gurbi,ko saboda dole ne ku yi amfani da maye gurbi don aiwatar da hanyar trait wacce aka bayyana ta asali don ɗaukar `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Compididdiga mai tsada tana zuwa nan
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Canza aiwatarwar `Clone`
//!
//! Wannan shi ne kawai na musamman, amma na kowa, hali na baya: buya mutability ga ayyukan da ya bayyana ga zama marar sakewa.
//! A [`clone`](Clone::clone) Hanyar ana sa ran ba canza tushen darajar, kuma aka ayyana dauki `&self`, ba `&mut self`.
//! Sabili da haka, duk wani maye gurbi wanda ya faru a cikin hanyar `clone` dole ne yayi amfani da nau'ikan ƙwayoyin halitta.
//! Alal misali, [`Rc<T>`] kula da reference kirga a cikin `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Wurin ƙwaƙwalwar ajiya mai canzawa.
///
/// # Examples
///
/// A wannan misali, za ka iya ganin cewa `Cell<T>` sa maye gurbi a cikin wani marar sakewa struct.
/// A wasu kalmomin, yana ba da damar "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // Kuskure: `my_struct` baya canzawa
/// // my_struct.regular_field =New_value.
///
/// // Aiki: ko da yake `my_struct` marar sakewa ne, `special_field` ne `Cell`,
/// // wanda koyaushe za'a iya maye gurbinsa
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Dubi [module-level documentation](self) for more.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Creatirƙira `Cell<T>`, tare da ƙimar `Default` don T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Irƙiri sabon `Cell` mai ɗauke da ƙimar da aka bayar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Ya kafa ƙimar da take ƙunshe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Sauya ƙimar Sel biyu.
    /// Bambanci tare da `std::mem::swap` shine cewa wannan aikin baya buƙatar bayanin `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // KYAUTA: Wannan na iya zama da haɗari idan an kira shi daga zaren daban, amma `Cell`
        // ne `!Sync` haka wannan ba zai faru.
        // Wannan ma ba zai wofintar da duk wani pointers tun `Cell` sa tabbata ba wani abu ba za a nuna a cikin ko dai na wadannan `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Sauya dauke darajar da `val`, da kuma dawo da tsohon dauke darajar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // KIYAYEWAR: Wannan zai iya sa data jinsi idan kira daga wani raba zare,
        // amma `Cell` shine `!Sync` don haka wannan ba zai faru ba.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Cire ƙimar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Ya dawo da kwafin ƙimar da ta ƙunsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // KIYAYEWAR: Wannan zai iya sa data jinsi idan kira daga wani raba zare,
        // amma `Cell` shine `!Sync` don haka wannan ba zai faru ba.
        unsafe { *self.value.get() }
    }

    /// Updates da dauke darajar amfani da wani aiki da kuma dawo da sabon darajar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Dawo a raw mauni zuwa tamkar data a cikin wannan cell.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Yana dawo da ambaton maye gurbin bayanan asali.
    ///
    /// Wannan kiran yana karɓar `Cell` mai haɗawa (a lokacin tarawa) wanda ke ba da tabbacin cewa mun mallaki abin da aka ambata kawai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ya dawo da `&Cell<T>` daga `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // KIYAYEWAR: `&mut` tabbatar musamman damar.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Theauki darajar tantanin halitta, yana barin `Default::default()` a wurinsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Koma wani `&[Cell<T>]` daga `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // KYAUTA: `Cell<T>` yana da tsari iri ɗaya na ƙwaƙwalwa kamar `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Wurin ƙwaƙwalwar da zai iya canzawa tare da ƙa'idodin aron ƙa'idodin bashi
///
/// Dubi [module-level documentation](self) for more.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Kuskure ya dawo ta [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Kuskure ya dawo ta [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// M dabi'u wakilci yawan `Ref` aiki.Dabi'u mara kyau suna wakiltar lambar `RefMut` mai aiki.
// `arin`` RefMut`s zai iya zama mai aiki a lokaci guda kawai idan sun koma ga abubuwan da suka bambanta, waɗanda ba a sake haɗawa ba na `RefCell` (misali, jeri daban-daban na yanki).
//
// `Ref` kuma `RefMut` duka kalmomi biyu ne a girma, kuma don haka da alama ba za a taɓa samun isasshen ``Ref`s ko '' RefMut`s ba wanda zai iya mamaye rabin zangon `usize`.
// Don haka, `BorrowFlag` tabbas ba zai taɓa cika ko kwarara ba.
// Koyaya, wannan ba garantin bane, kamar yadda shirin cututtukan cututtuka ke iya ƙirƙira akai-akai sannan kuma mem::forget ``Ref`s ko '' RefMut`s.
// Don haka, duk lamba dole ne a bayyane ta bincika ambaliyar ruwa da ambaliyar don kauce wa rashin aminci, ko kuma aƙalla nuna hali daidai a yayin da ambaliyar ruwa ko ambaliyar ta faru (misali, duba BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Creatirƙiri sabon `RefCell` mai ɗauke da `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Cinye `RefCell`, yana dawo da ƙimar da aka nade.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Tunda wannan aikin yana ɗaukar `self` (the `RefCell`) da daraja, mai tattarawa ya tabbatar da cewa ba aronta a halin yanzu.
        //
        self.value.into_inner()
    }

    /// Yana maye gurbin ƙimar da aka nannade da sabon, yana mai da tsohon ƙimar, ba tare da ɓata ɗayan ba.
    ///
    ///
    /// Wannan aikin yayi daidai da [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics idan darajar yanzu an aro ta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Yana maye gurbin ƙimar da aka nade tare da sabon da aka ƙididdige daga `f`, yana mai da tsohon ƙimar, ba tare da ɓata ɗayan ba.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan darajar yanzu an aro ta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ya sauya darajar da aka nade na `self` tare da darajar da aka nannade na `other`, ba tare da bayyana ɗayan ba.
    ///
    ///
    /// Wannan aikin yayi daidai da [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Bazai yuwu ya karɓi darajar da aka nade ba.
    ///
    /// Aron yana nan har zuwa lokacin da `Ref` ya dawo ya fita daga faɗin.
    /// Mahara marar sakewa ya yiwo aro za a iya dauka daga a lokaci guda.
    ///
    /// # Panics
    ///
    /// Panics idan darajar halin yanzu mutably aro.
    /// Ga wani maras panicking bambance-bambancen, amfani da [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Wani misali na panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably yiwo aro da nade darajar, dawo da wani kuskure idan darajar halin yanzu mutably aro.
    ///
    ///
    /// Aron yana nan har zuwa lokacin da `Ref` ya dawo ya fita daga faɗin.
    /// Mahara marar sakewa ya yiwo aro za a iya dauka daga a lokaci guda.
    ///
    /// Wannan shine bambancin rashin tsoro na [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // KYAUTA: `BorrowRef` yana tabbatar da cewa akwai hanyar shigowa mara canzawa
            // ga darajar yayin aro.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably yiwo aro da nade darajar.
    ///
    /// A aro yana har da koma `RefMut` ko duk `RefMut`s samu daga shi fita ikon yinsa.
    ///
    /// Ba za a iya karɓar ƙimar yayin wannan rancen yana aiki ba.
    ///
    /// # Panics
    ///
    /// Panics idan darajar yanzu an aro ta.
    /// Don bambancin ban tsoro, yi amfani da [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Wani misali na panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Zai iya karɓar kuɗin da aka nade, dawo da kuskure idan an karɓi ƙimar a halin yanzu.
    ///
    ///
    /// A aro yana har da koma `RefMut` ko duk `RefMut`s samu daga shi fita ikon yinsa.
    /// Ba za a iya karɓar ƙimar yayin wannan rancen yana aiki ba.
    ///
    /// Wannan shine bambancin rashin tsoro na [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // KYAUTA: `BorrowRef` ya ba da tabbacin samun dama ta musamman.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Dawo a raw mauni zuwa tamkar data a cikin wannan cell.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Yana dawo da ambaton maye gurbin bayanan asali.
    ///
    /// Wannan kiran yana karɓar `RefCell` mai canzawa (a lokacin tarawa) saboda haka babu buƙatar tsayayyen bincike.
    ///
    /// Koyaya yi hankali: wannan hanyar tana buƙatar `self` ya zama mai canzawa, wanda galibi ba haka bane yayin amfani da `RefCell`.
    ///
    /// Duba hanyar [`borrow_mut`] maimakon idan `self` ba zai iya canzawa ba.
    ///
    /// Har ila yau, don Allah ka sani cewa wannan hanya ne kawai ga yanayi na musamman da kuma shi ne yawanci ba abin da ka so.
    /// Idan akwai shakka, yi amfani da [`borrow_mut`] maimakon.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Fasa da sakamako na leaked masu gadi a ranta jihar na `RefCell`.
    ///
    /// Wannan kira ne kama da [`get_mut`] amma mafi qware.
    /// Yana yiwo aro `RefCell` mutably tabbatar babu yiwo aro zama sa'an nan resets jihar tracking shared ya yiwo aro.
    /// Wannan ya dace idan wasu basussukan `Ref` ko `RefMut` sun yi malalo.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably yiwo aro da nade darajar, dawo da wani kuskure idan darajar halin yanzu mutably aro.
    ///
    /// # Safety
    ///
    /// Ba kamar `RefCell::borrow`, wannan hanya ne unsafe saboda shi ba ya dawo a `Ref`, haka barin ara flag untouched.
    /// Biyan bashin `RefCell` yayin ma'anar da aka dawo ta wannan hanyar yana raye ba shi da ma'ana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // KIYAYEWAR: Mu duba da cewa babu wanda aka rayayye rubutu a yanzu, amma shi ne
            // da mai kira ke dauke da nauyin tabbatar da cewa babu wanda ya rubuta har da koma tunani ne ba a amfani.
            // Hakanan, `self.value.get()` yana nufin darajar da `self` ya mallaka kuma don haka an tabbatar dashi cewa yana aiki har tsawon rayuwar `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Valueauki darajar da aka nannade, yana barin `Default::default()` a wurinsa.
    ///
    /// # Panics
    ///
    /// Panics idan darajar yanzu an aro ta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics idan darajar halin yanzu mutably aro.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Creatirƙira `RefCell<T>`, tare da ƙimar `Default` don T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics idan darajar a ko dai `RefCell` a halin yanzu aro.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementing ara iya haifar da wani maras karanta darajar (<=0) a cikin wadannan lokuta:
            // 1. Yana da aka <0, watau akwai ake rubutu ya yiwo aro, don haka ba za mu iya ba da damar a karanta ara saboda Rust ta tunani aliasing dokoki
            // 2.
            // isize::MAX ne (adadin adadin karatun da ake binta) kuma ya malala zuwa isize::MIN (adadin adadin rubutu) don haka ba za mu iya bada izinin ƙarin karatun bashi ba saboda isize ba zai iya wakiltar yawancin rancen karatu ba (wannan na iya faruwa ne kawai idan ka mem::forget fiye da kananan m adadin `Ref`s, wanda ba shi da kyau yi)
            //
            //
            //
            //
            None
        } else {
            // Incrementing ara iya haifar da wani karatu darajar (> 0) a cikin wadannan lokuta:
            // 1. Yana da aka=0, watau shi ba aro, kuma muna shan farko karanta ara
            // 2. Ya kasance> 0 da <isize::MAX, watau
            // akwai karanta yiwo aro, kuma isize ne babban isa ga wakiltar da ciwon daya mafi karanta ara
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Tun da yake wannan Ref wanzu, mu san ara flag ne mai karatu ranta.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Hana da ranta counter daga ambaliya a cikin wani rubutu ranta.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Shigar a aro tunani zuwa wani darajar a wani `RefCell` akwatin.
/// A wrapper irin for wani immutably aro darajar daga `RefCell<T>`.
///
/// Dubi [module-level documentation](self) for more.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kwafin wani `Ref`.
    ///
    /// `RefCell` ya rigaya an aro bashi madaidaici, don haka wannan ba zai iya kasawa ba.
    ///
    /// Wannan haɗin aiki ne wanda yake buƙatar amfani dashi azaman `Ref::clone(...)`.
    /// A `Clone` aiwatar ko wata hanya zai tsoma baki tare da tartsatsi amfani da `r.borrow().clone()` zuwa clone abinda ke ciki na wani `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Sa wani sabon `Ref` ga wani bangaren na aro bayanai.
    ///
    /// `RefCell` ya rigaya an aro bashi madaidaici, don haka wannan ba zai iya kasawa ba.
    ///
    /// Wannan shi ne wani Associated aiki da ya kamata a yi amfani da matsayin `Ref::map(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Yana yin sabon `Ref` don wani zaɓi na zaɓin bayanan aro.
    /// An dawo da mai tsaron asali azaman `Err(..)` idan rufewa ya dawo `None`.
    ///
    /// `RefCell` ya rigaya an aro bashi madaidaici, don haka wannan ba zai iya kasawa ba.
    ///
    /// Wannan shi ne wani Associated aiki da ya kamata a yi amfani da matsayin `Ref::filter_map(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Tsãgewar ƙwãyar a `Ref` cikin mahara `Ref`s for daban-daban aka gyara na aro bayanai.
    ///
    /// `RefCell` ya rigaya an aro bashi madaidaici, don haka wannan ba zai iya kasawa ba.
    ///
    /// Wannan haɗin aiki ne wanda yake buƙatar amfani dashi azaman `Ref::map_split(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Juya zuwa tunani zuwa asalin bayanan.
    ///
    /// `RefCell` mai mahimmanci ba za a sake aron bashi daga sake ba kuma koyaushe zai bayyana wanda ba shi da rance koyaushe.
    ///
    /// Yana ba kyau ra'ayin zuba fiye da akai yawan nassoshi.
    /// `RefCell` za'a iya a sake bashi bashi idan kawai ƙananan lambobi ne suka faru gaba ɗaya.
    ///
    /// Wannan haɗin aiki ne wanda yake buƙatar amfani dashi azaman `Ref::leak(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // By manta da wannan Ref mu tabbatar da cewa rance counter a RefCell ba zai iya koma zuwa sauran a cikin rayuwa `'b`.
        // Sake tsara zance tracking jihar na bukatar a musamman tunani da aro RefCell.
        // Ba za a sake ƙirƙirar wasu nassoshi masu sauyawa daga asalin tantanin halitta ba.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ya sanya sabon `RefMut` don haɗin bayanan aro, misali, babban bambancin enum.
    ///
    /// `RefCell` ya riga ya kasance bashi aro, don haka wannan ba zai iya kasawa ba.
    ///
    /// Wannan haɗin aiki ne wanda yake buƙatar amfani dashi azaman `RefMut::map(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): gyara bashi-duba
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Yana yin sabon `RefMut` don wani zaɓi na zaɓin bayanan aro.
    /// An dawo da mai tsaron asali azaman `Err(..)` idan rufewa ya dawo `None`.
    ///
    /// `RefCell` ya riga ya kasance bashi aro, don haka wannan ba zai iya kasawa ba.
    ///
    /// Wannan haɗin aiki ne wanda yake buƙatar amfani dashi azaman `RefMut::filter_map(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): gyara bashi-duba
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // KIYAYEWAR: aikin da yake riƙe uwa da wata, tsattsarkar reference domin duration
        // na ta kira ta hanyar `orig`, kuma akan shi ne kawai de-nusar ciki na aiki kira taba barin m reference tserewa.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // KYAUTA: daidai yake da na sama.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Tsãgewar ƙwãyar a `RefMut` cikin mahara `RefMut`s for daban-daban aka gyara na aro bayanai.
    ///
    /// `RefCell` mai mahimmanci zai kasance a matsayin aro har zuwa lokacin da duk suka dawo ``RefMut`s zai wuce gona da iri.
    ///
    /// `RefCell` ya riga ya kasance bashi aro, don haka wannan ba zai iya kasawa ba.
    ///
    /// Wannan haɗin aiki ne wanda yake buƙatar amfani dashi azaman `RefMut::map_split(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Juya zuwa fassarar maye gurbin bayanai masu tushe.
    ///
    /// Ba za a iya aron `RefCell` da ke ƙasa daga sake ba kuma koyaushe zai bayyana riga ya karɓa bashi, yana mai da abin da aka dawo da shi kawai ga cikin.
    ///
    ///
    /// Wannan haɗin aiki ne wanda yake buƙatar amfani dashi azaman `RefMut::leak(...)`.
    /// Wata hanya za ta tsoma baki tare da hanyoyin iri ɗaya akan abubuwan `RefCell` da aka yi amfani da su ta hanyar `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ta hanyar manta wannan BorrowRefMut muna tabbatar da cewa kantin aro a cikin RefCell ba zai iya komawa UNUSED a cikin rayuwar `'b` ba.
        // Sake tsara zance tracking jihar na bukatar a musamman tunani da aro RefCell.
        // Babu wani ƙarin nassoshi da za a ƙirƙira daga asalin tantanin halitta a cikin wannan rayuwar, yana mai ba da rancen na yanzu kawai abin da yake nuni ga sauran rayuwar.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Ba kamar BorrowRefMut::clone ba, ana kiran sabon don ƙirƙirar farkon
        // fassarar da za a iya canzawa, don haka dole ne a halin yanzu babu alamun nassi.
        // Don haka, yayin da clone yana ƙaruwa da sake canzawa, anan muna bayyane kawai bada izinin tafiya daga UNUSED zuwa UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones a `BorrowRefMut`.
    //
    // Wannan yana aiki ne kawai idan ana amfani da kowane `BorrowRefMut` don biye da ambaton maye gurbi zuwa keɓaɓɓen yanki, ba tare da jujjuyawar asalin abin ba.
    //
    // Wannan ba a clone impl haka da cewa code ba kira wannan jabu.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Hana kantin bashi daga ambaliyar.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Nau'in kunsa don darajar aro daga `RefCell<T>`.
///
/// Dubi [module-level documentation](self) for more.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// A core m for ciki mutability a Rust.
///
/// Idan kuna da ma'anar `&T`, to a kullun a cikin Rust mai tarawa yana aiwatar da abubuwa bisa ga ilimin da `&T` ke nunawa ga bayanai mara canzawa.Canza wannan bayanan, misali ta hanyar lakanin baka ko ta hanyar juya `&T` zuwa `&mut T`, ana daukar sa azaman rashin siffa.
/// `UnsafeCell<T>` cirewa daga garantin mara canzawa don `&T`: bayanin da aka raba `&UnsafeCell<T>` na iya nuna bayanan da ake canzawa.Wannan ana kiran sa "interior mutability".
///
/// All sauran iri da cewa ba da damar ciki mutability, kamar `Cell<T>` da `RefCell<T>`, ƙ amfani `UnsafeCell` zuwa kunsa su data.
///
/// Lura cewa kawai garantin canzawa don nassoshi da aka raba ya shafi `UnsafeCell`.Tabbacin keɓaɓɓen garantin nassoshi masu canzawa ba ya tasiri.Akwai *babu* doka hanya kafin su sami aliasing `&mut`, ba ma tare da `UnsafeCell<T>`.
///
/// `UnsafeCell` API da kanta fasaha ce mai sauqi qwarai: [`.get()`] ya baku danyan nuna alama `*mut T` zuwa abinda ke ciki.Ya zuwa _you_ azaman zanen zane don amfani da ɗan madaidaicin maɓallin.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// A daidai Rust aliasing dokoki ne da ɗan cikin juyi, amma babban maki ba husũma:
///
/// - Idan ka ƙirƙiri wani hadari tunani da rayuwa `'a` (ko dai wani `&T` ko `&mut T` reference) cewa shi ne m da lafiya code (misali, domin ku koma da shi), sa'an nan dole ne ka ba samun damar data a duk hanyar da ta saba da tunani ga saura na `'a`.
/// Misali, wannan yana nufin cewa idan ka ɗauki `*mut T` daga `UnsafeCell<T>` ka jefa shi zuwa `&T`, to dole ne bayanan da ke cikin `T` su kasance marasa canzawa (koya kowane bayanan `UnsafeCell` da aka samo a cikin `T`, ba shakka) har sai wannan lokacin ya ƙare.
/// Hakanan, idan kun ƙirƙiri bayanin `&mut T` wanda aka sake shi zuwa lambar kariya, to lallai baza ku sami damar shiga cikin bayanan cikin `UnsafeCell` ba har sai wannan bayanin ya ƙare.
///
/// - A kowane lokaci, dole ne ka guji data jinsi.Idan zaren da yawa suna da damar zuwa iri ɗaya `UnsafeCell`, to kowane marubuci dole ne ya sami abin da ya dace-kafin dangantaka da duk sauran hanyoyin shiga (ko amfani da atomic).
///
/// Don taimakawa tare da ƙira mai kyau, waɗannan al'amuran da ke bayyane bayyane bayyane ga doka don lambar zare ɗaya:
///
/// 1. Za'a iya sakin bayanin `&T` zuwa lambar kariya kuma a can yana iya zama tare da sauran bayanan `&T`, amma ba tare da `&mut T` ba
///
/// 2. Ana iya sakin bayanin `&mut T` zuwa lambar kariya wanda ba wasu `&mut T` ko `&T` ba tare da shi ba.A `&mut T` dole ne ko da yaushe zama na musamman.
///
/// Lura cewa yayin canza abubuwan da ke cikin `&UnsafeCell<T>` (koda kuwa yayin da wasu `&UnsafeCell<T>` suke ambaton laƙabi da kwayar) yana da kyau (idan har zaku iya tilasta masu canzawa ta wata hanyar ta daban), har yanzu ba a bayyana ma'anar ba don samun sunayen laƙabi na `&mut UnsafeCell<T>` da yawa
/// Wannan shi ne, `UnsafeCell` ne a wrapper tsara don samun musamman hulda da _shared_ accesses (_i.e._, ta hanyar wani `&UnsafeCell<_>` reference).Babu sihiri ko yaya yayin ma'amala da _exclusive_ accesses (_e.g._, ta hanyar `&mut UnsafeCell<_>`): babu tantanin halitta ko ƙimar da aka nade ba za a iya lasafta shi ba har tsawon wannan `&mut` aro.
///
/// Wannan ne ya baje kolin ta [`.get_mut()`] accessor, wanda shi ne mai _safe_ getter cewa yã'yan a `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ga wani misali showcasing yadda za a soundly mutate da abinda ke ciki na wani `UnsafeCell<_>` duk da akwai kasancewa mahara nassoshi aliasing da cell:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Samun mahara/lokaci guda/shared nassoshi guda `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // KYAUTA: a cikin wannan yanayin babu wasu nassoshi game da abubuwan `` x '',
///     // don haka namu ya zama na musamman babu kamarsa.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ara-+
///     *p1_exclusive += 27; // |
/// } // <---------- ba zai iya wuce wannan batun ba -------------------+
///
/// unsafe {
///     // KYAUTA: a cikin wannan yanayin babu wanda ke fatan samun damar shiga cikin abubuwan `` x '',
///     // don haka za mu iya samun mahara shared accesses bi-biye.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Misali na gaba yana nuna gaskiyar cewa keɓantaccen damar zuwa `UnsafeCell<T>` yana nuna keɓance ta musamman zuwa ta `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // tare da keɓaɓɓun hanyoyin shiga,
///                         // `UnsafeCell` shine mai rufin buɗe ido ba don komai ba, don haka babu buƙatar `unsafe` anan.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Samu takamaiman bayani na lokaci-lokaci akan `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Tare da wata, tsattsarkar reference, za mu iya mutate da abinda ke ciki for free.
/// *p_unique.get_mut() = 0;
/// // Ko, daidai da:
/// x = UnsafeCell::new(0);
///
/// // Lokacin da muka mallaki ƙimar, zamu iya cire abubuwan ciki kyauta.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Ya gina sabon misali na `UnsafeCell` wanda zai kunshi ƙayyadadden ƙimar.
    ///
    ///
    /// Duk samun damar ƙimar ciki ta hanyoyi shine `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Cire ƙimar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Samun maɓallin canjin yanayi zuwa ƙimar da aka nade.
    ///
    /// Wannan na iya zama simintin zuwa Pointer na kowane irin.
    /// Tabbatar da cewa damar ne musamman (babu aiki nassoshi, mutable ko ba) idan Fitar don `&mut T`, da kuma tabbatar da cewa babu maye gurbi ko mutable sunayen laƙabi faruwa a lokacin da Fitar don `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Za mu iya kawai jefa mauni daga `UnsafeCell<T>` zuwa `T` saboda #[repr(transparent)].
        // Wannan yana amfani da matsayin musamman na libstd, babu garantin lambar mai amfani da wannan zaiyi aiki a cikin sifofin future na mai tarawa!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Yana dawo da ambaton maye gurbin bayanan asali.
    ///
    /// Wannan kira ya yiwo aro da `UnsafeCell` mutably (a tara-lokaci) wanda ya tabbatar da cewa mun mallaki kawai tunani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Samun maɓallin canjin yanayi zuwa ƙimar da aka nade.
    /// Bambanci zuwa [`get`] ne cewa wannan aiki ya yarda da wani raw akan, wanda ke da amfani don kauce wa halittar wucin gadi nassoshi.
    ///
    /// A sakamakon za a iya jefa shi zuwa wani akan na kowane irin.
    /// Tabbatar da cewa damar ne musamman (babu aiki nassoshi, mutable ko ba) idan Fitar don `&mut T`, da kuma tabbatar da cewa babu maye gurbi ko mutable sunayen laƙabi faruwa a lokacin da Fitar don `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Initiaddamarwa a hankali na `UnsafeCell` yana buƙatar `raw_get`, kamar kiran `get` zai buƙaci ƙirƙirar ishara zuwa bayanan da ba a sani ba:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Za mu iya kawai jefa mauni daga `UnsafeCell<T>` zuwa `T` saboda #[repr(transparent)].
        // Wannan yana amfani da matsayin musamman na libstd, babu garantin lambar mai amfani da wannan zaiyi aiki a cikin sifofin future na mai tarawa!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Creatirƙira `UnsafeCell`, tare da ƙimar `Default` don T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}