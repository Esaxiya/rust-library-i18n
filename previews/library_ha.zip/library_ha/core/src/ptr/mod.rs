//! Da kanka sarrafa ƙwaƙwalwa ta hanyar ɗan nuni.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Ayyuka da yawa a cikin wannan kundin suna ɗauke da ɗan alamu kamar mahawara kuma karanta daga gare su ko rubuta musu.Don wannan ya kasance mai aminci, waɗannan alamomin dole ne su kasance *ingantattu*.
//! Ko mai nuna alama yana da inganci ya dogara da aikin da aka yi amfani da shi (karanta ko rubutawa), da kuma iyakar ƙwaƙwalwar da aka samu (watau, baiti nawa ne read/written).
//! Yawancin ayyuka suna amfani da `*mut T` da `* const T` don samun damar ƙimar guda ɗaya kawai, a cikin wannan yanayin takaddun sun bar girman kuma a fakaice sun ɗauka ya zama baiti `size_of::<T>()`.
//!
//! Ba a tantance takamaiman dokoki don inganci ba tukuna.Garantin da aka bayar a wannan gaba kaɗan ne:
//!
//! * Alamar nunawa ta [null] ba *ta taɓa* inganci ba, ba ma don samun damar [size zero][zst] ba.
//! * Don mai nuna alama ya zama mai inganci, ya zama dole, amma ba koyaushe ya isa ba, cewa mai nuna alama ya zama *mai rikon sakainar kashi*: thewayar ƙwaƙwalwar ajiyar girman da aka bayar daga mai nunawa dole ne duka ta kasance a cikin iyakoki ɗaya na kashin abu.
//!
//! Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
//! * Koda don ayyukan [size zero][zst], mai nuna alama bazai nuna ma'anar ƙwaƙwalwar da aka raba ba, ma'ana, rarraba ma'amala ya sa masu nuna alama ba daidai ba har ma da ayyukan sifili ba.
//! Koyaya, jefa kowane lamba mara lamba *a zahiri* zuwa mai nunawa yana da inganci don samun damar sifili, koda kuwa wasu ƙwaƙwalwar sun wanzu a waccan adireshin kuma an raba su.
//! Wannan ya dace da rubuta naka mai rarrabawa: rarraba abubuwa masu girman sifili bashi da wahala.
//! Hanyar canonical don samun nuni wanda ke aiki don samun damar silo-sifili shine [`NonNull::dangling`].
//! * Duk hanyoyin shiga da ayyuka ke aiwatarwa a cikin wannan darasin sune *ba atomic* a ma'anar [atomic operations] da ake amfani dasu don aiki tsakanin zaren.
//! Wannan yana nufin rashin ma'ana ne don yin samfuran shiga guda biyu a wuri guda daga zaren daban sai dai idan duk damar shiga kawai an karanta daga ƙwaƙwalwa.
//! Lura cewa wannan ya fito fili ya haɗa da [`read_volatile`] da [`write_volatile`]: Ba za a iya amfani da damar shiga mara amfani ba don aiki tare da zaren zaren.
//! * Sakamakon jefa abin nuni zuwa manuni yana aiki ne muddin dai ainihin abin yana rayuwa kuma ba a yin amfani da isharar (kawai alamun nunin) don samun damar ƙwaƙwalwar guda.
//!
//! Waɗannan axioms ɗin, tare da amfani da [`offset`] a hankali don ƙididdigar lissafi, sun isa don aiwatar da abubuwa da yawa masu amfani da yawa cikin lambar hadari.
//! Za a bayar da tabbaci mai ƙarfi a ƙarshe, kamar yadda ake ƙaddara dokokin [aliasing].
//! Don ƙarin bayani, duba [book] da kuma ɓangaren da aka ambata akan [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Ingantattun mahimman bayanai kamar yadda aka bayyana a sama ba lallai bane suyi daidai (inda aka bayyana daidaiton "proper" ta nau'in mai gabatarwa, watau, `*const T` dole ne a daidaita shi zuwa `mem::align_of::<T>()`).
//! Koyaya, yawancin ayyuka suna buƙatar hujjojin su don daidaitawa daidai, kuma zasu bayyana wannan buƙatar a bayyane a cikin takardun su.
//! Keɓaɓɓun keɓaɓɓu ga wannan sune [`read_unaligned`] da [`write_unaligned`].
//!
//! Lokacin da aiki ke buƙatar daidaitawa daidai, yana yin hakan koda kuwa damar tana da girma 0, watau, koda kuwa ba a taɓa ƙwaƙwalwa a zahiri ba.Yi la'akari da amfani da [`NonNull::dangling`] a cikin irin waɗannan halaye.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Yana aiwatar da mai halakarwa (idan akwai) na darajar-zuwa darajar.
///
/// Wannan daidai yake da kiran [`ptr::read`] da yin watsi da sakamakon, amma yana da fa'idodi masu zuwa:
///
/// * Yana da *ake buƙata* don amfani da `drop_in_place` don sauke nau'ikan da ba a tantance su ba kamar abubuwa na trait, saboda ba za a iya karanta su a kan tarin ba kuma a sauke kamar yadda aka saba.
///
/// * Ya fi kyau ga mai yin damar yin hakan akan [`ptr::read`] lokacin da aka sauke memorin da aka ware da hannu (misali, a cikin aiwatarwar `Box`/`Rc`/`Vec`), saboda mai tarawa baya buƙatar tabbatar da cewa yana da kyau a kwafe kwafin.
///
///
/// * Ana iya amfani dashi don sauke bayanan [pinned] lokacin da `T` ba `repr(packed)` bane (dole ne a motsa bayanan da aka ƙulla ba kafin a sauke shi).
///
/// Valuesimar da ba a daidaita ba ba za a iya faduwa a wuri ba, dole ne a kwafe su zuwa wuri mai daidaita ta farko ta amfani da [`ptr::read_unaligned`].Don abubuwan da aka shirya, ana yin wannan motsi ta atomatik ta mai tarawa.
/// Wannan yana nufin ba a sauke filayen cushe madaukai a wuri.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `to_drop` dole ne ya zama [valid] don duka karatu da rubutu.
///
/// * `to_drop` Dole ne a yadda ya kamata hada kai.
///
/// * Pointsimar da `to_drop` ta nuna dole ne ya zama daidai don faduwa, wanda ke iya nufin dole ne ya goyi bayan ƙarin masu canzawa, wannan ya dogara da nau'in.
///
/// Bugu da ƙari, idan `T` ba [`Copy`] ba ne, ta amfani da alama mai ƙima bayan kiran `drop_in_place` na iya haifar da halayyar da ba a bayyana ta ba.Lura cewa `*to_drop = foo` ya kirga azaman amfani saboda zai haifar da sake sake ƙimar.
/// [`write()`] za a iya amfani da shi don sake rubuta bayanai ba tare da haifar da sauke shi ba.
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba kuma yayi daidai.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Da kanka cire abu na ƙarshe daga vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Sami ɗan nunawa zuwa ƙarshen abu a cikin `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Rage `v` don hana saukar da abu na ƙarshe.
///     // Muna yin hakan da farko, don hana matsaloli idan `drop_in_place` a ƙasa da panics.
///     v.set_len(1);
///     // Ba tare da kira `drop_in_place` ba, abu na ƙarshe ba zai taɓa faduwa ba, kuma ƙwaƙwalwar ajiyar da yake sarrafawa za ta malalo.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Tabbatar cewa an bar abu na ƙarshe.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Ka lura cewa mai tarawa yana yin wannan kwafin ta atomatik lokacin da yake fadada hanyoyin, watau, ba kasafai ka damu da irin waɗannan lamuran ba sai dai idan ka kira `drop_in_place` da hannu.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Lambar da ke nan ba ta da mahimmanci, ana maye gurbin wannan ta ainihin manne mai ɗowa ta mai tarawa.
    //

    // KYAUTA: duba sharhi a sama
    unsafe { drop_in_place(to_drop) }
}

/// Creatirƙirar maɓallin ɗan nuni mara amfani.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Irƙirar maɓallin manuni mai canzawa mara faɗi.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Ana buƙatar jagorar hannu don kaucewa ɗaure `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Ana buƙatar jagorar hannu don kaucewa ɗaure `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Forms ɗan yanki daga manuni da kuma tsayi.
///
/// A `len` shaida ne yawan **abubuwa**, ba da yawan bytes.
///
/// Wannan aikin yana da aminci, amma a zahiri amfani da ƙimar dawowa ba shi da hadari.
/// Duba takaddun aiki na [`slice::from_raw_parts`] don buƙatun aminci aminci.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // ƙirƙirar maɓallin yanki lokacin da farawa tare da mai nunawa zuwa farkon abun
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // KYAUTA: Samun damar ƙimar daga ƙungiyar `Repr` amintacce ne tun * const [T]
        //
        // kuma FatPtr suna da shimfidar ƙwaƙwalwar ajiya iri ɗaya.std ne kawai ke iya yin wannan garantin.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Yana aiwatar da aiki iri ɗaya kamar na [`slice_from_raw_parts`], sai dai an dawo da wani yanki wanda zai iya canzawa, sabanin ɗanyen da ba zai canja ba.
///
///
/// Duba takardun [`slice_from_raw_parts`] don ƙarin bayani.
///
/// Wannan aikin yana da aminci, amma a zahiri amfani da ƙimar dawowa ba shi da hadari.
/// Duba takaddun aiki na [`slice::from_raw_parts_mut`] don buƙatun aminci aminci.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // sanya ƙima a ma'auni a cikin yanki
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // KYAUTA: Samun damar ƙimar daga ƙungiyar `Repr` amintacce ne tun * mut [T]
        // kuma FatPtr suna da shimfidar ƙwaƙwalwar ajiya iri ɗaya
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Sauya dabi'un a wurare biyu masu sauyawa iri ɗaya, ba tare da lalata ɗaya ba.
///
/// Amma don banda guda biyu masu zuwa, wannan aikin yayi daidai da [`mem::swap`]:
///
///
/// * Yana aiki akan ɗan nuna alamun maimakon nassoshi.
/// Lokacin da aka sami nassoshi, [`mem::swap`] ya kamata a fifita.
///
/// * Valuesimomin nan biyu da aka nuna-na iya cikawa.
/// Idan ƙimomin sun yi ruɗi, to za a yi amfani da yankin ƙwaƙwalwa daga `x`.
/// Ana nuna wannan a misali na biyu a ƙasa.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * Dukansu `x` da `y` dole ne su kasance [valid] don duka karatu da rubutu.
///
/// * Dukansu `x` da `y` dole ne su daidaita daidai.
///
/// Lura cewa koda `T` yana da girman `0`, masu nunin dole ne su zama ba NULL ba kuma su dace sosai.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Sauya yankuna biyu da ba a rufe su ba:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // wannan shine `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // wannan shine `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Sauya yankuna biyu masu juyewa:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // wannan shine `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // wannan shine `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indididdigar `1..3` na yanki sun haɗu tsakanin `x` da `y`.
///     // Sakamakon da ya dace zai kasance a gare su shine `[2, 3]`, don haka fihirisa `0..3` sune `[1, 2, 3]` (daidai da `y` kafin `swap`);ko don su zama `[0, 1]` don haka ƙididdiga `1..4` sune `[0, 1, 2]` (daidai da `x` kafin `swap`).
/////
///     // An bayyana wannan aiwatar don zaɓin na ƙarshe.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Bamu kanmu wasu tarkon sarari da zamuyi aiki dasu.
    // Ba lallai bane mu damu da digo: `MaybeUninit` baya yin komai idan aka sauke shi.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Yi AMFANIN Swap: mai kira dole ne ya bada tabbacin cewa `x` da `y` suna aiki don rubutu kuma suna dacewa sosai.
    // `tmp` ba za a iya yin jujjuya ko dai `x` ko `y` ba saboda an rarraba `tmp` kawai a kan tari a matsayin wani keɓaɓɓen abin da aka keɓance.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` kuma `y` na iya haɗuwa
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Bywa Swaps `count * size_of::<T>()` bytes tsakanin yankuna biyu na ƙwaƙwalwar ajiyar farawa daga `x` da `y`.
/// Dole ne yankuna biyu *ba* zoba.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * Dukansu `x` da `y` dole ne su kasance [valid] don duka karatun da rubuce-rubuce na ƙidaya *
///   Girman: :<T>() baiti
///
/// * Dukansu `x` da `y` dole ne su daidaita daidai.
///
/// * Yankin ƙwaƙwalwar ajiya wanda ya fara a `x` tare da girman `` ƙidaya *
///   Girman: :<T>() `` baiti dole ne *kada* ya ruɓe tare da yankin ƙwaƙwalwar ajiyar farawa daga `y` tare da girm ɗaya.
///
/// Lura cewa ko da an kwafin girman yadda yakamata (``ƙidaya * size_of: :<T>()`` shine `0`, masu nunin dole ne su zama ba NULL ba kuma su dace sosai.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // KYAUTA: mai kira dole ne ya bada tabbacin cewa `x` da `y` ne
    // mai inganci don rubutu kuma ya dace sosai.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Ga nau'ikan da suka kasa inganta abubuwan toshewa a kasa, musanya kai tsaye don kaucewa mummunan zaban codegen.
    //
    if mem::size_of::<T>() < 32 {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `x` da `y` suna aiki
        // don rubutu, daidaitacce daidai, kuma ba mai juyewa ba.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Hanyar anan shine don amfani da simd don musanya x&y yadda yakamata.
    // Gwaji ya nuna cewa sauyawa ko dai bytes 32 ko baiti 64 a lokaci guda ya fi inganci ga masu sarrafa Intel Haswell E.
    // LLVM ya fi ƙarfin inganta idan muka ba da tsari #[repr(simd)], koda kuwa ba za mu yi amfani da wannan tsarin kai tsaye ba.
    //
    //
    // FIXME repr(simd) ya karye akan emscripten da redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Madauki ta hanyar x&y, kwafin su `Block` a lokaci guda Mai ingantawa yakamata ya zare madauki gaba daya don yawancin nau'ikan NB
    // Ba za mu iya amfani da don madauki kamar yadda `range` impl ya kira `mem::swap` a sake ba
    //
    let mut i = 0;
    while i + block_size <= len {
        // Irƙiri wasu ƙwaƙwalwar da ba a san su ba kamar yadda aka bayyana `t` a nan zai hana daidaita jigon lokacin da ba a amfani da wannan madauki
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // KYAUTA: Kamar yadda `i < len`, kuma kamar yadda mai kiran ya bada tabbacin cewa `x` da `y` suna aiki
        // don `len` bytes, `x + i` da `y + i` dole ne su zama ingantattun adiresoshin, waɗanda ke cika yarjejeniyar aminci ga `add`.
        //
        // Hakanan, mai kiran dole ne ya tabbatar da cewa `x` da `y` suna da inganci don rubutu, daidaito daidai, da rashin juyewa, wanda ke cika yarjejeniyar aminci ga `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Musayar wani baiti na x&y, ta amfani da t azaman ajiyar wucin gadi Wannan ya kamata a inganta shi cikin ingantattun ayyukan SIMD inda akwai
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Musayar kowane baiti
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // KYAUTA: duba sharhin tsaro na baya.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Matsar da `src` cikin nuna `dst`, yana dawo da ƙimar `dst` da ta gabata.
///
/// Babu ƙimar da aka bari.
///
/// Wannan aikin yayi daidai da [`mem::replace`] banda cewa yana aiki akan ɗan nuna alamun maimakon nassoshi.
/// Lokacin da aka sami nassoshi, [`mem::replace`] ya kamata a fifita.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `dst` dole ne ya zama [valid] don duka karatu da rubutu.
///
/// * `dst` Dole ne a yadda ya kamata hada kai.
///
/// * `dst` dole ne ya nuna ƙimar kirkirar nau'in `T`.
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba kuma yayi daidai.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` zai sami sakamako iri ɗaya ba tare da buƙatar toshe mara lafiya ba.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // KYAUTA: mai kira dole ne ya tabbatar da cewa `dst` ya kasance mai inganci
    // jefawa zuwa fassarar da za a iya canzawa (mai inganci don rubutu, mai haɗa kai, farawa), kuma ba zai iya jujjuya `src` ba tunda dole ne `dst` ya nuna wani abu da aka ware.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ba zai iya zoba
    }
    src
}

/// Karanta ƙimar daga `src` ba tare da motsa shi ba.Wannan ya bar ƙwaƙwalwar ajiya a cikin `src` mara canzawa.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `src` dole ne ya zama [valid] don karantawa.
///
/// * `src` dole ne a daidaita shi sosai.Yi amfani da [`read_unaligned`] idan wannan ba haka bane.
///
/// * `src` dole ne ya nuna ƙimar kirkirar nau'in `T`.
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba kuma yayi daidai.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Aiwatar da [`mem::swap`] da hannu:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Createirƙiri ɗan kwafin darajar a `a` a cikin `tmp`.
///         let tmp = ptr::read(a);
///
///         // Fitawa a wannan lokacin (ko dai ta hanyar dawo da bayyane ko kuma kiran wani aiki wanda panics) zai sa a rage darajar a cikin `tmp` yayin da wannan darajar har yanzu ana ambata ta `a`.
///         // Wannan na iya haifar da halayyar da ba a bayyana ta ba idan `T` ba `Copy` ba ne.
/////
/////
///
///         // Createirƙiri ɗan kwafin darajar a `b` a cikin `a`.
///         // Wannan amintacce ne saboda nassoshi masu canzawa baza su iya kiransa da suna ba
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kamar yadda yake a sama, fita daga nan na iya haifar da halayyar da ba a bayyana ta ba saboda ƙimar iri ɗaya ana ambata ta `a` da `b`.
/////
///
///         // Matsar da `tmp` cikin `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` an motsa (`write` ya mallaki hujjarsa ta biyu), don haka babu abin da aka sauke a fakaice a nan.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Mallakar Darajan Da Aka dawo
///
/// `read` ƙirƙirar ɗan kwafin `T`, ba tare da la'akari ko `T` shine [`Copy`] ba.
/// Idan `T` ba [`Copy`] bane, ta amfani da ƙimar da aka dawo da ita da ƙimar a `*src` na iya keta amincin ƙwaƙwalwa.
/// Lura cewa sanyawa ga `*src` ya ƙidaya azaman amfani saboda zaiyi ƙoƙarin sauke darajar a `* src`.
///
/// [`write()`] za a iya amfani da shi don sake rubuta bayanai ba tare da haifar da sauke shi ba.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` yanzu yana nuna mahimmin ƙwaƙwalwar ajiya kamar `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Sanya zuwa `s2` yana sa a sauke asalin darajarta.
///     // Bayan wannan lokacin, dole ne a daina amfani da `s`, saboda an 'yantar da tushen ƙwaƙwalwar.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Sanya zuwa `s` zai sa a sake sauke tsohuwar darajar, wanda hakan ke haifar da halayyar da ba a bayyana ta ba.
/////
///     // s= String::from("bar");//KUSKURE
///
///     // `ptr::write` ana iya amfani dashi don sake rubuta ƙima ba tare da faduwa ba.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KYAUTA: mai kira dole ne ya bada tabbacin cewa `src` yana aiki don karantawa.
    // `src` ba zai iya zowa da `tmp` ba saboda an rarraba `tmp` kawai a kan tari a matsayin wani keɓaɓɓen abin da aka keɓance.
    //
    //
    // Hakanan, tunda mun rubuta ingancin aiki a cikin `tmp`, ana tabbatar da an fara shi yadda yakamata.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Karanta ƙimar daga `src` ba tare da motsa shi ba.Wannan ya bar ƙwaƙwalwar ajiya a cikin `src` mara canzawa.
///
/// Ba kamar [`read`] ba, `read_unaligned` yana aiki tare da alamomin da ba a daidaita su ba.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `src` dole ne ya zama [valid] don karantawa.
///
/// * `src` dole ne ya nuna ƙimar kirkirar nau'in `T`.
///
/// Kamar [`read`], `read_unaligned` ya ƙirƙiri ɗan kwafin `T`, ba tare da la'akari ko `T` shine [`Copy`] ba.
/// Idan `T` ba [`Copy`] bane, ta amfani da duka darajar da aka dawo da ita da darajar a `*src` na iya [violate memory safety][read-ownership].
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## A kan ci gaba na `packed`
///
/// Ba shi yiwuwa a halin yanzu ƙirƙirar ɗan manuniya zuwa filayen da ba a daidaita su ba.
///
/// Attoƙarin ƙirƙirar ɗan nuni mai mahimmanci zuwa filin tsarin `unaligned` tare da magana kamar `&packed.unaligned as *const FieldType` ya haifar da matsakaiciyar matsakaiciyar tunani kafin canza wannan zuwa ma'anar ma'ana.
///
/// Cewa wannan bayanin na ɗan lokaci ne kuma nan da nan jefawa ba shi da ma'ana kamar yadda mai tarawa koyaushe yana buƙatar nassoshi su dace daidai.
/// Sakamakon haka, amfani da `&packed.unaligned as *const FieldType` yana haifar da* halin da ba a bayyana ba * a cikin shirinku.
///
/// Misali na abin da ba za a yi ba kuma yadda wannan ya danganta da `read_unaligned` shine:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Anan muna ƙoƙari mu ɗauki adireshin adadin-32 mai lamba wanda bai daidaita ba.
///     let unaligned =
///         // An ƙirƙiri bayanin ɗan lokaci mara izini a nan wanda ke haifar da halayyar da ba a bayyana ta ba ko da kuwa an yi amfani da bayanin ko a'a.
/////
///         &packed.unaligned
///         // Fitar da ɗan madaidaicin manuni ba ya taimaka;kuskuren ya riga ya faru.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Samun dama ga filayen da ba a daidaita ba kai tsaye tare da misali `packed.unaligned` yana da aminci duk da haka.
///
///
///
///
///
///
// FIXME: Sabunta takardu bisa ga sakamakon RFC #2582 da abokai.
/// # Examples
///
/// Karanta ƙimar amfani daga ma'aji
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KYAUTA: mai kira dole ne ya bada tabbacin cewa `src` yana aiki don karantawa.
    // `src` ba zai iya zowa da `tmp` ba saboda an rarraba `tmp` kawai a kan tari a matsayin wani keɓaɓɓen abin da aka keɓance.
    //
    //
    // Hakanan, tunda mun rubuta ingancin aiki a cikin `tmp`, ana tabbatar da an fara shi yadda yakamata.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Share bayanan ƙwaƙwalwa tare da ƙimar da aka bayar ba tare da karantawa ko sauke tsohuwar ƙimar ba.
///
/// `write` baya sauke abubuwan da ke cikin `dst`.
/// Wannan amintacce ne, amma yana iya zubo rabe-raben ko albarkatu, don haka ya kamata a kula kada a sake rubuta abin da ya kamata a bari.
///
///
/// Ari, ba ya sauke `src`.Semantically, `src` ya koma cikin wurin da `dst` ya nuna.
///
/// Wannan ya dace don fara ƙwaƙwalwar da ba a san komai ba, ko overwriting memorin da a baya ya kasance [`read`] daga.
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `dst` dole ne ya zama [valid] don rubutawa.
///
/// * `dst` dole ne a daidaita shi sosai.Yi amfani da [`write_unaligned`] idan wannan ba haka bane.
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba kuma yayi daidai.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Aiwatar da [`mem::swap`] da hannu:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Createirƙiri ɗan kwafin darajar a `a` a cikin `tmp`.
///         let tmp = ptr::read(a);
///
///         // Fitawa a wannan lokacin (ko dai ta hanyar dawo da bayyane ko kuma kiran wani aiki wanda panics) zai sa a rage darajar a cikin `tmp` yayin da wannan darajar har yanzu ana ambata ta `a`.
///         // Wannan na iya haifar da halayyar da ba a bayyana ta ba idan `T` ba `Copy` ba ne.
/////
/////
///
///         // Createirƙiri ɗan kwafin darajar a `b` a cikin `a`.
///         // Wannan amintacce ne saboda nassoshi masu canzawa baza su iya kiransa da suna ba
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kamar yadda yake a sama, fita daga nan na iya haifar da halayyar da ba a bayyana ta ba saboda ƙimar iri ɗaya ana ambata ta `a` da `b`.
/////
///
///         // Matsar da `tmp` cikin `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` an motsa (`write` ya mallaki hujjarsa ta biyu), don haka babu abin da aka sauke a fakaice a nan.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Muna kiran abubuwan da ke cikin intanet kai tsaye don kauce wa kiraye-kiraye a cikin lambar da aka samar kamar yadda `intrinsics::copy_nonoverlapping` aiki ne mai rufewa.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // KYAUTA: mai kira dole ne ya bada tabbacin cewa `dst` yana aiki don rubutu.
    // `dst` ba zai iya rufe `src` ba saboda mai kiran yana da damar sauyawa zuwa `dst` yayin da `src` mallakar wannan aikin ne.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Share bayanan ƙwaƙwalwa tare da ƙimar da aka bayar ba tare da karantawa ko sauke tsohuwar ƙimar ba.
///
/// Ba kamar [`write()`] ba, mai nunin ba zai iya daidaitawa ba.
///
/// `write_unaligned` baya sauke abubuwan da ke cikin `dst`.Wannan amintacce ne, amma yana iya zubo rabe-raben ko albarkatu, don haka ya kamata a kula kada a sake rubuta abin da ya kamata a bari.
///
/// Ari, ba ya sauke `src`.Semantically, `src` ya koma cikin wurin da `dst` ya nuna.
///
/// Wannan ya dace don farawa ƙwaƙwalwar ajiya, ko sake ƙwaƙwalwar ajiya wanda aka karanta a baya tare da [`read_unaligned`].
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `dst` dole ne ya zama [valid] don rubutawa.
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba.
///
/// [valid]: self#safety
///
/// ## A kan ci gaba na `packed`
///
/// Ba shi yiwuwa a halin yanzu ƙirƙirar ɗan manuniya zuwa filayen da ba a daidaita su ba.
///
/// Attoƙarin ƙirƙirar ɗan nuni mai mahimmanci zuwa filin tsarin `unaligned` tare da magana kamar `&packed.unaligned as *const FieldType` ya haifar da matsakaiciyar matsakaiciyar tunani kafin canza wannan zuwa ma'anar ma'ana.
///
/// Cewa wannan bayanin na ɗan lokaci ne kuma nan da nan jefawa ba shi da ma'ana kamar yadda mai tarawa koyaushe yana buƙatar nassoshi su dace daidai.
/// Sakamakon haka, amfani da `&packed.unaligned as *const FieldType` yana haifar da* halin da ba a bayyana ba * a cikin shirinku.
///
/// An misali da abin da ba su yi da kuma yadda wannan dangantaka da `write_unaligned` ne:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Anan muna ƙoƙari mu ɗauki adireshin adadin-32 mai lamba wanda bai daidaita ba.
///     let unaligned =
///         // An ƙirƙiri bayanin ɗan lokaci mara izini a nan wanda ke haifar da halayyar da ba a bayyana ta ba ko da kuwa an yi amfani da bayanin ko a'a.
/////
///         &mut packed.unaligned
///         // Fitar da ɗan madaidaicin manuni ba ya taimaka;kuskuren ya riga ya faru.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Samun dama ga filayen da ba a daidaita ba kai tsaye tare da misali `packed.unaligned` yana da aminci duk da haka.
///
///
///
///
///
///
///
///
///
// FIXME: Sabunta takardu bisa ga sakamakon RFC #2582 da abokai.
/// # Examples
///
/// Rubuta ƙimar amfani ga ma'aji
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // KYAUTA: mai kira dole ne ya bada tabbacin cewa `dst` yana aiki don rubutu.
    // `dst` ba zai iya rufe `src` ba saboda mai kiran yana da damar sauyawa zuwa `dst` yayin da `src` mallakar wannan aikin ne.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Muna kiran ainihin abin kai tsaye don kauce wa kiran aiki a cikin lambar da aka samar.
        intrinsics::forget(src);
    }
}

/// Yayi karatun mai canzawa daga darajar daga `src` ba tare da motsa shi ba.Wannan ya bar ƙwaƙwalwar ajiya a cikin `src` mara canzawa.
///
/// Ayyuka masu canzawa suna da niyyar aiki akan ƙwaƙwalwar I/O, kuma ana da tabbacin ba za a goge su ko sake dawo da su ta hanyar sauran ayyukan ba.
///
/// # Notes
///
/// Rust a halin yanzu bashi da ingantaccen samfurin ƙirar ƙwaƙwalwa, don haka madaidaitan ma'anonin abin da "volatile" ke nufi anan ana iya canza su akan lokaci.
/// Da aka faɗi haka, ilimin fassara kusan koyaushe yana ƙare da kama da [C11's definition of volatile][c11].
///
/// Mai harhadawa bazai canza tsarin dangi ko yawan ayyukan ƙwaƙwalwar da ke canzawa ba.
/// Koyaya, ayyukan ƙwaƙwalwar ajiya mai canzawa akan nau'ikan sifa iri (misali, idan aka ba da nau'ikan sikili zuwa `read_volatile`) ana yin su ne kuma ana iya yin biris dasu.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `src` dole ne ya zama [valid] don karantawa.
///
/// * `src` Dole ne a yadda ya kamata hada kai.
///
/// * `src` dole ne ya nuna ƙimar kirkirar nau'in `T`.
///
/// Kamar [`read`], `read_volatile` ya ƙirƙiri ɗan kwafin `T`, ba tare da la'akari ko `T` shine [`Copy`] ba.
/// Idan `T` ba [`Copy`] bane, ta amfani da duka darajar da aka dawo da ita da darajar a `*src` na iya [violate memory safety][read-ownership].
/// Koyaya, adana nau'ikan-```Copy`] a ƙwaƙwalwar ajiya mai canzawa kusan ba daidai bane.
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba kuma yayi daidai.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Kamar dai yadda yake a cikin C, shin aiki zai iya canzawa bashi da wata ma'ana dangane da tambayoyin da suka shafi samun dama kai tsaye daga zaren da yawa.Hanyoyin samun canji mara salo suna nuna halayyar su kamar hanyoyin da ba atom atom ba.
///
/// Musamman, tsere tsakanin `read_volatile` da kowane aikin rubutawa zuwa wuri ɗaya shine halin da ba'a bayyana ba.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ba tsoro ba don ci gaba da tasirin codegen karami.
        abort();
    }
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Yi rubutu mai ma'ana game da wurin ƙwaƙwalwar ajiya tare da ƙimar da aka bayar ba tare da karantawa ko sauke tsohuwar ƙimar ba.
///
/// Ayyuka masu canzawa suna da niyyar aiki akan ƙwaƙwalwar I/O, kuma ana da tabbacin ba za a goge su ko sake dawo da su ta hanyar sauran ayyukan ba.
///
/// `write_volatile` baya sauke abubuwan da ke cikin `dst`.Wannan amintacce ne, amma yana iya zubo rabe-raben ko albarkatu, don haka ya kamata a kula kada a sake rubuta abin da ya kamata a bari.
///
/// Ari, ba ya sauke `src`.Semantically, `src` ya koma cikin wurin da `dst` ya nuna.
///
/// # Notes
///
/// Rust a halin yanzu bashi da ingantaccen samfurin ƙirar ƙwaƙwalwa, don haka madaidaitan ma'anonin abin da "volatile" ke nufi anan ana iya canza su akan lokaci.
/// Da aka faɗi haka, ilimin fassara kusan koyaushe yana ƙare da kama da [C11's definition of volatile][c11].
///
/// Mai harhadawa bazai canza tsarin dangi ko yawan ayyukan ƙwaƙwalwar da ke canzawa ba.
/// Koyaya, ayyukan ƙwaƙwalwar ajiya mai canzawa a kan nau'ikan sifa iri (misali, idan aka ba da nau'ikan sikili zuwa `write_volatile`) ɓoyayyiya ne kuma ana iya watsi da su.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `dst` dole ne ya zama [valid] don rubutawa.
///
/// * `dst` Dole ne a yadda ya kamata hada kai.
///
/// Lura cewa koda `T` nada girman `0`, dole ne mai nunin ya zama ba NULL ba kuma yayi daidai.
///
/// [valid]: self#safety
///
/// Kamar dai yadda yake a cikin C, shin aiki zai iya canzawa bashi da wata ma'ana dangane da tambayoyin da suka shafi samun dama kai tsaye daga zaren da yawa.Hanyoyin samun canji mara salo suna nuna halayyar su kamar hanyoyin da ba atom atom ba.
///
/// Musamman, tsere tsakanin `write_volatile` da kowane aiki (karatu ko rubutu) akan wuri ɗaya shine halin da ba'a bayyana ba.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ba tsoro ba don ci gaba da tasirin codegen karami.
        abort();
    }
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Sanya alamar `p`.
///
/// Lissafin daidaitawa (dangane da abubuwan hawa na `stride`) wanda dole ne ayi amfani da shi akan mai nuna alama `p` don mai nuna alama `p` ya daidaita zuwa `a`.
///
/// Note: An tsara wannan aiwatar a hankali don ba panic.UB ne don wannan zuwa panic.
/// Iyakar canjin canjin da za a iya yi a nan shi ne canji na `INV_TABLE_MOD_16` da abubuwan haɗin kai.
///
/// Idan har muka yanke shawarar sanya damar kiran mara hankali tare da `a` wanda ba shi da iko-da-biyu, tabbas zai iya zama mai hankali ne kawai don kawai canzawa zuwa aiwatar da butulci maimakon ƙoƙarin daidaita wannan don dacewa da canjin.
///
///
/// Duk wani tambaya sai a je@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Amfani kai tsaye na waɗannan abubuwan na yau da kullun yana inganta codegen sosai a matakin zaɓi <=
    // 1, inda ba a zana sifofin hanyar waɗannan ayyukan ba.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Lissafi masu jujjuya salon sarkakke na `x` modulo `m`.
    ///
    /// An tsara wannan aiwatarwa don `align_offset` kuma yana da ƙa'idodi masu zuwa:
    ///
    /// * `m` yana da iko-na-biyu;
    /// * `x < m`; (idan `x ≥ m`, wucewa cikin `x % m` maimakon)
    ///
    /// Aiwatar da wannan aikin bazai panic ba.Ya kasance.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tableabi'ar juzu'i mai jujjuyawar salon juzu'i 2⁴=16.
        ///
        /// Lura, cewa wannan teburin ba ya ƙunsar ƙimomin da inda babu akasi (watau, na `0⁻¹ mod 16`, `2⁻¹ mod 16`, da sauransu)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo wanda aka tsara `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KYAUTA: Ana buƙatar `m` ya zama mai ƙarfi-na-biyu, saboda haka ba sifili.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Muna sanya "up" ta amfani da tsari mai zuwa:
            //
            // $$ xy ≡ 1 (yanayin 2ⁿ) y xy (2, xy) ≡ 1 (yanayin 2²ⁿ) $$
            //
            // har sai 2²ⁿ ≥ m.Sa'an nan ba za mu iya rage ga so `m` da shan sakamakon `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) yanayin n
                //
                // Lura, cewa muna amfani da ayyukan nadewa anan da gangan-asalin dabara yana amfani da misali, ragi `mod n`.
                // Yana da kyau gaba ɗaya ayi musu `mod usize::MAX` a maimakon haka, saboda muna ɗaukar sakamakon `mod n` a ƙarshen ta wata hanya.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // KYAUTA: `a` mai ƙarfi ne na biyu, saboda haka ba sifili ba.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` ana iya lissafin harka a sauƙaƙe ta hanyar `-p (mod a)`, amma yin hakan yana hana ikon LLVM zaɓi zaɓi umarni kamar `lea`.Madadin haka muke lissafi
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // wanda ke rarraba ayyuka a kusa da ɗaukar kaya, amma ɓatar da `and` sosai don LLVM don iya amfani da abubuwan haɓaka da ya sani game da su.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // An riga an daidaitaYay!
        return 0;
    } else if stride == 0 {
        // Idan mai nuna alama bai daidaita ba, kuma nauyin yana da sifilai, to babu adadin abubuwan da zasu taba daidaita alamar.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // KYAUTA: a shine ikon-na-biyu saboda haka ba sifili.stride==0 hali ne abar kulawa a sama.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // KYAUTA: gcdpow yana da maɓallin sama wanda yake mafi yawa yawan ragowa a cikin amfani.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // KYAUTA: gcd koyaushe yana girma ko daidai da 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Wannan branch yana warware matsalar lissafin haɗin linzami mai zuwa:
        //
        // ` p + so = 0 mod a `
        //
        // `p` a nan ne ƙimar nunawa, `s`, tarko na `T`, ƙaddamar da `o` a cikin ``T`s, da `a`, daidaitawa da aka nema.
        //
        // Tare da `g = gcd(a, s)`, da yanayin da ke sama yana tabbatar da cewa `p` shima ana raba shi ta `g`, zamu iya nuna `a' = a/g`, `s' = s/g`, `p' = p/g`, to wannan ya zama daidai da:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Kalmar farko itace "the relative alignment of `p` to `a`" (aka raba ta `g`), na biyu kuma shine "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (kuma aka sake raba shi da `g`).
        //
        // Rabawa ta `g` ya zama dole don samar da kishiyar da kyau idan `a` da `s` ba su kasance tare da Firayim.
        //
        // Bugu da ƙari, sakamakon da aka samar ta wannan maganin ba "minimal" bane, saboda haka ya zama dole a ɗauki sakamakon `o mod lcm(s, a)`.Zamu iya maye gurbin `lcm(s, a)` tare da `a'` kawai.
        //
        //
        //
        //
        //

        // KYAUTA: `gcdpow` yana da ɗaurin sama wanda bai fi adadin rarar 0-bits a cikin `a` ba.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // KYAUTA: `a2` ba sifili bane.Canza `a` ta `gcdpow` ba zai iya canza kowane ɗayan ragin ba
        // a cikin `a` (wanda yana da daidai ɗaya).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // KYAUTA: `gcdpow` yana da ɗaurin sama wanda bai fi adadin rarar 0-bits a cikin `a` ba.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // KYAUTA: `gcdpow` yana da ɗaurin sama wanda bai fi adadin rarar 0-bits a ciki ba
        // `a`.
        // Bugu da ƙari, ragi ba zai iya yin ambaliya ba, saboda `a2 = a >> gcdpow` koyaushe zai fi tsananin ƙarfi fiye da `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // KYAUTA: `a2` mai ƙarfi ne-biyu, kamar yadda aka tabbatar a sama.`s2` ba shi da ƙarfi sosai fiye da `a2`
        // saboda `(s % a) >> gcdpow` yayi tsananin kasa da `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ba za a iya daidaita ba kwata-kwata.
    usize::MAX
}

/// Kwatanta ɗan manuniya don daidaito.
///
/// Wannan daidai yake da amfani da mai aikin `==`, amma mafi ƙanƙanci:
/// tilas ne muhawara ta zama dole ta zama alama ta `*const T`, ba wani abu da ke aiwatar da `PartialEq` ba.
///
/// Ana iya amfani da wannan don kwatanta nassoshi na `&T` (wanda ke tilasta `*const T` kai tsaye) ta adireshin su maimakon kwatanta ƙimar da suke nunawa (wanda shine abin da aiwatar da `PartialEq for &T` ke yi).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Hakanan ana amfani da yanki ta tsayinsu (mai nuna mai):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Hakanan ana kwatanta Traits ta hanyar aiwatar dasu:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Lambobi suna da adireshi daidai.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Abubuwa suna da adreshin daidai, amma `Trait` yana da aiwatarwa daban-daban.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ana canza bayanin zuwa `*const u8` ana gwama shi ta adireshin.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash wani ɗan alama.
///
/// Ana iya amfani da wannan don zana bayanan `&T` (wanda ke tilasta `*const T` a fakaice) ta adireshinsa maimakon ƙimar da yake nunawa (wanda shine abin da aiwatar da `Hash for &T` ke yi).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Sanyawa don alamomin aiki
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ana buƙatar matsakaicin matsakaici kamar yadda ake amfani dashi don AVR
                // ta yadda za a adana sararin adireshin maɓallin aikin tushe a cikin ƙarshen aikin nunawa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ana buƙatar matsakaicin matsakaici kamar yadda ake amfani dashi don AVR
                // ta yadda za a adana sararin adireshin maɓallin aikin tushe a cikin ƙarshen aikin nunawa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Babu ayyuka masu banbanci tare da sigogi 0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Createirƙira ɗan alamar `const` mai ma'ana zuwa wuri, ba tare da ƙirƙirar matsakaiciyar tunani ba.
///
/// Isirƙirar tunani tare da `&`/`&mut` ana ba da izinin ne kawai idan mai nuna alama ya daidaita kuma ya nuna bayanan da aka fara.
/// Don shari'o'in da waɗancan buƙatun ba su riƙe ba, yakamata a yi amfani da ɗan nuna alama.
/// Koyaya, `&expr as *const _` ya ƙirƙiri tunani kafin jefa shi zuwa ɗan gajeren abu, kuma wannan bayanin yana ƙarƙashin ƙa'idodi iri ɗaya da duk sauran bayanan.
///
/// Wannan macro na iya ƙirƙirar ɗan nuna alama *ba tare da* ƙirƙirar abin da za a fara ba.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` zai haifar da wani tunani wanda ba a tsara shi ba, kuma don haka ya zama hava'idar da ba a Fayyace ba!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Createirƙira ɗan alamar `mut` mai ma'ana zuwa wuri, ba tare da ƙirƙirar matsakaiciyar tunani ba.
///
/// Isirƙirar tunani tare da `&`/`&mut` ana ba da izinin ne kawai idan mai nuna alama ya daidaita kuma ya nuna bayanan da aka fara.
/// Don shari'o'in da waɗancan buƙatun ba su riƙe ba, yakamata a yi amfani da ɗan nuna alama.
/// Koyaya, `&mut expr as *mut _` ya ƙirƙiri tunani kafin jefa shi zuwa ɗan gajeren abu, kuma wannan bayanin yana ƙarƙashin ƙa'idodi iri ɗaya da duk sauran bayanan.
///
/// Wannan macro na iya ƙirƙirar ɗan nuna alama *ba tare da* ƙirƙirar abin da za a fara ba.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` zai haifar da wani tunani wanda ba a tsara shi ba, kuma don haka ya zama hava'idar da ba a Fayyace ba!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` tilasta yin kwafin filin maimakon ƙirƙirar tunani.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}