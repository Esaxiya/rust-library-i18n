use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Yana dawowa `true` idan mai nunin baya aiki.
    ///
    /// Lura cewa nau'ikan da ba a tantance su ba suna da alamomi marasa ma'ana da yawa, saboda kawai ana nuna madogarar bayanan bayanai ne, ba tsayin su ba, vtable, da dai sauransu.
    /// Sabili da haka, alamomi biyu waɗanda ba su da amfani har yanzu ba za a iya kwatanta su da juna ba.
    ///
    /// ## Hali yayin kimantawa
    ///
    /// Lokacin da aka yi amfani da wannan aikin yayin kimantawar, zai iya dawo da `false` don alamomin da suka zama wofi a lokacin aiki.
    /// Musamman, lokacin da mai nunawa zuwa wasu ƙwaƙwalwar ajiyar ta daidaita abin da ya wuce iyakarta ta yadda abin da mai nunin da ya biyo baya ya ɓace, aikin zai ci gaba da dawowa `false`.
    ///
    /// Babu wata hanyar da CTFE zata iya sanin matsayin wannan abin tunawa, saboda haka baza mu iya sanin idan mai nunin ya baci ba.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Kwatanta ta hanyar simintin gyare-gyare zuwa matsakaiciyar manuni, don haka masu nunin mai kawai suna la'akari da sashinsu na "data" don null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Sanya wa mai nuna wani nau'in.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Rarraba mai nuna alama (mai yuwuwa mai fadi) zuwa cikin adireshin da abubuwan metadata.
    ///
    /// Daga baya za'a iya sake gina mai nuna alama tare da [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Yana dawo da `None` idan mai nunin ya baci, ko kuma ya dawo da bayanin da aka raba akan darajar da aka nannade ta `Some`.Idan ƙimar ba ta da wayewa, dole ne a yi amfani da [`as_uninit_ref`] maimakon.
    ///
    /// Don takwaran da zai iya canzawa duba [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa *ko dai* mai nuna alama NULL ne *ko* duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne mai nuna alama ya nuna misali na farawa na `T`.
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za ta canza ba (sai dai a cikin `UnsafeCell`).
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    /// (Bangaren da aka fara ba a yanke hukunci ba tukuna, amma har sai ya kasance, hanya mafi aminci ita ce a tabbatar da cewa an fara su.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Sigar da ba a duba shi ba
    ///
    /// Idan ka tabbata mai nuna alama ba zai taba yin banza ba kuma suna neman wasu nau'ikan `as_ref_unchecked` wadanda suka dawo da `&T` maimakon `Option<&T>`, ka sani cewa zaka iya soke mai nuna kai tsaye.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // KYAUTA: mai kira dole ne ya tabbatar da cewa `self` ya dace da a
        // nuni idan ba wofi ba
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Yana dawo da `None` idan mai nunin ya baci, ko kuma ya dawo da rabon magana game da ƙimar da aka nade a cikin `Some`.
    /// Ya bambanta da [`as_ref`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takwaran da zai iya canzawa duba [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa *ko dai* mai nuna alama NULL ne *ko* duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za ta canza ba (sai dai a cikin `UnsafeCell`).
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don tunani.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calculates da biya diyya daga Pointer.
    ///
    /// `count` yana cikin raka'a T;misali, `count` na 3 yana wakiltar maƙasudin nunawa na baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Idan aka keta ɗaya daga cikin sharuɗɗan masu zuwa, sakamakon shine ndea'idar da ba a Fayyace ba:
    ///
    /// * Duk mai nuna alama da farawa da kuma sakamakonta dole ne ya zama ko dai ya wuce iyaka ko baiti daya ya wuce ƙarshen abin da aka ware.
    /// Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
    ///
    /// * Setididdigar lissafin,**a bytes**, ba zai iya cika `isize` ba.
    ///
    /// * Kuskuren kasancewa cikin iyakoki ba zai iya dogara da "wrapping around" sararin adireshin ba.Wato, jimla marar daidaituwa,**a baiti** dole ne ya dace da amfani.
    ///
    /// Mai harhadawa da ingantaccen ɗakin karatu gabaɗaya suna ƙoƙari don tabbatar da rabe-raben ba su kai girman inda abin damuwa yake ba.
    /// Misali, `Vec` da `Box` sun tabbatar da cewa basu taba raba fiye da `isize::MAX` baiti, don haka `vec.as_ptr().add(vec.len())` koyaushe bashi da aminci.
    ///
    /// Yawancin dandamali da asali ba ma za su iya yin irin wannan kason ba.
    /// Misali, babu wani sanannen dandamali 64-bit da zai taɓa yin buƙata don baiti 2 <sup>63</sup> saboda iyakokin tebur na shafi ko raba sararin adireshin.
    /// Koyaya, wasu dandamali 32-bit da 16-bit zasu iya samun nasarar gabatar da buƙata don fiye da `isize::MAX` bytes tare da abubuwa kamar Fadada Adireshin Jiki.
    ///
    /// Kamar wannan, ƙwaƙwalwar da aka samo kai tsaye daga masu rarrabawa ko fayilolin taswirar ƙwaƙwalwa *na iya zama* babba da yawa don iya ɗauka tare da wannan aikin.
    ///
    /// Yi la'akari da amfani da [`wrapping_offset`] maimakon idan waɗannan ƙuntatawa suna da wahalar gamsarwa.
    /// Amfani da wannan hanyar ita ce kawai don haɓaka haɓakar haɓaka mai ƙarfi.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `offset`.
        // Alamar da aka samo tana aiki don rubutu tunda mai kiran dole ne ya bada tabbacin cewa yana nuni zuwa abu guda da aka ware kamar `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Ana kirga abin da ya rage daga ma'ana ta amfani da lissafin kunsa.
    /// `count` yana cikin raka'a T;misali, `count` na 3 yana wakiltar maƙasudin nunawa na baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Wannan aikin kansa koyaushe yana da aminci, amma amfani da maɓallin bayanan da aka samu ba haka bane.
    ///
    /// Sakamakon mai nunawa yana nan a haɗe da abin da aka ware wanda `self` ya nuna.
    /// Yana iya *ba* a yi amfani da shi don samun damar wani abin da aka ware ba.Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
    ///
    /// Watau, `let z = x.wrapping_offset((y as isize) - (x as isize))` baiyi * sanya `z` daidai da na `y` ba koda kuwa zamu ɗauka `T` yana da girman `1` kuma babu ambaliyar: `z` har yanzu a haɗe yake da abin da `x` ke haɗe, kuma ƙaddamar da shi Halin da ba a Fayyace bane sai dai idan `x` da `y` ya nuna cikin abin da aka ware.
    ///
    /// Idan aka kwatanta da [`offset`], wannan hanyar tana jinkirta jinkirin kasancewa cikin abu guda da aka ware: [`offset`] shine Uabi'a mara Tsammani lokacin da yake keta iyakar abin;`wrapping_offset` yana samar da mahimmin bayani amma har yanzu yana haifar da Bayyanar da Halaye idan aka nuna ragowar bayanan lokacin da ya wuce gona da iri akan abin da aka makala shi.
    /// [`offset`] za a iya inganta shi da kyau kuma don haka an fi so a cikin lambar ƙwarewar aiki.
    ///
    /// Binciken da aka jinkirta yana la'akari da ƙimar maɓallin da aka ɓata, ba ƙimar matsakaiciyar da aka yi amfani da ita yayin lissafin sakamakon ƙarshe ba.
    /// Misali, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` koyaushe iri ɗaya ne da `x`.A wasu kalmomin, barin abin da aka ba shi sannan sake shigar da shi daga baya an halatta.
    ///
    /// Idan kana bukatar ratsa iyakokin abin, jefa jakar zuwa lamba kuma kayi lissafi a wurin.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // Yi amfani da ma'anar ɗan ma'ana a cikin ƙarin abubuwa biyu
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KYAUTA: ainihin `arith_offset` bashi da wasu abubuwan da ake buƙata da za a kira shi.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Yana dawo da `None` idan mai nunin ya baci, ko kuma ya dawo da wani abin duba na musamman akan ƙimar da aka nannade ta `Some`.Idan ƙimar ba ta da wayewa, dole ne a yi amfani da [`as_uninit_mut`] maimakon.
    ///
    /// Don takaddar da aka raba duba [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa *ko dai* mai nuna alama NULL ne *ko* duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne mai nuna alama ya nuna misali na farawa na `T`.
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za a sami dama gare shi ba (karanta ko rubuta) ta kowane maɓallin.
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    /// (Bangaren da aka fara ba a yanke hukunci ba tukuna, amma har sai ya kasance, hanya mafi aminci ita ce a tabbatar da cewa an fara su.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Zai buga: "[4, 2, 3]".
    /// ```
    ///
    /// # Sigar da ba a duba shi ba
    ///
    /// Idan ka tabbata mai nuna alama ba zai taba yin banza ba kuma suna neman wasu nau'ikan `as_mut_unchecked` wadanda suka dawo da `&mut T` maimakon `Option<&mut T>`, ka sani cewa zaka iya soke mai nuna kai tsaye.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Zai buga: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // KYAUTA: mai kira dole ne ya tabbatar da cewa `self` yana aiki don
        // fassarar canzawa idan ba wofi ba.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Yana dawo da `None` idan mai nunin ba komai bane, ko kuma ya dawo da wata alama ta musamman akan ƙimar da aka lulluɓe a cikin `Some`.
    /// Ya bambanta da [`as_mut`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takaddar da aka raba duba [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa *ko dai* mai nuna alama NULL ne *ko* duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za a sami dama gare shi ba (karanta ko rubuta) ta kowane maɓallin.
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don tunani.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Ya dawo ko masu nuni biyu tabbas an daidaita su.
    ///
    /// A lokacin gudu wannan aikin yana nuna kamar `self == other`.
    /// Koyaya, a wasu mahallin (misali, ƙididdige lokaci), ba koyaushe ake iya tantance daidaiton maki biyu ba, don haka wannan aikin na iya dawo da `false` cikin ma'ana don masu nuni wanda daga baya ya zama daidai.
    ///
    /// Amma idan ya dawo `true`, an tabbatar masu alamomin sun daidaita.
    ///
    /// Wannan aikin shine madubin [`guaranteed_ne`], amma ba akasin haka bane.Akwai kwatancen kwatancen da ayyukan biyu suka dawo da `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Returnimar dawowa zata iya canzawa ya dogara da sigar mai tarawa kuma lambar da ba amintacciya ba zata dogara da sakamakon wannan aikin don ƙararrawa ba.
    /// An ba da shawarar cewa kawai a yi amfani da wannan aikin don abubuwan haɓakawa inda ƙa'idodin dawo da `false` ta wannan aikin ba zai shafi sakamako ba, amma kawai aikin.
    /// Ba a bincika illolin amfani da wannan hanyar don yin lokacin gudu da tsara lokacin-aiki da lamura daban-daban ba.
    /// Bai kamata a yi amfani da wannan hanyar don gabatar da irin waɗannan bambance-bambancen ba, kuma ya kamata kuma ba za a daidaita ba kafin mu sami fahimtar wannan batun sosai.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Ya dawo ko an tabbatar masu nuni biyu ba daidai ba.
    ///
    /// A lokacin gudu wannan aikin yana nuna kamar `self != other`.
    /// Koyaya, a wasu mahallin (misali, ƙididdige lokaci), ba koyaushe ake iya tantance rashin daidaiton maki biyu ba, don haka wannan aikin na iya dawo da `false` cikin ma'ana don daga baya wanda a zahiri ya zama bai zama daidai ba.
    ///
    /// Amma lokacin da ya dawo `true`, ana ba da tabbacin alamun ba daidai ba.
    ///
    /// Wannan aikin shine madubin [`guaranteed_eq`], amma ba akasin haka bane.Akwai kwatancen kwatancen da ayyukan biyu suka dawo da `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Returnimar dawowa zata iya canzawa ya dogara da sigar mai tarawa kuma lambar da ba amintacciya ba zata dogara da sakamakon wannan aikin don ƙararrawa ba.
    /// An ba da shawarar cewa kawai a yi amfani da wannan aikin don abubuwan haɓakawa inda ƙa'idodin dawo da `false` ta wannan aikin ba zai shafi sakamako ba, amma kawai aikin.
    /// Ba a bincika illolin amfani da wannan hanyar don yin lokacin gudu da tsara lokacin-aiki da lamura daban-daban ba.
    /// Bai kamata a yi amfani da wannan hanyar don gabatar da irin waɗannan bambance-bambancen ba, kuma ya kamata kuma ba za a daidaita ba kafin mu sami fahimtar wannan batun sosai.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Ya kirga nisa tsakanin maki biyu.Valueimar da aka dawo tana cikin raka'a T: nesa tsakanin baiti an raba ta `mem::size_of::<T>()`.
    ///
    /// Wannan aikin shine akasin [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Idan aka keta ɗaya daga cikin sharuɗɗan masu zuwa, sakamakon shine ndea'idar da ba a Fayyace ba:
    ///
    /// * Duk mai farawa da sauran mai nuna alama dole ne ya kasance a cikin iyaka ko byte ɗaya ya ƙare ƙarshen abin da aka ware.
    /// Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
    ///
    /// * Dole ne duk alamun biyu su kasance *samu daga* mai nunawa zuwa abu guda.
    ///   (Duba ƙasa don misali.)
    ///
    /// * Nisa tsakanin masu nunin, a cikin baiti, dole ne ya zama ya zama daidai na girman girman `T`.
    ///
    /// * Nisa tsakanin masu nuna alama,**a baiti**, ba zai iya cika `isize` ba.
    ///
    /// * Nisan kasancewa cikin iyakoki bazai iya dogaro da "wrapping around" sararin adireshin ba.
    ///
    /// Nau'in Rust bai fi girman `isize::MAX` ba kuma rarar Rust ba ta taɓa zagaye sararin adireshin ba, don haka masu nuni biyu a cikin wasu ƙimar kowane nau'in Rust nau'in `T` koyaushe za su gamsar da yanayi biyu na ƙarshe.
    ///
    /// Tabbataccen ɗakin karatu yana tabbatar da cewa rarar ba ta kai girman inda abin damuwa yake ba.
    /// Misali, `Vec` da `Box` sun tabbatar da cewa basu taba raba sama da baiti `isize::MAX` ba, don haka `ptr_into_vec.offset_from(vec.as_ptr())` yakan gamsar da yanayi biyu na ƙarshe.
    ///
    /// Yawancin dandamali da asali ba ma za su iya yin irin wannan babban kason ba.
    /// Misali, babu wani sanannen dandamali 64-bit da zai taɓa yin buƙata don baiti 2 <sup>63</sup> saboda iyakokin tebur na shafi ko raba sararin adireshin.
    /// Koyaya, wasu dandamali 32-bit da 16-bit zasu iya samun nasarar gabatar da buƙata don fiye da `isize::MAX` bytes tare da abubuwa kamar Fadada Adireshin Jiki.
    /// Kamar wannan, ƙwaƙwalwar da aka samo kai tsaye daga masu rarrabawa ko fayilolin taswirar ƙwaƙwalwa *na iya zama* babba da yawa don iya ɗauka tare da wannan aikin.
    /// (Lura cewa [`offset`] da [`add`] suma suna da irin wannan iyakancewa don haka baza'a iya amfani da su akan waɗannan manyan abubuwan ba.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Wannan aikin panics idan `T` shine nau'in Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Ba daidai ba* amfani:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Sanya ptr2_wani "alias" na ptr2, amma an samo daga ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Tunda ptr2_other da ptr2 sun samo asali ne daga masu nunawa zuwa abubuwa daban-daban, ƙididdigar ƙididdigar su dabi'a ce wacce ba a bayyana ta ba, duk da cewa suna nuni zuwa adireshi ɗaya!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Halin da ba a bayyana ba
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Yana kirga abubuwan da aka biya daga mai nunawa (dacewa ga `.offset(count as isize)`).
    ///
    /// `count` yana cikin raka'a T;misali, `count` na 3 yana wakiltar maƙasudin nunawa na baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Idan aka keta ɗaya daga cikin sharuɗɗan masu zuwa, sakamakon shine ndea'idar da ba a Fayyace ba:
    ///
    /// * Duk mai nuna alama da farawa da kuma sakamakonta dole ne ya zama ko dai ya wuce iyaka ko baiti daya ya wuce ƙarshen abin da aka ware.
    /// Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
    ///
    /// * Setididdigar lissafin,**a bytes**, ba zai iya cika `isize` ba.
    ///
    /// * Kuskuren kasancewa cikin iyakoki ba zai iya dogara da "wrapping around" sararin adireshin ba.Wancan shine, ƙididdigar ƙididdiga mara iyaka dole ta dace a cikin `usize`.
    ///
    /// Mai harhadawa da ingantaccen ɗakin karatu gabaɗaya suna ƙoƙari don tabbatar da rabe-raben ba su kai girman inda abin damuwa yake ba.
    /// Misali, `Vec` da `Box` sun tabbatar da cewa basu taba raba fiye da `isize::MAX` baiti, don haka `vec.as_ptr().add(vec.len())` koyaushe bashi da aminci.
    ///
    /// Yawancin dandamali da asali ba ma za su iya yin irin wannan kason ba.
    /// Misali, babu wani sanannen dandamali 64-bit da zai taɓa yin buƙata don baiti 2 <sup>63</sup> saboda iyakokin tebur na shafi ko raba sararin adireshin.
    /// Koyaya, wasu dandamali 32-bit da 16-bit zasu iya samun nasarar gabatar da buƙata don fiye da `isize::MAX` bytes tare da abubuwa kamar Fadada Adireshin Jiki.
    ///
    /// Kamar wannan, ƙwaƙwalwar da aka samo kai tsaye daga masu rarrabawa ko fayilolin taswirar ƙwaƙwalwa *na iya zama* babba da yawa don iya ɗauka tare da wannan aikin.
    ///
    /// Yi la'akari da amfani da [`wrapping_add`] maimakon idan waɗannan ƙuntatawa suna da wahalar gamsarwa.
    /// Amfani da wannan hanyar ita ce kawai don haɓaka haɓakar haɓaka mai ƙarfi.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Yana kirga abubuwan da aka biya daga maɓalli (saukakawa ga `` offset ((ƙidaya azaman isize).wrapping_neg())`)).
    ///
    /// `count` yana cikin raka'a T;misali, `count` na 3 yana wakiltar maƙasudin nunawa na baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Idan aka keta ɗaya daga cikin sharuɗɗan masu zuwa, sakamakon shine ndea'idar da ba a Fayyace ba:
    ///
    /// * Duk mai nuna alama da farawa da kuma sakamakonta dole ne ya zama ko dai ya wuce iyaka ko baiti daya ya wuce ƙarshen abin da aka ware.
    /// Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
    ///
    /// * Setididdigar lissafin ba zai iya wuce `isize::MAX`**bytes** ba.
    ///
    /// * Kuskuren kasancewa cikin iyakoki ba zai iya dogara da "wrapping around" sararin adireshin ba.Wato, ƙididdigar ƙididdigar rashin iyaka dole ne ta dace da amfani.
    ///
    /// Mai harhadawa da ingantaccen ɗakin karatu gabaɗaya suna ƙoƙari don tabbatar da rabe-raben ba su kai girman inda abin damuwa yake ba.
    /// Misali, `Vec` da `Box` sun tabbatar da cewa basu taba raba fiye da `isize::MAX` baiti, don haka `vec.as_ptr().add(vec.len()).sub(vec.len())` koyaushe bashi da aminci.
    ///
    /// Yawancin dandamali da asali ba ma za su iya yin irin wannan kason ba.
    /// Misali, babu wani sanannen dandamali 64-bit da zai taɓa yin buƙata don baiti 2 <sup>63</sup> saboda iyakokin tebur na shafi ko raba sararin adireshin.
    /// Koyaya, wasu dandamali 32-bit da 16-bit zasu iya samun nasarar gabatar da buƙata don fiye da `isize::MAX` bytes tare da abubuwa kamar Fadada Adireshin Jiki.
    ///
    /// Kamar wannan, ƙwaƙwalwar da aka samo kai tsaye daga masu rarrabawa ko fayilolin taswirar ƙwaƙwalwa *na iya zama* babba da yawa don iya ɗauka tare da wannan aikin.
    ///
    /// Yi la'akari da amfani da [`wrapping_sub`] maimakon idan waɗannan ƙuntatawa suna da wahalar gamsarwa.
    /// Amfani da wannan hanyar ita ce kawai don haɓaka haɓakar haɓaka mai ƙarfi.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ana kirga abin da ya rage daga ma'ana ta amfani da lissafin kunsa.
    /// (dacewa don `.wrapping_offset(count as isize)`)
    ///
    /// `count` yana cikin raka'a T;misali, `count` na 3 yana wakiltar maƙasudin nunawa na baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Wannan aikin kansa koyaushe yana da aminci, amma amfani da maɓallin bayanan da aka samu ba haka bane.
    ///
    /// Sakamakon mai nunawa yana nan a haɗe da abin da aka ware wanda `self` ya nuna.
    /// Yana iya *ba* a yi amfani da shi don samun damar wani abin da aka ware ba.Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
    ///
    /// Watau, `let z = x.wrapping_add((y as usize) - (x as usize))` baiyi * sanya `z` daidai da na `y` ba koda kuwa zamu ɗauka `T` yana da girman `1` kuma babu ambaliyar: `z` har yanzu a haɗe yake da abin da `x` ke haɗe, kuma ƙaddamar da shi Halin da ba a Fayyace bane sai dai idan `x` da `y` ya nuna cikin abin da aka ware.
    ///
    /// Idan aka kwatanta da [`add`], wannan hanyar tana jinkirta jinkirin kasancewa cikin abu guda da aka ware: [`add`] shine Uabi'a mara Tsammani lokacin da yake keta iyakar abin;`wrapping_add` yana samar da mahimmin bayani amma har yanzu yana haifar da Bayyanar da Halaye idan aka nuna ragowar bayanan lokacin da ya wuce gona da iri akan abin da aka makala shi.
    /// [`add`] za a iya inganta shi da kyau kuma don haka an fi so a cikin lambar ƙwarewar aiki.
    ///
    /// Binciken da aka jinkirta yana la'akari da ƙimar maɓallin da aka ɓata, ba ƙimar matsakaiciyar da aka yi amfani da ita yayin lissafin sakamakon ƙarshe ba.
    /// Misali, `x.wrapping_add(o).wrapping_sub(o)` koyaushe iri ɗaya ne da `x`.A wasu kalmomin, barin abin da aka ba shi sannan sake shigar da shi daga baya an halatta.
    ///
    /// Idan kana bukatar ratsa iyakokin abin, jefa jakar zuwa lamba kuma kayi lissafi a wurin.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // Yi amfani da ma'anar ɗan ma'ana a cikin ƙarin abubuwa biyu
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Wannan madauki ya buga "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ana kirga abin da ya rage daga ma'ana ta amfani da lissafin kunsa.
    /// (dacewa ga `` .wrapping_offset ((ƙidaya azaman isize).wrapping_neg())`).)
    ///
    /// `count` yana cikin raka'a T;misali, `count` na 3 yana wakiltar maƙasudin nunawa na baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Wannan aikin kansa koyaushe yana da aminci, amma amfani da maɓallin bayanan da aka samu ba haka bane.
    ///
    /// Sakamakon mai nunawa yana nan a haɗe da abin da aka ware wanda `self` ya nuna.
    /// Yana iya *ba* a yi amfani da shi don samun damar wani abin da aka ware ba.Lura cewa a cikin Rust, kowane mai canzawa na (stack-allocated) ana ɗaukarsa wani abu ne na daban.
    ///
    /// Watau, `let z = x.wrapping_sub((x as usize) - (y as usize))` baiyi * sanya `z` daidai da na `y` ba koda kuwa zamu ɗauka `T` yana da girman `1` kuma babu ambaliyar: `z` har yanzu a haɗe yake da abin da `x` ke haɗe, kuma ƙaddamar da shi Halin da ba a Fayyace bane sai dai idan `x` da `y` ya nuna cikin abin da aka ware.
    ///
    /// Idan aka kwatanta da [`sub`], wannan hanyar tana jinkirta jinkirin kasancewa cikin abu guda da aka ware: [`sub`] shine Uabi'a mara Tsammani lokacin da yake keta iyakar abin;`wrapping_sub` yana samar da mahimmin abu amma har yanzu yana haifar da Bayyanar da Halaye idan aka nuna ragowar bayanan lokacin da ya wuce gona da iri akan abin da aka makala shi.
    /// [`sub`] za a iya inganta shi da kyau kuma don haka an fi so a cikin lambar ƙwarewar aiki.
    ///
    /// Binciken da aka jinkirta yana la'akari da ƙimar maɓallin da aka ɓata, ba ƙimar matsakaiciyar da aka yi amfani da ita yayin lissafin sakamakon ƙarshe ba.
    /// Misali, `x.wrapping_add(o).wrapping_sub(o)` koyaushe iri ɗaya ne da `x`.A wasu kalmomin, barin abin da aka ba shi sannan sake shigar da shi daga baya an halatta.
    ///
    /// Idan kana bukatar ratsa iyakokin abin, jefa jakar zuwa lamba kuma kayi lissafi a wurin.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // Yi amfani da ma'anar ɗan ma'ana a cikin ƙarin abubuwa biyu (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Wannan madauki ya buga "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Ya saita darajar alama zuwa `ptr`.
    ///
    /// Idan `self` alama ce ta (fat) zuwa nau'in da ba a tantance shi ba, wannan aikin zai shafi ɓangaren maɓallin kawai, alhali kuwa masu nuna (thin) zuwa nau'ikan girma, wannan yana da sakamako iri ɗaya kamar aiki mai sauƙi.
    ///
    /// Mai nuna alama zai sami tabbaci na `val`, watau, don mai nuna mai, wannan aikin daidai yake da ƙirƙirar sabon mai nuna mai mai ƙimar bayanai na `val` amma metadata na `self`.
    ///
    ///
    /// # Examples
    ///
    /// Wannan aikin yana da amfani mai mahimmanci don ba da izinin lissafin lissafin lissafi akan alamun mai yiwuwa:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // zai buga "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // KYAUTA: Idan hali na ɗan siriri, waɗannan ayyukan iri ɗaya ne
        // zuwa karamin aiki.
        // Game da mai nuna mai, tare da aiwatar da shimfiɗa mai nuna mai a yanzu, filin farko na irin wannan mai nunawa koyaushe shine mai nuna bayanai, wanda kuma aka sanya shi.
        //
        unsafe { *thin = val };
        self
    }

    /// Karanta ƙimar daga `self` ba tare da motsa shi ba.
    /// Wannan ya bar ƙwaƙwalwar ajiya a cikin `self` mara canzawa.
    ///
    /// Duba [`ptr::read`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na ``.
        unsafe { read(self) }
    }

    /// Yayi karatun mai canzawa daga darajar daga `self` ba tare da motsa shi ba.Wannan ya bar ƙwaƙwalwar ajiya a cikin `self` mara canzawa.
    ///
    /// Ayyuka masu canzawa suna da niyyar aiki akan ƙwaƙwalwar I/O, kuma ana da tabbacin ba za a goge su ko sake dawo da su ta hanyar sauran ayyukan ba.
    ///
    ///
    /// Duba [`ptr::read_volatile`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Karanta ƙimar daga `self` ba tare da motsa shi ba.
    /// Wannan ya bar ƙwaƙwalwar ajiya a cikin `self` mara canzawa.
    ///
    /// Ba kamar `read` ba, mai nunin ba zai iya daidaitawa ba.
    ///
    /// Duba [`ptr::read_unaligned`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kwafa `count * size_of<T>` baiti daga `self` zuwa `dest`.
    /// Tushen da inda aka dosa na iya zoba.
    ///
    /// NOTE: wannan yana da tsari iri ɗaya * iri ɗaya kamar [`ptr::copy`].
    ///
    /// Duba [`ptr::copy`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kwafa `count * size_of<T>` baiti daga `self` zuwa `dest`.
    /// Tushen da inda aka dosa na iya *ba* zoba.
    ///
    /// NOTE: wannan yana da tsari iri ɗaya * iri ɗaya kamar [`ptr::copy_nonoverlapping`].
    ///
    /// Duba [`ptr::copy_nonoverlapping`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kwafa `count * size_of<T>` baiti daga `src` zuwa `self`.
    /// Tushen da inda aka dosa na iya zoba.
    ///
    /// NOTE: wannan yana da *kishiyar* tsarin jayayya na [`ptr::copy`].
    ///
    /// Duba [`ptr::copy`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Kwafa `count * size_of<T>` baiti daga `src` zuwa `self`.
    /// Tushen da inda aka dosa na iya *ba* zoba.
    ///
    /// NOTE: wannan yana da *kishiyar* tsarin jayayya na [`ptr::copy_nonoverlapping`].
    ///
    /// Duba [`ptr::copy_nonoverlapping`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Yana aiwatar da mai halakarwa (idan akwai) na darajar-zuwa darajar.
    ///
    /// Duba [`ptr::drop_in_place`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Share bayanan ƙwaƙwalwa tare da ƙimar da aka bayar ba tare da karantawa ko sauke tsohuwar ƙimar ba.
    ///
    ///
    /// Duba [`ptr::write`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `write`.
        unsafe { write(self, val) }
    }

    /// Yana neman memati a kan takamaiman manuniya, yana saita baiti na `count * size_of::<T>()` na ƙwaƙwalwar da ke farawa daga `self` zuwa `val`.
    ///
    ///
    /// Duba [`ptr::write_bytes`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Yi rubutu mai ma'ana game da wurin ƙwaƙwalwar ajiya tare da ƙimar da aka bayar ba tare da karantawa ko sauke tsohuwar ƙimar ba.
    ///
    /// Ayyuka masu canzawa suna da niyyar aiki akan ƙwaƙwalwar I/O, kuma ana da tabbacin ba za a goge su ko sake dawo da su ta hanyar sauran ayyukan ba.
    ///
    ///
    /// Duba [`ptr::write_volatile`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Share bayanan ƙwaƙwalwa tare da ƙimar da aka bayar ba tare da karantawa ko sauke tsohuwar ƙimar ba.
    ///
    ///
    /// Ba kamar `write` ba, mai nunin ba zai iya daidaitawa ba.
    ///
    /// Duba [`ptr::write_unaligned`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Sauya ƙimar a `self` tare da `src`, yana dawo da tsohuwar ƙimar, ba tare da faduwa ko ɗaya ba.
    ///
    ///
    /// Duba [`ptr::replace`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `replace`.
        unsafe { replace(self, src) }
    }

    /// Sauya dabi'un a wurare biyu masu sauyawa iri ɗaya, ba tare da lalata ɗaya ba.
    /// Za su iya ruɓewa, sabanin `mem::swap` wanda yake daidai yake.
    ///
    /// Duba [`ptr::swap`] don damuwar tsaro da misalai.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `swap`.
        unsafe { swap(self, with) }
    }

    /// Utesididdiga abubuwan da aka buƙata wanda ake buƙatar amfani dasu akan maɓallin don daidaita shi zuwa `align`.
    ///
    /// Idan ba zai yiwu a daidaita ma'anar ba, aiwatarwar ta dawo da `usize::MAX`.
    /// Ya halatta don aiwatarwa zuwa *koda yaushe* dawo da `usize::MAX`.
    /// Ayyukanka na algorithm kawai zasu iya dogaro da samun daidaitaccen amfani anan, ba daidaitanta ba.
    ///
    /// An bayyana abin da yake biya a cikin adadin abubuwa `T`, kuma ba bytes ba.Ana iya amfani da ƙimar da aka dawo tare da hanyar `wrapping_add`.
    ///
    /// Babu tabbaci ko yaya abin da ke daidaita maɓallin ba zai wuce gona da iri ba ko kuma ya zarce rabon da mai nuna ya nuna.
    ///
    /// Ya rage ga mai kiran don tabbatar da cewa abin da aka dawo da shi daidai ne ta kowane fanni ban da daidaitawa.
    ///
    /// # Panics
    ///
    /// Aikin panics idan `align` ba ƙarfi-na-biyu bane.
    ///
    /// # Examples
    ///
    /// Samun dama kusa da `u8` azaman `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // yayin da Pointer za a iya hada kai via `offset`, shi zai nuna a waje da kasafi
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // KYAUTA: An duba `align` don ƙarfin 2 ne a sama
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Ya dawo da tsawon ɗanyan yanki.
    ///
    /// Valueimar da aka dawo ita ce lambar **abubuwa**, ba lambar baiti ba.
    ///
    /// Wannan aikin yana da aminci, koda kuwa baza'a iya jefa ɗanyen yanki zuwa ga yanki ba saboda maɓallin ya ɓace ko bai daidaita ba.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // KYAUTA: wannan yana da aminci saboda `*const [T]` da `FatPtr<T>` suna da tsari iri ɗaya.
            // `std` ne kawai ke iya yin wannan garantin.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Yana dawo da ɗan manunin manuni zuwa maɓallin ajiyar yanki.
    ///
    /// Wannan yayi daidai da jefa `self` zuwa `*mut T`, amma mafi aminci-aminci.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Ya dawo da ɗan madaidaicin maɓallin abu ko ƙarami, ba tare da yin binciken iyaka ba.
    ///
    /// Kira wannan hanyar da lambar wuce gona da iri ko kuma lokacin da `self` ba za a iya soke shi ba * wannan ba shi da ma'ana ko kuma ba a yi amfani da shi ba.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // KYAUTA: mai kiran ya tabbatar da cewa `self` ba za a iya raba shi ba kuma `index` ya wuce iyaka.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Yana dawo da `None` idan mai nunin ya baci, ko kuma ya dawo da wani yanki da aka raba zuwa ƙimar da aka nannade ta `Some`.
    /// Ya bambanta da [`as_ref`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takwaran da zai iya canzawa duba [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa *ko dai* mai nuna alama NULL ne *ko* duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya zama [valid] don karantawa don `ptr.len() * mem::size_of::<T>()` da yawa bytes, kuma dole ne ya zama daidai ya dace.Wannan yana nufin musamman:
    ///
    ///     * Dukan kewayon ƙwaƙwalwar wannan yanki dole ne a ƙunshe cikin abu guda da aka ware!
    ///       Yankuna ba zai taba yin fadin abubuwa da yawa ba.
    ///
    ///     * Dole ne maɓallin nuna alama ya daidaita ko da don yanke-sifili.
    ///     Aya daga cikin dalilan wannan shine cewa ingantaccen tsarin shimfida lissafi na iya dogaro da nassoshi (gami da yanka kowane tsayi) ana daidaita su kuma basa zama mara amfani don bambanta su da sauran bayanan.
    ///
    ///     Kuna iya samo maɓallin da za a iya amfani dashi azaman `data` don yanke-tsayin tsaka mai amfani da [`NonNull::dangling()`].
    ///
    /// * Adadin girman `ptr.len() * mem::size_of::<T>()` na yanki dole ne ya zama bai fi `isize::MAX` girma ba.
    ///   Duba takardun aminci na [`pointer::offset`].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za ta canza ba (sai dai a cikin `UnsafeCell`).
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// Duba kuma [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Yana dawo da `None` idan mai nunin ya baci, ko kuma ya dawo da wani yanki na musamman zuwa ƙimar da aka nannade ta `Some`.
    /// Ya bambanta da [`as_mut`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takaddar da aka raba duba [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa *ko dai* mai nuna alama NULL ne *ko* duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya zama [valid] don karantawa da rubutu don `ptr.len() * mem::size_of::<T>()` da yawa bytes, kuma dole ne ya zama daidai ya dace.Wannan yana nufin musamman:
    ///
    ///     * Dukan kewayon ƙwaƙwalwar wannan yanki dole ne a ƙunshe cikin abu guda da aka ware!
    ///       Yankuna ba zai taba yin fadin abubuwa da yawa ba.
    ///
    ///     * Dole ne maɓallin nuna alama ya daidaita ko da don yanke-sifili.
    ///     Aya daga cikin dalilan wannan shine cewa ingantaccen tsarin shimfida lissafi na iya dogaro da nassoshi (gami da yanka kowane tsayi) ana daidaita su kuma basa zama mara amfani don bambanta su da sauran bayanan.
    ///
    ///     Kuna iya samo maɓallin da za a iya amfani dashi azaman `data` don yanke-tsayin tsaka mai amfani da [`NonNull::dangling()`].
    ///
    /// * Adadin girman `ptr.len() * mem::size_of::<T>()` na yanki dole ne ya zama bai fi `isize::MAX` girma ba.
    ///   Duba takardun aminci na [`pointer::offset`].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za a sami dama gare shi ba (karanta ko rubuta) ta kowane maɓallin.
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// Duba kuma [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Daidaita wa masu nuna alama
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}