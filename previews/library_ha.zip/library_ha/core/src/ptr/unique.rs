use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Kunsawa a kusa da danyen da ba wofi ba `*mut T` wanda ke nuna cewa mai wannan rigar ya mallaki mai gabatar da karar.
/// Amfani don gina zane-zane kamar `Box<T>`, `Vec<T>`, `String`, da `HashMap<K, V>`.
///
/// Ba kamar `*mut T` ba, `Unique<T>` yana nuna "as if" yana misalin `T`.
/// Yana aiwatar da `Send`/`Sync` idan `T` shine `Send`/`Sync`.
/// Hakanan yana haifar da nau'in ƙaƙƙarfan lamuni wanda ke ba da tabbacin misalin `T` na iya tsammanin:
/// bai kamata a canza fasalin mai nuni ba tare da wata hanya ta musamman da ta mallake ta ba.
///
/// Idan baku da tabbas ko daidai ne a yi amfani da `Unique` don dalilanku, yi la'akari da amfani da `NonNull`, wanda ke da rauni a ilimin fassara.
///
///
/// Ba kamar `*mut T` ba, dole ne mai nunin koyaushe ya zama mara banza, ko da kuwa mai nunawa ba a taɓa cire shi ba.
/// Wannan don enms suyi amfani da wannan ƙimar da aka hana azaman mai nuna bambanci-`Option<Unique<T>>` yana da girman daidai da `Unique<T>`.
/// Duk da haka mai nuna alama na iya yin harbawa idan ba a rubuta shi ba.
///
/// Ba kamar `*mut T` ba, `Unique<T>` yana da yawa akan `T`.
/// Wannan yakamata ya zama daidai ga kowane nau'i wanda ke ɗaukar buƙatun laƙabi na Musamman.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: wannan alamar ba ta da wani sakamako ga bambancin ra'ayi, amma ya zama dole
    // don sauke don fahimtar cewa a hankali muna mallakar `T`.
    //
    // Don cikakkun bayanai, duba:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` masu nuni sune `Send` idan `T` shine `Send` saboda bayanan da suke ishara basu da tsari.
/// Lura cewa wannan mai canzawa mara izini ba'a ƙarfafa shi ta hanyar nau'in nau'in;abstraction ta amfani da `Unique` dole ne ya tilasta shi.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` masu nuni sune `Sync` idan `T` shine `Sync` saboda bayanan da suke ishara basu da tsari.
/// Lura cewa wannan mai canzawa mara izini ba'a ƙarfafa shi ta hanyar nau'in nau'in;abstraction ta amfani da `Unique` dole ne ya tilasta shi.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Irƙiri sabon `Unique` wanda yake walƙiya, amma ya dace.
    ///
    /// Wannan yana da amfani don farawa iri wanda cikin kasala ke kasaftawa, kamar `Vec::new` yayi.
    ///
    /// Lura cewa ƙimar manuni na iya wakiltar mai nuna alama mai inganci zuwa `T`, wanda ke nufin wannan ba za a yi amfani da shi azaman darajar sentinel "not yet initialized" ba.
    /// Nau'ikan da kasala ke kasaftawa dole ne su bi diddigin farawa ta wasu hanyoyin.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // KYAUTA: mem::align_of() ya dawo da mahimmin aiki, mara amfani.Da
        // yanayin girmamawa don kiran new_unchecked() haka ake girmamawa.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Irƙiri sabon `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` dole ne ba wofi.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `ptr` ba wofi bane.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Irƙiri sabon `Unique` idan `ptr` ba wofi bane.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KYAUTA: An riga an bincika alamar kuma ba wofi ba ne.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Samun mahimmin alamar `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences da abun ciki.
    ///
    /// Sakamakon rayuwa yana ɗaure ne da kai saboda haka wannan yana nuna "as if" hakika ainihin misalin T ne wanda yake aron.
    /// Idan ana buƙatar tsawon rayuwar (unbound), yi amfani da `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don tunani.
        unsafe { &*self.as_ptr() }
    }

    /// Da kansa ya ɓata abubuwan.
    ///
    /// Sakamakon rayuwa yana ɗaure ne da kai saboda haka wannan yana nuna "as if" hakika ainihin misalin T ne wanda yake aron.
    /// Idan ana buƙatar tsawon rayuwar (unbound), yi amfani da `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don canjin canjin yanayi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Sanya wa mai nuna wani nau'in.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // KYAUTA: Unique::new_unchecked() ya ƙirƙiri sabon abu mai mahimmanci da buƙatu
        // alamar da aka ba ta ba ta zama banza ba.
        // Tunda muna wucewa kai a matsayin mai nunawa, ba zai iya zama wofi ba.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KYAUTA: Magana mai canzawa ba zata zama fanko ba
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}