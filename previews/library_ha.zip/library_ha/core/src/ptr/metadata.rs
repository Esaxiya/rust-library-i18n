#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Yana bayar da nau'in nau'in metadata na nunawa na kowane irin-nuna.
///
/// # Inarin metadata
///
/// Ana iya yin tunanin nau'ikan manunin bayanai da nau'ikan bayanai a cikin Rust kamar yadda aka yi su kashi biyu:
/// mai nuna bayanai wanda ya ƙunshi adireshin ƙwaƙwalwar ajiyar ƙimar, da wasu metadata.
///
/// Ga nau'ikan sihiri masu girma (waɗanda ke aiwatar da `Sized` traits) da kuma nau'ikan na `extern`, an ce masu nuna "sihiri ne": metadata ba ta da siffa kuma nau'inta ita ce `()`.
///
///
/// Masu nuni zuwa [dynamically-sized types][dst] ance suna da "fadi" ko "mai", suna da metadata ba-sifili:
///
/// * Don matakan da filin su na ƙarshe shine DST, metadata shine metadata don filin ƙarshe
/// * Ga nau'in `str`, metadata shine tsayi a baiti kamar `usize`
/// * Don nau'ikan yanki kamar `[T]`, metadata shine tsayi a cikin abubuwa azaman `usize`
/// * Don abubuwa trait kamar `dyn SomeTrait`, metadata shine [`DynMetadata<Self>`][DynMetadata] (misali `DynMetadata<dyn SomeTrait>`)
///
/// A cikin future, yaren Rust na iya samun sabbin nau'ikan nau'ikan da ke da metadata na nuni daban-daban.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Ma'anar wannan trait shine nau'in haɗin `Metadata` ɗin sa, wanda shine `()` ko `usize` ko `DynMetadata<_>` kamar yadda aka bayyana a sama.
/// Ana aiwatar dashi ta atomatik don kowane nau'i.
/// Ana iya ɗauka cewa za a aiwatar da shi a cikin yanayin mahaɗan, koda ba tare da daidaitaccen ƙulla ba.
///
/// # Usage
///
/// Za a iya narkar da ma'anar Raw a cikin adreshin bayanan da abubuwan metadata tare da hanyar [`to_raw_parts`] ɗin su.
///
/// A madadin haka, ana iya cire metadata kadai tare da aikin [`metadata`].
/// Za'a iya gabatar da ishara zuwa [`metadata`] kuma a fili an tilasta shi.
///
/// Za'a iya dawo da alamar (possibly-wide) tare daga adireshinta da kuma metadata tare da [`from_raw_parts`] ko [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Nau'in don metadata a cikin alamomi da nassoshi ga `Self`.
    #[lang = "metadata_type"]
    // NOTE: Adana trait bounds a cikin `static_assert_expected_bounds_for_metadata`
    //
    // a cikin `library/core/src/ptr/metadata.rs` a aiki tare da waɗanda ke nan:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Manuniya ga nau'ikan aiwatar da wannan laƙabi na trait "siriri ne".
///
/// Wannan ya haɗa da nau'ikan-Sized` iri da nau'in `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: kar a daidaita wannan kafin sunayen laƙabi na trait su tabbata a cikin yaren?
pub trait Thin = Pointee<Metadata = ()>;

/// Cire metadata bangaren manuni.
///
/// Canimar nau'ikan `*mut T`, `&T`, ko `&mut T` za a iya wuce su kai tsaye zuwa wannan aikin kamar yadda suke tilasta tilastawa zuwa `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // KYAUTA: Samun damar ƙimar daga ƙungiyar `PtrRepr` amintacce ne tun * const T
    // da kuma PtrComponents<T>suna da shimfidar ƙwaƙwalwar ajiya iri ɗaya.
    // std ne kawai ke iya yin wannan garantin.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Ya kirkiro ɗan nuna alama na (possibly-wide) daga adreshin bayanai da metadata.
///
/// Wannan aikin yana da aminci amma ma'anar da aka dawo ba lallai bane ya kasance da aminci ga rashi.
/// Don yanka, duba takaddun [`slice::from_raw_parts`] don bukatun aminci.
/// Don abubuwan trait, metadata dole ne ya zo daga maɓuɓɓuka zuwa irin wannan tsararren tsararren.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // KYAUTA: Samun damar ƙimar daga ƙungiyar `PtrRepr` amintacce ne tun * const T
    // da kuma PtrComponents<T>suna da shimfidar ƙwaƙwalwar ajiya iri ɗaya.
    // std ne kawai ke iya yin wannan garantin.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Yana aiwatar da aiki iri ɗaya kamar na [`from_raw_parts`], sai dai an dawo da maɓallin ɗan gajeren `*mut`, akasin maɓallin nuna alama na `* const`.
///
///
/// Duba takardun [`from_raw_parts`] don ƙarin bayani.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // KYAUTA: Samun damar ƙimar daga ƙungiyar `PtrRepr` amintacce ne tun * const T
    // da kuma PtrComponents<T>suna da shimfidar ƙwaƙwalwar ajiya iri ɗaya.
    // std ne kawai ke iya yin wannan garantin.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ana buƙatar jagorar hannu don kaucewa ɗaure `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Ana buƙatar jagorar hannu don kaucewa ɗaure `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata don nau'in abu na `Dyn = dyn SomeTrait` trait.
///
/// Mai nunawa ne ga vtable (tebur ɗin kira na kamala) wanda ke wakiltar duk bayanan da ake buƙata don sarrafa nau'in kankare da aka adana a cikin abin trait.
/// A vtable musamman irin ta ƙunshi:
///
/// * nau'in girma
/// * type jeri
/// * mai nuna alama ga nau'in `drop_in_place` impl (yana iya zama ba-op don tsofaffin-tsoffin-bayanan)
/// * yana nuna duk hanyoyin don aiwatar da nau'in trait
///
/// Lura cewa farkon ukun na musamman ne saboda suna da mahimmanci don kasada, saukewa, da kuma raba duk wani abu na trait.
///
/// Zai yiwu a sanya wa wannan tsarin suna tare da nau'in siga wanda ba abu bane na `dyn` trait (misali `DynMetadata<u64>`) amma ba don samun mahimmancin darajar wannan tsarin ba.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Prearin sananniyar ƙawancen yau da kullun.Ana bin sa da alamomin aiki don hanyoyin trait.
///
/// Bayanin aiwatarwa na zaman kansa na `DynMetadata::size_of` da dai sauransu.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Yana dawo da girman nau'in da ke tattare da wannan aikin.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Yana dawo da jeri na nau'in da ke hade da wannan aikin.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Ya dawo da girma da daidaitawa tare azaman `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // KYAUTA: mai harhaɗawa ya fitar da wannan waƙar don nau'in Rust na kankare wanda
        // an san yana da shimfida mai inganci.Hankali iri ɗaya kamar na `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ana buƙatar buƙatun hannu don kauce wa iyakokin `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}