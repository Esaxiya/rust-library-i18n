use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` amma ba sifili ba kuma mai canzawa.
///
/// Wannan shine ainihin abin da yakamata ayi amfani dashi lokacin gina tsarin bayanai ta amfani da ɗan nuni, amma ƙarshe yafi haɗari don amfani saboda ƙarin ƙaddarorinsa.Idan bakada tabbas idan yakamata kayi amfani da `NonNull<T>`, yi amfani da `*mut T` kawai!
///
/// Ba kamar `*mut T` ba, dole ne mai nunin koyaushe ya zama mara amfani, ko da kuwa mai nunawa ba a taɓa cire shi ba.Wannan saboda enms na iya amfani da wannan ƙimar da aka hana a matsayin mai nuna bambanci-`Option<NonNull<T>>` yana da girman daidai da `* mut T`.
/// Duk da haka mai nuna alama na iya yin harbawa idan ba a rubuta shi ba.
///
/// Ba kamar `*mut T` ba, an zaɓi `NonNull<T>` don ya kasance mai daidaitawa akan `T`.Wannan yana ba da damar amfani da `NonNull<T>` lokacin gina nau'ikan haɓaka, amma yana gabatar da haɗarin rashin nutsuwa idan aka yi amfani da shi a cikin nau'in da bai kamata ya zama mai haɗuwa ba.
/// (An zaɓi zaɓin kishiyar don `*mut T` duk da cewa a zahiri ana iya haifar da rashin nutsuwa ne ta hanyar kiran ayyukan rashin aminci.)
///
/// Canzawa daidai ne don mafi yawancin abubuwanda aka cire, kamar `Box`, `Rc`, `Arc`, `Vec`, da `LinkedList`.Wannan haka al'amarin yake saboda suna samar da API na jama'a wanda ke bin ka'idodi masu daidaitaccen XOR na Rust.
///
/// Idan nau'inku ba zai iya zama mai haɗari ba cikin aminci, dole ne ku tabbatar yana ƙunshe da wasu ƙarin filin don samar da ƙima.Sau da yawa wannan filin zai zama [`PhantomData`] irin kamar `PhantomData<Cell<T>>` ko `PhantomData<&'a mut T>`.
///
/// Lura cewa `NonNull<T>` yana da misali `From` don `&T`.Koyaya, wannan baya canza gaskiyar cewa maye gurbi ta hanyar (maɓallin da aka samo daga a) bayanin da aka raba shine halin da ba a bayyana ba sai dai maye gurbi ya faru a cikin [`UnsafeCell<T>`].Hakanan don ƙirƙirar bayanan maye gurɓataccen tunani.
///
/// Lokacin amfani da wannan misalin `From` ba tare da `UnsafeCell<T>` ba, alhakin ku ne tabbatar da cewa ba a taɓa kiran `as_mut` ba, kuma ba a taɓa amfani da `as_ptr` don maye gurbi ba.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` masu nuna alama ba `Send` bane saboda bayanan da suke ambata na iya zama na laƙanci.
// NB, wannan impl ɗin bashi da mahimmanci, amma yakamata ya samar da mafi kyawun saƙonnin kuskure.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` masu nuna alama ba `Sync` bane saboda bayanan da suke ambata na iya zama na laƙanci.
// NB, wannan impl ɗin bashi da mahimmanci, amma yakamata ya samar da mafi kyawun saƙonnin kuskure.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Irƙiri sabon `NonNull` wanda yake walƙiya, amma ya dace.
    ///
    /// Wannan yana da amfani don farawa iri wanda cikin kasala ke kasaftawa, kamar `Vec::new` yayi.
    ///
    /// Lura cewa ƙimar manuni na iya wakiltar mai nuna alama mai inganci zuwa `T`, wanda ke nufin wannan ba za a yi amfani da shi azaman darajar sentinel "not yet initialized" ba.
    /// Nau'ikan da kasala ke kasaftawa dole ne su bi diddigin farawa ta wasu hanyoyin.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // KYAUTA: mem::align_of() ya dawo da amfani mara amfani da sifiri wanda daga baya aka fitar dashi
        // zuwa wani * mut T.
        // Sabili da haka, `ptr` ba komai bane kuma ana mutunta yanayin kiran new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Ya dawo da nassoshin da aka raba zuwa ƙimar.Ya bambanta da [`as_ref`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takwaran da zai iya canzawa duba [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za ta canza ba (sai dai a cikin `UnsafeCell`).
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don tunani.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Ya dawo da nassoshi na musamman zuwa ƙimar.Ya bambanta da [`as_mut`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takaddar da aka raba duba [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za a sami dama gare shi ba (karanta ko rubuta) ta kowane maɓallin.
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don tunani.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Irƙiri sabon `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` dole ne ba wofi.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `ptr` ba wofi bane.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Irƙiri sabon `NonNull` idan `ptr` ba wofi bane.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KYAUTA: An riga an bincika alamar kuma ba wofi ba ne
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Yana yin aiki iri ɗaya kamar na [`std::ptr::from_raw_parts`], sai dai an dawo da alamar `NonNull`, sabanin maɓallin nuna alama na `*const`.
    ///
    ///
    /// Duba takardun [`std::ptr::from_raw_parts`] don ƙarin bayani.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // KYAUTA: Sakamakon `ptr::from::raw_parts_mut` ba wofi bane saboda `data_address` shine.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Rarraba mai nuna alama (mai yuwuwa mai fadi) zuwa cikin adireshin da abubuwan metadata.
    ///
    /// Daga baya za'a iya sake gina mai nuna alama tare da [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Samun mahimmin alamar `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ya dawo da bayanin da aka raba zuwa ƙimar.Idan ƙimar ba ta da wayewa, dole ne a yi amfani da [`as_uninit_ref`] maimakon.
    ///
    /// Don takwaran da zai iya canzawa duba [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne mai nuna alama ya nuna misali na farawa na `T`.
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za ta canza ba (sai dai a cikin `UnsafeCell`).
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    /// (Bangaren da aka fara ba a yanke hukunci ba tukuna, amma har sai ya kasance, hanya mafi aminci ita ce a tabbatar da cewa an fara su.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don tunani.
        unsafe { &*self.as_ptr() }
    }

    /// Ya dawo da tunani na musamman zuwa ƙimar.Idan ƙimar ba ta da wayewa, dole ne a yi amfani da [`as_uninit_mut`] maimakon.
    ///
    /// Don takaddar da aka raba duba [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya daidaita.
    ///
    /// * Dole ne ya zama "dereferencable" a ma'anar da aka bayyana a cikin [the module documentation].
    ///
    /// * Dole ne mai nuna alama ya nuna misali na farawa na `T`.
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za a sami dama gare shi ba (karanta ko rubuta) ta kowane maɓallin.
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    /// (Bangaren da aka fara ba a yanke hukunci ba tukuna, amma har sai ya kasance, hanya mafi aminci ita ce a tabbatar da cewa an fara su.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KYAUTA: mai kira dole ne ya bada tabbacin cewa `self` ya haɗu da duka
        // bukatun don canjin canjin yanayi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Sanya wa mai nuna wani nau'in.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // KYAUTA: `self` nuni ne na `NonNull` wanda ba lallai bane ya ɓaci
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Irƙirar yanki mara ɗanɗano mara kyau daga mai nuna siriri da tsayi.
    ///
    /// A `len` shaida ne yawan **abubuwa**, ba da yawan bytes.
    ///
    /// Wannan aikin yana da aminci, amma ƙaddamar da ƙimar dawowa ba shi da hadari.
    /// Duba takaddun aiki na [`slice::from_raw_parts`] don buƙatun aminci aminci.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ƙirƙirar maɓallin yanki lokacin da farawa tare da mai nunawa zuwa farkon abun
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Lura cewa wannan misalin yana nuna amfani da wannan hanyar ta hanzari, amma `` bari yanki= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // KYAUTA: `data` nuni ne na `NonNull` wanda ba lallai bane ya ɓaci
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Ya dawo da tsawon yanki mara ɗanɗano.
    ///
    /// Valueimar da aka dawo ita ce lambar **abubuwa**, ba lambar baiti ba.
    ///
    /// Wannan aikin yana da aminci, koda lokacinda ba za a iya tura shi yanki zuwa yanki ba saboda mai nuna ba shi da adireshin da yake da inganci.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Yana dawo da manunin da ba woɓaɓɓe ga maɓallin ajiyar yanki.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // KYAUTA: Mun san `self` ba komai bane.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Yana dawo da ɗan manunin manuni zuwa maɓallin ajiyar yanki.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Ya dawo da bayanin da aka raba zuwa yanki na ƙimomin ƙimomin da ba a sani ba.Ya bambanta da [`as_ref`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takwaran da zai iya canzawa duba [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya zama [valid] don karantawa don `ptr.len() * mem::size_of::<T>()` da yawa bytes, kuma dole ne ya zama daidai ya dace.Wannan yana nufin musamman:
    ///
    ///     * Dukan kewayon ƙwaƙwalwar wannan yanki dole ne a ƙunshe cikin abu guda da aka ware!
    ///       Yankuna ba zai taba yin fadin abubuwa da yawa ba.
    ///
    ///     * Dole ne maɓallin nuna alama ya daidaita ko da don yanke-sifili.
    ///     Aya daga cikin dalilan wannan shine cewa ingantaccen tsarin shimfida lissafi na iya dogaro da nassoshi (gami da yanka kowane tsayi) ana daidaita su kuma basa zama mara amfani don bambanta su da sauran bayanan.
    ///
    ///     Kuna iya samo maɓallin da za a iya amfani dashi azaman `data` don yanke-tsayin tsaka mai amfani da [`NonNull::dangling()`].
    ///
    /// * Adadin girman `ptr.len() * mem::size_of::<T>()` na yanki dole ne ya zama bai fi `isize::MAX` girma ba.
    ///   Duba takardun aminci na [`pointer::offset`].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za ta canza ba (sai dai a cikin `UnsafeCell`).
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// Duba kuma [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Ya dawo da tunani na musamman zuwa yanki na ƙimomin kimar da ba za a iya fahimtar ta ba.Ya bambanta da [`as_mut`], wannan baya buƙatar cewa dole ne a fara ƙimar.
    ///
    /// Don takaddar da aka raba duba [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Lokacin kiran wannan hanyar, dole ne ku tabbatar da cewa duk waɗannan masu zuwa gaskiya ne:
    ///
    /// * Dole ne mai nuna alama ya zama [valid] don karantawa da rubutu don `ptr.len() * mem::size_of::<T>()` da yawa bytes, kuma dole ne ya zama daidai ya dace.Wannan yana nufin musamman:
    ///
    ///     * Dukan kewayon ƙwaƙwalwar wannan yanki dole ne a ƙunshe cikin abu guda da aka ware!
    ///       Yankuna ba zai taba yin fadin abubuwa da yawa ba.
    ///
    ///     * Dole ne maɓallin nuna alama ya daidaita ko da don yanke-sifili.
    ///     Aya daga cikin dalilan wannan shine cewa ingantaccen tsarin shimfida lissafi na iya dogaro da nassoshi (gami da yanka kowane tsayi) ana daidaita su kuma basa zama mara amfani don bambanta su da sauran bayanan.
    ///
    ///     Kuna iya samo maɓallin da za a iya amfani dashi azaman `data` don yanke-tsayin tsaka mai amfani da [`NonNull::dangling()`].
    ///
    /// * Adadin girman `ptr.len() * mem::size_of::<T>()` na yanki dole ne ya zama bai fi `isize::MAX` girma ba.
    ///   Duba takardun aminci na [`pointer::offset`].
    ///
    /// * Dole ne ku tilasta bin ƙa'idodin Rust, tunda rayuwar da aka dawo `'a` an zaɓe ta ba bisa ƙa'ida ba kuma ba dole ba ne ya nuna ainihin rayuwar bayanan.
    ///   Musamman, har tsawon wannan rayuwar, ƙwaƙwalwar da mai nuna wa yake nunawa dole ne ba za a sami dama gare shi ba (karanta ko rubuta) ta kowane maɓallin.
    ///
    /// Wannan ya shafi ko da kuwa sakamakon wannan hanyar ba shi da amfani!
    ///
    /// Duba kuma [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Wannan yana da aminci saboda `memory` yana aiki don karantawa kuma yana rubutawa ga `memory.len()` da yawa bytes.
    /// // Lura cewa kiran `memory.as_mut()` ba a ba shi izinin a nan ba saboda abubuwan da ke ciki na iya zama marasa wayewa.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Ya dawo da ɗan madaidaicin maɓallin abu ko ƙarami, ba tare da yin binciken iyaka ba.
    ///
    /// Kira wannan hanyar da lambar wuce gona da iri ko kuma lokacin da `self` ba za a iya soke shi ba * wannan ba shi da ma'ana ko kuma ba a yi amfani da shi ba.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // KYAUTA: mai kiran ya tabbatar da cewa `self` ba za a iya raba shi ba kuma `index` ya wuce iyaka.
        // Sakamakon haka, mai nuna alama ba zai iya zama NULL ba.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // KYAUTA: Maɓallin keɓaɓɓe ba zai iya zama fanko ba, don haka sharuɗɗan don
        // new_unchecked() ana girmama su.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KYAUTA: Magana mai canzawa ba zata zama fanko ba.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // KYAUTA: Tabbatacce ba zai iya zama wofi ba, don haka sharuɗɗan don
        // new_unchecked() ana girmama su.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}