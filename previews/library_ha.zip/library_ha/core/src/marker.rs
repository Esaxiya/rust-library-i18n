//! Na farko traits da nau'ikan da ke wakiltar kyawawan halaye na nau'ikan.
//!
//! Rust iri za a iya classified a daban-daban amfani hanyoyi bisa ga muhimmi Properties.
//! Wadannan nau'o'i ake wakilta a matsayin traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Nau'in cewa za a iya canjawa wuri fadin thread iyakoki.
///
/// Wannan trait ana aiwatar dashi ta atomatik lokacin da mai tattarawar ya yanke hukuncin dacewa.
///
/// Misali na nau'in `` ba '' aikawa ba shine alamar nuna ƙidayar lamba [`rc::Rc`][`Rc`].
/// Idan zaren biyu yayi yunƙurin haɗawa wanda yake nuni ga ƙimar da aka ƙididdige, za su iya ƙoƙarin sabunta ƙididdigar ƙididdigar a lokaci guda, wanda shine [undefined behavior][ub] saboda [`Rc`] baya amfani da ayyukan atom.
///
/// Its dan uwan [`sync::Arc`][arc] ya aikata amfani atomic ayyukan (sun jawo wasu sama) da kuma kamar wancan ne `Send`.
///
/// Dubi [the Nomicon](../../nomicon/send-and-sync.html) don ƙarin bayani.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Nau'in tare da m size da aka sani a tara lokaci.
///
/// Duk da irin sigogi da wani fakaice daure na `Sized`.A musamman ginin kalma `?Sized` za a iya amfani da su cire wannan daure idan ta ke ba ta dace.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // Tsarin FooUse(Foo<[i32]>);//kuskure: sized ba a aiwatar for [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// A daya togiya ne a fakaice `Self` irin wani trait.
/// A trait ba shi da wani fakaice `Sized` daure kamar wannan ne m tare da [trait abu] s inda, ta definition, da trait bukatar aiki tare da duk yiwu implementors, kuma ta haka ne zai iya zama wani size.
///
///
/// Ko da yake Rust zai bari ka daura `Sized` zuwa trait, ba za ka iya amfani da shi don samar da wata trait abu daga baya:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // bari y: &dyn Bar= &Impl;//kuskure: da trait `Bar` ba za a iya sanya a cikin wani abu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // don Tsoffin, misali, wanda ke buƙatar `[T]: !Default` ya zama mai iya kimantawa
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Nau'o'in da zasu iya zama "unsized" zuwa nau'in girman su.
///
/// Misali, nau'ikan tsararren nau'in `[i8; 2]` yana aiwatar da `Unsize<[i8]>` da `Unsize<dyn fmt::Debug>`.
///
/// All implementations na `Unsize` aka bayar ta atomatik ta tarawa.
///
/// `Unsize` An aiwatar for:
///
/// - `[T; N]` ne `Unsize<[T]>`
/// - `T` ne `Unsize<dyn Trait>` lokacin `T: Trait`
/// - `Foo<..., T, ...>` shine `Unsize<Foo<..., U, ...>>` idan:
///   - `T: Unsize<U>`
///   - Foo tsari ne
///   - Sai kawai na karshe filin na `Foo` yana da wani irin shafe `T`
///   - `T` ne ba wani ɓangare na da irin wani filayen
///   - `Bar<T>: Unsize<Bar<U>>`, idan na karshe filin na `Foo` yana da irin `Bar<T>`
///
/// `Unsize` ana amfani dashi tare da [`ops::CoerceUnsized`] don ba da damar kwantena "user-defined" kamar [`Rc`] don ƙunshe da nau'ikan-girma.
/// Dubi [DST coercion RFC][RFC982] da [the nomicon entry on coercion][nomicon-coerce] don ƙarin bayani.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Ake bukata trait for constants amfani da juna ashana.
///
/// Wani irin abin da ya sami asali `PartialEq` ta atomatik aiwatar da wannan trait,*m* na ko ta irin-sigogi yi `Eq`.
///
/// Idan wani `const` abu ya ƙunshi wasu irin wannan ba ya yi wannan trait, sa'an nan cewa irin ko dai (1.) ba yi `PartialEq` (wanda ke nufin da m ba zai samar da kwatanta hanya, wanda code tsara kwakwalwa ne samuwa), ko (2.) shi da aiwatarwa *da kansa* Sigar `PartialEq` (wanda muke ɗauka bai dace da kwatankwacin tsarin daidaito ba).
///
///
/// A ko dai na biyu tatsuniyoyinsu sama, mun kãfirta da yadda ake amfani da irin wannan m, a wani juna wasan.
///
/// Duba kuma [structural match RFC][RFC1445], da [issue 63438] waɗanda suka motsa ƙaura daga ƙirar sifa zuwa ga wannan trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Ake bukata trait for constants amfani da juna ashana.
///
/// Duk wani nau'in da ya sami `Eq` yana aiwatar da wannan trait kai tsaye, * ba tare da la'akari da ko nau'ikan sigogin sa suna aiwatar da `Eq`.
///
/// Wannan hack ne don aiki kusa da iyakancewa a tsarin mu.
///
/// # Background
///
/// Muna so mu buƙaci nau'ikan kwandon da ake amfani da su a cikin wasan kwaikwayon suna da sifa `#[derive(PartialEq, Eq)]`.
///
/// A wani karin manufa duniya, za mu iya duba cewa umurni da kawai dubawa da cewa ba irin aiwatarwa biyu da `StructuralPartialEq` trait *da* da `Eq` trait.
/// Duk da haka, za ka iya samun ADTs cewa *aikata*`derive(PartialEq, Eq)`, da kuma zama wani hali da muke so da mai tarawa yarda, kuma duk da haka m ta irin kasa ta yi `Eq`.
///
/// Wato, wani hali kamar wannan:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Matsalar dake cikin lambar da ke sama shine `Wrap<fn(&())>` baya aiwatar da `PartialEq`, ko `Eq`, saboda `` don '' a> fn(&'a _)` does not implement those traits.)
///
/// Saboda haka, ba za mu iya dogara a kan butulci rajistan ga `StructuralPartialEq` da mere `Eq`.
///
/// A matsayin kutse don aiki a kusa da wannan, muna amfani da allurar traits daban daban guda biyu ta kowane ɗayan biyun ya sami (`#[derive(PartialEq)]` da `#[derive(Eq)]`) kuma duba cewa dukansu suna nan a matsayin ɓangare na tsarin daidaita wasan.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Nau'o'in da ƙimarsu za a iya rubanya su ta hanyar kwafin bits.
///
/// By tsoho, m bindings da 'motsa ilimin harsuna.'A wasu kalmomi:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ya koma cikin `y`, don haka ba za a iya amfani da shi ba
///
/// // println! ("{: ?}", x).//kuskure: amfani da ƙimar da aka motsa
/// ```
///
/// Duk da haka, idan wani irin aiwatarwa `Copy`, shi maimakon yana da 'kwafa ilimin harsuna':
///
/// ```
/// // Za mu iya samu a `Copy` aiwatar.
/// // `Clone` ne ma ake bukata, kamar yadda yana da wani supertrait na `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` shi ne kwafin da `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Yana da mahimmanci a lura cewa a cikin waɗannan misalai guda biyu, kawai bambancin shine ko an baku damar samun damar `x` bayan aikin.
/// Karkashin kaho, duka wani kwafin da kuma motsa iya haifar da ragowa da ake kofe a ƙwaƙwalwar, ko da yake wannan ne wani lokacin gyara tafi.
///
/// ## Ta yaya zan iya yi `Copy`?
///
/// Akwai hanyoyi biyu da su aiwatar da `Copy` a kan irin.Mafi sauki shine amfani da `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Hakanan zaka iya aiwatar da `Copy` da `Clone` da hannu:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Akwai kananan bambanci tsakanin biyu: da `derive` dabarun za su ma suna sanya wani `Copy` daure a kan irin sigogi, wanda ba a ko da yaushe ake so.
///
/// ## Menene bambanci tsakanin `Copy` da `Clone`?
///
/// Kwafa suna faruwa a bayyane, misali a matsayin ɓangare na ɗawainiyar `y = x`.Halin `Copy` ba ya cika nauyi;shi ne ko da yaushe wani sauki bit-hikima kwafin.
///
/// Cloning aiki ne bayyananne, `x.clone()`.Aiwatar da [`Clone`] na iya samar da kowane irin takamaiman halayyar da ta dace don yin riɓi ƙimomin lafiya.
/// Alal misali, da aiwatar da [`Clone`] for [`String`] bukatar ya kwafa da nuna-to kirtani buffer a cikin tsibin.
/// Kwafi kaɗan na valuesan darajar [`String`] kawai za a kwafe maɓallin nunawa, wanda zai haifar da sau biyu a layin.
/// Saboda wannan dalili, [`String`] ne [`Clone`] amma ba `Copy`.
///
/// [`Clone`] babban hoto ne na `Copy`, saboda haka duk abin da yake `Copy` dole ne ya aiwatar da [`Clone`].
/// Idan wani irin ne `Copy` sa'an nan ta [`Clone`] aiwatar kawai bukatar komawa `*self` (ganin misali a sama).
///
/// ## Yaushe nau'ina zai kasance `Copy`?
///
/// A irin iya yi `Copy` idan duk da aka gyara yi `Copy`.Alal misali, wannan struct iya zama `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// A struct iya zama `Copy`, kuma [`i32`] ne `Copy`, saboda haka `Point` ya cancanci ya zama `Copy`.
/// By bambanci, la'akari da
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// A struct `PointList` ba zai iya yi `Copy`, saboda [`Vec<T>`] ba `Copy`.Idan muka yi ƙoƙari don samo aiwatarwar `Copy`, zamu sami kuskure:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Rabawa nassoshi (`&T`) ne ma `Copy`, don haka a irin na iya zama `Copy`, ko da shi Cibiyar tana raba nassoshi daga iri `T` da suke *ba*`Copy`.
/// La'akari da wadannan struct, wanda za a iya yi `Copy`, saboda shi kawai riko da wani *shared reference* to mu ba `Copy` irin `PointList` daga sama:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Lokacin *ba zai iya* ta irin zama `Copy`?
///
/// Wasu iri ba za a iya kofe a amince.Alal misali, kwafan `&mut T` zai haifar da wani aliased mutable tunani.
/// Kwafar [`String`] zai kwafi alhakin manajan da [`String`] 's buffer, abu zuwa biyu free.
///
/// Bayyana shari'ar ta ƙarshe, kowane nau'in aiwatar da [`Drop`] ba zai iya zama `Copy` ba, saboda yana sarrafa wasu albarkatu ban da nasa baiti na [`size_of::<T>`].
///
/// Idan kayi ƙoƙarin aiwatar da `Copy` akan tsari ko enum mai ƙunshe da bayanan ba-Copy` ba, zaku sami kuskuren [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Yaushe *yakamata* nau'in na ya kasance `Copy`?
///
/// Kullum magana, idan ka irin _can_ yi `Copy`, shi ya kamata.
/// Ka tuna, ko da yake, cewa aiwatar da `Copy` ne wani ɓangare na jama'a API na type.
/// Idan nau'ikan na iya zama ba'Copy` a cikin future ba, zai iya zama wayo a ƙetare aiwatar da `Copy` a yanzu, don kauce wa canjin API.
///
/// ## Implementarin masu aiwatarwa
///
/// Baya ga [implementors listed below][impls], nau'ikan masu zuwa suna aiwatar da `Copy`:
///
/// * Nau'in kayan aiki (watau, nau'ikan nau'ikan da aka ayyana kowane aiki)
/// * Nau'in alamomin aiki (misali, `fn() -> i32`)
/// * Array iri, ga duk masu girma dabam, idan abu irin ma aiwatar da `Copy` (misali, `[i32; 123456]`)
/// * Nau'o'in plean ƙaranci, idan kowane ɓangaren ma yana aiwatar da `Copy` (misali, `()`, `(i32, bool)`)
/// * Nau'o'in rufewa, idan basu karɓi ƙima daga yanayin ba ko kuma duk waɗannan ƙimomin da aka kama suna aiwatar da `Copy` kansu.
///   Note cewa canji kama da raba tunani ko da yaushe yi `Copy` (ko da referent ya aikata ba), yayin da canji kama da mutable reference taba yi `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Wannan damar kwafan irin wannan ba ya yi `Copy` saboda unsatisfied rayuwa haddi (kwashe `A<'_>` lokacin da kawai `A<'static>: Copy` da `A<'_>: Clone`).
// Muna da wannan sifa anan a yanzu kawai saboda akwai aan ƙwararrun ƙwarewa da ake dasu akan `Copy` waɗanda suka riga sun kasance a cikin ɗakunan karatu na yau da kullun, kuma babu wata hanyar da za ta amintar da wannan halin a yanzu.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Samu macro wanda ke haifar da tasirin trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Nau'o'in da yake da aminci a raba nassoshi tsakanin zaren.
///
/// Wannan trait ana aiwatar dashi ta atomatik lokacin da mai tattarawar ya yanke hukuncin dacewa.
///
/// A daidai definition ne: wani irin `T` ne [`Sync`] idan kuma kawai idan `&T` ne [`Send`].
/// A wasu kalmomin, idan akwai wani yiwuwar [undefined behavior][ub] (ciki har da data jinsi) a lokacin da wucewa `&T` nassoshi tsakanin zaren.
///
/// Kamar yadda daya zai sa ran, m iri kamar [`u8`] da [`f64`] ne duk [`Sync`], kuma haka ne sauki tara iri dauke da su, kamar tuples, structs da enums.
/// More misalai na asali [`Sync`] iri hada "immutable" iri kamar `&T`, da kuma waɗanda suke tare da sauki gaji mutability, kamar [`Box<T>`][box], [`Vec<T>`][vec] kuma mafi sauran tarin iri.
///
/// (Generic sigogi bukatar zama [`Sync`] domin su ganga ya zama [`Sync`].)
///
/// A da ɗan m sakamako na definition ne cewa `&mut T` ne `Sync` (idan `T` ne `Sync`) ko da yake ga alama kamar da zai samar da unsynchronized maye gurbi.
/// A abin zamba ne cewa a mutable reference bayan wani shared reference (cewa shi ne, `& &mut T`) ta wãyi gari na karanta kawai, kamar dai shi ne wani `& &T`.
/// Saboda haka babu wani hadarin wani data tseren.
///
/// Nau'ukan da ba `Sync` ba sune waɗanda suke da "interior mutability" a cikin tsari marar aminci, kamar [`Cell`][cell] da [`RefCell`][refcell].
/// Wadannan iri damar domin maye gurbi da abinda ke ciki ko ta hanyar wani marar sakewa, shared tunani.
/// Misali hanyar `set` akan [`Cell<T>`][cell] tana daukar `&self`, don haka yana buƙatar kawai bayanin da aka raba na [`&Cell<T>`][cell].
/// A Hanyar aikin babu aiki tare, haka [`Cell`][cell] ba zai iya zama `Sync`.
///
/// Wani misali na nau'in maras ``Sync '' shine mai nuna ƙididdigar lamba [`Rc`][rc].
/// Ba wani tunani [`&Rc<T>`][rc], za ka iya clone wani sabon [`Rc<T>`][rc], gyaggyarawa da reference kirga a wani maras atomic hanya.
///
/// Domin lokuta idan daya ya aikata bukatar thread-hadari ciki mutability, Rust samar [atomic data types], kazalika da bayyane kulle via [`sync::Mutex`][mutex] da [`sync::RwLock`][rwlock].
/// Wadannan iri tabbatar da cewa kowane maye gurbi ba zai iya yi wa data jinsi, Saboda haka da iri ne `Sync`.
/// Haka kuma, [`sync::Arc`][arc] samar da wani thread-lafiya analogue na [`Rc`][rc].
///
/// Duk wani nau'ikan da ke canza yanayin ciki dole ne ya yi amfani da zanen [`cell::UnsafeCell`][unsafecell] a kusa da value(s) wanda za'a iya maye gurbinsa ta hanyar bayanin da aka raba.
/// Rashin yin wannan ne [undefined behavior][ub].
/// Misali, [`transmute`][transmute]-ing daga `&T` zuwa `&mut T` baya aiki.
///
/// Duba [the Nomicon][nomicon-send-and-sync] don ƙarin bayani game da `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): da zarar support don ƙara rubutu a `rustc_on_unimplemented` asashe a beta, kuma an mika duba ko da wani ƙulli ne a ko'ina a cikin bukata sarkar, mika shi kamar yadda irin wannan (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-sized irin amfani ga alama abubuwa da cewa "act like" da suka mallaka a `T`.
///
/// Dingara filin `PhantomData<T>` zuwa nau'in ku yana gaya wa mai tarawa cewa nau'in ku yana yin kamar yana adana ƙimar nau'in `T`, duk da cewa ba da gaske yake ba.
/// Wannan bayanai da aka yi amfani da lokacin da sarrafa kwamfuta wasu aminci Properties.
///
/// Domin a more a cikin zurfin bayani na yadda za a yi amfani da `PhantomData<T>`, don Allah ga [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Bayanin ban tsoro 👻👻👻
///
/// Kodayake dukansu suna da sunaye masu ban tsoro, `PhantomData` da 'nau'ikan fatalwa' suna da alaƙa, amma ba iri ɗaya bane.A fatalwa irin siga ne kawai a irin siga wadda aka taba amfani da su.
/// A cikin Rust, wannan yakan sa mai tarawa ya yi gunaguni, kuma mafita ita ce ƙara amfani da "dummy" ta hanyar `PhantomData`.
///
/// # Examples
///
/// ## Sigogin rayuwa marasa amfani
///
/// Zai yiwu mafi kowa yin amfani al'amarin ga `PhantomData` ne struct cewa yana da wani sauran rayuwa siga, yawanci a matsayin wani ɓangare na wasu unsafe code.
/// Alal misali, a nan ne wani struct `Slice` cewa yana da biyu pointers daga irin `*const T`, mai yiwuwa nuna a cikin wani tsararru wani wuri:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Manufar ita ce cewa bayanan da ke tushe suna aiki ne kawai don rayuwar `'a`, don haka `Slice` bai kamata ya wuce `'a` ba.
/// Duk da haka, wannan niyyar ba da aka bayyana a cikin code, tun babu amfani da rayuwa `'a` ya kuma inganta shi ba a share abin data shi ya shafi.
/// Zamu iya gyara wannan ta hanyar gaya wa mai tarawa yayi aiki *kamar dai* tsarin `Slice` ya ƙunshi bayanin `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Wannan ma a nuna bukatar da annotation `T: 'a`, na nuna cewa wani nassoshi a `T` suna da inganci a kan rayuwa `'a`.
///
/// Lokacin soma wani `Slice` ku kawai samar da darajar `PhantomData` ga filin `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Sauran irin sigogi
///
/// Yana wani lokacin da ya faru da cewa kana da sauran irin sigogi da suke nuni da abin da irin bayanan da struct ne "tied" zuwa, ko da yake cewa data ba a zahiri samu a cikin struct kanta.
/// Ga misali inda wannan ya taso tare da [FFI].
/// A kasashen waje ke dubawa amfani iyawa na irin `*mut ()` koma zuwa Rust dabi'u daban-daban.
/// Muna bin nau'ikan Rust ta amfani da ma'aunin nau'in fatalwa akan tsarin `ExternalResource` wanda ke narkar da makama.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Mallaka da digon dubawa
///
/// Ƙara wani filin daga irin `PhantomData<T>` nuna cewa your irin mallaki data nau'in `T`.Wannan bi da bi ya nuna cewa a lokacin da ka irin aka ragu, shi iya sauke daya ko fiye lokutta da irin `T`.
/// Wannan yana da tasiri akan bincike na Rust na [drop check].
///
/// Idan ka struct ya aikata ba a gaskiya *nasu* da data daga irin `T`, shi ne mafi alhẽri amfani da wani tunani irin, kamar `PhantomData<&'a T>` (ideally) ko `PhantomData<*const T>` (idan babu rayuwa ya shafi), don haka kamar yadda ba su nuna ikon mallakar.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Tarawa-ciki trait amfani da su nuna irin enum discriminants.
///
/// Wannan trait ne ta atomatik aiwatar ga kowane irin kuma ba ya ƙara wani tabbacin to [`mem::Discriminant`].
/// Yana da **halin da ba a bayyana ba** don watsa tsakanin `DiscriminantKind::Discriminant` da `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// A irin na discriminant, wanda dole ne ya gamsar da trait bounds bukata ta `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Mai amfani da trait na ciki wanda aka yi amfani dashi don tantance ko nau'ikan ya ƙunshi kowane `UnsafeCell` a ciki, amma ba ta hanyar juya baya ba.
///
/// Wannan yana shafar, alal misali, ko a sanya `static` na wannan nau'in a cikin ƙwaƙwalwar ajiyar-kawai ƙwaƙwalwar ajiya ko ƙwaƙwalwar ajiyar rubutu.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Nau'in cewa za a iya amince koma bayan da aka liƙe.
///
/// Rust kanta tana wani ra'ayi na immovable iri, kuma ya wadãtu da motsa (misali, ta hanyar aiki, ko [`mem::replace`]) to ko da yaushe ya kasance mai lafiya.
///
/// Ana amfani da nau'in [`Pin`][Pin] a maimakon don hana motsawa ta cikin nau'in nau'in.Pointers `P<T>` nade a cikin [`Pin<P<T>>`][Pin] wrapper ba za a iya koma daga.
/// Dubi [`pin` module] takardun don ƙarin bayani a kan pinning.
///
/// Aiwatar da `Unpin` trait for `T` dage da hane-hane na pinning kashe da irin, wanda sai damar motsi `T` daga [`Pin<P<T>>`][Pin] da ayyuka kamar [`mem::replace`].
///
///
/// `Unpin` bashi da wani sakamako kwata-kwata saboda bayanan da ba a sa su ba.
/// A musamman, [`mem::replace`] da farin ciki motsa `!Unpin` data (yana aiki ga wani `&mut T`, ba kawai a lokacin da `T: Unpin`).
/// Koyaya, baza ku iya amfani da [`mem::replace`] akan bayanan da aka nannade cikin [`Pin<P<T>>`][Pin] ba saboda ba za ku iya samun `&mut T` ɗin da kuke buƙata don hakan ba, kuma *wannan* shine abin da ke sa wannan tsarin aiki.
///
/// Don haka wannan, alal misali, ana iya yin shi akan nau'ikan aiwatar da `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Muna buƙatar ambaton maye gurbi don kiran `mem::replace`.
/// // Za mu iya samu irin wannan tunani ta (implicitly) kiran `Pin::deref_mut`, amma cewa shi ne kawai zai yiwu saboda `String` aiwatarwa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Wannan trait ana aiwatar dashi ta atomatik don kusan kowane nau'i.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// A alama irin wanda ba ya yi `Unpin`.
///
/// Idan wani irin ƙunshi `PhantomPinned`, shi ba zai yi `Unpin` ta tsohuwa.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Aiwatar da `Copy` don nau'ikan gargajiya.
///
/// Implementations cewa ba za a iya bayyana a Rust aka aiwatar a `traits::SelectionContext::copy_clone_conditions()` a `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Rabawa nassoshi za a iya kofe, amma mutable nassoshi *ba zai iya*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}