#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Kayan more rayuwa da suka shafi kasashen waje aiki dubawa (FFI) bindings.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Daidai C ta `void` irin lokacin amfani da mai [pointer].
///
/// Asali, `*const c_void` yayi daidai da C's `const void*` kuma `*mut c_void` yayi daidai da C's `void*`.
/// Wancan ya ce, wannan ba * daidai yake da nau'in dawowar C's `void` ba, wanda shine nau'in Rust na `()`.
///
/// Don samfurin nuni zuwa nau'ikan juzu'i a cikin FFI, har zuwa lokacin da `extern type` ya daidaita, ana bada shawarar yin amfani da newtype mai nadewa kusa da tsararrun baiti.
///
/// Dubi [Nomicon] domin cikakkun bayanai.
///
/// Mutum na iya amfani da `std::os::raw::c_void` idan suna son tallafawa tsoffin mai tara bayanan Rust har zuwa 1.1.0.
/// Bayan Rust 1.30.0, shi aka sake-fitar dashi da wannan definition.
/// Don ƙarin bayani, don Allah karanta [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, don LLVM don gane nau'in nunawa mara kyau kuma ta ayyukan haɓaka kamar malloc(), muna buƙatar sanya wakilta azaman i8 * a cikin LLVM bitcode.
// Enum da aka yi amfani da shi a nan yana tabbatar da wannan kuma yana hana yin amfani da nau'in "raw" ta hanyar samun nau'ikan keɓaɓɓu kawai.
// Muna bukatar biyu bambance-bambancen karatu, saboda tarawa tanã kai ƙãra game da repr sifa in ba haka ba kuma mu bukatar akalla daya bambance-bambancen a matsayin in ba haka ba da enum za a inda ba wanda yake zaune da a kalla dereferencing irin pointers zai zama UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Basic aiwatar da wani `va_list`.
// Sunan shine WIP, ta amfani da `VaListImpl` a yanzu.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Ba shi da bambanci a kan `'f`, don haka kowane abu na `VaListImpl<'f>` yana da alaƙa da yankin aikin da aka bayyana a ciki
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI aiwatar da `va_list`.
/// Dubi [AArch64 Procedure Call Standard] don ƙarin bayani.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI aiwatar da `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI aiwatar da `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Kunsawa don `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Sanya `VaListImpl` zuwa cikin `VaList` wanda ya dace da binary tare da C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Sanya `VaListImpl` zuwa cikin `VaList` wanda ya dace da binary tare da C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// A VaArgSafe trait bukatar a yi amfani da jama'a musaya, duk da haka, trait kanta dole ba za a yarda a yi amfani da waje wannan a koyaushe.
// Barin masu amfani don aiwatar da trait don sabon nau'in (don haka ba da damar amfani da va_arg a kan sabon nau'in) na iya haifar da halin da ba a bayyana ba.
//
// FIXME(dlrobertson): Don amfani da VaArgSafe trait a cikin keɓaɓɓiyar jama'a amma kuma tabbatar da cewa ba za a iya amfani da shi a wani wuri ba, trait yana buƙatar zama na jama'a a cikin tsarin sirri.
// Da zarar an aiwatar da RFC 2145 duba cikin inganta wannan.
//
//
//
//
mod sealed_trait {
    /// Trait wadda ta amince da yarda iri da za a yi amfani da tare da [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Advance na gaba Arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Kwafi `va_list` a wurin da yake yanzu.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // KIYAYEWAR: mun rubuta zuwa ga `MaybeUninit`, haka shi ne initialized da `assume_init` ne shari'a
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: wannan yakamata ya kira `va_end`, amma babu wata tsafta hanya zuwa
        // tabbatar da cewa `drop` ko da yaushe samun inlined cikin ta mai kira, don haka da `va_end` zai samun kai tsaye kira daga wannan aiki a matsayin m `va_copy`.
        // `man va_end` jihohin da C bukatar wannan, da kuma LLVM m bi C ilimin harsuna, saboda haka muna bukatar tabbatar da cewa `va_end` ne ko da yaushe kira daga wannan aiki a matsayin `va_copy`.
        //
        // Don ƙarin bayani, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Wannan yana aiki a yanzu, tunda `va_end` ba komai bane akan duk abubuwan LLVM na yanzu.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Rushe jerin sunayen `ap` bayan farawa tare da `va_start` ko `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Kwafa wurin da ake ciki na arglist `src` na yanzu zuwa ga jerin sunayen arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Auki takaddama na nau'in `T` daga `va_list` `ap` kuma ya haɓaka hujja `ap` ya nuna.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}