//! Aiki don oda da kwatantawa.
//!
//! Wannan module ƙunshi daban-daban kayayyakin aiki, don bada umarnin da gwada dabi'u.A takaice:
//!
//! * [`Eq`] kuma [`PartialEq`] sune traits waɗanda ke ba ku damar ayyana daidaito da juzu'i tsakanin ƙimomi, bi da bi.
//! Aiwatar da su overloads da `==` da `!=` aiki.
//! * [`Ord`] kuma [`PartialOrd`] ne traits cewa ba ka damar ayyana total da kuma m orderings tsakanin dabi'u, bi da bi.
//!
//! Yin aiwatar da su ya cika masu aikin `<`, `<=`, `>`, da `>=`.
//! * [`Ordering`] enum ne wanda aka dawo dashi ta hanyar manyan ayyukan [`Ord`] da [`PartialOrd`], kuma suna bayanin oda.
//! * [`Reverse`] tsari ne wanda zai baku damar sauya oda.
//! * [`max`] kuma [`min`] ayyuka ne da suke ginawa akan [`Ord`] kuma suna baka damar samun matsakaici ko mafi ƙarancin ƙimomi biyu.
//!
//! Don ƙarin bayani, duba Game da takardun da kowane abu a cikin jerin.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait don kwatancen daidaito waɗanda [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ne.
///
/// Wannan trait damar domin m daidaitaka, ga iri cewa ba su da cikakken daidaitawa aboki.
/// Alal misali, a iyo ma'ana lambobin `NaN != NaN`, don haka iyo ma'ana iri yi `PartialEq` amma ba [`trait@Eq`].
///
/// Bisa ga ƙa'ida, da daidaitakar dole ne (ga duk `a`, `b`, `c` na irin `A`, `B`, `C`):
///
/// - **Symmetric**: idan `A: PartialEq<B>` da `B: PartialEq<A>`, to **`a==b` yana nuna 'b==a`**;kuma
///
/// - **Mai wucewa**: idan `A: PartialEq<B>` da `B: PartialEq<C>` da `` A:
///   PartialEq<C>`, Sa'an nan **` mai==b`da `b == c` yakan haifar da`mai==c`**.
///
/// Note cewa `B: PartialEq<A>` (symmetric) da `A: PartialEq<C>` (transitive) impls ba tilasta zama, amma wadannan bukatu tambaya a duk lokacin da suka yi zama.
///
/// ## Derivable
///
/// Wannan trait za a iya amfani da `#[derive]`.Lokacin da ``aka samo asali a kan ka'idodi, lokuta guda biyu daidai ne idan duk fannoni sun daidaita, kuma basu daidaita ba idan kowane fage ba daidai yake ba.Lokacin da aka samu`` en enms '', kowane irin kamanceceniya da kansa kuma baiyi daidai da sauran bambance-bambancen ba.
///
/// ## Ta yaya zan iya aiwatar da `PartialEq`?
///
/// `PartialEq` kawai na bukatar da [`eq`] Hanyar da za a aiwatar.An bayyana [`ne`] dangane da shi ta tsohuwa.Duk wani aikin aiwatarwa na [`ne`]*dole ne* girmama doka cewa [`eq`] mai tsananin bijirewa ne na [`ne`];cewa shi ne, `!(a == b)` idan kuma kawai idan `a != b`.
///
/// Implementations na `PartialEq`, [`PartialOrd`], kuma [`Ord`]*dole ne* yarda da juna.Yana da sauki bazata sanya su saba da deriving wasu daga cikin traits da hannu aiwatar da sauransu.
///
/// An misali aiwatar for a yankin a cikin abin da littattafai biyu suna dauke da wannan littafi idan su ISBN ashana, ko idan tsare-tsare ya bambanta:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Ta yaya zan iya kwatanta nau'ikan nau'i biyu?
///
/// A irin za ka iya kwatanta da aka sarrafawa da `PartialEq` ta irin siga.
/// Misali, bari mu gyara lambar mu ta baya kadan:
///
/// ```
/// // A samu aiwatarwa<BookFormat>==<BookFormat>kwatancen
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Aiwatar<Book>==<BookFormat>kwatancen
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // yi<BookFormat>==<Book>kwatancen
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Ta canza `impl PartialEq for Book` zuwa `impl PartialEq<BookFormat> for Book`, muna ba da izinin ``BookFormat`s '' da 'Book`s.
///
/// Kwatantawa kamar na sama, wanda yayi watsi da wasu fannoni na tsarin, na iya zama mai haɗari.Yana iya kai wa ga wani niyya ba take hakkin da bukatun ga wani m daidaitawa aboki.
/// Misali, idan muka kiyaye aiwatar da sama na `PartialEq<Book>` na `BookFormat` kuma muka kara aiwatar da `PartialEq<Book>` don `Book` (ko dai ta hanyar `#[derive]` ko ta hanyar aiwatar da littafi daga misalin farko) to sakamakon zai karya transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Wannan hanyar ta gwada don ƙimar `self` da `other` don su daidaita, kuma ana amfani da `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Wannan hanya gwaje-gwaje domin `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Samu Macro da samar da wani impl na trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait don kwatancen daidaito waɗanda [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) ne.
///
/// Wannan yana nufin, ban da `a == b` da `a != b` kasancewa masu tsauraran matakai, daidaito dole ne (na duk `a`, `b` da `c`):
///
/// - reflexive: `a == a`;
/// - fasali: `a == b` yakan haifar da `b == a`.kuma
/// - wucewa: `a == b` da `b == c` suna nuna `a == c`.
///
/// Ba za a iya bincika wannan kayan ta mahaɗin ba, sabili da haka `Eq` yana nuna [`PartialEq`], kuma ba shi da ƙarin hanyoyin.
///
/// ## Derivable
///
/// Ana iya amfani da wannan trait tare da `#[derive]`.
/// Lokacin da ``derive`d, saboda `Eq` bashi da ƙarin hanyoyin, kawai yana sanar da mai tara cewa wannan dangantakar daidaito ce maimakon ta daidaitaccen yanki.
///
/// Lura cewa `derive` dabarun bukatar duk filayen ne `Eq`, wanda ba a ko da yaushe ake so.
///
/// ## Ta yaya zan iya aiwatar da `Eq`?
///
/// Idan ba za ka iya amfani da `derive` dabarun, saka da cewa your irin aiwatarwa `Eq`, abin da ba ya da hanyoyin:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ana amfani da wannan hanyar ne kawai ta hanyar#[bayarwa] don tabbatar da cewa duk wani nau'I na nau'ikan nau'ikan yana aiwatar da#[bayarwa] da kansa, kayan more rayuwa da ake samu a yanzu suna nufin yin wannan ikirarin ba tare da amfani da wata hanya akan wannan trait ba kusan ba zai yiwu ba.
    //
    //
    // Wannan ya kamata ba za a aiwatar da hannu.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Samu Macro da samar da wani impl na trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: wannan struct aka yi amfani kawai da#[samu] a
// tabbatar da cewa kowane bangaren na wani irin aiwatarwa Eq.
//
// Wannan tsarin bai kamata ya bayyana a lambar mai amfani ba.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` sakamakon kwatanci ne tsakanin ƙimomi biyu.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Umarni inda kimar kwatanta ta ƙaranci wani.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// An ordering inda wani idan aka kwatanta darajar ne daidai da wani.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Umarni inda kimar da aka kwatanta ta fi ta wani girma.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Yana dawowa `true` idan oda shine nau'ikan `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Koma `true` idan ordering ba `Equal` bambanci.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Yana dawowa `true` idan oda shine nau'ikan `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Yana dawowa `true` idan oda shine nau'ikan `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Yana dawo da `true` idan oda shine kodai shine bambancin `Less` ko `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Yana dawo da `true` idan oda shine kodai shine bambancin `Greater` ko `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Sauya `Ordering`.
    ///
    /// * `Less` ya zama `Greater`.
    /// * `Greater` ya zama `Less`.
    /// * `Equal` zama `Equal`.
    ///
    /// # Examples
    ///
    /// Basic hali:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Ana iya amfani da wannan hanyar don sake kwatanta kwatancen:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // raba tsararru daga mafi girma zuwa ƙarami.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Sarƙoƙi biyu orderings.
    ///
    /// Koma `self` lõkacin da ta ke ba `Equal`.In ba haka ba kõmo `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Sarkar oda tare da aikin da aka bayar.
    ///
    /// Yana dawowa `self` lokacin da ba `Equal` bane.
    /// In ba haka ba Kiran `f` da kuma dawo da sakamakon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Tsarin mai taimako don yin oda.
///
/// Wannan struct ne da wani mataimaki da za a yi amfani da tare da ayyuka kamar [`Vec::sort_by_key`] kuma za a iya amfani da su baya domin wani ɓangare na wani key.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait for iri cewa ya samar da wata [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Umarni shine tsari na duka idan ya kasance (ga duka `a`, `b` da `c`):
///
/// - duka da asymmetric: daidai ɗaya daga `a < b`, `a == b` ko `a > b` gaskiya ne;kuma
/// - wucewa, `a < b` da `b < c` suna nuna `a < c`.Hakanan dole ne ya riƙe duka `==` da `>`.
///
/// ## Derivable
///
/// Ana iya amfani da wannan trait tare da `#[derive]`.
/// Lokacin da `derive`d a kan structs, shi zai samar da wani [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ordering bisa saman-wa-kasa da'awarsu, domin na struct ta members.
///
/// Lokacin da `derive`d a kan enums, bambance-bambancen karatu a umarce su da su kai-da-kasa discriminant domin.
///
/// ## Lexicographical kwatanta
///
/// Lexicographical kwatanta shi ne wani aiki da wadannan Properties:
///  - Jeri biyu ana kwatanta abubuwa da kashi.
///  - A farko mismatching kashi ma'anar wanda jerin ne lexicographically kasa ko mafi girma fiye da sauran.
///  - Idan wani jeri prefix ne na wani, gajeren jerin baya kasa dayan.
///  - Idan biyu jerin suna da m abubuwa da suke da wannan tsawon, sa'an nan da jerin suna lexicographically daidai.
///  - Jerin komai wofi kasa da kowane jerin marasa wofi.
///  - Jeren abubuwa guda biyu marasa komai daidai suke.
///
/// ## Ta yaya zan iya aiwatar da `Ord`?
///
/// `Ord` yana buƙatar cewa nau'in shima ya kasance [`PartialOrd`] da [`Eq`] (wanda ke buƙatar [`PartialEq`]).
///
/// Sannan dole ne ku ayyana aiwatarwa don [`cmp`].Kuna iya amfanar ku da amfani da [`cmp`] akan filayen nau'in ku.
///
/// Implementations na [`PartialEq`], [`PartialOrd`], kuma `Ord`*dole ne* yarda da juna.
/// Wannan shi ne, `a.cmp(b) == Ordering::Equal` idan kuma kawai idan `a == b` da `Some(a.cmp(b)) == a.partial_cmp(b)` ga duk `a` da `b`.
/// Yana da sauki bazata sanya su saba da deriving wasu daga cikin traits da hannu aiwatar da sauransu.
///
/// Ga wani misali inda kana so ka warware mutane da tsawo kawai, bijirewa `id` da `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Wannan hanya ya koma wani [`Ordering`] tsakanin `self` da `other`.
    ///
    /// By al'ada, `self.cmp(&other)` dawo da ordering matching da magana `self <operator> other` idan gaskiya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Kwantanta da kuma dawo da matsakaicin na biyu dabi'u.
    ///
    /// Ya dawo da hujja ta biyu idan kwatancen ya nuna su daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Kwantanta da kuma dawo da ƙaramar na biyu dabi'u.
    ///
    /// Ya dawo da hujja ta farko idan kwatancen ya nuna su daidaita.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Ƙuntata da darajar da wani tazara.
    ///
    /// Dawowa `max` idan `self` ya fi `max` girma, kuma `min` idan `self` bai kai `min` ba.
    /// In ba haka ba wannan ya dawo `self`.
    ///
    /// # Panics
    ///
    /// Panics idan `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Samu Macro da samar da wani impl na trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait ga dabi'u da cewa za a iya kwatanta a raba-oda.
///
/// Dole ne kwatancen ya gamsar, saboda duka `a`, `b` da `c`:
///
/// - jeri na bangaren: idan `a < b` sa'an nan `!(a > b)`, kazalika da `a > b` yana ambaton `!(a < b)`.kuma
/// - transitivity: `a < b` da `b < c` yakan haifar da `a < c`.A wannan dole ne riƙe duka biyu `==` da `>`.
///
/// Lura cewa waɗannan bukatun suna nufin cewa trait da kanta dole ne a aiwatar dashi ta hanya mai sauƙi da sauƙi: idan `T: PartialOrd<U>` da `U: PartialOrd<V>` sannan `U: PartialOrd<T>` da `` T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ana iya amfani da wannan trait tare da `#[derive]`.Lokacin da `` aka samo '' a kan ka'idodi, zai samar da odar kalmomin ƙa'idoji bisa tsarin umarnin sanarwa daga sama zuwa ƙasa na mambobin tsarin.
/// Lokacin da `derive`d a kan enums, bambance-bambancen karatu a umarce su da su kai-da-kasa discriminant domin.
///
/// ## Ta yaya zan iya aiwatar da `PartialOrd`?
///
/// `PartialOrd` kawai yana buƙatar aiwatar da hanyar [`partial_cmp`], tare da sauran waɗanda aka samo asali daga aiwatarwar tsoho.
///
/// Duk da haka shi ya zauna zai yiwu a aiwatar da wasu dabam ga iri wanda ba su da wani total domin.
/// Alal misali, ga iyo batu lambobi, `NaN < 0 == false` da `NaN >= 0 == false` (gwama
/// IEEE 754-2008 sashe 5.11).
///
/// `PartialOrd` bukatar ka irin zama [`PartialEq`].
///
/// Aiwatar da [`PartialEq`], `PartialOrd`, da [`Ord`]*dole* su yarda da juna.
/// Yana da sauki bazata sanya su saba da deriving wasu daga cikin traits da hannu aiwatar da sauransu.
///
/// Idan nau'in ku shine [`Ord`], zaku iya aiwatar da [`partial_cmp`] ta amfani da [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Za ka iya kuma sami shi da amfani don amfani [`partial_cmp`] a kan irin ta filayen.
/// Ga wani misali na `Person` iri da suka yi iyo-aya `height` filin da cewa shi ne kadai filin da za a yi amfani da kasawa:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Wannan hanyar tana dawo da oda tsakanin kimar `self` da `other` idan akwai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Lokacin kwatantawa ba zai yiwu ba:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Wannan hanyar tana gwada ƙasa da (don `self` da `other`) kuma ana amfani da ita ta mai aikin `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Wannan hanya gwaje-gwaje kasa fi ko daidai to (don `self` da `other`) da ake amfani da `<=` sadarwarka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Wannan hanyar tana gwada mafi girma (don `self` da `other`) kuma ana amfani da ita ta mai aikin `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Wannan hanyar tana gwada mafi girma ko daidai da (don `self` da `other`) kuma ana amfani da mai aikin `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Samu Macro da samar da wani impl na trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Kwantanta da kuma dawo da ƙaramar na biyu dabi'u.
///
/// Ya dawo da hujja ta farko idan kwatancen ya nuna su daidaita.
///
/// Ƙ yana amfani da wani wanda aka ce masa to [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Yana dawo da mafi ƙarancin ƙimomi biyu dangane da aikin kwatanta aikin da aka ƙayyade.
///
/// Ya dawo da hujja ta farko idan kwatancen ya nuna su daidaita.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Ya dawo da abun da ke ba da ƙarami ƙimar daga aikin da aka ƙayyade.
///
/// Ya dawo da hujja ta farko idan kwatancen ya nuna su daidaita.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Kwantanta da kuma dawo da matsakaicin na biyu dabi'u.
///
/// Ya dawo da hujja ta biyu idan kwatancen ya nuna su daidaita.
///
/// A ciki yana amfani da laƙabi zuwa [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Koma matsakaicin na biyu dabi'u tare da girmamawa ga ajali kwatanta aiki.
///
/// Ya dawo da hujja ta biyu idan kwatancen ya nuna su daidaita.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Ya dawo da abun da ke ba da matsakaicin darajar daga aikin da aka ƙayyade.
///
/// Ya dawo da hujja ta biyu idan kwatancen ya nuna su daidaita.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Aiwatar da PartialEq, Eq, PartialOrd da Ord don iri na farko
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Umurni a nan yana da mahimmanci don samar da mafi kyawun taro.
                    // Dubi <https://github.com/rust-lang/rust/issues/63758> for more info.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Fitar don i8 ta kuma tana mayar da bambanci zuwa wani odar haifar mafi kyau duka taro.
            //
            // Duba <https://github.com/rust-lang/rust/issues/66780> don ƙarin bayani.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // KYAUTA: bool kamar yadda i8 ya dawo 0 ko 1, saboda haka bambancin ba zai iya zama komai ba
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &alamomi

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}