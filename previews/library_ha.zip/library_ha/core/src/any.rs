//! Wannan rukunin yana aiwatar da `Any` trait, wanda ke ba da damar buga kowane irin nau'in `'static` ta hanyar aikin lokaci.
//!
//! `Any` ana iya amfani da kanta don samun `TypeId`, kuma yana da ƙarin fasali yayin amfani dashi azaman abin trait.
//! A matsayin `&dyn Any` (abin da aka aro na trait), yana da hanyoyin `is` da `downcast_ref`, don gwada idan ƙimar da ke ciki nau'ikan da aka bayar ne, da kuma samun ishara zuwa ƙimar ciki kamar nau'in.
//! Kamar yadda `&mut dyn Any`, akwai kuma hanyar `downcast_mut`, don samun ambaton maye gurbin ƙimar ciki.
//! `Box<dyn Any>` yana ƙara hanyar `downcast`, wanda ke ƙoƙari ya juya zuwa `Box<T>`.
//! Duba takardun [`Box`] don cikakkun bayanai.
//!
//! Lura cewa `&dyn Any` an iyakance shi ne don gwada ko ƙimshi na takamaiman nau'in kankare ne, kuma ba za a iya amfani da shi don gwada ko nau'ikan aiwatar da trait ba.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Manuniya masu mahimmanci da `dyn Any`
//!
//! Daya yanki na hali da ka tuna lokacin da yin amfani da `Any` matsayin trait abu, musamman tare da iri kamar `Box<dyn Any>` ko `Arc<dyn Any>`, shi ne cewa kawai kiran `.type_id()` a kan darajar za su samar da `TypeId` na *ganga*, ba muhimmi trait abu.
//!
//! Wannan za a iya kauce masa ta hanyar mayar da kaifin baki akan cikin wani `&dyn Any` maimakon, wanda zai dawo da abu ta `TypeId`.
//! Misali:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Kana da mafi kusantar su so wannan:
//! let actual_id = (&*boxed).type_id();
//! // ... fiye da wannan:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Yi la'akari da halin da muke so don fitar da ƙimar da aka wuce zuwa aiki.
//! Mun san ƙimar da muke aiki a kan aiwatar da Debug, amma ba mu san irinsa ba.Muna so mu ba da kulawa ta musamman ga wasu nau'ikan: a wannan yanayin buga fitar da tsayin valuesimar Kirtani kafin ƙimar su.
//! Ba mu san takamaiman ƙimarmu ba a cikin tattara lokaci, don haka muna buƙatar amfani da tunanin lokacin gudu a maimakon haka.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Aikace-aikacen logger na kowane irin nau'in aiwatar da Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Ka yi kokarin maida mu darajar zuwa `String`.
//!     // Idan ya ci nasara, muna so mu fitar da tsayin String` da kuma ƙimarsa.
//!     // Idan ba haka ba, yana da wani daban-daban irin: kawai buga shi daga unadorned.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Wannan aikin yana so ya fitar da ma'aunin sa kafin yayi aiki dashi.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... yi wani aiki
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Duk wani trait
///////////////////////////////////////////////////////////////////////////////

/// trait don kwaikwayon buga rubutu mai ƙarfi.
///
/// Yawancin nau'ikan suna aiwatar da `Any`.Koyaya, kowane nau'i wanda ya ƙunshi bayanin ba 'Static` ba.
/// Duba [module-level documentation][mod] don ƙarin bayani.
///
/// [mod]: crate::any
// Wannan trait bashi da hadari, kodayake mun dogara ga ƙayyadaddun aikin aikin `type_id` ne kawai a cikin lambar tsaro (misali, `downcast`).A yadda aka saba, wannan zai zama matsala, amma saboda kawai shigar da `Any` shine aiwatar da bargo, babu wata lambar da zata iya aiwatar da `Any`.
//
// Zamu iya sanya wannan trait mara lafiya-ba zai haifar da lalacewa ba, tunda muna sarrafa dukkan aiwatarwar-amma mun zabi kar muyi hakan tunda duka basu zama lallai ba kuma zai iya rikita masu amfani da su game da banbancin traits da hanyoyin da basu da hadari (watau, `type_id` zai kasance amintacce don kira, amma muna iya nunawa kamar haka a cikin takardu).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Samu da `TypeId` na `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Hanyoyin faɗaɗa don kowane abu trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Tabbatar cewa sakamakon misali, shiga zaren za'a iya buga shi kuma don haka amfani dashi tare da `unwrap`.
// Mai yiwuwa ƙarshe ba za a ƙara buƙata ba idan aika aika aiki tare da haɓakawa.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Ya dawo `true` idan nau'in kwalin yayi daidai da `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Sami `TypeId` na nau'in wannan aikin da aka sanya shi tare da.
        let t = TypeId::of::<T>();

        // Samun `TypeId` na da irin a cikin trait abu (`self`).
        let concrete = self.type_id();

        // Kwatanta duka ``TypeId`s akan daidaito.
        t == concrete
    }

    /// Yana dawo da wasu bayanai zuwa ƙimar dambe idan ta nau'in `T` ce, ko `None` idan ba haka ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // KYAUTA: kawai an bincika ko muna nuna nau'in daidai, kuma zamu iya dogaro
            // wannan yana bincika amincin ƙwaƙwalwar ajiya saboda mun aiwatar da Duk wani nau'ikan;babu sauran impls iya zama kamar yadda suke bai yi muwafaka da mu impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Yana dawo da wasu kalmomin da za'a iya canzawa zuwa ƙimar dambe idan ta nau'in `T` ce, ko `None` idan ba haka ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // KYAUTA: kawai an bincika ko muna nuna nau'in daidai, kuma zamu iya dogaro
            // wannan yana bincika amincin ƙwaƙwalwar ajiya saboda mun aiwatar da Duk wani nau'ikan;babu sauran impls iya zama kamar yadda suke bai yi muwafaka da mu impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Gaba zuwa hanya da aka ayyana a kan irin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Gaba zuwa hanya da aka ayyana a kan irin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Gaba zuwa hanya da aka ayyana a kan irin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Gaba zuwa hanya da aka ayyana a kan irin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Gaba zuwa hanya da aka ayyana a kan irin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Gaba zuwa hanya da aka ayyana a kan irin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID kuma da hanyoyin
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` yana wakiltar mai ganowa na musamman a duniya don nau'in.
///
/// Kowane `TypeId` abu ne mai ɓoyayye wanda baya ba da izinin bincika abin da ke ciki amma yana ba da damar ayyukan yau da kullun kamar su cloning, kwatancen, bugu, da nunawa.
///
///
/// A `TypeId` a halin yanzu yana samuwa ne kawai don nau'ikan da suka danganci `'static`, amma wannan iyakance za'a iya cire shi a cikin future.
///
/// Yayinda `TypeId` ke aiwatar da `Hash`, `PartialOrd`, da `Ord`, yana da kyau a lura cewa toshewa da oda zasu bambanta tsakanin fitowar Rust.
/// Yi hankali da dogaro da su a cikin lambarka!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Ya dawo da `TypeId` na nau'in wannan aikin gama-gari wanda aka sanya shi tare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Maido da sunan wani nau'in azaman yanki na kirtani.
///
/// # Note
///
/// Wannan ana nufin yin amfani da bincike.
/// A daidai abinda ke ciki da kuma format na kirtani koma ana ba a kayyade ba, wasu fiye da kasancewa a mafi kyau-kokarin bayanin irin nau'in.
/// Misali, daga cikin zaren da `type_name::<Option<String>>()` zai iya dawowa akwai `"Option<String>"` da `"std::option::Option<std::string::String>"`.
///
///
/// Ba za a yi la'akari da layin da aka dawo da shi azaman ganowa na musamman na wani nau'i ba saboda nau'ikan da yawa na iya yin taswira zuwa sunan iri iri.
/// Hakanan, babu garantin cewa duk sassan nau'in zasu bayyana a cikin layin da aka dawo: misali, a halin yanzu ba a haɗa masu tantance rayuwa.
/// Bugu da kari, da fitarwa iya canza tsakanin versions na tarawa.
///
/// A halin yanzu aiwatar yana amfani da wannan kayayyakin more rayuwa a matsayin tarawa bincikowa da kuma debuginfo, amma wannan ba tabbas.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Ya dawo sunan nau'in alamar-zuwa darajar azaman yanki na kirtani.
/// Wannan yayi daidai da `type_name::<T>()`, amma ana iya amfani dashi inda nau'in mai canzawa baya samun saukinsa.
///
/// # Note
///
/// Wannan ana nufin yin amfani da bincike.A daidai abinda ke ciki da kuma format na kirtani ne ba a kayyade ba, wasu fiye da kasancewa a mafi kyau-kokarin bayanin irin nau'in.
/// Misali, `type_name_of_val::<Option<String>>(None)` na iya dawo da `"Option<String>"` ko `"std::option::Option<std::string::String>"`, amma ba `"foobar"` ba.
///
/// Bugu da kari, da fitarwa iya canza tsakanin versions na tarawa.
///
/// Wannan aikin baya warware abubuwan trait, ma'ana `type_name_of_val(&7u32 as &dyn Debug)` na iya dawo da `"dyn Debug"`, amma ba `"u32"` ba.
///
/// A irin sunan ya kamata ba za a dauke wani farɗan mai ganowa na wani irin;
/// nau'ikan nau'ikan na iya raba nau'in suna iri ɗaya.
///
/// A halin yanzu aiwatar yana amfani da wannan kayayyakin more rayuwa a matsayin tarawa bincikowa da kuma debuginfo, amma wannan ba tabbas.
///
/// # Examples
///
/// Buga tsoho lamba da float iri.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}