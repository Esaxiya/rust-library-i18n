//! Sauya halaye.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Sabobin tuba a `u32` zuwa `char`.
///
/// Note cewa duk [`char`] s suna da inganci [`u32`] s, da kuma iya zama da simintin zuwa daya tare da
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Koyaya, baya ba gaskiya bane: ba dukkan inganci [``u32`] s suke ingantacce '' char`] ba.
/// `from_u32()` zai dawo da `None` idan shigarwar ba ta da ƙimar darajar [`char`].
///
/// Ga wani unsafe version na wannan aiki wanda watsi da wadannan cak, ganin [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Dawo `None` a lokacin da labari ba ingantaccen [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Ya canza `u32` zuwa `char`, yana watsi da inganci.
///
/// Note cewa duk [`char`] s suna da inganci [`u32`] s, da kuma iya zama da simintin zuwa daya tare da
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Koyaya, baya ba gaskiya bane: ba dukkan inganci [``u32`] s suke ingantacce '' char`] ba.
/// `from_u32_unchecked()` za su yi watsi da wannan, kuma suyi jefa wa [`char`], yiwu samar da wani nakasasshe daya.
///
///
/// # Safety
///
/// Wannan aiki ne unsafe, kamar yadda zai iya yi ba daidai ba `char` dabi'u.
///
/// Don amintaccen sigar wannan aikin, duba aikin [`from_u32`].
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // KIYAYEWAR: mai kiran dole ne tabbacin cewa `i` ne mai aiki char darajar.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Sabobincike [`char`] zuwa [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Sabobincike [`char`] zuwa [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // An saka cajin zuwa ƙimar lambar lambar, sa'annan an ƙara sifiri zuwa 64 kaɗan.
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Sabobincike [`char`] zuwa [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // A char aka casted da darajar da code aya, sa'an nan sifili-mika to 128 bit.
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Maps baiti a cikin 0x00 ..=0xFF zuwa `char` wanda lambar lambar sa take da daraja iri ɗaya, a cikin U + 0000 ..=U + 00FF.
///
/// An tsara Unicode ta yadda wannan zai iya sarrafa baiti tare da tsarin haruffa wanda IANA ke kira ISO-8859-1.
/// Wannan rikodin ya dace da ASCII.
///
/// Lura cewa wannan ya bambanta da ISO/IEC 8859-1 aka
/// ISO 8859-1 (tare da daya kasa jan layi), wanda ya fita da wasu "blanks", byte dabi'u cewa ba su sanya masa wani takwara hali.
/// ISO-8859-1 (na IANA daya) yana sanya su zuwa lambobin sarrafa C0 da C1.
///
/// Note cewa wannan shi ne *ma* daban-daban daga Windows-1252 aka
/// lambar shafi na 1252, wanda shine babban ISO/IEC 8859-1 wanda ke sanya wasu (ba duka ba!) blanks zuwa alamun rubutu da haruffan Latin daban-daban.
///
/// Don kara rikitar da abubuwa, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, da `windows-1252` duk sunaye ne na babban tauraron dan adam na Windows-1252 wanda ke cike sauran ragowar tare da lambobin kula da C0 da C1 daidai.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Sabobin tuba a [`u8`] cikin wani [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Kuskure wanda za'a iya dawo dashi yayin gwada caji.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // KYAUTA: an bincika cewa ƙimar unicode ce ta doka
            Ok(unsafe { transmute(i) })
        }
    }
}

/// The kuskure irin koma a lõkacin da wata hira daga u32 zuwa char kasa.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Sabobin lambobi a cikin radix da aka bayar zuwa `char`.
///
/// A 'radix' nan ne wani lokacin kuma ya kira wani 'base'.
/// A radix na biyu ya nuna a binary lambar, a radix na goma, gidan goma, da kuma wani radix na goma sha shida, hexadecimal, to ba wasu na kowa dabi'u.
///
/// Hanawa radices suna goyon bayan.
///
/// `from_digit()` zai dawo `None` idan shigar ba lambobi a cikin ba radix.
///
/// # Panics
///
/// Panics idan aka bashi radix yafi 36 girma.
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Lambar Decimal 11 lambobi guda ɗaya ne a cikin tushe 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Dawowar `None` lokacin shigarwar ba lamba bace:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Wucewa babban radix, yana haifar da panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}