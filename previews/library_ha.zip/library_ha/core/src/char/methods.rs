//! talla char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Mafi mahimman lambar lambar da `char` zai iya samu.
    ///
    /// A `char` ne [Unicode Scalar Value], wanda ke nufin cewa shi ne mai [Code Point], amma kawai suke cikin wasu kewayo.
    /// `MAX` shine mafi mahimman lambar lambar da ke aiki [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () da ake amfani a Unicode wakilci a dikodi mai kuskure.
    ///
    /// Zai iya faruwa, alal misali, lokacin bayar da baiti mara kyau UTF-8 baiti zuwa [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// A version of [Unicode](http://www.unicode.org/) cewa Unicode sassa na `char` da `str` hanyoyin su ne bisa.
    ///
    /// Sabbin nau'ikan Unicode ana sake su akai-akai kuma daga baya duk hanyoyin da ke cikin ingantaccen ɗakin karatu dangane da Unicode ana sabunta su.
    /// Saboda haka halayyar wasu hanyoyin `char` da `str` da ƙimar wannan dorewar suna canzawa akan lokaci.
    /// Wannan *ba* ɗauke shi a matsayin raunin canji.
    ///
    /// An yi bayanin tsarin lambobi a cikin [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Esirƙira mai fa'ida akan abubuwan lambar kodin na UTF-16 wanda aka sanya a cikin `iter`, yana mai dawo da marasa aiki kamar ``Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// A lossy decoder za a iya samu ta hanyar maye gurbin `Err` sakamakon da maye hali:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Sabobin tuba a `u32` zuwa `char`.
    ///
    /// Note cewa duk `char`s suna da inganci [`u32`] s, kuma za a iya jefa shi zuwa daya tare da
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Koyaya, baya ba gaskiya bane: ba duk ingantattu [``u32`] s '' masu inganci ne 'char`s ba.
    /// `from_u32()` zai dawo da `None` idan shigarwar ba ta da ƙimar darajar `char`.
    ///
    /// Ga wani unsafe version na wannan aiki wanda watsi da wadannan cak, ganin [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Dawo `None` a lokacin da labari ba ingantaccen `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Ya canza `u32` zuwa `char`, yana watsi da inganci.
    ///
    /// Note cewa duk `char`s suna da inganci [`u32`] s, kuma za a iya jefa shi zuwa daya tare da
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Koyaya, baya ba gaskiya bane: ba duk ingantattu [``u32`] s '' masu inganci ne 'char`s ba.
    /// `from_u32_unchecked()` za su yi watsi da wannan, kuma suyi jefa wa `char`, yiwu samar da wani nakasasshe daya.
    ///
    ///
    /// # Safety
    ///
    /// Wannan aiki ne unsafe, kamar yadda zai iya yi ba daidai ba `char` dabi'u.
    ///
    /// Don amintaccen sigar wannan aikin, duba aikin [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // KYAUTA: dole ne mai kiran ya kiyaye yarjejeniyar aminci.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Sabobin lambobi a cikin radix da aka bayar zuwa `char`.
    ///
    /// A 'radix' nan ne wani lokacin kuma ya kira wani 'base'.
    /// A radix na biyu ya nuna a binary lambar, a radix na goma, gidan goma, da kuma wani radix na goma sha shida, hexadecimal, to ba wasu na kowa dabi'u.
    ///
    /// Hanawa radices suna goyon bayan.
    ///
    /// `from_digit()` zai dawo `None` idan shigar ba lambobi a cikin ba radix.
    ///
    /// # Panics
    ///
    /// Panics idan aka bashi radix yafi 36 girma.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Lambar Decimal 11 lambobi guda ɗaya ne a cikin tushe 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Dawowar `None` lokacin shigarwar ba lamba bace:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Wucewa babban radix, yana haifar da panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Ana dubawa idan `char` lamba ce a cikin radix ɗin da aka bayar.
    ///
    /// A 'radix' nan ne wani lokacin kuma ya kira wani 'base'.
    /// A radix na biyu ya nuna a binary lambar, a radix na goma, gidan goma, da kuma wani radix na goma sha shida, hexadecimal, to ba wasu na kowa dabi'u.
    ///
    /// Hanawa radices suna goyon bayan.
    ///
    /// Idan aka kwatanta da [`is_numeric()`], wannan aikin yana gane alamun `0-9`, `a-z` da `A-Z` kawai.
    ///
    /// 'Digit' an bayyana shine kawai haruffa masu zuwa:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Don cikakkiyar fahimtar 'digit', duba [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics idan aka bashi radix yafi 36 girma.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Wucewa babban radix, yana haifar da panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Ya canza `char` zuwa lamba a cikin radix din da aka bayar.
    ///
    /// A 'radix' nan ne wani lokacin kuma ya kira wani 'base'.
    /// A radix na biyu ya nuna a binary lambar, a radix na goma, gidan goma, da kuma wani radix na goma sha shida, hexadecimal, to ba wasu na kowa dabi'u.
    ///
    /// Hanawa radices suna goyon bayan.
    ///
    /// 'Digit' an bayyana shine kawai haruffa masu zuwa:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Koma `None` idan `char` ba koma zuwa wani lambobi a cikin ba radix.
    ///
    /// # Panics
    ///
    /// Panics idan aka bashi radix yafi 36 girma.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Wucewa maras lambar sakamakon a gazawar:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Wucewa babban radix, yana haifar da panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // an raba lambar a nan don haɓaka saurin aiwatarwa don shari'o'in da `radix` ke tsaye kuma 10 ko ƙarami
        //
        let val = if likely(radix <= 10) {
            // Idan ba a lambobi, da dama mafi girma daga radix za a halitta.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Ya dawo da mai magana wanda ya samar da tserewa na Unicode na yanayi wanda yake matsayin `` char ''.
    ///
    /// Wannan zai tsere haruffa da Rust ginin kalma da siffan `\u{NNNNNN}` inda `NNNNNN` ne hexadecimal misali.
    ///
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ko-ing 1 tabbatar da cewa ga c==0 da code computes cewa daya lambobi ya kamata a buga da kuma (abin da yake guda) zai kawar da (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // fihirisar mafi girman lamba hex
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// An Extended version of `escape_debug` cewa dole izni tsere Fadada Grapheme codepoints.
    /// Wannan yale mu mu format haruffa kamar nonspacing alamomi mafi alhẽri a lõkacin da suka yi a farkon kirtani.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Koma wani iterator cewa yã'yan gundarin gudun hijira code na wani hali kamar yadda `char`s.
    ///
    /// Wannan zai tsere daga haruffa kwatankwacin aiwatarwar `Debug` na `str` ko `char`.
    ///
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Koma wani iterator cewa yã'yan gundarin gudun hijira code na wani hali kamar yadda `char`s.
    ///
    /// An zaɓi tsoho tare da son zuciya don samar da rubuce-rubuce waɗanda ke halal a cikin yare daban-daban, gami da C++ 11 da ire-iren yaren C-family.
    /// Ainihin dokoki sune:
    ///
    /// * Tab ya tsere kamar `\t`.
    /// * Karusa dawo tsere a matsayin `\r`.
    /// * Layin layi yana tserewa azaman `\n`.
    /// * Single quote tsere kamar yadda `\'`.
    /// * Quote Double ya tsere azaman `\"`.
    /// * Backslash tsere kamar yadda `\\`.
    /// * Duk wani hali a cikin 'na bugawan dutse ascii' kewayon `0x20` .. `0x7e` m ba tsere.
    /// * All sauran haruffa da aka bã hexadecimal Unicode Tserewa.duba [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Koma yawan bytes wannan `char` zai bukatar idan shigar wanda ke aiki a UTF-8.
    ///
    /// Wannan yawan bytes ne ko da yaushe tsakanin 1 da 4, har zuwa.
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// A `&str` irin tabbacin cewa abinda ke ciki ne UTF-8, kuma haka za mu iya kwatanta tsawon shi zai dauka idan kowane code batu da aka wakilta a matsayin mai `char` vs a `&str` kanta:
    ///
    ///
    /// ```
    /// // a matsayin chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // duka biyu za a iya wakilta a matsayin uku bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // a matsayin &str, wadannan biyu suna shigar wanda ke aiki a UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // zamu iya ganin sun dauki baiti shida gaba daya ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... kamar &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Koma adadin 16-bit code raka'a wannan `char` zai bukatar idan shigar wanda ke aiki a UTF-16.
    ///
    ///
    /// Duba takardun don [`len_utf8()`] don ƙarin bayani game da wannan ra'ayi.
    /// Wannan aikin madubi ne, amma don UTF-16 maimakon UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Sanya wannan halayyar azaman UTF-8 a cikin tanadin byte buffer, sannan kuma ya dawo da ƙaramar buff din da ke ƙunshe da haruffan da ke aiki.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan buffer ba babban isa.
    /// Maɓallin ajiyewa na tsawon huɗu yana da girma don sanya kowane `char`.
    ///
    /// # Examples
    ///
    /// A biyu daga cikin wadannan misalai, 'ß' daukan biyu bytes zuwa encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Abin ajiyewa wanda yayi ƙarami kaɗan:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // KIYAYEWAR: `char` ba surrogate, don haka wannan shi ne inganci UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encodes wannan hali kamar yadda UTF-16 cikin bayar `u16` buffer, sa'an nan ya kõma da subslice na buffer cewa yana dauke da rikidadde hali.
    ///
    ///
    /// # Panics
    ///
    /// Panics idan buffer ba babban isa.
    /// Maɓallin ajiyewa na tsawon 2 yana da girma don sanya kowane `char`.
    ///
    /// # Examples
    ///
    /// A biyu daga cikin wadannan misalai, '𝕊' daukan biyu `u16`s zuwa encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Abin ajiyewa wanda yayi ƙarami kaɗan:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Koma `true` idan wannan `char` yana da `Alphabetic` dukiya.
    ///
    /// `Alphabetic` an bayyana shi a cikin Fasali na 4 (Abubuwan Hali) na [Unicode Standard] kuma an ƙayyade su a cikin [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // soyayya ne da abubuwa da yawa, amma shi ba alphabetic
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Ya dawo `true` idan wannan `char` yana da dukiyar `Lowercase`.
    ///
    /// `Lowercase` an bayyana shi a cikin Fasali na 4 (Abubuwan Hali) na [Unicode Standard] kuma an ƙayyade su a cikin [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // A daban-daban na kasar Sin rubutun da kuma alamar rubutu ba su da hali, da kuma haka:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Ya dawo `true` idan wannan `char` yana da dukiyar `Uppercase`.
    ///
    /// `Uppercase` an bayyana shi a cikin Fasali na 4 (Abubuwan Hali) na [Unicode Standard] kuma an ƙayyade su a cikin [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // A daban-daban na kasar Sin rubutun da kuma alamar rubutu ba su da hali, da kuma haka:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Ya dawo `true` idan wannan `char` yana da dukiyar `White_Space`.
    ///
    /// `White_Space` An kayyade a cikin [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // sarari mara karya
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Yana dawo da `true` idan wannan `char` ya gamsar ko dai [`is_alphabetic()`] ko [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Ya dawo `true` idan wannan `char` yana da babban jigo don lambobin sarrafawa.
    ///
    /// Control Lambobin (code maki tare da general category na `Cc`) suna bayyana a Babi na 4 (Character Properties) na [Unicode Standard] da kuma kayyade in da [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// // U + 009C, BABI MAI GASKIYA
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Koma `true` idan wannan `char` yana da `Grapheme_Extend` dukiya.
    ///
    /// `Grapheme_Extend` aka bayyana a cikin [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] da kuma kayyade in da [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Koma `true` idan wannan `char` yana daya daga cikin janar Categories ga lambobin.
    ///
    /// A general Categories ga lambobin (`Nd` for Lambobin gidan goma, `Nl` for harafi-kamar Tazarar haruffa, kuma `No` ga sauran Tazarar haruffa) an kayyade a cikin [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Amfani na asali:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Ya dawo da mai magana wanda ya samar da taswirar ƙaramar wannan `char` azaman ɗaya ko fiye
    /// `char`s.
    ///
    /// Idan wannan `char` bashi da taswirar ƙaramar wasiƙa, mai maimaitawa ya samar da wannan `char` ɗin.
    ///
    /// Idan wannan `char` yana da taswirar ƙarami ɗaya-da-ɗaya wanda aka bayar ta [Unicode Character Database][ucd] [`UnicodeData.txt`], mai gabatarwar ya samar da `char` ɗin.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Idan wannan `char` bukatar musamman sharudda (misali mahara `char`s) da iterator da ake samu da`char` (s) ba ta [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Wannan aikin yana aiwatar da taswira ba tare da sharadi ba ba tare da yin dinki ba.Wato, da hira ne mai zaman kanta da mahallin da kuma harshe.
    ///
    /// A [Unicode Standard], Babi na 4 (Character Properties) tattauna hali zanen taswira in general kuma Babi na 3 (Conformance) tattauna default algorithm for hali hira.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Wani lokaci sakamakon ne fiye da daya hali:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Haruffa cewa ba su da duka biyu babban da kuma Ƙaramin baki tuba zuwa da kansu.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Ya dawo da mai magana wanda ya samar da babbar taswirar wannan `char` ɗin kamar ɗaya ko fiye
    /// `char`s.
    ///
    /// Idan wannan `char` bashi da babban taswira, mai amsawar yana samar da `char` iri ɗaya.
    ///
    /// Idan wannan `char` yana da wani daya-to-daya babban Taswirar da aka ba da [Unicode Character Database][ucd] [`UnicodeData.txt`], da iterator da ake samu cewa `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Idan wannan `char` bukatar musamman sharudda (misali mahara `char`s) da iterator da ake samu da`char` (s) ba ta [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Wannan aikin yana aiwatar da taswira ba tare da sharadi ba ba tare da yin dinki ba.Wato, da hira ne mai zaman kanta da mahallin da kuma harshe.
    ///
    /// A [Unicode Standard], Babi na 4 (Character Properties) tattauna hali zanen taswira in general kuma Babi na 3 (Conformance) tattauna default algorithm for hali hira.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kamar yadda wani iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Amfani da `println!` kai tsaye:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Dukansu suna daidai da:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Amfani da `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Wani lokaci sakamakon ne fiye da daya hali:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Haruffa cewa ba su da duka biyu babban da kuma Ƙaramin baki tuba zuwa da kansu.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Lura kan yanki
    ///
    /// A Turkiyya, kwatankwacin 'i' a Latin yana da biyar siffofin maimakon biyu:
    ///
    /// * 'Dotless': I/i, wani lokacin rubuta ï
    /// * 'Dotted': İ/i
    ///
    /// Lura cewa Ƙaramin baki cike da gidajen gona 'i' ne guda a matsayin Latin.Saboda haka:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// The darajar `upper_i` nan dogara a kan harshe da rubutu: idan muka yi a cikin `en-US`, shi ya kamata `"I"`, amma idan muka yi a cikin `tr_TR`, shi ya kamata `"İ"`.
    /// `to_uppercase()` baya la'akari da wannan, don haka:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// riqe fadin harsuna.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Ana dubawa idan ƙimar tana cikin zangon ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Yana yin kwafin ƙimar a cikin babban lamarinta na ASCII daidai.
    ///
    /// Haruffan ASCII 'a' zuwa 'z' an tsara su zuwa 'A' zuwa 'Z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don babban darajar a-wuri, amfani da [`make_ascii_uppercase()`].
    ///
    /// Don babban ascii haruffa a Bugu da kari ya ba ascii characters, amfani da [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Yana yin kwafin ƙimar a cikin ƙaramin ƙaramin rubutun ta na ASCII.
    ///
    /// Haruffan ASCII 'A' zuwa 'Z' an tsara su zuwa 'a' zuwa 'z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don ƙaramin ƙimar a cikin-wuri, yi amfani da [`make_ascii_lowercase()`].
    ///
    /// Don Ƙaramin baki ascii haruffa a Bugu da kari ya ba ascii characters, amfani da [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Duba cewa ƙimomi biyu wasan ASCII ne maras ma'ana.
    ///
    /// Daidaita zuwa `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Sabobin tuba da irin wannan to ta ascii manya m, a-wuri.
    ///
    /// Haruffan ASCII 'a' zuwa 'z' an tsara su zuwa 'A' zuwa 'Z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don dawo da sabon darajar ƙarami ba tare da gyaggyara wanda yake ba, yi amfani da [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Sanya wannan nau'in zuwa matsayin ƙaramar shigar ta ASCII daidai-wuri.
    ///
    /// Haruffan ASCII 'A' zuwa 'Z' an tsara su zuwa 'a' zuwa 'z', amma ba haruffan ASCII ba canzawa.
    ///
    /// Don komawa wani sabon lowercased darajar ba tare da gyara da data kasance daya, yi amfani da [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Duba idan darajar haruffa ce ta ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ko
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Cak idan darajar ne wani ascii babban harafin:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Ana dubawa idan ƙimar hali ce ta ƙaramar ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Ana bincika idan ƙimar halayyar haruffa ta ASCII ce:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ko
    /// - U + 0061 'a' ..=U + 007A 'z', ko
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Ana dubawa idan ƙimar lambar adadi ce ta ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Cak idan darajar ne wani ascii hexadecimal lambobi:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ko
    /// - U + 0041 'A' ..=U + 0046 'F', ko
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Cak idan darajar ne wani ascii alamar rubutu hali:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ko
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ko
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, ko
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Ana bincika idan ƙimar halayyar hoto ce ta ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Cak idan darajar ne wani ascii farin hali:
    /// U + 0020 SPACE, U + 0009 kwance TAB, U + 000A LINE ciyar, U + 000C Form ciyar da abinci, ko U + 000D karusa MAYARWA.
    ///
    /// Rust yana amfani da WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Akwai wasu ma'anoni da yawa a cikin amfani mai yawa.
    /// Misali, [the POSIX locale][pct] ya hada da U + 000B VERTICAL TAB da kuma dukkan haruffan da ke sama, amma-daga irin bayanin guda daya-[ka'idojin daidai na "field splitting" a cikin Bourne shell][bfs] sun ɗauki *kawai* SPACE, HORIZONTAL TAB, kuma LAYI CIYAR kamar sararin samaniya.
    ///
    ///
    /// Idan kana rubuta wani shirin cewa zai aiwatar da wani data kasance fayil format, duba abin da wannan format ta definition na farin ne kafin yin amfani da wannan aikin.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Ana dubawa idan ƙimar hali ce ta yanayin sarrafa ASCII:
    /// U + 0000 NUL ..=U + 001F Naúrar SEPARATOR, ko U + 007F share.
    /// Note cewa mafi ascii farin haruffa ne iko haruffa, amma SPACE ba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Encodes wani raw u32 darajar a matsayin UTF-8 cikin bayar byte buffer, sa'an nan ya kõma da subslice na buffer cewa yana dauke da rikidadde hali.
///
///
/// Ba kamar `char::encode_utf8` ba, wannan hanyar tana ɗaukar maɓallin lambar sirri a cikin kewayon maye gurbinsu.
/// (Samar da wani `char` a surrogate iyaka ne UB.) A sakamakon haka ne m [generalized UTF-8] amma ba shi da inganci UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics idan buffer ba babban isa.
/// Maɓallin ajiyewa na tsawon huɗu yana da girma don sanya kowane `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Sanya ƙimar darajar u32 azaman UTF-16 a cikin tanadin `u16`, sannan kuma ya dawo da ƙaramin abin ajiye abin da ke ƙunshe da haruffan da ke aiki.
///
///
/// Ba kamar `char::encode_utf16` ba, wannan hanyar tana ɗaukar maɓallin lambar sirri a cikin kewayon maye gurbinsu.
/// (Samar da wani `char` a surrogate iyaka ne UB.)
///
/// # Panics
///
/// Panics idan buffer ba babban isa.
/// Maɓallin ajiyewa na tsawon 2 yana da girma don sanya kowane `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // KYAUTA: kowace hannu tana bincika ko akwai wadatar rarar da za'a rubuta a ciki
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ta faɗi ta ciki
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Karin jirage karya a cikin surrogates.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}