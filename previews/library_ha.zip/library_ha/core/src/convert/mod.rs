//! Traits don sauyawa tsakanin nau'ikan.
//!
//! A traits a cikin wannan module samar da wata hanya ta maida daga daya irin zuwa wani irin.
//! Kowane trait hidima a daban-daban manufa:
//!
//! - Aiwatar da [`AsRef`] trait for cheap reference-to-reference Abubuwan Taɗi
//! - Aiwatar da [`AsMut`] trait don raƙuman canjin canjin-canzawa
//! - Aiwatar da [`From`] trait ga cinyewa darajar-to-darajar Abubuwan Taɗi
//! - Aiwatar da [`Into`] trait don cinye canje-canje masu ƙima da darajar zuwa nau'ikan waje da crate na yanzu
//! - [`TryFrom`] da [`TryInto`] traits suna nuna hali kamar [`From`] da [`Into`], amma ya kamata a aiwatar da su yayin da sauyawar zai iya kasawa.
//!
//! A traits a cikin wannan module sukan amfani da matsayin trait bounds for Generic ayyuka irin wannan cewa ya muhawara na mahara iri suna goyan bayan.Dubi takardun na kowane trait ga misalai.
//!
//! A matsayinka na marubucin laburare, ya kamata koyaushe ka fi son aiwatar da [`From<T>`][`From`] ko [`TryFrom<T>`][`TryFrom`] maimakon [`Into<U>`][`Into`] ko [`TryInto<U>`][`TryInto`], kamar yadda [`From`] da [`TryFrom`] ke samar da sassauci mafi girma da bayar da kwatankwacin aiwatarwar [`Into`] ko [`TryInto`] kyauta, godiya ga aiwatar da bargo a cikin ɗakunan karatu na yau da kullun.
//! Lokacin da aka kaiwa wani version kafin Rust 1.41, shi yana iya zama dole su aiwatar da [`Into`] ko [`TryInto`] kai tsaye a lokacin da tana mayar wa wani irin waje na yanzu crate.
//!
//! # Aiwatar da Tsarin Mulki
//!
//! - [`AsRef`] da [`AsMut`] auto-refefe idan nau'in ciki abin tunani ne
//! - [`From`] <U>'for T`yakan haifar [` Into`]'</u><T><U>domin U`</u>
//! - [``TryFrom`] '' <U>don T`yana nuna [`` TryInto`] ''</u><T><U>domin U`</u>
//! - [`From`] kuma [`Into`] suna da juyayi, wanda ke nufin cewa duk nau'ikan zasu iya `into` kansu da `from` da kansu
//!
//! Dubi kowane trait for amfani misalai.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// A Aikin asali.
///
/// Abubuwa biyu suna da mahimmanci a lura game da wannan aikin:
///
/// - Ba koyaushe yake dacewa da ƙulli kamar `|x| x` ba, tunda ƙulli na iya tilasta `x` zuwa wani nau'in daban.
///
/// - Yana motsa shigarwar `x` da aka wuce zuwa aikin.
///
/// Duk da yake shi iya ze m zuwa da wani aiki da cewa kawai ya dawo baya da shigar, akwai wasu ban sha'awa amfani.
///
///
/// # Examples
///
/// Amfani da `identity` don yin komai a cikin jerin wasu, masu ban sha'awa, ayyuka:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Bari mu yi da'awa cewa ƙara daya ne mai ban sha'awa aiki.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Amfani da `identity` azaman tushen asalin "do nothing" a cikin sharaɗi:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Yi ƙarin abubuwa masu ban sha'awa ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Amfani da `identity` don adana nau'ikan `Some` na mai magana da `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// An yi amfani dashi don yin rahusar bincike mai sauƙin tunani.
///
/// Wannan trait yayi kama da [`AsMut`] wanda ake amfani dashi don canzawa tsakanin nassoshi masu canzawa.
/// Idan kana buƙatar yin canji mai tsada yana da kyau a aiwatar da [`From`] tare da nau'in `&T` ko rubuta aikin al'ada.
///
/// `AsRef` yana da sa hannu iri ɗaya kamar [`Borrow`], amma [`Borrow`] ya bambanta a cikin wasu fannoni:
///
/// - Ba kamar `AsRef`, [`Borrow`] yana da wani bargo impl ga wani `T`, kuma za a iya amfani da su yarda da ko dai wani tunani ko wani darajar.
/// - [`Borrow`] kuma na bukatar cewa [`Hash`], [`Eq`] da [`Ord`] for aro darajar ne m ga waɗanda na mallakar darajar.
/// Saboda wannan dalili, idan kana so ka ara guda ɗaya kawai filin daga a struct za ka iya yi `AsRef`, amma ba [`Borrow`].
///
/// **Note: Wannan trait dole ba kasa **.Idan jujjuyawar zata iya kasa, yi amfani da hanyar sadaukarwa wacce ta dawo da [`Option<T>`] ko [`Result<T, E>`].
///
/// # Aiwatar da Tsarin Mulki
///
/// - `AsRef` sake rubutawa ta atomatik idan nau'in ciki abin kwatance ne ko kuma fassarar canzawa (misali: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// By ta amfani da trait bounds za mu iya yarda da muhawara na daban-daban dai sun za a iya tuba zuwa kayyade irin `T`.
///
/// Ga misali: By samar da wani Generic aiki da daukan wani `AsRef<str>` mu bayyana cewa muna so mu yarda da duk nassoshi da cewa za a iya tuba zuwa [`&str`] a matsayin shaida.
/// Tun da [`String`] da [`&str`] yi `AsRef<str>` za mu iya yarda da duka biyu kamar yadda shigar da shaida.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Ya yi aikin hira.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// An yi amfani dashi don yin canjin canjin canjin canjin rahusa.
///
/// Wannan trait yayi kama da [`AsRef`] amma ana amfani dashi don canzawa tsakanin nassoshi masu canzawa.
/// Idan kana buƙatar yin canji mai tsada yana da kyau a aiwatar da [`From`] tare da nau'in `&mut T` ko rubuta aikin al'ada.
///
/// **Note: Wannan trait dole ba kasa **.Idan jujjuyawar zata iya kasa, yi amfani da hanyar sadaukarwa wacce ta dawo da [`Option<T>`] ko [`Result<T, E>`].
///
/// # Aiwatar da Tsarin Mulki
///
/// - `AsMut` auto-dereferences idan ciki da irin ne a mutable reference (misali: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Amfani da `AsMut` azaman trait bound don aikin gama gari za mu iya karɓar duk nassoshi masu canzawa waɗanda za a iya canza su zuwa rubuta `&mut T`.
/// Saboda [`Box<T>`] yana aiwatar da `AsMut<T>` zamu iya rubuta aiki `add_one` wanda ke ɗaukar duk mahawara da za a iya canzawa zuwa `&mut u64`.
/// Saboda [`Box<T>`] yana aiwatar da `AsMut<T>`, `add_one` yana karɓar maganganu na nau'in `&mut Box<u64>` kuma:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Ya yi aikin hira.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Canjin darajar-zuwa-ƙimar da ke cinye darajar shigarwar.Kishiyar [`From`].
///
/// Ya kamata mutum ya guji aiwatar da [`Into`] kuma aiwatar da [`From`] maimakon.
/// Aiwatar da [`From`] ta atomatik yana ba da ɗayan tare da aiwatar da [`Into`] godiya ga aiwatar da bargon a cikin ɗakunan karatu na yau da kullun.
///
/// Fi son amfani da [`Into`] akan [`From`] yayin tantance trait bounds akan aikin gama gari don tabbatar da cewa nau'ikan da suke aiwatar da [`Into`] kawai ana iya amfani dasu suma.
///
/// **Note: Wannan trait bazaiyi kasa ** ba.Idan jujjuyawar ta kasa, yi amfani da [`TryInto`].
///
/// # Aiwatar da Tsarin Mulki
///
/// - [`From`] '<T>don U` yana nuna `Into<U> for T`
/// - [`Into`] ne da turawa yanzu, wanda ke nufin cewa `Into<T> for T` aka aiwatar
///
/// # Aiwatar da [`Into`] for Abubuwan Taɗi zuwa waje iri a cikin tsohon juyi na Rust
///
/// Kafin Rust 1.41, idan nau'in makomar baya cikin crate na yanzu to baza ku iya aiwatar da [`From`] kai tsaye ba.
/// Alal misali, sama da wannan code:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Wannan zai kasa tara a mazan versions na harshe, saboda Rust ta orphaning dokoki amfani da su zama kadan mafi tsananin.
/// Don kewaye wannan, zaku iya aiwatar da [`Into`] kai tsaye:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Yana da mahimmanci a fahimci cewa [`Into`] baya bayar da aiwatar da [`From`] (kamar yadda [`From`] yayi tare da [`Into`]).
/// Saboda haka, ya kamata ka ko da yaushe kokarin aiwatar [`From`] sa'an nan fada a mayar da [`Into`] idan [`From`] ba za a iya aiwatar.
///
/// # Examples
///
/// [`String`] aiwatarwa [``Cikin ']`<`[`` Vec`]' '<`[`u8`] `` >>:
///
/// Domin bayyana cewa muna so a Generic aiki ya dauki dukan muhawara da cewa za a iya tuba zuwa ga wani ajali irin `T`, za mu iya amfani da wani trait bound na [`Into`] '<T>``.
///
/// Misali: Aikin `is_hello` yana ɗaukar duk takaddun da za a iya canza su zuwa cikin ``Vec`] '' <`[` u8`]``>.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Ya yi aikin hira.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// An yi amfani dashi don yin canjin darajar-zuwa-ƙimar yayin cinye ƙimar shigarwa.Yanayin [`Into`] ne.
///
/// Daya ya kamata ko da yaushe fi son aiwatar `From` kan [`Into`] domin aiwatar da `From` ta atomatik samar da daya tare da wani aiwatar da [`Into`] godiya ga bargo aiwatar a cikin misali library.
///
///
/// Kawai yi [`Into`] lokacin da niyya mai version kafin Rust 1.41 kuma tana mayar wa wani irin waje na yanzu crate.
/// `From` bai sami ikon yin waɗannan nau'ikan juyarwar a sigar da ta gabata ba saboda dokokin marayu na Rust.
/// Duba [`Into`] don ƙarin bayani.
///
/// Fi son yin amfani da [`Into`] kan yin amfani da `From` lokacin da tantancewa trait bounds a kan wani Generic aiki.
/// Wannan hanyar, nau'ikan da suke aiwatar da [`Into`] kai tsaye ana iya amfani dasu azaman mahawara.
///
/// `From` yana da matukar amfani yayin aiwatar da kuskuren kuskure.Lokacin da gina wani aiki da cewa shi ne iya kasawa, da dawowar irin za kullum zama daga cikin irin `Result<T, E>`.
/// `From` trait yana sauƙaƙe sarrafa kuskure ta hanyar barin aiki ya dawo da nau'in kuskuren guda ɗaya wanda ke rufe nau'ikan kuskuren da yawa.Duba sashin "Examples" da [the book][book] don ƙarin bayani.
///
/// **Note: Wannan trait bazaiyi kasa ** ba.Idan jujjuyawar zata iya faduwa, yi amfani da [`TryFrom`].
///
/// # Aiwatar da Tsarin Mulki
///
/// - `From<T> for U` yana nufin [``Cikin ']`` <U>don T`</u>
/// - `From` yana da saurin fahimta, wanda ke nufin cewa an aiwatar da `From<T> for T`
///
/// # Examples
///
/// [`String`] aiwatar da `From<&str>`:
///
/// Juyawa bayyananne daga `&str` zuwa Kirtani ana yin ta kamar haka:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Duk da yake yin kuskure da tanadin shi ne sau da yawa amfani da su aiwatar da `From` for your own kuskure irin.
/// By tana mayar tamkar kuskure iri to namu al'ada kuskure irin wanda encapsulates tamkar kuskure irin, ba za mu iya komawa guda kuskure irin tare da rasa bayani a kan tamkar hanyar.
/// Mai aiki na '?' yana canza nau'in kuskuren da ke ciki ta atomatik zuwa nau'in kuskurenmu na al'ada ta hanyar kiran `Into<CliError>::into` wanda aka bayar ta atomatik lokacin aiwatar da `From`.
/// Mai tattarawa ya bayyana abin da za a yi amfani da `Into`.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Ya yi aikin hira.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// An yi yunkurin hira da cewa jan `self`, wanda ya iya ko ba zai zama tsada.
///
/// Yakamata marubutan laburare ba su aiwatar da wannan trait kai tsaye, amma ya kamata su fi son aiwatar da [`TryFrom`] trait, wanda ke ba da sassauci mafi girma kuma yana samar da kwatankwacin aiwatar da `TryInto` kyauta, godiya ga aiwatar da bargo a cikin ɗakunan karatu na yau da kullun.
/// Don ƙarin bayani game da wannan, duba takaddun don [`Into`].
///
/// # Aiwatar da `TryInto`
///
/// Wannan yana fama da ƙuntatawa iri ɗaya da dalilai kamar aiwatar da [`Into`], duba can don cikakkun bayanai.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// A irin koma a taron na hira kuskure.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ya yi aikin hira.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Sauya nau'ikan juzu'i da aminci waɗanda zasu iya gazawa ta hanyar sarrafawa a ƙarƙashin wasu yanayi.Yanayin [`TryInto`] ne.
///
/// Wannan na da amfani a lokacin da kake yin wani irin hira da cewa zai iya trivially ci amma iya bukatar musamman handling.
/// Alal misali, akwai wata hanya zuwa maida wani [`i64`] cikin wani [`i32`] amfani da [`From`] trait, saboda wani [`i64`] iya ƙunsar wani darajar da cewa an [`i32`] ba zai iya wakiltar da haka hira zai rasa data.
///
/// Wannan zai iya abar kulawa da Yanke da [`i64`] zuwa wani [`i32`] (da gaske ba da [`i64`] 's darajar modulo [`i32::MAX`]) ko ta hanyar kawai dawo [`i32::MAX`], ko ta wata hanya.
/// [`From`] trait an tsara shi don cikakkiyar juyowa, don haka `TryFrom` trait yana sanar da mai shirya shirye-shiryen lokacin da wani nau'in jujjuyawar zai iya zama mara kyau kuma ya basu damar yanke shawarar yadda zasu magance shi.
///
/// # Aiwatar da Tsarin Mulki
///
/// - `TryFrom<T> for U` yakan haifar da [`TryInto`] <U>'for T`</u>
/// - [`try_from`] yana da hankali, wanda ke nufin cewa an aiwatar da `TryFrom<T> for T` kuma ba zai iya kasawa ba-nau'in `Error` mai hade don kiran `T::try_from()` akan ƙimar nau'in `T` shine [`Infallible`].
/// Lokacin da nau'in [`!`] ya daidaita [`Infallible`] kuma [`!`] zai zama daidai.
///
/// `TryFrom<T>` za a iya aiwatar kamar haka:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kamar yadda aka bayyana, [`i32`] yana aiwatar da ``TryFrom <`[`i64`] ''>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Shiru ya datse `big_number`, yana buƙatar ganowa da sarrafa katsewar bayan gaskiyar.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Koma wani kuskure saboda `big_number` ne ma babban don shige a wani `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Koma `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// A irin koma a taron na hira kuskure.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ya yi aikin hira.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS
////////////////////////////////////////////////////////////////////////////////

// Kamar yadda lifts kan&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Kamar yadda yake hawa sama da &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): maye gurbin abubuwan da ke sama don&/&mut tare da mai zuwa gaba ɗaya:
// // Kamar yadda yake ɗauke da Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {FN as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut ya ɗaga sama da &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): maye gurbin sama impl for &mut tare da wadannan karin janar daya:
// // AsMut ya daga DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Girma> AsMut <U>na D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Daga yakan haifar Cikin
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Daga (da haka Cikin) ne turawa yanzu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stability rubutu:** Wannan impl ba tukuna zama, amma muna "reserving space" don ƙara da shi a cikin future.
/// Dubi [rust-lang/rust#64715][#64715] domin cikakkun bayanai.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): yi a akida fix maimakon.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom yana nuna TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Ma'asumi Abubuwan Taɗi ne semantically daidai fallible Abubuwan Taɗi da wani inda ba wanda yake zaune kuskure irin.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// kankare IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// BABU-KUSKURI KURAI IRIN
////////////////////////////////////////////////////////////////////////////////

/// Nau'in kuskure don kurakurai waɗanda ba za su taɓa faruwa ba.
///
/// Tun da yake wannan enum yana da wani bambanci, da darajar da irin wannan zai iya taba zahiri wanzu.
/// Wannan zai iya zama da amfani ga Generic APIs cewa amfani da [`Result`] da parameterize da kuskure type, to nuna cewa sakamakon shi ne ko da yaushe [`Ok`].
///
/// Misali, [`TryFrom`] trait (jujjuyawar da ta dawo da [`Result`]) yana da aiwatar da bargo ga kowane nau'in inda aiwatar da [`Into`] na baya yake.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future karfinsu
///
/// Wannan enum yana da matsayi iri ɗaya kamar [the `!`“never”type][never], wanda ba shi da tabbas a cikin wannan sigar ta Rust.
/// Lokacin da `!` ya daidaita, muna shirin sanya `Infallible` wani nau'in laƙabi da shi:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Kuma ƙarshe rage darajar `Infallible`.
///
/// Duk da haka akwai daya hali inda `!` ginin kalma za a iya amfani da `!` aka stabilized a matsayin cikakken fledged type: a matsayin wani aiki na sama da irin.
/// Musamman, yana yiwuwa aiwatarwa don nau'ikan alamomin aiki iri biyu:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Tare da `Infallible` kasancewa wani enum, wannan code shi ne inganci.
/// Koyaya lokacin da `Infallible` ya zama laƙabi ga never type, abubuwan ``impl`s '' biyu za su fara haɗuwa don haka za a hana su ta dokokin haɗin kai na trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}