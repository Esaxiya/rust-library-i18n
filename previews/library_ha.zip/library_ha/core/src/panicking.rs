//! Panic goyon baya ga libcore
//!
//! Babban ɗakin karatu ba zai iya bayyana ma'anar tsoro ba, amma yana bayyana * tsoro.
//! Wannan yana nufin cewa ayyukan ciki na libcore an yarda dasu zuwa panic, amma don amfani ga crate na gaba dole ne ya ayyana tsoro don libcore yayi amfani dashi.
//! Hanyar yanzu don firgita ita ce:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Wannan ma'anar tana ba da damar firgita tare da kowane saƙo, amma ba ya ba da izinin gazawa tare da ƙimar `Box<Any>`.
//! (`PanicInfo` kawai yana ƙunshe da `&(dyn Any + Send)`, wanda muke cika shi da ƙima a cikin `` PanicInfo: : internally_constructor ''.) Dalilin wannan shi ne cewa ba a ba da izinin raba libcore ba.
//!
//!
//! Wannan kundin yana dauke da wasu sauran ayyukan firgita, amma wadannan sune abubuwan lalatattun abubuwa ga mai harhadawa.Duk panics ana haɗa su ta wannan aikin ɗaya.
//! Ana bayyana ainihin alamar ta hanyar sifa ta `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Abubuwan da ke gudana na libcore's `panic!` macro lokacin da ba a amfani da tsari.
#[cold]
// kar a baka layi sai dai panic_immediate_abort don kauce ma lambar lamba a wuraren kira gwargwadon iko
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // da ake buƙata ta codegen don panic kan yawo da sauran masu dakatarwa na `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Yi amfani da Arguments::new_v1 maimakon format_args! ("{}", Expr) don rage girman sama.
    // Tsarin-yayi!macro tana amfani da Str's Display trait don rubuta expr, wanda ke kira Formatter::pad, wanda dole ne ya saukar da kirtani da padding (duk da cewa babu wanda yayi amfani dashi anan).
    //
    // Amfani da Arguments::new_v1 na iya ba mahaɗin damar barin Formatter::pad daga binaryar da aka fitar, yana adanawa zuwa kiloan kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // da ake buƙata don ƙididdigar panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // da ake buƙata ta codegen don panic akan damar OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Abubuwan da ke gudana na libcore's `panic!` macro lokacin amfani da tsarin.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // SAURARA Wannan aikin ba ya ƙetare iyakar FFI;kira ne na Rust-to-Rust wanda aka warware shi zuwa aikin `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // KYAUTA: An bayyana `panic_impl` a cikin amintaccen lambar Rust kuma don haka amintacce ne a kira shi.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Aikin ciki don `assert_eq!` da `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}