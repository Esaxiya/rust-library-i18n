//! Wannan shi ne wani ciki module amfani da ifmt!Runtime.Wadannan Tsarin ake jefarwa rikicewar iri-iri to precompile format kirtani gaba lokaci.
//!
//! Waɗannan ma'anoni suna kama da kwatankwacinsu na `ct`, amma sun banbanta da cewa waɗannan ana iya rarraba su ta ƙa'ida kuma an ɗan inganta su don lokacin gudu
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Hanyoyin daidaitawa da za a iya buƙata azaman ɓangare na umarnin tsarawa.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Nuni da cewa abinda ke ciki ya zama hagu-hada kai.
    Left,
    /// Nuni da cewa abinda ke ciki ya zama dama-hada kai.
    Right,
    /// Nuni da cewa abinda ke ciki ya zama cibiyar hada kai-.
    Center,
    /// Ba a nemi daidaitawa ba.
    Unknown,
}

/// Amfani da [width](https://doc.rust-lang.org/std/fmt/#width) da [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// An ƙayyade tare da lambar zahiri, yana adana ƙimar
    Is(usize),
    /// Ƙayyade yin amfani da `$` da `*` syntaxes, Stores index cikin `args`
    Param(usize),
    /// Ba a kayyade ba
    Implied,
}