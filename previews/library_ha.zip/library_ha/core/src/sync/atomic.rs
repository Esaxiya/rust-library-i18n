//! Nau'ikan Atomic
//!
//! Nau'ikan Atomic suna samar da dadaddiyar hanyar sadarwa ta hanyar sadarwa tsakanin zaren, kuma sune tubalin ginin wasu nau'ikan.
//!
//! Wannan rukunin yana bayyana nau'ikan atomic na wani nau'in adadi na nau'ikan dadadden zamani, gami da [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], da sauransu.
//! Nau'ikan Atom suna gabatar da ayyuka wanda, idan aka yi amfani dasu daidai, aiki tare sabuntawa tsakanin zaren.
//!
//! Kowace hanya tana ɗaukar [`Ordering`] wanda ke wakiltar ƙarfin shingen ƙwaƙwalwar ajiya don wannan aikin.Waɗannan oda suna daidai da [C++20 atomic orderings][1].Don ƙarin bayani duba [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomic canji ne mai lafiya don raba tsakanin zaren (suka yi [`Sync`]) amma suka yi ba kansu samar da inji don rabawa da kuma bi [threading model](../../../std/thread/index.html#the-threading-model) na Rust.
//!
//! Mafi na kowa hanya don raba wani atomic m ne a saka shi a cikin wani [`Arc`][arc] (wani atomically-reference-kidaya shared akan).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Ana iya adana nau'ikan Atom a cikin maɓuɓɓuka masu canzawa, farawa ta amfani da masu farawa koyaushe kamar [`AtomicBool::new`].Atomic statics sukan yi amfani ga m duniya initialization.
//!
//! # Portability
//!
//! Duk nau'ikan atomatik a cikin wannan manhajan ana da tabbacin zama [lock-free] idan suna nan.Wannan yana nufin ba su samo lalata ta duniya ba.Nau'in Atom da ayyuka ba a tabbatar da cewa ba su da jira.
//! Wannan yana nufin cewa ayyukan kamar `fetch_or` iya aiwatar da wani kwatanta-da-canza madauki.
//!
//! Za'a iya aiwatar da ayyukan Atom a sashin umarni tare da atomatik masu girman girma.Misali wasu dandamali suna amfani da umarnin atomic 4-byte don aiwatar da `AtomicI8`.
//! Lura cewa wannan kwaikwayon bai kamata yayi tasiri akan daidaituwar lambar ba, kawai wani abu ne wanda ya kamata a sani.
//!
//! Nau'in zarra a cikin wannan tsarin maiyuwa bazai samu a dukkan dandamali ba.Nau'o'in atom a nan duk suna yadu, duk da haka, kuma ana iya dogara da shi gaba ɗaya akan abubuwan da ake dasu.Wasu sananne ware su ne:
//!
//! * PowerPC kuma dandamali na MIPS tare da masu nuni 32-bit basu da nau'ikan `AtomicU64` ko `AtomicI64`.
//! * ARM dandamali kamar `armv5te` waɗanda ba na Linux ba ne kawai ke ba da ayyukan `load` da `store`, kuma ba sa tallafawa ayyukan Kwatanta da Musayar (CAS), kamar `swap`, `fetch_add`, da dai sauransu.
//! Ari akan Linux, ana aiwatar da waɗannan ayyukan CAS ta hanyar [operating system support], wanda zai iya zuwa tare da azabar aiki.
//! * ARM maƙasudi tare da `thumbv6m` suna ba da ayyukan `load` da `store` kawai, kuma ba sa goyan bayan Kwatanta da Swap (CAS) aiki, kamar `swap`, `fetch_add`, da dai sauransu.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Lura cewa ana iya ƙara dandamali na future wanda shima bashi da tallafi don wasu ayyukan atom.Maxxally šaukuwa šaukuwa lambar zai so ya yi hankali game da abin da atomic iri ake amfani da.
//! `AtomicUsize` kuma `AtomicIsize` galibi sune mafi saurin ɗaukawa, amma duk da haka basa samunsu ko'ina.
//! Don tunani, ɗakin karatu na `std` yana buƙatar matakan atomatik, kodayake `core` baya buƙata.
//!
//! A halin yanzu zaku buƙaci amfani da `#[cfg(target_arch)]` da farko don tsara yanayin cikin lamba tare da atom.Akwai mara tabbaci `#[cfg(target_has_atomic)]` shima kuma wanda za'a iya daidaita shi a cikin future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Spinarƙirar sauƙi:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Jira dayan zaren don saki makullin
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Ci gaba da lissafin zaren duniya:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Nau'in boolean wanda za'a iya raba shi tsakanin zaren cikin aminci.
///
/// Wannan nau'in yana da wakilcin ƙwaƙwalwa iri ɗaya kamar [`bool`].
///
/// **Lura**: Ana samun wannan nau'in a dandamali waɗanda ke tallafawa kayan atom da ɗakunan ajiya na `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Irƙira `AtomicBool` da aka fara zuwa `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Aika aika a fakaice don AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Nau'in nunin manuni wanda za'a iya raba shi tsakanin zaren cikin aminci.
///
/// Wannan irin yana da guda a-memory wakilci a matsayin `*mut T`.
///
/// **Lura**: Ana samun wannan nau'in a dandamali waɗanda ke tallafawa kayan atom da kuma shagunan alamomi.
/// Its size dogara a kan manufa akan ta size.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Halicci null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomic memory orderings
///
/// Umurnin ƙwaƙwalwar ajiya yana tantance yadda ayyukan atom ke aiki tare da ƙwaƙwalwa.
/// A cikin mafi rauni [`Ordering::Relaxed`], kawai ƙwaƙwalwar da aikin ya taɓa kai tsaye ana aiki tare.
/// A gefe guda, ɗawainiyar kayan ajiya na ayyukan [`Ordering::SeqCst`] suna aiki tare da sauran ƙwaƙwalwar ajiya tare da adana cikakken tsari na irin waɗannan ayyukan a cikin dukkan zaren.
///
///
/// Umurnin ƙwaƙwalwar Rust shine [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Don ƙarin bayani duba [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Babu takurawar oda, kawai ayyukan atom.
    ///
    /// Ya dace da [`memory_order_relaxed`] a cikin C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Idan aka haɗe shi tare da shago, duk ayyukan da aka gabata ana yin oda kafin kowane lodin wannan ƙimar tare da odar [`Acquire`] (ko mafi ƙarfi).
    ///
    /// A musamman, duk baya ya rubuta ya zama a bayyane a duk zaren da cewa yin wani [`Acquire`] (ko karfi) load wannan darajar.
    ///
    /// Ka lura cewa amfani da wannan ordering ga wani aiki da hadawa lodi da Stores take kaiwa zuwa wani [`Relaxed`] load aiki!
    ///
    /// Wannan ordering ne kawai m ga ayyukan da za su iya yi wani store.
    ///
    /// Ya dace da [`memory_order_release`] a cikin C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Lokacin guda biyu tare da wani kaya, idan lodi darajar da aka rubuta da wani kantin sayar da aiki tare da [`Release`] (ko karfi) ordering, sa'an nan dukan m ayyukan sami umurni bayan cewa store.
    /// A musamman, duk m lodi za su ga data rubuta kafin store.
    ///
    /// Lura cewa yin amfani da wannan oda don aikin da ya haɗu da lodi da shaguna yana haifar da aikin shagon [`Relaxed`]!
    ///
    /// Wannan oda yana zartar ne kawai don ayyukan da zasu iya yin loda.
    ///
    /// Ya dace da [`memory_order_acquire`] a cikin C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Yana da tasirin duka [`Acquire`] da [`Release`] tare:
    /// Domin lodi shi yana amfani da [`Acquire`] ordering.Domin Stores shi yayi amfani da [`Release`] ordering.
    ///
    /// Lura cewa a cikin batun `compare_and_swap`, mai yiwuwa ne aikin ya ƙare ba tare da yin wani shago ba kuma saboda haka kawai yana da umarnin [`Acquire`].
    ///
    /// Koyaya, `AcqRel` ba zai taɓa yin amfani da damar [`Relaxed`] ba.
    ///
    /// Wannan ordering ne kawai m ga ayyukan da hada duka biyu lodi da Stores.
    ///
    /// Ya dace da [`memory_order_acq_rel`] a cikin C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Kamar [`Acquire`]/[`Release`]/[`AcqRel`](for kaya, store, da kuma aza-da-kantin sayar da aiki, bi da bi) tare da ƙarin tabbacin cewa duk zaren ganin dukkan sequentially m ayyukan a cikin wannan tsari .
    ///
    ///
    /// Ya dace da [`memory_order_seq_cst`] a cikin C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] ya fara zuwa `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Irƙiri sabon `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Koma wani mutable tunani da muhimmi [`bool`].
    ///
    /// Wannan amintacce ne saboda bayanan da za'a iya canzawa suna tabbatar da cewa babu wasu zaren da suke samun damar bayanan atom a lokaci guda.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // KIYAYEWAR: da mutable reference tabbatar musamman ikon mallakar.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Samu damar atomic zuwa `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // KYAUTA: fassarar mai canzawa tana ba da tabbacin mallaki na musamman, kuma
        // jeri na biyu `bool` da `Self` ne 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Cinye atom din kuma ya dawo da ƙimar da take ciki.
    ///
    /// Wannan shi ne hadari saboda wucewa `self` da darajar da tabbacin cewa babu sauran zaren ake bi-biye da samun dama da atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Lodi a darajar daga bool.
    ///
    /// `load` yana ɗaukar takaddar [`Ordering`] wanda ke bayanin umarnin ƙwaƙwalwar ajiyar wannan aikin.
    /// Zai yiwu dabi'u ne [`SeqCst`], [`Acquire`] da [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics idan `order` shine [`Release`] ko [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // KYAUTA: duk wani tseren bayanai an hana shi ta atomic intrinsics da danye
        // Pointer wuce a cikin da yake da inganci saboda mun samu shi daga wani zance.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Adana ƙimar cikin bool.
    ///
    /// `store` yana ɗaukar takaddar [`Ordering`] wanda ke bayanin umarnin ƙwaƙwalwar ajiyar wannan aikin.
    /// Zai yiwu dabi'u ne [`SeqCst`], [`Release`] da [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics idan `order` shine [`Acquire`] ko [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // KYAUTA: duk wani tseren bayanai an hana shi ta atomic intrinsics da danye
        // Pointer wuce a cikin da yake da inganci saboda mun samu shi daga wani zance.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Adana ƙima a cikin bool, yana dawo da ƙimar da ta gabata.
    ///
    /// `swap` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
    /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Adana ƙimar cikin [`bool`] idan ƙimar yanzu tana daidai da darajar `current`.
    ///
    /// Imar dawowa koyaushe ƙimar da ta gabata ce.Idan shi ne daidai `current`, sa'an nan da darajar da aka sabunta.
    ///
    /// `compare_and_swap` ma daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.
    /// Lura cewa koda ana amfani da [`AcqRel`], aikin na iya kasa don haka kawai yayi lodin `Acquire`, amma bashi da ma'anar ma'anar `Release`.
    /// Amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`] idan ya faru, kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Migrating zuwa `compare_exchange` da `compare_exchange_weak`
    ///
    /// `compare_and_swap` shi ne daidai da `compare_exchange` tare da wadannan Taswirar for memory orderings:
    ///
    /// Na asali |Nasara |Rashin nasara
    /// -------- | ------- | -------
    /// Huta |Huta |Annashuwa Samowa |acquire |Saya Release |Saki |Shaƙatawa AcqRel |AcqRel |Saya SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` an ba shi izinin gazawa koda da lokacin da kwatancen ya yi nasara, wanda zai ba mai haɗawa damar ƙirƙirar lambar haɗin mafi kyau lokacin da aka yi amfani da kwatancen da sauyawa a cikin madauki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Adana ƙimar cikin [`bool`] idan ƙimar yanzu tana daidai da darajar `current`.
    ///
    /// A samu darajar ne sakamakon nuna ko sabon darajar da aka rubuta da kuma dauke da baya darajar.
    /// A kan cin nasara wannan ƙimar tabbas an daidaita shi da `current`.
    ///
    /// `compare_exchange` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
    /// `success` yana bayanin umarnin da ake buƙata don karatun-gyara-rubutun aiki wanda ke gudana idan kwatankwacin `current` ya yi nasara.
    /// `failure` ya bayyana umarnin da ake buƙata don aikin ɗaukar kaya wanda ke faruwa lokacin da kwatancen ya gaza.
    /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya kaya mai nasara [`Relaxed`].
    ///
    /// Da gazawar ordering iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kuma dole ne daidai ko weaker fiye da nasara ordering.
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Adana ƙimar cikin [`bool`] idan ƙimar yanzu tana daidai da darajar `current`.
    ///
    /// Ba kamar [`AtomicBool::compare_exchange`] ba, ana ba da izinin wannan aikin ya ɓace koda kuwa lokacin da kwatancen ya yi nasara, wanda zai haifar da ingantaccen lamba akan wasu dandamali.
    ///
    /// A samu darajar ne sakamakon nuna ko sabon darajar da aka rubuta da kuma dauke da baya darajar.
    ///
    /// `compare_exchange_weak` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
    /// `success` yana bayanin umarnin da ake buƙata don karatun-gyara-rubutun aiki wanda ke gudana idan kwatankwacin `current` ya yi nasara.
    /// `failure` ya bayyana umarnin da ake buƙata don aikin ɗaukar kaya wanda ke faruwa lokacin da kwatancen ya gaza.
    /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya kaya mai nasara [`Relaxed`].
    /// Da gazawar ordering iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kuma dole ne daidai ko weaker fiye da nasara ordering.
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" mai ma'ana tare da ƙimar boolean.
    ///
    /// Yi aikin "and" mai ma'ana akan ƙimar yanzu da takaddar `val`, kuma saita sabon ƙima ga sakamakon.
    ///
    /// Ya dawo da ƙimar da ta gabata.
    ///
    /// `fetch_and` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
    /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Koma bayan tunanin "nand" da Boolean darajar.
    ///
    /// Aikin mai ma'ana "nand" aiki a kan halin yanzu darajar da shawara `val`, kuma sets sabon darajar da sakamakon.
    ///
    /// Ya dawo da ƙimar da ta gabata.
    ///
    /// `fetch_nand` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
    /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Ba za mu iya amfani da atomic_nand nan saboda yana iya haifar da wata bool mara darajar.
        // Wannan yana faruwa ne saboda ana yin aikin atom tare da lamba 8-bit aciki, wanda zai saita ragin 7 na sama.
        //
        // Saboda haka muna kawai amfani da fetch_xor ko canza maimakon.
        if val {
            // ! (X&gaskiya)== !x Dole ne mu invert da bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (X&ƙarya)==gaskiya Dole ne mu saita bool zuwa gaskiya.
            //
            self.swap(true, order)
        }
    }

    /// Koma bayan tunanin "or" da Boolean darajar.
    ///
    /// Yi aikin "or" mai ma'ana akan ƙimar yanzu da takaddar `val`, kuma saita sabon ƙima ga sakamakon.
    ///
    /// Ya dawo da ƙimar da ta gabata.
    ///
    /// `fetch_or` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
    /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Koma bayan tunanin "xor" da Boolean darajar.
    ///
    /// Yi aikin "xor" mai ma'ana akan ƙimar yanzu da takaddar `val`, kuma saita sabon ƙima ga sakamakon.
    ///
    /// Ya dawo da ƙimar da ta gabata.
    ///
    /// `fetch_xor` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
    /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Ya dawo da alamar nuna alama ga [`bool`].
    ///
    /// Yin ba atomic karanta, kuma ya rubuta a kan sakamakon lamba na iya zama wani data tseren.
    /// Wannan hanyar ta fi amfani ga FFI, inda sa hannu zai iya amfani da `*mut bool` maimakon `&AtomicBool`.
    ///
    /// Mayar da bayanan `*mut` daga bayanin da aka raba akan wannan atom din yana da aminci saboda nau'ikan atom suna aiki tare da canjin yanayin ciki.
    /// All gyare-gyare na wani atomic canji darajar ta hanyar wani shared reference, da kuma iya yin haka a amince matuƙar sun yi amfani da atomic ayyukan.
    /// Duk wani amfani na koma raw akan bukatar wani `unsafe` block kuma har yanzu yana da su riqi wannan hanin: aiki a kan shi dole ne atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Ebo da darajar, da kuma ya shafi wani aiki to shi cewa ya dawo wani na zaɓi sabon darajar.Koma wani `Result` na `Ok(previous_value)` idan aiki koma `Some(_)`, kuma `Err(previous_value)`.
    ///
    /// Note: Wannan na iya kiran aikin sau da yawa idan an canza darajar daga sauran zaren a halin yanzu, matuƙar aikin ya dawo `Some(_)`, amma aikin zai kasance sau ɗaya kawai aka sanya shi zuwa ƙimar da aka adana.
    ///
    ///
    /// `fetch_update` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
    /// Na farko ya bayyana umarnin da ake buƙata don lokacin da aiki ya sami nasara yayin da na biyun ya bayyana umarnin da ake buƙata don lodi.
    /// Waɗannan suna dacewa da umarnin nasara da rashin nasara na [`AtomicBool::compare_exchange`] bi da bi.
    ///
    /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aiki [`Relaxed`], kuma amfani da [`Release`] shine zai sanya nasarar ƙarshe [`Relaxed`].
    /// Umurnin ɗora kaya na (failed) na iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kawai kuma dole ne ya zama daidai ko rauni fiye da nasarar nasara.
    ///
    /// **Note:** Wannan hanya ne kawai samuwa a kan dandamali da cewa goyi bayan atomic aiki a kan `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Irƙiri sabon `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Koma wani mutable tunani da tamkar akan.
    ///
    /// Wannan amintacce ne saboda bayanan da za'a iya canzawa suna tabbatar da cewa babu wasu zaren da suke samun damar bayanan atom a lokaci guda.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Samu damar atomic zuwa mai nunawa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - Tunani mai canzawa yana ba da tabbacin mallakar mallaka ta musamman.
        //  - daidaitawar `*mut T` da `Self` iri ɗaya ne a duk dandamali da rust ke tallafawa, kamar yadda aka tabbatar a sama.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Cinye atom din kuma ya dawo da ƙimar da take ciki.
    ///
    /// Wannan shi ne hadari saboda wucewa `self` da darajar da tabbacin cewa babu sauran zaren ake bi-biye da samun dama da atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Loads ƙima daga maɓallin nunawa
    ///
    /// `load` yana ɗaukar takaddar [`Ordering`] wanda ke bayanin umarnin ƙwaƙwalwar ajiyar wannan aikin.
    /// Zai yiwu dabi'u ne [`SeqCst`], [`Acquire`] da [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics idan `order` shine [`Release`] ko [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Adana ƙima a cikin mai nunawa.
    ///
    /// `store` yana ɗaukar takaddar [`Ordering`] wanda ke bayanin umarnin ƙwaƙwalwar ajiyar wannan aikin.
    /// Zai yiwu dabi'u ne [`SeqCst`], [`Release`] da [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics idan `order` shine [`Acquire`] ko [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Adana ƙima a cikin mai nunawa, yana dawo da ƙimar da ta gabata.
    ///
    /// `swap` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
    /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    ///
    /// **Note:** Wannan hanyar kawai ana samun ta a dandamali waɗanda ke tallafawa ayyukan atom a kan alamomi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Stores da darajar cikin akan idan na yanzu darajar ne guda a matsayin `current` darajar.
    ///
    /// Imar dawowa koyaushe ƙimar da ta gabata ce.Idan shi ne daidai `current`, sa'an nan da darajar da aka sabunta.
    ///
    /// `compare_and_swap` ma daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.
    /// Lura cewa koda ana amfani da [`AcqRel`], aikin na iya kasa don haka kawai yayi lodin `Acquire`, amma bashi da ma'anar ma'anar `Release`.
    /// Amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`] idan ya faru, kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
    ///
    /// **Note:** Wannan hanyar kawai ana samun ta a dandamali waɗanda ke tallafawa ayyukan atom a kan alamomi.
    ///
    /// # Migrating zuwa `compare_exchange` da `compare_exchange_weak`
    ///
    /// `compare_and_swap` shi ne daidai da `compare_exchange` tare da wadannan Taswirar for memory orderings:
    ///
    /// Na asali |Nasara |Rashin nasara
    /// -------- | ------- | -------
    /// Huta |Huta |Annashuwa Samowa |acquire |Saya Release |Saki |Shaƙatawa AcqRel |AcqRel |Saya SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` an ba shi izinin gazawa koda da lokacin da kwatancen ya yi nasara, wanda zai ba mai haɗawa damar ƙirƙirar lambar haɗin mafi kyau lokacin da aka yi amfani da kwatancen da sauyawa a cikin madauki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Stores da darajar cikin akan idan na yanzu darajar ne guda a matsayin `current` darajar.
    ///
    /// A samu darajar ne sakamakon nuna ko sabon darajar da aka rubuta da kuma dauke da baya darajar.
    /// A kan cin nasara wannan ƙimar tabbas an daidaita shi da `current`.
    ///
    /// `compare_exchange` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
    /// `success` yana bayanin umarnin da ake buƙata don karatun-gyara-rubutun aiki wanda ke gudana idan kwatankwacin `current` ya yi nasara.
    /// `failure` ya bayyana umarnin da ake buƙata don aikin ɗaukar kaya wanda ke faruwa lokacin da kwatancen ya gaza.
    /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya kaya mai nasara [`Relaxed`].
    ///
    /// Da gazawar ordering iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kuma dole ne daidai ko weaker fiye da nasara ordering.
    ///
    /// **Note:** Wannan hanyar kawai ana samun ta a dandamali waɗanda ke tallafawa ayyukan atom a kan alamomi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Stores da darajar cikin akan idan na yanzu darajar ne guda a matsayin `current` darajar.
    ///
    /// Ba kamar [`AtomicPtr::compare_exchange`] ba, ana ba da izinin wannan aikin ya ɓace koda kuwa lokacin da kwatancen ya yi nasara, wanda zai haifar da ingantaccen lamba akan wasu dandamali.
    ///
    /// A samu darajar ne sakamakon nuna ko sabon darajar da aka rubuta da kuma dauke da baya darajar.
    ///
    /// `compare_exchange_weak` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
    /// `success` yana bayanin umarnin da ake buƙata don karatun-gyara-rubutun aiki wanda ke gudana idan kwatankwacin `current` ya yi nasara.
    /// `failure` ya bayyana umarnin da ake buƙata don aikin ɗaukar kaya wanda ke faruwa lokacin da kwatancen ya gaza.
    /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya kaya mai nasara [`Relaxed`].
    /// Da gazawar ordering iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kuma dole ne daidai ko weaker fiye da nasara ordering.
    ///
    /// **Note:** Wannan hanyar kawai ana samun ta a dandamali waɗanda ke tallafawa ayyukan atom a kan alamomi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KIYAYEWAR: Wannan muhimmi shi ne unsafe saboda shi aiki a kan wani raw akan
        // amma mun sani tabbas cewa mai nuna alama yana da inganci (kawai mun samo shi daga `UnsafeCell` da muke da shi ta hanyar tunani) kuma aikin atom ɗin kansa yana ba mu damar amintar da abubuwan da ke ciki na `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Ebo da darajar, da kuma ya shafi wani aiki to shi cewa ya dawo wani na zaɓi sabon darajar.Koma wani `Result` na `Ok(previous_value)` idan aiki koma `Some(_)`, kuma `Err(previous_value)`.
    ///
    /// Note: Wannan na iya kiran aikin sau da yawa idan an canza darajar daga sauran zaren a halin yanzu, matuƙar aikin ya dawo `Some(_)`, amma aikin zai kasance sau ɗaya kawai aka sanya shi zuwa ƙimar da aka adana.
    ///
    ///
    /// `fetch_update` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
    /// Na farko ya bayyana umarnin da ake buƙata don lokacin da aiki ya sami nasara yayin da na biyun ya bayyana umarnin da ake buƙata don lodi.
    /// Waɗannan suna dacewa da umarnin nasara da rashin nasara na [`AtomicPtr::compare_exchange`] bi da bi.
    ///
    /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aiki [`Relaxed`], kuma amfani da [`Release`] shine zai sanya nasarar ƙarshe [`Relaxed`].
    /// Umurnin ɗora kaya na (failed) na iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kawai kuma dole ne ya zama daidai ko rauni fiye da nasarar nasara.
    ///
    /// **Note:** Wannan hanyar kawai ana samun ta a dandamali waɗanda ke tallafawa ayyukan atom a kan alamomi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Sabobin tuba a `bool` cikin wani `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Wannan macro ya ƙare kasancewar ba a amfani dashi akan wasu gine-ginen.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// An lamba irin wanda za a iya amince raba tsakanin zaren.
        ///
        /// Wannan nau'ikan yana da wakilcin ƙwaƙwalwar ajiya iri ɗaya kamar nau'in nau'in lamba, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Don ƙarin game da bambance-bambance tsakanin atomic iri da kuma wadanda ba atomic iri, kazalika da bayanai game da portability na irin wannan, don Allah ganin [module-level documentation].
        ///
        ///
        /// **Note:** Wannan irin ne kawai samuwa a kan dandamali da cewa goyi bayan atomic lodi da Stores na [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// An atomic lamba initialized zuwa `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Aika aika a fakaice.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Irƙiri sabon lamba atomic.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Koma wani mutable tunani da tamkar lamba.
            ///
            /// Wannan amintacce ne saboda bayanan da za'a iya canzawa suna tabbatar da cewa babu wasu zaren da suke samun damar bayanan atom a lokaci guda.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// bari mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// bayyana_eq! (wasu_mintattu, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - Tunani mai canzawa yana ba da tabbacin mallakar mallaka ta musamman.
                //  - jeri na `$int_type` da `Self` ne guda, kamar yadda Ya yi alkawarin $cfg_align da kuma tabbatar sama.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Cinye atom din kuma ya dawo da ƙimar da take ciki.
            ///
            /// Wannan shi ne hadari saboda wucewa `self` da darajar da tabbacin cewa babu sauran zaren ake bi-biye da samun dama da atomic data.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Ana ɗora ƙima daga lambar atom.
            ///
            /// `load` yana ɗaukar takaddar [`Ordering`] wanda ke bayanin umarnin ƙwaƙwalwar ajiyar wannan aikin.
            /// Zai yiwu dabi'u ne [`SeqCst`], [`Acquire`] da [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics idan `order` shine [`Release`] ko [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Adana ƙimar cikin lambar atom.
            ///
            /// `store` yana ɗaukar takaddar [`Ordering`] wanda ke bayanin umarnin ƙwaƙwalwar ajiyar wannan aikin.
            ///  Zai yiwu dabi'u ne [`SeqCst`], [`Release`] da [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics idan `order` shine [`Acquire`] ko [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Adana ƙima a cikin lamba atom, yana dawo da ƙimar da ta gabata.
            ///
            /// `swap` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Adana ƙima a cikin lambar atom idan ƙimar ta yanzu daidai take da ta `current`.
            ///
            /// Imar dawowa koyaushe ƙimar da ta gabata ce.Idan shi ne daidai `current`, sa'an nan da darajar da aka sabunta.
            ///
            /// `compare_and_swap` ma daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.
            /// Lura cewa koda ana amfani da [`AcqRel`], aikin na iya kasa don haka kawai yayi lodin `Acquire`, amma bashi da ma'anar ma'anar `Release`.
            ///
            /// Amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`] idan ya faru, kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrating zuwa `compare_exchange` da `compare_exchange_weak`
            ///
            /// `compare_and_swap` shi ne daidai da `compare_exchange` tare da wadannan Taswirar for memory orderings:
            ///
            /// Na asali |Nasara |Rashin nasara
            /// -------- | ------- | -------
            /// Huta |Huta |Annashuwa Samowa |acquire |Saya Release |Saki |Shaƙatawa AcqRel |AcqRel |Saya SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` an ba shi izinin gazawa koda da lokacin da kwatancen ya yi nasara, wanda zai ba mai haɗawa damar ƙirƙirar lambar haɗin mafi kyau lokacin da aka yi amfani da kwatancen da sauyawa a cikin madauki.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Adana ƙima a cikin lambar atom idan ƙimar ta yanzu daidai take da ta `current`.
            ///
            /// A samu darajar ne sakamakon nuna ko sabon darajar da aka rubuta da kuma dauke da baya darajar.
            /// A kan cin nasara wannan ƙimar tabbas an daidaita shi da `current`.
            ///
            /// `compare_exchange` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
            /// `success` yana bayanin umarnin da ake buƙata don karatun-gyara-rubutun aiki wanda ke gudana idan kwatankwacin `current` ya yi nasara.
            /// `failure` ya bayyana umarnin da ake buƙata don aikin ɗaukar kaya wanda ke faruwa lokacin da kwatancen ya gaza.
            /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya kaya mai nasara [`Relaxed`].
            ///
            /// Da gazawar ordering iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kuma dole ne daidai ko weaker fiye da nasara ordering.
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Adana ƙima a cikin lambar atom idan ƙimar ta yanzu daidai take da ta `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// wannan aiki ne a yarda ya spuriously kasa ko lokacin da kwatanta ta yi nasara, wanda zai iya haifar da ya fi dacewa code a kan wasu dandamali.
            /// A samu darajar ne sakamakon nuna ko sabon darajar da aka rubuta da kuma dauke da baya darajar.
            ///
            /// `compare_exchange_weak` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
            /// `success` yana bayanin umarnin da ake buƙata don karatun-gyara-rubutun aiki wanda ke gudana idan kwatankwacin `current` ya yi nasara.
            /// `failure` ya bayyana umarnin da ake buƙata don aikin ɗaukar kaya wanda ke faruwa lokacin da kwatancen ya gaza.
            /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya kaya mai nasara [`Relaxed`].
            ///
            /// Da gazawar ordering iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kuma dole ne daidai ko weaker fiye da nasara ordering.
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// bari mut haihuwa= val.load(Ordering::Relaxed).
            /// madauki {bari sabon=haihuwa * 2.
            ///     daidaita val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Dsara zuwa ƙimar yanzu, dawo da ƙimar da ta gabata.
            ///
            /// Wannan aikin yana tattare da ambaliyar.
            ///
            /// `fetch_add` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Rage daga darajar yanzu, dawo da ƙimar da ta gabata.
            ///
            /// Wannan aikin yana tattare da ambaliyar.
            ///
            /// `fetch_sub` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" tare da ƙimar yanzu.
            ///
            /// Aikin wani bitwise "and" aiki a kan halin yanzu darajar da shawara `val`, kuma sets sabon darajar da sakamakon.
            ///
            /// Ya dawo da ƙimar da ta gabata.
            ///
            /// `fetch_and` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" tare da na yanzu darajar.
            ///
            /// Yana aiwatar da aikin "nand" mai ɗan gajeren lokaci akan ƙimar yanzu da hujja `val`, kuma saita sabon ƙima ga sakamakon.
            ///
            /// Ya dawo da ƙimar da ta gabata.
            ///
            /// `fetch_nand` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ((0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" tare da na yanzu darajar.
            ///
            /// Yana aiwatar da aikin "or" mai ɗan gajeren lokaci akan ƙimar yanzu da hujja `val`, kuma saita sabon ƙima ga sakamakon.
            ///
            /// Ya dawo da ƙimar da ta gabata.
            ///
            /// `fetch_or` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" tare da ƙimar yanzu.
            ///
            /// Aikin wani bitwise "xor" aiki a kan halin yanzu darajar da shawara `val`, kuma sets sabon darajar da sakamakon.
            ///
            /// Ya dawo da ƙimar da ta gabata.
            ///
            /// `fetch_xor` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Ebo da darajar, da kuma ya shafi wani aiki to shi cewa ya dawo wani na zaɓi sabon darajar.Koma wani `Result` na `Ok(previous_value)` idan aiki koma `Some(_)`, kuma `Err(previous_value)`.
            ///
            /// Note: Wannan na iya kiran aikin sau da yawa idan an canza darajar daga sauran zaren a halin yanzu, matuƙar aikin ya dawo `Some(_)`, amma aikin zai kasance sau ɗaya kawai aka sanya shi zuwa ƙimar da aka adana.
            ///
            ///
            /// `fetch_update` daukan biyu [`Ordering`] muhawara don bayyana ƙwaƙwalwar ordering na wannan aiki.
            /// A farko ya bayyana bukata ordering domin idan aiki karshe nasara yayin da na biyu ya bayyana bukata ordering for lodi.Wadannan dace da nasara da kuma gazawar orderings na
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Amfani da [`Acquire`] azaman yin odar nasara yana sanya shagon sashin wannan aiki [`Relaxed`], kuma amfani da [`Release`] shine zai sanya nasarar ƙarshe [`Relaxed`].
            /// Umurnin ɗora kaya na (failed) na iya zama [`SeqCst`], [`Acquire`] ko [`Relaxed`] kawai kuma dole ne ya zama daidai ko rauni fiye da nasarar nasara.
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (odar: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (odar: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Iyakar da na yanzu darajar.
            ///
            /// Sami iyakar da halin yanzu darajar da shawara `val`, da kuma kafa sabon darajar da sakamakon.
            ///
            /// Ya dawo da ƙimar da ta gabata.
            ///
            /// `fetch_max` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// bar bar=42;
            /// bari max_foo=foo.fetch_max (mashaya, Ordering::SeqCst).max(bar);
            /// tabbatar! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Mafi qarancin darajar ta yanzu.
            ///
            /// Sami m na yanzu darajar da shawara `val`, da kuma kafa sabon darajar da sakamakon.
            ///
            /// Ya dawo da ƙimar da ta gabata.
            ///
            /// `fetch_min` daukan wani [`Ordering`] shaida abin da ya bayyana memory ordering na wannan aiki.Duk tsarin oda yana yiwuwa.
            /// Lura cewa amfani da [`Acquire`] yana sanya shagon sashin wannan aikin [`Relaxed`], kuma amfani da [`Release`] yana sanya ɓangaren ɗaukar kaya [`Relaxed`].
            ///
            ///
            /// **Lura**: Wannan hanya ana samunta ne kawai a dandamali da ke tallafawa ayyukan atom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// bar bar=12;
            /// bari min_foo=foo.fetch_min (mashaya, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // KYAUTA: tseren bayanai an hana su ta atomic intrinsics.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Yana dawo da maɓallin canjin yanayi zuwa mahimmin lamba.
            ///
            /// Yin ba atomic karanta, kuma ya rubuta a kan sakamakon lamba na iya zama wani data tseren.
            /// Wannan hanya ita ce mafi yawa da amfani ga FFI, inda aikin sa hannu na iya amfani da
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Mayar da bayanan `*mut` daga bayanin da aka raba akan wannan atom din yana da aminci saboda nau'ikan atom suna aiki tare da canjin yanayin ciki.
            /// All gyare-gyare na wani atomic canji darajar ta hanyar wani shared reference, da kuma iya yin haka a amince matuƙar sun yi amfani da atomic ayyukan.
            /// Duk wani amfani na koma raw akan bukatar wani `unsafe` block kuma har yanzu yana da su riqi wannan hanin: aiki a kan shi dole ne atomic.
            ///
            ///
            /// # Examples
            ///
            /// `` `Watsi (extern-declaration)
            ///
            /// # FN main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// hanyar "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // KYAUTA: Lafiya muddin `my_atomic_op` na atomic ne.
            /// unsafe {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Ya dawo da ƙimar da ta gabata (kamar __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Ya dawo da ƙimar da ta gabata (kamar __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KIYAYEWAR: mai kiran dole ne riqi aminci kwangila ga `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KIYAYEWAR: mai kiran dole ne riqi aminci kwangila ga `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ya dawo da ƙimar ƙima (kwatancen da aka sa hannu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// dawo da darajar min (kwatancen da aka sa hannu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KIYAYEWAR: mai kiran dole ne riqi aminci kwangila ga `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// dawo da ƙimar max (kwatancen da ba a sa hannu ba)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KIYAYEWAR: mai kiran dole ne riqi aminci kwangila ga `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// dawo da darajar min (kwatancen da ba a sa hannu ba)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KYAUTA: mai kira dole ne ya kiyaye kwangilar aminci na `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Wani shingen atom.
///
/// Dogaro da ƙayyadadden tsari, shinge yana hana mai tarawa da CPU daga sake dawo da wasu nau'ikan ayyukan ƙwaƙwalwar ajiya a kewayenta.
/// Wannan yana haifar da aiki tare-tare da dangantaka tsakaninsa da ayyukan atom ko kuma shinge a cikin sauran zaren.
///
/// Wani shinge 'A' wanda yake da (aƙalla) [`Release`] yana ba da umarnin ma'anoni, yana aiki tare da shinge 'B' tare da (aƙalla) [`Acquire`] ma'anar ma'ana, idan kuma kawai idan akwai ayyukan X da Y, dukansu suna aiki a kan wani abu atomic 'M' irin wannan A an tsara su kafin X, Y aka aiki kafin B da kuma Y lura da canji zuwa M.
/// Wannan yana ba da damar-kafin dogaro tsakanin A da B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomic ayyukan da [`Release`] ko [`Acquire`] ilimin harsuna kuma iya aiki tare da wani shinge.
///
/// A shinge wanda yana [`SeqCst`] ordering, ban da ciwon biyu [`Acquire`] da [`Release`] ilimin harsuna, zabi a duniya shirin domin na sauran [`SeqCst`] ayyukan da/ko fences.
///
/// Yana karɓar umarnin [`Acquire`], [`Release`], [`AcqRel`] da [`SeqCst`].
///
/// # Panics
///
/// Panics idan `order` shine [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Haɓaka juna ta hanyar farko dangane da spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Jira har sai tsohuwar darajar ta kasance `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Wannan shingen yana aiki tare-tare da shago a cikin `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // KYAUTA: amfani da shingen atom yana da aminci.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Mai shinge mai ƙwaƙwalwa mai tarawa.
///
/// `compiler_fence` baya fitar da lambar inji, amma yana ƙuntata nau'ikan ƙwaƙwalwar da ke sake ba da umarnin mai tarawa ya sami izinin yin.Musamman, gwargwadon ma'anar [`Ordering`] da aka bayar, ana iya hana mai tarawa motsa motsi ko rubutu daga gaba ko bayan kira zuwa ɗayan kiran zuwa `compiler_fence`.Lura cewa hakan **baya** hana *hardware* yin irin wannan sake odar.
///
/// Wannan ba matsala bane a cikin layi ɗaya, mahallin aiwatarwa, amma lokacin da wasu zaren na iya canza ƙwaƙwalwar ajiya a lokaci guda, ana buƙatar abubuwan aiki tare na ƙarfi kamar [`fence`].
///
/// Sake yin oda wanda aka hana shi ta hanyar amfani da ilimin ma'anan shine:
///
///  - tare da [`SeqCst`], ba a sake ba da izinin sake karantawa da rubutu a cikin wannan ma'anar ba.
///  - tare da [`Release`], gabanin karanta, kuma ya rubuta ba za a iya koma da m ya rubuta.
///  - tare da [`Acquire`], karatun da ya biyo baya da rubutu ba za a iya motsa su gabanin karantawa ba.
///  - tare da [`AcqRel`], duka ƙa'idodin da ke sama ana aiwatar da su.
///
/// `compiler_fence` ne kullum kawai da amfani ga hana a thread daga tseren *da kanta*.Wato, idan zaren da aka bashi yana aiwatar da lambar lamba daya, sannan kuma aka katse shi, sai ya fara aiwatar da lambar a wani wuri (yayin da yake a dunkule guda, kuma a mahallin yana kan ainihin).A cikin shirye-shiryen gargajiya, wannan na iya faruwa lokacin da aka yi rijistar mai kula da sigina.
/// A mafi low-matakin code, irin wannan yanayi kuma iya bayyana lokacin da tanadin interrupts, a lokacin da za'a aiwatar kore zaren da pre-emption, da dai sauransu
/// Ana ƙarfafa masu karatu masu sha'awar karanta tattaunawar kwayar Linux game da [memory barriers].
///
/// # Panics
///
/// Panics idan `order` shine [`Relaxed`].
///
/// # Examples
///
/// Ba tare da `compiler_fence` ba, `assert_eq!` a cikin bin lambar *ba* tabbas ce don cin nasara, duk da duk abin da ke faruwa a cikin zare ɗaya.
/// Don ganin dalilin, tuna cewa mai tarawa yana da kyauta don musanya shagunan zuwa `IMPORTANT_VARIABLE` da `IS_READ` tunda dukkansu `Ordering::Relaxed` ne.Idan yayi, kuma ana kiran mai kula da sigina daidai bayan an sabunta `IS_READY`, to mai siginar zai ga `IS_READY=1`, amma `IMPORTANT_VARIABLE=0`.
/// Amfani da magunguna na `compiler_fence` wannan yanayin.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // hana a baya rubutuwa daga motsawa sama da wannan
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // KYAUTA: amfani da shingen atom yana da aminci.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Yi sigina ga mai sarrafawa cewa yana cikin madaidaiciyar jira-("juya makullin").
///
/// Wannan aikin ya yanke aiki saboda yarda da [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}