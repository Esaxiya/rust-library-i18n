#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` yana bawa mai aiwatar da aiki damar ƙirƙirar [`Waker`] wanda ke ba da halin farkawa na musamman.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ya ƙunshi bayanin bayanai da [virtual function pointer table (vtable)][vtable] wanda ke tsara halayen `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Mai nuna bayanai, wanda za a iya amfani da shi don adana bayanan ba da izini ba kamar yadda mai zartarwa ya buƙata.
    /// Wannan na iya zama misali
    /// wani irin-sharewa mauni zuwa wani `Arc` da ake dangantawa da aiki.
    /// Passedimar wannan filin yana wucewa zuwa duk ayyukan da ke ɓangare na abin da za a iya amfani da su azaman farkon siga.
    ///
    data: *const (),
    /// Taswirar manunin aiki wanda ke tsara halayen wannan farkawa.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Esirƙiri sabon `RawWaker` daga samfurin da aka bayar na `data` da `vtable`.
    ///
    /// A `data` akan za a iya amfani da su adana sabani data kamar yadda ake bukata da haƙĩ.Wannan na iya zama misali
    /// wani irin-sharewa mauni zuwa wani `Arc` da ake dangantawa da aiki.
    /// A darajar wannan Pointer za samun wuce zuwa da dukkan ayyuka da cewa wani bangare ne na `vtable` matsayin farko siga.
    ///
    /// `vtable` yana haɓaka halayen `Waker` wanda aka ƙirƙira shi daga `RawWaker`.
    /// Ga kowane aiki akan `Waker`, za a kira aikin da ke hade a cikin `vtable` na tushen `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// A tebur mai nuna alama mai mahimmanci (vtable) wanda ke ƙayyade halin [`RawWaker`].
///
/// The Pointer ya wuce zuwa da dukkan ayyuka a ciki da vtable ne `data` akan daga kwasfa [`RawWaker`] abu.
///
/// Ayyukan da ke cikin wannan tsarin an yi niyya ne kawai don a kira su a kan alamar `data` na ingantaccen abu [`RawWaker`] daga cikin aiwatar da [`RawWaker`].
/// Kira daya daga cikin kunshe ayyuka yin amfani da wani `data` akan zai sa maras bayyani hali.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Wannan aiki za a kira a lokacin da [`RawWaker`] samun cloned, misali a lokacin da [`Waker`] a cikin abin da [`RawWaker`] aka adana samun cloned.
    ///
    /// Aiwatar da wannan aikin dole ne ya riƙe duk albarkatun da ake buƙata don wannan ƙarin misalin [`RawWaker`] da haɗin aiki.
    /// Kira `wake` a kan sakamakon [`RawWaker`] kamata haifar da wani wakeup daga cikin wannan aiki da zai yi, an farkar damu da asali [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Wannan aikin za'a kira shi lokacin da aka kira `wake` akan [`Waker`].
    /// Dole ne ya farka aikin da ke hade da wannan [`RawWaker`].
    ///
    /// Aiwatar da wannan aikin dole ne tabbatar da sakin duk albarkatun da ke da alaƙa da wannan misalin na [`RawWaker`] da haɗin aiki.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Wannan aiki za a kira a lokacin da `wake_by_ref` aka kira a kan [`Waker`].
    /// Dole ne ya farka aikin da ke hade da wannan [`RawWaker`].
    ///
    /// Wannan aiki ne mai kama da `wake`, amma dole ne ba cinye bayar da bayanai akan.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ana kiran wannan aikin lokacin da aka sauke [`RawWaker`].
    ///
    /// Aiwatar da wannan aikin dole ne tabbatar da sakin duk albarkatun da ke da alaƙa da wannan misalin na [`RawWaker`] da haɗin aiki.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Creatirƙiri sabon `RawWakerVTable` daga ayyukan `clone`, `wake`, `wake_by_ref`, da `drop` da aka bayar.
    ///
    /// # `clone`
    ///
    /// Wannan aiki za a kira a lokacin da [`RawWaker`] samun cloned, misali a lokacin da [`Waker`] a cikin abin da [`RawWaker`] aka adana samun cloned.
    ///
    /// Aiwatar da wannan aikin dole ne ya riƙe duk albarkatun da ake buƙata don wannan ƙarin misalin [`RawWaker`] da haɗin aiki.
    /// Kira `wake` a kan sakamakon [`RawWaker`] kamata haifar da wani wakeup daga cikin wannan aiki da zai yi, an farkar damu da asali [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Wannan aikin za'a kira shi lokacin da aka kira `wake` akan [`Waker`].
    /// Dole ne ya farka aikin da ke hade da wannan [`RawWaker`].
    ///
    /// Aiwatar da wannan aikin dole ne tabbatar da sakin duk albarkatun da ke da alaƙa da wannan misalin na [`RawWaker`] da haɗin aiki.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Wannan aiki za a kira a lokacin da `wake_by_ref` aka kira a kan [`Waker`].
    /// Dole ne ya farka aikin da ke hade da wannan [`RawWaker`].
    ///
    /// Wannan aiki ne mai kama da `wake`, amma dole ne ba cinye bayar da bayanai akan.
    ///
    /// # `drop`
    ///
    /// Ana kiran wannan aikin lokacin da aka sauke [`RawWaker`].
    ///
    /// Aiwatar da wannan aikin dole ne tabbatar da sakin duk albarkatun da ke da alaƙa da wannan misalin na [`RawWaker`] da haɗin aiki.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` na aikin asynchronous.
///
/// A halin yanzu, `Context` kawai hidima don samar da damar yin wani `&Waker` wanda za a iya amfani da su a tashe yanzu aiki.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Tabbatar mana da future-hujja akan canje-canje masu banbanci ta hanyar tilasta rayuwar ta zama mara ƙarfi (rayuwar mahawara ba ta sabawa yayin rayuwar masu komawa baya masu canzawa).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Ƙirƙirar sabon `Context` daga `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Koma wani tunani da `Waker` ga halin yanzu aiki.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` shine rike don farka aiki ta hanyar sanar da mai zartarwa cewa a shirye yake don gudanar da shi.
///
/// Wannan rikewar ta kunshi misalan [`RawWaker`], wanda ke bayyana halin farkawa na mai aiwatarwa.
///
///
/// Yana aiwatar da [`Clone`], [`Send`], da [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Wake up da aiki hade da wannan `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Ana kiran ainihin kiran farkawa ta hanyar kiran aiki na kama-da-wane don aiwatarwa wanda mai aiwatarwa ya bayyana.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Karka kira `drop`-`wake` ne zai cinye mai farke.
        crate::mem::forget(self);

        // KYAUTA: Wannan amintacce ne saboda `Waker::from_raw` ne kaɗai hanyar
        // to initialize `wake` da `data` bukata da mai amfani to amince da cewa kwangila na `RawWaker` aka tsayar.
        //
        unsafe { (wake)(data) };
    }

    /// Tashi aikin da ke hade da wannan `Waker` ba tare da cinye `Waker` ba.
    ///
    /// Wannan yayi kama da `wake`, amma yana iya zama ba shi da inganci kaɗan a cikin yanayin inda aka sami mallakar `Waker`.
    /// Wannan hanyar ya kamata a fifita shi wajen kiran `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Ana kiran ainihin kiran farkawa ta hanyar kiran aiki na kama-da-wane don aiwatarwa wanda mai aiwatarwa ya bayyana.
        //

        // KIYAYEWAR: gani `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Ya dawo `true` idan wannan `Waker` da wani `Waker` sun farka aiki iri ɗaya.
    ///
    /// Wannan aikin yana aiki akan mafi kyawun ƙoƙari, kuma yana iya dawowa karya koda lokacin da Waker ɗin zai farka aiki ɗaya.
    /// Koyaya, idan wannan aikin ya dawo `true`, ana tabbatar da cewa Waker's zai farka aikin daya.
    ///
    /// Ana amfani da wannan aikin da farko don dalilan ingantawa.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Irƙiri sabon `Waker` daga [`RawWaker`].
    ///
    /// The hali na koma `Waker` ne maras bayyani idan kwangilarsa a tsare a cikin [`RawWaker`] 's da kuma [`RawWakerVTable`]' s takardun da aka ba tsayar.
    ///
    /// Saboda haka wannan hanyar ba ta da aminci.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // KYAUTA: Wannan amintacce ne saboda `Waker::from_raw` ne kaɗai hanyar
            // don fara `clone` da `data` da ke buƙatar mai amfani ya yarda cewa kwangilar [`RawWaker`] ana kiyaye ta.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // KYAUTA: Wannan amintacce ne saboda `Waker::from_raw` ne kaɗai hanyar
        // to initialize `drop` da `data` bukata da mai amfani to amince da cewa kwangila na `RawWaker` aka tsayar.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}