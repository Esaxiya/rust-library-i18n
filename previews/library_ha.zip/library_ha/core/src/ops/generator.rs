use crate::marker::Unpin;
use crate::pin::Pin;

/// Sakamakon dawo da janareta.
///
/// Wannan enum an dawo dashi daga hanyar `Generator::resume` kuma yana nuna yuwuwar dawowar darajar janareto.
/// A halin yanzu wannan yana dacewa da ko maɓallin dakatarwa (`Yielded`) ko ma'anar ƙarshe (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// A janareta dakatar da darajar.
    ///
    /// Wannan jihar tana nuna cewa an dakatar da janareto, kuma yawanci yayi daidai da bayanin `yield`.
    /// Theimar da aka bayar a cikin wannan bambancin yayi daidai da bayanin da aka wuce zuwa `yield` kuma yana ba da damar janaretoci su samar da ƙima a duk lokacin da suka bayar.
    ///
    ///
    Yielded(Y),

    /// An gama janareto da darajar dawowa.
    ///
    /// Wannan jihar tana nuna cewa janareto ya gama aiwatarwa tare da ƙimar da aka bayar.
    /// Da zarar janareto ya dawo `Complete` ana ɗauka kuskuren mai shirye-shirye don sake kiran `resume`.
    ///
    Complete(R),
}

/// trait an aiwatar dashi ta hanyar ginannun nau'ikan janareta.
///
/// Janareto, wanda galibi ake kira da coroutines, a halin yanzu fasalin harshen gwaji ne a cikin Rust.
/// Ara a cikin masu samar da wutar lantarki na [RFC 2033] a halin yanzu ana nufin su samar da tubalin gini don haɗin async/await amma zai yiwu ya faɗaɗa har ila yau don samar da ma'anar ergonomic ga masu karɓa da sauran abubuwan farko.
///
///
/// Tsarin tsari da ma'anar ma'anar janareto bashi da karko kuma zai buƙaci ƙarin RFC don daidaitawa.A wannan lokacin, kodayake, ginin kalma cikakke ne:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Ana iya samun ƙarin takaddun janareto a cikin littafin mara ƙarfi.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Nau'in darajar wannan janareta ke samarwa.
    ///
    /// Wannan nau'in haɗin yana dacewa da bayanin `yield` da ƙimomin da aka ba da izinin mayar da su duk lokacin da janareta ya samar.
    ///
    /// Misali mai bada labari-as-a-a-generator zai iya samun irin wannan azaman `T`, ana yin amfani da nau'ikan aiki dashi.
    ///
    type Yield;

    /// Nau'in darajar wannan janareta ya dawo.
    ///
    /// Wannan ya dace da nau'in da aka dawo daga janareta ko dai tare da bayanin `return` ko a bayyane azaman magana ta ƙarshe ta janareta a zahiri.
    /// Misali futures zai yi amfani da wannan azaman `Result<T, E>` saboda yana wakiltar future da aka kammala.
    ///
    ///
    type Return;

    /// Ya ci gaba da aiwatar da wannan janareta.
    ///
    /// Wannan aikin zai ci gaba da aiwatar da aikin janareta ko fara aiwatarwa idan bai riga ya aikata ba.
    /// Wannan kira zai koma baya a cikin janareta ta karshe dakatar batu, komawarsu kisa daga latest `yield`.
    /// Generator zai ci gaba da aiwatarwa har sai ya samar ko ya dawo, a wannan lokacin ne wannan aikin zai dawo.
    ///
    /// # Komawa darajar
    ///
    /// `GeneratorState` enum da aka dawo daga wannan aikin yana nuna yadda yanayin janareta yake cikin dawowa.
    /// Idan an dawo da bambancin `Yielded` to janareto ya isa wurin dakatarwa kuma an fitar da ƙimar.
    /// Akwai janareto a cikin wannan jihar don sake dawowa a gaba.
    ///
    /// Idan `Complete` ya dawo to janareto ya gama da kimar da aka bayar.Ba daidai ba ne don a sake ci gaba da janareto.
    ///
    /// # Panics
    ///
    /// Wannan aikin na iya panic idan aka kira shi bayan an dawo da bambancin `Complete` a baya.
    /// Yayinda adana janareto a cikin yaren suka tabbata ga panic akan sake dawowa bayan `Complete`, wannan ba tabbas bane ga duk aiwatarwar `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}