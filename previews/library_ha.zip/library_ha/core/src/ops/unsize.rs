use crate::marker::Unsize;

/// Trait wanda ke nuna cewa wannan alama ce ko kuma abin nadewa ne na daya, inda za'a iya yin kwanciya akan mai nuna alamar.
///
/// Duba [DST coercion RFC][dst-coerce] da [the nomicon entry on coercion][nomicon-coerce] don ƙarin bayani.
///
/// Ga nau'ikan nuna alama na ciki, masu nuna alama zuwa `T` zasu tilasta masu nuni zuwa `U` idan `T: Unsize<U>` ta hanyar canzawa daga matsakaicin mai nunawa zuwa mai nuna mai mai.
///
/// Don nau'ikan al'ada, tilastawa anan yana aiki ta tilasta `Foo<T>` zuwa `Foo<U>` wanda aka samar da tasirin `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Irin wannan impl za a iya rubuta shi ne kawai idan `Foo<T>` yana da filin da ba na Phantomdata guda ɗaya wanda ya haɗa da `T` ba.
/// Idan nau'in wannan filin shine `Bar<T>`, aiwatar da `CoerceUnsized<Bar<U>> for Bar<T>` dole ne ya wanzu.
/// Tursasawa za ta yi aiki ta hanyar tilasta filin `Bar<T>` a cikin `Bar<U>` da kuma cike sauran filayen daga `Foo<T>` don ƙirƙirar `Foo<U>`.
/// Wannan zai yi tasiri sosai har zuwa filin nunawa da tilasta hakan.
///
/// Gabaɗaya, don alamomin wayo zaku aiwatar da `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, tare da zaɓi `?Sized` ɗaure akan `T` kanta.
/// Don nau'ikan lulluɓi waɗanda kai tsaye suke saka `T` kamar `Cell<T>` da `RefCell<T>`, kuna iya aiwatar da `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` kai tsaye.
///
/// Wannan zai bar tilastawa iri-iri kamar `Cell<Box<T>>` suyi aiki.
///
/// [`Unsize`][unsize] ana amfani dashi don yin alama iri wanda za'a iya tilasta shi zuwa DSTs idan yana bayan bayanan.Ana aiwatar da shi ta atomatik ta mai tarawa.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ana amfani da wannan don amincin abu, don bincika cewa ana iya aika nau'in mai karɓar hanyar.
///
/// Misali aiwatar da trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}