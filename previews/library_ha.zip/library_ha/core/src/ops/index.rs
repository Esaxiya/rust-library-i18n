/// An yi amfani dashi don ayyukan sarrafawa (`container[index]`) a cikin mahalli mara canzawa.
///
/// `container[index]` shine ainihin sananniyar sukari don `*container.index(index)`, amma kawai lokacin amfani dashi azaman ƙimar da baya canzawa.
/// Idan ana neman ƙimar maye gurbi, ana amfani da [`IndexMut`] maimakon.
/// Wannan yana ba da kyawawan abubuwa kamar `let value = v[index]` idan nau'in `value` ya aiwatar da [`Copy`].
///
/// # Examples
///
/// Misali na gaba yana aiwatar da `Index` akan akwatin `NucleotideCount` mai karantawa kawai, yana ba da damar ƙididdigar mutum don dawo da shi tare da rubutun nuni.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Nau'in da aka dawo bayan yin nuni.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Yayi aikin nunawa na (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// An yi amfani dashi don ayyukan sarrafawa (`container[index]`) a cikin abubuwan da za'a iya canzawa.
///
/// `container[index]` shine ainihin sukari na roba don `*container.index_mut(index)`, amma kawai lokacin amfani dashi azaman ƙimar canzawa.
/// Idan ana neman ƙimar da ba za a iya canzawa ba, ana amfani da [`Index`] trait maimakon.
/// Wannan yana ba da kyawawan abubuwa kamar `v[index] = value`.
///
/// # Examples
///
/// Mai sauƙin aiwatarwa na tsarin `Balance` wanda ke da ɓangarori biyu, inda kowannensu zai iya yin daidaito da daidaituwa.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // A wannan halin, `balance[Side::Right]` sukari ne na `*balance.index(Side::Right)`, tunda kawai muna karantawa*`balance[Side::Right]`, ba rubuta shi ba.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Koyaya, a wannan yanayin `balance[Side::Left]` sukari ne na `*balance.index_mut(Side::Left)`, tunda muna rubuta `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Yayi aikin (`container[index]`) mai canza fasalin canji.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}