/// Siffar mai aikin kira wanda ke karɓar mai karɓa mara canzawa.
///
/// Za a iya kiran lokuta na `Fn` akai-akai ba tare da canza yanayin ba.
///
/// *Wannan trait (`Fn`) bai kamata a rikita shi da [function pointers] (`fn`) ba.*
///
/// `Fn` ana aiwatar da shi ta atomatik ta hanyar rufewa wanda kawai yake ɗaukar nassoshi mara canzawa ga masu canji da aka kama ko kar su kama komai kwata-kwata, da kuma (safe) [function pointers] (tare da wasu kofofin, duba takaddun su don ƙarin bayani).
///
/// Bugu da ƙari, ga kowane nau'in `F` wanda ke aiwatar da `Fn`, `&F` yana aiwatar da `Fn`, suma.
///
/// Tunda duka [`FnMut`] da [`FnOnce`] sune supertraits na `Fn`, kowane misali na `Fn` za'a iya amfani dashi azaman ma'auni inda ake tsammanin [`FnMut`] ko [`FnOnce`].
///
/// Yi amfani da `Fn` azaman ɗaure lokacin da kake son karɓar ma'auni na nau'in aiki kuma kana buƙatar kiran shi akai-akai kuma ba tare da canza yanayin ba (misali, yayin kiran shi a lokaci ɗaya).
/// Idan ba kwa buƙatar irin waɗannan ƙa'idodi masu ƙarfi, yi amfani da [`FnMut`] ko [`FnOnce`] azaman iyaka.
///
/// Duba [chapter on closures in *The Rust Programming Language*][book] don ƙarin bayani game da wannan batun.
///
/// Har ila yau, bayanin kula shine keɓaɓɓiyar tsari don `Fn` traits (misali
/// `Fn(usize, bool) -> amfani ').Wadanda ke da sha'awar bayanan fasaha na wannan na iya komawa zuwa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kiran rufewa
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Amfani da ma'aunin `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ta yadda regex zai iya dogaro da `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Yayi aikin kira.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Siffar mai ba da sabis ɗin kira wanda ke karɓar mai karɓar sauyawa.
///
/// Za a iya kiran lokuta na `FnMut` akai-akai kuma yana iya canza yanayin.
///
/// `FnMut` ana aiwatar da shi ta atomatik ta hanyar rufewa wanda ke ɗaukar nassoshi masu canzawa zuwa masu canjin da aka kama, da kuma duk nau'ikan da suke aiwatar da [`Fn`], misali, (safe) [function pointers] (tunda `FnMut` babban hoto ne na [`Fn`]).
/// Bugu da ƙari, ga kowane nau'in `F` wanda ke aiwatar da `FnMut`, `&mut F` yana aiwatar da `FnMut`, suma.
///
/// Tunda [`FnOnce`] babban hoto ne na `FnMut`, ana iya amfani da kowane misali na `FnMut` inda ake tsammanin [`FnOnce`], kuma tunda [`Fn`] ƙananan sub ne na `FnMut`, ana iya amfani da kowane misali na [`Fn`] inda ake tsammanin `FnMut`.
///
/// Yi amfani da `FnMut` azaman ɗaure lokacin da kake son karɓar ma'auni na nau'in aiki kuma kuna buƙatar kiran shi akai-akai, yayin ba shi damar sauya yanayin.
/// Idan ba kwa son saitin ya canza yanayin, yi amfani da [`Fn`] azaman ɗaure;idan baku buƙatar kiran shi akai-akai, yi amfani da [`FnOnce`].
///
/// Duba [chapter on closures in *The Rust Programming Language*][book] don ƙarin bayani game da wannan batun.
///
/// Har ila yau, bayanin kula shine keɓaɓɓiyar tsari don `Fn` traits (misali
/// `Fn(usize, bool) -> amfani ').Wadanda ke da sha'awar bayanan fasaha na wannan na iya komawa zuwa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kira mai kamawa rufewa
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Amfani da ma'aunin `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ta yadda regex zai iya dogaro da `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Yayi aikin kira.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Sigar mai aikin kira wanda ke karɓar mai karɓar ƙima.
///
/// Ana iya kiran lokuta na `FnOnce`, amma maiyuwa ba zai yuwu ba sau da yawa.Saboda wannan, idan kawai abin da aka sani game da nau'in shi ne cewa yana aiwatar da `FnOnce`, ana iya kiran shi sau ɗaya kawai.
///
/// `FnOnce` ana aiwatar da shi ta atomatik ta hanyar rufewa wanda zai iya cinye masu canjin da aka kama, da kuma duk nau'ikan da suke aiwatar da [`FnMut`], misali, (safe) [function pointers] (tunda `FnOnce` babban hoto ne na [`FnMut`]).
///
///
/// Tunda duka [`Fn`] da [`FnMut`] subtraits ne na `FnOnce`, ana iya amfani da kowane misali na [`Fn`] ko [`FnMut`] inda ake tsammanin `FnOnce`.
///
/// Yi amfani da `FnOnce` azaman ɗaure lokacin da kake son karɓar ma'auni na nau'in aiki kuma kawai kuna buƙatar kiran shi sau ɗaya.
/// Idan kana buƙatar kiran saiti akai-akai, yi amfani da [`FnMut`] azaman ɗaure;idan kuma kuna buƙatar shi don kar ya canza yanayin, yi amfani da [`Fn`].
///
/// Duba [chapter on closures in *The Rust Programming Language*][book] don ƙarin bayani game da wannan batun.
///
/// Har ila yau, bayanin kula shine keɓaɓɓiyar tsari don `Fn` traits (misali
/// `Fn(usize, bool) -> amfani ').Wadanda ke da sha'awar bayanan fasaha na wannan na iya komawa zuwa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Amfani da ma'aunin `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` cinye abubuwan canji da aka kama, saboda haka baza'a iya gudanar dashi fiye da sau daya ba.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Oƙarin sake kiran `func()` zai sake jefa kuskuren `use of moved value` na `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ba za a iya kiran sa ba a wannan lokacin
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ta yadda regex zai iya dogaro da `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Nau'in da aka dawo dashi bayan anyi amfani da afaretan kira.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Yayi aikin kira.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}