/// Lambar al'ada a cikin mai lalatawa.
///
/// Lokacin da ba'a ƙara buƙatar ƙima ba, Rust zai gudanar da "destructor" akan wannan ƙimar.
/// Hanya mafi yawan gaske da ba'a buƙata ƙimar ita ce lokacin da ta wuce gona da iri.Har ila yau, masu lalata abubuwa na iya gudana a cikin wasu yanayi, amma za mu mai da hankali kan iyaka ga misalai a nan.
/// Don koyo game da wasu waɗancan shari'o'in, da fatan za a duba sashin [the reference] akan masu lalatawa.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Wannan mai halakarwar ya kunshi abubuwa biyu:
/// - Kira ga `Drop::drop` don wannan ƙimar, idan an aiwatar da wannan `Drop` trait na musamman don nau'in sa.
/// - "drop glue" da aka kirkira ta atomatik wanda ke sake kira ga masu lalata dukkanin fannoni na wannan ƙimar.
///
/// Kamar yadda Rust ya kira ta atomatik masu lalata dukkanin filayen da ke ƙunshe, ba lallai bane ku aiwatar da `Drop` a mafi yawan lokuta.
/// Amma akwai wasu lokuta inda yake da amfani, misali ga nau'ikan da ke sarrafa albarkatun kai tsaye.
/// Wannan kayan aikin na iya zama ƙwaƙwalwa, yana iya zama mai bayanin fayil, yana iya zama soket na cibiyar sadarwa.
/// Da zarar ba za a ƙara amfani da ƙimar wannan nau'in ba, ya kamata "clean up" albarkatu ta hanyar 'yantar da ƙwaƙwalwar ko rufe fayil ɗin ko soket.
/// Wannan aikin mai lalata ne, sabili da haka aikin `Drop::drop`.
///
/// ## Examples
///
/// Don ganin masu lalata abubuwa suna aiki, bari muyi la'akari da shirin mai zuwa:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust zai fara kiran `Drop::drop` don `_x` sannan kuma don duka `_x.one` da `_x.two`, ma'ana gudanar da wannan zai buga
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Koda mun cire aiwatar da `Drop` don `HasTwoDrop`, ana kiran masu lalata lamuran ta.
/// Wannan zai haifar da
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ba za ku iya kiran `Drop::drop` da kanku ba
///
/// Saboda ana amfani da `Drop::drop` don tsaftace ƙima, yana iya zama haɗari a yi amfani da wannan ƙimar bayan an kira hanyar.
/// Kamar yadda `Drop::drop` baya ɗaukar ikon shigarwar sa, Rust yana hana amfani mara kyau ta hanyar ba ku damar kiran `Drop::drop` kai tsaye.
///
/// Watau, idan kunyi ƙoƙari ku kira `Drop::drop` a bayyane a cikin misalin da ke sama, kuna da kuskuren tarawa.
///
/// Idan kuna son bayyane ya lalata mai ƙima, za a iya amfani da [`mem::drop`] maimakon.
///
/// [`mem::drop`]: drop
///
/// ## Sauke oda
///
/// Wanne ne daga cikin `HasDrop` ɗinmu guda biyu da farko, kodayake?Don motsawa, tsari iri ɗaya ne wanda aka ayyana: na farko `one`, sannan `two`.
/// Idan kanaso ka gwada wannan da kanka, zaka iya canza `HasDrop` da ke sama dan dauke wasu bayanai, kamar lamba, sannan kayi amfani da shi a cikin `println!` din na `Drop`.
/// Wannan halayyar yare ce ta tabbatar dashi.
///
/// Ba kamar don motsa jiki ba, ana jefa masu canji na gida a cikin tsari na baya:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Wannan zai buga
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Da fatan za a duba [the reference] don cikakkun dokoki.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` kuma `Drop` suna keɓance
///
/// Ba za ku iya aiwatar da [`Copy`] da `Drop` a kan nau'in ɗaya ba.Nau'o'in da suke `Copy` ana samun su sosai a mahaɗa, wanda ya sa ya zama da wahalar hango ko yaushe, da kuma yadda sau da yawa za a kashe su.
///
/// Saboda haka, waɗannan nau'ikan ba za su iya samun masu lalata su ba.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Kashe mai halakarwa don wannan nau'in.
    ///
    /// Ana kiran wannan hanyar a fakaice lokacin da ƙimar ta wuce gona da iri, kuma ba za a iya kiran sa a sarari (wannan kuskuren mai tarawa ne [E0040]).
    /// Koyaya, ana iya amfani da aikin [`mem::drop`] a cikin prelude don kiran huɗar aiwatarwar `Drop`.
    ///
    /// Lokacin da aka kira wannan hanyar, `self` ba a sake rarraba shi ba.
    /// Wannan yana faruwa ne kawai bayan hanyar ta ƙare.
    /// Idan wannan ba haka bane, `self` zai zama abin dogara ne kawai.
    ///
    /// # Panics
    ///
    /// Ganin cewa [`panic!`] zai kira `drop` yayin da yake kwance, kowane [`panic!`] a cikin aiwatarwar `drop` zai iya zubar da ciki.
    ///
    /// Lura cewa koda wannan panics, ana ɗaukar ƙimar da za a sauke;
    /// dole ne ka sake sanya `drop`.
    /// Ana sarrafa wannan ta atomatik ta mai tarawa, amma yayin amfani da lambar da ba amintacciya ba, wani lokacin na iya faruwa ba da gangan ba, musamman lokacin amfani da [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}