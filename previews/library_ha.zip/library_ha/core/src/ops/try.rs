/// A trait don keɓance halayyar mai aiki na `?`.
///
/// Nau'in aiwatar da `Try` shine wanda ke da hanyar canonical don duba shi dangane da yanayin hoto na success/failure.
/// Wannan trait yana ba da damar fitar da waɗancan nasarar ko ƙimar gazawa daga misalin da ke ciki da ƙirƙirar sabon misali daga darajar nasara ko rashin nasara.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Nau'in wannan ƙimar idan aka kalleta kamar mai nasara.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Nau'in wannan ƙimar yayin da aka kalle ta ba ta yi nasara ba.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Yana amfani da mai ba da sabis na "?".Dawowar `Ok(t)` yana nufin cewa aiwatarwa yakamata yaci gaba da dacewa, kuma sakamakon `?` shine darajar `t`.
    /// Dawowar `Err(e)` na nufin cewa aiwatarwa yakamata branch ya kasance zuwa cikin `catch` da ke kewaye, ko dawowa daga aikin.
    ///
    /// Idan an dawo da sakamako na `Err(e)`, darajar `e` zata kasance "wrapped" a cikin nau'in dawowa na ƙirar kewaye (wanda dole ne kansa aiwatar da `Try`).
    ///
    /// Musamman, an dawo da darajar `X::from_error(From::from(e))`, inda `X` shine nau'in dawowa na aikin kewayewa.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Kunsa ƙimar kuskure don gina sakamakon haɗin.
    /// Misali, `Result::Err(x)` da `Result::from_error(x)` daidai suke.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Kunsa ƙimar OK don ƙirƙirar sakamakon haɗin.
    /// Misali, `Result::Ok(x)` da `Result::from_ok(x)` daidai suke.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}