//! Masu aiki da yawa
//!
//! Aiwatar da waɗannan traits yana ba ku damar yin obalodi da wasu masu aiki.
//!
//! Wasu daga waɗannan traits ana shigo dasu ta hanyar prelude, saboda haka ana samun su a kowane shirin Rust.Masu aiki kawai da traits ke tallafawa za a iya yin lodi.
//! Misali, ana iya shigar da mai kara (`+`) ta hanyar [`Add`] trait, amma tunda mai ba da aikin (`=`) ba shi da goyan bayan trait, babu yadda za a yi lodi da ma'anoninsa.
//! Ari, wannan kundin ba ya samar da wata hanyar don ƙirƙirar sabbin masu aiki.
//! Idan ana buƙatar ɗaukar nauyi ko masu aiki na al'ada, ya kamata ku duba zuwa macros ko masu tara abubuwa don ƙara haɗin ginin Rust.
//!
//! Aiwatar da ayyukan mai aiki traits ya zama ba abin al'ajabi ba a cikin mahallin su, la'akari da ma'anonin da suka saba da [operator precedence].
//! Misali, yayin aiwatar da [`Mul`], aikin yakamata ya zama yana da kamanni iri biyu (kuma raba abubuwan da ake tsammani kamar haɗin kai).
//!
//! Lura cewa masu aikin `&&` da `||` masu gajeren gajere, ma'ana, suna kimanta operand na biyu ne kawai idan ya bada gudummawa ga sakamakon.Tunda wannan dabi'a ba ta hanyar traits, `&&` da `||` ba a tallafawa su azaman masu aiki da yawa.
//!
//! Yawancin masu aiki suna ɗaukar ayyukansu da daraja.A ba-Generic riƙa shafe gina-in-daban, wannan ne yawanci ba matsala.
//! Koyaya, amfani da waɗannan masu aiki a cikin jumlar lambar, yana buƙatar kulawa idan za'a sake amfani da ƙimomin akasin barin masu aiki su cinye su.Wani zaɓi shine lokaci-lokaci amfani da [`clone`].
//! Wani zaɓi shine dogaro da nau'ikan da ke ƙunshe da samar da ƙarin aiwatarwar afareto don nassoshi.
//! Misali, don mai amfani da nau'in `T` wanda yakamata ya goyi bayan ƙari, yana yiwuwa mai kyau ne a sami duka `T` da `&T` su aiwatar da traits [`Add<T>`][`Add`] da [`Add<&T>`][`Add`] don a iya rubuta lambar jaka ba tare da ɗorawa ba.
//!
//!
//! # Examples
//!
//! Wannan misalin yana haifar da tsarin `Point` wanda ke aiwatar da [`Add`] da [`Sub`], sannan kuma yana nuna ƙara da ragin ``Point`s biyu.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Duba takardu don kowane trait don misali aiwatarwa.
//!
//! [`Fn`], [`FnMut`], da [`FnOnce`] traits ana aiwatar dasu ta nau'ikan da za'a iya kiransu kamar ayyuka.Lura cewa [`Fn`] ya ɗauki `&self`, [`FnMut`] ya ɗauki `&mut self` kuma [`FnOnce`] ya ɗauki `self`.
//! Waɗannan sun dace da nau'ikan hanyoyi guda uku waɗanda za a iya kira a kan misali: kira-da-tunani, kira-da-mutable-tunani, da kira-da-darajar.
//! Amfani mafi mahimmanci na waɗannan traits shine yin aiki a matsayin iyakoki zuwa manyan ayyuka waɗanda ke ɗaukar ayyuka ko rufewa azaman mahawara.
//!
//! Shan [`Fn`] azaman ma'auni:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Shan [`FnMut`] azaman ma'auni:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Shan [`FnOnce`] azaman ma'auni:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` cinye abubuwan canji da aka kama, saboda haka baza'a iya gudanar dashi fiye da sau daya ba
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Oƙarin sake kiran `func()` zai sake jefa kuskuren `use of moved value` na `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ba za a iya kiran sa ba a wannan lokacin
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;