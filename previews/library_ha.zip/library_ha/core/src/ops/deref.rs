/// An yi amfani dashi don ayyukan sake fasalin canzawa, kamar `*v`.
///
/// Toari da amfani da shi don ayyukan ɓoyewa tare da mai ba da sabis na (unary) `*` a cikin abubuwan da ba za su iya canzawa ba, ana amfani da `Deref` a bayyane ta hanyar mai tarawa a cikin yanayi da yawa.
/// Ana kiran wannan inji ['`Deref` coercion'][more].
/// A cikin abubuwan da za'a iya canzawa, ana amfani da [`DerefMut`].
///
/// Aiwatar da `Deref` don masu nuni mai kaifin baki yana sanya samun damar bayanan da ke bayan su ya dace, wanda shine dalilin da yasa suke aiwatar da `Deref`.
/// A gefe guda, an tsara dokoki game da `Deref` da [`DerefMut`] musamman don sauƙaƙe masu ma'ana.
/// Saboda wannan,**``Deref` ya kamata a aiwatar dashi kawai don masu nunin hankali** don kaucewa rikicewa.
///
/// Saboda dalilai irin wannan,**wannan trait bazai taba faduwa ba**.Rashin yin aiki yayin rubuta abubuwa na iya zama mai rikita rikice lokacin da aka kira `Deref` a fakaice.
///
/// # Ari kan tilastawa `Deref`
///
/// Idan `T` ya aiwatar da `Deref<Target = U>`, kuma `x` yana da darajar nau'in `T`, to:
///
/// * A cikin ma'anoni marasa canzawa, `*x` (inda `T` ba ma'ana ba ce ko ma'anar ɗan alama) daidai yake da `* Deref::deref(&x)`.
/// * Imar nau'in `&T` ana tilasta ta zuwa ƙimar nau'in `&U`
/// * `T` a fakaice yana aiwatar da duk hanyoyin (immutable) na nau'in `U`.
///
/// Don ƙarin cikakkun bayanai, ziyarci [the chapter in *The Rust Programming Language*][book] harma da sassan tunani akan [the dereference operator][ref-deref-op], [method resolution] da [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Tsarin tare da filin guda ɗaya wanda ke da damar ta hanyar ƙaddamar da tsarin.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Nau'in da aka samu bayan rubutawa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferences da darajar.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// An yi amfani dashi don ayyukan ƙaddamar da ƙaddamarwa, kamar a cikin `*v = 1;`.
///
/// Toari da amfani da shi don ayyukan ɓoyewa tare da mai ba da sabis na (unary) `*` a cikin abubuwan da ke canzawa, `DerefMut` ana amfani da shi gaba ɗaya ta mai tarawa a cikin yanayi da yawa.
/// Ana kiran wannan inji ['`Deref` coercion'][more].
/// A cikin mahalli mara canzawa, ana amfani da [`Deref`].
///
/// Aiwatar da `DerefMut` don alamomi masu mahimmanci yana sanya sauya bayanan da ke bayan su ya dace, wanda shine dalilin da yasa suke aiwatar da `DerefMut`.
/// A gefe guda, an tsara dokoki game da [`Deref`] da `DerefMut` musamman don sauƙaƙe masu ma'ana.
/// Saboda wannan,**``DerefMut` ya kamata a aiwatar dashi kawai don masu nunin hankali** don kaucewa rikicewa.
///
/// Saboda dalilai irin wannan,**wannan trait bazai taba faduwa ba**.Rashin yin aiki yayin rubuta bayanan na iya zama mai rikitarwa yayin da aka kira `DerefMut` a fakaice.
///
/// # Ari kan tilastawa `Deref`
///
/// Idan `T` ya aiwatar da `DerefMut<Target = U>`, kuma `x` yana da darajar nau'in `T`, to:
///
/// * A cikin abubuwan da za'a iya canzawa, `*x` (inda `T` ba ma'ana ba ce ko ma'anar ɗan alama) daidai yake da `* DerefMut::deref_mut(&mut x)`.
/// * Imar nau'in `&mut T` ana tilasta ta zuwa ƙimar nau'in `&mut U`
/// * `T` a fakaice yana aiwatar da duk hanyoyin (mutable) na nau'in `U`.
///
/// Don ƙarin cikakkun bayanai, ziyarci [the chapter in *The Rust Programming Language*][book] harma da sassan tunani akan [the dereference operator][ref-deref-op], [method resolution] da [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Tsarin tare da filin guda ɗaya wanda za'a iya canza shi ta hanyar ƙaddamar da tsarin.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Ablyididdigar ƙaddamar da ƙimar.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Yana nuna cewa ana iya amfani da tsarin azaman mai karɓar hanya, ba tare da fasalin `arbitrary_self_types` ba.
///
/// Ana aiwatar da wannan ta nau'ikan alamun stdlib kamar `Box<T>`, `Rc<T>`, `&T`, da `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}