use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A wrapper irin su yi uninitialized lokutta na `T`.
///
/// # initialization maras canjawa
///
/// A tarawa, in general, kwakwalwa gaba da cewa wani m da aka yadda ya kamata initialized bisa ga bukatun na m ta irin.Alal misali, a m na reference irin dole ne a hada kai da wadanda ba null.
/// Wannan shi ne wani maras canjawa cewa dole ne *ko da yaushe* a tsayar, ko da a unsafe code.
/// Sakamakon haka, ƙaddamar da wani nau'ikan nau'ikan tunani yana haifar da [undefined behavior][ub] nan take, ba tare da la'akari da ko ana amfani da wannan bayanin don samun damar ƙwaƙwalwar ba:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // maras bayyani hali!⚠️
/// // The m code tare da `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // maras bayyani hali!⚠️
/// ```
///
/// Wannan ne maida su ba kome da mai tarawa domin daban-daban optimizations, kamar eliding gudu-lokaci cak kuma optimizing `enum` layout.
///
/// Hakazalika, gaba ɗaya uninitialized memory iya samun kowane abun ciki, yayin da wani `bool` dole ne ko da yaushe a `true` ko `false`.Saboda haka, ƙirƙirar `bool` mara wayewa ba halayya ce mara ma'ana:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // maras bayyani hali!⚠️
/// // Lambar daidai da `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // maras bayyani hali!⚠️
/// ```
///
/// Bugu da ƙari, ƙwaƙwalwar da ba a san ta ba ta musamman saboda ba ta da tsayayyen ƙima ("fixed" ma'ana "it won't change without being written to").Karanta wannan uninitialized byte mahara sau iya ba daban-daban sakamakon.
/// Wannan ya sa shi maras bayyani hali da uninitialized data a wani m har idan cewa m yana da wani lamba type, wanda in ba haka ba za su iya rike kowane *gyarawa* bit juna:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // maras bayyani hali!⚠️
/// // The m code tare da `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // maras bayyani hali!⚠️
/// ```
/// (Ka lura cewa dokokin kusa uninitialized integers ba cimma matsaya ba, amma har suna, shi ne bu mai kyau don kauce wa su.)
///
/// A saman wannan, ka tuna cewa yawancin nau'ikan suna da ƙarin masu haɗari fiye da yadda ake la'akari da farawa a matakin nau'in.
/// Alal misali, a `1`-initialized [`Vec<T>`] aka dauke initialized (a karkashin halin yanzu aiwatar; wannan bai dokoki a barga tabbacin) saboda kawai ake bukata da mai tarawa sani game da shi shi ne cewa data akan dole ba null.
/// Samar da irin wannan `Vec<T>` ba dalili *nan da nan* maras bayyani hali, amma zai sa maras bayyani hali tare da mafi hadari ayyukan (ciki har da faduwa da shi).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` da hidima ga ba dama unsafe code to magance uninitialized data.
/// Alamar ishara ce ga mai harhaɗawa da ke nuna cewa bayanan da ke nan mai yiwuwa ba * za a fara su ba:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Create an baro-baro uninitialized tunani.
/// // Mai tattarawa ya san cewa bayanai a cikin `MaybeUninit<T>` na iya zama marasa inganci, saboda haka wannan ba UB bane:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Saita shi zuwa mai aiki darajar.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Cire bayanan da aka fara-wannan ana ba da izinin *bayan* fara ƙaddamar da `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// A tarawa sa'an nan ya sani to ba zai yi wani ba daidai ba zato ko optimizations a kan wannan code.
///
/// Za ka iya tunanin `MaybeUninit<T>` matsayin kasancewa a bit kamar `Option<T>` amma ba tare da wani daga cikin gudu-lokaci tracking kuma ba tare da wani daga cikin aminci cak.
///
/// ## out-pointers
///
/// Za ka iya amfani da `MaybeUninit<T>` da su aiwatar da "out-pointers": maimakon dawo data daga wani aiki, wuce da shi a mauni zuwa wasu (uninitialized) memory to sa sakamakon cikin.
/// Wannan zai iya zama da amfani a lokacin da yana da muhimmanci ga mai kira zuwa ga kula da yadda ƙwaƙwalwar sakamakon da aka adana a samun kasaftawa, kuma kana so ka kauce wa ba dole ba motsa.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` baya sauke tsohon abinda ke ciki, wanda yake da mahimmanci.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Yanzu mun san `v` aka initialized!Wannan ma ya sa tabbata da vector samun yadda ya kamata kika aika.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Ana soma wani tsararru kashi-da-kashi
///
/// `MaybeUninit<T>` za a iya amfani da su initialize babban tsararru kashi-da-kashi:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Createirƙiri tsararren tsararru na `MaybeUninit`.
///     // A `assume_init` da hadari saboda irin muka faxa don sun initialized nan ne wani gungu na `MaybeUninit`s, wanda ba ya bukatar initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Faduwa da `MaybeUninit` ba komai.
///     // Don haka amfani da ɗanyen aikin nuna alama maimakon `ptr::write` ba ya sa a sauke tsohuwar ƙimar da ba a san ta ba.
/////
///     // Hakanan idan akwai panic yayin wannan madauki, muna da zuƙowar ƙwaƙwalwa, amma babu batun amincin ƙwaƙwalwa.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Duk abin da aka initialized.
///     // Canja tsararru da initialized irin.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Zaka kuma iya aiki tare da partially initialized iri-iri, wanda za a iya samu a low-matakin datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Createirƙiri tsararren tsararru na `MaybeUninit`.
/// // A `assume_init` da hadari saboda irin muka faxa don sun initialized nan ne wani gungu na `MaybeUninit`s, wanda ba ya bukatar initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Idaya yawan abubuwan da muka sanya.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Domin kowane abu a cikin tsararru, sauke idan muka kasaftawa shi.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Alizingaddamar da tsarin tsari-ta-filin
///
/// Za ka iya amfani da `MaybeUninit<T>`, da kuma [`std::ptr::addr_of_mut`] Macro, to initialize structs filin da filin:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Alizingaddamar da filin `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ana soma da `list` filin Idan akwai wani panic a nan, sa'an nan da `String` a `name` filin leaks.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Duk da filayen suna initialized, don haka muka kira `assume_init` don samun wani initialized Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` yana da tabbacin samun girma iri ɗaya, daidaitawa, da ABI kamar `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Koyaya tuna cewa nau'in *dauke** `MaybeUninit<T>` ba lallai bane ya kasance shimfida ɗaya;Rust ya aikata ba in general tabbacin cewa filayen daga a `Foo<T>` da wannan tsari a matsayin `Foo<U>` ko idan `T` da `U` da wannan size da kuma jeri.
///
/// Bugu da ƙari, saboda wani bit darajar yana aiki ga wani `MaybeUninit<T>` da mai tarawa ba zai iya tambaya non-zero/niche-filling optimizations, yiwuwar sakamakon da ya fi girma size:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Idan `T` ne FFI-hadari, to, don haka ne `MaybeUninit<T>`.
///
/// Duk da yake `MaybeUninit` shine `#[repr(transparent)]` (yana nuna yana ba da tabbacin girman daidai, daidaitawa, da ABI a matsayin `T`), wannan bai *canza* kowane ɗayan bayanan da ya gabata ba.
/// `Option<T>` kuma `Option<MaybeUninit<T>>` iya har yanzu suna da daban-daban masu girma dabam, da kuma iri dauke da wani filin daga irin `T` iya dage farawa daga (da sized) daban fiye idan cewa filin sun `MaybeUninit<T>`.
/// `MaybeUninit` ne mai jam'iyya type, kuma `#[repr(transparent)]` a kan kungiya ta kashin ne m (ga [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// A tsawon lokaci, daidai da tabbacin na `#[repr(transparent)]` a kan kungiyoyin kwadago iya halittu farfadowa, kuma `MaybeUninit` iya ko ba zama `#[repr(transparent)]`.
/// Wannan ce, `MaybeUninit<T>` so *ko da yaushe* tabbacin cewa shi yana da guda size, jeri, kuma Abi kamar yadda `T`.dai kawai cewa hanyar `MaybeUninit` aiwatarwa cewa garanti iya tasowa.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang abu haka za mu iya kunsa da sauran iri a cikin shi.Wannan na da amfani domin janareto.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ba kiran `T::clone()` ba, ba za mu iya sani ba idan an ƙaddamar da mu kawai don hakan.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Halicci sabon `MaybeUninit<T>` initialized da ba darajar.
    /// Yana da wani hadari ga kiran [`assume_init`] a kan samu darajar da wannan aikin.
    ///
    /// Lura cewa faduwa wani `MaybeUninit<T>` ba zai taba kiran lambar digo na T` ba.
    /// Shi ne alhakin don tabbatar da `T` samun ragu idan ta samu initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Irƙiri sabon `MaybeUninit<T>` a cikin yanayin da ba a san shi ba.
    ///
    /// Lura cewa faduwa wani `MaybeUninit<T>` ba zai taba kiran lambar digo na T` ba.
    /// Shi ne alhakin don tabbatar da `T` samun ragu idan ta samu initialized.
    ///
    /// Duba [type-level documentation][MaybeUninit] don wasu misalai.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Irƙiri sabon tsari na abubuwa `MaybeUninit<T>`, a cikin yanayin rashin wayewa.
    ///
    /// Note: a cikin sigar future Rust wannan hanyar na iya zama ba dole ba yayin da daidaitaccen tsari ya ba [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// A misali a kasa iya sa'an nan kuma amfani `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Yana dawo da wani yanki (mai yuwuwa) na bayanan da aka karanta a zahiri
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // KIYAYEWAR: An uninitialized `[MaybeUninit<_>; LEN]` ne m.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Halicci sabon `MaybeUninit<T>` a wani uninitialized jihar, tare da ƙwaƙwalwar ya cika da `0` bytes.Ya dogara da `T` ko wannan ya riga ya zama don farawa mai kyau.
    ///
    /// Misali, `MaybeUninit<usize>::zeroed()` an fara shi, amma `MaybeUninit<&'static i32>::zeroed()` ba haka bane saboda nassoshi bazai zama fanko ba.
    ///
    /// Lura cewa faduwa wani `MaybeUninit<T>` ba zai taba kiran lambar digo na T` ba.
    /// Shi ne alhakin don tabbatar da `T` samun ragu idan ta samu initialized.
    ///
    /// # Example
    ///
    /// Daidai yadda ake amfani da wannan aikin: soma wani struct da sifili, inda dukkan filayen na struct iya rike da bit-juna 0 matsayin mai inganci darajar.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Mara daidai* amfani da wannan aikin: kiran `x.zeroed().assume_init()` lokacin `0` ba ingantaccen bit-juna domin type:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Tu da wani biyu, za mu ƙirƙirar `NotZero` cewa ba shi da wani inganci discriminant.
    /// // Wannan shi ne maras bayyani hali.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // KIYAYEWAR: `u.as_mut_ptr()` nuna kasaftawa ƙwaƙwalwar.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Buga tamanin da `MaybeUninit<T>`.
    /// Wannan yana sake share kowane ƙimar da ta gabata ba tare da faduwa ba, don haka yi hankali kar a yi amfani da wannan sau biyu sai dai idan kuna son tsallake aiki ga mai lalatawa.
    ///
    /// Don saukaka, wannan ma ya kõma mai mutable tunani da (yanzu a amince initialized) abinda ke ciki na `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // KYAUTA: Mun ƙaddamar da wannan ƙimar.
        unsafe { self.assume_init_mut() }
    }

    /// Auri akan zuwa dauke da darajar.
    /// Reading daga wannan akan ko juya shi a cikin wani zance ne maras bayyani hali har da `MaybeUninit<T>` aka initialized.
    /// Rubutu zuwa memory cewa wannan akan (non-transitively) maki to shi ne maras bayyani hali (sai cikin wani `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Daidai yadda ake amfani da wannan hanyar:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Createirƙirar tunani a cikin `MaybeUninit<T>`.Wannan ze saboda mun initialized shi.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Ba daidai ba* amfani da wannan hanyar:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Mun halitta tunani zuwa wani uninitialized vector!Wannan halayyar da ba a bayyana ta ba.⚠️
    /// ```
    ///
    /// (Ka lura cewa dokokin kusa nassoshi uninitialized data ba cimma matsaya ba, amma har suna, shi ne bu mai kyau don kauce wa su.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` kuma `ManuallyDrop` ne duka `repr(transparent)` haka za mu iya jefa mauni.
        self as *const _ as *const T
    }

    /// Auri mutable akan zuwa dauke da darajar.
    /// Reading daga wannan akan ko juya shi a cikin wani zance ne maras bayyani hali har da `MaybeUninit<T>` aka initialized.
    ///
    /// # Examples
    ///
    /// Daidai yadda ake amfani da wannan hanyar:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Createirƙirar tunani a cikin `MaybeUninit<Vec<u32>>`.
    /// // Wannan ze saboda mun initialized shi.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Ba daidai ba* amfani da wannan hanyar:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Mun halitta tunani zuwa wani uninitialized vector!Wannan halayyar da ba a bayyana ta ba.⚠️
    /// ```
    ///
    /// (Ka lura cewa dokokin kusa nassoshi uninitialized data ba cimma matsaya ba, amma har suna, shi ne bu mai kyau don kauce wa su.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` kuma `ManuallyDrop` ne duka `repr(transparent)` haka za mu iya jefa mauni.
        self as *mut _ as *mut T
    }

    /// Tsame darajar daga `MaybeUninit<T>` ganga.Wannan hanya ce mai kyau don tabbatar da cewa za a sauke bayanan, saboda sakamakon `T` ya ta'allaka ne da yadda ake sauke digo.
    ///
    /// # Safety
    ///
    /// Mai kiran ya tabbatar da cewa `MaybeUninit<T>` da gaske yana cikin yanayin farawa.Kira da wannan a lokacin da abun ciki da aka ba tukuna cikakken initialized haddasawa nan da nan maras bayyani hali.
    /// [type-level documentation][inv] ya ƙunshi ƙarin bayani game da wannan farashi mara iyaka.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// A saman wannan, ka tuna cewa yawancin nau'ikan suna da ƙarin masu haɗari fiye da yadda ake la'akari da farawa a matakin nau'in.
    /// Alal misali, a `1`-initialized [`Vec<T>`] aka dauke initialized (a karkashin halin yanzu aiwatar; wannan bai dokoki a barga tabbacin) saboda kawai ake bukata da mai tarawa sani game da shi shi ne cewa data akan dole ba null.
    ///
    /// Samar da irin wannan `Vec<T>` ba dalili *nan da nan* maras bayyani hali, amma zai sa maras bayyani hali tare da mafi hadari ayyukan (ciki har da faduwa da shi).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Daidai yadda ake amfani da wannan hanyar:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Ba daidai ba* amfani da wannan hanyar:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ya ba a initialized tukuna, saboda haka wannan na karshe line sa maras bayyani hali.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // KYAUTA: mai kira dole ne ya tabbatar da cewa an fara `self`.
        // Wannan kuma yana nufin cewa `self` dole ne a `value` bambanci.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Karanta ƙimar daga akwatin `MaybeUninit<T>`.A sakamakon `T` ne batun da ya saba drop handling.
    ///
    /// A duk lokacin da zai yiwu, shi ne fin so yin amfani da [`assume_init`] maimakon, wanda hana duplicating da abun ciki na `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Mai kiran ya tabbatar da cewa `MaybeUninit<T>` da gaske yana cikin yanayin farawa.Kira da wannan a lokacin da abun ciki da aka ba tukuna cikakken initialized haddasawa maras bayyani hali.
    /// [type-level documentation][inv] ya ƙunshi ƙarin bayani game da wannan farashi mara iyaka.
    ///
    /// Bugu da ƙari, wannan ganye a kwafin guda data baya a `MaybeUninit<T>`.
    /// Lokacin amfani da kwafin bayanai da yawa (ta hanyar kiran `assume_init_read` sau da yawa, ko kiran `assume_init_read` da farko sannan [`assume_init`]), hakkin ku ne ku tabbatar da cewa lallai za a iya ribanyar wannan bayanan.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Daidai yadda ake amfani da wannan hanyar:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ne `Copy`, saboda haka muna iya karanta mahara sau.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicating a `None` darajar ne lafiya, don haka mu iya karanta mahara sau.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Ba daidai ba* amfani da wannan hanyar:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Yanzu mun kirkira kwafi biyu iri guda na vector, wanda zai haifar da da mai double mara double lokacin da duk suka faɗi ƙasa!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // KYAUTA: mai kira dole ne ya tabbatar da cewa an fara `self`.
        // Reading daga `self.as_ptr()` shi ne hadari tun `self` ya kamata a initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Sauke darajar da aka ƙunshe a wuri.
    ///
    /// Idan kuna da mallakar `MaybeUninit`, zaku iya amfani da [`assume_init`] a madadin.
    ///
    /// # Safety
    ///
    /// Mai kiran ya tabbatar da cewa `MaybeUninit<T>` da gaske yana cikin yanayin farawa.Kira da wannan a lokacin da abun ciki da aka ba tukuna cikakken initialized haddasawa maras bayyani hali.
    ///
    /// A saman wannan, duk ƙarin masu canzawa na nau'in `T` dole ne su gamsu, saboda aiwatar da `Drop` na `T` (ko membobinta) na iya dogaro da wannan.
    /// Alal misali, a `1`-initialized [`Vec<T>`] aka dauke initialized (a karkashin halin yanzu aiwatar; wannan bai dokoki a barga tabbacin) saboda kawai ake bukata da mai tarawa sani game da shi shi ne cewa data akan dole ba null.
    ///
    /// Faduwa irin wannan `Vec<T>` duk da haka zai sa maras bayyani hali.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // KIYAYEWAR: mai kiran dole ne tabbacin cewa `self` aka initialized da kuma
        // ya gamsar da duk marasa canji na `T`.
        // Faduwa da darajar a wuri ne mai lafiya idan cewa shi ne yanayin.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Samu takamaiman bayani game da ƙimar da take ƙunshe.
    ///
    /// Wannan na iya zama mai amfani yayin da muke son samun damar `MaybeUninit` wanda aka ƙaddamar amma ba mu da mallakar `MaybeUninit` (hana amfani da `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kira da wannan a lokacin da abun ciki da aka ba tukuna cikakken initialized haddasawa maras bayyani hali: shi ne har zuwa mai kira zuwa ga tabbacin cewa `MaybeUninit<T>` gaske ne a wani initialized jihar.
    ///
    ///
    /// # Examples
    ///
    /// ### Daidai yadda ake amfani da wannan hanyar:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Gabatar da `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Yanzu da yake `MaybeUninit<_>` ɗinmu an san cewa an fara shi, ba laifi a ƙirƙiri wani bayanin da ya dace da shi:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // KIYAYEWAR: `x` an initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Ba daidai ba* amfani da wannan hanyar:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Mun halitta tunani zuwa wani uninitialized vector!Wannan halayyar da ba a bayyana ta ba.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize da `MaybeUninit` amfani `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Reference zuwa wani uninitialized `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // KYAUTA: mai kira dole ne ya tabbatar da cewa an fara `self`.
        // Wannan kuma yana nufin cewa `self` dole ne a `value` bambanci.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Yana samun bayanin (unique) mai canzawa zuwa ƙimar da take ƙunshe.
    ///
    /// Wannan na iya zama mai amfani yayin da muke son samun damar `MaybeUninit` wanda aka ƙaddamar amma ba mu da mallakar `MaybeUninit` (hana amfani da `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kira da wannan a lokacin da abun ciki da aka ba tukuna cikakken initialized haddasawa maras bayyani hali: shi ne har zuwa mai kira zuwa ga tabbacin cewa `MaybeUninit<T>` gaske ne a wani initialized jihar.
    /// Alal misali, `.assume_init_mut()` ba za a iya amfani da su initialize a `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Daidai yadda ake amfani da wannan hanyar:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Yana ƙaddamar da *dukkan* baiti na ajiyar abubuwan sakawa.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Gabatar da `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Yanzu mun san cewa `buf` an initialized, saboda haka muna iya `.assume_init()` shi.
    /// // Duk da haka, ta yin amfani da `.assume_init()` iya fararwa wani `memcpy` na 2048 bytes.
    /// // Don tabbatar da cewa an fara ajiyar mu ba tare da mun kwafa ba, mun haɓaka `&mut MaybeUninit<[u8; 2048]>` zuwa `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // KYAUTA: `buf` an fara shi.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Yanzu za mu iya amfani da `buf` a matsayin al'ada yanki:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Ba daidai ba* amfani da wannan hanyar:
    ///
    /// Ba zaku iya amfani da `.assume_init_mut()` don ƙaddamar da ƙima ba:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Mun halitta (mutable) tunani zuwa wani uninitialized `bool`!
    ///     // Wannan shi ne maras bayyani hali.⚠️
    /// }
    /// ```
    ///
    /// Alal misali, za ka iya ba [`Read`] cikin wani uninitialized buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) tunani zuwa uninitialized memory!
    ///                             // Wannan halayyar da ba a bayyana ta ba.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Kuma ba za ka yi amfani da kai tsaye filin damar yin filin-da-filin sauka a hankali initialization:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tunani zuwa uninitialized memory!
    ///                  // Wannan halayyar da ba a bayyana ta ba.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tunani zuwa uninitialized memory!
    ///                  // Wannan halayyar da ba a bayyana ta ba.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): A yanzu muna dogara ga kuskuren da ke sama ba daidai ba, watau, muna da nassoshi ga bayanan da ba a san su ba (misali, a cikin `libcore/fmt/float.rs`).
    // Yakamata mu yanke hukunci na karshe game da dokoki kafin daidaitawa.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // KYAUTA: mai kira dole ne ya tabbatar da cewa an fara `self`.
        // Wannan kuma yana nufin cewa `self` dole ne a `value` bambanci.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Cire ƙimar ƙimomin daga jerin kwantena `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Yana da har zuwa mai kira zuwa ga tabbacin cewa duk abubuwa na tsararru ne a wani initialized jihar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // KIYAYEWAR: Yanzu lafiya kamar yadda muka initialised duk abubuwa
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Da mai kira da tabbacin cewa dukkan abubuwa na tsararru ana initialized
        // * `MaybeUninit<T>` kuma T an tabbatar suna da tsari iri ɗaya
        // * MaybeUnint ba sauke, don haka babu biyu-fid Kuma ta haka ne da hira ne hadari
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Da alama duk abubuwan an fara su, to a basu yanki.
    ///
    /// # Safety
    ///
    /// Yana da har zuwa ga mai kiran a tabbatar da cewa `MaybeUninit<T>` abubuwa da gaske ne a wani initialized jihar.
    ///
    /// Kira da wannan a lokacin da abun ciki da aka ba tukuna cikakken initialized haddasawa maras bayyani hali.
    ///
    /// Dubi [`assume_init_ref`] don ƙarin bayani da misalai.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // KIYAYEWAR: Fitar yanki zuwa wani `*const [T]` shi ne hadari tun da mai kira tabbacin cewa
        // `slice` ne initialized, and`MaybeUninit` tabbas ne a yi wannan layout kamar yadda `T`.
        // The Pointer samu ne m tun da shi yana nufin memory mallakar `slice` wanda yake shi ne tunani da kuma ta haka tabbas zai zama m for karanta.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Da alama duk abubuwan an fara su, samo musu yanki mai canzawa.
    ///
    /// # Safety
    ///
    /// Yana da har zuwa ga mai kiran a tabbatar da cewa `MaybeUninit<T>` abubuwa da gaske ne a wani initialized jihar.
    ///
    /// Kira da wannan a lokacin da abun ciki da aka ba tukuna cikakken initialized haddasawa maras bayyani hali.
    ///
    /// Dubi [`assume_init_mut`] don ƙarin bayani da misalai.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // KIYAYEWAR: kama da aminci rubutu for `slice_get_ref`, amma muna da
        // Magana mai canzawa wanda shima an tabbatar dashi dacewa don rubutu.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Auri mauni zuwa na farko kashi na tsararru.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Auri mutable mauni zuwa na farko kashi na tsararru.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Ana kwafin abubuwan daga `src` zuwa `this`, suna dawo da magana mai canzawa zuwa abubuwan ciki na `this`.
    ///
    /// Idan `T` ba yi `Copy`, yi amfani da [`write_slice_cloned`]
    ///
    /// Wannan shi ne kama da [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Wannan aiki zai panic idan yanka biyu da daban-daban tsawo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KIYAYEWAR: mun kawai kofe dukan abubuwa na Len cikin kayayyakin iya aiki
    /// // abubuwan farko na src.len() na vec suna aiki yanzu.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // KIYAYEWAR: &[T] da kuma&[MaybeUninit<T>] Da wannan layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // KIYAYEWAR: Yana aiki abubuwa sun kawai aka kofe zuwa `this` haka shi ne initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Kwafi masu kunnen doki da abubuwa daga `src` zuwa `this`, ya dawo a mutable tunani da yanzu initalized abinda ke ciki na `this`.
    /// Duk wani abu da ya rigaya ya zama sihiri ba za a sa shi ba.
    ///
    /// Idan `T` aiwatarwa `Copy`, amfani [`write_slice`]
    ///
    /// Wannan yayi kama da [`slice::clone_from_slice`] amma baya sauke abubuwan da ke akwai.
    ///
    /// # Panics
    ///
    /// Wannan aiki zai panic idan yanka biyu da daban-daban tsawo, ko idan da aiwatar da `Clone` panics.
    ///
    /// Idan akwai wani panic, da riga cloned abubuwa za a kika aika.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KIYAYEWAR: mun kawai cloned dukan abubuwa na Len cikin kayayyakin iya aiki
    /// // abubuwan farko na src.len() na vec suna aiki yanzu.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // sabanin copy_from_slice wannan baya kiran clone_from_slice akan yanki wannan saboda `MaybeUninit<T: Clone>` baya aiwatar da clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KIYAYEWAR: wannan raw yanki zai dauke da kawai initialized abubuwa
                // shi ke sa, da shi ne a yarda ya sauke shi.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Muna buƙatar bayyana su a bayyane zuwa tsayi iri ɗaya
        // domin haddi dubawa da za a elided, da kuma dab'i zai samar da memcpy for sauki lokuta (misali T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // ana buƙatar tsaro b/c panic na iya faruwa yayin ɓata lokaci
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // KIYAYEWAR: Yana aiki abubuwa sun kawai aka rubuta a cikin `this` haka shi ne initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}