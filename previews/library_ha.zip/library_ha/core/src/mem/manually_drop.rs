use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A wrapper to hana tarawa daga atomatik kiran `T` ta destructor.
/// Wannan kunshin shine 0-cost.
///
/// `ManuallyDrop<T>` ne batun guda layout optimizations kamar yadda `T`.
/// A sakamakon, shi yana da *ba da sakamako* a kan zaton cewa tarawa sa game da abinda ke ciki.
/// Misali, fara `ManuallyDrop<&mut T>` tare da [`mem::zeroed`] halayyar da ba a bayyana ta ba.
/// Idan kana bukatar ka rike uninitialized data, yi amfani da [`MaybeUninit<T>`] maimakon.
///
/// Lura cewa samun dama da darajar ciki a `ManuallyDrop<T>` shi ne hadari.
/// Wannan yana nufin cewa a `ManuallyDrop<T>` wanda abun ciki da aka kika aika dole ba za a fallasa ta jama'a lafiya API.
/// Correspondingly, `ManuallyDrop::drop` ne unsafe.
///
/// # `ManuallyDrop` kuma sauke domin.
///
/// Rust yana da kyakkyawan ƙimar [drop order] na ƙimomi.
/// Don tabbatar da cewa an jefa filaye ko mazauna cikin takamaiman tsari, sake sake fasalin bayanan don umarnin da yake bayyane shine daidai.
///
/// Yana yiwuwa a yi amfani da `ManuallyDrop` don sarrafa drop domin, amma wannan na bukatar unsafe code, kuma da wuya su yi daidai a gaban unwinding.
///
///
/// Alal misali, idan kana so ka tabbatar da cewa wani takamaiman filin da aka ragu bayan da wasu, Ya tabbatar da shi na karshe filin daga a struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` za a kika aika bayan `children`.
///     // Rust tabbatar da cewa filayen suna kika aika a cikin tsari na bayyanawa.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Kunsa da darajar da za a hannu ya ragu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Za ka iya har yanzu a amince aiki a kan darajar
    /// assert_eq!(*x, "Hello");
    /// // Amma `Drop` ba za a gudu a nan
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Tsame darajar daga `ManuallyDrop` ganga.
    ///
    /// Wannan yana ba da damar sake ƙimar darajar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Wannan saukad da `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Theauki ƙimar daga kwandon `ManuallyDrop<T>` ɗin.
    ///
    /// Wannan hanya ne da farko yi nufi ga motsi daga dabi'u a drop.
    /// Maimakon amfani da [`ManuallyDrop::drop`] don sauke darajar da hannu, zaku iya amfani da wannan hanyar don ɗaukar ƙimar da amfani da shi yadda ake so.
    ///
    /// Duk lokacin da zai yiwu, ya fi kyau a yi amfani da [`into_inner`][`ManuallyDrop::into_inner`] maimakon, wanda ke hana kwafin abun cikin `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Wannan aiki semantically motsa fitar da dauke darajar ba tare da hana kara mai cutarwa, da barin Jihar wannan akwati canzawa.
    /// Shi ne alhakin tabbatar da cewa wannan `ManuallyDrop` ba a amfani da sake.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // KIYAYEWAR: muna karanta daga wani tunani, wanda tabbas ne
        // zama m for karanta.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Da hannu saukad da dauke darajar.Wannan shi ne daidai daidai da kiran [`ptr::drop_in_place`] da Pointer zuwa dauke da darajar.
    /// Kamar wannan, sai dai idan ƙimar da ke ƙunshe ita ce tsari, za'a kira mai lalata cikin wuri ba tare da matsar da ƙimar ba, don haka ana iya amfani dashi don sauke bayanan [pinned] lafiya.
    ///
    /// Idan kana da ikon mallakar ƙimar, zaka iya amfani da [`ManuallyDrop::into_inner`] a madadin.
    ///
    /// # Safety
    ///
    /// Wannan aiki gudanar da destructor na dauke da darajar.
    /// Baya ga canje-canje da mai lalata kansa yayi, ƙwaƙwalwar ajiyar ba ta canzawa ba, kuma har zuwa lokacin da mai tarawar ya damu har yanzu yana riƙe da ɗan tsari wanda yake daidai da nau'in `T`.
    ///
    ///
    /// Koyaya, wannan ƙimar "zombie" bai kamata a fallasa shi zuwa lambar kariya ba, kuma bai kamata a kira wannan aikin fiye da sau ɗaya ba.
    /// Don amfani da ƙima bayan an sauke ta, ko sauke ƙima sau da yawa, na iya haifar da ndea'idar Ma'anarta (gwargwadon abin da `drop` ke yi).
    /// Wannan nau'in tsarin yana hana shi, amma masu amfani da `ManuallyDrop` dole ne su riƙe waɗannan garanti ba tare da taimako daga mai tarawa ba.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // KIYAYEWAR: muna faduwa da darajar ishãra zuwa da wani mutable reference
        // wanda tabbas ne ya zama m domin ya rubuta.
        // Ya rage ga mai kiran don tabbatar da cewa ba a sake sauke `slot` ba.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}