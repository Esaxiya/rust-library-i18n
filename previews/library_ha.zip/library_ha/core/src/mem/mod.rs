//! Basic ayyukan mu'amala da ƙwaƙwalwar ajiyar.
//!
//! Wannan module ƙunshi ayyuka ga querying da size da kuma jeri na iri daban-daban, da kuma soma sabawa memory.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Daukan mallaka da kuma "forgets" game da darajar **ba tare da guje ta destructor**.
///
/// Duk wani albarkatun da darajar da kulawa, kamar tsibin ƙwaƙwalwar ajiya ko fayil rike, zai tsaya har abada a wani unreachable jihar.Duk da haka, shi ba ya tabbatar da cewa pointers a wannan memory zai kasance da inganci.
///
/// * Idan kana so ka zuba memory, ganin [`Box::leak`].
/// * Idan kana so ka samu wani raw mauni zuwa ƙwaƙwalwar ajiya, gani [`Box::into_raw`].
/// * Idan kana so ka jefa wani darajar yadda ya kamata, a guje ta destructor, ganin [`mem::drop`].
///
/// # Safety
///
/// `forget` ba alama kamar `unsafe`, saboda Rust ta aminci da tabbacin ba sun hada da tabbacin cewa destructors zai ko da yaushe gudu.
/// Alal misali, a shirin na iya haifar da wani tunani da sake zagayowar amfani [`Rc`][rc], ko kira [`process::exit`][exit] to fita ba tare da guje destructors.
/// Sabili da haka, barin `mem::forget` daga lambar kariya ba ya canza ainihin tabbacin aminci na Rust.
///
/// Wancan ya ce, malalar albarkatu kamar ƙwaƙwalwar ajiya ko abubuwa na I/O galibi ba a ke so.
/// A bukatar zo up a wasu musamman amfani lokuta ga FFI ko unsafe code, amma ko da daga baya, [`ManuallyDrop`] ne yawanci fĩfĩta.
///
/// Saboda manta da darajar da aka yarda, wani `unsafe` code ka rubuta dole ba da damar domin wannan yiwuwar.Ba zaku iya dawo da ƙima ba kuma kuyi tsammanin mai kiran zaiyi aiki da lalata darajar.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Amintaccen amfani da `mem::forget` shine don hana ɓarna mai ƙimar da aiwatarwa ta hanyar `Drop` trait.Alal misali, wannan zai zuba a `File`, watau
/// maida kuɗi da sarari dauka da m amma ba kusa tamkar tsarin hanya:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Wannan na da amfani a lokacin da ikon mallakar muhimmi hanya da aka a baya canjawa wuri zuwa code waje na Rust, misali ta hanyar yada da raw fayil descriptor zuwa C code.
///
/// # Alaka da `ManuallyDrop`
///
/// Duk da yake `mem::forget` kuma za a iya amfani da su canja wurin *memory* ikon mallakar, yin haka shi ne kuskure-yiwuwa.
/// [`ManuallyDrop`] yakamata ayi amfani dashi.Yi la'akari, misali, wannan lambar:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Gina `String` ta amfani da abubuwan cikin `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // zubo `v` saboda `s` ke sarrafa ƙwaƙwalwar ajiyar ta a yanzu
/// mem::forget(v);  // Kuskure, v ba shi da inganci kuma ba za a wuce shi zuwa aiki ba
/// assert_eq!(s, "Az");
/// // `s` An jabu kika aika da memory deallocated.
/// ```
///
/// Akwai matsala biyu tare da misalin da ke sama:
///
/// * Idan mafi code da aka kara tsakanin gina `String` da kuma kiran `mem::forget()`, a panic cikin shi zai sa wani biyu free saboda wannan memory aka abar kulawa da biyu `v` da `s`.
/// * Bayan kiran `v.as_mut_ptr()` da watsa ikon mallakar bayanai zuwa `s`, ƙimar `v` ba ta da inganci.
/// Ko a lokacin da wani darajar da aka koma kawai zuwa `mem::forget` (wanda ba zai duba shi), wasu iri da tsananin bukatun kan su dabi'u cewa sanya su da inganci idan dangling ko ba mallakar.
/// Amfani da ƙimomin da ba su da inganci ta kowace hanya, gami da tura su zuwa ko dawo da su daga ayyuka, ya zama halin da ba a bayyana ba kuma yana iya karya tunanin da mai tattara bayanan ya yi.
///
/// Sauyawa zuwa `ManuallyDrop` yana guje wa batutuwan biyu:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Kafin mu kwakkwance `v` cikin raw sassa, Tabbatar da shi ba ya samun kika aika!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Yanzu kwance `v`.Wadannan ayyukan ba zai iya panic, don haka akwai ba zai iya zama mai zuba.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // A karshe, gina wani `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` An jabu kika aika da memory deallocated.
/// ```
///
/// `ManuallyDrop` da karfi yana hana kyauta sau biyu saboda mun kashe mai lalata v 'kafin yin komai.
/// `mem::forget()` baya ba da izinin wannan saboda yana cinye maganganunta, yana tilasta mana mu kira shi kawai bayan cire duk abin da muke buƙata daga `v`.
/// Ko da an gabatar da panic tsakanin ginin `ManuallyDrop` da gina kirtani (wanda ba zai iya faruwa a lambar ba kamar yadda aka nuna), zai haifar da yoyo kuma ba kyauta biyu ba.
/// Watau, `ManuallyDrop` yayi kuskure a gefen malala maimakon kuskure a gefen (sau biyu) faduwa.
///
/// Hakanan, `ManuallyDrop` ya hana mu samun zuwa "touch" `v` bayan canja wurin mallakar zuwa `s`-matakin ƙarshe na hulɗa tare da `v` don zubar da shi ba tare da gudanar da mai lalata shi ba an kauce masa gaba ɗaya.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Kamar [`forget`], amma kuma yana karɓar ƙimomin da ba a tantance su ba.
///
/// Wannan aikin shine shimfidar shim da aka nufa don cire lokacin da fasalin `unsized_locals` ya daidaita.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Yana dawo da girman nau'ikan in baiti.
///
/// Musamman musamman, wannan shine ɓarna a cikin baiti tsakanin abubuwa masu zuwa a cikin tsararru tare da wancan nau'in abun ciki harda padding jeri.
///
/// Don haka, ga kowane nau'in `T` da tsawon `n`, `[T; n]` yana da girman `n * size_of::<T>()`.
///
/// Gabaɗaya, girman nau'ikan nau'ikan tsari bai daidaita ba, amma takamaiman nau'ikan abubuwa kamar na farkon.
///
/// Tebur mai zuwa yana ba da girman abubuwan farko.
///
/// Rubuta |girma_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Bugu da ƙari, `usize` da `isize` suna da girma ɗaya.
///
/// Nau'ikan `*const T`, `&T`, `Box<T>`, `Option<&T>`, da `Option<Box<T>>` duk girmansu ɗaya ne.
/// Idan `T` ya kasance Sized, duk waɗannan nau'ikan suna da girman girman ɗaya da `usize`.
///
/// Canjin yanayin mai nunawa ba ya canza girmansa.Kamar wannan, `&T` da `&mut T` suna da girma iri ɗaya.
/// Hakanan don `*const T` da `* mut T`.
///
/// # Girman abubuwa `#[repr(C)]`
///
/// Wakilcin `C` don abubuwa yana da tsararren shimfiɗa.
/// Tare da wannan shimfiɗar, girman abubuwa kuma suna da ƙarfi muddin dai dukkan filayen suna da girman tsayayye.
///
/// ## Girman Stangiyoyi
///
/// Don `structs`, ana ƙaddara girman ta hanyar algorithm mai zuwa.
///
/// Ga kowane fanni a cikin tsari wanda aka ba da umarnin ta hanyar sanarwa:
///
/// 1. Sanya girman filin.
/// 2. Rage girman girman yanzu zuwa mafi kusa na [alignment] filin na gaba.
///
/// A ƙarshe, zagaye girman tsarin zuwa mafi kusa na [alignment] ɗin sa.
/// Daidaitawar tsarin galibi shine daidaitawa mafi girma na dukkan fannoni;ana iya canza wannan ta amfani da `repr(align(N))`.
///
/// Ba kamar `C` ba, ba a dunƙule tsaka-tsakin sikito zuwa baiti ɗaya a girma.
///
/// ## Girman Enums
///
/// Abubuwan da ba su da bayanai banda mai nuna wariya suna da girman da ya dace da na C enums akan dandalin da aka hada su.
///
/// ## Girman kungiyoyin kwadago
///
/// Girman ƙungiyar kwatankwacin girman filin sa.
///
/// Ba kamar `C` ba, ba a tara ƙungiyoyin ƙwadago ba sifili har zuwa girman baiti ɗaya.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Wasu abubuwan farko
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // wasu iri-iri
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointer size daidaito
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Amfani da `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // A size na farko filin ne 1, saboda haka ƙara 1 ga size.Girman ne 1.
/// // A jeri na biyu filin ne 2, don haka ƙara 1 ga size ga padding.Girma shine 2.
/// // Girman filin na biyu 2 ne, don haka ƙara 2 zuwa girman.Girman ne 4.
/// // Jeri na filin na uku 1 ne, don haka ƙara 0 zuwa girman don padding.Girman ne 4.
/// // Girman filin na uku 1 ne, don haka ƙara 1 zuwa girman.Girman ne 5.
/// // A karshe, cikin jeri na struct ne 2 (domin mafi girma a jeri daga gare ta filayen ne 2), don haka ƙara 1 ga size ga padding.
/// // Girman ne 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Pleungiyoyin ƙarami suna bin ƙa'idodi iri ɗaya.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Lura cewa reordering da filayen iya rage da size.
/// // Za mu iya cire duka biyu padding bytes ta sa `third` kafin `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Girman ƙungiyar shine girman mafi girman filin.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Yana dawo da girman abin da aka nuna-zuwa ƙima a cikin baiti.
///
/// Wannan yawanci daidai yake da `size_of::<T>()`.
/// Koyaya, lokacin da `T`*bashi da* sanannen girma sananne, misali, yanki [`[T]`][slice] ko [trait object], to ana iya amfani da `size_of_val` don samun girman sanannen ƙarfi.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // KYAUTA: `val` ishara ce, saboda haka yana da cikakkiyar ma'anar ma'ana
    unsafe { intrinsics::size_of_val(val) }
}

/// Yana dawo da girman abin da aka nuna-zuwa ƙima a cikin baiti.
///
/// Wannan yawanci daidai yake da `size_of::<T>()`.Koyaya, lokacin da `T`*bashi da* girman sanannen lissafi, misali, yanki [`[T]`][slice] ko [trait object], to ana iya amfani da `size_of_val_raw` don samun girman sanannen ƙarfi.
///
/// # Safety
///
/// Wannan aikin yana da aminci in kira idan yanayi mai zuwa ya riƙe:
///
/// - Idan `T` shine `Sized`, wannan aikin yana da lafiya koyaushe.
/// - Idan unsized wutsiya na `T` ne:
///     - a [slice], to tsayin wutsiyar yanki dole ne ya zama cikakkiyar lamba, kuma girman *duka ƙimar*(tsayin daka mai ƙarfi + prefix mai cikakken girma) dole ne ya dace a cikin `isize`.
///     - a [trait object], to dole ne ɓangaren maɓallin keɓaɓɓen mai nunawa ya nuna aiki mai inganci wanda aka samu ta hanyar tilasta tilastawa, kuma girman * ƙimar duka (tsayayyen wutsiyar ƙarfin + prefix mai girma) dole ya dace a `isize`.
///
///     - wani (unstable) [extern type], to, wannan aikin ne ko da yaushe lafiya kira, amma iya panic ko in ba haka ba koma da ba daidai ba da darajar, kamar yadda da extern irin ta layout ba a sani.
///     Wannan halayya iri ɗaya ce kamar [`size_of_val`] akan tunani zuwa nau'in da ke da wutsiyar nau'in waje.
///     - in ba haka ba, ba a yarda da ra'ayin mazan jiya ya kira wannan aikin ba.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KYAUTA: mai kira dole ne ya samar da ingantaccen ɗan nuna alama
    unsafe { intrinsics::size_of_val(val) }
}

/// Ya dawo da daidaiton [ABI] da ake buƙata na daidaitaccen nau'in.
///
/// Duk bayanin da ya shafi darajar nau'in `T` dole ne ya zama yana da yawa na wannan lambar.
///
/// Wannan jeri ne da aka yi amfani dashi don filayen tsari.Zai iya zama ƙasa da daidaitawar da aka fi so.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ya dawo da daidaitaccen [ABI] na nau'in ƙimar da `val` ya nuna.
///
/// Duk bayanin da ya shafi darajar nau'in `T` dole ne ya zama yana da yawa na wannan lambar.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // KYAUTA: val is reference ne, saboda haka yana da ingantaccen ma'ana
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ya dawo da daidaiton [ABI] da ake buƙata na daidaitaccen nau'in.
///
/// Duk bayanin da ya shafi darajar nau'in `T` dole ne ya zama yana da yawa na wannan lambar.
///
/// Wannan jeri ne da aka yi amfani dashi don filayen tsari.Zai iya zama ƙasa da daidaitawar da aka fi so.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ya dawo da daidaitaccen [ABI] na nau'in ƙimar da `val` ya nuna.
///
/// Duk bayanin da ya shafi darajar nau'in `T` dole ne ya zama yana da yawa na wannan lambar.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // KYAUTA: val is reference ne, saboda haka yana da ingantaccen ma'ana
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ya dawo da daidaitaccen [ABI] na nau'in ƙimar da `val` ya nuna.
///
/// Duk bayanin da ya shafi darajar nau'in `T` dole ne ya zama yana da yawa na wannan lambar.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Wannan aikin yana da aminci in kira idan yanayi mai zuwa ya riƙe:
///
/// - Idan `T` shine `Sized`, wannan aikin yana da lafiya koyaushe.
/// - Idan unsized wutsiya na `T` ne:
///     - a [slice], to tsayin wutsiyar yanki dole ne ya zama cikakkiyar lamba, kuma girman *duka ƙimar*(tsayin daka mai ƙarfi + prefix mai cikakken girma) dole ne ya dace a cikin `isize`.
///     - a [trait object], to dole ne ɓangaren maɓallin keɓaɓɓen mai nunawa ya nuna aiki mai inganci wanda aka samu ta hanyar tilasta tilastawa, kuma girman * ƙimar duka (tsayayyen wutsiyar ƙarfin + prefix mai girma) dole ya dace a `isize`.
///
///     - wani (unstable) [extern type], to, wannan aikin ne ko da yaushe lafiya kira, amma iya panic ko in ba haka ba koma da ba daidai ba da darajar, kamar yadda da extern irin ta layout ba a sani.
///     Wannan halayya iri ɗaya ce kamar [`align_of_val`] akan tunani zuwa nau'in da ke da wutsiyar nau'in waje.
///     - in ba haka ba, ba a yarda da ra'ayin mazan jiya ya kira wannan aikin ba.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KYAUTA: mai kira dole ne ya samar da ingantaccen ɗan nuna alama
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Yana dawo da `true` idan fadada darajar nau'ikan nau'ikan `T`.
///
/// Wannan zance ne kawai na ingantawa, kuma ana iya aiwatar dashi ta hanyar ra'ayin mazan jiya:
/// yana iya dawo da `true` don nau'ikan da basa buƙatar a sauke su.
/// Kamar wannan koyaushe dawo da `true` zai zama ingantaccen aiwatar da wannan aikin.Koyaya idan wannan aikin ya dawo da `false` a zahiri, to kuna iya tabbatar da faduwa `T` bashi da wani tasiri.
///
/// Implementananan aiwatarwar abubuwa kamar tarin abubuwa, waɗanda ke buƙatar sauke bayanan su da hannu, yakamata suyi amfani da wannan aikin don kauce wa ƙoƙarin ba da izinin sauke duk abubuwan da ke ciki lokacin da aka lalata su.
///
/// Wannan bazai haifar da bambanci ba a cikin sakewar gini (inda madauki wanda ba shi da tasiri-sauƙin ganowa da kawar da shi), amma galibi babban nasara ne don haɓaka haɓaka.
///
/// Lura cewa [`drop_in_place`] ya riga yayi wannan binciken, don haka idan aikinku zai iya raguwa zuwa wasu ƙananan lambobin kiran [`drop_in_place`], yin amfani da wannan bashi da mahimmanci.
/// Musamman lura cewa zaku iya [`drop_in_place`] yanki, kuma wannan zaiyi binciken buƙata guda ɗaya don duk ƙimomin.
///
/// Nau'ikan kamar Vec saboda haka kawai `drop_in_place(&mut self[..])` ba tare da amfani da `needs_drop` a sarari ba.
/// Nau'ikan kamar [`HashMap`], a gefe guda, dole ne su sauke ƙimomi ɗaya bayan ɗaya kuma yakamata suyi amfani da wannan API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ga misalin yadda tarin zai iya amfani da `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // sauke bayanai
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Ya dawo da darajar nau'in `T` wanda aka wakilta ta hanyar zane-zane.
///
/// Wannan yana nufin cewa, misali, baiti mai kwalliya a cikin `(u8, u16)` ba lallai bane ya zama sifili.
///
/// Babu tabbacin cewa tsarin sifili-sifili yana wakiltar ƙimar darajar wani nau'in `T`.
/// Misali, tsarin sifili-sifili ba cikakkiyar ƙima ba ce ga nau'ikan tunani (``&T`, `&mut T`) da alamomin ayyuka.
/// Amfani da `zeroed` akan waɗannan nau'ikan yana haifar da [undefined behavior][ub] nan da nan saboda [the Rust compiler assumes][inv] cewa koyaushe akwai ƙimar inganci a cikin canjin da take ɗaukar ƙaddamarwa.
///
///
/// Wannan yana da sakamako iri ɗaya kamar [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Yana da amfani ga FFI wani lokacin, amma yakamata a guje shi.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Daidaita amfani da wannan aikin: ƙaddamar da lamba tare da sifili.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Ba daidai ba* amfani da wannan aikin: fara tunani tare da sifili.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Maras bayyani hali!
/// let _y: fn() = unsafe { mem::zeroed() }; // Kuma a sake!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // KYAUTA: mai kira dole ne ya bada tabbacin cewa ƙimar-sifili tana da inganci ga `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Yana kewaya Rust na al'ada ƙwaƙwalwar-farawa dubawa ta hanyar yin kamar don samar da darajar nau'in `T`, yayin yin komai kwata-kwata.
///
/// **Wannan aikin ya lalace.** Amfani da [`MaybeUninit<T>`] maimakon.
///
/// Dalilin raguwa shi ne cewa aikin ba za a iya amfani dashi daidai ba: yana da sakamako iri ɗaya kamar na [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kamar yadda [`assume_init` documentation][assume_init] yayi bayani, [the Rust compiler assumes][inv] cewa ƙimar kirkirar kirkirar kirki ce.
/// A sakamakon haka, kiran misali
/// `mem::uninitialized::<bool>()` yana haifar da halin da ba a bayyana ba nan da nan don dawo da `bool` wanda ba lallai bane ko dai `true` ko `false`.
/// Mafi munin, ƙwaƙwalwar ajiyar ƙwaƙwalwa kamar abin da aka dawo anan yana da mahimmanci saboda masu tarawa sun san cewa bashi da ƙayyadaddun ƙima.
/// Wannan ya sa ba a bayyana ma'anarta ba don samun bayanai marasa wayewa a cikin mai canzawa koda kuwa wancan canjin yana da nau'in lamba.
/// (Ka lura cewa dokokin kusa uninitialized integers ba cimma matsaya ba, amma har suna, shi ne bu mai kyau don kauce wa su.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // KYAUTA: mai kira dole ne ya bada tabbacin cewa ƙimar da ba ta gama aiki ba tana da inganci don `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Sauya dabi'u a wurare biyu masu canzawa, ba tare da lalata ɗayan ba.
///
/// * Idan kana son yin musaya da wani tsoho ko darajar gunki, duba [`take`].
/// * Idan kanaso musanyawa da darajar da aka wuce, dawo da tsohon darajar, duba [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KYAUTA: an ƙirƙiri madogara masu ma'ana daga amintattun maganganu masu gamsarwa duka
    // ƙuntatawa akan `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Yana maye gurbin `dest` tare da ƙimar tsoho na `T`, yana dawo da ƙimar `dest` da ta gabata.
///
/// * Idan kana son maye gurbin ƙimar masu canji biyu, duba [`swap`].
/// * Idan kanaso maye gurbinsu da darajar da aka wuce maimakon ta tsohuwa, duba [`replace`].
///
/// # Examples
///
/// Misali mai sauki:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` yana ba da damar mallakar mallakar fili ta maye gurbin shi da ƙimar "empty".
/// In ba tare da `take` ba za ku iya fuskantar matsaloli kamar waɗannan:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Lura cewa `T` ba lallai bane ya aiwatar da [`Clone`], don haka ba zai iya haɗawa da sake saita `self.buf` ba.
/// Amma ana iya amfani da `take` don cire asalin asalin `self.buf` daga `self`, yana ba da damar dawowa:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Motsa `src` zuwa cikin `dest` da aka ambata, yana dawo da ƙimar `dest` da ta gabata.
///
/// Babu ƙimar da aka bari.
///
/// * Idan kana son maye gurbin ƙimar masu canji biyu, duba [`swap`].
/// * Idan kana son maye gurbinsu da ƙimar tsohuwa, duba [`take`].
///
/// # Examples
///
/// Misali mai sauki:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` Yana ba da damar amfani da filin tsari ta hanyar maye gurbin shi da wani ƙimar.
/// In ba tare da `replace` ba za ku iya fuskantar matsaloli kamar waɗannan:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Lura cewa `T` ba lallai bane ya aiwatar da [`Clone`], don haka ba zamu iya haɗawa da `self.buf[i]` don gujewa motsawa ba.
/// Amma ana iya amfani da `replace` don rarraba asalin asali a waccan bayanan daga `self`, yana ba da damar dawowa:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // KYAUTA: Mun karanta daga `dest` amma kai tsaye rubuta `src` a ciki daga baya,
    // irin wannan cewa ba a maimaita tsohuwar ƙimar ba.
    // Babu wani abu da aka sauke kuma babu abin da zai iya panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Kashe darajar.
///
/// Wannan yana yin ta kiran kiran aiwatarwar hujja na [`Drop`][drop].
///
/// Wannan ba ya yin komai don nau'ikan da ke aiwatar da `Copy`, misali
/// integers.
/// Irin waɗannan ƙididdigar suna kofe kuma _then_ ya koma cikin aikin, don haka ƙimar ta ci gaba bayan wannan kiran aikin.
///
///
/// Wannan aikin ba sihiri bane;an bayyana shi a zahiri kamar yadda
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Saboda `_x` ya koma cikin aikin, ana sauke shi kai tsaye kafin aikin ya dawo.
///
/// [drop]: Drop
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // baro-baro jifa da vector
/// ```
///
/// Tunda [`RefCell`] na tilasta bin dokokin aro a lokacin aiki, `drop` na iya sakin aron [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // daina karɓar aro mai canzawa akan wannan hanyar
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Masu haɗakawa da wasu nau'ikan aiwatar da [`Copy`] ba su da tasirin `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kwafi na `x` an motsa an sauke shi
/// drop(y); // kwafi na `y` an motsa an sauke shi
///
/// println!("x: {}, y: {}", x, y.0); // har yanzu akwai
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Yana fassara `src` kamar mai nau'in `&U`, sannan kuma karanta `src` ba tare da matsar da ƙimar da take ciki ba.
///
/// Wannan aikin zai amintar da cewa mai nuna alama `src` yana da inganci don baiti [`size_of::<U>`][size_of] ta hanyar canza `&T` zuwa `&U` sannan karanta `&U` (sai dai ana yin wannan ta hanyar da ke daidai koda lokacin da `&U` ya sanya tsayayyar buƙatun daidaitawa fiye da `&T`).
/// Hakanan zai amintar da ƙirƙirar kwafin ƙimar da aka ƙunshe maimakon ƙaura daga `src`.
///
/// Ba kuskuren tattara lokaci bane idan `T` da `U` suna da girma dabam-dabam, amma ana ƙarfafa shi kawai don kiran wannan aikin inda `T` da `U` suke da girma ɗaya.Wannan aikin yana haifar da [undefined behavior][ub] idan `U` ya fi `T` girma.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kwafi da data daga 'foo_array' kuma ku bi shi a matsayin 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Gyara bayanan da aka kwafa
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Abinda ke ciki na 'foo_array' kamata ba sun canza
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Idan U yana da buƙatar daidaitawa mafi girma, src bazai dace da daidaito ba.
    if align_of::<U>() > align_of::<T>() {
        // KYAUTA: `src` nuni ne wanda aka tabbatar da ingancinsa don karantawa.
        // Wajibi ne mai kiran ya ba da tabbacin cewa ainihin fitowar ba ta da aminci.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // KYAUTA: `src` nuni ne wanda aka tabbatar da ingancinsa don karantawa.
        // Mun dai bincika cewa `src as *const U` yayi daidai.
        // Wajibi ne mai kiran ya ba da tabbacin cewa ainihin fitowar ba ta da aminci.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Nau'in Opaque wanda yake wakiltar mai nuna wariyar launin fata.
///
/// Duba aikin [`discriminant`] a cikin wannan kundin don ƙarin bayani.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Waɗannan aiwatarwar trait ba za a iya samo su ba saboda ba ma son samun iyaka akan T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Ya dawo da ƙimar da ke gano asalin enum a cikin `v`.
///
/// Idan `T` ba enum bane, kiran wannan aikin ba zai haifar da halayyar da ba a bayyana ba, amma ba a bayyana darajar dawowa ba.
///
///
/// # Stability
///
/// Mai nuna bambancin bambanci zai iya canzawa idan ma'anar ta canza.
/// Mai nuna bambanci ga wasu bambance-bambancen ba zai canza tsakanin tattarawa tare da mai tarawa ɗaya ba.
///
/// # Examples
///
/// Ana iya amfani da wannan don kwatanta abubuwan da ke ɗauke da bayanai, yayin yin watsi da ainihin bayanan:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Ya dawo da adadin bambance-bambancen karatu a cikin nau'in enum na `T`.
///
/// Idan `T` ba enum bane, kiran wannan aikin ba zai haifar da halayyar da ba a bayyana ba, amma ba a bayyana darajar dawowa ba.
/// Hakanan, idan `T` enum ne tare da wasu bambance-bambancen da yawa fiye da `usize::MAX` ba za'a bayyana darajar dawowa ba.
/// Za'a kidaya bambance-bambancen da ba mazauni
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}