//! Tallafin Panic a cikin ɗakunan karatu na misali.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Tsarin da ke ba da bayani game da panic.
///
/// `PanicInfo` An ba da tsari zuwa panic hook wanda aikin [`set_hook`] ya tsara.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Ya dawo da aikin biyan kuɗi wanda ke hade da panic.
    ///
    /// Wannan gabaɗaya, amma ba koyaushe, zai zama `&'static str` ko [`String`] ba.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Idan an yi amfani da macen `panic!` daga `core` crate (ba daga `std` ba) tare da zaren tsarawa da wasu ƙarin ƙarin bahasi, ya dawo da wannan saƙon da aka shirya amfani dashi misali tare da [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Yana dawo da bayani game da wurin da panic ya samo asali, idan akwai.
    ///
    /// Wannan hanyar a halin yanzu koyaushe zata dawo da [`Some`], amma wannan na iya canzawa a cikin sifofin future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Idan an canza wannan don wani lokacin ya dawo Babu,
        // magance wannan shari'ar a cikin std::panicking::default_hook da std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ba za mu iya amfani da downcast_ref: :<String>() nan
        // tunda babu Kirtani a cikin libcore!
        // Biyan kuɗi shine Kirtani lokacin da aka kira `std::panic!` tare da mahawara da yawa, amma a wannan yanayin ana samun saƙon.
        //

        self.location.fmt(formatter)
    }
}

/// Tsarin da ke ƙunshe da bayanai game da wurin panic.
///
/// Wannan tsarin an ƙirƙira shi ta [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Ana yin kwatancen daidaito da oda a cikin fayil, layi, sannan fifikon shafi.
/// Ana kwatanta fayiloli azaman kirtani, ba `Path` ba, wanda zai iya zama ba zato ba tsammani.
/// Duba takaddun [``W: :::file`] don ƙarin tattaunawa.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Yana dawo da wurin asalin mai kiran wannan aikin.
    /// Idan an sanar da mai kiran wannan aikin to za a dawo da wurin kiransa, don haka a kan tari zuwa kiran farko a cikin jikin aikin da ba sa ido.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Ya dawo da [`Location`] wanda aka kira shi.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Ya dawo da [`Location`] daga cikin ma'anar wannan aikin.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // gudanar da aiki iri daban daban a wani wuri daban yana bamu sakamako iri daya
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // gudanar da aikin bin sawu a wani wuri daban yana samar da wata daraja ta daban
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Mayar da sunan fayil ɗin tushe wanda panic ya samo asali.
    ///
    /// # `&str`, ba `&Path` ba
    ///
    /// Sunan da aka dawo yana nufin hanyar tushe akan tsarin tattarawa, amma baya aiki don wakiltar wannan kai tsaye azaman `&Path`.
    /// Lambar da aka tattara za ta iya aiki a kan wani tsarin daban tare da aiwatar da `Path` daban-daban fiye da tsarin da ke samar da abubuwan da ke ciki kuma wannan ɗakin karatun a halin yanzu ba shi da nau'in "host path" daban.
    ///
    /// Halin da ya fi ban mamaki yana faruwa yayin da fayil ɗin "the same" zai iya isa ta hanyoyi da yawa a cikin tsarin koyaushe (yawanci ta amfani da sifa ta `#[path = "..."]` ko makamancin haka), wanda zai iya haifar da abin da ya zama alama iri ɗaya don dawo da ƙimomi daban-daban daga wannan aikin.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Wannan ƙimar ba ta dace ba don wucewa zuwa `Path::new` ko masu ginin irin wannan lokacin da dandamalin mai masaukin da maƙasudin dandamali ya bambanta.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Yana dawo da lambar layin daga wacce panic ta samo asali.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Yana dawo da shafi wanda asalin panic ya samo asali.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait na ciki wanda libstd yayi amfani dashi don watsa bayanai daga libstd zuwa `panic_unwind` da sauran lokutan panic.
/// Ba niyya don daidaitawa kowane lokaci nan da nan, kar a yi amfani da shi.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Yi cikakken mallakar abubuwan da ke ciki.
    /// Nau'in dawowa shine ainihin `Box<dyn Any + Send>`, amma baza mu iya amfani da `Box` a cikin libcore ba.
    ///
    /// Bayan wannan hanyar da aka kira, kawai wasu ƙididdigar tsoho ne kawai aka bari a cikin `self`.
    /// Kira wannan hanyar sau biyu, ko kiran `get` bayan kiran wannan hanyar, kuskure ne.
    ///
    /// An aro gardamar saboda lokacin aikin panic (`__rust_start_panic`) kawai yana samun `dyn BoxMeUp` aro.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Kawai aron abin da ke ciki.
    fn get(&mut self) -> &(dyn Any + Send);
}