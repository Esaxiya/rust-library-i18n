//! Mai tattara abubuwa masu mahimmanci.
//!
//! Ma'anar ma'anar suna cikin `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Abubuwan aiwatarwa masu daidaito suna cikin `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Intungiya mai mahimmanci
//!
//! Note: duk wani canje-canje ga mahimmin abu ya kamata a tattauna tare da ƙungiyar masu amfani da harshe.
//! Wannan ya hada da canje-canje a cikin kwanciyar hankali na dindindin.
//!
//! Domin yin wani muhimmi mai amfani a tara-lokaci, daya bukatun to kwafa da aiwatar daga <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> zuwa `compiler/rustc_mir/src/interpret/intrinsics.rs` kuma ƙara `#[rustc_const_unstable(feature = "foo", issue = "01234")]` da muhimmi.
//!
//!
//! Idan yakamata ayi amfani da ainihin daga `const fn` tare da sifa na `rustc_const_stable`, sifar mahimmin dole ne ya zama `rustc_const_stable`, ma.
//! Bai kamata a yi irin wannan canjin ba tare da tuntubar T-lang ba, saboda yana toshe fasali cikin yaren da ba za a sake buga shi ba a cikin lambar mai amfani ba tare da tallafi ba.
//!
//! # Volatiles
//!
//! Intananan maɓallin keɓaɓɓu suna samar da ayyukan da aka yi niyya don aiki akan ƙwaƙwalwar I/O, waɗanda aka ba da tabbacin cewa ba za a sake dawo da su ta hanyar mai tarawa a cikin sauran mahimman maganganun ba.Dubi LLVM takardun a kan [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Abubuwan da ke cikin kwayar zarra suna samar da ayyukan atom na yau da kullun akan kalmomin inji, tare da yiwuwar oda da yawa.Suna yin biyayya ga wannan ilimin harsuna kamar C++ 11.Dubi LLVM takardun a kan [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! A sauri refresher a kan memory ordering:
//!
//! * Karɓo su, da wata tõshiya a gare nemowa wani kulle.M karanta da kuma rubuta faru bayan da shãmaki.
//! * Saki, shamaki don sakin makulli.Gabanin karanta da kuma rubuta dauki wuri kafin shãmaki.
//! * Sequentially m, sequentially m yadda ake gudanar tabbas ya faru domin.Wannan shine yanayin daidaitaccen aiki don aiki tare da nau'ikan atomic kuma yayi daidai da Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ana amfani da waɗannan shigo da kaya don sauƙaƙa hanyoyin intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // KIYAYEWAR: gani `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, wadannan intrinsics dauki raw pointers saboda sun mutate aliased memory, wanda ba shi da inganci domin dai `&` ko `&mut`.
    //

    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange` Hanyar ta wucewa [`Ordering::SeqCst`] kamar yadda biyu da `success` da `failure` sigogi.
    ///
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange` ta wucewa [`Ordering::Acquire`] azaman duka matakan `success` da `failure`.
    ///
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange` ta wucewa [`Ordering::Release`] azaman `success` da [`Ordering::Relaxed`] azaman sigogin `failure`.
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `success` da [`Ordering::Acquire`] matsayin `failure` sigogi.
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange` Hanyar ta wucewa [`Ordering::Relaxed`] kamar yadda biyu da `success` da `failure` sigogi.
    ///
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `success` da [`Ordering::Relaxed`] matsayin `failure` sigogi.
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `success` da [`Ordering::Acquire`] matsayin `failure` sigogi.
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `success` da [`Ordering::Relaxed`] matsayin `failure` sigogi.
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange` ta wucewa [`Ordering::AcqRel`] azaman `success` da [`Ordering::Relaxed`] azaman sigogin `failure`.
    /// Misali, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange_weak` ta wucewa [`Ordering::SeqCst`] azaman duka matakan `success` da `failure`.
    ///
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange_weak` ta wucewa [`Ordering::Acquire`] azaman duka matakan `success` da `failure`.
    ///
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange_weak` ta wucewa [`Ordering::Release`] azaman `success` da [`Ordering::Relaxed`] azaman sigogin `failure`.
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange_weak` ta wucewa [`Ordering::AcqRel`] azaman `success` da [`Ordering::Acquire`] azaman sigogin `failure`.
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange_weak` ta wucewa [`Ordering::Relaxed`] azaman duka matakan `success` da `failure`.
    ///
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange_weak` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `success` da [`Ordering::Relaxed`] matsayin `failure` sigogi.
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `compare_exchange_weak` ta wucewa [`Ordering::SeqCst`] azaman `success` da [`Ordering::Acquire`] azaman sigogin `failure`.
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange_weak` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `success` da [`Ordering::Relaxed`] matsayin `failure` sigogi.
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores da darajar idan na yanzu darajar ne guda a matsayin `old` darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `compare_exchange_weak` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `success` da [`Ordering::Relaxed`] matsayin `failure` sigogi.
    /// Misali, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Lodi na yanzu tamanin da Pointer.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `load` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Lodi na yanzu tamanin da Pointer.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `load` ta wucewa [`Ordering::Acquire`] azaman `order`.
    /// Misali, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Lodi na yanzu tamanin da Pointer.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `load` ta wucewa [`Ordering::Relaxed`] azaman `order`.
    /// Misali, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Adana ƙimar a ƙayyadadden wurin ƙwaƙwalwar ajiya.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `store` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Adana ƙimar a ƙayyadadden wurin ƙwaƙwalwar ajiya.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `store` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Adana ƙimar a ƙayyadadden wurin ƙwaƙwalwar ajiya.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `store` Hanyar ta wucewa [`Ordering::Relaxed`] matsayin `order`.
    /// Misali, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Stores darajar a kayyade memory wuri, ya dawo da tsohon darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `swap` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores darajar a kayyade memory wuri, ya dawo da tsohon darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `swap` ta wucewa [`Ordering::Acquire`] azaman `order`.
    /// Misali, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores darajar a kayyade memory wuri, ya dawo da tsohon darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `swap` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores darajar a kayyade memory wuri, ya dawo da tsohon darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `swap` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores darajar a kayyade memory wuri, ya dawo da tsohon darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `swap` Hanyar ta wucewa [`Ordering::Relaxed`] matsayin `order`.
    /// Misali, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Dsara zuwa ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_add` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dsara zuwa ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_add` ta wucewa [`Ordering::Acquire`] azaman `order`.
    /// Misali, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dsara zuwa ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_add` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dsara zuwa ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_add` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dsara zuwa ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_add` Hanyar ta wucewa [`Ordering::Relaxed`] matsayin `order`.
    /// Misali, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Debewa daga yanzu darajar, ya dawo da baya darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_sub` ta wucewa [`Ordering::SeqCst`] azaman `order`.
    /// Misali, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Debewa daga yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_sub` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Debewa daga yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_sub` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Debewa daga yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_sub` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Debewa daga yanzu darajar, ya dawo da baya darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_sub` ta wucewa [`Ordering::Relaxed`] azaman `order`.
    /// Misali, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise da da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_and` ta wucewa [`Ordering::SeqCst`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise da da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_and` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise da da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_and` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise da da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_and` ta wucewa [`Ordering::AcqRel`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise da da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_and` ta wucewa [`Ordering::Relaxed`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise Nand tare da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// Ana samun ingantaccen fasalin wannan na ainihi akan nau'in [`AtomicBool`] ta hanyar hanyar `fetch_nand` ta wucewa [`Ordering::SeqCst`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise Nand tare da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// Ana samun ingantaccen fasalin wannan na ainihi akan nau'in [`AtomicBool`] ta hanyar hanyar `fetch_nand` ta wucewa [`Ordering::Acquire`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise Nand tare da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`AtomicBool`] irin via da `fetch_nand` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise Nand tare da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`AtomicBool`] irin via da `fetch_nand` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise Nand tare da na yanzu darajar, ya dawo da baya darajar.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`AtomicBool`] irin via da `fetch_nand` Hanyar ta wucewa [`Ordering::Relaxed`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ko tare da ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_or` ta wucewa [`Ordering::SeqCst`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ko tare da ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_or` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ko tare da ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_or` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ko tare da ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_or` ta wucewa [`Ordering::AcqRel`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ko tare da ƙimar yanzu, dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_or` Hanyar ta wucewa [`Ordering::Relaxed`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor tare da ƙimar yanzu, yana dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_xor` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor tare da ƙimar yanzu, yana dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_xor` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor tare da ƙimar yanzu, yana dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_xor` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor tare da ƙimar yanzu, yana dawo da ƙimar da ta gabata.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] iri via da `fetch_xor` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor tare da ƙimar yanzu, yana dawo da ƙimar da ta gabata.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan [`atomic`] ta hanyar hanyar `fetch_xor` ta wucewa [`Ordering::Relaxed`] azaman `order`.
    /// Misali, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Iyakar da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] hannu lamba iri via da `fetch_max` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyakar da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] hannu lamba iri via da `fetch_max` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyakar da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan adadin lamba da aka sanya hannu akan [`atomic`] ta hanyar hanyar `fetch_max` ta hanyar wucewa [`Ordering::Release`] azaman `order`.
    /// Misali, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyakar da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] hannu lamba iri via da `fetch_max` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyakar da na yanzu darajar.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan adadin lamba da aka sanya hannu akan [`atomic`] ta hanyar hanyar `fetch_max` ta hanyar wucewa [`Ordering::Relaxed`] azaman `order`.
    /// Misali, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mafi qarancin da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] hannu lamba iri via da `fetch_min` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qarancin da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] hannu lamba iri via da `fetch_min` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qarancin da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] hannu lamba iri via da `fetch_min` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qarancin da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// Samfurin da aka daidaita na wannan yanayin yana samuwa akan nau'ikan adadin lamba da aka sanya hannu akan [`atomic`] ta hanyar hanyar `fetch_min` ta hanyar wucewa [`Ordering::AcqRel`] azaman `order`.
    /// Misali, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qarancin da na yanzu darajar amfani da wani ya sanya hannu kwatanta.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] hannu lamba iri via da `fetch_min` Hanyar ta wucewa [`Ordering::Relaxed`] matsayin `order`.
    /// Misali, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mafi qaranci da darajar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] Unsigned lamba iri via da `fetch_min` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qaranci da darajar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] Unsigned lamba iri via da `fetch_min` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qaranci da darajar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// An samu ingantaccen sigar wannan asalin akan nau'ikan nau'in lamba mara lamba [`atomic`] ta hanyar hanyar `fetch_min` ta hanyar wucewa [`Ordering::Release`] azaman `order`.
    /// Misali, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qaranci da darajar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] Unsigned lamba iri via da `fetch_min` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mafi qaranci da darajar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// An samu ingantaccen sigar wannan asalin akan nau'ikan nau'in lamba mara lamba [`atomic`] ta hanyar hanyar `fetch_min` ta hanyar wucewa [`Ordering::Relaxed`] azaman `order`.
    /// Misali, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Matsakaici tare da ƙimar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] Unsigned lamba iri via da `fetch_max` Hanyar ta wucewa [`Ordering::SeqCst`] matsayin `order`.
    /// Misali, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Matsakaici tare da ƙimar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] Unsigned lamba iri via da `fetch_max` Hanyar ta wucewa [`Ordering::Acquire`] matsayin `order`.
    /// Misali, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Matsakaici tare da ƙimar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] Unsigned lamba iri via da `fetch_max` Hanyar ta wucewa [`Ordering::Release`] matsayin `order`.
    /// Misali, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Matsakaici tare da ƙimar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a kan [`atomic`] Unsigned lamba iri via da `fetch_max` Hanyar ta wucewa [`Ordering::AcqRel`] matsayin `order`.
    /// Misali, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Matsakaici tare da ƙimar yanzu ta amfani da kwatancen da ba a sa hannu ba.
    ///
    /// An samu ingantaccen sigar wannan asalin akan nau'ikan nau'in lamba mara lamba [`atomic`] ta hanyar hanyar `fetch_max` ta hanyar wucewa [`Ordering::Relaxed`] azaman `order`.
    /// Misali, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` na ainihi alama ce ga janareta lambar don saka umarnin prefetch idan an tallafawa;in ba haka ba, shi ne mai ba-op.
    /// Prefetches da wani sakamako a kan hali na shirin amma na iya canza ta yi halaye.
    ///
    /// A `locality` shaida dole ne akai lamba kuma shi ne na boko Locality specifier jere daga (0), babu Locality, to (3), musamman na gida Ka cache.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` na ainihi alama ce ga janareta lambar don saka umarnin prefetch idan an tallafawa;in ba haka ba, shi ne mai ba-op.
    /// Prefetches da wani sakamako a kan hali na shirin amma na iya canza ta yi halaye.
    ///
    /// A `locality` shaida dole ne akai lamba kuma shi ne na boko Locality specifier jere daga (0), babu Locality, to (3), musamman na gida Ka cache.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` na ainihi alama ce ga janareta lambar don saka umarnin prefetch idan an tallafawa;in ba haka ba, shi ne mai ba-op.
    /// Prefetches da wani sakamako a kan hali na shirin amma na iya canza ta yi halaye.
    ///
    /// A `locality` shaida dole ne akai lamba kuma shi ne na boko Locality specifier jere daga (0), babu Locality, to (3), musamman na gida Ka cache.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` na ainihi alama ce ga janareta lambar don saka umarnin prefetch idan an tallafawa;in ba haka ba, shi ne mai ba-op.
    /// Prefetches da wani sakamako a kan hali na shirin amma na iya canza ta yi halaye.
    ///
    /// A `locality` shaida dole ne akai lamba kuma shi ne na boko Locality specifier jere daga (0), babu Locality, to (3), musamman na gida Ka cache.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Wani shingen atom.
    ///
    /// Ana samun ingantaccen sigar wannan asalin a cikin [`atomic::fence`] ta wucewar [`Ordering::SeqCst`] azaman `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Wani shingen atom.
    ///
    /// Ana samun ingantaccen sigar wannan asalin a cikin [`atomic::fence`] ta wucewar [`Ordering::Acquire`] azaman `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Wani shingen atom.
    ///
    /// Ana samun ingantaccen sigar wannan asalin a cikin [`atomic::fence`] ta wucewar [`Ordering::Release`] azaman `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Wani shingen atom.
    ///
    /// Ana samun ingantaccen sigar wannan asalin a cikin [`atomic::fence`] ta wucewar [`Ordering::AcqRel`] azaman `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Mai toshewar ƙwaƙwalwar ajiya kawai.
    ///
    /// Ba za a taɓa sake samun damar shiga ƙwaƙwalwar ajiya ba a cikin wannan shingen ta mai tarawa, amma babu umarnin da za a fitar da shi.
    /// Wannan ya dace da aiki a kan zaren guda wanda za a iya saurin kamawa, kamar lokacin hulɗa tare da masu kula da sigina.
    ///
    /// Ana samun ingantaccen sigar wannan asalin a cikin [`atomic::compiler_fence`] ta wucewar [`Ordering::SeqCst`] azaman `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Mai toshewar ƙwaƙwalwar ajiya kawai.
    ///
    /// Ba za a taɓa sake samun damar shiga ƙwaƙwalwar ajiya ba a cikin wannan shingen ta mai tarawa, amma babu umarnin da za a fitar da shi.
    /// Wannan ya dace da aiki a kan zaren guda wanda za a iya saurin kamawa, kamar lokacin hulɗa tare da masu kula da sigina.
    ///
    /// Ana samun ingantaccen sigar wannan asalin a cikin [`atomic::compiler_fence`] ta wucewar [`Ordering::Acquire`] azaman `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Mai toshewar ƙwaƙwalwar ajiya kawai.
    ///
    /// Ba za a taɓa sake samun damar shiga ƙwaƙwalwar ajiya ba a cikin wannan shingen ta mai tarawa, amma babu umarnin da za a fitar da shi.
    /// Wannan ya dace da aiki a kan zaren guda wanda za a iya saurin kamawa, kamar lokacin hulɗa tare da masu kula da sigina.
    ///
    /// A stabilized version na wannan muhimmi shi ne samuwa a [`atomic::compiler_fence`] ta wucewa [`Ordering::Release`] matsayin `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Mai toshewar ƙwaƙwalwar ajiya kawai.
    ///
    /// Ba za a taɓa sake samun damar shiga ƙwaƙwalwar ajiya ba a cikin wannan shingen ta mai tarawa, amma babu umarnin da za a fitar da shi.
    /// Wannan ya dace da aiki a kan zaren guda wanda za a iya saurin kamawa, kamar lokacin hulɗa tare da masu kula da sigina.
    ///
    /// Ana samun ingantaccen sigar wannan asalin a cikin [`atomic::compiler_fence`] ta wucewar [`Ordering::AcqRel`] azaman `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic muhimmi da cewa ya sami asali da ma'anar daga halayen haɗe zuwa aiki.
    ///
    /// Alal misali, dataflow amfani da wannan allurar a tsaye assertions haka cewa `rustc_peek(potentially_uninitialized)` zai zahiri biyu-rajistan shiga cewa dataflow lalle lissafta cewa shi ne uninitialized a wancan batu a kula da kwarara.
    ///
    ///
    /// Kada a yi amfani da wannan mahimmanci a wajen mai tarawa.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts da kisa da tsari.
    ///
    /// A mafi amfani-friendly da kuma barga version na wannan aiki shi ne [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ya sanar da mai ba da kwarin gwiwa cewa wannan batu a cikin lambar ba za a iya riskar shi ba, yana ba da damar ingantawa.
    ///
    /// NB, wannan ne sosai daban-daban daga `unreachable!()` Macro: Ba kamar da Macro, wanda panics idan aka kashe, shi ne *maras bayyani hali* to kai code alama tare da wannan aiki.
    ///
    ///
    /// Sigar tsayayyar wannan asalin shine [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Sanar da dab'i cewa wani yanayin ne ko da yaushe gaskiya.
    /// Idan yanayin karya ne, ba a bayyana ma'anar ba.
    ///
    /// Babu code ne generated da wannan muhimmi, amma dab'i za su yi kokarin kiyaye shi (da kuma ta yanayin) tsakanin kafa, wanda zai iya tsoma baki tare da ingantawa da kewaye code da kuma rage aiki.
    /// Bai kamata ayi amfani dashi ba idan mai ingantawa zai iya gano mai canzawa a karan kansa, ko kuma idan ba zai iya samar da wasu abubuwan ingantawa ba.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Alamu ga mai tarawa cewa yanayin branch na iya zama gaskiya.
    /// Koma darajar wuce zuwa gare shi.
    ///
    /// Duk wani amfani banda bayanan `if` tabbas ba zai yi tasiri ba.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Alamu ga mai tattara bayanan cewa yanayin branch na iya zama ƙarya.
    /// Koma darajar wuce zuwa gare shi.
    ///
    /// Duk wani amfani banda bayanan `if` tabbas ba zai yi tasiri ba.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Yana aiwatar da tarko mai wuyar warwarewa, don dubawa ta mai lalatawa.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn breakpoint();

    /// A size of a irin a bytes.
    ///
    /// More musamman, wannan ne da biya diyya a bytes tsakanin m abubuwa da irin, ciki har da jeri padding.
    ///
    ///
    /// Sigar tsayayyar wannan asalin shine [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Mafi qarancin jeri na wani nau'i.
    ///
    /// A stabilized version na wannan muhimmi ne [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Daidaitaccen jeri na wani nau'in.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Girman darajar da aka ambata a cikin bytes.
    ///
    /// Sigar tsayayyar wannan asalin shine [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Daidaitawar da ake buƙata na darajar da aka ambata.
    ///
    /// A stabilized version na wannan muhimmi ne [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Ya sami yanki madaidaiciya yanki yanki dauke da sunan wani nau'in.
    ///
    /// Sigar tsayayyar wannan asalin shine [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Samun mai ganowa wanda ke duniya daban-daban ga takamaiman nau'in.
    /// Wannan aiki zai koma guda darajar for wani irin ko da kuwa kõwane ɗayan adadin crate shi da aka ambaci a.
    ///
    ///
    /// A stabilized version na wannan muhimmi ne [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Mai tsaro don ayyukan tsaro waɗanda ba za a taɓa kashe su ba idan `T` ba shi da zama:
    /// Wannan zai iya zama ko dai panic, ko kuma yin komai.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A matsara ga matsera ayyuka da cewa ba zai iya taba a kashe idan `T` bai ba da izinin sifili-initialization: Wannan zai statically ko dai panic, ko aikata kome ba.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn assert_zero_valid<T>();

    /// A matsara ga matsera ayyuka da cewa ba zai iya taba a kashe idan `T` yana da inganci bit alamu: Wannan zai statically ko dai panic, ko aikata kome ba.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn assert_uninit_valid<T>();

    /// Ya sami ishara zuwa wani tsayayyen `Location` wanda ke nuna inda aka kira shi.
    ///
    /// Ka yi la'akari da amfani da [`core::panic::Location::caller`](crate::panic::Location::caller) maimakon.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Matsar da ƙima daga girmanta ba tare da gudummawar mannawa ba.
    ///
    /// Wannan ya wanzu ne kawai don [`mem::forget_unsized`];al'ada `forget` tana amfani da `ManuallyDrop` maimakon.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Sake fassara fassarar ƙimar kowane nau'i azaman wani nau'in.
    ///
    /// Duk nau'ikan dole su kasance suna da girma iri ɗaya.
    /// Babu asali, ko sakamako, na iya zama [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ne semantically daidai da wata bitwise tafi na daya irin cikin wani.Yana kwafin ragowa daga ƙimar asalin zuwa ƙimar makoma, sannan ta manta da asali.
    /// Yana daidai da C ta `memcpy` karkashin kaho, kamar `transmute_copy`.
    ///
    /// Saboda `transmute` ne da-darajar aiki, jeri na *transmuted dabi'u kansu* ba wani damuwa.
    /// Kamar yadda da wani aiki, da mai tarawa riga tabbatar da duka biyu `T` da `U` suna da kyau masu hada kai.
    /// Duk da haka, a lokacin da transmuting dabi'u cewa *auna da sauran wurare*(kamar pointers, da ayoyi, da kwalaye ...), mai kira yana tabbatar da ta dace jeri na nuna-to dabi'u.
    ///
    /// `transmute` shine **wuce yarda** bashi da aminci.Akwai hanyoyi da yawa da yawa don haifar da [undefined behavior][ub] tare da wannan aikin.`transmute` yakamata ya zama cikakken makoma.
    ///
    /// A [nomicon](../../nomicon/transmutes.html) yana da ƙarin takardun.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Akwai 'yan abubuwa da `transmute` ne da gaske da amfani ga.
    ///
    /// Kunna akan cikin wani aiki akan.Wannan *ba* šaukuwa a cikin injuna inda masu nunin aiki da bayanan bayanai suke da girma dabam-dabam.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Mikawa a rayuwa, ko rage wani maras canjawa rayuwa.Wannan ne ci gaba, sosai unsafe Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Kada ku yanke ƙauna: da yawa amfani da `transmute` za a iya samu ta hanyar wasu hanyoyi.
    /// Kasa ne na kowa aikace-aikace na `transmute` wanda za a iya maye gurbinsu da mafi aminci gina.
    ///
    /// Juyawa raw bytes(`&[u8]`) zuwa `u32`, `f64`, da sauransu:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // yi amfani da `u32::from_ne_bytes` maimakon
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ko yi amfani da `u32::from_le_bytes` ko `u32::from_be_bytes` don tantance endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Kunna akan cikin wani `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Yi amfani da simintin `as` maimakon
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Kunna a `*mut T` cikin wani `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Yi amfani da reborrow maimakon
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Kunna wani `&mut T` cikin wani `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Yanzu, hada `as` da sake dawowa, lura da sarƙar `as` `as` ba ta wucewa
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Juyawa `&str` zuwa `&[u8]`:
    ///
    /// ```
    /// // wannan ba mai kyau hanya don yin wannan.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Za ka iya amfani da `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ko, kamar amfani da byte kirtani, idan kana da iko a kan kirtani na zahiri
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Juya `Vec<&T>` zuwa cikin `Vec<Option<&T>>`.
    ///
    /// Don canja ciki da irin abinda ke ciki na wani akwati, dole ne ka tabbatar da su ba karya wani daga cikin akwati ta invariants.
    /// Domin `Vec`, wannan yana nufin cewa duka size *kuma jeri* daga ciki iri daban-daban da su daidaita ba.
    /// Wasu kwantena iya dogara a kan girman da irin, jeri, ko da `TypeId`, wanda idan transmuting ba zai yiwu a duk ba tare da qetare ganga invariants.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone da vector kamar yadda za mu sake amfani da su daga baya
    /// let v_clone = v_orig.clone();
    ///
    /// // Amfani da transmute: wannan ya dogara ne da tsarin bayanan da ba a ƙayyade ba na `Vec`, wanda mummunan ra'ayi ne kuma zai iya haifar da Bea'idar da ba a Fayyace ta ba.
    /////
    /// // Koyaya, ba kwafin kwafi ne.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Wannan shine shawarar, hanya mai aminci.
    /// // Yana kwafin duk vector, kodayake, cikin sabon tsararru.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Wannan shi ne dace ba-kwafin, matsera hanyar "transmuting" a `Vec`, ba tare da dogaro a kan data layout.
    /// // Maimakon a zahiri kiran `transmute`, mun yi akan simintin, amma cikin sharuddan tana mayar da asali ciki irin (`&i32`) ga sabon daya (`Option<&i32>`), wannan yana da duk wannan caveats.
    /////
    /// // Bayan da bayanai bayar a sama, kuma shawarta da [`from_raw_parts`] takardun.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Sabunta wannan lokacin da aka ƙarfafa vec_into_raw_parts.
    ///     // Tabbatar da cewa ba a faɗi ainihin vector ba.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Aiwatar da `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Akwai mahara hanyoyin da za a yi wannan, da kuma akwai mahara matsaloli tare da wadannan (transmute) hanya.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // na farko: ya canja ba a rubuta lafiya.duk abin dubawa shine T da
    ///         // U suna da girma iri ɗaya.
    ///         // Na biyu, a nan, kuna da nassoshi guda biyu masu canzawa waɗanda ke nuna ƙwaƙwalwa ɗaya.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Wannan yana kawar da nau'in matsalolin aminci;`&mut *` za* kawai *ba ku da wani `&mut T` daga wani `&mut T` ko `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // duk da haka, har yanzu kuna da nassoshi guda biyu masu canzawa waɗanda ke nuna ƙwaƙwalwa ɗaya.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Wannan shine yadda ingantaccen ɗakin karatu ke yin sa.
    /// // Wannan shi ne kyakkyawar hanya, idan kana bukatar ka yi wani abu kamar wannan
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Wannan yanzu yana da uku mutable nassoshi nuna a wannan ƙwaƙwalwar.`slice`, da mara daraja ret.0, da kuma mara daraja ret.1.
    ///         // `slice` An taba amfani da bayan `let ptr = ...`, kuma haka wanda zai iya bi da shi kamar yadda "dead", sabili da haka, ku ne kawai da biyu real mutable yanka.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Duk da yake wannan ya sa maɓallin keɓaɓɓen mawuyacin hali, muna da wasu lambobin al'ada a cikin const fn
    // cak cewa hana ta yin amfani a cikin `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Koma `true` idan ainihin irin ba kamar yadda `T` bukatar drop manne.dawo da `false` idan ainihin nau'in da aka bayar don `T` ya aiwatar da `Copy`.
    ///
    ///
    /// Idan ainihin nau'in ba ya buƙatar sauke manna ko aiwatar da `Copy`, to ba za a bayyana darajar komowar wannan aikin ba.
    ///
    /// A stabilized version na wannan muhimmi ne [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calculates da biya diyya daga Pointer.
    ///
    /// Wannan ne ya aiwatar da matsayin muhimmi don kauce wa shiga addinin kuma daga wani lamba, tun da hira zai jifa aliasing bayanai.
    ///
    /// # Safety
    ///
    /// Duk mai nuna alama da farawa da mai biyowa dole ne ya zama ko dai a kan iyaka ko byte ɗaya ya wuce ƙarshen abin da aka ware.
    /// Idan mai nuna alama ya fita daga kan iyaka ko ambaliyar lissafi ta auku to duk wani ƙarin amfani da ƙimar da aka dawo zai haifar da halayyar da ba a bayyana ta ba.
    ///
    ///
    /// Sigar tsayayyar wannan asalin shine [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calculates da biya diyya daga Pointer, yiwuwar Kintsa.
    ///
    /// Wannan ne ya aiwatar da matsayin muhimmi don kauce wa shiga addinin kuma daga wani lamba, tun da hira damuarn wasu optimizations.
    ///
    /// # Safety
    ///
    /// Ba kamar na `offset` na asali ba, wannan mahimmin abu ba ya ƙuntata maɓallin nunawa don nunawa ko byte ɗaya ya wuce ƙarshen abin da aka keɓe, kuma yana nadewa tare da lissafin haɗin biyu.
    /// A sakamakon darajar ne ba dole ba ne inganci da za a yi amfani da su a zahiri damar žwažwalwar ajiya.
    ///
    /// Sigar tsayayyar wannan asalin shine [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Yayi daidai da ainihin `llvm.memcpy.p0i8.0i8.*` mai mahimmanci, tare da girman `count`*`size_of::<T>()` kuma daidaitawa na
    ///
    /// `min_align_of::<T>()`
    ///
    /// A maras tabbas siga an saita zuwa `true`, don haka shi ba zai iya gyara fita sai size ne ya daidaita da sifili.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Daidai da dace `llvm.memmove.p0i8.0i8.*` muhimmi, tare da wani size of `count* size_of::<T>()` da wani jeri na
    ///
    /// `min_align_of::<T>()`
    ///
    /// A maras tabbas siga an saita zuwa `true`, don haka shi ba zai iya gyara fita sai size ne ya daidaita da sifili.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Daidai da dace `llvm.memset.p0i8.*` muhimmi, tare da wani size of `count* size_of::<T>()` da wani jeri na `min_align_of::<T>()`.
    ///
    ///
    /// A maras tabbas siga an saita zuwa `true`, don haka shi ba zai iya gyara fita sai size ne ya daidaita da sifili.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Yana yin lodi mai nunawa daga maɓallin `src`.
    ///
    /// A stabilized version na wannan muhimmi ne [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Aikin wani maras tabbas kantin sayar da `dst` akan.
    ///
    /// A stabilized version na wannan muhimmi ne [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Aikin wani maras tabbas kaya daga `src` akan The Pointer, ba a bukatar da za a hada kai.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Aikin wani maras tabbas kantin sayar da `dst` akan.
    /// Ba a buƙatar mai nuna alama don daidaitawa.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Koma cikin square tushen na wani `f32`
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Yana dawo da asalin murabba'in `f64`
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Isesara `f32` zuwa ƙarfin lamba.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Isesara `f64` zuwa ƙarfin lamba.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Koma ga ba tare da wani `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Koma ga ba tare da wani `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Ya dawo da cosine na `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Koma da cosine na wani `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Isesara `f32` zuwa ikon `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Isesara `f64` zuwa ikon `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Koma da karuwa da sauri na wani `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Yana dawo da ƙimar `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Dawowar 2 da aka ɗaga zuwa ikon `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Koma 2 tãyar da su da ikon wani `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Ya dawo da logarithm na asali na `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Koma da na halitta logarithm na wani `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Yana dawo da logarithm 10 na `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Koma tushe 10 logarithm na wani `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Yana dawo da asalin logarithm na `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Yana dawo da asalin logarithm na `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Koma `a * b + c` for `f32` dabi'u.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Koma `a * b + c` for `f64` dabi'u.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Ya dawo da cikakken darajar `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Ya dawo da cikakken darajar `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Koma da ƙaramar na biyu `f32` dabi'u.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Koma da ƙaramar na biyu `f64` dabi'u.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Yana dawo da ƙimar darajar `f32` biyu.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Yana dawo da ƙimar darajar `f64` biyu.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kofe da ãyã daga `y` zuwa `x` for `f32` dabi'u.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kwafi alamar daga `y` zuwa `x` don ƙimar `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Dawo da most lamba kasa fi ko daidai to wani `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Ya dawo mafi yawan adadin da bai kai ko daidai da `f64` ba.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Koma da karami lamba fi ko daidai to wani `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Ya dawo da ƙaramin lamba wanda ya fi girma ko daidai da `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Ya dawo da ɓangaren adadin lamba na `f32`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Koma ga lamba wani ɓangare na wani `f64`.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Ya mayar da lamba mafi kusa zuwa `f32`.
    /// Iya ta da wani inexact iyo-aya togiya idan hujjarsu ba wani lamba.
    pub fn rintf32(x: f32) -> f32;
    /// Ya mayar da lamba mafi kusa zuwa `f64`.
    /// Iya ta da wani inexact iyo-aya togiya idan hujjarsu ba wani lamba.
    pub fn rintf64(x: f64) -> f64;

    /// Ya mayar da lamba mafi kusa zuwa `f32`.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ya mayar da lamba mafi kusa zuwa `f64`.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Koma mafi kusa lamba zuwa wani `f32`.Undsididdigar shari'o'in rabin hanya daga sifili.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Koma mafi kusa lamba zuwa wani `f64`.Akai-akai rabin hanya lokuta daga sifili.
    ///
    /// Sigar ingantaccen yanayin wannan yanayin shine
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Additionari na kan ruwa wanda ke ba da damar haɓaka dangane da dokokin algebraic.
    /// Iya xaukar bayanai ne guntun.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Taso kan ruwa subtraction da damar optimizations dangane algebraic dokoki.
    /// Iya xaukar bayanai ne guntun.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Taso kan ruwa multiplication da damar optimizations dangane algebraic dokoki.
    /// Iya xaukar bayanai ne guntun.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Rarraba kan ruwa wanda ke ba da damar ingantawa dangane da dokokin algebraic.
    /// Iya xaukar bayanai ne guntun.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Ragowar jirgin ruwa wanda ke ba da damar ingantawa dangane da dokokin algebraic.
    /// Iya xaukar bayanai ne guntun.
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Canza tare da LLVM's fptoui/fptosi, wanda zai iya dawo da undef don ƙimomin daga nesa
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// An daidaita matsayin [`f32::to_int_unchecked`] da [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Ya dawo da adadin ragogin da aka saita a cikin nau'in lamba `T`
    ///
    /// Ana samun ingantattun sifofin wannan asalin a kan abubuwan da aka saba amfani dasu ta hanyar hanyar `count_ones`.
    /// Misali,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Koma yawan manyan unset ragowa (zeroes) a wani lamba irin `T`.
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `leading_zeros`.
    /// Misali,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` mai darajar `0` zai dawo da ɗan faɗin `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Kamar `ctlz`, amma ƙari-amintacce yayin da yake dawo da `undef` lokacin da aka bashi `x` tare da darajar `0`.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Koma yawan trailing unset ragowa (zeroes) a wani lamba irin `T`.
    ///
    /// A stabilized versions wannan muhimmi ne samuwa a kan lamba primitives via da `trailing_zeros` Hanyar.
    /// Misali,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` mai darajar `0` zai dawo da ɗan faɗin `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Kamar `cttz`, amma karin-unsafe kamar yadda ta kõma `undef` lokacin da ba wani `x` da darajar `0`.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Reverses da bytes a wani lamba irin `T`.
    ///
    /// A stabilized versions wannan muhimmi ne samuwa a kan lamba primitives via da `swap_bytes` Hanyar.
    /// Misali,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Reverses da ragowa, a wani lamba irin `T`.
    ///
    /// A stabilized versions wannan muhimmi ne samuwa a kan lamba primitives via da `reverse_bits` Hanyar.
    /// Misali,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Yana yin ƙarin adadin lamba.
    ///
    /// A stabilized versions wannan muhimmi ne samuwa a kan lamba primitives via da `overflowing_add` Hanyar.
    /// Misali,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yana yin ragi mai lamba
    ///
    /// A stabilized versions wannan muhimmi ne samuwa a kan lamba primitives via da `overflowing_sub` Hanyar.
    /// Misali,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Aikin bari lamba multiplication
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `overflowing_mul`.
    /// Misali,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yi cikakken rabo, wanda ke haifar da halayyar da ba a bayyana ba inda `x % y != 0` ko `y == 0` ko `x == T::MIN && y == -1`
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Yana aiwatar da rarrabuwa wanda ba a tantance shi ba, wanda ke haifar da halayyar da ba a bayyana ta ba inda `y == 0` ko `x == T::MIN && y == -1`
    ///
    ///
    /// Ana samun wadatattun masu kunshin wannan mahimmancin a kan abubuwan haɓaka na lamba ta hanyar hanyar `checked_div`.
    /// Misali,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Koma saura daga wani zũciyõyinsu, division, sakamakon maras bayyani hali a lokacin da `y == 0` ko `x == T::MIN && y == -1`
    ///
    ///
    /// Safe wrappers ga wannan muhimmi ne samuwa a kan lamba primitives via da `checked_rem` Hanyar.
    /// Misali,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Yana yin canjin hagu wanda ba a duba shi ba, wanda ke haifar da halayyar da ba a bayyana ta lokacin da `y < 0` ko `y >= N`, inda N yake da nisa na T a ragowa.
    ///
    ///
    /// Ana samun wadatattun masu kunshin wannan mahimmancin a kan abubuwan haɓaka na lamba ta hanyar hanyar `checked_shl`.
    /// Misali,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Aikin wani zũciyõyinsu, ba dama motsa, sakamakon maras bayyani hali a lokacin da `y < 0` ko `y >= N`, inda N ne da nisa daga T a ragowa.
    ///
    ///
    /// Ana samun wadatattun masu kunshin wannan mahimmancin a kan abubuwan haɓaka na lamba ta hanyar hanyar `checked_shr`.
    /// Misali,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Koma sakamakon wani zũciyõyinsu, Bugu da kari, sakamakon maras bayyani hali a lokacin da `x + y > T::MAX` ko `x + y < T::MIN`.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Koma sakamakon wani zũciyõyinsu, subtraction, sakamakon maras bayyani hali a lokacin da `x - y > T::MAX` ko `x - y < T::MIN`.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Mayar da sakamakon yawan bazuka ne, wanda ke haifar da halayyar da ba a bayyana ta lokacin da `x *y > T::MAX` ko `x* y < T::MIN`.
    ///
    ///
    /// Wannan mahimmin abu ba shi da tsayayyen takwaransa.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Yi juyawa hagu.
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `rotate_left`.
    /// Misali,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Yi juyawa dama.
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `rotate_right`.
    /// Misali,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Koma (a + b) Mod 2 <sup>N,</sup> inda N ne da nisa daga T a ragowa.
    ///
    /// A stabilized versions wannan muhimmi ne samuwa a kan lamba primitives via da `wrapping_add` Hanyar.
    /// Misali,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Ya dawo (a, b) zamani na 2 <sup>N</sup>, inda N yake da nisa na T a cikin ragowa.
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `wrapping_sub`.
    /// Misali,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Koma (a * b) Mod 2 <sup>N,</sup> inda N ne da nisa daga T a ragowa.
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `wrapping_mul`.
    /// Misali,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating a Tazarar haddi.
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `saturating_add`.
    /// Misali,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ididdiga `a - b`, saturating a iyakan iyaka.
    ///
    /// Ana samun sifofin ingantaccen wannan muhimmin abu akan ingantattun abubuwa ta hanyar hanyar `saturating_sub`.
    /// Misali,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Koma tamanin da discriminant ga bambance-bambancen a 'v'.
    /// idan `T` yana da wani discriminant, ya kõma `0`.
    ///
    /// A stabilized version na wannan muhimmi ne [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Ya dawo da adadin bambance-bambancen nau'in nau'in `T` da aka jefa zuwa `usize`;
    /// idan `T` yana da wani bambance-bambancen karatu, ya dawo `0`.Za'a kidaya bambance-bambancen da ba mazauni
    ///
    /// Siffar da za'a tsayar da wannan ma'anar ita ce [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust ta "try catch" gina wanda ya kira, da aiki akan `try_fn` tare da data akan `data`.
    ///
    /// The uku hujjarsu wani aiki kira idan wani panic faruwa.
    /// Wannan aikin yana ɗaukar bayanan bayanai da mai nunawa zuwa takamaiman ƙayyadadden abin da aka kama.
    ///
    /// Don ƙarin bayani duba tarawa ta source kazalika std ta kama aiwatar.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Nemi shagon `!nontemporal` bisa ga LLVM (duba takaddun su).
    /// Kila ba zai zama barga.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Dubi takaddun `<*const T>::offset_from` don cikakkun bayanai.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Dubi takardun na `<*const T>::guaranteed_eq` domin cikakkun bayanai.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Dubi takardun na `<*const T>::guaranteed_ne` domin cikakkun bayanai.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Raba a tara lokaci.Kamata ba za a kira a Runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Wasu ayyuka suna tsare a nan, saboda sun bazata samu sanya samuwa a cikin wannan module a barga.
// Dubi <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` ma da dama a cikin wannan rukuni, amma ba za a iya nannade saboda rajistan cewa `T` da `U` da wannan size.)
//

/// Cak ko `ptr` ne ya kamata masu hada kai tare da girmamawa ga `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kofe `count *size_of::<T>()` bytes daga `src` zuwa `dst`.A tushen da kuma manufa dole ne* ba * zoba.
///
/// Domin yankuna na memory wanda zai zoba, yi amfani da [`copy`] maimakon.
///
/// `copy_nonoverlapping` ne semantically daidai C ta [`memcpy`], amma tare da shawara domin swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `src` dole ne ya zama [valid] don karatun baiti `count * size_of::<T>()`.
///
/// * `dst` dole ne ya zama [valid] don rubuta na `count * size_of::<T>()` bytes.
///
/// * Dukansu `src` da `dst` dole ne a yadda ya kamata hada kai.
///
/// * Yankin ƙwaƙwalwar ajiya wanda ya fara a `src` tare da girman `` ƙidaya *
///   Girman: :<T>() `` baiti dole ne *kada* ya ruɓe tare da yankin ƙwaƙwalwar ajiyar farawa daga `dst` tare da girm ɗaya.
///
/// Kamar [`read`], `copy_nonoverlapping` ya ƙirƙiri ɗan kwafin `T`, ba tare da la'akari ko `T` shine [`Copy`] ba.
/// Idan `T` ba [`Copy`] bane, ta amfani da *duka* ƙimomin a cikin yankin farawa daga `*src` kuma yankin da ya fara daga `* dst` zai iya [violate memory safety][read-ownership].
///
///
/// Lura cewa ko da an kwafin girman yadda yakamata (``ƙidaya * size_of: :<T>()`` shine `0`, masu nunin dole ne su zama ba NULL ba kuma su dace sosai.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Aiwatar da [`Vec::append`] da hannu:
///
/// ```
/// use std::ptr;
///
/// /// Matsar da dukkan abubuwan da ke cikin `src` zuwa `dst`, suna barin `src` fanko.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Tabbatar da cewa `dst` yana da isasshen damar rike duk `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Kira don sake biya koyaushe yana da aminci saboda `Vec` ba zai taɓa rarraba sama da baiti `isize::MAX` ba.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` ba tare da sauke abin da ke ciki ba.
///         // Mun yi wannan na farko, don kauce wa matsalolin da idan wani abu kara saukar panics.
///         src.set_len(0);
///
///         // Yankuna biyu ba zai iya zoba domin mutable nassoshi yi ba aka ce masa, da kuma biyu daban-daban vectors ba zai iya mallaka guda memory.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Sanar da `dst` cewa shi yanzu riqe da abinda ke ciki na `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Yi waɗannan cak ne kawai a lokacin gudu
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ba tsoro ba don ci gaba da tasirin codegen karami.
        abort();
    }*/

    // KYAUTA: kwangilar aminci ga `copy_nonoverlapping` dole ne ta kasance
    // tsayar da kira.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kwafa `count * size_of::<T>()` baiti daga `src` zuwa `dst`.A tushen da kuma manufa na iya zoba.
///
/// Idan tushe da makoma zasu *taba* ruɓewa, za'a iya amfani da [`copy_nonoverlapping`] a madadin.
///
/// `copy` ne semantically daidai C ta [`memmove`], amma tare da shawara domin swapped.
/// Ana yin kwafin ne kamar dai an kwafa bytes daga `src` zuwa tsararren lokaci sannan a kwafe daga tsararru zuwa `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `src` dole ne ya zama [valid] don karatun baiti `count * size_of::<T>()`.
///
/// * `dst` dole ne ya zama [valid] don rubuta na `count * size_of::<T>()` bytes.
///
/// * Dukansu `src` da `dst` dole ne a yadda ya kamata hada kai.
///
/// Kamar [`read`], `copy` ya ƙirƙiri ɗan kwafin `T`, ba tare da la'akari ko `T` shine [`Copy`] ba.
/// Idan `T` ba [`Copy`] bane, ta amfani da duka ƙimomin yankin da ke farawa daga `*src` da yankin da yake farawa a `* dst` na iya [violate memory safety][read-ownership].
///
///
/// Lura cewa ko da an kwafin girman yadda yakamata (``ƙidaya * size_of: :<T>()`` shine `0`, masu nunin dole ne su zama ba NULL ba kuma su dace sosai.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Nagarta sosai ƙirƙirar Rust vector daga wani unsafe buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` Dole ne a daidai hada kai domin da irin da kuma wadanda ba sifili.
/// /// * `ptr` dole ne su kasance da inganci ga karanta `elts` contiguous abubuwa na irin `T`.
/// /// * Wadanda abubuwa dole ba za a yi amfani da bayan kiran wannan aiki har `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // KYAUTA: Sharadin mu na tabbatar da cewa tushen ya daidaita kuma yana aiki,
///     // kuma `Vec::with_capacity` yana tabbatar da cewa muna da sarari mai amfani don rubuta su.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // KIYAYEWAR: Mun halitta shi tare da wannan yawa damar baya,
///     // kuma `copy` da ta gabata ta ƙaddamar da waɗannan abubuwan.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Yi waɗannan cak ne kawai a lokacin gudu
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ba tsoro ba don ci gaba da tasirin codegen karami.
        abort();
    }*/

    // KYAUTA: kwangilar aminci ga `copy` dole ne mai kiran ya kiyaye ta.
    unsafe { copy(src, dst, count) }
}

/// Ya kafa baiti na ƙwaƙwalwar `count * size_of::<T>()` wanda ya fara daga `dst` zuwa `val`.
///
/// `write_bytes` yayi kama da C's [`memset`], amma yana saita baiti `count * size_of::<T>()` zuwa `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Ba'a bayyana halayya idan an keta ɗaya daga cikin sharuɗɗan masu zuwa:
///
/// * `dst` dole ne ya zama [valid] don rubuta na `count * size_of::<T>()` bytes.
///
/// * `dst` Dole ne a yadda ya kamata hada kai.
///
/// Bugu da ƙari, mai kira dole ne tabbatar da cewa rubutu `count * size_of::<T>()` bytes da aka yankin na memory sakamakon a wani m darajar `T`.
/// Amfani da yankin ƙwaƙwalwar da aka buga a matsayin `T` wanda ke ƙunshe da ƙimar mara inganci na `T` halayyar da ba a bayyana ta ba.
///
/// Lura cewa ko da an kwafin girman yadda yakamata (``ƙidaya * size_of: :<T>()`) Ne `0`, da Pointer dole ba null da kuma yadda ya kamata masu hada kai.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Amfani na asali:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ingirƙirar ƙima mara inganci:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Bayar da ƙimar da aka riƙe ta baya ta sake yin rubutun `Box<T>` tare da maɓallin null.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // A wannan lokaci, ta yin amfani da ko faduwa `v` sakamakon a maras bayyani hali.
/// // drop(v); // ERROR
///
/// // Ko da malalewa `v` "uses" shi, don haka ya zama halin da ba a bayyana ba.
/// // mem::forget(v); // ERROR
///
/// // A gaskiya ma, `v` ba shi da inganci bisa ga asali irin layout invariants, don haka *wani* aiki m shi ne maras bayyani hali.
/////
/// // bari v2 =v.//ERROR
///
/// unsafe {
///     // Bari mu sanya maimakon hakan cikin ƙimar dacewa
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Yanzu akwatin yayi kyau
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // KIYAYEWAR: aminci kwangila ga `write_bytes` dole ne a tsayar da kira.
    unsafe { write_bytes(dst, val, count) }
}