//! Mai haɗaka asynchronous iteration.
//!
//! Idan futures ne asynchronous dabi'u, sa'an nan kõguna suna asynchronous iterators.
//! Idan kun sami kanku tare da wani nau'in asynchronous, kuma kuna buƙatar yin aiki akan abubuwanda aka faɗi tarin, zaku yi saurin shiga cikin 'streams'.
//! Ana amfani da rafi sosai a cikin lambar Rust mara kyau, don haka ya cancanci zama sananne da su.
//!
//! Kafin bayanin more, bari magana game da yadda wannan module ne tsari:
//!
//! # Organization
//!
//! Wannan tsarin an tsara shi ta hanyar nau'i:
//!
//! * [Traits] sune ainihin ɓangaren: waɗannan traits suna ƙayyade wane irin rafuka ne da abin da zaka iya yi dasu.Hanyoyin waɗannan traits sun cancanci saka ƙarin lokacin karatu a ciki.
//! * Ayyuka suna ba da wasu hanyoyi masu taimako don ƙirƙirar wasu rafuka na asali.
//! * Ruungiyoyi galibi sune nau'ikan dawo da hanyoyi daban-daban akan traits na wannan rukunin.Za ku ji yawanci so a dubi Hanyar cewa halitta da `struct`, maimakon `struct` kanta.
//! Don ƙarin bayani game da dalilin, duba '[Aiwatar da rafi](#aiwatarwa-rafi)'.
//!
//! [Traits]: #traits
//!
//! Shi ke nan!Bari mu shiga cikin rafuka.
//!
//! # Stream
//!
//! Zuciya da ruhin wannan rukunin shine [`Stream`] trait.Jigon [`Stream`] yayi kama da wannan:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Ba kamar `Iterator` ba, `Stream` ya banbanta tsakanin hanyar [`poll_next`] wacce ake amfani da ita yayin aiwatar da `Stream`, da hanyar (to-be-implemented) `next` wacce ake amfani da ita yayin cin rafi.
//!
//! Masu amfani da `Stream` kawai suna buƙatar la'akari da `next`, wanda lokacin da aka kira shi, ya dawo da future wanda ya samar da `Option<Stream::Item>`.
//!
//! future da `next` ya dawo zai ba da `Some(Item)` muddin akwai abubuwa, kuma da zarar sun gama duka, za su ba da `None` don nuna cewa an gama zance.
//! Idan muna jira akan wani abu mara kyau don warwarewa, future zai jira har sai rafin ya shirya ya sake samarwa.
//!
//! Kogunan mutum na iya zaɓar sake farawa, don haka kiran `next` zai iya sake ko kuma ba zai iya ba da `Some(Item)` ba a wani lokaci.
//!
//! Cikakkiyar ma'anar ta "``Stream` '' ta hada da wasu sauran hanyoyin kuma, amma su hanyoyi ne na asali, wadanda aka gina su a saman [`poll_next`], don haka sai ka same su kyauta.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Aiwatar da Rafi
//!
//! Samar da wani rafi da naka ya shafi matakai biyu: da samar da wani `struct` rike rafi ta jihar, sa'an nan aiwatar [`Stream`] ga cewa `struct`.
//!
//! Bari muyi rafi mai suna `Counter` wanda ya kirga daga `1` zuwa `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Na farko, tsarin:
//!
//! /// A rafi wanda kirga daga daya zuwa biyar
//! struct Counter {
//!     count: usize,
//! }
//!
//! // muna so mu count zuwa fara a daya, saboda haka bari mu ƙara new() Hanyar to taimako.
//! // Wannan ba ya zama tilas, amma shi ne ya dace.
//! // Lura cewa mun fara `count` a sifili, zamu ga dalilin da yasa a aiwatar da `poll_next()`'s a ƙasa.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Bayan haka, zamu aiwatar da `Stream` don `Counter` ɗinmu:
//!
//! impl Stream for Counter {
//!     // zamu kasance muna ƙidaya tare da amfani
//!     type Item = usize;
//!
//!     // poll_next() ne kawai ake bukata Hanyar
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Mentara yawanmu.Wannan shine dalilin da yasa muka fara sifili.
//!         self.count += 1;
//!
//!         // Duba ka gani ko mun gama kirgawa ko a'a.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Kõguna suna *m*.Wannan yana nufin cewa kawai ƙirƙirar rafi ba _do_ gaba ɗaya ba.Babu wani abu da zai faru da gaske har sai kun kira `next`.
//! Wannan wani lokacin tushen rikicewa ne yayin ƙirƙirar rafi kawai don tasirin sa.
//! Mai tarawa zai gargaɗe mu game da irin wannan ɗabi'ar:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;