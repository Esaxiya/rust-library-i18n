use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Hanyar ma'amala don ma'amala da masu ba da izini na asynchronous.
///
/// Wannan shine babban rafin trait.
/// Don ƙarin bayani game da batun rafuffuka gabaɗaya, da fatan za a duba [module-level documentation].
/// Musamman, kuna so ku san yadda ake [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Nau'in abubuwan da aka bayar ta rafin.
    type Item;

    /// Oƙarin cire ƙimar gaba ta wannan rafin, yin rijistar aikin yanzu don farkawa idan ƙimar ba ta riga ta samo ba, da dawowa `None` idan rafin ya ƙare.
    ///
    /// # Komawa darajar
    ///
    /// Akwai da dama yiwu koma dabi'u, kowane isharar jinsin rafi jihar:
    ///
    /// - `Poll::Pending` nufin cewa wannan rafi ta gaba darajar ba a shirye tukuna.Implementations zai tabbatar da cewa yanzu aiki za a sanar a lokacin da na gaba darajar iya zama a shirye.
    ///
    /// - `Poll::Ready(Some(val))` yana nufin cewa rafin ya sami nasarar samar da ƙima, `val`, kuma yana iya samar da ƙarin ƙimomi akan kira na `poll_next` na gaba.
    ///
    /// - `Poll::Ready(None)` yana nufin cewa rafin ya ƙare, kuma ba za a sake kiran `poll_next` ba.
    ///
    /// # Panics
    ///
    /// Da zarar rafi ya gama (ya dawo da `Ready(None)` from `poll_next`), yana sake kiran hanyar `poll_next` ɗinsa zai iya panic, toshe shi har abada, ko haifar da wasu matsaloli; `Stream` trait baya sanya buƙatu akan tasirin irin wannan kiran.
    ///
    /// Koyaya, kamar yadda ba a yiwa hanyar `poll_next` alama ba `unsafe`, ƙa'idodin ƙa'idodin Rust suna amfani da su: kira dole ne ya taɓa haifar da halayyar da ba a bayyana ba (gurɓataccen ƙwaƙwalwar ajiya, kuskuren amfani da ayyukan `unsafe`, ko makamancin haka), ba tare da la'akari da yanayin rafin ba.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Yana dawo da haddi akan ragowar ragowar rafin.
    ///
    /// Musamman, `size_hint()` kõma a tuple inda na farko kashi ne ƙananan ɗaure ciki daidai, da kuma na biyu da rabi ne babba a ɗaure.
    ///
    /// Rabin na biyu na abin da aka dawo dashi shi ne ``'' zaɓi ']`` ``' '' '' '' '' ''.
    /// A [`None`] nan nufin cewa ko dai akwai wani da aka sani babba ɗaure ciki daidai, ko da na sama a ɗaure shi ne ya fi girma fiye [`usize`].
    ///
    /// # aiwatar rubutu
    ///
    /// Ba a tilasta aiwatar da shi cewa aiwatarwar rafi yana haifar da adadin abubuwan da aka ayyana.Ruwan igiyar ruwa mai haɗari na iya samar ƙasa da ƙananan igiya ko sama da ƙananan abubuwan abubuwa.
    ///
    /// `size_hint()` da farko ana nufin amfani da shi don ingantawa kamar ajiyar sarari don abubuwan rafin, amma kada a amince da su misali, ƙetare cak a cikin lambar hadari.
    /// Rashin aiwatar da `size_hint()` bai kamata ya haifar da take hakkin aminci ba.
    ///
    /// Wannan ce, da aiwatar kamata samar da wani daidai hakkin, saboda in ba haka ba zai zama wani take hakkin da trait ta yarjejeniya.
    ///
    /// The default aiwatar dawo `(0,` [`None`] ')` wanda shi ne daidai ga wani rafi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}