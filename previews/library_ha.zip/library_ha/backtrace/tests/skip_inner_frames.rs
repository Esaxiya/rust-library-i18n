use backtrace::Backtrace;

// Wannan gwajin yana aiki ne kawai a kan dandamali wanda ke da aikin `symbol_address` mai aiki don sigogi wanda ke bayar da rahoton adireshin farawa na alama.
// Sakamakon haka kawai ana kunna shi a kan wasu 'yan dandamali.
//
const ENABLED: bool = cfg!(all(
    // Windows ba a gwada shi da gaske ba, kuma OSX ba ya goyan bayan ainihin gano ƙira, don haka musaki wannan
    //
    target_os = "linux",
    // Akan ARM gano aikin sakawa shine kawai dawo da ip kanta.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}