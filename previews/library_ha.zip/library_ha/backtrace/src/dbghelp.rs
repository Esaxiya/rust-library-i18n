//! A koyaushe domin taimakawa a manajan dbghelp bindings a kan Windows
//!
//! Bayanin baya akan Windows (aƙalla don MSVC) ana yin amfani da ƙarfi ta hanyar `dbghelp.dll` da ayyuka daban-daban da ya ƙunsa.
//! Wadannan ayyukan a halin yanzu ana ɗora su a tsaye * maimakon haɗi zuwa `dbghelp.dll` a zahiri.
//! Wannan halin yanzu yi da misali library (kuma shi ne a ka'idar da ake bukata a can), amma shi ne wani kokarin taimakon rage canzawa DLL dependencies na a library tun backtraces ne yawanci kyawawan tilas ba ne.
//!
//! Wannan ake ce, `dbghelp.dll` kusan ko da yaushe nasarar lodi a kan Windows.
//!
//! Note da yake cewa tun muna loading duk wannan da goyon bayan da kuzari ba za mu iya zahiri amfani da albarkatun ma'anar a `winapi`, amma dai muna bukatar ayyana aiki akan iri da kanmu da kuma yin amfani da.
//! Ba da gaske muke so mu kasance cikin kasuwancin kwafin winapi ba, don haka muna da fasalin Cargo `verify-winapi` wanda ke tabbatar da cewa duk ɗaurin ɗayan sun dace da waɗanda ke winapi kuma an kunna wannan fasalin akan CI.
//!
//! A ƙarshe, zaku lura anan cewa dll don `dbghelp.dll` ba a taɓa sauke shi ba, kuma wannan a halin yanzu da gangan ne.
//! Tunanin shine cewa zamu iya adana shi a duniya kuma muyi amfani dashi tsakanin kira zuwa API, guje ma tsada loads/unloads.
//! Idan wannan matsala ce ga masu gano ruwa ko wani abu makamancin haka zamu iya tsallaka gadar idan muka isa wurin.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Yi aiki kusa da `SymGetOptions` da `SymSetOptions` kasancewar ba su cikin winapi kanta ba.
// In ba haka ba ana amfani da wannan ne kawai lokacin da muke binciken nau'ikan biyu akan winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ba a bayyana cikin winapi ba tukuna
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // An bayyana wannan a winapi, amma ba daidai bane (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ba a bayyana cikin winapi ba tukuna
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Wannan Macro da ake amfani da su ayyana wani `Dbghelp` Gininsu, wanda ƙ ƙunshi dukkan aikin pointers cewa muna iya load.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL da aka ɗora akan `dbghelp.dll`
            dll: HMODULE,

            // Kowane manunin aiki ga kowane aiki da zamu iya amfani da shi
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Da farko bamu loda DLL ba
            dll: 0 as *mut _,
            // Initiall da dukkan ayyuka da an saita zuwa sifili zuwa ce suna bukatar da za a ɗora Kwatancen da kuzari.
            //
            $($name: 0,)*
        };

        // Sauƙaƙe typedef ga kowane nau'in aiki.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tooƙarin buɗe `dbghelp.dll`.
            /// Koma nasara idan yana aiki ko kuskure idan `LoadLibraryW` kasa.
            ///
            /// Panics idan an riga an loda ɗakin karatu.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Aiki ga kowace hanyar da muke son amfani da ita.
            // Lokacin da aka kira shi zai karanta maɓallin aikin ɓoye ko ɗora shi kuma ya dawo da ƙimar da aka ɗora.
            // An tabbatar da ɗora kaya don cin nasara.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Saukaka wakili don amfani da cleanup kwa'di to reference dbghelp ayyuka.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Alizeaddamar da duk goyon bayan da ake buƙata don samun damar ayyukan `dbghelp` API daga wannan crate.
///
///
/// Lura cewa wannan aikin **mai lafiya**, a ciki yana da aiki tare na kansa.
/// Har ila yau lura cewa yana da lafiya kiran wannan aikin sau da yawa sauƙaƙewa.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Abu na farko da yakamata muyi shine don daidaita wannan aikin.Ana iya kiran wannan lokaci ɗaya daga wasu zaren ko sake dawowa cikin zare ɗaya.
        // Lura cewa ya fi wannan wahalar fahimta saboda abin da muke amfani da shi a nan, `dbghelp`,*shima* yana buƙatar aiki tare da duk sauran masu kira zuwa `dbghelp` a cikin wannan aikin.
        //
        // Yawanci akwai ba sosai cewa da yawa da kira zuwa `dbghelp` a cikin wannan tsari, kuma ba za mu iya yiwuwa a amince zaton cewa za mu yi ne kawai suke samun dama da shi.
        // Akwai, kodayake, wani mai amfani na farko dole ne mu damu game da abin da ke kanmu, amma a cikin ɗakunan karatu na yau da kullun.
        // A Rust misali library dogara a kan wannan crate for backtrace support, kuma wannan crate ma wanzu a kan crates.io.
        // Wannan yana nufin cewa idan daidaitaccen laburaren yana buga panic baya zai iya tsere tare da wannan crate yana zuwa daga crates.io, yana haifar da ɓarna.
        //
        // Don taimakawa warware wannan matsalar aiki tare muna amfani da wata takamaiman Windows a nan (shi ne, bayan duk, takamaiman takamaiman Windows game da aiki tare).
        // Mun kirkiro *zaman-gida* mai suna mutex kare wannan kira.
        // Manufa a nan ita ce, ɗakunan karatu na yau da kullun da wannan crate bai kamata su raba matakan Rust na API don aiki tare a nan ba amma a maimakon haka suna iya yin aiki a bayan fage don tabbatar da cewa suna aiki tare da juna.
        //
        // Wannan hanya a lokacin da wannan aiki da aka kira ta hanyar daidaitaccen library ko ta hanyar crates.io za mu iya tabbata cewa wannan mutex da ake samu.
        //
        // Don haka duk wannan shine a faɗi cewa farkon abin da muke yi anan shine ƙirƙirar `HANDLE` wanda yake shine mutex mai suna Windows.
        // Muna aiki tare kaɗan tare da sauran zaren raba wannan aikin musamman kuma muna tabbatar da cewa madaidaiciya ɗaya kawai aka ƙirƙira ta kowane misali na wannan aikin.
        // Lura cewa ba a taɓa riƙe madafin lokacin da aka adana shi a cikin duniya.
        //
        // Bayan mun zahiri tafi da kulle mu kawai saya da shi, kuma mu `Init` rike mu mika fitar zai zama alhakin faduwa shi ƙarshe.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Yanzu duk muna aiki lafiya, bari mu fara aiwatar da komai.
        // Farko har muna bukatar mu tabbatar da cewa `dbghelp.dll` ne a zahiri ɗora Kwatancen a cikin wannan tsari.
        // Muna yin wannan ne gaba ɗaya don kauce wa dogaro na yau da kullun.
        // Anyi wannan don tarihi don aiki kusa da alaƙa da lamuran lamuran kuma ana nufin sa binaries a ɗan ƙaramin motsi tunda wannan galibi kawai mai amfani ne mai lalatawa.
        //
        //
        // Da zarar mun buɗe `dbghelp.dll` muna buƙatar kiran wasu ayyukan farawa a ciki, kuma wannan yana da cikakken bayani a ƙasa.
        // Muna yin wannan sau ɗaya kawai, kodayake, saboda haka muna da tutturarwa ta duniya da ke nuna ko mun gama ko ba mu kammala ba.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Tabbatar cewa an saita tutar `SYMOPT_DEFERRED_LOADS`, saboda bisa ga takaddun MSVC game da wannan: "This is the fastest, most efficient way to use the symbol handler.", don haka bari muyi haka!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // A gaskiya initialize alamomin da MSVC.Lura cewa wannan na iya kasawa, amma muna watsi da shi.
        // Babu wata fasaha ta fasaha ta wannan don wannan, amma LLVM a ciki yana kama da watsi da ƙimar dawowa a nan kuma ɗayan dakunan karatu a cikin LLVM yana buga faɗakarwa mai ban tsoro idan wannan ya kasa amma yana watsi da shi a cikin dogon lokaci.
        //
        //
        // Wata shari'ar da ta zo da yawa ga Rust shine daidaitaccen ɗakin karatu da wannan crate akan crates.io duk suna son yin gasa don `SymInitializeW`.
        // Daidaitaccen laburaren tarihi yana son farawa sannan tsaftacewa mafi yawan lokuta, amma yanzu da yake amfani da wannan crate yana nufin cewa wani zai fara farawa dayan kuma zai karɓi wannan ƙaddamarwar.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}