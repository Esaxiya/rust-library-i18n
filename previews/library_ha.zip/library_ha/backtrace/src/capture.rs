use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Wakilcin abin da aka mallaka da abin da aka mallaka.
///
/// Wannan tsarin za a iya amfani da su kama a backtrace a daban-daban maki a wani shirin da daga baya amfani da su duba abin da backtrace shi ne a wancan lokaci.
///
///
/// `Backtrace` yana tallafawa kyakkyawa-buga bayanan baya ta hanyar aiwatarwar `Debug`.
///
/// # Abubuwan da ake buƙata
///
/// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Frames a nan an jera daga sama zuwa ƙasa na tari
    frames: Vec<BacktraceFrame>,
    // Theididdigar da muka yi imani shine ainihin farkon dawo da baya, yana barin abubuwa kamar `Backtrace::new` da `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Sigar fasalin firam a cikin bayanan baya.
///
/// Wannan irin aka koma kamar yadda jerin daga `Backtrace::frames` da kuma wakiltar daya tari firam a kama backtrace.
///
/// # Abubuwan da ake buƙata
///
/// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Sigar fasalin wata alama a cikin bayanan baya.
///
/// An dawo da wannan nau'in azaman lissafi daga `BacktraceFrame::symbols` kuma yana wakiltar metadata don alama a cikin baya.
///
/// # Abubuwan da ake buƙata
///
/// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Yana ɗaukar baya a wurin kiran wannan aikin, dawo da wakilcin mallaka.
    ///
    /// Wannan aikin yana da amfani don wakiltar bayanan baya azaman abu a cikin Rust.Wannan koma darajar za a iya aika a fadin zaren da kuma buga sauran wurare, da kuma manufar wannan darajar ne ya zama gaba ɗaya kai dauke.
    ///
    /// Ka lura cewa a wasu dandamali nemowa cikakken backtrace da kuma warware shi iya zama musamman tsada.
    /// Idan farashin yayi yawa don aikace-aikacenka an bada shawarar maimakon amfani da `Backtrace::new_unresolved()` wanda ke guji matakin ƙuduri na alama (wanda yawanci ya ɗauki mafi tsayi) kuma yana ba da damar jinkirta hakan zuwa wani lokaci na gaba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ana so a tabbatar akwai wata firam anan don cirewa
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Mai kama da `new` banda cewa wannan baya warware kowace alama, wannan kawai yana ɗaukar traan baya kamar jerin adiresoshin.
    ///
    /// A wani lokaci ana iya kiran aikin `resolve` don warware alamomin wannan bayanan a cikin sunaye da ake iya karantawa.
    /// Wannan aiki akwai saboda ƙuduri tsari iya, wani lokacin daukar wani gagarumin adadin lokaci, alhãli kuwa wani daya backtrace iya kawai za a wuya buga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // babu alama ce sunayen
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // sunayen alama yanzu suna
    /// ```
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    ///
    #[inline(never)] // ana so a tabbatar akwai wata firam anan don cirewa
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Yana dawo da Fim daga lokacin da aka kama wannan bayanan.
    ///
    /// A farko shigarwa na wannan yanki ne m da aiki `Backtrace::new`, kuma na karshe frame ne m wani abu game da yadda wannan thread ko da babban aiki fara.
    ///
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Idan an ƙirƙiri wannan bayanan daga `new_unresolved` to wannan aikin zai warware duk adiresoshin da ke cikin bayanan zuwa sunayensu na alama.
    ///
    ///
    /// Idan wannan matsalar ta baya an warware ta ko an ƙirƙira ta ta hanyar `new`, wannan aikin ba komai.
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Yayi daidai da `Frame::ip`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Yayi daidai da `Frame::symbol_address`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Yayi daidai da `Frame::module_base_address`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Koma cikin jerin alamomin da cewa wannan frame dace to.
    ///
    /// Kullum akwai daya kawai alama ce da firam, amma wani lokacin idan wani yawan ayyuka suna inlined cikin daya frame sa'an nan mahara alamomin za a mayar da su.
    /// Alamar farko da aka lissafa ita ce "innermost function", yayin da alama ta ƙarshe ita ce mafi ƙarancin (mai kiran ƙarshe).
    ///
    /// Lura cewa idan wannan tsarin ya fito ne daga abin da ba'a warware shi ba to wannan zai dawo da jerin wofi.
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Yayi daidai da `Symbol::name`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Same kamar yadda `Symbol::addr`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Same kamar yadda `Symbol::filename`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Yayi daidai da `Symbol::lineno`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Yayi daidai da `Symbol::colno`
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Lokacin da bugu hanyoyi mu yi kokarin kwashe cwd idan ta wanzu, in ba haka ba za mu kawai buga hanyar as-ne.
        // Lura cewa muma muna yin hakan ne kawai don gajeren tsari, saboda idan ya cika muna iya son buga komai.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}