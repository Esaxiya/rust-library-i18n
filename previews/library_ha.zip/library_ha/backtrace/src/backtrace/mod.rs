use core::ffi::c_void;
use core::fmt;

/// Duba yanzu kira-tari, wucewa duk aiki Frames a cikin ƙulli bayar da yin lissafi wani tari alama.
///
/// Wannan aiki ne da workhorse wannan library a kirga da tari burbushi ga shirin.A ba ƙulli `cb` aka bada misalin wani `Frame` wanda wakiltar bayani game da cewa kira frame a kan tari.
/// Ulli an samar da faifai a cikin yanayin sama-sama (wanda aka kira ayyukan kwanan nan da farko).
///
/// Returnimar dawowar ƙulli alama ce ta ko yakamata a dawo da baya.A samu darajar `false` zai žare backtrace da kuma komawa nan da nan.
///
/// Da zarar wani `Frame` aka samu za ka iya so ka kira `backtrace::resolve` maida da `ip` (wa'azi akan) ko alama adireshin zuwa `Symbol` ta hanyar abin da sunan da/ko filename/line lamba za a iya koya.
///
///
/// Note cewa wannan shi ne mai gwada da low-matakin aiki kuma idan ka so, misali, kama wani backtrace da za a binciki daga baya, to, `Backtrace` irin na iya zama mafi dace.
///
/// # Abubuwan da ake buƙata
///
/// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
///
/// # Panics
///
/// Wannan aikin yana ƙoƙari don taɓa panic, amma idan `cb` ya samar da panics to wasu dandamali zasu tilasta panic ninki biyu don zubar da aikin.
/// Wasu dandamali suna amfani da laburaren C wanda a ciki yana amfani da kira na kira wanda bazai iya zamawa ba, don haka firgita daga `cb` na iya haifar da zubar da tsari.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ci gaba da backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Ya yi daidai da `trace`, ba shi da aminci kamar yadda ba a haɗa shi ba.
///
/// Wannan aikin bashi da alamun aiki tare amma yana samuwa lokacin da ba'a tattara fasalin `std` na wannan crate ba.
/// Duba aikin `trace` don ƙarin takaddun bayanai da misalai.
///
/// # Panics
///
/// Duba bayanai akan `trace` don koyaswa akan tsoro na `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait mai wakiltar firam guda na baya, ya bada izinin aikin `trace` na wannan crate.
///
/// Closulli da aikin bin sawun zai zama an samar da faifai masu fa'ida, kuma kusan ana aiko da firam ɗin saboda ba a san asalin aiwatarwa koyaushe har zuwa lokacin aiki.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Koma yanzu wa'azi akan wannan firam.
    ///
    /// Wannan shi ne kullum na gaba wa'azi ga kashe a cikin firam, amma ba dukan implementations lissafa wannan da 100% daidaito (amma yana da kullum kyawawan kusa).
    ///
    ///
    /// Ana ba da shawarar wuce wannan ƙimar zuwa `backtrace::resolve` don juya shi zuwa sunan alama.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ya dawo da alamar dutsen yanzu na wannan firam.
    ///
    /// A cikin yanayin cewa mai baya baya iya dawo da maɓallin kewaya na wannan firam, an dawo da null null.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Yana dawo da adireshin alamar farawa na firam ɗin wannan aikin.
    ///
    /// Wannan zai yi ƙoƙari ya sake jan ragamar umarnin da aka dawo da shi ta `ip` zuwa farkon aikin, ya dawo da ƙimar.
    ///
    /// A wasu yanayi, kodayake, backends zai dawo da `ip` kawai daga wannan aikin.
    ///
    /// Wasu lokuta ana iya amfani da ƙimar da aka dawo idan `backtrace::resolve` ya gaza akan `ip` da aka bayar a sama.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Ya dawo da adireshin tushe na ƙirar da ƙirar take.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Wannan yana buƙatar zuwa da farko, don tabbatar da cewa Miri ya ɗauki fifiko akan dandalin mai masaukin
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // kawai ana amfani dashi a cikin alamar dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}