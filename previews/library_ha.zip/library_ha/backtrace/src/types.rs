//! Nau'in dandamali na dandamali.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// A dandamali m misali wani layi.
/// Lokacin aiki tare da `std` kunna ana bada shawara zuwa hanyoyin sauƙaƙa don samar da juyawa zuwa nau'ikan `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// A yanki, yawanci bayar a kan Unix dandamali.
    Bytes(&'a [u8]),
    /// Wide kirtani yawanci daga Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Rashin hasara ya canza zuwa `Cow<str>`, zai kasafta idan `Bytes` bashi da inganci UTF-8 ko kuma idan `BytesOrWideString` na `Wide` ne.
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Yana bayar da wakilcin `Path` na `BytesOrWideString`.
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}