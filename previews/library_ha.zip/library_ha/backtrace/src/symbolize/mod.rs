use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Warware wani address to wata alama ce, wucewa alama ce ga ajali ƙulli.
///
/// Wannan aikin zai duba adireshin da aka bayar a yankuna kamar teburin alamar gida, tebur mai alamar motsa jiki, ko DUF bayanan cire kuskure (gwargwadon aiwatarwar da aka kunna) don nemo alamun don samarwa.
///
///
/// The ƙulli iya ba za a kira idan ƙuduri ba za a iya yi, kuma shi ma iya kira fiye da sau daya a cikin hali na inlined ayyuka.
///
/// Alamun da aka bayar suna wakiltar aiwatarwa a takamaiman `addr`, dawo da nau'ikan file/line na adireshin (idan akwai).
///
/// Lura cewa idan kuna da `Frame` to an bada shawarar yin amfani da aikin `resolve_frame` maimakon wannan.
///
/// # Abubuwan da ake buƙata
///
/// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
///
/// # Panics
///
/// Wannan aikin yana ƙoƙari don taɓa panic, amma idan `cb` ya samar da panics to wasu dandamali zasu tilasta panic ninki biyu don zubar da aikin.
/// Wasu dandamali suna amfani da laburaren C wanda a ciki yana amfani da kira na kira wanda bazai iya zamawa ba, don haka firgita daga `cb` na iya haifar da zubar da tsari.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // kawai kalli saman firam
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Warware wani baya kama firam zuwa wata alama ce, wucewa alama ce ga ajali ƙulli.
///
/// Wannan functin aikin wannan aiki a matsayin `resolve` sai dai cewa yana daukan wani `Frame` a matsayin shaida maimakon wani address.
/// Wannan na iya ba da izinin wasu aiwatarwar dandamali na dawo da baya don samar da cikakkun bayanai na alama ko bayani game da firam ɗin layi misali.
///
/// An ba da shawarar yin amfani da wannan idan za ku iya.
///
/// # Abubuwan da ake buƙata
///
/// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
///
/// # Panics
///
/// Wannan aikin yana ƙoƙari don taɓa panic, amma idan `cb` ya samar da panics to wasu dandamali zasu tilasta panic ninki biyu don zubar da aikin.
/// Wasu dandamali suna amfani da laburaren C wanda a ciki yana amfani da kira na kira wanda bazai iya zamawa ba, don haka firgita daga `cb` na iya haifar da zubar da tsari.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // kawai kalli saman firam
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP dabi'u daga tari Frames ne yawanci (always?) wa'azi *bayan* kiran shi ke da ainihin tari alama.
// Misali wannan akan sa lambar filename/line ta zama ta gaba gaba kuma wataƙila ta zama mara kyau idan ta kusan zuwa ƙarshen aikin.
//
// Wannan ya bayyana ga asali koyaushe lamarin haka ne a duk dandamali, don haka koyaushe muna cire ɗaya daga ip da aka warware don warware shi zuwa koyarwar kira na baya maimakon umarnin da aka mayar dashi.
//
//
// Tabbas ba za muyi haka ba.
// Fi dacewa za mu bukatar masu kira na `resolve` APIs nan da hannu yi da -1 da kuma asusun cewa suna so location bayanai ga *baya* wa'azi, ba na yanzu.
// Da kyau kuma zamu nuna a kan `Frame` idan da gaske mu ne adireshin koyarwa ta gaba ko ta yanzu.
//
// Domin a yanzu da yake wannan shi ne kyawawan alkuki damuwa saboda haka muna kawai ƙ ko da yaushe muka ɗebe daya.
// Masu amfani su ci gaba da aiki da samun kyakkyawan sakamako, saboda haka ya kamata mu zama masu isa.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Ya yi daidai da `resolve`, ba shi da aminci kamar yadda ba a haɗa shi ba.
///
/// Wannan aikin bashi da alamun aiki tare amma yana samuwa lokacin da ba'a tattara fasalin `std` na wannan crate ba.
/// Duba aikin `resolve` don ƙarin takaddun bayanai da misalai.
///
/// # Panics
///
/// Duba bayanai akan `resolve` don koyaswa akan tsoro na `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Ya yi daidai da `resolve_frame`, ba shi da aminci kamar yadda ba a haɗa shi ba.
///
/// Wannan aikin bashi da alamun aiki tare amma yana samuwa lokacin da ba'a tattara fasalin `std` na wannan crate ba.
/// Duba aikin `resolve_frame` don ƙarin takaddun bayanai da misalai.
///
/// # Panics
///
/// Duba bayanai akan `resolve_frame` don koyaswa akan tsoro na `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait mai wakiltar ƙudurin alama a cikin fayil.
///
/// Wannan trait aka bada a matsayin trait abu da ƙulli ba ga `backtrace::resolve` aiki, kuma shi ne kusan tura kamar yadda ta unknown wanda aiwatar da shi ne a baya shi.
///
///
/// A alama iya ba kunsa bayani game da wani aiki, misali sunan, filename, line lamba, daidai adireshin, da dai sauransu.
/// Ba duk bayanai ake samun su koyaushe a cikin alama ba, duk da haka, saboda haka duk hanyoyin suna dawo da `Option`.
///
///
pub struct Symbol {
    // TODO: dole ne a dage wannan rayuwar ta ƙarshe zuwa `Symbol`,
    // amma wannan a halin yanzu canzawa ne.
    // Domin yanzu wannan shi ne hadari tun `Symbol` ne kawai taba mika fita da tunani da kuma ba za a iya cloned.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Maida sunan wannan aikin.
    ///
    /// A koma tsarin za a iya amfani da su tambayi daban-daban Properties game da alama suna:
    ///
    ///
    /// * Aikace-aikacen `Display` zai buga alamar da aka lalata.
    /// * A raw `str` darajar da alama za a iya isa (idan ta ta inganci utf-8).
    /// * Za'a iya isa ga albarkatun baiti don sunan alama.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Mayar da adireshin farawa na wannan aikin.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Ya dawo da sunan sabon sunan a matsayin yanki.
    /// Wannan shi ne yafi amfani ga `no_std` yanayin.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ya dawo da lambar ginshiƙi don inda wannan alamar ke gudana a halin yanzu.
    ///
    /// Kawai gimli a halin yanzu na samar da wani darajar nan har ma sai kawai idan `filename` kõma `Some`, don haka shi ne sa'an nan saboda haka batun kama caveats.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Koma cikin layi yawan for inda wannan alama ce a halin yanzu aiwatar.
    ///
    /// Wannan samu darajar ne yawanci `Some` idan `filename` kõma `Some`, kuma shi ne saboda haka batun kama caveats.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Koma cikin sunan fayil inda wannan aiki da aka bayyana.
    ///
    /// Wannan a halin yanzu yana samuwa ne kawai lokacin da ake amfani da libbacktrace ko gimli (misali
    /// unix dandamali wasu) kuma lokacin da aka tattara binary tare da debuginfo.
    /// Idan ɗayan waɗannan sharuɗɗan ba su cika ba to wannan zai iya dawo da `None`.
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Watakila wani parsed C++ alama, idan parsing da mangled alama ce kamar yadda Rust kasa.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Tabbatar ci gaba da wannan sifili-sized, don haka da cewa `cpp_demangle` siffa yana da wani farashi a lokacin da naƙasasshe.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Kunsa a kusa da sunan alama don samar da masu amfani da ergonomic zuwa sunan da aka lalata, ƙananan baiti, ɗan zaren, da dai sauransu.
///
// Bada lambar matacce don lokacin da ba'a kunna fasalin `cpp_demangle` ba.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Creatirƙiri sabon sunan alama daga ɗanyen baiti.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Ya dawo da sunan alamar (mangled) mai kyau azaman `str` idan alamar tana aiki utf-8.
    ///
    /// Yi amfani da aiwatar da `Display` idan kuna son sigar ɓatarwa.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Ya dawo da sunan alamar alamar azaman jerin baiti
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Wannan na iya bugawa idan alamar da ke kwance ba ta da inganci, don haka ku riƙe kuskuren a nan da kyau ta hana yaduwar sa a waje.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Oƙarin dawo da wannan maƙunsar da aka yi amfani da ita don alamar adiresoshin.
///
/// Wannan hanyar za ta yi ƙoƙari ta saki duk wani tsarin bayanan duniya wanda in ba haka ba an adana shi a duniya ko a cikin zaren wanda ke wakiltar ɓataccen bayanin DWARF ko makamancin haka.
///
///
/// # Caveats
///
/// Duk da yake ana samun wannan aikin koyaushe baya yin komai akan yawancin aiwatarwa.
/// Dakunan karatu kamar dbghelp ko libbacktrace ba su samar da wuraren zuwa deallocate jihar da kuma sarrafa kasaftawa ƙwaƙwalwar.
/// A yanzu fasalin `gimli-symbolize` na wannan crate shine kawai fasalin inda wannan aikin yake da tasiri.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}