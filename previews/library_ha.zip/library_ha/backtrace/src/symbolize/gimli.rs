//! Support for symbolication amfani da `gimli` crate a kan crates.io
//!
//! Wannan ita ce alamar alama ta asali don Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Tsayayyen rayuwa karya ce don yaudara game da rashin tallafi don matakan tuntuɓar kai.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Tuba zuwa ga 'a tsaye rayuwar Annabi tun da alamomin kamata kawai ranta `map` da `stash` kuma muna tsare su a kasa.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Don loda ɗakunan karatu na asali akan Windows, duba ɗan tattaunawa akan rust-lang/rust#71060 don dabaru iri-iri anan.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW dakunan karatu a halin yanzu basa tallafawa ASLR (rust-lang/rust#16514), amma har yanzu ana iya sake DLLs a cikin filin adireshin.
            // Ya bayyana cewa adiresoshin cikin bayanan cire kuskure duk kamar dai-an ɗora wannan ɗakin karatun a "image base" ɗin sa, wanda shine filin a cikin maƙallan fayil ɗin COFF.
            // Tun da yake wannan shi ne abin da debuginfo alama lissafa mu parse da alama tebur da kantin sayar da adiresoshin kamar yadda idan library aka ɗora Kwatancen a "image base" da.
            //
            // Ba za a ɗora lodin a laburaren a "image base" ba, duk da haka.
            // (Mai yiwuwa wani abu dabam iya ɗora Kwatancen akwai?) Wannan shi ne inda `bias` filin zo a cikin play, kuma muna bukatar mu gane darajar `bias` nan.Abin baƙin ciki duk da cewa ba a bayyana yadda ake samun wannan ba daga ɗakunan da aka ɗora.
            // Abin da ba mu da, duk da haka, shi ne ainihin kaya adireshin (`modBaseAddr`).
            //
            // Kamar yadda muke ɗan ƙaramin kwafi don yanzu mun inganta fayil ɗin, karanta bayanan taken fayil ɗin, sa'annan ku sauke mmap ɗin.Wannan ɓarnatarwa ce saboda tabbas zamu iya buɗe mmap daga baya, amma wannan yakamata yayi aiki sosai har yanzu.
            //
            // Da zarar mun sami `image_base` (wurin da ake buƙata) da `base_addr` (ainihin wurin ɗora kaya) za mu iya cika `bias` (bambanci tsakanin ainihin da abin da ake so) sannan adireshin da aka faɗi na kowane sashi shi ne `image_base` tunda wancan ne abin da fayil ɗin ya ce.
            //
            //
            // A yanzu ya bayyana cewa ba kamar ELF/MachO ba zamu iya yin tare da kashi ɗaya a kowane ɗakin karatu, ta amfani da `modBaseSize` azaman duka girman.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS amfani da Mach-O fayil format da kuma amfani DYLD-takamaiman APIs to load a jerin 'yan qasar dakunan karatu da cewa wani bangare ne na aikace-aikace.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Kawo sunan wannan dakin karatun wanda yayi daidai da hanyar inda za'a loda shi shima.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Loda hoton hoton wannan laburaren kuma ku wakilta zuwa `object` don taƙaita duk dokokin da aka ɗora don mu iya gano dukkan sassan da ke ciki.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Yi fushi akan sassan kuma yi rijistar sanannun yankuna don sassan da muka samu.
            // Recordari akan rikodin ɓangaren rubutu na bayanai don aiki daga baya, duba ra'ayoyi a ƙasa.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Ƙayyade da "slide" ga wannan library wanda ƙare har kasancewa da nuna bambanci muka yi amfani da su adadi daga inda a ƙwaƙwalwar ajiyar abubuwa suna ɗora Kwatancen.
            // Wannan shi ne a bit da wani m ƙidãyar ko kuma shi ne sakamakon kokarin da 'yan abubuwa a cikin daji da kuma ganin abin da sandunansu.
            //
            // Babban ra'ayi shine `bias` tare da `stated_virtual_memory_address` na wani ɓangare zai kasance inda a cikin ainihin adireshin ɓangaren ya kasance.
            // Sauran abu da muka dõgara a kan ko yana da wani real adireshin debe da `bias` ne index zuwa duba sama a cikin alama ce tebur da debuginfo.
            //
            // Sai dai itace, ko da yake, cewa ga tsarin ɗora Kwatancen dakunan karatu wadannan lissafinta daidai ba.Ga 'yan asalin zartarwa, kodayake, ya bayyana daidai.
            // Someaga wasu dabaru daga tushen LLDB yana da casing na musamman don ɓangaren `__TEXT` na farko wanda aka loda daga fayel wanda ya biya 0 tare da girman nonzero.
            // Ga kowane dalili idan wannan ya kasance yana bayyana yana nufin cewa teburin alama yana da alaƙa da kawai zirin vmaddr don ɗakin karatu.
            // Idan yana da *ba* ba nan da alama tebur ne dangi zuwa ga cikin vmaddr nunin da kashi ta ajali adireshin.
            //
            // Don magance wannan yanayin idan ba mu * sami ɓangaren rubutu a fayil ɗin da ba a biya ba to sai mu ƙara nuna son kai ta hanyar adireshin sassan sassan farko da rage duk adiresoshin da aka ambata ta wannan adadin kuma.
            //
            // Wannan hanya da alama tebur ne ko da yaushe bayyana dangi da library ta nuna bambanci adadin.
            // Wannan ya bayyana a yi da dama sakamakon for NUNA via alama ce tebur.
            //
            // Gaskiya ba ni da cikakken tabbaci ko wannan daidai ne ko kuma idan akwai wani abin da ya kamata ya nuna yadda ake yin hakan.
            // Domin a yanzu da yake wannan alama aiki da kyau isa (?) kuma ya kamata mu ko da yaushe su iya tweak wannan a kan lokaci idan ya cancanta.
            //
            // Ga wasu karin bayanai ga #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Sauran Unix (misali
        // Linux) dandamali suna amfani da ELF azaman tsarin fayil ɗin abu kuma galibi suna aiwatar da API da ake kira `dl_iterate_phdr` don ɗora ɗakunan karatu na asali.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ya zama mai inganci pointers.
        // `vec` ya zama mai inganci akan wani `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ba natively goyi bayan cire kuskure info, amma ginawa tsarin zai sanya cire kuskure info a hanya `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Sauran ayyukan da ya kamata amfani da Elf, amma bai sani ba yadda za a load 'yan qasar dakunan karatu.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Duk aka sani raba dakunan karatu da cewa an ɗora Kwatancen.
    libraries: Vec<Library>,

    /// Mappings cache inda muke rike parsed dwarf information.
    ///
    /// Wannan jerin yana da wani tsayayyen iya aiki domin ta dukan liftime wanda ba qara.
    /// A `usize` kashi na kowane biyu ne wani index cikin `libraries` sama inda `usize::max_value()` wakiltar halin yanzu executable.
    ///
    /// `Mapping` daidai yake da bayanan dwarf.
    ///
    /// Note cewa wannan shi ne m wani LRU cache da za mu iya canjawa abubuwa kewaye da a nan kamar yadda muka alamar adiresoshin.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Angarorin wannan ɗakin karatun an ɗora su a ƙwaƙwalwa, da kuma inda aka ɗora su.
    segments: Vec<LibrarySegment>,
    /// "bias" na wannan ɗakin karatun, galibi inda aka ɗora shi a ƙwaƙwalwa.
    /// Ana ƙara wannan ƙimar a kowane ɓangaren da aka bayyana adireshin don samun ainihin adireshin ƙwaƙwalwar ajiya wacce aka shigar da ɓangaren.
    /// Ari akan haka an cire wannan nuna bambanci daga ainihin adiresoshin ƙwaƙwalwar ajiya na kama-da-wane don zuwa cikin debuginfo da teburin alama.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Adireshin da aka bayyana na wannan ɓangaren a cikin fayil ɗin abu.
    /// Wannan shi ne ba a zahiri inda kashi da aka yi wa lodi, amma wannan adireshin da na dauke da library ta `bias` ne inda zan samu shi.
    ///
    stated_virtual_memory_address: usize,
    /// Girman sashin sashin ƙwaƙwalwar ajiya.
    len: usize,
}

// amintacce saboda ana buƙatar aiki tare daga waje
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // amintacce saboda ana buƙatar aiki tare daga waje
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Smallan ƙaramin abu, mai sauƙin LRU don ɓarnatar da bayanan taswira.
        //
        // Matsakaicin bugun ya zama mai girma sosai, tunda ɗimbin ɗumbin ba ya ƙetare tsakanin ɗakunan karatu da yawa masu raba.
        //
        // A `addr2line::Context` Tsarin su ne kyawawan tsada don ƙirƙirar.
        // Ana tsammanin za a daidaita farashin ta ta hanyar tambayoyin `locate` na gaba, wanda ke yin amfani da tsarin da aka gina yayin gina ``addr2line: : Context`s don samun saurin saurin.
        //
        // Idan ba mu da wannan maɓallin, wannan amortization ba zai taɓa faruwa ba, kuma alamomin baya zai zama ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Da farko, gwada idan wannan `lib` yana da kowane bangare wanda yake dauke da `addr` (kula da ƙaura).Idan wannan rajistan ya wuce to zamu iya ci gaba a ƙasa kuma a zahiri muna fassara adireshin.
                //
                // Note cewa muna amfani da `wrapping_add` nan don kauce wa ambaliya cak.Shi ke an gani a cikin daji da cewa SVMA + nuna bambanci ƙidãyar fal da mai.
                // Da alama baƙon abu ne da zai faru amma babu wata adadi mai yawa da za mu iya yi game da shi in ban da ƙila mu yi watsi da waɗancan sassan tunda suna iya nunawa cikin sarari.
                //
                // Wannan asalin ya samo asali ne a cikin rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Yanzu tunda mun san `lib` ya ƙunshi `addr`, zamu iya daidaita shi da son zuciya don nemo adreshin ƙwaƙwalwar ajiya da aka ambata.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: bayan wannan sharadin ya cika ba tare da dawowa da wuri ba
        // daga kuskure, shigar da cache don wannan hanyar yana kan layin 0.

        if let Some(idx) = idx {
            // Lokacin da taswirar ta riga ta kasance cikin ma'ajin, matsar da shi zuwa gaba.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Lokacin da zanen taswira ba a cikin cache, haifar da wani sabon zanen taswira, saka shi a cikin gaban da cache, da kuma kore mafi tsufa cache shigarwa idan ya cancanta.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // kar ku zubar da rayuwar `'static`, ku tabbata cewa ya rage wa kanmu kawai
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Ara tsawon rayuwar `sym` zuwa `'static` tunda abin baƙin cikin shine ana buƙatar mu anan, amma yana da kyau koyaushe ya fita azaman abin tunani don haka ba zancen shi ya kamata a nace bayan wannan tsarin ba.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // A ƙarshe, samo taswirar da aka adana ko ƙirƙirar sabon taswira don wannan fayil ɗin, kuma kimanta bayanin DWARF don nemo file/line/name don wannan adireshin.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Mun yi iya gano wuri frame bayanai ga wannan alama ce, da `addr2line` ta firam ƙ yana da dukan nitty gritty bayani.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Ba a iya samun cire kuskure bayanai, amma mun same shi a cikin alama ce tebur na jinslrl executable.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}