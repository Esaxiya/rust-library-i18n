//! Dabarar nuna alama ta amfani da lambar DARF-parsing a cikin libbacktrace.
//!
//! Laburaren libbacktrace C, yawanci ana rarraba shi tare da gcc, yana tallafawa ba kawai samar da baya ba (wanda ba ma amfani da shi a zahiri) amma kuma yana nuna alamar baya da kuma sarrafa dug na ɓatar da bayanai game da abubuwa kamar zane-zane da abin da ba shi ba.
//!
//!
//! Wannan yana da rikitarwa saboda yawancin damuwa daban-daban anan, amma ainihin ra'ayin shine:
//!
//! * Da farko muna kira `backtrace_syminfo`.Wannan samun alama bayanai daga tsauri alama ce tebur idan za mu iya.
//! * Gaba muna kiran `backtrace_pcinfo`.Wannan zai parse debuginfo alluna, idan sun yi samuwa da kuma ƙyale mu mu mai da bayanai game da línea Frames, filenames, line lambobin, da dai sauransu
//!
//! Akwai kuri'a na yaudara game da samun Dwarf allunan cikin libbacktrace, amma da fatan wannan ba shi ne karshen duniya, kuma a fili yake da isasshen lokacin karanta a kasa.
//!
//! Wannan ita ce dabarar nuna alama ta asali ga dandamali ba MSVC da na OSX ba.A libstd da yake wannan ne default dabarun domin OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Idan za ta yiwu fi son sunan `function` wanda ya fito daga debuginfo kuma yawanci zai iya zama mafi daidaito ga ƙananan hotuna misali.
                // Idan ba haka ba duk da cewa komawa ga sunan tebur mai alama da aka ƙayyade a cikin `symname`.
                //
                // Lura cewa wani lokacin `function` na iya jin ɗan daidai, misali ana lasafta shi azaman `try<i32,closure>` ba na `std::panicking::try::do_call` ba.
                //
                // Shi ke ba da gaske share me ya sa, amma sauran da `function` sunan alama mafi m.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // kada ayi komai a yanzu
}

/// Rubuta na `data` akan shige cikin `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Da zarar an kira wannan kiran daga `backtrace_syminfo` lokacin da muka fara warwarewa sai mu kara kira `backtrace_pcinfo`.
    // Aikin `backtrace_pcinfo` zai bincika bayanan cire kuskure da yunƙurin yin abubuwa kamar dawo da bayanin file/line da kuma zane mai zane.
    // Ka lura duk da cewa `backtrace_pcinfo` na iya kasawa ko rashin yin abubuwa da yawa idan babu cire bayanai, don haka idan hakan ta faru muna da tabbacin zamu kira kiran da aƙalla alama guda daga `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Rubuta na `data` akan shige cikin `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API na libbacktrace API yana tallafawa ƙirƙirar jiha, amma baya goyan bayan lalata wata ƙasa.
// Ni kaina na dauki wannan yana nufin cewa ana nufin kirkirar jiha sannan kuma ta rayu har abada.
//
// Ina son yin rijistar mai kula da at_exit() wanda ke tsabtace wannan jihar, amma libbacktrace ba ta da hanyar yin hakan.
//
// Tare da wadannan constraints, wannan aiki yana da statically Kama jihar da ake lasafta karo na farko da wannan da aka nema.
//
// Ka tuna cewa backtracing duk ya faru serially (daya duniya kulle).
//
// Lura rashin aiki tare anan saboda larurar da ake aiki da `resolve` a waje.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Kada motsa jiki threadsafe damar libbacktrace tun muna ko da yaushe ya kira ta a cikin wani aiki fashion.
        //
        0,
        error_cb,
        ptr::null_mut(), // babu karin bayanai
    );

    return STATE;

    // Ka lura cewa a libbacktrace ta yi aiki a duk yana bukatar a samu da Dwarf cire kuskure info ga halin yanzu executable.Yawanci yana yin hakan ta hanyoyi da yawa waɗanda suka haɗa da, amma ba'a iyakance ga:
    //
    // * /proc/self/exe a kan dandamali goyon
    // * A filename wuce a cikin baro-baro a lokacin da samar jihar
    //
    // Laburaren libbacktrace babban yanki ne na lambar C.Wannan a zahiri yana nufin yana da raunin amincin ƙwaƙwalwa, musamman yayin magance ɓataccen kuskure.
    // Libstd ya sami wadatattun wadatattun tarihin.
    //
    // Idan anyi amfani da /proc/self/exe to lallai zamu iya yin watsi da waɗannan yayin da muke ɗauka cewa libbacktrace shine "mostly correct" kuma in ba haka ba baya yin abubuwa masu ban mamaki tare da "attempted to be correct" dwarf debug info.
    //
    //
    // Idan muka wuce a wani filename, duk da haka, to, shi ke nan zai yiwu a kan wasu dandamali (kamar BSDs) inda wani qeta actor iya haifar da wani sabani fayil da za a sanya a wancan wuri.
    // Wannan yana nufin cewa idan muka gaya ma libbacktrace game da sunan sunan mai amfani yana iya amfani da fayil na son rai, mai yuwuwar haifar da matsala.
    // Idan ba mu gaya wa libbacktrace komai ba to amma ba zai yi komai ba a dandamali waɗanda ba sa goyan bayan hanyoyi kamar /proc/self/exe!
    //
    // Idan aka ba duk abin da muke ƙoƙari sosai don * kada mu wuce a cikin sunan sunan, amma dole ne mu kasance a kan dandamali waɗanda ba sa goyan bayan /proc/self/exe kwata-kwata.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Lura cewa da kyau zamuyi amfani da `std::env::current_exe`, amma ba zamu iya buƙatar `std` a nan ba.
            //
            // Yi amfani da `_NSGetExecutablePath` don loda hanyar da za'a iya aiwatarwa ta yanzu zuwa wani yanki (wanda idan yayi ƙarami to bari kawai).
            //
            //
            // Lura cewa muna dogara ga sassaucin ra'ayi anan don kada mu mutu kan masu aiwatar da rashawa, amma tabbas hakan yayi ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows yana da yanayin bude fayiloli inda bayan an bude shi ba za a iya share shi ba.
            // Wannan ta a general abin da muke so a nan saboda mun so mu tabbatar da cewa executable ba canza fita daga karkashin mana bayan mun mika shi a kashe su libbacktrace, da fatan mitigating da ikon hawa a sabani data cikin libbacktrace (wanda za a iya mishandled).
            //
            //
            // Ganin cewa muna ɗan rawa a nan don ƙoƙari don samun wani irin kulle akan hotonmu:
            //
            // * Samun wani rike zuwa yanzu tsari, load ta filename.
            // * Bude fayil zuwa wannan sunan sunan tare da tutocin dama.
            // * Sake shigar da sunan fayil na yanzu, tabbatar cewa daidai yake
            //
            // Idan da cewa duk wuce mu a ka'idar, lalle ne, ya bude da mu aiwatar ta fayil kuma muna tabbatar da shi ba zai canza.FWIW wani gungu na wannan kofe daga libstd tarihi, don haka wannan shi ne mafi kyau fassarar abin da aka faruwa.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Wannan zaune a tsaye memory haka za mu iya mayar da ita ..
                static mut BUF: [i8; N] = [0; N];
                // ... kuma wannan yana rayuwa akan tarin tunda na ɗan lokaci ne
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // zubar da `handle` da gangan a nan saboda buɗe wannan zai kiyaye makullinmu akan wannan sunan fayil ɗin.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Muna so mu dawo da yanki wanda ba shi da iyaka, don haka idan komai ya cika kuma ya yi daidai da tsawon saiti to ya daidaita da gazawa.
                //
                //
                // In ba haka ba a lokacin da ya dawo nasara Tabbatar da nul byte ne kunshe a cikin yanki.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // kurakuran baya baya a halin yanzu ana share su a ƙarƙashin kilishi
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Kira `backtrace_syminfo` API wanda (daga karatun code) ya kira `syminfo_cb` daidai da zarar (ko kasa da wani kuskure mai yiwuwa).
    // Mun sa'an nan rike more cikin `syminfo_cb`.
    //
    // Lura cewa muna yin hakan tunda `syminfo` zai tuntubi teburin alama, gano sunayen alamomi koda kuwa babu bayanan cire bayanai a cikin binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}