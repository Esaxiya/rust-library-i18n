// kawai a kan yi amfani Linux a yanzu, don haka ba da damar matattu code sauran wurare
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// A sauki fagen fama allocator for byte buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Keɓaɓɓun maɓalli na ƙayyadadden girman kuma ya mayar da ambaton maye gurbinsa.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // KYAUTA: wannan shine kawai aikin da ke taɓa canza fasali
        // koma zuwa `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // KYAUTA: ba zamu taɓa cire abubuwa daga `self.buffers` ba, don haka tunani
        // zuwa bayanan da ke cikin kowane abin ajiyewa zai rayu muddin `self` yayi.
        &mut buffers[i]
    }
}