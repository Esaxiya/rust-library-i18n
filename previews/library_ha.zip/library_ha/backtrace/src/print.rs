#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// A formatter for backtraces.
///
/// Wannan irin za a iya amfani da su buga a backtrace ko da kuwa inda backtrace kanta zo daga.
/// Idan kuna da nau'in `Backtrace` to aiwatar da `Debug` ya riga yayi amfani da wannan tsarin bugawa.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Salon bugawa wanda zamu iya bugawa
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Kwafi a terser backtrace wanda fi dacewa kawai ya ƙunshi dacewa bayanai
    Short,
    /// Kwafi a backtrace cewa ya ƙunshi dukkan yiwu bayanai
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Irƙiri sabon `BacktraceFmt` wanda zai rubuta fitarwa zuwa `fmt` ɗin da aka bayar.
    ///
    /// A `format` shawara za sarrafa style a cikin abin da backtrace aka buga, da kuma `print_path` shawara za a yi amfani da su buga da `BytesOrWideString` lokutta na filenames.
    /// Wannan nau'ikan kansa baya yin kowane irin buga sunayen filenames, amma ana buƙatar yin wannan kiran don yin hakan.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Buga wani preamble na farkon abin da za a buga.
    ///
    /// Ana buƙatar wannan a wasu dandamali don bayanan baya don zama cikakken kwatanci daga baya, kuma in ba haka ba wannan ya zama kawai hanyar farko da kuke kira bayan ƙirƙirar `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Yana ƙara firam zuwa da backtrace fitarwa.
    ///
    /// Wannan ƙaddamarwar ta dawo da misalin RAII na `BacktraceFrameFmt` wanda za'a iya amfani dashi don zahiri buga firam, kuma a kan lalacewar zai haɓaka ƙirar firam ɗin.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// An kammala fitowar bayanan baya.
    ///
    /// Wannan a halin yanzu ba komai bane amma an kara shi don dacewa da future tare da tsarin sake dawowa.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // A halin yanzu a wani-op-- ciki har da wannan hook don ba da damar for future tarawa.
        Ok(())
    }
}

/// Mai tsara fasali don tsari ɗaya kawai na bayanan baya.
///
/// Wannan nau'in an ƙirƙira shi ta hanyar aikin `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Buga `BacktraceFrame` tare da wannan mai tsara fasalin.
    ///
    /// Wannan zai sake buga duk abubuwan `BacktraceSymbol` a cikin `BacktraceFrame`.
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Kwafi a `BacktraceSymbol` cikin `BacktraceFrame`.
    ///
    /// # Abubuwan da ake buƙata
    ///
    /// Wannan aikin yana buƙatar fasalin `std` na `backtrace` crate don kunna, kuma fasalin `std` ya sami aiki ta tsohuwa.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: wannan ba shi da kyau cewa ba za mu ƙarasa buga komai ba
            // tare da wadanda ba utf8 filenames.
            // Alhamdu lillahi kusan kome da kome shi ne utf8 haka wannan kada ta kasance ma ma bad.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ana buga ɗanyen da aka gano `Frame` da `Symbol`, galibi daga cikin ƙarancin kira na wannan crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Yana rawara raw firam zuwa bayan fitarwa.
    ///
    /// Wannan hanyar, ba kamar ta baya ba, tana ɗauke da muhawara idan har suna samun tushe daga wurare daban-daban.
    /// Lura cewa wannan na iya kira mahara sau daya frame.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// In ji wani raw firam zuwa backtrace fitarwa, ciki har da shafi bayanai.
    ///
    /// Wannan hanya, kamar baya, daukan cikin raw muhawara a yanayin da suka kana zama tushen daga wurare daban-daban.
    /// Lura cewa wannan na iya kira mahara sau daya frame.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia baya iya yin alama a cikin tsari don haka yana da tsari na musamman wanda za'a iya amfani dashi don alama daga baya.
        // Buga wancan maimakon buga adiresoshin a namu tsarin anan.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Babu bukatar buga "null" Frames, shi m kawai yana nufin cewa tsarin backtrace ya bit m gano mayar super nisa.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Don rage girman TCB a cikin Sgx enclave, ba mu son aiwatar da aikin ƙuduri alama.
        // Maimakon haka, mun iya buga da biya diyya na adireshin nan, wanda za a iya daga baya tsara don daidai aiki.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Buga fihirisar firam ɗin da maɓallin koyarwar zaɓi na firam.
        // Idan mun wuce farkon alama ta wannan firam duk da cewa kawai mun buga sararin da ya dace.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Next up write fitar da alama sunan, ta amfani da m tsara don ƙarin bayani idan muka yi cikakken backtrace.
        // Anan ma muna rike da alamomin da basu da suna,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Kuma šauki up, a buga fitar da filename/line lambar, idan sun yi samuwa.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line an buga su a kan layi a ƙarƙashin sunan alama, don haka a buga wasu sararin da suka dace don daidaita kan mu daidai.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Yi wakilai zuwa kiran mu na cikin gida don buga sunan filo sannan sai a buga lambar layin.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Sanya lambar shafi, idan akwai.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Muna kula kawai da farkon alama na firam
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}