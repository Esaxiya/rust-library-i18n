# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Laburare don siyan baya a lokacin gudu don Rust.
Wannan library manufofin bunkasa da goyon bayan da misali library ta samar da wani programmatic dubawa zuwa aiki tare da, amma shi ma goyon bayan kawai sauƙi bugu na yanzu backtrace kamar libstd ta panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Don kawai kama wani backtrace kuma cira tafiyad da shi har wani lokaci daga baya, za ka iya amfani da saman-matakin `Backtrace` irin.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Idan, duk da haka, kuna son samun ƙarin ɗanye zuwa ainihin aikin ganowa, zaku iya amfani da ayyukan `trace` da `resolve` kai tsaye.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Warware wannan kwatancen jagorar zuwa sunan alama
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ci gaba da zuwa matattakala ta gaba
    });
}
```

# License

Wannan aikin lasisi ne a ƙarƙashin ɗayan ɗayan

 * Lasisin Apache, Siffar 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ko http://www.apache.org/licenses/LICENSE-2.0)
 * MIT lasisi ([LICENSE-MIT](LICENSE-MIT) ko http://opensource.org/licenses/MIT)

a zabinka.

### Contribution

Sai dai idan da ka baro-baro a jihar in ba haka ba, duk wani taimako da ganganci sallama ga hada a backtrace-rs da ku, kamar yadda aka ayyana a cikin Apache-2.0 lasisi, zai zama dual lasisi kamar a sama, ba tare da wani ƙarin sharuddan ko yanayi.







