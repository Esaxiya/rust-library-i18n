//! Laburaren tallafi don marubutan macro lokacin bayyana sabon macros.
//!
//! Wannan laburaren, wanda aka samar dashi ta hanyar daidaitaccen rarrabawa, yana samarda nau'ikan da ake cinyewa a cikin hanyoyin ma'anar macro mai aiki kamar macros `#[proc_macro]`, halayen macro `#[proc_macro_attribute]` da halaye masu alaƙa da al'ada##proc_macro_derive] ``.
//!
//!
//! Duba [the book] don ƙarin.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Dayyade ko proc_macro ya sami damar zuwa shirin da yake gudana a halin yanzu.
///
/// Proc_macro crate kawai akayi nufin amfani dashi a cikin aiwatar da aikin macros.Duk da ayyuka a cikin wannan crate panic idan kiran daga waje na wani procedural Macro, kamar daga wani ginawa rubutun ko naúrar gwajin ko talakawa Rust binary.
///
/// Tare da la'akari da ɗakunan karatu na Rust waɗanda aka tsara don tallafawa duka shari'ar amfani da macro da mara amfani, `proc_macro::is_available()` yana ba da hanyar da ba ta tsoro ba don gano ko abubuwan more rayuwa da ake buƙata don amfani da API na proc_macro suna nan a halin yanzu.
/// Yana dawowa gaskiya idan aka kirashi daga cikin tsarin macro, na ƙarya idan aka kirashi daga kowane binary.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Babban nau'in da wannan crate ya bayar, yana wakiltar rafin z0 na tokens, ko, ƙari musamman, jerin bishiyoyin token.
/// Nau'in yana samar da hanyoyin musayar abubuwa akan waɗancan bishiyoyi na token kuma, akasin haka, tattara adadin itatuwan token zuwa rafi ɗaya.
///
///
/// Wannan duka shigarwar da fitowar `#[proc_macro]`, `#[proc_macro_attribute]` da ma'anar `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Kuskure ya dawo daga `TokenStream::from_str`
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Ya dawo da komai na `TokenStream` wanda bashi da bishiyoyin token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Ana dubawa idan wannan `TokenStream` ɗin fanko ne.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Attoƙarin fasa zaren cikin tokens kuma ya ɓatar da waɗancan tokens ɗin zuwa rafin token.
/// Iya kasa ga yawan dalilan, misali, idan kirtani ya ƙunshi unbalanced delimiters ko haruffa ba data kasance a cikin harshen.
///
/// Duk tokens a cikin rafin da aka ɓoye yana samun faɗin `Span::call_site()`.
///
/// NOTE: wasu kurakurai na iya haifar da panics maimakon dawo da `LexError`.Mu rike da hakkin ya canza wadannan kurakurai a cikin `LexError`s daga baya.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, da gada kawai samar da `to_string`, yi `fmt::Display` dangane da shi (da baya daga cikin saba dangantaka tsakanin biyu).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Kwafi da token rafi matsayin kirtani cewa ya kamata su zama losslessly canzawa baya a cikin wannan token rafi (modulo Al'arshinSa), fãce da yiwu `TokenTree: : Group`s da `Delimiter::None` delimiters kuma korau Tazarar literals.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Buga token a cikin sigar da ta dace don yin kuskure.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Halicci token rafi dauke da guda token itace.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Tattara itatuwan token da yawa a cikin rafi guda.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Aikin "flattening" akan rafin token, yana tattara bishiyoyin token daga rafuka token masu yawa zuwa rafi ɗaya.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Yi amfani da ingantaccen aiwatarwa if/when mai yiwuwa.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Bayanin aiwatar da jama'a game da nau'in `TokenStream`, kamar masu amfani da shi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// An iterator kan `TokenStream` ta`TokenTree`s.
    /// Maimaitawar ita ce "shallow", misali, mai ba da labari ba ya sake komawa cikin rukunin da aka keɓance, kuma ya dawo da dukkanin rukunin kamar bishiyoyin token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ya yarda da sabani tokens kuma yana faɗaɗa cikin wani `TokenStream` kwatanta shigar.
/// Alal misali, `quote!(a + b)` zai samar da wani magana, cewa, a lokacin da kimanta, gina da `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Ana aiwatar da cirewa tare da `$`, kuma yana aiki ta hanyar ɗaukar guda ɗaya mai zuwa azaman lokacin da ba'a ƙayyade ba.
/// Don faɗi `$` kanta, yi amfani da `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Yankin lambar tushe, tare da bayanan faɗaɗa macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Irƙiri sabon `Diagnostic` tare da `message` da aka bayar a taƙaice `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Gwanin da ke warwarewa a shafin ma'anar macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Dogaro da kira na tsarin aiki na yanzu.
    /// Za a warware masu ganowa tare da wannan lokacin kamar dai an rubuta su kai tsaye a wurin kiran kiran macro (tsabtace wurin kiran-kira) da sauran lambobin da ke wurin kiran macro za su iya zuwa gare su su ma.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Tazara mai wakiltar tsabtace `macro_rules`, kuma wani lokacin yakan warware a shafin ma'anar macro (masu canji na gida, lakabi, `$crate`) wani lokacin kuma a wurin kiran macro (duk wani abu).
    ///
    /// An ɗauka wuri mai tsawo daga shafin kira.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// The asali tushen fayil a cikin abin da wannan span maki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` don tokens a cikin haɓakar macro da ta gabata wanda aka samo asalin `self` daga, idan akwai.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// A span ga asalin tushen code cewa `self` aka generated daga.
    /// Idan ba a samar da wannan `Span` din ba daga sauran fadada macro to darajar dawowa daidai take da `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Samun farawa line/column a cikin fayil ɗin asalin wannan zangon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Samu line/column mai ƙarewa a cikin fayil ɗin asalin wannan zangon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Halicci sabon span kẽwayẽwa `self` da `other`.
    ///
    /// Dawowar `None` idan `self` da `other` sun kasance daga fayiloli daban-daban.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Irƙiri sabon yanayi tare da irin wannan bayanin na line/column kamar na `self` amma wannan yana warware alamomin kamar dai yana a `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Creatirƙiri sabon layi tare da halaye masu yanke suna kamar `self` amma tare da bayanin line/column na `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Kwatanta da spans don ganin idan sun daidaita.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Koma tushen rubutun bãYan wani span.
    /// Wannan tserar da asali source code, ciki har da sarari da comments.
    /// Yana dawo da sakamako ne kawai idan tsawon yayi dace da lambar asalin asali.
    ///
    /// Note: Sakamakon da ake gani na macro ya kamata ya dogara da tokens kawai ba a kan wannan asalin tushen ba.
    ///
    /// Sakamakon wannan aikin shine mafi kyawun ƙoƙari don amfani dashi don bincikowa kawai.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Fitar da span a sifa mai dacewa don yin kuskure.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Takaddun layi-layi masu wakiltar farawa ko ƙarshen `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Layin 1-wanda aka nuna a cikin fayil ɗin asalin wanda akansa ya fara ko ƙare (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Shafin 0-wanda aka zana (a cikin haruffan UTF-8) a cikin fayil ɗin asalin wanda akansa ya fara ko ƙare (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Fayil ɗin asalin abin da aka ba `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Samun hanya zuwa wannan tushen fayil.
    ///
    /// ### Note
    /// Idan code span hade da wannan `SourceFile` aka generated da na waje Macro, wannan Macro, wannan bazai zama wani ainihin hanya a kan filesystem.
    /// Yi amfani da [`is_real`] don bincika.
    ///
    /// Hakanan ku lura cewa koda `is_real` ya dawo da `true`, idan aka wuce da `--remap-path-prefix` akan layin umarni, hanyar da aka bayar bazai da inganci.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Yana dawo da `true` idan wannan fayil ɗin asalin asalin fayil ɗin asalin asalinsa ne, kuma ba ƙirƙirarsa ta haɓakar macro ta waje ba.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Wannan shi ne wani hack har intercrate Al'arshinSa da ake aiwatar da za mu iya yi real tushen fayilolin ga Al'arshinSa generated a waje macros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// A guda token ko wani delimited jerin token itatuwa (misali, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Rafin token wanda ke kewaye da masu iyakance sashi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Mai ganowa.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Halin rubutu guda ɗaya (`` + ', `,`, `$`, da sauransu).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Hali na zahiri (`'a'`), kirtani (`"hello"`), lamba (`2.3`), da sauransu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Dawo da span na wannan itace, delegating ga `span` Hanyar na dauke token ko wani delimited rafi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Yana sake saita tazara don *kawai wannan token*.
    ///
    /// Note cewa idan wannan token ne `Group` to wannan hanya ba zai saita span na kowane daga cikin ciki tokens, wannan zai kawai wakilta ga `set_span` Hanyar kowane bambanci.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Buga itace token a cikin sifa da ta dace don yin kuskure.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kowane ɗayan waɗannan yana da suna a cikin nau'in tsari a cikin ƙirar da aka samo, don haka kada ku dame tare da ƙarin takaddama na ɓoyewa
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, da gada kawai samar da `to_string`, yi `fmt::Display` dangane da shi (da baya daga cikin saba dangantaka tsakanin biyu).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Buga bishiyar token azaman zaren da yakamata ya zama ba za a iya canza shi ba a cikin bishiyar token ɗin nan (modulo spans), sai dai mai yiwuwa ``TokenTree: : Group`s tare da masu ƙididdiga na `Delimiter::None` da ƙananan lambobi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// A delimited token rafi.
///
/// `Group` a ciki yana ƙunshe da `TokenStream` wanda ke kewaye da `` Delimiter ''.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Ya bayyana yadda a jerin token itatuwa ne delimited.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// An fakaice delimiter, cewa zai iya, misali, ya bayyana a kusa da tokens ya fito daga wata "macro variable" `$var`.
    /// Yana da muhimmanci a kiyaye sadarwarka manyan al'amurra a lokuta kamar `$var * 3` inda `$var` ne `1 + 2`.
    /// Delididdigar keɓaɓɓu na iya tsira daga zagayen rafin token ta cikin layi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Esirƙiri sabon `Group` tare da iyakancewar da aka bayar da rafin token.
    ///
    /// Wannan maginin zai saita tsawon wannan rukunin zuwa `Span::call_site()`.
    /// Don canza jaka zaka iya amfani da hanyar `set_span` da ke ƙasa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Yana dawo da iyakantaccen wannan `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Dawo da `TokenStream` na tokens cewa an delimited a cikin wannan `Group`.
    ///
    /// Lura cewa rafin token da aka dawo ba ya haɗa da iyaka da aka dawo a sama ba.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Yana dawo da forida don iyakancewar wannan rafin token, yana zagaye duka `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Koma span nuna bude delimiter wannan kungiya.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Yana dawo da tsawon da yake nuna iyakar iyakar wannan rukunin.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configures da span ga wannan 'Group` ta delimiters, amma ba ta ciki tokens.
    ///
    /// Wannan hanyar ba **zata** saita tazarar dukkanin tokens na ciki wanda wannan rukuni ya shimfida ba, saidai kawai zai saita tazarar mai iyaka tokens a matakin `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, da gada kawai samar da `to_string`, yi `fmt::Display` dangane da shi (da baya daga cikin saba dangantaka tsakanin biyu).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Kwafi da kungiyar a matsayin wani kirtani cewa ya kamata losslessly canzawa baya cikin wannan kungiya (modulo Al'arshinSa), fãce da yiwu `TokenTree: : Group`s da `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// An `Punct` ne guda alamar rubutu hali kamar `+`, `-` ko `#`.
///
/// Masu aikin haruffa da yawa kamar `+=` ana wakilta azaman yanayi biyu na `Punct` tare da nau'ikan `Spacing` da aka dawo da su.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ko wani `Punct` aka bi nan da nan ta wani `Punct` ko bi ta wani token ko farin.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// misali, `+` ne `Alone` a `+ =`, `+ident` ko `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// misali, `+` shine `Joint` a cikin `+=` ko `'#`.
    /// Allyari akan haka, zancen guda `'` na iya haɗawa tare da masu ganowa don ƙirƙirar rayuwar `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Creatirƙiri sabon `Punct` daga halin da aka bayar da tazara.
    /// Hujjar `ch` dole ne ta zama halayyar alamun rubutu mai inganci wacce yare ya yarda da ita, in ba haka ba aikin zai panic.
    ///
    /// `Punct` da aka dawo zai sami tsaka-tsakin tsaka-tsakin na `Span::call_site()` wanda za'a iya sake daidaita shi tare da hanyar `set_span` a ƙasa.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ya dawo da darajar wannan alamar rubutu kamar `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Dawo da jerawa da wannan alamar rubutu hali, nuna ko shi ke nan da nan ya bi ta hanyar wani `Punct` a token rafi, haka za su iya yiwuwar za a hada a cikin wani Multi-hali sadarwarka (`Joint`), ko da shi ke bi ta wasu token ko farin (`Alone`) haka da sadarwarka yana da haƙĩƙa, ƙare.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Yana dawo da span don wannan alamun rubutu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Sanya tazara don wannan alamun rubutu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, da gada kawai samar da `to_string`, yi `fmt::Display` dangane da shi (da baya daga cikin saba dangantaka tsakanin biyu).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Fitar da alamun rubutu a matsayin kirtani wanda yakamata a canza shi ba ɓacewa cikin hali ɗaya.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Mai ganowa (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Halicci sabon `Ident` da ba `string` kazalika da kayyade `span`.
    /// A `string` shaida dole ne mai aiki ganowa halatta ta harshen (ciki har da keywords, misali `self` ko `fn`).In ba haka ba, da aiki so panic.
    ///
    /// Lura cewa `span`, a halin yanzu a cikin rustc, configures da kiwon lafiya bayanai ga wannan ganowa.
    ///
    /// Tun daga wannan lokacin `Span::call_site()` a bayyane yake ya shiga-zuwa "call-site" tsabtace ma'ana cewa masu gano abubuwan da aka ƙirƙira tare da wannan lokacin za a warware su kamar dai an rubuta su kai tsaye a wurin kiran macro, kuma wasu lambobi a wurin kiran macro za su iya komawa zuwa su ma.
    ///
    ///
    /// Lokaci daga baya kamar `Span::def_site()` zai ba da izinin shiga zuwa "definition-site" tsabtace ma'ana cewa masu gano abubuwan da aka ƙirƙira tare da wannan ƙaddarar za a warware su a wurin bayanin ma'anar macro kuma sauran lambobin a wurin kiran macro ba za su iya koma zuwa gare su ba.
    ///
    /// Saboda yanzu muhimmancin tsabta da wannan constructor, sabanin sauran tokens, na bukatar a `Span` da za a kayyade a yi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Yayi daidai da `Ident::new`, amma yana ƙirƙirar ɗan ganowa (`r#ident`).
    /// A `string` shawara zama mai inganci ganowa halatta ta harshen (ciki har da keywords, misali `fn`).
    /// Keywords wanda suke mai amfani a hanya segments (misali
    /// `self`, ``super`) ba a tallafawa, kuma zai haifar da panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Koma span na wannan `Ident`, Mai kẽwayewa dukan kirtani koma ta [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures da span na wannan `Ident`, yiwu canza ta kiwon lafiya mahallin.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, da gada kawai samar da `to_string`, yi `fmt::Display` dangane da shi (da baya daga cikin saba dangantaka tsakanin biyu).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Fitar da mai ganowa azaman kirtani wanda yakamata ya zama ba zai yiwu a canza shi cikin ainihin mai ganowa ba.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Layin zahiri (`"hello"`), baiti kirtani (`b"hello"`), harafin (`'a'`), baiti harafi (`b'a'`), lamba ko lambar shawagi tare da ko ba kari (``1`, `1u8`, `2.3`, `2.3f32`).
///
/// Boolean literals kamar `true` da `false` da ba su kasance a nan, su ne 'Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Halicci sabon suffixed lamba na zahiri tare da kayyade darajar.
        ///
        /// Wannan aiki zai haifar da wani lamba kamar `1u32` inda lamba darajar kayyade shi ne na farko da wani ɓangare na token da na game aka kuma suffixed a karshen.
        /// Adabin da aka kirkira daga lambobi marasa kyau bazai iya rayuwa ba-zagaye-zagaye ta hanyar `TokenStream` ko kirtani kuma ana iya rabe shi zuwa tokens biyu (`-` da tabbatacce na zahiri).
        ///
        ///
        /// Adabin da aka kirkira ta wannan hanyar suna da nauyin `Span::call_site()` ta tsohuwa, wanda za'a iya daidaita shi tare da hanyar `set_span` da ke ƙasa.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Halicci sabon unsuffixed lamba na zahiri tare da kayyade darajar.
        ///
        /// Wannan aikin zai ƙirƙiri lamba kamar `1` inda ƙimar lamba ta ƙayyade shine farkon ɓangaren token.
        /// Babu kari na baya baki aka kayyade a kan wannan token, ma'ana cewa addu'a kamar `Literal::i8_unsuffixed(1)` ne daidai da `Literal::u32_unsuffixed(1)`.
        /// Literals halitta daga korau lambobin iya ba tsira rountrips ta hanyar `TokenStream` ko kirtani da kuma iya karya cikin biyu tokens (`-` da kyau na zahiri).
        ///
        ///
        /// Adabin da aka kirkira ta wannan hanyar suna da nauyin `Span::call_site()` ta tsohuwa, wanda za'a iya daidaita shi tare da hanyar `set_span` da ke ƙasa.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Irƙirar sabon maƙasudin yatsan ruwa mai ma'ana.
    ///
    /// Wannan maginin yana kama da waɗanda suke kamar `Literal::i8_unsuffixed` inda ana fitar da ƙimar jirgin sama kai tsaye zuwa cikin token amma ba a amfani da ƙarin kari, saboda haka ana iya zama `f64` daga baya a cikin mahaɗin.
    ///
    /// Literals halitta daga korau lambobin iya ba tsira rountrips ta hanyar `TokenStream` ko kirtani da kuma iya karya cikin biyu tokens (`-` da kyau na zahiri).
    ///
    /// # Panics
    ///
    /// Wannan aiki na bukatar cewa a kayyade taso ne guntun, misali idan yana rashin iyaka ko Nan wannan aiki zai panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Creatirƙiri sabon maƙalar madaidaiciyar ma'ana mai zahiri.
    ///
    /// Wannan constructor zai haifar da da na zahiri, kamar `1.0f32` inda darajar kayyade ne gabanin wani ɓangare na token da `f32` ne kari na baya baki na token.
    /// Wannan token ko da yaushe za girman zama wani `f32` a cikin tarawa.
    /// Literals halitta daga korau lambobin iya ba tsira rountrips ta hanyar `TokenStream` ko kirtani da kuma iya karya cikin biyu tokens (`-` da kyau na zahiri).
    ///
    ///
    /// # Panics
    ///
    /// Wannan aiki na bukatar cewa a kayyade taso ne guntun, misali idan yana rashin iyaka ko Nan wannan aiki zai panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Irƙirar sabon maƙasudin yatsan ruwa mai ma'ana.
    ///
    /// Wannan maginin yana kama da waɗanda suke kamar `Literal::i8_unsuffixed` inda ana fitar da ƙimar jirgin sama kai tsaye zuwa cikin token amma ba a amfani da ƙarin kari, saboda haka ana iya zama `f64` daga baya a cikin mahaɗin.
    ///
    /// Literals halitta daga korau lambobin iya ba tsira rountrips ta hanyar `TokenStream` ko kirtani da kuma iya karya cikin biyu tokens (`-` da kyau na zahiri).
    ///
    /// # Panics
    ///
    /// Wannan aiki na bukatar cewa a kayyade taso ne guntun, misali idan yana rashin iyaka ko Nan wannan aiki zai panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Creatirƙiri sabon maƙalar madaidaiciyar ma'ana mai zahiri.
    ///
    /// Wannan constructor zai haifar da da na zahiri, kamar `1.0f64` inda darajar kayyade ne gabanin wani ɓangare na token da `f64` ne kari na baya baki na token.
    /// Wannan token koyaushe za a sanya shi ya zama `f64` a cikin mai tarawa.
    /// Literals halitta daga korau lambobin iya ba tsira rountrips ta hanyar `TokenStream` ko kirtani da kuma iya karya cikin biyu tokens (`-` da kyau na zahiri).
    ///
    ///
    /// # Panics
    ///
    /// Wannan aiki na bukatar cewa a kayyade taso ne guntun, misali idan yana rashin iyaka ko Nan wannan aiki zai panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Kirtani na zahiri.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Character zahiri.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Baiti zahiri
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Koma span ace wannan zahiri.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Yana daidaita fa'idar da ke hade da wannan a zahiri.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Ya dawo da `Span` wanda shine rukuni na `self.span()` wanda ya ƙunshi kawai tushen tushen tushen a kewayon `range`.
    /// Ya dawo `None` idan lokacinda za'a yanke shi yana waje da iyakokin `self`.
    ///
    // FIXME(SergioBenitez): duba cewa zangon baiti yana farawa kuma yana ƙarewa zuwa iyakar UTF-8 na tushen.
    // in ba haka ba, yana da m cewa wani panic zai faru ne a wani wuri a lokacin da tushen rubutun da aka buga.
    // FIXME(SergioBenitez): babu wata hanyar ga mai amfani ga san abin da `self.span()` zahiri maps to, don haka wannan hanya za a iya a halin yanzu kawai za a kira ɗimuwa.
    // Alal misali, `to_string()` ga harafin 'c' kõma "'\u{63}'".babu wata hanyar ga mai amfani a san ko tushen rubutun da aka 'c' ko ko shi '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) wani abu mai kama `Option::cloned`, amma ga `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, da gada kawai samar da `to_string`, yi `fmt::Display` dangane da shi (da baya daga cikin saba dangantaka tsakanin biyu).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Buga a zahiri azaman zaren da yakamata ya zama ba zai iya canzawa zuwa ga rubutu iri ɗaya ba (banda yuwuwar zagayawa don ma'anar ruwa mai iyo).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Hanyar samun damar sauyin yanayi.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Dawo da wani yanayi m kuma ƙara da shi don gina dogara info.
    /// Ginawa tsarin aiwatar da mai tarawa zai san cewa da m aka isa a lokacin tari, kuma za su iya rerun da ginawa a lokacin da darajar da m canza.
    ///
    /// Bayan dogaro da dogaro da wannan aikin ya zama daidai da `env::var` daga daidaitaccen laburaren, sai dai cewa mahawarar dole ne ta zama UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}