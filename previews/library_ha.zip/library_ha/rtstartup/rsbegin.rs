// rsbegin.o kuma rsend.o sune ake kira "compiler runtime startup objects".
// Sun ƙunshi code da ake bukata a daidai initialize da mai tarawa Runtime.
//
// Lokacin da wani executable ko dylib image aka nasaba, duk mai amfani da code da kuma dakunan karatu ne "sandwiched" tsakanin wadannan biyu abu fayiloli, don haka code ko data daga rsbegin.o zama na farko a cikin Game da sassan da image, alhãli kuwa code, kuma data ne daga rsend.o zama na karshe su.
// Wannan sakamako za a iya amfani da su wurin alamu a farko ko a karshen wani sashe, kazalika da saka wani bukata buga kwallo ko footers.
//
// Note cewa ainihin module shigarwa batu ne dake a cikin C Runtime farawa abu (mafi yawa kira `crtX.o`), wanda sai ya kirayi initialization callbacks na sauran Runtime gyara (rajista via duk da haka wani na musamman image sashe).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Alamomin farko na jigon jigon buɗe ɓangaren bayani
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Ratara sarari don ajiyar littafin ciki na mara izini.
    // Wannan aka bayyana a matsayin `struct object` a $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Cire bayanan yau da kullun na registration/deregistration.
    // Duba takardu na libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // rajistar unwind info a kan module farawa
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // yi rajista a kan kashewa
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-takamaiman init/uninit na yau da kullum rajista
    pub mod mingw_init {
        // MinGW ta farawa abubuwa (crt0.o/dllcrt0.o) zai kira duniya constructors a .ctors da .dtors sassan a kan farawa da mafita.
        // A cikin hali na DLLs, wannan da aka yi a lokacin da DLL aka ɗora Kwatancen da kuma unloaded.
        //
        // Mai haɗin yanar gizon zai rarraba sassan, wanda ke tabbatar da cewa kiran kiran mu yana a ƙarshen jerin.
        // Tun constructors suna gudu a baya domin, wannan tabbatar da cewa mu callbacks ne na farko da kuma karshe wadanda hukuncin kisa.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C initialization callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C ƙarshe callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}