#![feature(no_core)]
#![no_core]

// Duba rustc-std-workspace-core don me yasa ake buƙatar wannan crate.

// Sake suna ga crate don kaucewa saɓani tare da tsarin ƙaddamarwa a cikin liballoc.
extern crate alloc as foo;

pub use foo::*;