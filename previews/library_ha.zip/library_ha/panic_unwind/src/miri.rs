//! Unwinding panics for Miri.
use alloc::boxed::Box;
use core::any::Any;

// A irin na dangi cewa Miri engine farfagandar ta hanyar unwinding domin mu.
// Dole ne ya zama akan-sized.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-bayar extern aiki don fara unwinding.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Biyan kuɗin da muka wuce zuwa `miri_start_panic` zai zama daidai gardamar da muka samu a cikin `cleanup` a ƙasa.
    // Saboda haka muna kawai akwatin shi har sau daya, don samun wani abu akan-sized.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Mayar da tushen `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}