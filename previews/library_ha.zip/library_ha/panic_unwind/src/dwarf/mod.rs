//! Kayan more rayuwa ga parsing Dwarf-shigar wanda ke aiki data qarqashinsu.
//! Duba <http://www.dwarfstd.org>, daidaitaccen DWARF-4, Sashe na 7, "Data Representation"
//!

// Ana amfani da wannan rukunin ta x86_64-pc-windows-gnu kawai a yanzu, amma muna tattara shi ko'ina don kauce wa koma baya.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // An cika rafukan DWARF, don haka misali, u32 ba lallai bane ya kasance cikin daidaituwa akan iyaka 4 baiti.
    // Wannan na iya haifar da matsaloli a kan dandamali tare da m jeri bukatun.
    // By wrapping data a wani "packed" struct, mun kasance mãsu backend don samar da "misalignment-safe" code.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 da SLEB128 sakonnin imel suna tsare a Sashen 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}