//! Windows SEH
//!
//! A kan Windows (a halin yanzu akan MSVC kawai), ingantacciyar hanyar sarrafa ma'amala ita ce Tsararren ceptionwarewar Musamman (SEH).
//! Wannan ya sha bamban da yadda aka keɓance na Dwarf (misali, abin da wasu dandamali na unix ke amfani da shi) dangane da abubuwan ciki na tarawa, don haka ana buƙatar LLVM don samun kyakkyawan tallafi na SEH.
//!
//! A takaice, abin da ke faruwa a nan shi ne:
//!
//! 1. A `panic` aiki kira da misali Windows aiki `_CxxThrowException` jefa wani C++ -kamar togiya, triggering da unwinding tsari.
//! 2.
//! All saukowa gammaye generated da mai tarawa amfani da hali aiki `__CxxFrameHandler3`, wani aiki a cikin Crt, da kuma unwinding code a Windows zai yi amfani da wannan hali aiki don kashe duk cleanup code a kan tari.
//!
//! 3. Duk kiran da aka samarda mai tarawa zuwa `invoke` suna da kushin saukowa azaman umarnin `cleanuppad` LLVM, wanda ke nuna farkon aikin tsaftacewa.
//! Halin mutum (a mataki na 2, wanda aka bayyana a cikin CRT) yana da alhakin gudanar da ayyukan tsaftacewa.
//! 4. A ƙarshe lambar "catch" a cikin `try` na asali (wanda mai tarawa ya samar) ana aiwatar da shi kuma yana nuna cewa ikon ya kamata ya dawo zuwa Rust.
//! Ana yin wannan ta hanyar `catchswitch` tare da umarnin `catchpad` a cikin lamuran LLVM IR, a ƙarshe dawo da iko na yau da kullun zuwa shirin tare da umarnin `catchret`.
//!
//! Wasu takamaiman bambance-bambance daga keɓancewar keɓancewar gcc sune:
//!
//! * Rust yana da wani al'ada hali aiki, shi ne maimakon *ko da yaushe*`__CxxFrameHandler3`.Bugu da kari, ba a yin wani karin tacewa, don haka sai mu kama duk wasu kebantattun C++ da ke faruwa kama da irin da muke jefawa.
//! Lura cewa jefa wata togiya a cikin Rust dabi'a ce wacce ba a bayyana ta ba, don haka wannan ya zama daidai.
//! * Muna da wasu bayanai don watsawa a kan iyakokin warwarewa, musamman `Box<dyn Any + Send>`.Kamar tare da keɓaɓɓun keɓaɓɓun waɗannan alamomin guda biyu ana adana su azaman biyan kuɗi in banda kanta.
//! A MSVC, duk da haka, da akwai babu bukatar wani karin heap kasafi saboda kiran tari ne kiyaye yayin da tace ayyuka ana kashe.
//! Wannan yana nufin cewa pointers an shige kai tsaye zuwa `_CxxThrowException` wanda ake sa'an nan gano a cikin tace aikin da za a rubuta zuwa ga tari firam na `try` muhimmi.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Wannan yana buƙatar zama Zaɓi saboda mun kama banda ta hanyar tunani kuma ana kashe mai lalata ta lokacin C++ .
    // Lokacin da muka cire Akwatin daga keɓewa, muna buƙatar barin keɓancewa a cikin ingantacciyar hanya don mai lalata ta ya gudana ba tare da sauke akwatin sau biyu ba.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Da farko up, a dukan bunch na irin ma'anar.Akwai 'yan dandali-takamaiman oddities nan, kuma da yawa da ke kawai zargi kofe daga LLVM.Dalilin duk wannan shi ne a aiwatar da `panic` aiki a kasa ta hanyar kira zuwa `_CxxThrowException`.
//
// Wannan aikin yana ɗaukar muhawara biyu.Na farko shine manuniya akan bayanan da muke wucewa, wanda a wannan yanayin shine abin mu na trait.Pretty sauki sami!Na gaba, duk da haka, ya fi rikitarwa.
// Wannan alama ce ga tsarin `_ThrowInfo`, kuma gabaɗaya ana nufin kawai don kawai bayyana keɓancewar da ake jefawa.
//
// A halin yanzu da definition irin wannan [1] ne kadan m, da kuma babban oddity (da bambanci daga online labarin) yana cewa a 32-cije da pointers ne pointers amma a kan 64-cije da pointers aka bayyana a matsayin 32-bit offsets daga Alamar `__ImageBase`
//
// `ptr_t` da `ptr!` macro a cikin matakan da ke ƙasa ana amfani da su don bayyana wannan.
//
// Ma'anar ma'anar maanar tana bin abin da LLVM ke fitarwa don irin wannan aikin.Misali, idan kun tara wannan lambar C++ akan MSVC kuma kuka fitar da LLVM IR:
//
//      #include <stdint.h>
//
//      Tsarin rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2].};
//
//      wofi foo() { rust_panic a = {0, 1};
//          jefa a;}
//
// Wannan shi ne ainihin abin da muke ƙoƙarin yin koyi da shi.Mafi yawan ƙa'idodin da ke ƙasa an kwafe su daga LLVM,
//
// A kowane hali, waɗannan gine-ginen duk an gina su cikin irin wannan yanayin, kuma kawai ɗan magana ne a gare mu.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Lura cewa da gangan muke watsi da dokokin mangling suna a nan: ba ma son C++ ya sami damar kama Rust panics ta hanyar kawai bayyana `struct rust_panic`.
//
//
// Lokacin gyara, tabbatar cewa nau'in layin suna daidai yayi daidai da wanda aka yi amfani dashi a cikin `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Babban jagorar baiti `\x01` a nan ainihin alama ce ta sihiri ga LLVM don *ba* amfani da kowane ɗayan manji kamar prefixing tare da halin `_`.
    //
    //
    // Wannan alamar ita ce vtable da C++ 's `std::type_info` ke amfani da shi.
    // Abubuwa na nau'in `std::type_info`, masu siffantawa, suna da nuni zuwa wannan tebur.
    // Nau'in masu kwatancen rubutu ana amfani dasu ta tsarin C++ EH wanda aka bayyana a sama kuma muke ginawa a ƙasa.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Wannan nau'in mai ba da bayanin ana amfani dashi ne kawai yayin jefa wani banda.
// Ana ɗaukar ɓangaren kamawa ta hanyar gwadawa, wanda ke haifar da TypeDescriptor nasa.
//
// Wannan yana da kyau tunda lokacin tafiyar MSVC yana amfani da kwatancen kirtani akan nau'in suna don dacewa da TypeDescriptors maimakon nuna daidaito.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor amfani idan C++ code yanke shawarar da ya kama da togiya da sauke shi ba tare da yada shi.
// Catchangaren kamun gwaji na ainihi zai saita kalmar farko ta ƙarancin abu zuwa 0 don haka mai lalacewa ya tsallake shi.
//
// Lura cewa x86 Windows yayi amfani da taron kira na "thiscall" don ayyukan membobin C++ maimakon tsoho kiran taron "C".
//
// Aikin keɓaɓɓiyar_kopy abu ne na musamman a nan: lokacin aiki na MSVC yana ƙarƙashin kira na try/catch da panic da muka samar anan za a yi amfani da shi azaman kwafin keɓaɓɓe.
//
// Wannan da ake amfani da C++ Runtime don tallafa kamawa ware tare da std::exception_ptr, wanda ba za mu iya tallafa saboda Box<dyn Any>ba clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException yana aiwatarwa kwata-kwata a kan wannan ginshiƙan, don haka babu buƙatar sake canza `data` zuwa tudun.
    // Mun wuce kawai nuna alama ga wannan aikin.
    //
    // Ana buƙatar ManuallyDrop a nan tunda ba ma son a sauke Fitar lokacin buɗewa.
    // Maimakon haka shi za a kika aika da exception_cleanup wanda aka ambaci da C++ Runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Wannan ... na iya zama abin mamaki, kuma da hujja haka.A 32-bit MSVC da pointers tsakanin wadannan tsarin ne kawai cewa, pointers.
    // A kan 64VC bit MSVC, kodayake, ana nuna alamun tsakanin tsarin azaman ƙarancin 32-bit daga `__ImageBase`.
    //
    // Sakamakon haka, akan 32-bit MSVC zamu iya bayyana duk waɗannan alamomin a cikin ``tsayayyen`s sama.
    // A 64-bit MSVC, za mu yi bayyana subtraction na pointers a statics, wanda Rust ba a halin yanzu ba da damar, don haka ba za mu iya zahiri yi cewa.
    //
    // A gaba mafi kyau abu, sa'an nan shi ne cika a cikin wadannan Tsarin at Runtime (panicking ne riga da "slow path" ta wata hanya).
    // Don haka a nan zamu sake fassara dukkan waɗannan fannonin nuna alama azaman 32-bit lambobi sannan mu adana ƙimar da ta dace a ciki (atomatik, kamar yadda panics mai haɗuwa ke faruwa).
    //
    // Ta hanyar fasaha lokacin aiki zai iya yin karatun bazuwar waɗannan fannoni, amma a ka'ida ba za su taɓa karanta ƙimar *ba daidai ba* don haka bai kamata ya zama mummunan ba ...
    //
    // A kowane hali, muna buƙatar yin abu kamar wannan har sai mun iya bayyana ƙarin ayyuka a cikin ilimin lissafi (kuma ƙila ba za mu iya ba).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // A null dangi a nan yana nufin cewa mu samu a nan daga kama (...) na __rust_try.
    // Wannan ya faru a lokacin da wani maras Rust waje togiya ne kama.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Mai tarawa ya buƙaci wannan ya wanzu (misali, abu ne mai nishaɗi), amma mai tarawa ba ya taɓa kiransa saboda __C_specific_handler ko_except_handler3 shine halin mutumcin da ake amfani dashi koyaushe.
//
// Don haka wannan ɗan tsako ne kawai.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}