//! Unwinding for *emscripten* manufa.
//!
//! Ganin cewa Rust ta saba unwinding aiwatar for Unix dandamali kira a cikin libunwind APIs kai tsaye, a kan Emscripten mu maimakon kira a cikin C++ unwinding APIs.
//! Wannan shi ne kawai wani expedience tun Emscripten ta Runtime ko da yaushe aiwatar da waɗanda APIs kuma ba ya yi libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Wannan yayi daidai da fasalin std::type_info a cikin C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Babban jagorar baiti `\x01` a nan ainihin alama ce ta sihiri ga LLVM don *ba* amfani da kowane ɗayan manji kamar prefixing tare da halin `_`.
    //
    //
    // Wannan alamar ita ce vtable da C++ 's `std::type_info` ke amfani da shi.
    // Abubuwa na nau'in `std::type_info`, masu siffantawa, suna da nuni zuwa wannan tebur.
    // Nau'in masu kwatancen rubutu ana amfani dasu ta tsarin C++ EH wanda aka bayyana a sama kuma muke ginawa a ƙasa.
    //
    // Lura cewa ainihin girman ya fi girma fiye da amfani da 3, amma kawai muna buƙatar ikon mu don nunawa zuwa ɓangare na uku.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info don ajin tsatsa_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Kullum za mu yi amfani da .as_ptr().add(2) amma wannan bai yi aiki ba a wata const mahallin.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Wannan da gangan ba ya amfani da makircin mangogi na al'ada saboda ba ma son C++ ya iya samarwa ko kama Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Wannan ya zama dole saboda lambar C++ na iya ɗaukar aiwatarwarmu tare da std::exception_ptr kuma sake maimaita shi sau da yawa, ƙila ma a cikin wani zaren.
    //
    //
    caught: AtomicBool,

    // Wannan yana buƙatar zama Zaɓi saboda rayuwar abu yana bin ma'anar C++ : lokacin da kama_unwind ya motsa Akwatin daga keɓance to dole ne har yanzu ya bar keɓaɓɓen abin a cikin halaye mai inganci saboda har yanzu __cxa_end_catch zai kira mai lalata shi.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try a zahiri ya bamu manuni ga wannan tsarin.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Tunda ba'a bawa cleanup() izuwa panic ba, kawai muna zubar da ciki ne.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}