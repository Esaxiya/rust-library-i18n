//! Aiwatar da panics mai goyan bayan libgcc/libunwind (a wani nau'i).
//!
//! Domin bango a kan togiya handling da kuma tari unwinding don Allah ga "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) da takardun nasaba daga gare ta.
//! Wadannan ma suna da kyau karanta:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Takaitaccen bayani
//!
//! Keɓancewa daban yana faruwa a matakai biyu: lokacin bincike da tsabtace lokaci.
//!
//! A cikin duka bulan da unwinder tafiya tari Frames daga sama zuwa kasa yin amfani da bayanai daga tari frame unwind sassan na halin yanzu tsari ta kayayyaki ("module" nan na nufin wani OS module, watau, wani executable ko wani mashahurin library).
//!
//!
//! Ga kowane tari frame, shi kiran hade "personality routine", wanda adireshin da aka ma adana a cikin unwind info sashe.
//!
//! A search lokaci, da aiki na wani hali na yau da kullum ne, don su bincika togiya abu da ake jẽfa, da kuma yanke shawarar ko ya kamata a kama a cewa tari firam.Da zarar an gano ƙirar mai sarrafawa, tsabtace lokaci zai fara.
//!
//! A cikin tsabtace tsabta, wanda ba a so ya sake kiran kowane halin mutum.
//! Wannan lokaci shi ya yanke shawarar wanda (idan wani) cleanup code bukatun da za a gudanar domin yanzu tari firam.Idan haka ne, ana canza ikon zuwa branch na musamman a cikin jikin aiki, "landing pad", wanda ke kiran masu lalata, yantar da ƙwaƙwalwar ajiya, da dai sauransu.
//! A karshen saukowa kushin, da iko aka canjawa wuri baya ga unwinder da unwinding ya dawo.
//!
//! Da zarar an buɗe tarin har zuwa matakin mai kulawa, buɗe tashoshi da kuma halin mutum na ƙarshe yana canza iko zuwa toshe abin kama.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Mai gano aji na banda Rust.
// Ana amfani da wannan ta hanyar abubuwan yau da kullun na mutum don tantance ko banda ya jefa su ne lokacin aikin su.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 tsatsa-mai sayarwa, harshe
    0x4d4f5a_00_52555354
}

// Rajistar ID aka dauke daga LLVM ta TargetLowering::getExceptionPointerRegister() da TargetLowering::getExceptionSelectorRegister() ga kowane gine-gine, sa'an nan tsara don Dwarf littãfi lambobin via littãfi definition alluna (yawanci<arch>RegisterInfo.td, bincika "DwarfRegNum").
//
// Duba kuma http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, - R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Wadannan code dogara ne a kan GCC ta C da kuma C++ hali routines.Don tunani, duba:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI hali na yau da kullum.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS yana amfani da aikin yau da kullun maimakon tunda yana amfani da SjLj kwance.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces a hannu zai kira da hali na yau da kullum da jihar==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // A waɗancan lokuta muna so mu ci gaba da kwance ragamar, in ba haka ba duk abubuwan da muke bi baya zasu ƙare a __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // A Dwarf unwinder kwakwalwa gaba da cewa_Unwind_Context riko da abubuwa kamar aiki da LSDA pointers, duk da haka hannu EHABI sanya su a cikin togiya abu.
            // Don adana sa hannu na ayyuka kamar _Unwind_GetLanguageSpecificData(), wanda ke ɗaukar ma'anar mahallin kawai, ayyukan GCC na yau da kullun suna nuna mai nuna alama zuwa keɓaɓɓiyar magana a cikin mahallin, ta amfani da wurin da aka keɓe don ARM's "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Hanya mafi ƙa'ida za ta kasance don samar da cikakkiyar ma'anar ARM ta_Unwind_Context a cikin haɗin haɗin libunwind ɗinmu da kuma nemo bayanan da ake buƙata daga can kai tsaye, ta hanyar keta ayyukan haɗin DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI yana buƙatar tsarin al'ada don sabunta darajar SP a cikin ɓoye shingen abin togiya.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // A hannu EHABI hali na yau da kullum ne alhakin zahiri unwinding guda tari frame kafin ya dawo (hannu EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // an bayyana a cikin libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Default hali na yau da kullum, wanda aka yi amfani kai tsaye a kan mafi hari da kuma a kaikaice a kan Windows x86_64 via Seh.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // A x86_64 MinGW hari, da unwinding inji shi ne Seh duk da haka da unwind horo data (aka LSDA) yana amfani da GCC-jituwa tsarinsa.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // The hali na yau da kullum ga mafi yawan mu hari.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Adireshin dawowa ya nuna baiti 1 ya wuce koyarwar kira, wanda zai iya kasancewa a cikin kewayon IP na gaba a cikin teburin zangon LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Madauki unwind info rajista
//
// Kowace a koyaushe ta image ƙunshi frame unwind info sashe (yawanci ".eh_frame").Lokacin da wani koyaushe ne loaded/unloaded a cikin tsari, da unwinder dole ne a sanar da game da wurin da wannan sashe a cikin ƙwaƙwalwar ajiyar.Hanyoyin cin nasara waɗanda suka bambanta da dandamali.
// A wasu (misali, Linux), da unwinder iya gano unwind info sassan da kansa (da kuzari enumerating a halin yanzu ɗora Kwatancen kayayyaki via da dl_iterate_phdr() API and finding their ".eh_frame" sections). Others, kamar Windows, bukatar kayayyaki zuwa rayayye su yi rajistar unwind info sassan via unwinder API.
//
//
// Wannan module ma'anar biyu alamomin wanda ake nusar da kuma kira daga rsbegin.rs yin rajistar mu bayanai tare da GCC Runtime.
// Aiwatar da shimfida shara ta kwance (a yanzu) an jinkirta ta zuwa libgcc_eh, duk da haka Rust crates suna amfani da waɗannan takamaiman wuraren shigarwar Rust don kauce wa rikici tare da kowane lokacin GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}