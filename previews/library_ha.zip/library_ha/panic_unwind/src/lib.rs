//! Aiwatar da panics via tari unwinding
//!
//! Wannan crate aiwatarwa ce ta panics a cikin Rust ta amfani da kayan kwance kwance na "most native" na dandamali wannan ana tattara shi.
//! Wannan gaske samun kasafta cikin uku buckets a halin yanzu:
//!
//! 1. Manufofin MSVC suna amfani da SEH a cikin fayil ɗin `seh.rs`.
//! 2. Emscripten yana amfani da C++ ware a cikin `emcc.rs` fayil.
//! 3. Duk sauran abubuwan da aka sa gaba suna amfani da libunwind/libgcc a cikin fayil ɗin `gcc.rs`.
//!
//! More takardun game da kowane aiwatar za a iya samu a cikin Game da koyaushe.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ne sauran tare da Miri, don haka shiru gargadi.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust Runtime ta farawa abubuwa dogara ne a kan wadannan alamomin, don haka sanya su jama'a.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Manufofin da ba sa tallafawa kwancewa.
        // - arch=wasm32
        // - os=m ("bare metal" hari)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Yi amfani da Miri Runtime.
        // Har yanzu muna buƙatar loda lokacin aikin da ke sama, kamar yadda rustc ke tsammanin za a bayyana wasu lalatattun abubuwa daga can.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Yi amfani da ainihin lokacin gudu.
        use real_imp as imp;
    }
}

extern "C" {
    /// Mai kulawa a cikin libstd ya kira lokacin da aka sauke abu panic a waje da `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Horo a libstd kira a lokacin da wani waje togiya ne kama.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Wurin shigarwa don haɓaka keɓancewa, kawai wakilai ne ga takamaiman aiwatar da dandamali.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}