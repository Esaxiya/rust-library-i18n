# `rustc-std-workspace-std` crate

Dubi takardun ga `rustc-std-workspace-core` crate.