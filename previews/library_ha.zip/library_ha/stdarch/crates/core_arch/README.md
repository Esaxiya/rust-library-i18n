`core::arch` - Rust ta ainihin ɗakunan gine-ginen ɗakunan karatu na musamman
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Aikin `core::arch` yana aiwatar da abubuwan da suka dogara da gine-gine (misali SIMD).

# Usage 

`core::arch` yana samuwa azaman wani ɓangare na `libcore` kuma ana sake fitar dashi ta `libstd`.Fi son yin amfani da shi via `core::arch` ko `std::arch` fiye da via wannan crate.
Ana samun samfuran marasa ƙarfi a cikin dare Rust ta hanyar `feature(stdsimd)`.

Amfani da `core::arch` ta wannan crate yana buƙatar Rust da daddare, kuma yana iya (kuma ya aikata) karyawa sau da yawa.Lamarin kawai da yakamata kayi la'akari da amfani da shi ta wannan crate sune:

* idan kuna buƙatar sake tattara `core::arch` da kanku, misali, tare da keɓaɓɓiyar siffofin fasali waɗanda aka kunna waɗanda ba a kunna su ba don `libcore`/`libstd`.
Note: idan kuna buƙatar sake tattara shi don manufa mara daidaituwa, da fatan za ku fi son amfani da `xargo` kuma sake tattara `libcore`/`libstd` yadda ya dace maimakon amfani da wannan crate.
  
* ta amfani da wasu sifofi waɗanda ƙila ba za a same su ba ko da a bayan fasalulluran Rust.Muna ƙoƙarin kiyaye waɗannan zuwa mafi ƙarancin.
Idan kana bukatar ka yi amfani da wasu daga cikin wadannan siffofin, don Allah bude wani batun haka da cewa ba za mu iya bijirar da su a cikin kwãna Rust kuma za ka iya amfani da su daga can.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` An rarraba shi sosai a ƙarƙashin sharuɗɗan lasisin MIT da Apache Lasisi (Sigar 2.0), tare da ɓangarorin da ke rufe lasisi iri iri na BSD.

Duba LICENCE-APACHE, da LICENSE-MIT don cikakkun bayanai.

# Contribution

Sai dai in kun faɗi sabanin haka, duk gudummawar da aka gabatar da gangan don haɗawa a cikin `core_arch` daga gare ku, kamar yadda aka bayyana a cikin lasisin Apache-2.0, zai zama mai lasisi biyu kamar yadda yake a sama, ba tare da ƙarin ƙarin sharuɗɗa ko sharuɗɗa ba.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












