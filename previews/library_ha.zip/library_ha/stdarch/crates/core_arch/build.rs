use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Anyi amfani dashi don gayawa bayanin mu na `#[assert_instr]` cewa duk samfuran simd suna samuwa don gwada codegen su, tunda wasu ana ƙofar su ta bayan ƙarin `-Ctarget-feature=+unimplemented-simd128` wanda bashi da kwatankwacinsa a cikin `#[target_feature]` a yanzu.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}