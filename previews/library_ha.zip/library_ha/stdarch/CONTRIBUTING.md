# Gudunmawa ga stdarch

A `stdarch` crate ne fiye da son su karbi gudunmawar!Da farko tabbas kuna son bincika ma'ajiyar kuma ku tabbatar cewa gwaje-gwaje sun wuce ku:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Inda `<your-target-arch>` shine manufa sau uku kamar yadda `rustup` yayi amfani da shi, misali `x86_x64-unknown-linux-gnu` (ba tare da wani `nightly-` na gaba ba ko makamancin haka).
Har ila yau tuna cewa wannan mangaza bukatar da kwãna tashar na Rust!
The sama gwaje-gwaje yi a gaskiya bukatar kwãna rust zama tsoho a kan tsarin da ya sa da cewa yin amfani da `rustup default nightly` (da `rustup default stable` to koma).

Idan ɗayan matakan da ke sama ba suyi aiki ba, [please let us know][new]!

Nan gaba zaku iya [find an issue][issues] don taimakawa gaba, mun zaɓi yan kaɗan tare da alamun [`help wanted`][help] da [`impl-period`][impl] waɗanda zasu iya amfani da wasu taimako musamman. 
Wataƙila kuna da sha'awar [#40][vendor], aiwatar da duk abubuwan da aka siyar dillalai akan x86.Wannan batun yana da kyawawan alamu game da inda za'a fara!

Idan kuna da cikakkun tambayoyin jin kyauta ga [join us on gitter][gitter] kuma kuyi tambaya!Feel free to ping ko dai@BurntSushi ko@alexcrichton da tambayoyi.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Yadda ake rubuta misalai don abubuwan da suka shafi stdarch

Akwai featuresan fasali waɗanda dole ne a kunna su don asalin da aka bayar yayi aiki yadda yakamata kuma dole ne a gudanar da misali ta `cargo test --doc` kawai lokacin da fasalin ke tallafawa da CPU.

A sakamakon haka, tsoho `fn main` cewa an generated da `rustdoc` zai yi aiki ba (a mafi yawan lokuta).
Ka yi la'akari da amfani da wadannan a matsayin jagora don tabbatar da misali da ayyuka a matsayin sa ran.

```rust
/// # // Muna buƙatar cfg_target_feature don tabbatar da misalin kawai ne
/// # // gudana ta `cargo test --doc` lokacin da CPU ke goyan bayan fasalin
/// # #![feature(cfg_target_feature)]
/// # // Muna buƙatar target_feature don ainihin ya yi aiki
/// # #![feature(target_feature)]
/// #
/// # // rustdoc da tsoho yana amfani da `extern crate stdarch`, amma muna bukatar da
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // The real babban aiki
/// # FN main() {
/// #     // Gudanar da wannan kawai idan `<target feature>` yana tallafawa
/// #     idan cfg_feature_enabled! (""<target feature>"){
/// #         // Irƙiri aikin `worker` wanda kawai za a gudanar idan fasalin fasalin
/// #         // ana tallafawa kuma tabbatar cewa an kunna `target_feature` don ma'aikacin ku
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         amintacce fn worker() {
/// // Rubuta misalin ka anan.Feature takamaiman abin da ke ciki zai yi aiki a nan!Ku tafi daji!
///
/// #         }
///
/// #         amintacce { worker(); }
/// #     }
/// # }
```

Idan wasu kalmomin da ke sama ba su saba ba, sashin [Documentation as tests] na [Rust Book] ya bayyana haɗin `rustdoc` sosai.
Kamar koyaushe, jin kyauta ga [join us on gitter][gitter] kuma ka tambaye mu idan kun buge kowane suruɗi, kuma na gode da kuka taimaka don inganta takardun `stdarch`!

# Umarnin Gwaji na dabam

Gabaɗaya ana ba da shawarar cewa kayi amfani da `ci/run.sh` don gudanar da gwaje-gwajen.
Koyaya wannan bazai iya muku aiki ba, misali idan kuna kan Windows.

A wannan yanayin zaku iya komawa ga gudana `cargo +nightly test` da `cargo +nightly test --release -p core_arch` don gwada ƙirar lambar.
Lura cewa waɗannan suna buƙatar shigarwar kayan aikin dare da `rustc` don sanin makasudin ku sau uku da CPU.
Musamman kuna buƙatar saita yanayin yanayi na `TARGET` kamar yadda kuke don `ci/run.sh`.
Bugu da kari kuna buƙatar saita `RUSTCFLAGS` (buƙatar `C`) don nuna fasalin manufa, misali `RUSTCFLAGS="-C -target-features=+avx2"`.
Hakanan zaka iya saita `-C -target-cpu=native` idan kuna "just" masu haɓakawa akan CPU ɗinku na yanzu.

Yi gargadin cewa lokacin da kake amfani da waɗannan madadin umarnin, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], misali
umurci tsara gwaje-gwaje iya kasa saboda disassembler ambace su da su daban, misali
yana iya samar da `vaesenc` maimakon umarnin `aesenc` duk da suna yin abu ɗaya.
Hakanan waɗannan umarnin suna yin ƙasa da gwaje-gwaje fiye da yadda aka saba yi, don haka kar kuyi mamakin cewa lokacin da kuka ɗaga-neman wasu kurakurai na iya bayyana ga gwaje-gwajen da ba'a rufe su anan ba.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






