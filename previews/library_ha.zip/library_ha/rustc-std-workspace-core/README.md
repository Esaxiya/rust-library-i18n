# `rustc-std-workspace-core` crate

Wannan crate ne a shim da komai crate wanda kawai ya dogara da `libcore` da reexports duk abinda ke ciki.
A crate ne crux na karfafawa da misali library to dogara ne kan crates daga crates.io

Crates a kan crates.io cewa misali library dogara ne kan bukatar dogara ne a kan `rustc-std-workspace-core` crate daga crates.io, wanda shi ne komai.

Muna amfani da `[patch]` don share shi zuwa wannan crate a cikin wannan ma'ajiyar.
Sakamakon haka, crates akan crates.io zai zana dogaro edge zuwa `libcore`, sigar da aka bayyana a cikin wannan ma'ajiyar.
Wannan yakamata ya zana dukkan gefunan dogaro don tabbatar da Cargo ya gina crates cikin nasara!

Lura cewa crates akan crates.io suna buƙatar dogaro da wannan crate tare da suna `core` don komai yayi aiki daidai.Don yin hakan zasu iya amfani da:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Ta hanyar amfani da `package` key da crate aka sake masa suna zuwa `core`, ma'ana shi za kama

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

idan Cargo kiran da mai tarawa, gamsarwa da a fakaice `extern crate core` umarnin allura da mai tarawa.




