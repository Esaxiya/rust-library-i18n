//! Размотка panics для Міры.
use alloc::boxed::Box;
use core::any::Any;

// Тып карыснай нагрузкі, якую рухавік Miri распаўсюджвае, раскручваючыся для нас.
// Павінна быць памерам паказальніка.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Знешняя функцыя, прадастаўленая Miri, пачынае раскручвацца.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Карысная нагрузка, якую мы перадаем `miri_start_panic`, будзе менавіта такім аргументам, які мы атрымаем у `cleanup` ніжэй.
    // Такім чынам, мы проста разбіраем яго, каб атрымаць нешта памерам з паказальнік.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Аднавіце асноўны `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}