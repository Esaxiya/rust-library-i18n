//! Windows SEH
//!
//! На Windows (у цяперашні час толькі на MSVC) механізмам апрацоўкі выключэнняў па змаўчанні з'яўляецца структураваная апрацоўка выключэнняў (SEH).
//! Гэта зусім іншае, чым апрацоўка выключэнняў на аснове Гномаў (напрыклад, тое, што выкарыстоўваюць іншыя платформы unix) з пункту гледжання ўнутраных кампілятараў, таму LLVM павінен мець шмат дадатковай падтрымкі SEH.
//!
//! У двух словах, што тут адбываецца:
//!
//! 1. Функцыя `panic` выклікае стандартную функцыю Windows `_CxxThrowException` для выдалення выключэння, падобнага на C++ , і выклікае працэс размоткі.
//! 2.
//! Усе пасадкавыя пляцоўкі, створаныя кампілятарам, выкарыстоўваюць асабістую функцыю `__CxxFrameHandler3`, функцыю ў ЭПТ, а код размоткі ў Windows будзе выкарыстоўваць гэтую асабістую функцыю для выканання ўсяго ачышчальнага кода ў стэку.
//!
//! 3. Усе званкі, створаныя кампілятарам на `invoke`, маюць пасадкавую пляцоўку, усталяваную ў якасці інструкцыі L01V L01, якая паказвае на пачатак працэдуры ачысткі.
//! Асоба (на этапе 2, вызначаным у ЭПТ) адказвае за выкананне працэдур ачысткі.
//! 4. У рэшце рэшт код "catch" ва ўласным `try` (згенераваны кампілятарам) выконваецца і паказвае, што кіраванне павінна вярнуцца ў Rust.
//! Гэта робіцца праз інструкцыю `catchswitch` плюс інструкцыю `catchpad` у тэрмінах ВК-LLVM, нарэшце, вяртаючы нармальны кантроль праграме з інструкцыяй `catchret`.
//!
//! Некаторыя канкрэтныя адрозненні ад апрацоўкі выключэнняў на аснове gcc:
//!
//! * Rust не мае ўласнай індывідуальнай функцыі, замест гэтага *заўсёды*`__CxxFrameHandler3`.Акрамя таго, дадатковая фільтрацыя не выконваецца, таму ў выніку мы выяўляем любыя выключэнні C++ , якія здаюцца падобнымі на тое, што мы кідаем.
//! Звярніце ўвагу, што выкід выключэння ў Rust у любым выпадку не вызначаны, таму гэта павінна быць нармальна.
//! * У нас ёсць некаторыя дадзеныя для перадачы праз мяжу размоткі, у прыватнасці, `Box<dyn Any + Send>`.Як і ў выпадку з гномскімі выключэннямі, гэтыя два паказальнікі захоўваюцца як карысная нагрузка ў самім выключэнні.
//! Аднак у MSVC няма неабходнасці ў дадатковым размеркаванні кучы, таму што стэк выклікаў захоўваецца, пакуль выконваюцца функцыі фільтра.
//! Гэта азначае, што паказальнікі перадаюцца непасрэдна ў `_CxxThrowException`, якія потым аднаўляюцца ў функцыі фільтра для запісу ў фрэйм стэка ўласнай `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Гэта павінен быць варыянт, таму што мы выяўляем выключэнне шляхам спасылкі, і яго дэструктар выконваецца падчас выканання C++ .
    // Калі мы вымаем скрынку з выключэння, нам трэба пакінуць выключэнне ў сапраўдным стане, каб яго дэструктар працаваў, не выдаляючы скрынку двойчы.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Спачатку цэлая куча азначэнняў тыпаў.Тут ёсць некалькі дзівацтваў, звязаных з пэўнай платформай, і шмат, што проста нахабна скапіявана з LLVM.Мэта ўсяго гэтага-рэалізаваць функцыю `panic` ніжэй праз званок да `_CxxThrowException`.
//
// Гэтая функцыя прымае два аргументы.Першы-гэта паказальнік на дадзеныя, якія мы перадаём, а ў дадзеным выпадку гэта наш аб'ект Portrait.Даволі проста знайсці!Наступнае, аднак, больш складанае.
// Гэта ўказальнік на структуру `_ThrowInfo`, і ён, як правіла, прызначаны проста для апісання выкліканага выключэння.
//
// У цяперашні час вызначэнне гэтага тыпу [1] крыху валасатае, і галоўная дзівацтва (і адрозненне ад Інтэрнэт-артыкула) заключаецца ў тым, што на 32-бітных паказальнікі з'яўляюцца паказальнікамі, а на 64-бітных паказальнікі выяўляюцца як 32-бітныя зрушэнні ад Сімвал `__ImageBase`.
//
// Для выражэння гэтага выкарыстоўваюцца макрасы `ptr_t` і `ptr!` у прыведзеных ніжэй модулях.
//
// Лабірынт азначэнняў тыпаў таксама ўважліва сочыць за тым, што LLVM выдзяляе для такога роду аперацый.Напрыклад, калі вы скампілюеце гэты код C++ на MSVC і выпраміце ВК LLVM:
//
//      #include <stdint.h>
//
//      структура rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      пустэча foo() { rust_panic a = {0, 1};
//          кінуць a;}
//
// Па сутнасці, гэта тое, што мы спрабуем пераймаць.Большасць значэнняў пастаянных значэнняў проста скапіяваны з LLVM,
//
// У любым выпадку, усе гэтыя структуры пабудаваны падобным чынам, і для нас гэта проста шматслоўна.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Звярніце ўвагу, што мы наўмысна ігнаруем правілы маніпуляцыі імёнамі: мы не хочам, каб C++ мог лавіць Rust panics, проста аб'явіўшы `struct rust_panic`.
//
//
// Пры мадыфікацыі пераканайцеся, што радок імя тыпу дакладна адпавядае таму, які выкарыстоўваецца ў `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Вядучы байт `\x01` тут на самай справе з'яўляецца магічным сігналам да LLVM, каб *не* прымяняць любыя іншыя дэфармацыі, такія як прэфікс з сімвалам `_`.
    //
    //
    // Гэты сімвал з'яўляецца vtable, які выкарыстоўваецца `std::type_info` C++ .
    // Аб'екты тыпу `std::type_info`, дэскрыптары тыпу, маюць паказальнік на гэтую табліцу.
    // На дэскрыптары тыпаў спасылаюцца структуры C++ EH, вызначаныя вышэй, і якія мы будуем ніжэй.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Гэты дэскрыптар тыпу выкарыстоўваецца толькі пры выдаленні выключэння.
// Частка ўлову апрацоўваецца ўнутранай спробай, якая стварае ўласны TypeDescriptor.
//
// Гэта выдатна, бо час выканання MSVC выкарыстоўвае параўнанне радкоў у імя тыпу, каб адпавядаць TypeDescriptors, а не роўнасці паказальніка.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Дэструктар выкарыстоўваецца, калі код C++ вырашае захапіць выключэнне і выдаліць яго без распаўсюджвання.
// Частка catch унутранай спробы ўсталюе для першага слова аб'екта выключэння 0, каб дэструктар прапусціў яго.
//
// Звярніце ўвагу, што x86 Windows выкарыстоўвае канвенцыю выклікаў "thiscall" для функцый члена C++ замест умовы выклікаў "C" па змаўчанні.
//
// Функцыя exception_copy тут трохі адмысловая: яна выклікаецца падчас выканання MSVC пад блокам try/catch, і panic, які мы тут ствараем, будзе выкарыстоўвацца ў выніку копіі выключэння.
//
// Гэта выкарыстоўваецца падчас выканання C++ для падтрымкі захопу выключэнняў з std::exception_ptr, якія мы не можам падтрымаць, таму што Box<dyn Any>не клануецца.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException выконваецца цалкам на гэтым фрэйме стэка, таму няма неабходнасці пераносіць `data` у кучу.
    // Мы проста перадаем паказальнік стэка гэтай функцыі.
    //
    // Тут патрэбен ManuallyDrop, бо мы не хочам, каб выключэнне адпускалася пры размотцы.
    // Замест гэтага ён будзе скінуты з izuzetka_cleanup, які выклікаецца падчас выканання C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Гэта ... можа падацца дзіўным, і гэта абгрунтавана.На 32-разрадным MSVC паказальнікі паміж гэтымі структурамі-гэта толькі паказальнікі.
    // Аднак на 64-бітным MSVC указальнікі паміж структурамі хутчэй выяўляюцца як 32-бітныя зрушэнні ад `__ImageBase`.
    //
    // Такім чынам, на 32-бітным MSVC мы можам аб'явіць усе гэтыя паказальнікі ў "статычных" вышэй.
    // На 64-разрадным MSVC нам трэба было б выказаць адніманне паказальнікаў у статыцы, чаго Rust у цяперашні час не дазваляе, таму мы на самой справе гэтага зрабіць не можам.
    //
    // Наступнае самае лепшае-запаўняць гэтыя структуры падчас выканання (паніка ў любым выпадку ўжо "slow path").
    // Такім чынам, тут мы пераасэнсоўваем усе гэтыя палі ўказальнікаў як 32-разрадныя цэлыя лікі, а затым захоўваем у іх адпаведнае значэнне (атамна, бо адначасова можа адбывацца panics).
    //
    // Тэхнічна час выканання, верагодна, будзе праводзіць неатамнае счытванне гэтых палёў, але тэарэтычна яны ніколі не чытаюць значэнне *няправільна*, таму гэта не павінна быць дрэнна ...
    //
    // У любым выпадку нам трэба зрабіць нешта накшталт гэтага, пакуль мы не зможам выказаць больш аперацый у статыцы (і, магчыма, мы ніколі не зможам).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Нулявая карысная нагрузка тут азначае, што мы трапілі сюды з улову (...) __rust_try.
    // Гэта адбываецца, калі выяўляецца замежнае выключэнне, якое не з'яўляецца Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Гэта патрабуецца кампілятару для існавання (напрыклад, гэта элемент lang), але на самой справе ён ніколі не выклікаецца кампілятарам, таму што __C_specific_handler або _except_handler3-гэта функцыя асобы, якая заўсёды выкарыстоўваецца.
//
// Такім чынам, гэта проста перарываецца заглушка.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}