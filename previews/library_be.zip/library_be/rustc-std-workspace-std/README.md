# `rustc-std-workspace-std` crate

Глядзіце дакументацыю для `rustc-std-workspace-core` crate.