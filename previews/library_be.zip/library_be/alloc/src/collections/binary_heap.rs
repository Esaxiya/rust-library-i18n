//! Чарга прыярытэтаў, рэалізаваная з двайковай кучай.
//!
//! Устаўка і выманне найбуйнейшага элемента маюць складанасць у часе *O*(log(*n*)).
//! Праверка самага вялікага элемента-*O*(1).Пераўтварэнне vector у двайковую кучу можа быць зроблена на месцы і мае складанасць *O*(*n*).
//! Бінарную кучу можна таксама пераўтварыць у адсартаваны vector на месцы, што дазваляе выкарыстоўваць яе для *O*(*n*\*log(* n*)) на месцы.
//!
//! # Examples
//!
//! Гэта больш буйны прыклад, які рэалізуе [Dijkstra's algorithm][dijkstra] для вырашэння [shortest path problem][sssp] на [directed graph][dir_graph].
//!
//! Ён паказвае, як выкарыстоўваць [`BinaryHeap`] з карыстацкімі тыпамі.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Чарга прыярытэтаў залежыць ад `Ord`.
//! // Выразна рэалізуйце Portrait, каб чаргу стала міні-кучай замест максімальнай.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Звярніце ўвагу, што мы перагортваем парадак выдаткаў.
//!         // У выпадку роўнай ступені мы параўноўваем пазіцыі, гэты крок неабходны, каб рэалізацыі `PartialEq` і `Ord` адпавядалі.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` неабходна таксама рэалізаваць.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Кожны вузел прадстаўлены ў выглядзе `usize` для больш кароткай рэалізацыі.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Алгарытм кароткага шляху Дейкстры.
//!
//! // Пачніце з `start` і выкарыстоўвайце `dist` для адсочвання бягучай самай кароткай адлегласці да кожнага вузла.Гэтая рэалізацыя не эфектыўная для памяці, паколькі можа пакідаць дублікаты вузлоў у чарзе.
//! //
//! // Ён таксама выкарыстоўвае `usize::MAX` у якасці вартавога значэння для больш простай рэалізацыі.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [вузел]=найменшая бягучая адлегласць ад `start` да `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Мы ў `start`, з нулявым коштам
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Спачатку вывучыце мяжу з вузламі з меншай коштам (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // У якасці альтэрнатывы мы маглі працягваць знаходзіць самыя кароткія шляхі
//!         if position == goal { return Some(cost); }
//!
//!         // Важна, бо, магчыма, мы ўжо знайшлі лепшы спосаб
//!         if cost > dist[position] { continue; }
//!
//!         // Для кожнага вузла, да якога мы можам дабрацца, даведаемся, ці зможам мы знайсці шлях з меншымі выдаткамі, які праходзіць праз гэты вузел
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Калі так, дадайце яго да мяжы і працягвайце
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Расслабленне, зараз мы знайшлі лепшы спосаб
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Мэта недасяжная
//!     None
//! }
//!
//! fn main() {
//!     // Гэта накіраваны графік, які мы будзем выкарыстоўваць.
//!     // Нумары вузлоў адпавядаюць розным станам, а вагі edge сімвалізуюць кошт пераходу ад аднаго вузла да іншага.
//!     //
//!     // Звярніце ўвагу, што краю аднабаковыя.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Графік прадстаўлены ў выглядзе спісу сумежнасці, дзе кожны індэкс, які адпавядае значэнню вузла, мае спіс выходных рэбраў.
//!     // Выбралі за эфектыўнасць.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Вузел 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Вузел 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Вузел 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Вузел 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Вузел 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Чарга прыярытэтаў, рэалізаваная з двайковай кучай.
///
/// Гэта будзе максімальная куча.
///
/// Гэта лагічная памылка, калі элемент мадыфікуецца такім чынам, што парадак элемента адносна любога іншага элемента, як гэта вызначана `Ord` Portrait, змяняецца, пакуль ён знаходзіцца ў кучы.
///
/// Звычайна гэта магчыма толькі праз `Cell`, `RefCell`, глабальны стан, I/O альбо небяспечны код.
/// Паводзіны, якія ўзнікаюць у выніку такой лагічнай памылкі, не ўказваюцца, але не прыводзяць да нявызначаных паводзін.
/// Гэта можа ўключаць panics, няправільныя вынікі, перапыненне, уцечку памяці і не спыненне.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Вывад тыпу дазваляе апусціць відавочную подпіс тыпу (якая ў гэтым прыкладзе будзе `BinaryHeap<i32>`).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Мы можам выкарыстоўваць Peek для прагляду наступнага элемента ў кучы.
/// // У гэтым выпадку прадметаў пакуль няма, таму мы атрымліваем Няма.
/// assert_eq!(heap.peek(), None);
///
/// // Дадамо некалькі балаў ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Цяпер зазірні паказвае найбольш важны элемент у кучы.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Мы можам праверыць даўжыню кучы.
/// assert_eq!(heap.len(), 3);
///
/// // Мы можам перабіраць элементы ў кучы, хаця яны вяртаюцца ў выпадковым парадку.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Калі мы замест гэтага паставім гэтыя балы, яны павінны вярнуцца па парадку.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Мы можам ачысціць кучу астатніх элементаў.
/// heap.clear();
///
/// // Куча цяпер павінна быць пустой.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Для стварэння `BinaryHeap` мінімальнай кучы можна выкарыстоўваць альбо `std::cmp::Reverse`, альбо ўласную рэалізацыю `Ord`.
/// Гэта прымушае `heap.pop()` вяртаць найменшае значэнне замест самага вялікага.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Перамяшчэнне значэнняў у `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Калі мы паставім гэтыя балы зараз, яны павінны вярнуцца ў зваротным парадку.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Складанасць часу
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Значэнне для `push`-гэта чаканы кошт;дакументацыя на метад дае больш падрабязны аналіз.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Структура абгарнула зменную спасылку на найвялікшы прадмет на `BinaryHeap`.
///
///
/// Гэты `struct` створаны метадам [`peek_mut`] на [`BinaryHeap`].
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // БЯСПЕКА: PeekMut ствараецца толькі для непустых куч.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // БЯСПЕЧНА: PeekMut ствараецца толькі для непустых куч
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // БЯСПЕЧНА: PeekMut ствараецца толькі для непустых куч
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Выдаляе заглянутае значэнне з кучы і вяртае яго.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Стварае пусты `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Стварае пусты `BinaryHeap` як максімальную кучу.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Стварае пусты `BinaryHeap` з пэўнай ёмістасцю.
    /// Гэта папярэдне выдзяляе дастаткова памяці для элементаў `capacity`, так што `BinaryHeap` не трэба будзе пераразмяркоўваць, пакуль ён не ўтрымлівае як мінімум столькі значэнняў.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Вяртае зменлівую спасылку на найбольшы элемент у двайковай кучы альбо `None`, калі ён пусты.
    ///
    /// Note: Калі значэнне `PeekMut` прасочваецца, куча можа знаходзіцца ў супярэчлівым стане.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Складанасць часу
    ///
    /// Калі элемент зменены, то ў горшым выпадку складанасць часу-*O*(log(*n*)), інакш гэта *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Выдаляе найбольшы элемент з двайковай кучы і вяртае яго, альбо `None`, калі ён пусты.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Складанасць часу
    ///
    /// Найгоршы кошт `pop` для кучы, якая змяшчае *n* элементы,-*O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // БЯСПЕКА: !self.is_empty() азначае, што self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Падштурхоўвае элемент да двайковай кучы.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Складанасць часу
    ///
    /// Чаканая кошт `push`, у сярэднім па ўсіх магчымых упарадкаваннях элементаў, якія штурхаюцца, і пры досыць вялікай колькасці штуршкоў складае *O*(1).
    ///
    /// Гэта найбольш значная метрыка выдаткаў пры націсканні элементаў, якія *няма* ужо ў якім-небудзь сартаваным узоры.
    ///
    /// Складанасць часу пагаршаецца, калі элементы перамяшчаюцца ў пераважна ўзрастаючым парадку.
    /// У горшым выпадку элементы перамяшчаюцца ў парадку ўзрастання, і амартызаваная кошт за штуршок складае *O*(log(*n*)) да кучы, якая змяшчае *n* элементаў.
    ///
    /// Найгоршы кошт *аднаго* званка на `push`-*O*(*n*).Горшы выпадак бывае, калі ёмістасць вычарпана і патрабуецца змяніць памер.
    /// Кошт змены амартызаваны ў папярэдніх лічбах.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // БЯСПЕКА: Паколькі мы прасунулі новы пункт, гэта азначае
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Спажывае `BinaryHeap` і вяртае vector у адсартаваным парадку (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // БЯСПЕКА: `end` пераходзіць з `self.len() - 1` на 1 (абодва ў камплекце),
            //  таму заўсёды даступны сапраўдны індэкс.
            //  Доступ да індэкса 0 (г.зн. `ptr`) бяспечны, таму што
            //  1 <=канец <self.len(), што азначае self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // БЯСПЕКА: `end` пераходзіць з `self.len() - 1` на 1 (абодва ў камплекце), таму:
            //  0 <1 <=канец <= self.len(), 1 <self.len() Што азначае 0 <канец і канец <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Рэалізацыі sift_up і sift_down выкарыстоўваюць небяспечныя блокі для таго, каб перамясціць элемент з vector (пакінуўшы адтуліну), зрушыць уздоўж астатніх і перамясціць выдалены элемент назад у vector у канчатковым месцы адтуліны.
    //
    // Тып `Hole` выкарыстоўваецца, каб прадставіць гэта, і пераканайцеся, што адтуліна запоўнена назад у канцы вобласці, нават на panic.
    // Выкарыстанне адтуліны памяншае пастаянны каэфіцыент у параўнанні з выкарыстаннем свопаў, які ўключае ў два разы больш хадоў.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Выміце значэнне ў `pos` і стварыце дзірку.
        // БЯСПЕКА: абанент гарантуе, што pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // БЯСПЕКА: hole.pos()> start>=0, што азначае hole.pos()> 0
            //  і таму hole.pos(), 1 не можа падцягнуцца.
            //  Гэта гарантуе, што бацька <hole.pos(), таму гэта сапраўдны індэкс, а таксама!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // БЯСПЕКА: Тое ж, што і вышэй
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Вазьміце элемент у `pos` і перамесціце яго ўніз, пакуль яго дзеці будуць больш.
    ///
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // БЯСПЕКА: абанент гарантуе, што pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Інварыянт завесы: дзіця==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // параўнайце з вялікім з двух дзяцей БЕЗОПАСНАСЦЬ: дзіця <канец, 1 <self.len() і дзіця + 1 <канец <= self.len(), таму яны сапраўдныя індэксы.
            //
            //  дзіця==2 *hole.pos() + 1!= hole.pos() і дзіця + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 або 2* hole.pos() + 2 могуць перапоўніцца, калі T-ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // калі мы ўжо ў парадку, спыніцеся.
            // БЯСПЕКА: дзіця цяпер альбо старое, альбо старое + 1
            //  Мы ўжо даказалі, што і тое, і іншае <self.len() і!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // БЯСПЕКА: тое ж самае, што і вышэй.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // БЯСПЕКА: &&кароткае замыканне, што азначае, што ў
        //  другая ўмова, гэта ўжо дакладна, што дзіця==канец, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // БЯСПЕКА: дзіця ўжо даказана як сапраўдны індэкс і
            //  дзіця==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // БЯСПЕКА: pos <len гарантуецца абанентам і
        //  відавочна len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Вазьміце элемент у `pos` і перамясціце яго ўніз па кучы, а потым прасейце да месца.
    ///
    ///
    /// Note: Гэта хутчэй, калі элемент, як вядома, вялікі/павінен знаходзіцца бліжэй да дна.
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // БЯСПЕКА: абанент гарантуе, што pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Інварыянт завесы: дзіця==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // БЯСПЕКА: дзіця <канец, 1 <self.len() і
            //  дзіця + 1 <канец <= self.len(), таму яны сапраўдныя індэксы.
            //  дзіця==2 *hole.pos() + 1!= hole.pos() і дзіця + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 або 2* hole.pos() + 2 могуць перапоўніцца, калі T-ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // БЯСПЕКА: Тое ж, што і вышэй
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // БЯСПЕКА: дзіця==канец, 1 <self.len(), таму гэта сапраўдны індэкс
            //  і дзіця==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // БЯСПЕКА: pos-гэта становішча ў лунцы, якое ўжо было даказана
        //  каб быць сапраўдным індэксам.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // БЯСПЕКА: n пачынаецца з self.len()/2 і апускаецца да 0.
            //  Адзіны выпадак, калі! (N <self.len())-гэта калі self.len() ==0, але гэта выключаецца ўмовай цыкла.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Перамяшчае ўсе элементы `other` у `self`, пакідаючы `other` пустым.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` прымае аперацыі O(len1 + len2) і каля 2 *(len1 + len2) параўнанняў у горшым выпадку, у той час як `extend` бярэ аперацыі O(len2* log(len1)) і каля 1 *len2* log_2(len1) параўнанняў у горшым выпадку, мяркуючы, што len1>= len2.
        // Для вялікіх куч кропка скрыжавання больш не варта гэтым развагам і была вызначана эмпірычна.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Вяртае ітэратар, які атрымлівае элементы ў парадку кучы.
    /// Атрыманыя элементы выдаляюцца з зыходнай кучы.
    /// Астатнія элементы будуць выдалены пры падзенні ў кучу.
    ///
    /// Note:
    /// * `.drain_sorted()` з'яўляецца *O*(*n*\*log(* n*)); значна павольней, чым `.drain()`.
    ///   Вы павінны выкарыстоўваць апошнія для большасці выпадкаў.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // выдаляе ўсе элементы ў парадку кучы
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Захоўвае толькі элементы, указаныя прэдыкатам.
    ///
    /// Іншымі словамі, выдаліце ўсе элементы `e` так, каб `f(&e)` вярнуў `false`.
    /// Элементы наведваюцца ў несартаваным (і неўстаноўленым) парадку.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // захоўваць толькі цотныя лічбы
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Вяртае ітэратар, які наведвае ўсе значэнні ў базавым vector у адвольным парадку.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Раздрукуйце 1, 2, 3, 4 у адвольным парадку
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Вяртае ітэратар, які атрымлівае элементы ў парадку кучы.
    /// Гэты метад спажывае зыходную кучу.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Вяртае найбольшы элемент у двайковай кучы альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Складанасць часу
    ///
    /// Кошт *O*(1) у горшым выпадку.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Вяртае колькасць элементаў, якія можа захоўваць двайковая куча без пераразмеркавання.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Захоўвае мінімальную ёмістасць для роўна `additional`, каб дадатковыя элементы былі ўстаўлены ў дадзены `BinaryHeap`.
    /// Нічога не робіць, калі магутнасці ўжо дастаткова.
    ///
    /// Звярніце ўвагу, што размеркавальнік можа даць калекцыі больш месца, чым ён просіць.
    /// Таму нельга спадзявацца, што ёмістасць будзе мінімальнай.
    /// Аддайце перавагу [`reserve`], калі чакаецца ўстаўка future.
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перапаўняе `usize`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Рэзервуе ёмістасць як мінімум для `additional`, каб у `BinaryHeap` было ўстаўлена больш элементаў.
    /// Калекцыя можа зарэзерваваць больш месца, каб пазбегнуць частых пераразмеркаванняў.
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перапаўняе `usize`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Адкідае як мага больш дадатковай ёмістасці.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Адкідае ёмістасць з ніжняй мяжой.
    ///
    /// Ёмістасць застанецца як мінімум роўнай як даўжыні, так і пастаўленай кошту.
    ///
    ///
    /// Калі бягучая ёмістасць менш ніжняй мяжы, гэта адмоўна.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Спажывае `BinaryHeap` і вяртае асноўны vector у адвольным парадку.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Будзе друкаваць у нейкім парадку
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Вяртае даўжыню двайковай кучы.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Правярае, ці пустая двайковая куча.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ачышчае двайковую кучу, вяртаючы ітэратар над выдаленымі элементамі.
    ///
    /// Элементы выдаляюцца ў адвольным парадку.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Выкідвае ўсе элементы з двайковай кучы.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Адтуліна ўяўляе дзірку ў зрэзе, г. зн., Індэкс без дапушчальнага значэння (таму што ён быў перамешчаны альбо прадубліраваны).
///
/// Падзенне `Hole` адновіць зрэз, запоўніўшы адтуліну значэннем, якое было першапачаткова выдалена.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Стварыце новы `Hole` з індэксам `pos`.
    ///
    /// Небяспечна, таму што пазіцыі павінны знаходзіцца ў разрэзе дадзеных.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // БЯСПЕЧНА: поз павінен знаходзіцца ўнутры зрэзу
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Вяртае спасылку на выдалены элемент.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Вяртае спасылку на элемент у `index`.
    ///
    /// Небяспечна, таму што індэкс павінен знаходзіцца ў разрэзе дадзеных і не раўняцца поз.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Перамясціць дзірку на новае месца
    ///
    /// Небяспечна, таму што індэкс павінен знаходзіцца ў разрэзе дадзеных і не раўняцца поз.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // зноў запоўніць адтуліну
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Ітэратар над элементамі `BinaryHeap`.
///
/// Гэты `struct` створаны [`BinaryHeap::iter()`].
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Выдаліць на карысць `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Уладальнік ітэратара над элементамі `BinaryHeap`.
///
/// Гэты `struct` створаны [`BinaryHeap::into_iter()`] (прадастаўляецца `IntoIterator` Portrait).
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Зліўны ітэратар над элементамі `BinaryHeap`.
///
/// Гэты `struct` створаны [`BinaryHeap::drain()`].
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Зліўны ітэратар над элементамі `BinaryHeap`.
///
/// Гэты `struct` створаны [`BinaryHeap::drain_sorted()`].
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Выдаляе элементы кучы ў парадку кучы.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Пераўтварае `Vec<T>` у `BinaryHeap<T>`.
    ///
    /// Гэта пераўтварэнне адбываецца на месцы і мае складанасць у часе *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Пераўтварае `BinaryHeap<T>` у `Vec<T>`.
    ///
    /// Гэта пераўтварэнне не патрабуе руху і размеркавання дадзеных і мае пастаянную складанасць у часе.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Стварае спажывальны ітэратар, гэта значыць той, які перамяшчае кожнае значэнне з кучы двайковых файлаў у адвольным парадку.
    /// Бінарную кучу нельга выкарыстоўваць пасля выкліку гэтага.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Раздрукуйце 1, 2, 3, 4 у адвольным парадку
    /// for x in heap.into_iter() {
    ///     // x мае тып i32, а не &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}