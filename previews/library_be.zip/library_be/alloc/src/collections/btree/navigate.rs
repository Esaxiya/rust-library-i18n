use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Часова вымае іншы, нязменны эквівалент таго ж дыяпазону.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Знаходзіць розныя краю лісця, якія размяжоўваюць зададзены дыяпазон у дрэве.
    /// Вяртае альбо пару розных ручак у адно і тое ж дрэва, альбо пару пустых варыянтаў.
    ///
    /// # Safety
    ///
    /// Калі `BorrowType` не з'яўляецца `Immut`, не выкарыстоўвайце паўторныя ручкі, каб двойчы наведаць адзін і той жа КВ.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Эквівалентна `(root1.first_leaf_edge(), root2.last_leaf_edge())`, але больш эфектыўна.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Знаходзіць пару краёў ліста, якая вызначае пэўны дыяпазон у дрэва.
    ///
    /// Вынік мае значэнне толькі ў тым выпадку, калі дрэва упарадкавана па ключах, як дрэва ў `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // БЯСПЕКА: наш тып пазыкі нязменны.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Знаходзіць пару краёў лісця, якія размяжоўваюць цэлае дрэва.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Разбівае унікальную спасылку на пару краёў лісця, якія размяжоўваюць зададзены дыяпазон.
    /// У выніку атрымліваюцца ўнікальныя спасылкі, якія дазваляюць мутаваць (some), якімі трэба карыстацца асцярожна.
    ///
    /// Вынік мае значэнне толькі ў тым выпадку, калі дрэва упарадкавана па ключах, як дрэва ў `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Не выкарыстоўвайце дублікаты ручак, каб двойчы наведаць адзін і той жа КВ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Разбівае унікальную спасылку на пару краёў лісця, якія размяжоўваюць увесь дыяпазон дрэва.
    /// Вынікі-гэта ўнікальныя спасылкі, якія дазваляюць мутаваць (толькі значэнні), таму трэба карыстацца асцярожна.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Мы дублюем тут каранёвы NodeRef-мы ніколі не наведаем адзін і той жа KV двойчы і ніколі не атрымаем перакрытыя спасылкі на значэнні.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Разбівае унікальную спасылку на пару краёў лісця, якія размяжоўваюць увесь дыяпазон дрэва.
    /// Вынікі-гэта ўнікальныя спасылкі, якія дазваляюць масава разбураць мутацыю, таму іх трэба выкарыстоўваць з максімальнай асцярожнасцю.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Мы дублюем тут каранёвы NodeRef-мы ніколі не атрымаем да яго доступ, які перакрывае спасылкі, атрыманыя з кораня.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Улічваючы ліст edge, ён вяртае [`Result::Ok`] з ручкай да суседняга КВ з правага боку, які знаходзіцца альбо ў тым самым лісце, альбо ў вузле продка.
    ///
    /// Калі ліст edge з'яўляецца апошнім у дрэве, вяртаецца [`Result::Err`] з каранёвым вузлом.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Улічваючы ліст edge, ён вяртае [`Result::Ok`] з ручкай да суседняга КВ з левага боку, які знаходзіцца альбо ў тым самым лісце, альбо ў вузле продка.
    ///
    /// Калі ліст edge з'яўляецца першым у дрэве, вяртаецца [`Result::Err`] з каранёвым вузлом.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Улічваючы ўнутраную ручку edge, вяртае [`Result::Ok`] з ручкай да суседняга КВ з правага боку, які знаходзіцца альбо ў тым самым унутраным вузле, альбо ў вузле-папярэдніку.
    ///
    /// Калі ўнутраны edge з'яўляецца апошнім у дрэве, вяртае [`Result::Err`] з каранёвым вузлом.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Улічваючы ліст edge у паміраючае дрэва, вяртае наступны ліст edge з правага боку і пару ключ-значэнне паміж імі, якая знаходзіцца альбо ў тым самым вузле ліста, альбо ў вузле продкаў, альбо не існуе.
    ///
    ///
    /// Гэты метад таксама вызваляе любы node(s), які ён дасягнуў у канцы.
    /// Гэта азначае, што калі больш не існуе пары ключ-значэнне, увесь астатак дрэва будзе вызвалены, і вярнуць нічога не застанецца.
    ///
    /// # Safety
    /// Дадзены edge не павінен быць раней вернуты аналагам `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Улічваючы ліст edge у дрэва, якое памірае, вяртае наступны ліст edge з левага боку і пару ключ-значэнне паміж імі, якая знаходзіцца альбо ў тым самым вузле ліста, альбо ў вузле продкаў, альбо не існуе.
    ///
    ///
    /// Гэты метад таксама вызваляе любы node(s), які ён дасягнуў у канцы.
    /// Гэта азначае, што калі больш не існуе пары ключ-значэнне, увесь астатак дрэва будзе вызвалены, і вярнуць нічога не застанецца.
    ///
    /// # Safety
    /// Дадзены edge не павінен быць раней вернуты аналагам `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Выдзяляе груду вузлоў ад ліста да кораня.
    /// Гэта адзіны спосаб вызваліць астатнюю частку дрэва пасля таго, як `deallocating_next` і `deallocating_next_back` абгрызалі абодва бакі дрэва і патрапілі ў адзін і той жа edge.
    /// Паколькі ён прызначаны для выкліку толькі тады, калі ўсе ключы і значэнні вернуты, ачыстка ніводнага з ключоў і значэнняў не праводзіцца.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Перамяшчае ліст edge ліста да наступнага аркуша edge і вяртае спасылкі на ключ і значэнне паміж імі.
    ///
    ///
    /// # Safety
    /// У напрамку, які прайшоў, павінен быць яшчэ адзін КВ.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Перамяшчае ліст edge ліста да папярэдняга аркуша edge і вяртае спасылкі на ключ і значэнне паміж імі.
    ///
    ///
    /// # Safety
    /// У напрамку, які прайшоў, павінен быць яшчэ адзін КВ.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Перамяшчае ліст edge ліста да наступнага аркуша edge і вяртае спасылкі на ключ і значэнне паміж імі.
    ///
    ///
    /// # Safety
    /// У напрамку, які прайшоў, павінен быць яшчэ адзін КВ.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Зрабіць гэта апошнім хутчэй, згодна з эталонамі.
        kv.into_kv_valmut()
    }

    /// Перамяшчае ліст edge ліста да папярэдняга аркуша і вяртае спасылкі на ключ і значэнне паміж імі.
    ///
    ///
    /// # Safety
    /// У напрамку, які прайшоў, павінен быць яшчэ адзін КВ.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Зрабіць гэта апошнім хутчэй, згодна з эталонамі.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Перамяшчае ліст edge ліста да наступнага аркуша edge і вяртае ключ і значэнне паміж імі, вызваляючы любы вузел, які застаўся ззаду, пакідаючы адпаведны edge у сваім бацькоўскім вузле, які вісіць.
    ///
    /// # Safety
    /// - У напрамку, які прайшоў, павінен быць яшчэ адзін КВ.
    /// - Гэта KV раней не было вернута аналагам `next_back_unchecked` ні на адной копіі ручак, якія выкарыстоўваюцца для праходжання дрэва.
    ///
    /// Адзіны бяспечны спосаб пайсці з абноўленай ручкай-параўнаць яе, выпусціць, зноў выклікаць гэты метад з улікам умоў бяспекі альбо выклікаць аналог `next_back_unchecked` з улікам умоў бяспекі.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Перамяшчае ліст edge ліста да папярэдняга аркуша edge і вяртае ключ і значэнне паміж імі, вызваляючы любы вузел, які застаўся ззаду, пакідаючы адпаведны edge у сваім бацькоўскім вузле, які вісіць.
    ///
    /// # Safety
    /// - У напрамку, які прайшоў, павінен быць яшчэ адзін КВ.
    /// - Гэты ліст edge раней не быў вернуты аналагам `next_unchecked` ні на адной копіі ручак, якія выкарыстоўваюцца для перамяшчэння дрэва.
    ///
    /// Адзіны бяспечны спосаб пайсці з абноўленай ручкай-параўнаць яе, выпусціць, зноў выклікаць гэты метад з улікам умоў бяспекі альбо выклікаць аналог `next_unchecked` з улікам умоў бяспекі.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Вяртае крайні левы ліст edge у або пад вузлом, іншымі словамі, edge, які вам спачатку патрэбны пры навігацыі наперад (альбо апошні пры навігацыі назад).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Вяртае крайні правы ліст edge у або пад вузлом, іншымі словамі, edge, які вам патрэбен апошні пры навігацыі наперад (альбо першым пры звароце назад).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Наведвае лісцевыя вузлы і ўнутраныя KV у парадку ўзрастання ключоў, а таксама наведвае ўнутраныя вузлы ў цэлым у глыбіні першага парадку, гэта азначае, што ўнутраныя вузлы папярэднічаюць іх асобным KV і іх даччыным вузлам.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Вылічвае колькасць элементаў у (пад) дрэве.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Вяртае ліст edge, бліжэйшы да КВ, для прамой навігацыі.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Вяртае ліст edge, бліжэйшы да КВ, для зваротнай навігацыі.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}