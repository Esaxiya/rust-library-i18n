use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Схема фіктыўных экзэмпляраў краш-тэстаў, якія адсочваюць пэўныя падзеі.
/// Некаторыя выпадкі могуць быць настроены на panic у нейкі момант.
/// Падзеі-`clone`, `drop` альбо нейкі ананімны `query`.
///
/// Фіктыўныя манекены ідэнтыфікуюцца і ўпарадкоўваюцца ідэнтыфікатарам, таму іх можна выкарыстоўваць як ключы ў BTreeMap.
/// Рэалізацыя, наўмысна выкарыстоўваная, не абапіраецца ні на што, што вызначана ў crate, акрамя `Debug` Portrait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Стварае дызайнерскі манекен краш-тэсту.`id` вызначае парадак і роўнасць асобнікаў.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Стварае асобнік манекена краш-тэсту, які запісвае, якія падзеі ён перажывае, і неабавязкова panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Вяртае, колькі разоў былі клонаваны асобнікі манекена.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Вяртае, колькі разоў былі выдалены асобнікі манекена.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Вяртае, колькі разоў асобнікі манекена выклікалі ўдзельніка `query`.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Нейкі ананімны запыт, вынік якога ўжо прыведзены.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}