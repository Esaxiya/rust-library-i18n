use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Дадае ўсе пары ключ-значэнне з аб'яднання двух узыходзячых ітэратараў, павялічваючы зменную `length` па шляху.Апошняе дазваляе абаненту лягчэй пазбегнуць уцечкі, калі апрацоўшчык падзення панікуе.
    ///
    /// Калі абодва ітэратара вырабляюць адзін і той жа ключ, гэты метад скідае пару з левага ітэратара і дадае пару з правага ітэратара.
    ///
    /// Калі вы хочаце, каб дрэва апынулася ў строга ўзрастаючым парадку, як для `BTreeMap`, абодва ітэратары павінны вырабляць ключы ў строга ўзрастаючым парадку, кожны большы за ўсе ключы ў дрэве, уключаючы любыя ключы, якія ўжо ёсць у дрэве пры ўваходзе.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Мы рыхтуемся аб'яднаць `left` і `right` у адсартаваную паслядоўнасць у лінейны час.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Тым часам мы будуем дрэва з адсартаванай паслядоўнасці за лінейны час.
        self.bulk_push(iter, length)
    }

    /// Падштурхоўвае ўсе пары ключ-значэнне да канца дрэва, павялічваючы зменную `length` па шляху.
    /// Апошняе дазваляе абаненту лягчэй пазбегнуць уцечкі пры паніцы ітэратара.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Прайдзіце па ўсіх парах ключ-значэнне, перамяшчаючы іх у вузлы патрэбнага ўзроўню.
        for (key, value) in iter {
            // Паспрабуйце ўціснуць пару ключ-значэнне ў бягучы вузел ліста.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Не засталося месца, падніміцеся і націсніце туды.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Знайшоў вузел з прабелам, націсніце сюды.
                                open_node = parent;
                                break;
                            } else {
                                // Ідзі зноў уверх.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Мы знаходзімся ўверсе, ствараем новы каранёвы вузел і націскаем туды.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Націсніце пару ключ-значэнне і новае правае паддрэва.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Зноў спусціцеся да самага правага ліста.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Павялічвайце даўжыню кожнай ітэрацыі, каб пераканацца, што карта скідае дададзеныя элементы, нават калі пасоўванне ітэратара панічна.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ітэратар для аб'яднання дзвюх адсартаваных паслядоўнасцей у адну
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Калі два ключы роўныя, вяртае пару ключ-значэнне з правай крыніцы.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}