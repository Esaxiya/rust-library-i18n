//! API размеркавання памяці

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Гэта магічныя сімвалы, якія можна назваць глабальным размеркавальнікам.rustc генеруе іх для выкліку `__rg_alloc` і г.д.
    // калі ёсць атрыбут `#[global_allocator]` (код, які пашырае гэты атрыбут, генеруе гэтыя функцыі), альбо выклікаць рэалізацыі па змаўчанні ў libstd (`__rdl_alloc` і г.д.
    //
    // у `library/std/src/alloc.rs`) у адваротным выпадку.
    // rustc fork LLVM таксама спецыяльна выкарыстоўвае назвы гэтых функцый, каб мець магчымасць аптымізаваць іх, як `malloc`, `realloc` і `free`, адпаведна.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Размяшчальнік глабальнай памяці.
///
/// Гэты тып рэалізуе [`Allocator`] Portrait шляхам перанакіравання выклікаў на размеркавальнік, зарэгістраваны з атрыбутам `#[global_allocator]`, калі ён ёсць, альбо па змаўчанні `std` crate.
///
///
/// Note: хаця гэты тып нестабільны, функцыянальнасць, якую ён прадастаўляе, можа быць даступная праз [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Вылучыце памяць з глабальным размеркавальнікам.
///
/// Гэтая функцыя перанакіроўвае выклікі да метаду [`GlobalAlloc::alloc`] размеркавальніка, зарэгістраванага з атрыбутам `#[global_allocator]`, калі ён ёсць, альбо па змаўчанні `std` crate.
///
///
/// Чакаецца, што гэтая функцыя будзе састарэла на карысць метаду `alloc` тыпу [`Global`], калі яна і [`Allocator`] Portrait стануць стабільнымі.
///
/// # Safety
///
/// Глядзіце [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Вылучыце памяць з глабальным размеркавальнікам.
///
/// Гэтая функцыя перанакіроўвае выклікі да метаду [`GlobalAlloc::dealloc`] размеркавальніка, зарэгістраванага з атрыбутам `#[global_allocator]`, калі ён ёсць, альбо па змаўчанні `std` crate.
///
///
/// Чакаецца, што гэтая функцыя будзе састарэла на карысць метаду `dealloc` тыпу [`Global`], калі яна і [`Allocator`] Portrait стануць стабільнымі.
///
/// # Safety
///
/// Глядзіце [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Пераразмеркаваць памяць з глабальным размеркавальнікам.
///
/// Гэтая функцыя перанакіроўвае выклікі да метаду [`GlobalAlloc::realloc`] размеркавальніка, зарэгістраванага з атрыбутам `#[global_allocator]`, калі ён ёсць, альбо па змаўчанні `std` crate.
///
///
/// Чакаецца, што гэтая функцыя будзе састарэла на карысць метаду `realloc` тыпу [`Global`], калі яна і [`Allocator`] Portrait стануць стабільнымі.
///
/// # Safety
///
/// Глядзіце [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Вылучыце нуль ініцыялізаванай памяці з глабальным размеркавальнікам.
///
/// Гэтая функцыя перанакіроўвае выклікі да метаду [`GlobalAlloc::alloc_zeroed`] размеркавальніка, зарэгістраванага з атрыбутам `#[global_allocator]`, калі ён ёсць, альбо па змаўчанні `std` crate.
///
///
/// Чакаецца, што гэтая функцыя будзе састарэла на карысць метаду `alloc_zeroed` тыпу [`Global`], калі яна і [`Allocator`] Portrait стануць стабільнымі.
///
/// # Safety
///
/// Глядзіце [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // БЯСПЕКА: `layout` мае ненулявы памер,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // БЯСПЕКА: Тое ж, што і `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // БЯСПЕКА: `new_size` ненулявы, бо `old_size` большы або роўны `new_size`
            // як патрабуюць умовы бяспекі.Астатнія павінны выконваць іншыя ўмовы
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` верагодна, правярае `new_size >= old_layout.size()` ці нешта падобнае.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // БЯСПЕКА: паколькі `new_layout.size()` павінна быць большай або роўнай `old_size`,
            // як старое, так і новае размеркаванне памяці сапраўдныя для чытання і запісу для байтаў `old_size`.
            // Акрамя таго, паколькі старое размеркаванне яшчэ не было вызвалена, яно не можа перакрываць `new_ptr`.
            // Такім чынам, званок на `copy_nonoverlapping` бяспечны.
            // Дамова бяспекі для `dealloc` павінна выконвацца абанентам.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // БЯСПЕКА: `layout` мае ненулявы памер,
            // іншыя ўмовы павінны выконвацца абанентам
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЯСПЕКА: абанент павінен выконваць усе ўмовы
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЯСПЕКА: абанент павінен выконваць усе ўмовы
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // БЯСПЕКА: абанент павінен выконваць умовы
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // БЯСПЕКА: `new_size` не нулявы.Астатнія павінны выконваць іншыя ўмовы
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` верагодна, правярае `new_size <= old_layout.size()` ці нешта падобнае.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // БЯСПЕКА: паколькі `new_size` павінен быць меншым або роўным `old_layout.size()`,
            // як старое, так і новае размеркаванне памяці сапраўдныя для чытання і запісу для байтаў `new_size`.
            // Акрамя таго, паколькі старое размеркаванне яшчэ не было вызвалена, яно не можа перакрываць `new_ptr`.
            // Такім чынам, званок на `copy_nonoverlapping` бяспечны.
            // Дамова бяспекі для `dealloc` павінна выконвацца абанентам.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Размяшчальнік унікальных указальнікаў.
// Гэта функцыя не павінна раскручвацца.Калі гэта адбудзецца, кодэген MIR не атрымаецца.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Гэты подпіс павінен быць такім жа, як `Box`, інакш адбудзецца ДВС.
// Калі да `Box` дадаецца дадатковы параметр (напрыклад, `A: Allocator`), яго трэба дадаць і тут.
// Напрыклад, калі `Box` зменены на `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, гэтая функцыя таксама павінна быць зменена на `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Апрацоўшчык памылак размеркавання

extern "Rust" {
    // Гэта чароўны сімвал для выкліку глабальнага апрацоўшчыка памылак alloc.
    // rustc генеруе яго для выкліку `__rg_oom`, калі ёсць `#[alloc_error_handler]`, альбо для звароту да рэалізацый па змаўчанні ніжэй (`__rdl_oom`).
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Скасаваць памылку пры размеркаванні памяці.
///
/// Выклічнікі API выдзялення памяці, якія жадаюць перапыніць вылічэнні ў адказ на памылку размеркавання, рэкамендуецца выклікаць гэтую функцыю, а не непасрэдна выклікаць `panic!` ці аналагічную.
///
///
/// Паводзіны гэтай функцыі па змаўчанні-надрукаваць паведамленне са стандартнай памылкай і перапыніць працэс.
/// Яго можна замяніць на [`set_alloc_error_hook`] і [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Для алокавага тэсту `std::alloc::handle_alloc_error` можна выкарыстоўваць непасрэдна.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // выклікаецца праз згенераваны `__rust_alloc_error_handler`

    // калі няма `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // калі ёсць `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Спецыялізуйцеся на клонах у загадзя выдзеленай, неініцыялізаванай памяці.
/// Выкарыстоўваецца ў `Box::clone` і `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Вылучыўшы *first*, можа дазволіць аптымізатару стварыць кланаванае значэнне на месцы, прапусціўшы лакальнае і перамясціць.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Мы заўсёды можам скапіраваць на месцы, не прыцягваючы мясцовых каштоўнасцей.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}