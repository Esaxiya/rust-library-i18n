//! Аднанітовыя паказальнікі падліку спасылак.'Rc' расшыфроўваецца як "Даведка"
//! Counted'.
//!
//! Тып [`Rc<T>`][`Rc`] забяспечвае агульнае валоданне значэннем тыпу `T`, размешчаным у кучы.
//! Выклік [`clone`][clone] на [`Rc`] вырабляе новы паказальнік на тое ж размеркаванне ў кучы.
//! Калі апошні ўказальнік [`Rc`] на дадзенае размеркаванне будзе знішчаны, значэнне, якое захоўваецца ў гэтым размеркаванні (часта званае "inner value"), таксама скідаецца.
//!
//! Агульныя спасылкі ў Rust па змаўчанні забараняюць мутацыю, і [`Rc`] не з'яўляецца выключэннем: вы звычайна не можаце атрымаць зменлівую спасылку на нешта ўнутры [`Rc`].
//! Калі вам патрэбна зменлівасць, устаўце [`Cell`] або [`RefCell`] унутр [`Rc`];см. [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] выкарыстоўвае неатамны падлік спасылак.
//! Гэта азначае, што накладныя выдаткі вельмі нізкія, але [`Rc`] нельга перасылаць паміж патокамі, і, такім чынам, [`Rc`] не рэалізуе [`Send`][send].
//! У выніку кампілятар Rust праверыць *падчас кампіляцыі*, што вы не пасылаеце [`Rc`] s паміж патокамі.
//! Калі вам патрэбен шматструменны, атамны падлік спасылак, выкарыстоўвайце [`sync::Arc`][arc].
//!
//! Метад [`downgrade`][downgrade] можа быць выкарыстаны для стварэння неналежнага паказальніка [`Weak`].
//! Паказальнікам [`Weak`] можна [`абнавіць`][абнавіць] d да [`Rc`], але гэта верне [`None`], калі значэнне, якое захоўваецца ў размеркаванні, ужо было скінута.
//! Іншымі словамі, указальнікі `Weak` не падтрымліваюць значэнне ўнутры размеркавання;аднак яны *робяць* падтрымліваюць размеркаванне (запас для ўнутранага значэння).
//!
//! Цыкл паміж паказальнікамі [`Rc`] ніколі не будзе вызвалены.
//! Па гэтай прычыне [`Weak`] выкарыстоўваецца для разрыву цыклаў.
//! Напрыклад, дрэва можа мець моцныя паказальнікі [`Rc`] ад бацькоўскіх вузлоў да дзяцей, а [`Weak`]-ад дзяцей назад да бацькоў.
//!
//! `Rc<T>` аўтаматычна перанакіроўвае на `T` (праз [`Deref`] Portrait), так што вы можаце выклікаць метады `T` на значэнні тыпу [`Rc<T>`][`Rc`].
//! Каб пазбегнуць сутыкнення імёнаў з метадамі `T`, метады самога [`Rc<T>`][`Rc`] звязаныя з функцыямі, якія выклікаюцца з выкарыстаннем [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Рэалізацыі traits, такія як `Clone`, таксама можна выклікаць з выкарыстаннем поўнасцю кваліфікаванага сінтаксісу.
//! Некаторыя людзі аддаюць перавагу выкарыстоўваць поўнасцю кваліфікаваны сінтаксіс, у той час як іншыя аддаюць перавагу сінтаксісу выкліку метадаў.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Сінтаксіс выкліку метаду
//! let rc2 = rc.clone();
//! // Поўнасцю кваліфікаваны сінтаксіс
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] не ажыццяўляе аўтаматычны зварот да `T`, таму што ўнутранае значэнне, магчыма, ужо скінута.
//!
//! # Спасылкі на кланаванне
//!
//! Стварэнне новай спасылкі на тое ж размеркаванне, што і існуючы паказальнік падліку спасылак, ажыццяўляецца з выкарыстаннем `Clone` Portrait, рэалізаванай для [`Rc<T>`][`Rc`] і [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ніжэй прыведзены два сінтаксісы эквівалентныя.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // а і b паказваюць на адно і тое ж месца ў памяці, што і foo.
//! ```
//!
//! Сінтаксіс `Rc::clone(&from)` з'яўляецца найбольш ідыяматычным, паколькі ён больш дакладна паказвае значэнне кода.
//! У прыведзеным вышэй прыкладзе гэты сінтаксіс дазваляе прасцей убачыць, што гэты код стварае новую спасылку, а не капіюе ўвесь змест foo.
//!
//! # Examples
//!
//! Разгледзім сцэнар, калі набор "гаджэтаў" належыць дадзенаму `Owner`.
//! Мы хочам, каб наш гаджэт паказваў на іх `Owner`.Мы не можам зрабіць гэта з унікальным правам уласнасці, таму што больш за адзін гаджэт можа належаць аднаму `Owner`.
//! [`Rc`] дазваляе нам дзяліцца `Owner` паміж некалькімі "гаджэтамі", і каб `Owner` заставаўся выдзеленым да таго часу, пакуль на яго паказваюць любыя `Gadget`.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... іншыя палі
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... іншыя палі
//! }
//!
//! fn main() {
//!     // Стварыце `Owner` з улікам спасылак.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Стварыце `гаджэт`, які належыць `gadget_owner`.
//!     // Кланаванне `Rc<Owner>` дае нам новы паказальнік на тое ж размеркаванне `Owner`, павялічваючы колькасць спасылак у працэсе.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Утылізуйце нашу лакальную зменную `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Нягледзячы на адмову ад `gadget_owner`, мы па-ранейшаму можам раздрукаваць назву `Owner` з "Гаджэта".
//!     // Гэта таму, што мы выпусцілі толькі адзін `Rc<Owner>`, а не `Owner`, на які ён паказвае.
//!     // Пакуль ёсць іншыя `Rc<Owner>`, якія паказваюць на тое ж размеркаванне `Owner`, ён будзе заставацца жывым.
//!     // Палявая праекцыя `gadget1.owner.name` працуе, таму што `Rc<Owner>` аўтаматычна перанакіроўвае на `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // У канцы функцыі `gadget1` і `gadget2` знішчаюцца, а разам з імі і апошнія падлічаныя спасылкі на наш `Owner`.
//!     // Чалавек-гаджэт цяпер таксама знішчаецца.
//!     //
//! }
//! ```
//!
//! Калі нашы патрабаванні зменяцца, і мы таксама павінны мець магчымасць пераходу ад `Owner` да `Gadget`, мы сутыкнемся з праблемамі.
//! Паказальнік [`Rc`] з `Owner` на `Gadget` уводзіць цыкл.
//! Гэта азначае, што іх колькасць спасылак ніколі не можа дасягнуць 0, і размеркаванне ніколі не будзе разбурана:
//! уцечка памяці.Каб абысці гэта, мы можам выкарыстоўваць паказальнікі [`Weak`].
//!
//! Rust на самай справе ў першую чаргу ўскладняе стварэнне гэтага цыкла.Каб у выніку атрымалася два значэнні, накіраваныя адно на адно, адно з іх павінна быць зменлівым.
//! Гэта складана, таму што [`Rc`] забяспечвае бяспеку памяці, выдаючы толькі агульныя спасылкі на значэнне, якое яно абгортвае, і яны не дазваляюць прамой мутацыі.
//! Нам трэба абгарнуць частку значэння, якую мы хочам мутаваць, у [`RefCell`], які забяспечвае *унутраную зменлівасць*: метад для дасягнення зменлівасці праз агульную спасылку.
//! [`RefCell`] выконвае правілы пазычання Rust падчас выканання.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... іншыя палі
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... іншыя палі
//! }
//!
//! fn main() {
//!     // Стварыце `Owner` з улікам спасылак.
//!     // Звярніце ўвагу, што мы змясцілі "Уладальнік" vector "Гаджэта" у `RefCell`, каб мы маглі яго мутаваць праз агульную спасылку.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Стварыце `гаджэт`, які належыць `gadget_owner`, як і раней.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Дадайце прылады да свайго `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` дынамічны запазычанне тут заканчваецца.
//!     }
//!
//!     // Праглядайце нашы прылады, раздрукоўваючы іх звесткі.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` з'яўляецца `Weak<Gadget>`.
//!         // Паколькі паказальнікі `Weak` не могуць гарантаваць, што размеркаванне ўсё яшчэ існуе, нам трэба выклікаць `upgrade`, які вяртае `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // У гэтым выпадку мы ведаем, што размеркаванне ўсё яшчэ існуе, таму мы проста `unwrap`-`Option`.
//!         // У больш складанай праграме вам можа спатрэбіцца вытанчаная апрацоўка памылак для выніку `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Па заканчэнні функцыі `gadget_owner`, `gadget1` і `gadget2` руйнуюцца.
//!     // Зараз няма моцных указальнікаў (`Rc`) на прылады, таму яны знішчаюцца.
//!     // Гэта абнуляе колькасць спасылак на Gadget Man, таму яго таксама знішчаюць.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Гэта абарона ад repr(C) да future супраць магчымага пераўпарадкавання палёў, якое перашкаджае бяспечнаму [into|from]_raw() унутраных тыпаў, якія пераўтвараюцца.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Аднапоточны паказальнік падліку спасылак.'Rc' расшыфроўваецца як "Даведка"
/// Counted'.
///
/// Для больш падрабязнай інфармацыі глядзіце [module-level documentation](./index.html).
///
/// Уласцівыя метады `Rc`-гэта ўсе звязаныя з імі функцыі, а гэта значыць, што іх трэба выклікаць, напрыклад, [`Rc::get_mut(&mut value)`][get_mut] замест `value.get_mut()`.
/// Гэта дазваляе пазбегнуць канфліктаў з метадамі ўнутранага тыпу `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Гэта небяспечна, таму што пакуль гэты Rc жывы, мы гарантуем, што ўнутраны паказальнік сапраўдны.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Канструюе новы `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Існуе няяўны слабы паказальнік, які належыць усім моцным паказальнікам, што гарантуе, што слабы дэструктар ніколі не вызваляе размеркаванне, пакуль працуе моцны дэструктар, нават калі слабы паказальнік захоўваецца ў моцным.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Канструюе новы `Rc<T>`, выкарыстоўваючы слабую спасылку на сябе.
    /// Спроба абнавіць слабую спасылку да вяртання гэтай функцыі прывядзе да значэння `None`.
    ///
    /// Аднак слабую спасылку можна свабодна кланаваць і захоўваць для выкарыстання ў далейшым.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... яшчэ палі
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Пабудуйце ўнутранае ў стане "uninitialized" з адной слабой спасылкай.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важна, каб мы не адмаўляліся ад права ўласнасці на слабы паказальнік, інакш памяць можа вызваліцца да вяртання `data_fn`.
        // Калі б мы сапраўды хацелі перадаць права ўласнасці, мы маглі б стварыць дадатковы слабы паказальнік для сябе, але гэта прывяло б да дадатковых абнаўленняў слабага адліку спасылак, якія інакш не спатрэбіліся б.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Моцныя спасылкі павінны разам мець агульную слабую спасылку, таму не запускайце дэструктар для нашай старой слабой спасылкі.
        //
        mem::forget(weak);
        strong
    }

    /// Канструюе новы `Rc` з неініцыялізаваным змесцівам.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Стварае новы `Rc` з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Канструюе новы `Rc<T>`, вяртаючы памылку, калі размеркаванне не ўдаецца
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Існуе няяўны слабы паказальнік, які належыць усім моцным паказальнікам, што гарантуе, што слабы дэструктар ніколі не вызваляе размеркаванне, пакуль працуе моцны дэструктар, нават калі слабы паказальнік захоўваецца ў моцным.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Стварае новы `Rc` з неініцыялізаваным змесцівам, вяртаючы памылку, калі размеркаванне не ўдаецца
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Канструюе новы `Rc` з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`, вяртаючы памылку, калі размеркаванне не ўдаецца
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Канструюе новы `Pin<Rc<T>>`.
    /// Калі `T` не рэалізуе `Unpin`, `value` будзе замацаваны ў памяці і не можа быць перамешчаны.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Вяртае ўнутранае значэнне, калі `Rc` мае роўна адну моцную спасылку.
    ///
    /// У адваротным выпадку [`Err`] вяртаецца з тым самым `Rc`, які быў перададзены.
    ///
    ///
    /// Гэта атрымаецца, нават калі ёсць выбітныя слабыя спасылкі.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // скапіруйце змешчаны аб'ект

                // Пакажыце Слабым, што іх нельга павысіць, памяншаючы моцны лік, а затым выдаліце няяўны паказальнік "strong weak", а таксама апрацоўвайце логіку падзення, проста вырабіўшы падроблены Слабы.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Сканструюе новы зрэз падлікаў з неініцыялізаваным зместам.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Стварае новы зрэзаны падлік з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Пераўтварае ў `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Як і ў выпадку з [`MaybeUninit::assume_init`], абанент павінен гарантаваць, што ўнутранае значэнне сапраўды знаходзіцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае неадкладныя паводзіны.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Пераўтварае ў `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Як і ў выпадку з [`MaybeUninit::assume_init`], абанент павінен гарантаваць, што ўнутранае значэнне сапраўды знаходзіцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае неадкладныя паводзіны.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Спажывае `Rc`, вяртаючы загорнуты паказальнік.
    ///
    /// Каб пазбегнуць уцечкі памяці, паказальнік неабходна пераўтварыць назад у `Rc` з дапамогай [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Забяспечвае неапрацаваны паказальнік на дадзеныя.
    ///
    /// На падлік ніяк не ўплывае, і `Rc` не спажываецца.
    /// Паказальнік дзейнічае да таго часу, пакуль у `Rc` ёсць моцны падлік.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // БЯСПЕКА: Гэта не можа прайсці праз Deref::deref альбо Rc::inner, таму што
        // гэта неабходна для захавання паходжання raw/mut такім, каб, напрыклад
        // `get_mut` можа пісаць праз паказальнік пасля аднаўлення Rc праз `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Стварае `Rc<T>` з сырога паказальніка.
    ///
    /// Неапрацаваны паказальнік павінен быць раней вернуты выклікам [`Rc<U>::into_raw`][into_raw], дзе `U` павінен мець той жа памер і выраўноўванне, што і `T`.
    /// Гэта банальна дакладна, калі `U`-гэта `T`.
    /// Звярніце ўвагу, што калі `U` не з'яўляецца `T`, але мае аднолькавы памер і выраўноўванне, гэта ў асноўным падобна на перапрацоўку спасылак розных тыпаў.
    /// Для атрымання дадатковай інфармацыі пра тое, якія абмежаванні прымяняюцца ў гэтым выпадку, см.
    ///
    /// Карыстальнік `from_raw` павінен пераканацца, што пэўнае значэнне `T` ўпала толькі адзін раз.
    ///
    /// Гэтая функцыя небяспечная, бо няправільнае выкарыстанне можа прывесці да небяспекі памяці, нават калі зваротны `Rc<T>` ніколі не будзе даступны.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Пераўтварыце назад у `Rc`, каб прадухіліць уцечку.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Далейшыя званкі на `Rc::from_raw(x_ptr)` будуць небяспечнымі для памяці.
    /// }
    ///
    /// // Памяць вызвалілася, калі `x` выйшаў з-пад сферы дзеяння вышэй, таму `x_ptr` зараз вісіць!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Зменіце зрушэнне, каб знайсці зыходны RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Стварае новы ўказальнік [`Weak`] на гэта размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Пераканайцеся, што мы не ствараем вісячага Слабага
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Атрымлівае колькасць указальнікаў [`Weak`] на гэта размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Атрымлівае колькасць моцных указальнікаў (`Rc`) на гэта размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Вяртае `true`, калі няма іншых указальнікаў `Rc` або [`Weak`] на гэта размеркаванне.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Вяртае зменлівую спасылку на дадзены `Rc`, калі няма іншых указальнікаў `Rc` або [`Weak`] на тое ж размеркаванне.
    ///
    ///
    /// Вяртае [`None`] у адваротным выпадку, таму што бяспечна мутаваць агульнае значэнне.
    ///
    /// Глядзіце таксама [`make_mut`][make_mut], які будзе [`clone`][clone] унутраным значэннем, калі ёсць іншыя ўказальнікі.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Вяртае зменную спасылку на дадзены `Rc` без праверкі.
    ///
    /// Глядзіце таксама [`get_mut`], які з'яўляецца бяспечным і праводзіць адпаведныя праверкі.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Любыя іншыя ўказальнікі `Rc` або [`Weak`] на тое ж самае размеркаванне не павінны разглядацца на працягу часу вяртання пазыкі.
    ///
    /// Гэта банальна, калі такіх паказальнікаў не існуе, напрыклад, адразу пасля `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Мы асцярожна, каб *не* ствараць спасылку, якая ахоплівае палі "count", бо гэта супярэчыць доступу да падліку спасылак (напрыклад,
        // па `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Вяртае `true`, калі два `Rc` паказваюць на адно і тое ж размеркаванне (у вене, аналагічнай [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Змяняе спасылку на дадзены `Rc`.
    ///
    /// Калі ёсць іншыя ўказальнікі `Rc` на тое ж размеркаванне, то `make_mut` будзе [`clone`] унутраным значэннем для новага размеркавання, каб забяспечыць унікальнае валоданне.
    /// Гэта таксама называюць клонам на запіс.
    ///
    /// Калі няма іншых указальнікаў `Rc` да гэтага размеркавання, то паказальнікі [`Weak`] да гэтага размеркавання будуць раз'яднаны.
    ///
    /// Глядзіце таксама [`get_mut`], які хутчэй не атрымаецца, чым кланіраваць.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Не будзе нічога кланаваць
    /// let mut other_data = Rc::clone(&data);    // Не будзе кланаваць унутраныя дадзеныя
    /// *Rc::make_mut(&mut data) += 1;        // Унутраныя дадзеныя клонаў
    /// *Rc::make_mut(&mut data) += 1;        // Не будзе нічога кланаваць
    /// *Rc::make_mut(&mut other_data) *= 2;  // Не будзе нічога кланаваць
    ///
    /// // Цяпер `data` і `other_data` паказваюць на розныя размеркаванні.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] паказальнікі будуць раз'яднаны:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Павінен кланаваць дадзеныя, ёсць і іншыя Rcs.
            // Загадзя вылучыце памяць, каб дазволіць непасрэдна пісаць кланаванае значэнне.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Можаце проста скрасці дадзеныя, засталося толькі Слабае
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Выдаліце няяўны моцны і слабы рэф (тут не трэба ствараць падробленых слабых-мы ведаем, што іншыя слабыя могуць ачысціць нас)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Гэта небяспечна, бо мы гарантуем, што зваротны паказальнік будзе адзіным *,* які заўсёды будзе вернуты T.
        // На дадзены момант наша колькасць спасылак гарантавана роўная 1, і мы патрабавалі, каб сам `Rc<T>` быў `mut`, таму мы вяртаем адзіную магчымую спасылку на размеркаванне.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Спроба панізіць `Rc<dyn Any>` да канкрэтнага тыпу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Выдзяляе `RcBox<T>` з дастатковай прасторай для магчымага невялікага ўнутранага значэння, дзе значэнне мае макет.
    ///
    /// Функцыя `mem_to_rcbox` выклікаецца з указальнікам дадзеных і павінна вярнуць (патэнцыйна тлусты) паказальнік для `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Разлічыце макет, выкарыстоўваючы заданы макет значэння.
        // Раней кампаноўка разлічвалася па выразе `&*(ptr as* const RcBox<T>)`, але гэта стварала няправільнае выраўноўванне (гл. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Выдзяляе `RcBox<T>` з дастатковай прасторай для магчымага невялікага ўнутранага значэння, дзе значэнне мае макет, вяртаючы памылку ў выпадку няўдалага размеркавання.
    ///
    ///
    /// Функцыя `mem_to_rcbox` выклікаецца з указальнікам дадзеных і павінна вярнуць (патэнцыйна тлусты) паказальнік для `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Разлічыце макет, выкарыстоўваючы заданы макет значэння.
        // Раней кампаноўка разлічвалася па выразе `&*(ptr as* const RcBox<T>)`, але гэта стварала няправільнае выраўноўванне (гл. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Вылучыце для макета.
        let ptr = allocate(layout)?;

        // Ініцыялізацыя RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Выдзяляе `RcBox<T>` з дастатковай прасторай для непамернага ўнутранага значэння
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Вылучыце для `RcBox<T>` з выкарыстаннем зададзенага значэння.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Капіраваць значэнне ў байтах
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Вызваліце размеркаванне, не выпускаючы яго змесціва
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Выдзяляе `RcBox<[T]>` з зададзенай даўжынёй.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Скапіруйце элементы са зрэзу ў зноў выдзелены Rc <\[T\]>
    ///
    /// Небяспечна, таму што абанент павінен альбо атрымаць права ўласнасці, альбо звязаць `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Стварае `Rc<[T]>` з ітэратара пэўнага памеру.
    ///
    /// Паводзіны не вызначана, калі памер няправільны.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic ахоўнік пры кланаванні элементаў Т.
        // У выпадку panic элементы, якія былі запісаны ў новы RcBox, будуць выдалены, а потым вызвалена памяць.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Паказальнік на першы элемент
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Усё зразумела.Забудзьцеся на ахоўніка, каб ён не вызваліў новы RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Спецыялізацыя Portrait, якая выкарыстоўваецца для `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Падае `Rc`.
    ///
    /// Гэта зменшыць значную колькасць спасылак.
    /// Калі колькасць моцных спасылак дасягае нуля, то адзінымі іншымі спасылкамі (калі такія маюцца) з'яўляюцца [`Weak`], таму мы `drop`-унутранае значэнне.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Нічога не друкуе
    /// drop(foo2);   // Друкуе "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // знішчыць змешчаны аб'ект
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // выдаліце няяўны паказальнік "strong weak" цяпер, калі мы знішчылі змесціва.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Робіць клон паказальніка `Rc`.
    ///
    /// Гэта стварае яшчэ адзін паказальнік на тое ж размеркаванне, павялічваючы моцны лік спасылак.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Стварае новы `Rc<T>` са значэннем `Default` для `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Узламаць, каб дазволіць спецыялізавацца на `Eq`, нават калі ў `Eq` ёсць метад.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Мы робім гэтую спецыялізацыю тут, а не як больш агульную аптымізацыю на `&T`, таму што ў адваротным выпадку гэта дадасць выдаткаў на ўсе праверкі адноснасці.
/// Мы мяркуем, што `Rc` выкарыстоўваюцца для захоўвання вялікіх значэнняў, якія павольна клануюцца, але таксама цяжкія для праверкі на роўнасць, з-за чаго гэты кошт акупляецца лягчэй.
///
/// Таксама больш верагоднасць мець два клоны `Rc`, якія паказваюць на адно і тое ж значэнне, чым два `&T`.
///
/// Мы можам зрабіць гэта толькі тады, калі `T: Eq` як `PartialEq` можа быць наўмысна недарэчным.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Роўнасць для двух `Rc`s.
    ///
    /// Два `Rc` роўныя, калі іх унутраныя значэнні роўныя, нават калі яны захоўваюцца ў іншым размеркаванні.
    ///
    /// Калі `T` таксама рэалізуе `Eq` (маецца на ўвазе рэфлексіўнасць роўнасці), два `Rc`, якія паказваюць на аднолькавы размеркаванне, заўсёды роўныя.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Няроўнасць для двух "Rc`s.
    ///
    /// Два `Rc` неаднолькавыя, калі іх унутраныя значэнні неаднолькавыя.
    ///
    /// Калі `T` таксама рэалізуе `Eq` (маецца на ўвазе рэфлексіўнасць роўнасці), два `Rc`, якія паказваюць на аднолькавы размеркаванне, ніколі не бываюць няроўнымі.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Частковае параўнанне для двух `Rc`.
    ///
    /// Іх параўноўваюць шляхам выкліку `partial_cmp()` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Менш, чым параўнанне для двух Rc.
    ///
    /// Іх параўноўваюць шляхам выкліку `<` па ўнутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Параўнанне "Менш або роўна" для двух "Rc".
    ///
    /// Іх параўноўваюць шляхам выкліку `<=` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Больш, чым параўнанне для двух `Rc`s.
    ///
    /// Іх параўноўваюць шляхам выкліку `>` па ўнутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Параўнанне "большае або роўнае" для двух "Rc".
    ///
    /// Іх параўноўваюць шляхам выкліку `>=` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Параўнанне для двух `Rc`.
    ///
    /// Іх параўноўваюць шляхам выкліку `cmp()` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Вылучыце зрэзаны лічыльнік і запоўніце яго шляхам кланавання элементаў v.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Вылучыце фрагмент радка, падлічаны спасылкамі, і скапіруйце ў яго `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Вылучыце фрагмент радка, падлічаны спасылкамі, і скапіруйце ў яго `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Перамясціць скрынкавы аб'ект у новы, размеркаваны спасылкі, размеркаванне.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Вылучыце зрэзаны падлік і перамясціце ў яго элементы `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Дазвольце Vec вызваліць памяць, але не разбураць яе змест
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Прымае кожны элемент у `Iterator` і збірае яго ў `Rc<[T]>`.
    ///
    /// # Характарыстыкі эксплуатацыйных характарыстык
    ///
    /// ## Агульны выпадак
    ///
    /// У агульным выпадку збор у `Rc<[T]>` ажыццяўляецца шляхам першага збору ў `Vec<T>`.Гэта значыць пры напісанні наступнага:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// гэта паводзіць сябе так, нібы мы пісалі:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Тут адбываецца першы набор вылучэнняў.
    ///     .into(); // Тут адбываецца другое размеркаванне для `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Гэта выдзеліць столькі разоў, колькі неабходна для пабудовы `Vec<T>`, а потым выдзеліць адзін раз для ператварэння `Vec<T>` у `Rc<[T]>`.
    ///
    ///
    /// ## Ітэратары вядомай даўжыні
    ///
    /// Калі ваш `Iterator` рэалізуе `TrustedLen` і мае дакладны памер, для `Rc<[T]>` будзе зроблена адзінае размеркаванне.Напрыклад:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Тут адбываецца толькі адно размеркаванне.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Спецыялізацыя Portrait, якая выкарыстоўваецца для збору ў `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Гэта тычыцца ітэратара `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЯСПЕКА: Мы павінны пераканацца, што ітэратар мае дакладную даўжыню і ў нас.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Вярнуцца да звычайнай рэалізацыі.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` гэта версія [`Rc`], якая ўтрымлівае неналежную спасылку на кіраванае размеркаванне.Доступ да выдзялення ажыццяўляецца праз выклік [`upgrade`] на паказальніку `Weak`, які вяртае [`Option`]`<`[`Rc`] `<T>>`.
///
/// Паколькі спасылка `Weak` не ўлічваецца ва ўласнасці, гэта не будзе перашкаджаць выдаленню значэння, якое захоўваецца ў размеркаванні, і сам `Weak` не дае ніякіх гарантый адносна значэння, якое ўсё яшчэ прысутнічае.
/// Такім чынам, ён можа вярнуць [`None`], калі [`абнавіць`] d.
/// Аднак звярніце ўвагу, што спасылка `Weak`*не дазваляе* выдзяляць само размеркаванне (сховішча).
///
/// Паказальнік `Weak` карысны для захавання часовай спасылкі на размеркаванне, якім кіруе [`Rc`], не прадухіляючы яго ўнутранага значэння.
/// Ён таксама выкарыстоўваецца для прадухілення кругавых спасылак паміж паказальнікамі [`Rc`], бо ўзаемныя спасылкі ніколі не дазваляюць адмовіцца ад любога з [`Rc`].
/// Напрыклад, дрэва можа мець моцныя паказальнікі [`Rc`] ад бацькоўскіх вузлоў да дзяцей, а `Weak`-ад дзяцей назад да бацькоў.
///
/// Тыповы спосаб атрымання паказальніка `Weak`-выклік [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Гэта `NonNull`, каб дазволіць аптымізаваць памер гэтага тыпу ў пералічэннях, але гэта не абавязкова сапраўдны паказальнік.
    //
    // `Weak::new` усталёўвае гэта на `usize::MAX`, так што яму не трэба выдзяляць месца ў кучы.
    // Гэта не тое значэнне, якое рэальны паказальнік калі-небудзь будзе мець, таму што RcBox мае выраўноўванне па меншай меры 2.
    // Гэта магчыма толькі пры `T: Sized`;непамерны `T` ніколі не боўтаецца.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Канструюе новы `Weak<T>` без выдзялення памяці.
    /// Выклік [`upgrade`] па зваротным значэнні заўсёды дае [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Тып дапаможніка, каб дазволіць доступ да падлікаў, не выказваючы ніякіх сцвярджэнняў пра поле дадзеных.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Вяртае неапрацаваны паказальнік на аб'ект `T`, на які паказвае гэты `Weak<T>`.
    ///
    /// Паказальнік сапраўдны, толькі калі ёсць некаторыя моцныя спасылкі.
    /// Паказальнік можа вісець, не выраўноўвацца ці нават [`null`] у адваротным выпадку.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Абодва паказваюць на адзін і той жа аб'ект
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Моцны тут падтрымлівае яго ў жывых, таму мы ўсё яшчэ маем доступ да аб'екта.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Але больш не.
    /// // Мы можам зрабіць weak.as_ptr(), але доступ да паказальніка прывядзе да нявызначаных паводзін.
    /// // assert_eq! ("прывітанне", небяспечна {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Калі паказальнік вісіць, мы вяртаем вартавога непасрэдна.
            // Гэта не можа быць сапраўдным адрасам карыснай нагрузкі, бо карысная нагрузка па меншай меры выраўнавана як RcBox (usize).
            ptr as *const T
        } else {
            // БЯСПЕКА: калі is_dangling вяртае false, значыць, паказальнік не падлягае спасылцы.
            // Карысная нагрузка ў гэты момант можа скінуцца, і мы павінны падтрымліваць паходжанне, таму выкарыстоўвайце маніпуляцыі з неапрацаванымі паказальнікамі.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Спажывае `Weak<T>` і ператварае яго ў неапрацаваны паказальнік.
    ///
    /// Гэта пераўтварае слабы паказальнік у неапрацаваны паказальнік, захоўваючы пры гэтым права ўласнасці на адну слабую спасылку (слабая колькасць не змяняецца гэтай аперацыяй).
    /// Яго можна ператварыць у `Weak<T>` разам з [`from_raw`].
    ///
    /// Прымяняюцца тыя ж абмежаванні доступу да мэты паказальніка, што і ў выпадку з [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Пераўтварае неапрацаваны паказальнік, раней створаны [`into_raw`], назад у `Weak<T>`.
    ///
    /// Гэта можа быць выкарыстана для бяспечнага атрымання надзейнай спасылкі (пазней патэлефанаваўшы на [`upgrade`]) альбо для вызвалення слабага рахунку, выпусціўшы `Weak<T>`.
    ///
    /// Ён бярэ на сябе ўласнасць адной слабой спасылкі (за выключэннем паказальнікаў, створаных [`new`], бо яны нічога не валодаюць; метад па-ранейшаму працуе на іх).
    ///
    /// # Safety
    ///
    /// Паказальнік павінен паходзіць з [`into_raw`] і павінен па-ранейшаму мець сваю слабую спасылку.
    ///
    /// На момант выкліку дазволена, каб моцны лік быў роўны 0.
    /// Тым не менш, гэта бярэ на сябе ўласнасць адной слабой спасылкі, прадстаўленай у цяперашні час як неапрацаваны паказальнік (слабая колькасць не змяняецца гэтай аперацыяй), і таму яна павінна быць у пары з папярэднім выклікам [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Паменшыць апошні слабы падлік.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Глядзіце Weak::as_ptr для кантэксту пра тое, як выводзіцца ўказальнік.

        let ptr = if is_dangling(ptr as *mut T) {
            // Гэта боўтаецца Слабы.
            ptr as *mut RcBox<T>
        } else {
            // У адваротным выпадку мы гарантуем, што паказальнік паходзіў ад неразборлівага Слабага.
            // БЯСПЕКА: data_offset бяспечна выклікаць, бо ptr спасылаецца на рэальны (патэнцыяльна скінуты) T.
            let offset = unsafe { data_offset(ptr) };
            // Такім чынам, мы змяняем зрушэнне, каб атрымаць увесь RcBox.
            // БЯСПЕКА: паказальнік паходзіць ад слабага, таму гэты зрух бяспечны.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЯСПЕКА: зараз мы аднавілі арыгінальны слабы паказальнік, таму можам стварыць слабы.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Спробы абнавіць паказальнік `Weak` да [`Rc`], адкладаючы выпадзенне ўнутранага значэння ў выпадку поспеху.
    ///
    ///
    /// Вяртае [`None`], калі ўнутранае значэнне з тых часоў было скінута.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Знішчыце ўсе моцныя паказальнікі.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Атрымлівае колькасць моцных указальнікаў (`Rc`), якія паказваюць на гэта размеркаванне.
    ///
    /// Калі `self` быў створаны з выкарыстаннем [`Weak::new`], гэта верне 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Атрымлівае колькасць указальнікаў `Weak`, якія паказваюць на гэта размеркаванне.
    ///
    /// Калі не застанецца моцных указальнікаў, гэта верне нуль.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // адняць няяўны слабы ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Вяртае `None`, калі паказальнік вісіць і `RcBox` не выдзелены (г.зн., калі `Weak` быў створаны `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Мы асцярожна, каб *не* ствараць спасылку, якая ахоплівае поле "data", бо поле можа адначасова мутаваць (напрыклад, калі апошні `Rc` будзе адкінуты, поле дадзеных будзе выдалена на месцы).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Вяртае `true`, калі два "слабых" паказваюць на адно і тое ж размеркаванне (аналагічна [`ptr::eq`]), альбо калі абодва не паказваюць на якое-небудзь размеркаванне (бо яны былі створаны з `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Паколькі гэта параўноўвае паказальнікі, гэта азначае, што `Weak::new()` будзе раўняцца адзін аднаму, нават калі яны не паказваюць на якое-небудзь размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Параўноўваючы `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Падае паказальнік `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Нічога не друкуе
    /// drop(foo);        // Друкуе "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // слабы падлік пачынаецца з 1 і будзе пераходзіць у нуль толькі тады, калі ўсе моцныя паказальнікі знікнуць.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Робіць клон паказальніка `Weak`, які паказвае на тое ж размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Канструюе новы `Weak<T>`, выдзяляючы памяць для `T` без яго ініцыялізацыі.
    /// Выклік [`upgrade`] па зваротным значэнні заўсёды дае [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Мы check_add сюды, каб бяспечна мець справу з mem::forget.У прыватнасці
// калі вы mem::forget Rcs (або слабыя), падлік падліку можа перапаўніцца, і тады вы можаце вызваліць размеркаванне, пакуль існуюць выдатныя Rcs (або слабыя).
//
// Мы перарываемся, таму што гэта настолькі дэгенератыўны сцэнар, што нам усё роўна, што адбываецца-гэта не павінна адчуваць ніводная рэальная праграма.
//
// Гэта павінна мець нязначныя накладныя выдаткі, бо вам на самой справе не трэба шмат іх кланаваць у Rust дзякуючы ўласнасці і семантыцы перамяшчэння.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Мы хочам перапыніць перапаўненне, а не скідаць значэнне.
        // Лік спасылак ніколі не будзе роўны нулю, калі гэта выклікаецца;
        // тым не менш, мы ўстаўляем тут скасаванне, каб намякнуць LLVM на іншую ўпушчаную аптымізацыю.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Мы хочам перапыніць перапаўненне, а не скідаць значэнне.
        // Лік спасылак ніколі не будзе роўны нулю, калі гэта выклікаецца;
        // тым не менш, мы ўстаўляем тут скасаванне, каб намякнуць LLVM на іншую ўпушчаную аптымізацыю.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Атрымайце зрушэнне ў межах `RcBox` для карыснай нагрузкі за паказальнікам.
///
/// # Safety
///
/// Паказальнік павінен паказваць на (і мець сапраўдныя метададзеныя) раней сапраўдны экземпляр T, але T можа быць скінуты.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Сумясціце велічыню памеру з канцом RcBox.
    // Паколькі RcBox-гэта repr(C), ён заўсёды будзе апошнім полем у памяці.
    // БЯСПЕКА: паколькі адзінымі магчымымі тыпамі з'яўляюцца зрэзы, аб'екты Portrait,
    // і знешніх тыпаў, патрабаванняў бяспекі ўводу ў цяперашні час дастаткова для задавальнення патрабаванняў align_of_val_raw;гэта дэталь рэалізацыі мовы, на якую нельга разлічваць па-за межамі std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}