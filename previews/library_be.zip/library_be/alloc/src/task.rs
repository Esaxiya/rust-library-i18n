#![stable(feature = "wake_trait", since = "1.51.0")]
//! Тыпы і Traits для працы з асінхроннымі задачамі.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ажыццяўленне абуджэння задання на выканаўцу.
///
/// Гэты Portrait можна выкарыстоўваць для стварэння [`Waker`].
/// Выканаўца можа вызначыць рэалізацыю гэтага Portrait і выкарыстоўваць яго для пабудовы Waker для пераходу да задач, якія выконваюцца на гэтым выканаўцы.
///
/// Гэты Portrait з'яўляецца бяспечнай і эрганамічнай альтэрнатывай пабудове [`RawWaker`].
/// Ён падтрымлівае агульны дызайн выканаўцы, пры якім дадзеныя, якія выкарыстоўваюцца для абуджэння задачы, захоўваюцца ў [`Arc`].
/// Некаторыя выканаўцы (асабліва ўбудаваныя сістэмы) не могуць выкарыстоўваць гэты API, таму [`RawWaker`] існуе ў якасці альтэрнатывы для гэтых сістэм.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Базавая функцыя `block_on`, якая прымае future і запускае яго да завяршэння ў бягучым патоку.
///
/// **Note:** У гэтым прыкладзе прадастаўляецца правільнасць для прастаты.
/// Для таго, каб прадухіліць тупіковыя сітуацыі, рэалізацыі вытворчага ўзроўню таксама павінны апрацоўваць прамежкавыя выклікі `thread::unpark`, а таксама ўкладзеныя выклікі.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker, які абуджае бягучую нітку пры выкліку.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Запусціце future да завяршэння на бягучым патоку.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Прышпіліце future, каб яго можна было апытаць.
///     let mut fut = Box::pin(fut);
///
///     // Стварыце новы кантэкст, які будзе перададзены future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Запусціце future да завяршэння.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Абудзіце гэтае заданне.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Прачніцеся з гэтай задачай, не спажываючы вакер.
    ///
    /// Калі выканаўца падтрымлівае больш танны спосаб абуджэння, не спажываючы вакер, ён павінен адмяніць гэты спосаб.
    /// Па змаўчанні ён кланіруе [`Arc`] і выклікае [`wake`] на клоне.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // БЯСПЕКА: Гэта бяспечна, таму што raw_waker бяспечна канструюе
        // RawWaker з Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Гэта прыватная функцыя для пабудовы RawWaker выкарыстоўваецца, а не
// уключыўшы гэта ў імпл `From<Arc<W>> for RawWaker`, каб гарантаваць, што бяспека `From<Arc<W>> for Waker` не залежыць ад правільнай адпраўкі Portrait, замест гэтага абодва імпульсы выклікаюць гэтую функцыю прама і відавочна.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Павялічце колькасць спасылак дугі, каб яе кланаваць.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Абуджэнне па значэнні, перамяшчэнне дугі ў функцыю Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Абудзіце па спасылцы, загарніце вакер у ManuallyDrop, каб пазбегнуць яго
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Паменшыце колькасць спасылак Дугі пры падзенні
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}