#![stable(feature = "rust1", since = "1.0.0")]

//! Бяспечныя для ніткі паказальнікі падліку спасылак.
//!
//! Для больш падрабязнай інфармацыі глядзіце дакументацыю [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Мяккае абмежаванне колькасці спасылак на `Arc`.
///
/// Перавышэнне гэтага абмежавання прывядзе да спынення вашай праграмы (хоць і не абавязкова) у спасылках _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer не падтрымлівае агароджы памяці.
// Каб пазбегнуць ілжыва станоўчых справаздач пры рэалізацыі Arc/Weak, выкарыстоўвайце атамныя нагрузкі для сінхранізацыі.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Бяспечны паказальнік падліку спасылак.'Arc' расшыфроўваецца як "Атамна даведкавы ўлік".
///
/// Тып `Arc<T>` забяспечвае агульнае валоданне значэннем тыпу `T`, размешчаным у кучы.Выклік [`clone`][clone] на `Arc` стварае новы экземпляр `Arc`, які паказвае на тое ж размеркаванне ў кучы, што і крыніца `Arc`, павялічваючы пры гэтым колькасць спасылак.
/// Калі апошні ўказальнік `Arc` на дадзенае размеркаванне будзе знішчаны, значэнне, якое захоўваецца ў гэтым размеркаванні (часта званае "inner value"), таксама скідаецца.
///
/// Агульныя спасылкі ў Rust забараняюць мутацыю па змаўчанні, і `Arc` не з'яўляецца выключэннем: вы звычайна не можаце атрымаць зменлівую спасылку на нешта ўнутры `Arc`.Калі вам трэба зрабіць мутацыю праз `Arc`, выкарыстоўвайце [`Mutex`][mutex], [`RwLock`][rwlock] альбо адзін з тыпаў [`Atomic`][atomic].
///
/// ## Бяспека разьбы
///
/// У адрозненне ад [`Rc<T>`], `Arc<T>` выкарыстоўвае атамныя аперацыі для падліку спасылак.Гэта азначае, што ён бяспечны для нітак.Недахопам з'яўляецца тое, што атамныя аперацыі каштуюць даражэй, чым звычайны доступ да памяці.Калі вы не карыстаецеся выдзяленнямі, улічанымі спасылкамі, паміж раздзеламі, падумайце аб выкарыстанні [`Rc<T>`] для меншага накладання.
/// [`Rc<T>`] з'яўляецца бяспечным па змаўчанні, таму што кампілятар зафіксуе любую спробу адпраўкі [`Rc<T>`] паміж патокамі.
/// Аднак бібліятэка можа выбраць `Arc<T>`, каб даць карыстальнікам бібліятэкі вялікую гнуткасць.
///
/// `Arc<T>` будзе рэалізоўваць [`Send`] і [`Sync`], пакуль `T` рэалізуе [`Send`] і [`Sync`].
/// Чаму вы не можаце змясціць у `Arc<T>` тып `T`, які не з'яўляецца бяспечным для разьбы?Спачатку гэта можа быць крыху інтуітыўна зразумелым: у рэшце рэшт, не ў гэтым сэнс бяспекі патокаў `Arc<T>`?Галоўнае ў гэтым: `Arc<T>` робіць бяспечным ніткавае валоданне множнымі правамі ўласнасці на адны і тыя ж дадзеныя, але гэта не павялічвае бяспеку патокаў.
///
/// Разгледзім `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] гэта не [`Sync`], і калі `Arc<T>` заўсёды быў [`Send`], `Arc <` [`RefCell<T>`]`>`было б таксама.
/// Але тады ў нас узнікне праблема:
/// [`RefCell<T>`] не бяспечны для нітак;ён адсочвае колькасць запазычанняў пры дапамозе неатамных аперацый.
///
/// У рэшце рэшт, гэта азначае, што вам можа спатрэбіцца спалучэнне `Arc<T>` з нейкім тыпам [`std::sync`], звычайна [`Mutex<T>`][mutex].
///
/// ## Ламаючы цыклы з `Weak`
///
/// Метад [`downgrade`][downgrade] можа быць выкарыстаны для стварэння неналежнага паказальніка [`Weak`].Паказальнікам [`Weak`] можна [`абнавіць`][абнавіць] d да `Arc`, але гэта верне [`None`], калі значэнне, якое захоўваецца ў размеркаванні, ужо было скінута.
/// Іншымі словамі, указальнікі `Weak` не падтрымліваюць значэнне ўнутры размеркавання;аднак яны *робяць* падтрымліваюць размеркаванне (рэзервовае капіраванне значэння).
///
/// Цыкл паміж паказальнікамі `Arc` ніколі не будзе вызвалены.
/// Па гэтай прычыне [`Weak`] выкарыстоўваецца для разрыву цыклаў.Напрыклад, дрэва можа мець моцныя паказальнікі `Arc` ад бацькоўскіх вузлоў да дзяцей, а [`Weak`]-ад дзяцей да бацькоў.
///
/// # Спасылкі на кланаванне
///
/// Стварэнне новай спасылкі з існуючага паказальніка з улікам спасылак вырабляецца з выкарыстаннем `Clone` Portrait, рэалізаванай для [`Arc<T>`][Arc] і [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ніжэй прыведзены два сінтаксісы эквівалентныя.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b і foo-гэта ўсе дугі, якія паказваюць на адно і тое ж месца ў памяці
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` аўтаматычна перанакіроўвае на `T` (праз [`Deref`][deref] Portrait), так што вы можаце выклікаць метады `T` на значэнні тыпу `Arc<T>`.Каб пазбегнуць сутыкнення імёнаў з метадамі T, метады самога `Arc<T>` звязаны з функцыямі, якія выклікаюцца з выкарыстаннем [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Дуга<T>Рэалізацыі traits, такія як `Clone`, таксама можна выклікаць з выкарыстаннем поўнасцю кваліфікаванага сінтаксісу.
/// Некаторыя людзі аддаюць перавагу выкарыстоўваць поўнасцю кваліфікаваны сінтаксіс, у той час як іншыя аддаюць перавагу сінтаксісу выкліку метадаў.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Сінтаксіс выкліку метаду
/// let arc2 = arc.clone();
/// // Поўнасцю кваліфікаваны сінтаксіс
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] не ажыццяўляе аўтаматычны зварот да `T`, таму што ўнутранае значэнне, магчыма, ужо скінута.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Абмен некаторымі нязменнымі дадзенымі паміж патокамі:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Звярніце ўвагу, што мы **не** праводзім гэтыя тэсты тут.
// Стваральнікі windows становяцца вельмі няшчаснымі, калі паток перажывае асноўны паток, а потым выходзіць адначасова (нешта тупіковае), таму мы проста пазбягаем гэтага, не праводзячы гэтыя тэсты.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Сумеснае выкарыстанне зменлівага [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Больш прыкладаў падліку спасылак у цэлым глядзіце ў [`rc` documentation][rc_examples].
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` гэта версія [`Arc`], якая ўтрымлівае неналежную спасылку на кіраванае размеркаванне.
/// Доступ да выдзялення ажыццяўляецца праз выклік [`upgrade`] на паказальніку `Weak`, які вяртае [`Option`]`<`[`Arc`] `<T>>`.
///
/// Паколькі спасылка `Weak` не ўлічваецца ва ўласнасці, гэта не будзе перашкаджаць выдаленню значэння, якое захоўваецца ў размеркаванні, і сам `Weak` не дае ніякіх гарантый адносна значэння, якое ўсё яшчэ прысутнічае.
///
/// Такім чынам, ён можа вярнуць [`None`], калі [`абнавіць`] d.
/// Аднак звярніце ўвагу, што спасылка `Weak`*не дазваляе* выдзяляць само размеркаванне (сховішча).
///
/// Паказальнік `Weak` карысны для захавання часовай спасылкі на размеркаванне, якім кіруе [`Arc`], не прадухіляючы яго ўнутранага значэння.
/// Ён таксама выкарыстоўваецца для прадухілення кругавых спасылак паміж паказальнікамі [`Arc`], паколькі ўзаемныя спасылкі ніколі не дазваляюць адмовіцца ад любога з [`Arc`].
/// Напрыклад, дрэва можа мець моцныя паказальнікі [`Arc`] ад бацькоўскіх вузлоў да дзяцей, а `Weak`-ад дзяцей назад да бацькоў.
///
/// Тыповы спосаб атрымання паказальніка `Weak`-выклік [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Гэта `NonNull`, каб дазволіць аптымізаваць памер гэтага тыпу ў пералічэннях, але гэта не абавязкова сапраўдны паказальнік.
    //
    // `Weak::new` усталёўвае гэта на `usize::MAX`, так што яму не трэба выдзяляць месца ў кучы.
    // Гэта не тое значэнне, якое рэальны паказальнік калі-небудзь будзе мець, таму што RcBox мае выраўноўванне па меншай меры 2.
    // Гэта магчыма толькі пры `T: Sized`;непамерны `T` ніколі не боўтаецца.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Гэта абарона ад repr(C) да future супраць магчымага пераўпарадкавання палёў, якое перашкаджае бяспечнаму [into|from]_raw() унутраных тыпаў, якія пераўтвараюцца.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // значэнне usize::MAX дзейнічае як вартавы для часовага "locking"-магчымасць павышаць слабыя паказальнікі альбо паніжаць моцныя;гэта выкарыстоўваецца для пазбягання гонак у `make_mut` і `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Канструюе новы `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Пачніце лічыць слабы паказальнік як 1, які з'яўляецца слабым паказальнікам, які ўтрымліваецца ўсімі моцнымі паказальнікамі (kinda), гл. std/rc.rs для атрымання дадатковай інфармацыі
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Канструюе новы `Arc<T>`, выкарыстоўваючы слабую спасылку на сябе.
    /// Спроба абнавіць слабую спасылку да вяртання гэтай функцыі прывядзе да значэння `None`.
    /// Аднак слабую спасылку можна свабодна кланаваць і захоўваць для выкарыстання ў далейшым.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Пабудуйце ўнутранае ў стане "uninitialized" з адной слабой спасылкай.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важна, каб мы не адмаўляліся ад права ўласнасці на слабы паказальнік, інакш памяць можа вызваліцца да вяртання `data_fn`.
        // Калі б мы сапраўды хацелі перадаць права ўласнасці, мы маглі б стварыць дадатковы слабы паказальнік для сябе, але гэта прывяло б да дадатковых абнаўленняў слабага адліку спасылак, якія інакш не спатрэбіліся б.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Цяпер мы можам правільна ініцыялізаваць унутранае значэнне і ператварыць нашу слабую спасылку ў моцную спасылку.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Вышэйапісанае запіс у поле дадзеных павінна быць бачным для ўсіх патокаў, якія назіраюць ненулявы моцны падлік.
            // Таму нам патрэбен як мінімум заказ "Release" для сінхранізацыі з `compare_exchange_weak` у `Weak::upgrade`.
            //
            // "Acquire" заказ не патрабуецца.
            // Разглядаючы магчымыя паводзіны `data_fn`, нам трэба толькі паглядзець, што ён можа зрабіць са спасылкай на `Weak`, які не абнаўляецца:
            //
            // - Ён можа *кланаваць*`Weak`, павялічваючы колькасць слабых спасылак.
            // - Ён можа скінуць гэтыя клоны, памяншаючы колькасць слабых спасылак (але ніколі да нуля).
            //
            // Гэтыя пабочныя эфекты ніяк не ўплываюць на нас, і ніякія іншыя пабочныя эфекты немагчымыя толькі пры дапамозе бяспечнага кода.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Моцныя спасылкі павінны разам мець агульную слабую спасылку, таму не запускайце дэструктар для нашай старой слабой спасылкі.
        //
        mem::forget(weak);
        strong
    }

    /// Канструюе новы `Arc` з неініцыялізаваным змесцівам.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Стварае новы `Arc` з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Канструюе новы `Pin<Arc<T>>`.
    /// Калі `T` не рэалізуе `Unpin`, `data` будзе замацаваны ў памяці і не можа быць перамешчаны.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Канструюе новы `Arc<T>`, вяртаючы памылку, калі размеркаванне не ўдаецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Пачніце лічыць слабы паказальнік як 1, які з'яўляецца слабым паказальнікам, які ўтрымліваецца ўсімі моцнымі паказальнікамі (kinda), гл. std/rc.rs для атрымання дадатковай інфармацыі
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Стварае новы `Arc` з неініцыялізаваным змесцівам, вяртаючы памылку, калі размеркаванне не ўдаецца.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Стварае новы `Arc` з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`, вяртаючы памылку, калі размеркаванне не ўдаецца.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Вяртае ўнутранае значэнне, калі `Arc` мае роўна адну моцную спасылку.
    ///
    /// У адваротным выпадку [`Err`] вяртаецца з тым самым `Arc`, які быў перададзены.
    ///
    ///
    /// Гэта атрымаецца, нават калі ёсць выбітныя слабыя спасылкі.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Зрабіце слабы паказальнік, каб ачысціць няяўную спасылку моцны і слабы
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Стварае новы зрэз з атамнай падлікай з неініцыялізаваным змесцівам.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Стварае новы зрэзаны з атамнай спасылкай фрагмент з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Пераўтварае ў `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Як і ў выпадку з [`MaybeUninit::assume_init`], абанент павінен гарантаваць, што ўнутранае значэнне сапраўды знаходзіцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае неадкладныя паводзіны.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Пераўтварае ў `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Як і ў выпадку з [`MaybeUninit::assume_init`], абанент павінен гарантаваць, што ўнутранае значэнне сапраўды знаходзіцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае неадкладныя паводзіны.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Спажывае `Arc`, вяртаючы загорнуты паказальнік.
    ///
    /// Каб пазбегнуць уцечкі памяці, паказальнік неабходна пераўтварыць назад у `Arc` з дапамогай [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Забяспечвае неапрацаваны паказальнік на дадзеныя.
    ///
    /// На падлік ніяк не ўплывае, і `Arc` не спажываецца.
    /// Паказальнік сапраўдны, пакуль у `Arc` ёсць моцны падлік.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // БЯСПЕКА: Гэта не можа прайсці праз Deref::deref альбо RcBoxPtr::inner, таму што
        // гэта неабходна для захавання паходжання raw/mut такім, каб, напрыклад
        // `get_mut` можа пісаць праз паказальнік пасля аднаўлення Rc праз `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Стварае `Arc<T>` з сырога паказальніка.
    ///
    /// Неапрацаваны паказальнік павінен быць раней вернуты выклікам [`Arc<U>::into_raw`][into_raw], дзе `U` павінен мець той жа памер і выраўноўванне, што і `T`.
    /// Гэта банальна дакладна, калі `U`-гэта `T`.
    /// Звярніце ўвагу, што калі `U` не з'яўляецца `T`, але мае аднолькавы памер і выраўноўванне, гэта ў асноўным падобна на перапрацоўку спасылак розных тыпаў.
    /// Для атрымання дадатковай інфармацыі пра тое, якія абмежаванні прымяняюцца ў гэтым выпадку, см.
    ///
    /// Карыстальнік `from_raw` павінен пераканацца, што пэўнае значэнне `T` ўпала толькі адзін раз.
    ///
    /// Гэтая функцыя небяспечная, бо няправільнае выкарыстанне можа прывесці да небяспекі памяці, нават калі зваротны `Arc<T>` ніколі не будзе даступны.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Пераўтварыце назад у `Arc`, каб прадухіліць уцечку.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Далейшыя званкі на `Arc::from_raw(x_ptr)` будуць небяспечнымі для памяці.
    /// }
    ///
    /// // Памяць вызвалілася, калі `x` выйшаў з-пад сферы дзеяння вышэй, таму `x_ptr` зараз вісіць!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Зменіце зрушэнне, каб знайсці зыходны ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Стварае новы ўказальнік [`Weak`] на гэта размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Гэта расслаблена, гэта нармальна, таму што мы правяраем значэнне ў CAS ніжэй.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // праверыць, ці слабы лічыльнік у цяперашні час "locked";калі так, круці.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: гэты код у цяперашні час ігнаруе магчымасць перапаўнення
            // у usize::MAX;увогуле, як Rc, так і Arc неабходна наладзіць, каб справіцца з перапаўненнем.
            //

            // У адрозненне ад Clone(), нам трэба, каб гэта было счытванне Acquire для сінхранізацыі з запісам, які паступае з `is_unique`, каб падзеі да гэтага запісу адбываліся да гэтага прачытання.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Пераканайцеся, што мы не ствараем вісячага Слабага
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Атрымлівае колькасць указальнікаў [`Weak`] на гэта размеркаванне.
    ///
    /// # Safety
    ///
    /// Гэты спосаб сам па сабе бяспечны, але правільнае яго выкарыстанне патрабуе дадатковай асцярожнасці.
    /// Іншы паток можа ў любы момант змяніць колькасць слабых, у тым ліку патэнцыйна паміж выклікам гэтага метаду і уздзеяннем на вынік.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Гэта зацвярджэнне з'яўляецца дэтэрмінаваным, паколькі мы не падзялялі `Arc` або `Weak` паміж патокамі.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Калі слабы падлік у цяперашні час заблакаваны, значэнне падліку было 0 непасрэдна перад прыняццем блакавання.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Атрымлівае колькасць моцных указальнікаў (`Arc`) на гэта размеркаванне.
    ///
    /// # Safety
    ///
    /// Гэты спосаб сам па сабе бяспечны, але правільнае яго выкарыстанне патрабуе дадатковай асцярожнасці.
    /// Іншая нітка можа ў любы час змяніць моцны падлік, у тым ліку, магчыма, паміж выклікам гэтага метаду і уздзеяннем на вынік.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Гэта зацвярджэнне з'яўляецца дэтэрмінаваным, паколькі мы не падзялялі `Arc` паміж патокамі.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Павялічвае моцны лік спасылак на `Arc<T>`, звязаны з прадастаўленым паказальнікам, на адзін.
    ///
    /// # Safety
    ///
    /// Паказальнік павінен быць атрыманы праз `Arc::into_raw`, і звязаны з ім экземпляр `Arc` павінен быць сапраўдным (г.зн.
    /// моцны лік павінен быць не менш за 1) на працягу ўсяго гэтага метаду.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Гэта зацвярджэнне з'яўляецца дэтэрмінаваным, паколькі мы не падзялялі `Arc` паміж патокамі.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Захоўвайце Arc, але не дакранайцеся да пералічэння, абгарнуўшы ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Цяпер павялічце падлік, але таксама не скідайце новы
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Памяншае значную колькасць спасылак на `Arc<T>`, звязаную з прадастаўленым паказальнікам, на адзінку.
    ///
    /// # Safety
    ///
    /// Паказальнік павінен быць атрыманы праз `Arc::into_raw`, і звязаны з ім экземпляр `Arc` павінен быць сапраўдным (г.зн.
    /// моцны лік павінен быць не менш за 1) пры выкарыстанні гэтага метаду.
    /// Гэты метад можна выкарыстоўваць для вызвалення канчатковага `Arc` і рэзервовага сховішча, але **не варта** выклікаць ** пасля вызвалення канчатковага `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Гэтыя сцвярджэнні дэтэрмінаваныя, таму што мы не падзялялі `Arc` паміж патокамі.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Гэта небяспечна, бо пакуль гэтая дуга жывая, мы гарантуем, што ўнутраны паказальнік сапраўдны.
        // Акрамя таго, мы ведаем, што сама структура `ArcInner`-гэта `Sync`, таму што ўнутраныя дадзеныя таксама з'яўляюцца `Sync`, таму мы можам пазычыць нязменны паказальнік на гэты змест.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Неўстаўленая частка `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Зараз знішчайце дадзеныя, хаця мы і не можам вызваліць само размеркаванне скрынкі (усё яшчэ могуць ляжаць слабыя паказальнікі).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Адкіньце слабую рэфлектыву, якая ўтрымліваецца ўсімі моцнымі спасылкамі
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Вяртае `true`, калі дзве дугі паказваюць на адно і тое ж размеркаванне (у вене, аналагічнай [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Выдзяляе `ArcInner<T>` з дастатковай прасторай для магчымага невялікага ўнутранага значэння, дзе значэнне мае макет.
    ///
    /// Функцыя `mem_to_arcinner` выклікаецца з указальнікам дадзеных і павінна вярнуць (патэнцыйна тлусты) паказальнік для `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Разлічыце макет, выкарыстоўваючы заданы макет значэння.
        // Раней кампаноўка разлічвалася па выразе `&*(ptr as* const ArcInner<T>)`, але гэта стварала няправільнае выраўноўванне (гл. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Выдзяляе `ArcInner<T>` з дастатковай прасторай для магчымага невялікага ўнутранага значэння, дзе значэнне мае макет, вяртаючы памылку ў выпадку няўдалага размеркавання.
    ///
    ///
    /// Функцыя `mem_to_arcinner` выклікаецца з указальнікам дадзеных і павінна вярнуць (патэнцыйна тлусты) паказальнік для `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Разлічыце макет, выкарыстоўваючы заданы макет значэння.
        // Раней кампаноўка разлічвалася па выразе `&*(ptr as* const ArcInner<T>)`, але гэта стварала няправільнае выраўноўванне (гл. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Ініцыялізацыя ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Выдзяляе `ArcInner<T>` з дастатковай прасторай для непамернага ўнутранага значэння.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Вылучыце для `ArcInner<T>` з выкарыстаннем зададзенага значэння.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Капіраваць значэнне ў байтах
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Вызваліце размеркаванне, не выпускаючы яго змесціва
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Выдзяляе `ArcInner<[T]>` з зададзенай даўжынёй.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Скапіруйце элементы з зрэзу ў зноў выдзеленую дугу <\[T\]>
    ///
    /// Небяспечна, таму што абанент павінен альбо атрымаць права ўласнасці, альбо звязаць `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Стварае `Arc<[T]>` з ітэратара пэўнага памеру.
    ///
    /// Паводзіны не вызначана, калі памер няправільны.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic ахоўнік пры кланаванні элементаў Т.
        // У выпадку panic элементы, якія былі запісаны ў новы ArcInner, будуць выдалены, а потым вызвалена памяць.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Паказальнік на першы элемент
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Усё зразумела.Забудзьцеся на ахоўніка, каб ён не вызваліў новы ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Спецыялізацыя Portrait, якая выкарыстоўваецца для `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Робіць клон паказальніка `Arc`.
    ///
    /// Гэта стварае яшчэ адзін паказальнік на тое ж размеркаванне, павялічваючы моцны лік спасылак.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Тут можна выкарыстоўваць спакойнае ўпарадкаванне, бо веданне зыходнай спасылкі перашкаджае памылковаму выдаленню аб'екта іншымі патокамі.
        //
        // Як тлумачыцца ў [Boost documentation][1], павелічэнне лічыльніка спасылак заўсёды можна зрабіць з дапамогай memory_order_relaxed: Новыя спасылкі на аб'ект могуць быць сфармаваны толькі з існуючай спасылкі, а перадача існуючай спасылкі з аднаго патоку ў іншы павінна ўжо забяспечваць неабходную сінхранізацыю.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Аднак нам трэба засцерагчыся ад масавых пералічэнняў на той выпадак, калі хто-небудзь `mem: : забудзецца` дугі.
        // Калі мы гэтага не зробім, колькасць можа перапаўніцца, і карыстальнікі будуць выкарыстоўваць пасля.
        // Мы насычана насычаем `isize::MAX`, мяркуючы, што няма нітак ~2 мільярдаў, якія адначасова павялічваюць колькасць спасылак.
        //
        // Гэты branch ніколі не возьмецца ні ў адной рэалістычнай праграме.
        //
        // Мы спыняем працу, бо такая праграма неверагодна выраджана, і мы не хочам яе падтрымліваць.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Змяняе спасылку на дадзены `Arc`.
    ///
    /// Калі ёсць іншыя ўказальнікі `Arc` або [`Weak`] на тое ж размеркаванне, тады `make_mut` створыць новы размеркаванне і выкліча [`clone`][clone] на ўнутранае значэнне для забеспячэння унікальнай уласнасці.
    /// Гэта таксама называюць клонам на запіс.
    ///
    /// Звярніце ўвагу, што гэта адрозніваецца ад паводзін [`Rc::make_mut`], які раз'ядноўвае любыя астатнія паказальнікі `Weak`.
    ///
    /// Глядзіце таксама [`get_mut`][get_mut], які хутчэй не атрымаецца, чым кланіраваць.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Не будзе нічога кланаваць
    /// let mut other_data = Arc::clone(&data); // Не будзе кланаваць унутраныя дадзеныя
    /// *Arc::make_mut(&mut data) += 1;         // Унутраныя дадзеныя клонаў
    /// *Arc::make_mut(&mut data) += 1;         // Не будзе нічога кланаваць
    /// *Arc::make_mut(&mut other_data) *= 2;   // Не будзе нічога кланаваць
    ///
    /// // Цяпер `data` і `other_data` паказваюць на розныя размеркаванні.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Звярніце ўвагу, што мы маем як моцную спасылку, так і слабую.
        // Такім чынам, вызваленне толькі нашай моцнай спасылкі само па сабе не прывядзе да вызвалення памяці.
        //
        // Выкарыстоўвайце Acquire, каб пераканацца, што мы бачым любыя запісы ў `weak`, якія адбываюцца да запісу выпуску (г.зн. змяншэнні) у `strong`.
        // Паколькі мы маем слабы падлік галасоў, няма магчымасці вывесці саму ArcInner.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Існуе яшчэ адзін моцны паказальнік, таму мы павінны кланаваць.
            // Загадзя вылучыце памяць, каб дазволіць непасрэдна пісаць кланаванае значэнне.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Вышэй сказанага дастаткова, таму што гэта прынцыпова аптымізацыя: мы заўсёды імчамся са слабымі паказальнікамі.
            // У горшым выпадку мы ў выніку вылучылі новую дугу без неабходнасці.
            //

            // Мы выдалілі апошнюю моцную спасылку, але засталіся дадатковыя слабыя спасылкі.
            // Мы перамесцім змесціва ў новую дугу, а іншыя слабыя спасылкі прызнаем несапраўднымі.
            //

            // Звярніце ўвагу, што чытанне `weak` не можа даць usize::MAX (г.зн., заблакаванае), бо слабы падлік можа быць зафіксаваны толькі патокам з моцнай спасылкай.
            //
            //

            // Матэрыялізуйце наш уласны няяўны слабы паказальнік, каб ён мог ачысціць ArcInner па меры неабходнасці.
            //
            let _weak = Weak { ptr: this.ptr };

            // Можаце проста скрасці дадзеныя, засталося толькі Слабае
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Мы былі адзінай спасылкай любога віду;падняць назад моцны падлік.
            //
            this.inner().strong.store(1, Release);
        }

        // Як і ў выпадку з `get_mut()`, небяспека ў парадку, бо наша спасылка для пачатку была альбо унікальнай, альбо стала такой пры кланаванні змесціва.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Вяртае зменлівую спасылку на дадзены `Arc`, калі няма іншых указальнікаў `Arc` або [`Weak`] на тое ж размеркаванне.
    ///
    ///
    /// Вяртае [`None`] у адваротным выпадку, таму што бяспечна мутаваць агульнае значэнне.
    ///
    /// Глядзіце таксама [`make_mut`][make_mut], які будзе [`clone`][clone] унутраным значэннем, калі ёсць іншыя ўказальнікі.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Гэта небяспечна, бо мы гарантуем, што зваротны паказальнік будзе адзіным *,* які заўсёды будзе вернуты T.
            // У гэты момант наша колькасць спасылак гарантавана роўная 1, і мы патрабавалі, каб сама дуга была `mut`, таму мы вяртаем адзіную магчымую спасылку на ўнутраныя дадзеныя.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Вяртае зменную спасылку на дадзены `Arc` без праверкі.
    ///
    /// Глядзіце таксама [`get_mut`], які з'яўляецца бяспечным і праводзіць адпаведныя праверкі.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Любыя іншыя ўказальнікі `Arc` або [`Weak`] на тое ж самае размеркаванне не павінны разглядацца на працягу часу вяртання пазыкі.
    ///
    /// Гэта банальна, калі такіх паказальнікаў не існуе, напрыклад, адразу пасля `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Мы асцярожна, каб *не* ствараць спасылку, якая ахоплівае палі "count", паколькі гэта можа мець псеўданім з адначасовым доступам да падліку спасылак (напрыклад,
        // па `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Вызначце, ці з'яўляецца гэта унікальнай спасылкай (уключаючы слабыя спасылкі) на асноўныя дадзеныя.
    ///
    ///
    /// Звярніце ўвагу, што для гэтага трэба зафіксаваць слабы падлік.
    fn is_unique(&mut self) -> bool {
        // зафіксуйце колькасць слабых паказальнікаў, калі мы з'яўляемся адзіным трымальнікам слабага паказальніка.
        //
        // Этыкетка "набыць" тут забяспечвае сувязь, якая адбываецца раней, з любымі запісамі ў `strong` (у прыватнасці, у `Weak::upgrade`) да памяншэння колькасці `weak` (праз `Weak::drop`, які выкарыстоўвае рэліз).
        // Калі абноўленая слабая спасылка ніколі не была адменена, CAS тут не атрымаецца, таму мы не хочам сінхранізаваць.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Гэта павінен быць `Acquire` для сінхранізацыі з змяншэннем лічыльніка `strong` у `drop`-адзіны доступ, які адбываецца, калі аніякая спасылка, акрамя апошняй, апускаецца.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Запіс выпуску тут сінхранізуецца з чытаннем у `downgrade`, эфектыўна прадухіляючы згаданае чытанне `strong` пасля запісу.
            //
            //
            self.inner().weak.store(1, Release); // адпусціце замак
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Падае `Arc`.
    ///
    /// Гэта зменшыць значную колькасць спасылак.
    /// Калі колькасць моцных спасылак дасягае нуля, то адзінымі іншымі спасылкамі (калі такія маюцца) з'яўляюцца [`Weak`], таму мы `drop`-унутранае значэнне.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Нічога не друкуе
    /// drop(foo2);   // Друкуе "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Паколькі `fetch_sub` ужо атамны, нам не трэба сінхранізаваць з іншымі патокамі, калі мы не збіраемся выдаляць аб'ект.
        // Гэтая ж логіка адносіцца да ніжэй прыведзенага `fetch_sub` да падліку `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Гэты плот неабходны для прадухілення змянення парадку выкарыстання дадзеных і іх выдалення.
        // Паколькі ён пазначаны `Release`, памяншэнне колькасці спасылак сінхранізуецца з гэтым плотам `Acquire`.
        // Гэта азначае, што выкарыстанне дадзеных адбываецца да памяншэння колькасці спасылак, што адбываецца да гэтага плота, што адбываецца да выдалення дадзеных.
        //
        // Як тлумачыцца ў [Boost documentation][1],
        //
        // > Важна забяспечыць любы магчымы доступ да аб'екта ў адным
        // > паток (праз існуючую спасылку), каб *адбылося да* выдалення
        // > аб'ект у іншай нітцы.Гэта дасягаецца "release"
        // > аперацыя пасля выдалення спасылкі (любы доступ да аб'екта
        // > праз гэтую спасылку, відавочна, павінна было адбыцца раней), і
        // > "acquire" аперацыя перад выдаленнем аб'екта.
        //
        // У прыватнасці, нягледзячы на тое, што змест дугі звычайна нязменны, унутраныя запісы могуць быць падобныя на Mutex<T>.
        // Паколькі Mutex не атрымліваецца пры выдаленні, мы не можам спадзявацца на яго логіку сінхранізацыі, каб зрабіць запісы ў патоку A бачнымі для дэструктара, які працуе ў патоку B.
        //
        //
        // Таксама звярніце ўвагу, што плот Acquire тут, верагодна, можа быць заменены нагрузкай Acquire, што можа палепшыць прадукцыйнасць ва ўмовах высокай канкурэнцыі.Глядзіце [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Спроба панізіць `Arc<dyn Any + Send + Sync>` да канкрэтнага тыпу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Канструюе новы `Weak<T>` без выдзялення памяці.
    /// Выклік [`upgrade`] па зваротным значэнні заўсёды дае [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Тып дапаможніка, каб дазволіць доступ да падлікаў, не выказваючы ніякіх сцвярджэнняў пра поле дадзеных.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Вяртае неапрацаваны паказальнік на аб'ект `T`, на які паказвае гэты `Weak<T>`.
    ///
    /// Паказальнік сапраўдны, толькі калі ёсць некаторыя моцныя спасылкі.
    /// Паказальнік можа вісець, не выраўноўвацца ці нават [`null`] у адваротным выпадку.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Абодва паказваюць на адзін і той жа аб'ект
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Моцны тут падтрымлівае яго ў жывых, таму мы ўсё яшчэ маем доступ да аб'екта.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Але больш не.
    /// // Мы можам зрабіць weak.as_ptr(), але доступ да паказальніка прывядзе да нявызначаных паводзін.
    /// // assert_eq! ("прывітанне", небяспечна {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Калі паказальнік вісіць, мы вяртаем вартавога непасрэдна.
            // Гэта не можа быць сапраўдным адрасам карыснай нагрузкі, бо карысная нагрузка па меншай меры выраўнавана як ArcInner (usize).
            ptr as *const T
        } else {
            // БЯСПЕКА: калі is_dangling вяртае false, значыць, паказальнік не падлягае спасылцы.
            // Карысная нагрузка ў гэты момант можа скінуцца, і мы павінны падтрымліваць паходжанне, таму выкарыстоўвайце маніпуляцыі з неапрацаванымі паказальнікамі.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Спажывае `Weak<T>` і ператварае яго ў неапрацаваны паказальнік.
    ///
    /// Гэта пераўтварае слабы паказальнік у неапрацаваны паказальнік, захоўваючы пры гэтым права ўласнасці на адну слабую спасылку (слабая колькасць не змяняецца гэтай аперацыяй).
    /// Яго можна ператварыць у `Weak<T>` разам з [`from_raw`].
    ///
    /// Прымяняюцца тыя ж абмежаванні доступу да мэты паказальніка, што і ў выпадку з [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Пераўтварае неапрацаваны паказальнік, раней створаны [`into_raw`], назад у `Weak<T>`.
    ///
    /// Гэта можа быць выкарыстана для бяспечнага атрымання надзейнай спасылкі (пазней патэлефанаваўшы на [`upgrade`]) альбо для вызвалення слабага рахунку, выпусціўшы `Weak<T>`.
    ///
    /// Ён бярэ на сябе ўласнасць адной слабой спасылкі (за выключэннем паказальнікаў, створаных [`new`], бо яны нічога не валодаюць; метад па-ранейшаму працуе на іх).
    ///
    /// # Safety
    ///
    /// Паказальнік павінен паходзіць з [`into_raw`] і павінен па-ранейшаму мець сваю слабую спасылку.
    ///
    /// На момант выкліку дазволена, каб моцны лік быў роўны 0.
    /// Тым не менш, гэта бярэ на сябе ўласнасць адной слабой спасылкі, прадстаўленай у цяперашні час як неапрацаваны паказальнік (слабая колькасць не змяняецца гэтай аперацыяй), і таму яна павінна быць у пары з папярэднім выклікам [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Паменшыць апошні слабы падлік.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Глядзіце Weak::as_ptr для кантэксту пра тое, як выводзіцца ўказальнік.

        let ptr = if is_dangling(ptr as *mut T) {
            // Гэта боўтаецца Слабы.
            ptr as *mut ArcInner<T>
        } else {
            // У адваротным выпадку мы гарантуем, што паказальнік паходзіў ад неразборлівага Слабага.
            // БЯСПЕКА: data_offset бяспечна выклікаць, бо ptr спасылаецца на рэальны (патэнцыяльна скінуты) T.
            let offset = unsafe { data_offset(ptr) };
            // Такім чынам, мы змяняем зрушэнне, каб атрымаць увесь RcBox.
            // БЯСПЕКА: паказальнік паходзіць ад слабага, таму гэты зрух бяспечны.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЯСПЕКА: зараз мы аднавілі арыгінальны слабы паказальнік, таму можам стварыць слабы.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Спробы абнавіць паказальнік `Weak` да [`Arc`], адкладаючы выпадзенне ўнутранага значэння ў выпадку поспеху.
    ///
    ///
    /// Вяртае [`None`], калі ўнутранае значэнне з тых часоў было скінута.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Знішчыце ўсе моцныя паказальнікі.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Мы выкарыстоўваем цыкл CAS для павелічэння моцнага падліку замест fetch_add, паколькі гэтая функцыя ніколі не павінна прымаць адлік спасылак з нуля да аднаго.
        //
        //
        let inner = self.inner()?;

        // Паслабленая нагрузка, таму што любы запіс 0, які мы можам назіраць, пакідае поле ў пастаянна нулявым стане (таму чытанне "stale" з 0 выдатна), а любое іншае значэнне пацвярджаецца з дапамогай CAS ніжэй.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Глядзіце каментарыі ў `Arc::clone` пра тое, чаму мы гэта робім (для `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // У выпадку няўдачы расслабленасць-гэта добра, бо мы не чакаем новай дзяржавы.
            // Набыць неабходна для сінхранізацыі выпадку паспяховасці з `Arc::new_cyclic`, калі ўнутранае значэнне можа быць ініцыялізавана пасля таго, як ужо створаны спасылкі на `Weak`.
            // У гэтым выпадку мы разлічваем назіраць цалкам ініцыялізаванае значэнне.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // нуль правераны вышэй
                Err(old) => n = old,
            }
        }
    }

    /// Атрымлівае колькасць моцных указальнікаў (`Arc`), якія паказваюць на гэта размеркаванне.
    ///
    /// Калі `self` быў створаны з выкарыстаннем [`Weak::new`], гэта верне 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Атрымлівае прыблізнае колькасць указальнікаў `Weak`, якія паказваюць на гэта размеркаванне.
    ///
    /// Калі `self` быў створаны з выкарыстаннем [`Weak::new`], альбо калі няма астатніх моцных указальнікаў, гэта верне 0.
    ///
    /// # Accuracy
    ///
    /// З-за дэталяў рэалізацыі, якое вяртаецца значэнне можа быць адключана на 1 у любым кірунку, калі іншыя патокі маніпулююць любымі `Arc`s або`Weak`s, якія паказваюць на тое ж размеркаванне.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Паколькі мы заўважылі, што пасля прачытання слабага падліку існаваў па меншай меры адзін моцны паказальнік, мы ведаем, што няяўная слабая спасылка (прысутнічае, калі жывыя любыя моцныя спасылкі) усё яшчэ была побач, калі мы назіралі слабы падлік, і таму смела можам яе адняць.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Вяртае `None`, калі паказальнік вісіць і `ArcInner` не выдзелены (г.зн., калі `Weak` быў створаны `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Мы асцярожна, каб *не* ствараць спасылку, якая ахоплівае поле "data", бо поле можа адначасова мутаваць (напрыклад, калі апошні `Arc` будзе адкінуты, поле дадзеных будзе выдалена на месцы).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Вяртае `true`, калі два "слабых" паказваюць на адно і тое ж размеркаванне (аналагічна [`ptr::eq`]), альбо калі абодва не паказваюць на якое-небудзь размеркаванне (бо яны былі створаны з `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Паколькі гэта параўноўвае паказальнікі, гэта азначае, што `Weak::new()` будзе раўняцца адзін аднаму, нават калі яны не паказваюць на якое-небудзь размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Параўноўваючы `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Робіць клон паказальніка `Weak`, які паказвае на тое ж размеркаванне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Глядзіце каментарыі ў Arc::clone(), каб даведацца, чаму гэта расслаблена.
        // Тут можна выкарыстоўваць fetch_add (ігнаруючы блакаванне), таму што слабы падлік заблакаваны толькі там, дзе *няма* іншых слабых паказальнікаў.
        //
        // (Такім чынам, мы не можам запусціць гэты код у гэтым выпадку).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Глядзіце каментарыі ў Arc::clone() пра тое, чаму мы гэта робім (для mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Канструюе новы `Weak<T>` без выдзялення памяці.
    /// Выклік [`upgrade`] па зваротным значэнні заўсёды дае [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Падае паказальнік `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Нічога не друкуе
    /// drop(foo);        // Друкуе "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Калі мы даведаемся, што мы былі апошнім слабым паказальнікам, настаў час цалкам вызваліць дадзеныя.Глядзіце дыскусію ў Arc::drop() аб упарадкаванні памяці
        //
        // Тут няма неабходнасці правяраць заблакаваны стан, таму што слабы падлік можа быць заблакаваны толькі ў тым выпадку, калі быў дакладна адзін слабы рэф, гэта значыць, што падзенне можа толькі пасля запусціцца на той астатні слабы рэф, што можа адбыцца толькі пасля вызвалення блакавання.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Мы робім гэтую спецыялізацыю тут, а не як больш агульную аптымізацыю на `&T`, таму што ў адваротным выпадку гэта дадасць выдаткаў на ўсе праверкі адноснасці.
/// Мы мяркуем, што `Arc`s выкарыстоўваюцца для захоўвання вялікіх значэнняў, якія павольна клануюцца, але таксама цяжкія для праверкі на роўнасць, дзякуючы чаму гэты кошт лягчэй акупляецца.
///
/// Таксама больш верагоднасць мець два клоны `Arc`, якія паказваюць на адно і тое ж значэнне, чым два `&T`.
///
/// Мы можам зрабіць гэта толькі тады, калі `T: Eq` як `PartialEq` можа быць наўмысна недарэчным.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Роўнасць для двух `Arc`s.
    ///
    /// Дзве дугі роўныя, калі іх унутраныя значэнні роўныя, нават калі яны захоўваюцца ў іншым размеркаванні.
    ///
    /// Калі `T` таксама рэалізуе `Eq` (маецца на ўвазе рэфлексіўнасць роўнасці), дзве `дугі, якія паказваюць на аднолькавы размеркаванне, заўсёды роўныя.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Няроўнасць для двух `Arc`s.
    ///
    /// Дзве дугі неаднолькавыя, калі іх унутраныя значэнні неаднолькавыя.
    ///
    /// Калі `T` таксама рэалізуе `Eq` (маецца на ўвазе рэфлексіўнасць роўнасці), дзве `дугі, якія паказваюць на адно і тое ж значэнне, ніколі не бываюць няроўнымі.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Частковае параўнанне для двух `Arc`s.
    ///
    /// Іх параўноўваюць шляхам выкліку `partial_cmp()` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Менш чым параўнанне для двух "Arc`s.
    ///
    /// Іх параўноўваюць шляхам выкліку `<` па ўнутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Параўнанне "Менш альбо роўна" для двух "Arc`s.
    ///
    /// Іх параўноўваюць шляхам выкліку `<=` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Большае параўнанне для двух "Arc`s.
    ///
    /// Іх параўноўваюць шляхам выкліку `>` па ўнутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Параўнанне "Большае або роўнае" для двух "Arc`s.
    ///
    /// Іх параўноўваюць шляхам выкліку `>=` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Параўнанне для двух `Arc`s.
    ///
    /// Іх параўноўваюць шляхам выкліку `cmp()` па іх унутраных каштоўнасцях.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Стварае новы `Arc<T>` са значэннем `Default` для `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Вылучыце зрэзаны лічыльнік і запоўніце яго шляхам кланавання элементаў v.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Вылучыце падлічаны `str` і скапіруйце ў яго `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Вылучыце падлічаны `str` і скапіруйце ў яго `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Перамясціць скрынкавы аб'ект у новае размеркаванне, улічанае спасылкамі.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Вылучыце зрэзаны падлік і перамясціце ў яго элементы `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Дазвольце Vec вызваліць памяць, але не разбураць яе змест
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Прымае кожны элемент у `Iterator` і збірае яго ў `Arc<[T]>`.
    ///
    /// # Характарыстыкі эксплуатацыйных характарыстык
    ///
    /// ## Агульны выпадак
    ///
    /// У агульным выпадку збор у `Arc<[T]>` ажыццяўляецца шляхам першага збору ў `Vec<T>`.Гэта значыць пры напісанні наступнага:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// гэта паводзіць сябе так, нібы мы пісалі:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Тут адбываецца першы набор вылучэнняў.
    ///     .into(); // Тут адбываецца другое размеркаванне для `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Гэта выдзеліць столькі разоў, колькі неабходна для пабудовы `Vec<T>`, а потым выдзеліць адзін раз для ператварэння `Vec<T>` у `Arc<[T]>`.
    ///
    ///
    /// ## Ітэратары вядомай даўжыні
    ///
    /// Калі ваш `Iterator` рэалізуе `TrustedLen` і мае дакладны памер, для `Arc<[T]>` будзе зроблена адзінае размеркаванне.Напрыклад:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Тут адбываецца толькі адно размеркаванне.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Спецыялізацыя Portrait, якая выкарыстоўваецца для збору ў `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Гэта тычыцца ітэратара `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЯСПЕКА: Мы павінны пераканацца, што ітэратар мае дакладную даўжыню і ў нас.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Вярнуцца да звычайнай рэалізацыі.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Атрымайце зрушэнне ў межах `ArcInner` для карыснай нагрузкі за паказальнікам.
///
/// # Safety
///
/// Паказальнік павінен паказваць на (і мець сапраўдныя метададзеныя) раней сапраўдны экземпляр T, але T можа быць скінуты.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Выраўняйце велічыню памеру да канца ArcInner.
    // Паколькі RcBox-гэта repr(C), ён заўсёды будзе апошнім полем у памяці.
    // БЯСПЕКА: паколькі адзінымі магчымымі тыпамі з'яўляюцца зрэзы, аб'екты Portrait,
    // і знешніх тыпаў, патрабаванняў бяспекі ўводу ў цяперашні час дастаткова для задавальнення патрабаванняў align_of_val_raw;гэта дэталь рэалізацыі мовы, на якую нельга разлічваць па-за межамі std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}