//! Вылучэнне Prelude
//!
//! Мэта гэтага модуля-палегчыць імпарт часта выкарыстоўваюцца элементаў `alloc` crate, дадаўшы імпарт глабальнай верхняй часткі модуляў:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;