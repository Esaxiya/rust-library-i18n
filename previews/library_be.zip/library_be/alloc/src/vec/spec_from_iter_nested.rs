use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Іншая спецыялізацыя Portrait для Vec::from_iter, неабходная для ўручную расстаноўкі прыярытэтаў, якія перакрываюцца, у падрабязнасцях гл. [`SpecFromIter`](super::SpecFromIter).
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Разгарніце першую ітэрацыю, бо vector будзе пашырацца на гэтай ітэрацыі ў кожным выпадку, калі ітэрацыя не пустая, але цыкл у extend_desugared() не бачыць, каб vector быў запоўнены ў некалькіх наступных ітэрацыях цыкла.
        //
        // Такім чынам, мы атрымліваем лепшае прагназаванне branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // павінен дэлегаваць spec_extend(), бо сам extend() дэлегуе spec_from для пустых Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // павінен дэлегаваць spec_extend(), бо сам extend() дэлегуе spec_from для пустых Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}