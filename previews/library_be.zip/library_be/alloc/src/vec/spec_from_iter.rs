use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Спецыялізацыя Portrait, якая выкарыстоўваецца для Vec::from_iter
///
/// ## Графік дэлегацыі:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Звычайным выпадкам з'яўляецца перадача vector у функцыю, якая неадкладна зноў збіраецца ў vector.
        // Мы можам зрабіць кароткае замыканне, калі IntoIter зусім не прасунуты.
        // Калі ён быў удасканалены, мы таксама можам выкарыстоўваць памяць паўторна і перанесці дадзеныя ў пярэднюю частку.
        // Але мы робім гэта толькі тады, калі атрыманы Vec не будзе мець больш невыкарыстоўванай ёмістасці, чым стварыць яе праз агульную рэалізацыю FromIterator.
        //
        // Гэта абмежаванне не з'яўляецца строга неабходным, паколькі паводзіны Vec па размеркаванні наўмысна не вызначана.
        // Але гэта кансерватыўны выбар.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // павінен дэлегаваць spec_extend(), бо сам extend() дэлегуе spec_from для пустых Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Тут выкарыстоўваецца `iterator.as_slice().to_vec()`, бо spec_extend павінен зрабіць больш крокаў, каб разважаць пра канчатковую ёмістасць + даўжыню і, такім чынам, зрабіць больш працы.
// `to_vec()` непасрэдна выдзяляе правільную колькасць і дакладна запаўняе.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): з cfg(test) уласцівы метад `[T]::to_vec`, неабходны для вызначэння гэтага метаду, недаступны.
    // Замест гэтага выкарыстоўвайце функцыю `slice::to_vec`, якая даступная толькі з cfg(test) NB. Глядзіце модуль slice::hack у slice.rs для атрымання дадатковай інфармацыі
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}