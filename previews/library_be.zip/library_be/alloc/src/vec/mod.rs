//! Сумежны тып масіва, які можна прарастаць, з выдзеленым кучай змесцівам, напісаны `Vec<T>`.
//!
//! Vectors маюць індэксацыю `O(1)`, амартызаваны `O(1)` штуршок (да канца) і `O(1)` поп (з канца).
//!
//!
//! Vectors гарантуюць, што яны ніколі не выдзяляюць больш за байт `isize::MAX`.
//!
//! # Examples
//!
//! Вы можаце відавочна стварыць [`Vec`] з [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... альбо з выкарыстаннем макраса [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // дзесяць нулёў
//! ```
//!
//! Вы можаце ўнесці значэнні [`push`] у канец vector (які будзе павялічваць vector па меры неабходнасці):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Выскакванне значэнняў працуе прыблізна аднолькава:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors таксама падтрымлівае індэксацыю (праз [`Index`] і [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Сумежны тып масіва, які можна вырошчваць, запісваецца як `Vec<T>` і вымаўляецца як 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Макрас [`vec!`] прадастаўляецца для больш зручнай ініцыялізацыі:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Ён таксама можа ініцыялізаваць кожны элемент `Vec<T>` зададзеным значэннем.
/// Гэта можа быць больш эфектыўна, чым выкананне размеркавання і ініцыялізацыі ў асобных кроках, асабліва пры ініцыялізацыі vector нулёў:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ніжэй прыведзены эквівалент, але патэнцыйна больш павольны:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Для атрымання дадатковай інфармацыі см. [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Выкарыстоўвайце `Vec<T>` у якасці эфектыўнага стэка:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Друкуе 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Тып `Vec` дазваляе атрымаць доступ да значэнняў па індэксе, таму што ён рэалізуе [`Index`] Portrait.Прыклад будзе больш відавочным:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ён будзе адлюстроўваць '2'
/// ```
///
/// Аднак будзьце асцярожныя: калі вы паспрабуеце атрымаць доступ да індэкса, якога няма ў `Vec`, ваша праграмнае забеспячэнне будзе panic!Вы не можаце зрабіць гэта:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Выкарыстоўвайце [`get`] і [`get_mut`], калі вы хочаце праверыць, ці знаходзіцца індэкс у `Vec`.
///
/// # Slicing
///
/// `Vec` можа быць зменлівым.З іншага боку, зрэзы-гэта аб'екты толькі для чытання.
/// Каб атрымаць [slice][prim@slice], выкарыстоўвайце [`&`].Прыклад:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... і ўсё!
/// // Вы таксама можаце зрабіць гэта так:
/// let u: &[usize] = &v;
/// // альбо вось так:
/// let u: &[_] = &v;
/// ```
///
/// У Rust часцей за ўсё перадаваць зрэзы ў якасці аргументаў, а не vectors, калі вы проста хочаце забяспечыць доступ для чытання.Тое ж самае тычыцца [`String`] і [`&str`].
///
/// # Ёмістасць і пераразмеркаванне
///
/// Ёмістасць vector-гэта колькасць месца, адведзенага для любых элементаў future, якія будуць дададзены да vector.Гэта не варта блытаць з *даўжынёй* vector, якая ўказвае колькасць фактычных элементаў у vector.
/// Калі даўжыня vector перавышае яго ёмістасць, яе ёмістасць будзе аўтаматычна павялічана, але элементы павінны быць пераразмеркаваны.
///
/// Напрыклад, vector ёмістасцю 10 і даўжынёй 0 быў бы пустым vector з месцам для яшчэ 10 элементаў.Націсканне 10 ці менш элементаў на vector не зменіць яго ёмістасць і не прывядзе да пераразмеркавання.
/// Аднак, калі даўжыню vector павялічыць да 11, яе давядзецца пераразмеркаваць, што можа быць павольна.Па гэтай прычыне рэкамендуецца выкарыстоўваць [`Vec::with_capacity`] па магчымасці, каб паказаць, наколькі вялікі vector павінен атрымацца.
///
/// # Guarantees
///
/// Дзякуючы сваёй неверагодна фундаментальнай прыродзе, `Vec` дае шмат гарантый адносна сваёй канструкцыі.Гэта гарантуе, што ў агульным выпадку гэта максімальна нізкія накладныя выдаткі і можа быць правільна апрацавана прымітыўнымі спосабамі з дапамогай небяспечнага кода.Звярніце ўвагу, што гэтыя гарантыі адносяцца да некваліфікаванага `Vec<T>`.
/// Калі дадаюцца дадатковыя параметры тыпу (напрыклад, для падтрымкі карыстацкіх размеркавальнікаў), перавызначэнне стандартных значэнняў можа змяніць паводзіны.
///
/// Самае прынцыповае, `Vec`-гэта і заўсёды будзе трыплет (паказальнік, ёмістасць, даўжыня).Ні больш, ні менш.Парадак гэтых палёў зусім не вызначаны, і вы павінны выкарыстоўваць адпаведныя метады, каб змяніць іх.
/// Паказальнік ніколі не будзе нулявым, таму гэты тып аптымізаваны для нулявага ўказальніка.
///
/// Аднак паказальнік можа фактычна не паказваць на выдзеленую памяць.
/// У прыватнасці, калі вы ствараеце `Vec` ёмістасцю 0 праз [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] альбо выклікаючы [`shrink_to_fit`] на пустым Vec, ён не выдзеліць памяць.Сапраўды гэтак жа, калі вы захоўваеце нулявыя тыпы ўнутры `Vec`, ён не выдзеліць для іх месца.
/// *Звярніце ўвагу, што ў гэтым выпадку `Vec` можа не паведамляць пра [`capacity`] 0*.
/// `Vec` выдзеліць тады і толькі тады, калі [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Увогуле, дэталі размеркавання "Vec" вельмі тонкія-калі вы збіраецеся вылучыць памяць з дапамогай `Vec` і выкарыстоўваць яе для чагосьці іншага (альбо для пераходу да небяспечнага кода, альбо для стварэння ўласнай калекцыі, якая падтрымліваецца памяццю), абавязкова вызваліць гэту памяць, выкарыстоўваючы `from_raw_parts` для аднаўлення `Vec`, а потым скідаючы яго.
///
/// Калі `Vec` * мае выдзеленую памяць, памяць, на якую ён паказвае, знаходзіцца ў кучы (як вызначана размеркавальнікам Rust настроена на выкарыстанне па змаўчанні), а паказальнік паказвае на ініцыялізаваныя, сумежныя элементы па парадку (тое, што вы б паглядзіце, калі вы прымусілі яго зрабіць зрэз), а потым [`ёмістасць`]`,`[`len`], лагічна неініцыялізаваныя, сумежныя элементы.
///
///
/// vector, які змяшчае элементы `'a'` і `'b'` ёмістасцю 4, можна візуалізаваць, як паказана ніжэй.Верхняя частка-структура `Vec`, яна ўтрымлівае паказальнік на галоўку размеркавання ў кучы, даўжыню і ёмістасць.
/// Ніжняя частка-вылучэнне ў кучы, сумежны блок памяці.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** уяўляе сабой памяць, якая не ініцыялізуецца, гл. [`MaybeUninit`].
/// - Note: ABI не з'яўляецца стабільным, і `Vec` не дае ніякіх гарантый адносна размяшчэння памяці (уключаючы парадак палёў).
///
/// `Vec` ніколі не будзе выконваць "small optimization", калі элементы сапраўды захоўваюцца ў стэку па дзвюх прычынах:
///
/// * Гэта зробіць больш цяжкім для небяспечнага кода правільнае маніпуляванне `Vec`.Змест `Vec` не меў бы стабільнага адраса, калі б яго толькі перамяшчалі, і было б больш складана вызначыць, ці сапраўды `Vec` выдзяляў памяць.
///
/// * Гэта будзе караць агульны выпадак, ствараючы дадатковы branch пры кожным доступе.
///
/// `Vec` ніколі не зменшыцца аўтаматычна, нават калі ён цалкам пусты.Гэта гарантуе адсутнасць непатрэбных выдзяленняў і вызваленняў.Апарожненне `Vec` і яго запаўненне назад да таго ж [`len`] не павінны выклікаць выклікаў у размеркавальнік.Калі вы хочаце вызваліць нявыкарыстаную памяць, выкарыстоўвайце [`shrink_to_fit`] або [`shrink_to`].
///
/// [`push`] і [`insert`] ніколі не будзе (пера) выдзяляць, калі паведамленая ёмістасць дастатковая.[`push`] і [`insert`]*будуць*(пера) выдзяляць, калі [`len`]`==`[`ёмістасць`].Гэта значыць, зарэгістраваная ёмістасць цалкам дакладная, і на яе можна спадзявацца.Пры жаданні яго можна нават вызваліць памяць, выдзеленую `Vec`, уручную.
/// Масавыя метады ўстаўкі *могуць* пераразмеркаваць, нават калі гэта не трэба.
///
/// `Vec` не гарантуе якой-небудзь канкрэтнай стратэгіі росту пры пераразмеркаванні пры поўнай загрузцы і пры выкліку [`reserve`].Цяперашняя стратэгія з'яўляецца асноўнай, і можа апынуцца пажаданым выкарыстоўваць непастаянны фактар росту.Якая б стратэгія не выкарыстоўвалася, вядома, гарантуе *O*(1) амартызаваны [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` і [`Vec::with_capacity(n)`][`Vec::with_capacity`] вырабляюць `Vec` з дакладна запытанай магутнасцю.
/// Калі [`len`]`==`[`ёмістасць`], (як і ў выпадку з макрасам [`vec!`]), то `Vec<T>` можна пераўтварыць у і з [`Box<[T]>`][owned slice] без пераразмеркавання і перамяшчэння элементаў.
///
/// `Vec` не будзе спецыяльна перазапісваць любыя дадзеныя, якія з іх выдаляюцца, але таксама не будзе спецыяльна захоўваць іх.Неініцыялізаваная памяць-гэта месца для драпін, якое ён можа выкарыстоўваць, як хоча.Звычайна ён проста робіць усё, што найбольш эфектыўна альбо проста рэалізаваць.Не спадзявайцеся на выдаленне дадзеных, якія будуць выдалены ў мэтах бяспекі.
/// Нават калі вы выпусціце `Vec`, яго буфер можа быць проста выкарыстаны іншым `Vec`.
/// Нават калі вы спачатку абнуліце памяць `Vec`, гэта на самой справе можа не адбыцца, таму што аптымізатар не лічыць гэта пабочным эфектам, які неабходна захаваць.
/// Аднак ёсць адзін выпадак, які мы не парушым: выкарыстанне кода `unsafe` для запісу на лішнюю ёмістасць, а затым павелічэнне адпаведнасці даўжыні заўсёды дзейнічае.
///
/// У цяперашні час `Vec` не гарантуе парадак скідання элементаў.
/// Парадак змяняўся ў мінулым і можа змяніцца зноў.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Уласцівыя метады
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Канструюе новы, пусты `Vec<T>`.
    ///
    /// vector не вылучыць, пакуль на яго не будуць націснуты элементы.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Канструюе новы, пусты `Vec<T>` з зададзенай магутнасцю.
    ///
    /// vector зможа ўтрымліваць роўна элементы `capacity` без пераразмеркавання.
    /// Калі `capacity` роўны 0, vector не выдзяляе.
    ///
    /// Важна адзначыць, што нягледзячы на тое, што вернуты vector мае зададзеную *ёмістасць*, vector будзе мець нулявую *даўжыню*.
    ///
    /// Для тлумачэння розніцы паміж даўжынёй і ёмістасцю см.*[Ёмістасць і пераразмеркаванне]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector не ўтрымлівае прадметаў, хаця ў ім ёсць і больш
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Усё гэта робіцца без пераразмеркавання ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... але гэта можа зрабіць vector пераразмеркаваннем
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Стварае `Vec<T>` непасрэдна з неапрацаваных кампанентаў іншага vector.
    ///
    /// # Safety
    ///
    /// Гэта вельмі небяспечна з-за колькасці інварыянтаў, якія не правяраюцца:
    ///
    /// * `ptr` павінна быць папярэдне выдзелена праз [`String`]/`Vec<T>`(па меншай меры, вельмі верагодна, што гэта будзе няправільна, калі б не было).
    /// * `T` павінны мець такі ж памер і выраўноўванне, як і тое, з чым быў выдзелены `ptr`.
    ///   (`T` з менш строгім выраўноўваннем недастатковы, выраўноўванне сапраўды павінна быць роўным, каб задаволіць патрабаванне [`dealloc`] аб тым, што памяць павінна выдзяляцца і выводзіцца з аднолькавай кампаноўкай.)
    ///
    /// * `length` павінна быць менш або роўна `capacity`.
    /// * `capacity` павінна быць ёмістасцю, з якой быў прызначаны паказальнік.
    ///
    /// Парушэнне іх можа выклікаць такія праблемы, як пашкоджанне ўнутраных структур дадзеных размеркавальніка.Напрыклад,**не** бяспечна будаваць `Vec<u8>` з указальніка на масіў C `char` даўжынёй `size_t`.
    /// Акрамя таго, бяспечна будаваць адзін з `Vec<u16>` і яго даўжыню, таму што размеркавальнік клапоціцца пра выраўноўванне, і гэтыя два тыпы маюць розныя выраўноўванні.
    /// Буфер быў выдзелены з выраўноўваннем 2 (для `u16`), але пасля ператварэння яго ў `Vec<u8>` ён будзе вызвалены з выраўноўваннем 1.
    ///
    /// Права ўласнасці на `ptr` фактычна перадаецца `Vec<T>`, які можа потым вызваліць, пераразмеркаваць альбо змяніць змесціва памяці, на якую паказвае паказальнік па жаданні.
    /// Пераканайцеся, што нішто іншае не выкарыстоўвае паказальнік пасля выкліку гэтай функцыі.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Абнавіце гэта, калі vec_into_raw_parts стабілізуецца.
    ///     // Не дапускайце запуску дэструктара `v`, каб мы цалкам кантралявалі размеркаванне.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Дастаньце розныя важныя звесткі пра `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Перазапішыце памяць з 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Збярыце ўсё разам у Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Канструюе новы, пусты `Vec<T, A>`.
    ///
    /// vector не вылучыць, пакуль на яго не будуць націснуты элементы.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Канструюе новы, пусты `Vec<T, A>` з зададзенай ёмістасцю з прадастаўленым размеркавальнікам.
    ///
    /// vector зможа ўтрымліваць роўна элементы `capacity` без пераразмеркавання.
    /// Калі `capacity` роўны 0, vector не выдзяляе.
    ///
    /// Важна адзначыць, што нягледзячы на тое, што вернуты vector мае зададзеную *ёмістасць*, vector будзе мець нулявую *даўжыню*.
    ///
    /// Для тлумачэння розніцы паміж даўжынёй і ёмістасцю см.*[Ёмістасць і пераразмеркаванне]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector не ўтрымлівае прадметаў, хаця ў ім ёсць і больш
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Усё гэта робіцца без пераразмеркавання ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... але гэта можа зрабіць vector пераразмеркаваннем
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Стварае `Vec<T, A>` непасрэдна з неапрацаваных кампанентаў іншага vector.
    ///
    /// # Safety
    ///
    /// Гэта вельмі небяспечна з-за колькасці інварыянтаў, якія не правяраюцца:
    ///
    /// * `ptr` павінна быць папярэдне выдзелена праз [`String`]/`Vec<T>`(па меншай меры, вельмі верагодна, што гэта будзе няправільна, калі б не было).
    /// * `T` павінны мець такі ж памер і выраўноўванне, як і тое, з чым быў выдзелены `ptr`.
    ///   (`T` з менш строгім выраўноўваннем недастатковы, выраўноўванне сапраўды павінна быць роўным, каб задаволіць патрабаванне [`dealloc`] аб тым, што памяць павінна выдзяляцца і выводзіцца з аднолькавай кампаноўкай.)
    ///
    /// * `length` павінна быць менш або роўна `capacity`.
    /// * `capacity` павінна быць ёмістасцю, з якой быў прызначаны паказальнік.
    ///
    /// Парушэнне іх можа выклікаць такія праблемы, як пашкоджанне ўнутраных структур дадзеных размеркавальніка.Напрыклад,**не** бяспечна будаваць `Vec<u8>` з указальніка на масіў C `char` даўжынёй `size_t`.
    /// Акрамя таго, бяспечна будаваць адзін з `Vec<u16>` і яго даўжыню, таму што размеркавальнік клапоціцца пра выраўноўванне, і гэтыя два тыпы маюць розныя выраўноўванні.
    /// Буфер быў выдзелены з выраўноўваннем 2 (для `u16`), але пасля ператварэння яго ў `Vec<u8>` ён будзе вызвалены з выраўноўваннем 1.
    ///
    /// Права ўласнасці на `ptr` фактычна перадаецца `Vec<T>`, які можа потым вызваліць, пераразмеркаваць альбо змяніць змесціва памяці, на якую паказвае паказальнік па жаданні.
    /// Пераканайцеся, што нішто іншае не выкарыстоўвае паказальнік пасля выкліку гэтай функцыі.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Абнавіце гэта, калі vec_into_raw_parts стабілізуецца.
    ///     // Не дапускайце запуску дэструктара `v`, каб мы цалкам кантралявалі размеркаванне.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Дастаньце розныя важныя звесткі пра `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Перазапішыце памяць з 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Збярыце ўсё разам у Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Раскладае `Vec<T>` на сырыя кампаненты.
    ///
    /// Вяртае неапрацаваны паказальнік на базавыя дадзеныя, даўжыню vector (у элементах) і выдзеленую ёмістасць дадзеных (у элементах).
    /// Гэта тыя самыя аргументы ў тым жа парадку, што і аргументы [`from_raw_parts`].
    ///
    /// Пасля выкліку гэтай функцыі абанент адказвае за памяць, якой раней кіраваў `Vec`.
    /// Адзіны спосаб зрабіць гэта-пераўтварыць неапрацаваны паказальнік, даўжыню і ёмістасць назад у `Vec` з функцыяй [`from_raw_parts`], дазваляючы дэструктару выконваць ачыстку.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Цяпер мы можам уносіць змены ў кампаненты, напрыклад, пераводзіць неапрацаваны паказальнік у сумяшчальны тып.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Раскладае `Vec<T>` на сырыя кампаненты.
    ///
    /// Вяртае неапрацаваны паказальнік на базавыя дадзеныя, даўжыню vector (у элементах), размеркаваную ёмістасць дадзеных (у элементах) і размеркавальнік.
    /// Гэта тыя ж аргументы ў тым жа парадку, што і аргументы [`from_raw_parts_in`].
    ///
    /// Пасля выкліку гэтай функцыі абанент адказвае за памяць, якой раней кіраваў `Vec`.
    /// Адзіны спосаб зрабіць гэта-пераўтварыць неапрацаваны паказальнік, даўжыню і ёмістасць назад у `Vec` з функцыяй [`from_raw_parts_in`], дазваляючы дэструктару выконваць ачыстку.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Цяпер мы можам уносіць змены ў кампаненты, напрыклад, пераводзіць неапрацаваны паказальнік у сумяшчальны тып.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Вяртае колькасць элементаў, якія vector можа ўтрымліваць без пераразмеркавання.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Рэзервуе ёмістасць прынамсі для `additional`, каб у дадзены `Vec<T>` было ўстаўлена больш элементаў.
    /// Калекцыя можа зарэзерваваць больш месца, каб пазбегнуць частых пераразмеркаванняў.
    /// Пасля выкліку `reserve` ёмістасць будзе большай або роўнай `self.len() + additional`.
    /// Нічога не робіць, калі ёмістасці ўжо дастаткова.
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перавышае `isize::MAX` байт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Захоўвае мінімальную ёмістасць для роўна `additional`, каб дадатковыя элементы былі ўстаўлены ў дадзены `Vec<T>`.
    ///
    /// Пасля выкліку `reserve_exact` ёмістасць будзе большай або роўнай `self.len() + additional`.
    /// Нічога не робіць, калі магутнасці ўжо дастаткова.
    ///
    /// Звярніце ўвагу, што размеркавальнік можа даць калекцыі больш месца, чым ён просіць.
    /// Такім чынам, нельга разлічваць на ёмістасць як мінімум.
    /// Аддайце перавагу `reserve`, калі чакаецца ўстаўка future.
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перапаўняе `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Спрабуе захаваць ёмістасць як мінімум для `additional`, каб у дадзены `Vec<T>` было ўстаўлена больш элементаў.
    /// Калекцыя можа зарэзерваваць больш месца, каб пазбегнуць частых пераразмеркаванняў.
    /// Пасля выкліку `try_reserve` ёмістасць будзе большай або роўнай `self.len() + additional`.
    /// Нічога не робіць, калі ёмістасці ўжо дастаткова.
    ///
    /// # Errors
    ///
    /// Калі ёмістасць перапаўняецца альбо размеркавальнік паведамляе пра збой, вяртаецца памылка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Папярэдне зарэзервуйце памяць, выйшаўшы, калі мы не можам
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Цяпер мы ведаем, што гэта не можа OOM пасярод нашай складанай працы
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // вельмі складана
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Спрабуе зарэзерваваць мінімальную ёмістасць для дакладна ўстаўленых элементаў `additional` у дадзены `Vec<T>`.
    /// Пасля выкліку `try_reserve_exact` ёмістасць будзе большай або роўнай `self.len() + additional`, калі ён верне `Ok(())`.
    ///
    /// Нічога не робіць, калі магутнасці ўжо дастаткова.
    ///
    /// Звярніце ўвагу, што размеркавальнік можа даць калекцыі больш месца, чым ён просіць.
    /// Такім чынам, нельга разлічваць на ёмістасць як мінімум.
    /// Аддайце перавагу `reserve`, калі чакаецца ўстаўка future.
    ///
    /// # Errors
    ///
    /// Калі ёмістасць перапаўняецца альбо размеркавальнік паведамляе пра збой, вяртаецца памылка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Папярэдне зарэзервуйце памяць, выйшаўшы, калі мы не можам
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Цяпер мы ведаем, што гэта не можа OOM пасярод нашай складанай працы
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // вельмі складана
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Максімальна скарачае ёмістасць vector.
    ///
    /// Ён упадзе як мага бліжэй да даўжыні, але размеркавальнік усё яшчэ можа паведаміць vector, што ёсць месца яшчэ для некалькіх элементаў.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Ёмістасць ніколі не меншая за даўжыню, і няма чаго рабіць, калі яны роўныя, таму мы можам пазбегнуць выпадку panic у `RawVec::shrink_to_fit`, толькі выклікаючы яго з большай ёмістасцю.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Скарачаецца ёмістасць vector з ніжняй мяжой.
    ///
    /// Ёмістасць застанецца як мінімум роўнай як даўжыні, так і пастаўленай кошту.
    ///
    ///
    /// Калі бягучая ёмістасць менш ніжняй мяжы, гэта адмоўна.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Пераўтварае vector у [`Box<[T]>`][owned slice].
    ///
    /// Звярніце ўвагу, што гэта знізіць любую лішнюю магутнасць.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Любая лішняя ёмістасць выдаляецца:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Скарачае vector, захоўваючы першыя элементы `len` і скідаючы астатнія.
    ///
    /// Калі `len` перавышае бягучую даўжыню vector, гэта не ўплывае.
    ///
    /// Метад [`drain`] можа эмуляваць `truncate`, але прымушае лішнія элементы вяртаць, а не скідаць.
    ///
    ///
    /// Звярніце ўвагу, што гэты метад не ўплывае на размеркаваны патэнцыял vector.
    ///
    /// # Examples
    ///
    /// Скарачэнне пяці элементаў vector да двух элементаў:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Адсячэнне не адбываецца, калі `len` перавышае бягучую даўжыню vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Скарачэнне, калі `len == 0` эквівалентна выкліку метаду [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Гэта бяспечна, бо:
        //
        // * зрэз, перададзены `drop_in_place`, сапраўдны;справа `len > self.len` дазваляе пазбегнуць стварэння недапушчальнага зрэзу, і
        // * `len` vector памяншаецца перад выклікам `drop_in_place`, так што значэнне не будзе скінута двойчы, калі `drop_in_place` будзе адзін раз panic (калі panics двойчы, праграма спыняе).
        //
        //
        //
        unsafe {
            // Note: Наўмысна, што гэта `>`, а не `>=`.
            //       Змена яго на `>=` у некаторых выпадках мае негатыўныя наступствы для прадукцыйнасці.
            //       Больш падрабязна гл. #78884.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Здабывае зрэз, які змяшчае ўвесь vector.
    ///
    /// Эквівалентна `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Вымае зменлівы зрэз цэлага vector.
    ///
    /// Эквівалентна `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Вяртае неапрацаваны паказальнік на буфер vector.
    ///
    /// Абанент павінен пераканацца, што vector перажывае паказальнік, які гэтая функцыя вяртае, інакш ён у канчатковым выніку ўказвае на смецце.
    /// Мадыфікацыя vector можа прывесці да пераразмеркавання яго буфера, што таксама зробіць несапраўднымі любыя ўказальнікі на яго.
    ///
    /// Абанент таксама павінен пераканацца, што памяць, на якую паказвае паказальнік (non-transitively), ніколі не запісваецца (за выключэннем унутры `UnsafeCell`), выкарыстоўваючы гэты паказальнік альбо любы паказальнік, атрыманы з яго.
    /// Калі вам трэба змяніць змесціва зрэзу, выкарыстоўвайце [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Мы адцяняем аднайменны метад зрэзу, каб пазбегнуць праходжання `deref`, які стварае прамежкавую спасылку.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Вяртае небяспечны зменлівы паказальнік на буфер vector.
    ///
    /// Абанент павінен пераканацца, што vector перажывае паказальнік, які гэтая функцыя вяртае, інакш ён у канчатковым выніку ўказвае на смецце.
    ///
    /// Мадыфікацыя vector можа прывесці да пераразмеркавання яго буфера, што таксама зробіць несапраўднымі любыя ўказальнікі на яго.
    ///
    /// # Examples
    ///
    /// ```
    /// // Вылучыце vector досыць вялікі для 4 элементаў.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Ініцыялізуйце элементы з дапамогай неапрацаванага запісу паказальніка, затым задайце даўжыню.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Мы адцяняем аднайменны метад зрэзу, каб пазбегнуць праходжання `deref_mut`, які стварае прамежкавую спасылку.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Вяртае спасылку на асноўны размеркатар.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Прымушае даўжыню vector да `new_len`.
    ///
    /// Гэта аперацыя нізкага ўзроўню, якая не падтрымлівае ніводнага з нармальных інварыянтаў тыпу.
    /// Звычайна змяненне даўжыні vector вырабляецца з выкарыстаннем адной з бяспечных аперацый, напрыклад, [`truncate`], [`resize`], [`extend`] або [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` павінна быць менш або роўна [`capacity()`].
    /// - Элементы `old_len..new_len` павінны быць ініцыялізаваны.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Гэты метад можа быць карысны ў сітуацыях, калі vector служыць буферам для іншага кода, асабліва для FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Гэта ўсяго толькі мінімальны каркас для прыкладу дакумента;
    /// # // не выкарыстоўвайце гэта як адпраўную кропку для сапраўднай бібліятэкі.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Згодна з дакументамі метаду FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // БЯСПЕКА: Калі `deflateGetDictionary` вяртае `Z_OK`, ён лічыць, што:
    ///     // 1. `dict_length` элементы былі ініцыялізаваны.
    ///     // 2.
    ///     // `dict_length` <=ёмістасць (32_768), што робіць `set_len` бяспечным для выкліку.
    ///     unsafe {
    ///         // Зрабіце званок FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... і абнавіце даўжыню да ініцыялізаванай.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Хоць наступны прыклад з'яўляецца гукавым, уцечка памяці назіраецца, бо ўнутраныя vectors не вызваляліся да выкліку `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` пусты, таму не трэба ініцыялізаваць элементы.
    /// // 2. `0 <= capacity` заўсёды змяшчае любы `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Звычайна тут замест гэтага трэба выкарыстоўваць [`clear`], каб правільна апусціць змесціва і, такім чынам, не ўцечкі памяці.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Выдаляе элемент з vector і вяртае яго.
    ///
    /// Выдалены элемент замяняецца апошнім элементам vector.
    ///
    /// Гэта не дазваляе захаваць парадак, але гэта O(1).
    ///
    /// # Panics
    ///
    /// Panics, калі `index` па-за межамі.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Мы замяняем self [index] апошнім элементам.
            // Звярніце ўвагу, што калі праверка межаў атрымаецца вышэй, павінен быць апошні элемент (які можа быць уласным [індэксам]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Устаўляе элемент у становішчы `index` у vector, ссоўваючы ўсе элементы пасля яго направа.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // месца для новага элемента
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // беспамылкова Пляма, каб паставіць новае значэнне
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Перанясіце ўсё, каб вызваліць месца.
                // (Дублюючы элемент `index` на два месцы запар.)
                ptr::copy(p, p.offset(1), len - index);
                // Запішыце гэта, перазапісаўшы першую копію элемента `index`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Выдаляе і вяртае элемент у становішчы `index` у межах vector, ссоўваючы ўсе элементы пасля яго ўлева.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `index` па-за межамі.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // месца, з якога мы бярэмся.
                let ptr = self.as_mut_ptr().add(index);
                // скапіруйце яго, небяспечна маючы адначасова копію значэння ў стэку і ў vector.
                //
                ret = ptr::read(ptr);

                // Зрушыце ўсё ўніз, каб запоўніць гэтае месца.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Захоўвае толькі элементы, указаныя прэдыкатам.
    ///
    /// Іншымі словамі, выдаліце ўсе элементы `e` так, каб `f(&e)` вярнуў `false`.
    /// Гэты метад дзейнічае на месцы, наведваючы кожны элемент роўна адзін раз у зыходным парадку, і захоўвае парадак захаваных элементаў.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Паколькі элементы наведваюцца роўна адзін раз у першапачатковым парадку, знешні стан можа быць выкарыстаны для вырашэння, якія элементы захоўваць.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Пазбягайце падвойнага падзення, калі засцерагальнік не выкананы, бо падчас працэсу мы можам зрабіць дзіркі.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-апрацаваны лен-> |^-побач з праверкай
        //                  | <-выдалены cnt-> |
        //      | <-арыгінал_лен-> |Захоўваецца: Элементы, прэдыкат якіх вяртае true.
        //
        // Адтуліна: Перамешчаны альбо ўпушчаны слот элемента.
        // Неправеранае: Неправераныя сапраўдныя элементы.
        //
        // Гэта абарона ад падзення будзе выклікана, калі прэдыкат альбо `drop` элемента запанікаюць.
        // Ён ссоўвае неправераныя элементы, каб закрыць адтуліны і `set_len`, на патрэбную даўжыню.
        // У выпадках, калі предикат і `drop` ніколі не ўпадаюць у паніку, яны будуць аптымізаваны.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // БЯСПЕКА: Адставанне неправераных элементаў павінна быць сапраўдным, бо мы ніколі не дакранаемся да іх.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // БЯСПЕКА: Пасля запаўнення дзірак усе прадметы знаходзяцца ў сумежнай памяці.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // БЯСПЕКА: Неправераны элемент павінен быць сапраўдным.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Рана загадзя, каб пазбегнуць падвойнага падзення, калі `drop_in_place` запанікуе.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // БЯСПЕКА: Мы больш ніколі не дакранаемся да гэтага элемента пасля падзення.
                unsafe { ptr::drop_in_place(cur) };
                // Мы ўжо прасунулі лічыльнік.
                continue;
            }
            if g.deleted_cnt > 0 {
                // БЯСПЕКА: `deleted_cnt`> 0, таму шчыліна адтуліны не павінна перакрывацца бягучым элементам.
                // Мы выкарыстоўваем копію для перамяшчэння і больш ніколі не дакранаемся да гэтага элемента.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Усе дэталі апрацоўваюцца.Гэта можа быць аптымізавана да ўзроўню `set_len` з дапамогай LLVM.
        drop(g);
    }

    /// Выдаляе ўсе паслядоўныя элементы ў vector, акрамя першага, якія вырашаюцца на адзін і той жа ключ.
    ///
    ///
    /// Калі vector адсартавана, гэта выдаляе ўсе дублікаты.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Выдаляе ўсе паслядоўныя элементы, акрамя першага, у vector, якія задавальняюць зададзенаму суадносінам роўнасці.
    ///
    /// У функцыю `same_bucket` перадаюцца спасылкі на два элементы з vector і яна павінна вызначыць, калі элементы параўноўваюцца роўнымі.
    /// Элементы перадаюцца ў парадку, процілеглым парадку ў зрэзе, таму, калі `same_bucket(a, b)` вяртае `true`, `a` выдаляецца.
    ///
    ///
    /// Калі vector адсартавана, гэта выдаляе ўсе дублікаты.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Дадае элемент на адваротны бок калекцыі.
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перавышае `isize::MAX` байт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Гэта прывядзе да panic альбо да спынення, калі мы выдзелім> isize::MAX байтаў альбо калі павелічэнне даўжыні будзе перапаўнена для нулявых тыпаў.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Выдаляе апошні элемент з vector і вяртае яго, альбо [`None`], калі ён пусты.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Перамяшчае ўсе элементы `other` у `Self`, пакідаючы `other` пустым.
    ///
    /// # Panics
    ///
    /// Panics, калі колькасць элементаў у vector перавышае `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Дадае элементы ў `Self` з іншага буфера.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Стварае зліўны ітэратар, які выдаляе зададзены дыяпазон у vector і дае выдаленыя элементы.
    ///
    /// Калі ітэратар **апускаецца**, усе элементы ў дыяпазоне выдаляюцца з vector, нават калі ітэратар быў выкарыстаны не цалкам.
    /// Калі ітэратар **не ўпушчаны**(напрыклад, з [`mem::forget`]), не ўдакладняецца, колькі элементаў выдаляецца.
    ///
    /// # Panics
    ///
    /// Panics, калі пачатковая кропка большая за канчатковую кропку альбо калі канчатковая кропка большая за даўжыню vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Поўны спектр ачышчае vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Бяспека памяці
        //
        // Калі Drain ствараецца ўпершыню, ён скарачае даўжыню зыходнага vector, каб пераканацца, што неініцыялізаваныя элементы альбо элементы, якія перамяшчаюцца, наогул даступныя, калі дэструктар Drain ніколі не запусціцца.
        //
        //
        // Drain выдасць ptr::read значэнні для выдалення.
        // Пасля завяршэння астатні хвост века капіруецца назад, каб закрыць адтуліну, і даўжыня vector аднаўляецца да новай даўжыні.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // усталюйце для пачатку даўжыню self.vec, каб быць бяспечным у выпадку ўцечкі Drain
            self.set_len(start);
            // Выкарыстоўвайце запазычанне ў IterMut, каб паказаць паводзіны запазычання ўсяго ітэратара Drain (напрыклад, &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Ачышчае vector, выдаляючы ўсе значэнні.
    ///
    /// Звярніце ўвагу, што гэты метад не ўплывае на размеркаваны патэнцыял vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Вяртае колькасць элементаў у vector, які таксама называюць яго 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Вяртае `true`, калі vector не ўтрымлівае элементаў.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Разбівае калекцыю на дзве часткі па зададзеным індэксе.
    ///
    /// Вяртае нядаўна выдзелены vector, які змяшчае элементы ў дыяпазоне `[at, len)`.
    /// Пасля званка застанецца зыходны vector, які змяшчае элементы `[0, at)` з нязменнай папярэдняй ёмістасцю.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // новы vector можа пераняць арыгінальны буфер і пазбегнуць капіравання
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Небяспечна `set_len` і капіюйце элементы ў `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Змяняе памер `Vec` на месцы так, каб `len` быў роўны `new_len`.
    ///
    /// Калі `new_len` больш, чым `len`, `Vec` павялічваецца на розніцу, пры гэтым кожны дадатковы слот запаўняецца ў выніку выкліку закрыцця `f`.
    ///
    /// Зваротныя значэнні ад `f` апынуцца ў `Vec` у тым парадку, у якім былі створаны.
    ///
    /// Калі `new_len` менш, чым `len`, `Vec` проста зрэзаны.
    ///
    /// Гэты метад выкарыстоўвае закрыццё для стварэння новых значэнняў пры кожным націску.Калі вы аддаеце перавагу [`Clone`] зададзенага значэння, выкарыстоўвайце [`Vec::resize`].
    /// Калі вы хочаце выкарыстоўваць [`Default`] Portrait для генерацыі значэнняў, вы можаце перадаць [`Default::default`] у якасці другога аргумента.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Спажывае і ўцекае `Vec`, вяртаючы зменлівую спасылку на змест, `&'a mut [T]`.
    /// Звярніце ўвагу, што тып `T` павінен перажыць абраны тэрмін службы `'a`.
    /// Калі тып мае толькі статычныя спасылкі, альбо ўвогуле няма, гэта можа быць абраны `'static`.
    ///
    /// Гэтая функцыя аналагічная функцыі [`leak`][Box::leak] на [`Box`], за выключэннем таго, што няма магчымасці аднавіць уцечку памяці.
    ///
    ///
    /// Гэтая функцыя ў асноўным карысная для дадзеных, якія жывуць да канца жыцця праграмы.
    /// Кіданне вернутай спасылкі прывядзе да ўцечкі памяці.
    ///
    /// # Examples
    ///
    /// Простае выкарыстанне:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Вяртае астатнюю свабодную ёмістасць vector як зрэз `MaybeUninit<T>`.
    ///
    /// Вярнуты зрэз можна выкарыстоўваць для запаўнення vector дадзенымі (напрыклад,
    /// чытаннем з файла) перад пазначаннем дадзеных як ініцыялізаваных метадам [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Вылучыце vector досыць вялікі для 10 элементаў.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Запоўніце першыя 3 элементы.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Адзначыць першыя 3 элементы vector як ініцыялізаваныя.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Гэты метад не рэалізаваны з пункту гледжання `split_at_spare_mut`, каб прадухіліць несапраўднасць паказальнікаў на буфер.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Вяртае змест vector як зрэз `T`, а таксама астатнюю свабодную ёмістасць vector як зрэз `MaybeUninit<T>`.
    ///
    /// Вярнуты зрэз свабоднай ёмістасці можа быць выкарыстаны для запаўнення vector дадзенымі (напрыклад, чытаннем з файла) перад пазначаннем дадзеных як ініцыялізаваных метадам [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Звярніце ўвагу, што гэта API нізкага ўзроўню, які трэба з асцярожнасцю выкарыстоўваць для аптымізацыі.
    /// Калі вам трэба дадаць дадзеныя ў `Vec`, вы можаце выкарыстоўваць [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] або [`resize_with`], у залежнасці ад вашых дакладных патрэб.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Забяспечце дадатковае месца, досыць вялікае для 10 элементаў.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Запоўніце наступныя 4 элементы.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Адзначце 4 элементы vector як ініцыялізаваныя.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ігнаруецца і таму ніколі не мяняецца
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Бяспека: змена вернутага .2 (&mut usize) лічыцца такім жа, як выклік `.set_len(_)`.
    ///
    /// Гэты метад выкарыстоўваецца для атрымання унікальнага доступу да ўсіх частак vec адначасова ў `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` гарантавана дзейнічае для элементаў `len`
        // - `spare_ptr` накіроўвае адзін элемент міма буфера, каб ён не перакрываўся з `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Змяняе памер `Vec` на месцы так, каб `len` быў роўны `new_len`.
    ///
    /// Калі `new_len` больш, чым `len`, `Vec` павялічваецца на розніцу, з кожным дадатковым слотам, запоўненым `value`.
    ///
    /// Калі `new_len` менш, чым `len`, `Vec` проста зрэзаны.
    ///
    /// Гэты метад патрабуе `T` для рэалізацыі [`Clone`], каб мець магчымасць кланаваць перададзенае значэнне.
    /// Калі вам патрэбна большая гнуткасць (альбо вы хочаце спадзявацца на [`Default`] замест [`Clone`]), выкарыстоўвайце [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Клануе і дадае ўсе элементы зрэзу да `Vec`.
    ///
    /// Узаемадзейнічае па зрэзе `other`, кланіруе кожны элемент, а затым дадае яго да гэтага `Vec`.
    /// `other` vector перамяшчаецца ў парадку.
    ///
    /// Звярніце ўвагу, што гэтая функцыя такая ж, як і [`extend`], за выключэннем таго, што яна спецыялізуецца на працы з фрагментамі.
    ///
    /// Калі і калі Rust атрымае спецыялізацыю, гэтая функцыя, хутчэй за ўсё, састарэе (але ўсё яшчэ даступная).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Капіруе элементы ад дыяпазону `src` да канца vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` гарантуе, што дадзены дыяпазон сапраўдны для самастойнага індэксавання
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Гэты код абагульняе `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Пашырце vector на значэнні `n`, выкарыстоўваючы дадзены генератар.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Выкарыстоўвайце SetLenOnDrop для абыходжання з памылкамі, калі кампілятар можа не зразумець, што сховішча праз `ptr` па self.set_len() не псеўданім.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Запішыце ўсе элементы, акрамя апошняга
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Павялічвайце даўжыню на кожным этапе ў выпадку next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Мы можам напісаць апошні элемент непасрэдна, без неабходнасці кланавання
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // лен усталяваны аховай прыцэла
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Выдаляе паслядоўныя паўтараюцца элементы ў vector у адпаведнасці з рэалізацыяй [`PartialEq`] Portrait.
    ///
    ///
    /// Калі vector адсартавана, гэта выдаляе ўсе дублікаты.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Унутраныя метады і функцыі
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` павінен быць сапраўдным індэксам
    /// - `self.capacity() - self.len()` павінна быць `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len павялічваецца толькі пасля ініцыялізацыі элементаў
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - абанент гарантуе, што src з'яўляецца сапраўдным індэксам
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Элемент толькі што быў ініцыялізаваны з `MaybeUninit::write`, таму можна павялічыць аб'ём
            // - len павялічваецца пасля кожнага элемента для прадухілення ўцечак (гл. выпуск #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - абанент гарантуе, што `src` з'яўляецца сапраўдным індэксам
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Абодва паказальнікі створаны з унікальных спасылак на зрэзы (`&mut [_]`), таму яны сапраўдныя і не перакрываюцца.
            //
            // - Элементы: Капіяваць, таму можна капіяваць іх, нічога не робячы з арыгінальнымі значэннямі
            // - `count` роўна аб'ектыву `source`, таму крыніца сапраўдны для чытання `count`
            // - `.reserve(count)` гарантуе, што `spare.len() >= count` настолькі запасны дзейнічае для запісаў `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Элементы былі толькі ініцыялізаваны `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Агульныя рэалізацыі Portrait для Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): з cfg(test) уласцівы метад `[T]::to_vec`, неабходны для вызначэння гэтага метаду, недаступны.
    // Замест гэтага выкарыстоўвайце функцыю `slice::to_vec`, якая даступная толькі з cfg(test) NB. Глядзіце модуль slice::hack у slice.rs для атрымання дадатковай інфармацыі
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // кіньце ўсё, што не будзе перазапісана
        self.truncate(other.len());

        // self.len <= other.len з-за ўсечанага круга, таму зрэзы тут заўсёды ў межах.
        //
        let (init, tail) = other.split_at(self.len());

        // паўторна выкарыстоўваць змешчаныя значэнні allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Стварае спажывальны ітэратар, гэта значыць той, які перамяшчае кожнае значэнне з vector (ад пачатку да канца).
    /// vector нельга выкарыстоўваць пасля выкліку гэтага.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s мае тып String, а не &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // ліставы метад, да якога дэлегуюць розныя рэалізацыі SpecFrom/SpecExtend, калі яны не маюць патрэбы ў дадатковай аптымізацыі
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Гэта тычыцца агульнага ітэратара.
        //
        // Гэтая функцыя павінна быць маральным эквівалентам:
        //
        //      для элемента ў ітэратары {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB не можа перапоўніцца, бо нам прыйшлося б вылучыць адрасную прастору
                self.set_len(len + 1);
            }
        }
    }

    /// Стварае ітэратар зрошчвання, які замяняе зададзены дыяпазон у vector дадзеным ітэратарам `replace_with` і дае выдаленыя элементы.
    ///
    /// `replace_with` не павінна быць такой жа даўжыні, як `range`.
    ///
    /// `range` выдаляецца, нават калі ітэратар не выкарыстоўваецца да канца.
    ///
    /// Невядома, колькі элементаў выдаляецца з vector, калі значэнне `Splice` прасочваецца.
    ///
    /// Уваходны ітэратар `replace_with` спажываецца толькі пры падзенні значэння `Splice`.
    ///
    /// Гэта аптымальна, калі:
    ///
    /// * Хвост (элементы ў vector пасля `range`) пусты,
    /// * альбо `replace_with` дае менш альбо роўных элементаў, чым даўжыня "дыяпазону"
    /// * альбо ніжняя мяжа `size_hint()` дакладная.
    ///
    /// У адваротным выпадку вылучаецца часовы vector, а хвост перамяшчаецца двойчы.
    ///
    /// # Panics
    ///
    /// Panics, калі пачатковая кропка большая за канчатковую кропку альбо калі канчатковая кропка большая за даўжыню vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Стварае ітэратар, які выкарыстоўвае закрыццё, каб вызначыць, ці трэба выдаляць элемент.
    ///
    /// Калі закрыццё вяртае ісціну, элемент выдаляецца і выдаецца.
    /// Калі закрыццё вяртае false, элемент застанецца ў vector і ітэратар не выдасць яго.
    ///
    /// Выкарыстанне гэтага метаду эквівалентна наступнаму коду:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ваш код тут
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Але `drain_filter` прасцей у выкарыстанні.
    /// `drain_filter` таксама больш эфектыўны, паколькі можа масава перамяшчаць элементы масіва.
    ///
    /// Звярніце ўвагу, што `drain_filter` таксама дазваляе мутаваць кожны элемент у закрыцці фільтра, незалежна ад таго, захацелі вы яго выдаліць.
    ///
    ///
    /// # Examples
    ///
    /// Разбіццё масіва на няроўныя і каэфіцыенты, паўторнае выкарыстанне зыходнага размеркавання:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Засцерагайцеся ад таго, каб мы не прасачыліся
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Пашырце рэалізацыю, якая капіруе элементы са спасылак, перш чым перасоўваць іх на Vec.
///
/// Гэтая рэалізацыя спецыялізавана для ітэратараў зрэзаў, дзе яна выкарыстоўвае [`copy_from_slice`] для дадання цэлага зрэзу адначасова.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Рэалізуе параўнанне vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Рэалізуе ўпарадкаванне vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // выкарыстаць падзенне для [T] выкарыстоўваць зыходны зрэз для абазначэння элементаў vector як найбольш слабага неабходнага тыпу;
            //
            // можа пазбегнуць пытанняў аб сапраўднасці ў пэўных выпадках
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec апрацоўвае вызваленне
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Стварае пусты `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: тэст уцягвае libstd, што тут выклікае памылкі
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: тэст уцягвае libstd, што тут выклікае памылкі
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Атрымлівае ўвесь змест `Vec<T>` у выглядзе масіва, калі яго памер дакладна адпавядае памеру запытанага масіва.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Калі даўжыня не супадае, увод вяртаецца ў `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Калі вы проста атрымліваеце прэфікс `Vec<T>`, спачатку вы можаце патэлефанаваць у [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // БЯСПЕКА: `.set_len(0)`-гэта заўсёды гук.
        unsafe { vec.set_len(0) };

        // БЯСПЕКА: паказальнік `Vec` заўсёды правільна выраўнаваны, і
        // выраўноўванне, неабходнае масіву, такое ж, як і элементаў.
        // Раней мы праверылі, ці дастаткова ў нас прадметаў.
        // Элементы не будуць падавацца ўдвая, бо `set_len` кажа `Vec`, каб таксама не скідваў іх.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}