// Усталюйце даўжыню vec, калі значэнне `SetLenOnDrop` выходзіць за рамкі.
//
// Ідэя заключаецца ў тым, што поле даўжыні ў SetLenOnDrop-гэта лакальная зменная, якую аптымізатар убачыць, не з'яўляецца псеўданімам любых крам праз паказальнік дадзеных Vec.
// Гэта абыходны шлях для аналізу псеўданіма #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}