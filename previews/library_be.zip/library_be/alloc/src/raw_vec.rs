#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Змест новай памяці неініцыялізаваны.
    Uninitialized,
    /// Новая памяць гарантавана будзе абнулена.
    Zeroed,
}

/// Утыліта нізкага ўзроўню для больш эрганамічнага размеркавання, пераразмеркавання і выдзялення буфера памяці ў кучы без неабходнасці турбавацца аб усіх кутовых выпадках.
///
/// Гэты тып выдатна падыходзіць для стварэння ўласных структур дадзеных, такіх як Vec і VecDeque.
/// У прыватнасці:
///
/// * Выпускае `Unique::dangling()` на нулявых тыпах.
/// * Вырабляе `Unique::dangling()` на размеркаваннях нулявой даўжыні.
/// * Пазбягае вызвалення `Unique::dangling()`.
/// * Лавіць усе перапаўненні ў разліках ёмістасці (павышае іх да "capacity overflow" panics).
/// * Засцерагае ад 32-бітных сістэм, якія выдзяляюць больш за isize::MAX байт.
/// * Засцерагае ад перапаўнення вашай даўжыні.
/// * Выклікае `handle_alloc_error` для памылковага размеркавання.
/// * Змяшчае `ptr::Unique` і, такім чынам, надзяляе карыстальніка ўсімі адпаведнымі перавагамі.
/// * Выкарыстоўвае лішак, які вяртаецца з размеркавальніка, для выкарыстання самай вялікай даступнай магутнасці.
///
/// Гэты тып у любым выпадку не правярае памяць, якой кіруе.Пры падзенні *вызваляе* памяць, але *не будзе* спрабаваць выдаліць яго змесціва.
/// Карыстальнік `RawVec` павінен апрацоўваць фактычныя рэчы, якія захоўваюцца ў `RawVec`.
///
/// Звярніце ўвагу, што лішак нулявога тыпу заўсёды бясконцы, таму `capacity()` заўсёды вяртае `usize::MAX`.
/// Гэта азначае, што трэба быць асцярожным, калі вы спрацоўваеце гэты тып з `Box<[T]>`, бо `capacity()` не дасць даўжыні.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Гэта існуе, таму што `#[unstable]` `const fn`s не павінны адпавядаць `min_const_fn`, таму іх нельга выклікаць у`min_const_fn`s.
    ///
    /// Калі вы змяняеце `RawVec<T>::new` альбо залежнасці, пераканайцеся, што не ўводзіце нічога, што сапраўды парушае `min_const_fn`.
    ///
    /// NOTE: Мы маглі б пазбегнуць гэтага ўзлому і праверыць адпаведнасць з якім-небудзь атрыбутам `#[rustc_force_min_const_fn]`, які патрабуе адпаведнасці з `min_const_fn`, але не абавязкова дазваляе выклікаць яго ў `stable(...) const fn`/код карыстальніка, які не дазваляе `foo`, калі `#[rustc_const_unstable(feature = "foo", issue = "01234")]` прысутнічае.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Стварае максімальна магчымы `RawVec` (у сістэмнай кучы) без выдзялення.
    /// Калі `T` мае станоўчы памер, гэта робіць `RawVec` ёмістасцю `0`.
    /// Калі `T` нулявога памеру, то гэта `RawVec` ёмістасцю `usize::MAX`.
    /// Карысна для рэалізацыі адкладзенага размеркавання.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Стварае `RawVec` (у сістэмнай кучы) з дакладнай ёмістасцю і патрабаваннямі да выраўноўвання для `[T; capacity]`.
    /// Гэта эквівалентна выкліку `RawVec::new`, калі `capacity`-гэта `0` альбо `T`-нулявога памеру.
    /// Звярніце ўвагу, што калі `T` нулявога памеру, гэта азначае, што вы не атрымаеце `RawVec` з патрабаванай ёмістасцю.
    ///
    /// # Panics
    ///
    /// Panics, калі запытаная ёмістасць перавышае `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Аборты на OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Як і `with_capacity`, але гарантуе, што буфер абнулены.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Аднаўляе `RawVec` з паказальніка і ёмістасці.
    ///
    /// # Safety
    ///
    /// `ptr` павінен быць выдзелены (у сістэмнай кучы) і з дадзеным `capacity`.
    /// `capacity` не можа перавышаць `isize::MAX` для тыпаразмераў.(хвалюе толькі 32-разрадныя сістэмы).
    /// ZST vectors можа мець ёмістасць да `usize::MAX`.
    /// Калі `ptr` і `capacity` паходзяць ад `RawVec`, то гэта гарантавана.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Малюсенькія векі-нямыя.Перайсці да:
    // - 8, калі памер элемента роўны 1, таму што любы размеркавальнік кучы, хутчэй за ўсё, можа акругляць запыт меншым за 8 байт прынамсі да 8 байтаў.
    //
    // - 4, калі элементы ўмеранага памеру (<=1 КіБ).
    // - 1 у адваротным выпадку, каб пазбегнуць страты занадта шмат месца на вельмі кароткіх веках.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Як і `new`, але параметрызаваны пры выбары размеркавальніка для вернутага `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` азначае "unallocated".нулявыя тыпы ігнаруюцца.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Як і `with_capacity`, але параметрызаваны пры выбары размеркавальніка для вернутага `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Як і `with_capacity_zeroed`, але параметрызаваны пры выбары размеркавальніка для вернутага `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Пераўтварае `Box<[T]>` у `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Пераўтварае ўвесь буфер у `Box<[MaybeUninit<T>]>` з указаным `len`.
    ///
    /// Звярніце ўвагу, што гэта дазволіць правільна аднавіць любыя змены `cap`, якія маглі быць унесены.(Больш падрабязна гл. Апісанне тыпу.)
    ///
    /// # Safety
    ///
    /// * `len` павінна быць большай або роўнай самай нядаўна запытанай ёмістасці, і
    /// * `len` павінна быць менш або роўна `self.capacity()`.
    ///
    /// Звярніце ўвагу, што запытаная ёмістасць і `self.capacity()` могуць адрознівацца, паколькі размеркавальнік можа пераразмеркаваць і вярнуць большы блок памяці, чым запытваецца.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Разумнасць-праверыць палову патрабаванняў бяспекі (другую палову мы не можам праверыць).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Тут мы пазбягаем `unwrap_or_else`, таму што ён перакрывае колькасць генеруемага ВК LLVM.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Аднаўляе `RawVec` з паказальніка, ёмістасці і размеркавальніка.
    ///
    /// # Safety
    ///
    /// `ptr` неабходна вылучыць (праз дадзены размеркатар `alloc`) і з дадзеным `capacity`.
    /// `capacity` не можа перавышаць `isize::MAX` для тыпаразмераў.
    /// (хвалюе толькі 32-разрадныя сістэмы).
    /// ZST vectors можа мець ёмістасць да `usize::MAX`.
    /// Калі `ptr` і `capacity` паходзяць з `RawVec`, створанага праз `alloc`, гэта гарантавана.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Атрымлівае неапрацаваны паказальнік на пачатак выдзялення.
    /// Звярніце ўвагу, што гэта `Unique::dangling()`, калі `capacity == 0` або `T` маюць нулявы памер.
    /// У першым выпадку трэба быць асцярожным.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Атрымлівае магутнасць выдзялення.
    ///
    /// Гэта заўсёды будзе `usize::MAX`, калі `T` нулявога памеру.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Вяртае агульную спасылку на размеркавальнік, які падтрымлівае гэты `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // У нас выдзелены кавалак памяці, таму мы можам абысці праверкі падчас выканання, каб атрымаць наш бягучы макет.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Гарантуе, што буфер змяшчае хаця б дастаткова месца для ўтрымання элементаў `len + additional`.
    /// Калі ў яго яшчэ няма дастатковай ёмістасці, будзе пераразмеркавана дастатковую колькасць месца плюс зручнае слабае месца, каб атрымаць амартызаванае паводзіны *O*(1).
    ///
    /// Абмяжуе гэта паводзіны, калі яно без патрэбы прывядзе да panic.
    ///
    /// Калі `len` перавышае `self.capacity()`, гэта можа прывесці да няздольнасці размеркаваць запытаную прастору.
    /// Гэта на самай справе не небяспечна, але небяспечны код *, які вы пішаце і які абапіраецца на паводзіны гэтай функцыі, можа зламацца.
    ///
    /// Гэта ідэальна для рэалізацыі аперацыі масавага націскання, як `extend`.
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перавышае `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Аборты на OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // рэзерв спыніў бы сябе ці запанікаваў, калі б аб'ектыў перавышаў `isize::MAX`, таму зараз гэта немагчыма зрабіць неправераным.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Тое ж самае, што і `reserve`, але вяртае памылкі замест таго, каб панікаваць альбо перапыняць працу.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Гарантуе, што буфер змяшчае хаця б дастаткова месца для ўтрымання элементаў `len + additional`.
    /// Калі гэтага яшчэ не адбылося, будзе пераразмеркаваны мінімальна магчымы аб'ём неабходнай памяці.
    /// Звычайна гэта будзе менавіта той аб'ём неабходнай памяці, але ў прынцыпе размеркавальнік можа вярнуць больш, чым мы прасілі.
    ///
    ///
    /// Калі `len` перавышае `self.capacity()`, гэта можа прывесці да няздольнасці размеркаваць запытаную прастору.
    /// Гэта на самай справе не небяспечна, але небяспечны код *, які вы пішаце і які абапіраецца на паводзіны гэтай функцыі, можа зламацца.
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перавышае `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Аборты на OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Тое ж самае, што і `reserve_exact`, але вяртае памылкі замест таго, каб панікаваць альбо перапыняць працу.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Сцягвае размеркаванне да зададзенай сумы.
    /// Калі дадзеная сума роўная 0, фактычна цалкам вызваляецца.
    ///
    /// # Panics
    ///
    /// Panics, калі дадзеная сума *большая*, чым бягучая ёмістасць.
    ///
    /// # Aborts
    ///
    /// Аборты на OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Вяртае, калі буфер павінен расці, каб выканаць неабходную дадатковую ёмістасць.
    /// У асноўным выкарыстоўваецца для ўключэння рэзервовых выклікаў без уключэння `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Звычайна гэты метад узнікае шмат разоў.Таму мы хочам, каб гэта было як мага менш, каб палепшыць час кампіляцыі.
    // Але мы таксама хочам, каб як мага большая частка яго зместу была статычна вылічальнай, каб згенераваны код працаваў хутчэй.
    // Такім чынам, гэты метад старанна напісаны, каб увесь код, які залежыць ад `T`, быў у ім, у той час як як мага большая частка кода, які не залежыць ад `T`, была ў функцыях, якія не з'яўляюцца агульнымі для `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Гэта забяспечваецца выклікаючым кантэкстам.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Так як мы вяртаем ёмістасць `usize::MAX`, калі `elem_size` ёсць
            // 0, дабрацца сюды абавязкова азначае, што `RawVec` перапоўнены.
            return Err(CapacityOverflow);
        }

        // На жаль, мы нічога не можам зрабіць з гэтымі праверкамі.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Гэта гарантуе экспанентны рост.
        // Падваенне не можа пераліцца, таму што `cap <= isize::MAX` і тып `cap`-гэта `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не з'яўляецца агульным у параўнанні з `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Абмежаванні для гэтага метаду практычна такія ж, як і для `grow_amortized`, але гэты метад звычайна ўзнікае радзей, таму ён менш крытычны.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Так як мы вяртаем ёмістасць `usize::MAX`, калі памер тыпу
            // 0, дабрацца сюды абавязкова азначае, што `RawVec` перапоўнены.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не з'яўляецца агульным у параўнанні з `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Гэта функцыя знаходзіцца па-за межамі `RawVec`, каб мінімізаваць час кампіляцыі.Больш падрабязна глядзіце каментарый вышэй `RawVec::grow_amortized`.
// (Параметр `A` не мае значнага значэння, паколькі колькасць розных тыпаў `A`, якія назіраюцца на практыцы, значна меншая, чым колькасць тыпаў `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Праверце памылку тут, каб мінімізаваць памер `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Размеркавальнік правярае роўнасць выраўноўвання
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Вызваляе памяць, якая належыць `RawVec` *, не спрабуючы выдаліць яе змесціва.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Цэнтральная функцыя для апрацоўкі рэзервовых памылак.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Мы павінны гарантаваць наступнае:
// * Мы ніколі не выдзяляем аб'екты памерам байт `> isize::MAX`.
// * Мы не перапаўняем `usize::MAX` і фактычна выдзяляем занадта мала.
//
// На 64-разраднай нам проста трэба праверыць наяўнасць перапаўнення, бо спроба вылучыць байты `> isize::MAX` напэўна не атрымаецца.
// На 32-разраднай і 16-разраднай нам трэба дадаць дадатковую ахову для гэтага, калі мы працуем на платформе, якая можа выкарыстоўваць усе 4 Гб у карыстацкай прасторы, напрыклад, PAE або x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Адна цэнтральная функцыя, якая адказвае за перапаўненне магутнасці справаздачнасці.
// Гэта забяспечыць мінімальную генерацыю кода, звязаную з гэтымі panics, паколькі ёсць толькі адно месца, якое panics, а не куча па ўсім модулі.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}