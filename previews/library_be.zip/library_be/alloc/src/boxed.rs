//! Тып паказальніка для размеркавання кучы.
//!
//! [`Box<T>`], выпадкова званы 'box', забяспечвае найпростую форму размеркавання кучы ў Rust.Скрынкі забяспечваюць права ўласнасці на гэта размеркаванне і выдаляюць іх змест, калі яны выходзяць з-за межы прымянення.Скрынкі таксама гарантуюць, што яны ніколі не выдзяляюць больш за байт `isize::MAX`.
//!
//! # Examples
//!
//! Перамясціце значэнне са стэка ў кучу, стварыўшы [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Перамясціце значэнне з [`Box`] назад у стэк па [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Стварэнне рэкурсіўнай структуры дадзеных:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Пры гэтым будзе надрукавана `Cons (1, Cons(2, Nil))`.
//!
//! Рэкурсіўныя структуры павінны быць скрынкавымі, бо калі б вызначэнне `Cons` выглядала так:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Не атрымалася б.Гэта таму, што памер `List` залежыць ад таго, колькі элементаў у спісе, і таму мы не ведаем, колькі памяці вылучыць для `Cons`.Прадстаўляючы [`Box<T>`], які мае пэўны памер, мы ведаем, якім вялікім павінен быць `Cons`.
//!
//! # Размяшчэнне памяці
//!
//! Для значэнняў, якія не адпавядаюць нулю, [`Box`] будзе выкарыстоўваць размеркавальнік [`Global`] для яго размеркавання.Дапушчальна пераўтварыць абодва шляхі паміж [`Box`] і неапрацаваным паказальнікам, выдзеленым з размеркатарам [`Global`], улічваючы, што [`Layout`], які выкарыстоўваецца з размеркатарам, правільны для гэтага тыпу.
//!
//! Дакладней, `value:*mut T`, які быў выдзелены з размеркавальнікам [`Global`] з `Layout::for_value(&* value)`, можа быць пераўтвораны ў скрынку з выкарыстаннем [`Box::<T>::from_raw(value)`].
//! І наадварот, памяць, якая падтрымлівае `value:*mut T`, атрыманую з [`Box::<T>::into_raw`], можа быць вызвалена з выкарыстаннем размеркавальніка [`Global`] з [`Layout::for_value(&* value)`].
//!
//! Для нулявых памераў паказальнік `Box` па-ранейшаму павінен быць [valid] для чытання і запісу і дастаткова выраўнаваны.
//! У прыватнасці, прывядзенне любога выраўнаванага ненулявога цэлага літэраля да сырога паказальніка вырабляе сапраўдны паказальнік, але паказальнік, які паказвае на раней выдзеленую памяць, якая з таго часу вызвалілася, несапраўдны.
//! Рэкамендуемы спосаб зборкі скрынкі да ZST, калі `Box::new` нельга выкарыстоўваць,-выкарыстанне [`ptr::NonNull::dangling`].
//!
//! Пакуль `T: Sized`, `Box<T>` гарантавана будзе прадстаўлены як адзінкавы паказальнік, а таксама сумяшчальны з ABI з паказальнікамі C (г.зн. тып C `T*`).
//! Гэта азначае, што калі ў вас ёсць знешнія функцыі "C" Rust, якія будуць выклікацца з C, вы можаце вызначыць гэтыя функцыі Rust, выкарыстоўваючы тыпы `Box<T>`, і выкарыстоўваць `T*` як адпаведны тып на баку C.
//! У якасці прыкладу разгледзім гэты загаловак C, які аб'яўляе функцыі, якія ствараюць і разбураюць нейкае значэнне `Foo`:
//!
//! ```c
//! /* З загалоўка */
//!
//! /* Вяртае ўласнасць абаненту */
//! struct Foo* foo_new(void);
//!
//! /* Забірае права ўласнасці ў абанента;no-op пры выкліку з NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Гэтыя дзве функцыі могуць быць рэалізаваны ў Rust наступным чынам.Тут тып `struct Foo*` з C пераводзіцца ў `Box<Foo>`, які фіксуе абмежаванні ўласнасці.
//! Звярніце таксама ўвагу на тое, што аргумент, які дазваляе ануляваць `foo_delete`, прадстаўлены ў Rust як `Option<Box<Foo>>`, бо `Box<Foo>` не можа быць роўным нулю.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Нягледзячы на тое, што `Box<T>` мае такое ж прадстаўленне і C ABI, як паказальнік C, гэта не азначае, што вы можаце пераўтварыць адвольны `T*` у `Box<T>` і чакаць, што ўсё атрымаецца.
//! `Box<T>` значэнні заўсёды будуць цалкам выраўнаваны, не нулявыя паказальнікі.Больш за тое, дэструктар для `Box<T>` паспрабуе вызваліць значэнне з дапамогай глабальнага размеркавальніка.Увогуле, лепшай практыкай з'яўляецца выкарыстанне `Box<T>` толькі для паказальнікаў, якія паходзяць з глабальнага размеркавальніка.
//!
//! **Важна.** Па меншай меры, у цяперашні час вам варта пазбягаць выкарыстання тыпаў `Box<T>` для функцый, якія вызначаны ў C, але якія выклікаюцца з Rust.У гэтых выпадках вы павінны непасрэдна адлюстроўваць тыпы C як мага бліжэй.
//! Выкарыстанне тыпаў, такіх як `Box<T>`, дзе азначэнне C проста выкарыстоўвае `T*`, можа прывесці да нявызначаных паводзін, як апісана ў [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Тып паказальніка для размеркавання кучы.
///
/// Глядзіце [module-level documentation](../../std/boxed/index.html) для атрымання дадатковай інфармацыі.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Выдзяляе памяць у кучы, а потым змяшчае ў яе `x`.
    ///
    /// Гэта фактычна не выдзяляецца, калі `T` мае нулявы памер.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Стварае новую скрынку з неініцыялізаваным змесцівам.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Стварае новы `Box` з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Канструюе новы `Pin<Box<T>>`.
    /// Калі `T` не рэалізуе `Unpin`, `x` будзе замацаваны ў памяці і не можа быць перамешчаны.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Выдзяляе памяць у кучы, затым змяшчае ў яе `x`, вяртаючы памылку, калі размеркаванне не ўдаецца
    ///
    ///
    /// Гэта фактычна не выдзяляецца, калі `T` мае нулявы памер.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Стварае новае поле з неініцыялізаваным змесцівам у кучы, вяртаючы памылку, калі размеркаванне не ўдаецца
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Канструюе новы `Box` з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0` у кучы
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Выдзяляе памяць у дадзеным размеркавальніку, пасля чаго змяшчае ў яе `x`.
    ///
    /// Гэта фактычна не выдзяляецца, калі `T` мае нулявы памер.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Выдзяляе памяць у дадзеным размеркавальніку, затым змяшчае ў яе `x`, вяртаючы памылку, калі размеркаванне не ўдаецца
    ///
    ///
    /// Гэта фактычна не выдзяляецца, калі `T` мае нулявы памер.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Стварае новую скрынку з неініцыялізаваным змесцівам у прадастаўленым размеркатары.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Аддайце перавагу супадзенню перад "unsrap_or_else", паколькі закрыццё часам не паддаецца.
        // Гэта павялічыць памер кода.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Стварае новае поле з неініцыялізаваным змесцівам у прадастаўленым размеркатары, вяртаючы памылку, калі размеркаванне не ўдаецца
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Стварае новы `Box` з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0` у прадастаўленым размеркатары.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Аддайце перавагу супадзенню перад "unsrap_or_else", паколькі закрыццё часам не паддаецца.
        // Гэта павялічыць памер кода.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Канструюе новы `Box` з неініцыялізаваным змесцівам, пры гэтым памяць запаўняецца байтамі `0` у прадастаўленым размеркавальніку, вяртаючы памылку, калі размеркаванне не атрымліваецца,
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Канструюе новы `Pin<Box<T, A>>`.
    /// Калі `T` не рэалізуе `Unpin`, `x` будзе замацаваны ў памяці і не можа быць перамешчаны.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Пераўтварае `Box<T>` у `Box<[T]>`
    ///
    /// Гэта пераўтварэнне не выдзяляецца на кучу і адбываецца на месцы.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Спажывае `Box`, вяртаючы загарнутае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Стварае новы зрэз у скрынцы з неініцыялізаваным змесцівам.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Стварае новы зрэз у скрынцы з неініцыялізаваным змесцівам, памяць запаўняецца байтамі `0`.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Стварае новы зрэз у скрынцы з неініцыялізаваным змесцівам у прадастаўленым размеркатары.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Стварае новы скрыначны зрэз з неініцыялізаваным змесцівам у прадастаўленым размеркавальніку, памяць запаўняецца байтамі `0`.
    ///
    ///
    /// Глядзіце прыклады правільнага і няправільнага выкарыстання гэтага метаду ў [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Пераўтварае ў `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Як і ў выпадку з [`MaybeUninit::assume_init`], абанент павінен гарантаваць, што значэнне сапраўды знаходзіцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае неадкладныя паводзіны.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Пераўтварае ў `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Як і ў выпадку з [`MaybeUninit::assume_init`], абанент павінен гарантаваць, што значэнні сапраўды знаходзяцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае неадкладныя паводзіны.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Адкладзеная ініцыялізацыя:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Стварае поле з сырога паказальніка.
    ///
    /// Пасля выкліку гэтай функцыі неапрацаваны паказальнік належыць атрыманаму `Box`.
    /// У прыватнасці, дэструктар `Box` выкліча дэструктар `T` і вызваліць выдзеленую памяць.
    /// Каб гэта было бяспечна, памяць павінна быць выдзелена ў адпаведнасці з [memory layout], які выкарыстоўваецца `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Гэтая функцыя небяспечная, бо няправільнае выкарыстанне можа прывесці да праблем з памяццю.
    /// Напрыклад, можа адбыцца падвойнае вызваленне, калі функцыя выклікаецца двойчы на адным і тым жа неапрацаваным паказальніку.
    ///
    /// Умовы бяспекі апісаны ў раздзеле [memory layout].
    ///
    /// # Examples
    ///
    /// Узнавім `Box`, які раней быў пераўтвораны ў неапрацаваны паказальнік з дапамогай [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Уручную стварыце `Box` з нуля, выкарыстоўваючы глабальны размеркавальнік:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Увогуле .write патрабуецца, каб пазбегнуць спроб разбурыць (uninitialized) папярэдняга зместу `ptr`, хаця для гэтага простага прыкладу `*ptr = 5` таксама працаваў бы.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Стварае поле з неапрацаванага паказальніка ў дадзеным размеркатары.
    ///
    /// Пасля выкліку гэтай функцыі неапрацаваны паказальнік належыць атрыманаму `Box`.
    /// У прыватнасці, дэструктар `Box` выкліча дэструктар `T` і вызваліць выдзеленую памяць.
    /// Каб гэта было бяспечна, памяць павінна быць выдзелена ў адпаведнасці з [memory layout], які выкарыстоўваецца `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Гэтая функцыя небяспечная, бо няправільнае выкарыстанне можа прывесці да праблем з памяццю.
    /// Напрыклад, можа адбыцца падвойнае вызваленне, калі функцыя выклікаецца двойчы на адным і тым жа неапрацаваным паказальніку.
    ///
    /// # Examples
    ///
    /// Узнавім `Box`, які раней быў пераўтвораны ў неапрацаваны паказальнік з дапамогай [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Уручную стварыце `Box` з нуля з дапамогай сістэмнага размеркавальніка:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Увогуле .write патрабуецца, каб пазбегнуць спроб разбурыць (uninitialized) папярэдняга зместу `ptr`, хаця для гэтага простага прыкладу `*ptr = 5` таксама працаваў бы.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Спажывае `Box`, вяртаючы загорнуты неапрацаваны паказальнік.
    ///
    /// Паказальнік будзе правільна выраўнаваны і не будзе нулявым.
    ///
    /// Пасля выкліку гэтай функцыі абанент адказвае за памяць, якой раней кіраваў `Box`.
    /// У прыватнасці, абанент павінен правільна знішчыць `T` і вызваліць памяць, прымаючы пад увагу [memory layout], які выкарыстоўваецца `Box`.
    /// Самы просты спосаб зрабіць гэта-пераўтварыць неапрацаваны паказальнік назад у `Box` з функцыяй [`Box::from_raw`], дазваляючы дэструктару `Box` выконваць ачыстку.
    ///
    ///
    /// Note: гэта звязаная функцыя, гэта азначае, што вы павінны называць яе як `Box::into_raw(b)` замест `b.into_raw()`.
    /// Гэта для таго, каб не ўзнікала канфлікту з метадам унутранага тыпу.
    ///
    /// # Examples
    /// Пераўтварэнне неапрацаванага паказальніка назад у `Box` з [`Box::from_raw`] для аўтаматычнай ачысткі:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Ачыстка ўручную шляхам відавочнага запуску дэструктара і вызвалення памяці:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Спажывае `Box`, вяртаючы загорнуты неапрацаваны паказальнік і размеркатар.
    ///
    /// Паказальнік будзе правільна выраўнаваны і не будзе нулявым.
    ///
    /// Пасля выкліку гэтай функцыі абанент адказвае за памяць, якой раней кіраваў `Box`.
    /// У прыватнасці, абанент павінен правільна знішчыць `T` і вызваліць памяць, прымаючы пад увагу [memory layout], які выкарыстоўваецца `Box`.
    /// Самы просты спосаб зрабіць гэта-пераўтварыць неапрацаваны паказальнік назад у `Box` з функцыяй [`Box::from_raw_in`], дазваляючы дэструктару `Box` выконваць ачыстку.
    ///
    ///
    /// Note: гэта звязаная функцыя, гэта азначае, што вы павінны называць яе як `Box::into_raw_with_allocator(b)` замест `b.into_raw_with_allocator()`.
    /// Гэта для таго, каб не ўзнікала канфлікту з метадам унутранага тыпу.
    ///
    /// # Examples
    /// Пераўтварэнне неапрацаванага паказальніка назад у `Box` з [`Box::from_raw_in`] для аўтаматычнай ачысткі:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Ачыстка ўручную шляхам відавочнага запуску дэструктара і вызвалення памяці:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box прызнаны "unique pointer" кампаніяй Stacked Borrows, але ўнутрана ён з'яўляецца неапрацаваным паказальнікам для сістэмы тыпаў.
        // Пераўтварэнне яго непасрэдна ў неапрацаваны паказальнік не будзе прызнана ўнікальным паказальнікам "releasing", каб дазволіць здзейснены доступ да неактыўных дадзеных, таму ўсе метады неапрацаванага паказальніка павінны праходзіць праз `Box::leak`.
        //
        // Ператварэнне *, што* да сырога паказальніка, паводзіць сябе карэктна.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Вяртае спасылку на асноўны размеркатар.
    ///
    /// Note: гэта звязаная функцыя, гэта азначае, што вы павінны называць яе як `Box::allocator(&b)` замест `b.allocator()`.
    /// Гэта для таго, каб не ўзнікала канфлікту з метадам унутранага тыпу.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Спажывае і ўцекае `Box`, вяртаючы зменную спасылку, `&'a mut T`.
    /// Звярніце ўвагу, што тып `T` павінен перажыць абраны тэрмін службы `'a`.
    /// Калі тып мае толькі статычныя спасылкі, альбо ўвогуле няма, гэта можа быць абраны `'static`.
    ///
    /// Гэтая функцыя ў асноўным карысная для дадзеных, якія жывуць да канца жыцця праграмы.
    /// Кіданне вернутай спасылкі прывядзе да ўцечкі памяці.
    /// Калі гэта непрымальна, спасылку трэба спачатку абгарнуць функцыяй [`Box::from_raw`], якая вырабляе `Box`.
    ///
    /// Затым гэты `Box` можна скінуць, што правільна знішчыць `T` і вызваліць выдзеленую памяць.
    ///
    /// Note: гэта звязаная функцыя, гэта азначае, што вы павінны называць яе як `Box::leak(b)` замест `b.leak()`.
    /// Гэта для таго, каб не ўзнікала канфлікту з метадам унутранага тыпу.
    ///
    /// # Examples
    ///
    /// Простае выкарыстанне:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Непамерныя дадзеныя:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Пераўтварае `Box<T>` у `Pin<Box<T>>`
    ///
    /// Гэта пераўтварэнне не выдзяляецца на кучу і адбываецца на месцы.
    ///
    /// Гэта таксама даступна праз [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Немагчыма перамясціць або замяніць нутро `Pin<Box<T>>`, калі `T: !Unpin`, таму можна бяспечна замацаваць яго непасрэдна без дадатковых патрабаванняў.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Не рабіце нічога, падзенне ў цяперашні час выконваецца кампілятарам.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Стварае `Box<T>` са значэннем `Default` для T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Вяртае новую скрынку з `clone()` змесціва гэтай скрынкі.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Значэнне аднолькавае
    /// assert_eq!(x, y);
    ///
    /// // Але яны ўнікальныя аб'екты
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Загадзя вылучыце памяць, каб дазволіць непасрэдна пісаць кланаванае значэнне.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Капіруе змест "крыніцы" ў `self` без стварэння новага размеркавання.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Значэнне аднолькавае
    /// assert_eq!(x, y);
    ///
    /// // І ніякага размеркавання не адбылося
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // гэта робіць копію дадзеных
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Пераўтварае агульны тып `T` у `Box<T>`
    ///
    /// Пераўтварэнне выдзяляе кучу і перамяшчае `t` са стэка ў яе.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Пераўтварае `Box<T>` у `Pin<Box<T>>`
    ///
    /// Гэта пераўтварэнне не выдзяляецца на кучу і адбываецца на месцы.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Пераўтварае `&[T]` у `Box<[T]>`
    ///
    /// Гэта пераўтварэнне выдзяляецца на кучу і выконвае копію `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // стварыце&[u8], які будзе выкарыстоўвацца для стварэння акна <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Пераўтварае `&str` у `Box<str>`
    ///
    /// Гэта пераўтварэнне выдзяляецца на кучу і выконвае копію `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Пераўтварае `Box<str>` у `Box<[u8]>`
    /// Гэта пераўтварэнне не выдзяляецца на кучу і адбываецца на месцы.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // стварыць скрынку<str>які будзе выкарыстоўвацца для стварэння акна <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // стварыце&[u8], які будзе выкарыстоўвацца для стварэння акна <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Пераўтварае `[T; N]` у `Box<[T]>`
    /// Гэта пераўтварэнне перамяшчае масіў у нядаўна выдзеленую кучу памяці.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Спроба апусціць скрыню да канкрэтнага тыпу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Спроба апусціць скрыню да канкрэтнага тыпу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Спроба апусціць скрыню да канкрэтнага тыпу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Немагчыма атрымаць унутраны Uniq непасрэдна з скрынкі, замест гэтага мы накіроўваем яго ў * const, які псеўданім Unique
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Спецыялізацыя для памераў "I", якая выкарыстоўвае "I" з `last()`, а не па змаўчанні.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}