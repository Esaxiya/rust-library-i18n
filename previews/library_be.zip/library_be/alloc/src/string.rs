//! Кадзіраваны UTF-8 радок, які прарастае.
//!
//! Гэты модуль утрымлівае тып [`String`], [`ToString`] Portrait для пераўтварэння ў радкі і некалькі тыпаў памылак, якія могуць паўстаць у выніку працы з [`String`] s.
//!
//!
//! # Examples
//!
//! Ёсць некалькі спосабаў стварыць новы [`String`] з радкавога літарала:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Вы можаце стварыць новы [`String`] з існуючага, аб'яднаўшыся з
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Калі ў вас ёсць vector з сапраўднымі байтамі UTF-8, вы можаце зрабіць з яго [`String`].Вы можаце зрабіць і адваротнае.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Мы ведаем, што гэтыя байты сапраўдныя, таму мы будзем выкарыстоўваць `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Кадзіраваны UTF-8 радок, які прарастае.
///
/// Тып `String`-найбольш распаўсюджаны тып радкоў, які мае права ўласнасці на змест радка.Ён мае цесныя адносіны са сваім запазычаным аналагам, прымітыўным [`str`].
///
/// # Examples
///
/// Вы можаце стварыць `String` з [a literal string][`str`] з [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Вы можаце дадаць [`char`] да `String` метадам [`push`], а [`&str`]-метадам [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Калі ў вас ёсць vector з байтамі UTF-8, вы можаце стварыць з яго `String` метадам [`from_utf8`]:
///
/// ```
/// // некалькі байтаў, у vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Мы ведаем, што гэтыя байты сапраўдныя, таму мы будзем выкарыстоўваць `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Радкі заўсёды сапраўдныя UTF-8.Гэта мае некалькі наступстваў, першы з якіх заключаецца ў тым, што калі вам патрэбна радок, якая не ўваходзіць у UTF-8, разгледзім [`OsString`].Ён падобны, але без абмежаванняў UTF-8.Другі вынік заключаецца ў тым, што вы не можаце індэксаваць у `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Індэксацыя прызначана для аперацыі з пастаянным часам, але кадаванне UTF-8 не дазваляе нам гэтага зрабіць.Акрамя таго, незразумела, якую рэч павінен вярнуць індэкс: байт, кодавы пункт альбо графемны кластар.
/// Метады [`bytes`] і [`chars`] вяртаюць ітэратары на працягу першых двух адпаведна.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `Рэалізацыя радка [` Deref`]`<Target=str>`, і таму ўспадкоўвае ўсе метады [` str`].Акрамя таго, гэта азначае, што вы можаце перадаць `String` функцыі, якая прымае [`&str`], выкарыстоўваючы амперсанд (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Гэта створыць [`&str`] з `String` і перадасць яго. Гэта пераўтварэнне вельмі недарагое, і таму, як правіла, функцыі будуць прымаць [`&str`] у якасці аргументаў, калі ім не патрэбны `String` па нейкай канкрэтнай прычыне.
///
/// У некаторых выпадках Rust не мае дастатковай колькасці інфармацыі для гэтага пераўтварэння, вядомага як прымус [`Deref`].У наступным прыкладзе зрэз радка [`&'a str`][`&str`] рэалізуе Portrait `TraitExample`, а функцыя `example_func` прымае ўсё, што рэалізуе Portrait.
/// У гэтым выпадку Rust спатрэбіцца зрабіць два няяўныя пераўтварэнні, чаго ў Rust няма.
/// Па гэтай прычыне наступны прыклад не будзе кампілявацца.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Замест гэтага будуць працаваць два варыянты.Першым было б змяніць радок `example_func(&example_string);` на `example_func(example_string.as_str());`, выкарыстоўваючы метад [`as_str()`] для відавочнага выдзялення зрэзу радка, які змяшчае радок.
/// Другі спосаб мяняе `example_func(&example_string);` на `example_func(&*example_string);`.
/// У гэтым выпадку мы перанакіроўваем `String` на [`str`][`&str`], затым спасылаемся на [`str`][`&str`] назад на [`&str`].
/// Другі спосаб больш ідыяматычны, аднак абодва працуюць, каб зрабіць пераўтварэнне відавочна, а не спадзявацца на няяўнае пераўтварэнне.
///
/// # Representation
///
/// `String` складаецца з трох кампанентаў: паказальніка на некаторыя байты, даўжыні і ёмістасці.Паказальнік паказвае на ўнутраны буфер, які `String` выкарыстоўвае для захоўвання сваіх дадзеных.Даўжыня-гэта колькасць байтаў, якія ў цяперашні час захоўваюцца ў буферы, а ёмістасць-гэта памер буфера ў байтах.
///
/// Такім чынам, даўжыня заўсёды будзе меншай або роўнай ёмістасці.
///
/// Гэты буфер заўсёды захоўваецца ў кучы.
///
/// Вы можаце паглядзець на іх метадамі [`as_ptr`], [`len`] і [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Абнавіце гэта, калі vec_into_raw_parts стабілізуецца.
/// // Не дапускайце аўтаматычнага падзення дадзеных радка
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // гісторыя мае дзевятнаццаць байт
/// assert_eq!(19, len);
///
/// // Мы можам аднавіць радок з ptr, len і ёмістасці.
/// // Усё гэта небяспечна, таму што мы нясем адказнасць за тое, каб кампаненты былі сапраўднымі:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Калі `String` мае дастатковую ёмістасць, даданне элементаў у яго не будзе пераразмеркавана.Напрыклад, разгледзім гэтую праграму:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Гэта выдасць наступнае:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Спачатку ў нас наогул не выдзелена памяці, але па меры дадання радка гэта павялічвае ёмістасць належным чынам.Калі мы замест гэтага выкарыстоўваем метад [`with_capacity`] для размеркавання правільнай ёмістасці першапачаткова:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// У выніку мы атрымліваем іншы выхад:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Тут няма неабходнасці выдзяляць больш памяці ўнутры цыкла.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Магчымае значэнне памылкі пры пераўтварэнні `String` з байта UTF-8 vector.
///
/// Гэты тып з'яўляецца тыпам памылкі для метаду [`from_utf8`] на [`String`].
/// Ён распрацаваны такім чынам, каб старанна пазбягаць пераразмеркавання: метад [`into_bytes`] верне байт vector, які быў выкарыстаны пры спробе пераўтварэння.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Тып [`Utf8Error`], прадстаўлены [`std::str`], уяўляе сабой памылку, якая можа ўзнікнуць пры пераўтварэнні зрэзу [`u8`] s у [`&str`].
/// У гэтым сэнсе гэта аналаг `FromUtf8Error`, і вы можаце атрымаць яго з `FromUtf8Error` метадам [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// // некалькі няслушных байтаў у vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Магчымае значэнне памылкі пры пераўтварэнні `String` з байтавага зрэзу UTF-16.
///
/// Гэты тып з'яўляецца тыпам памылкі для метаду [`from_utf16`] на [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Стварае новы пусты `String`.
    ///
    /// Улічваючы, што `String` пусты, пачатковы буфер не выдзяляе.Хоць гэта азначае, што гэтая першапачатковая аперацыя вельмі недарагая, яна можа выклікаць празмернае размеркаванне пазней пры даданні дадзеных.
    ///
    /// Калі вы ўяўляеце, колькі дадзеных будзе змяшчаць `String`, разгледзьце метад [`with_capacity`], каб прадухіліць празмернае пераразмеркаванне.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Стварае новы пусты `String` з пэўнай ёмістасцю.
    ///
    /// `String`s маюць унутраны буфер для захоўвання сваіх дадзеных.
    /// Ёмістасць-гэта даўжыня гэтага буфера, і яго можна запытаць метадам [`capacity`].
    /// Гэты метад стварае пусты `String`, але такі з пачатковым буферам, які змяшчае байты `capacity`.
    /// Гэта карысна, калі вы можаце дадаваць кучу дадзеных у `String`, памяншаючы колькасць пераразмеркаванняў, якія яму трэба зрабіць.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Калі дадзеная ёмістасць складае `0`, размеркаванне не адбудзецца, і гэты метад ідэнтычны метаду [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Радок не ўтрымлівае сімвалаў, нават нягледзячы на тое, што ў ім ёсць магчымасць
    /// assert_eq!(s.len(), 0);
    ///
    /// // Усё гэта робіцца без пераразмеркавання ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... але гэта можа зрабіць пераразмеркаванне радка
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): з cfg(test) уласцівы метад `[T]::to_vec`, неабходны для вызначэння гэтага метаду, недаступны.
    // Паколькі нам не патрэбны гэты метад для тэставання, я проста заглушаю. Звярніце ўвагу на модуль slice::hack у slice.rs для атрымання дадатковай інфармацыі
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Пераўтварае vector байтаў у `String`.
    ///
    /// Радок ([`String`]) складаецца з байтаў ([`u8`]), а vector байт ([`Vec<u8>`])-з байтаў, таму гэтая функцыя пераўтворыцца паміж імі.
    /// Не ўсе зрэзы байтаў з'яўляюцца сапраўднымі `String`s, аднак: `String` патрабуе, каб ён быў сапраўдным UTF-8.
    /// `from_utf8()` правярае, каб байты былі сапраўднымі UTF-8, а потым выконвае пераўтварэнне.
    ///
    /// Калі вы ўпэўнены, што зрэз байта з'яўляецца сапраўдным UTF-8, і вам не хочацца накладваць выдаткі на праверку сапраўднасці, існуе небяспечная версія гэтай функцыі, [`from_utf8_unchecked`], якая мае такія ж паводзіны, але прапускае праверку.
    ///
    ///
    /// Гэты метад дапаможа не капіраваць vector дзеля эфектыўнасці.
    ///
    /// Калі вам патрэбен [`&str`] замест `String`, разгледзім [`str::from_utf8`].
    ///
    /// Інверсія гэтага метаду-[`into_bytes`].
    ///
    /// # Errors
    ///
    /// Вяртае [`Err`], калі зрэз не з'яўляецца UTF-8, з апісаннем, чаму прадастаўленыя байты не з'яўляюцца UTF-8.vector, у які вы пераехалі, таксама ўваходзіць.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // некалькі байтаў, у vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Мы ведаем, што гэтыя байты сапраўдныя, таму мы будзем выкарыстоўваць `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Няправільныя байты:
    ///
    /// ```
    /// // некалькі няслушных байтаў у vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Больш падрабязна пра тое, што вы можаце зрабіць з гэтай памылкай, глядзіце ў дакументах для [`FromUtf8Error`].
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Пераўтварае зрэз байтаў у радок, уключаючы недапушчальныя сімвалы.
    ///
    /// Радкі складаюцца з байтаў ([`u8`]), а зрэз байтаў ([`&[u8]`][byteslice])-з байтаў, таму гэтая функцыя пераўтворыцца паміж імі.Аднак не ўсе зрэзы байтаў з'яўляюцца сапраўднымі радкамі: радкі павінны быць сапраўднымі UTF-8.
    /// Падчас гэтага пераўтварэння `from_utf8_lossy()` заменіць любыя недапушчальныя паслядоўнасці UTF-8 на [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], які выглядае так:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Калі вы ўпэўнены, што зрэз байта з'яўляецца сапраўдным UTF-8, і вам не хочацца накладваць выдаткі на пераўтварэнне, існуе небяспечная версія гэтай функцыі, [`from_utf8_unchecked`], якая мае такія ж паводзіны, але прапускае праверкі.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Гэтая функцыя вяртае [`Cow<'a, str>`].Калі наш зрэз байта несапраўдны UTF-8, нам трэба ўставіць сімвалы замены, якія зменяць памер радка і, такім чынам, патрабуюць `String`.
    /// Але калі гэта ўжо сапраўдны UTF-8, нам не трэба новае размеркаванне.
    /// Гэты тып вяртання дазваляе апрацоўваць абодва выпадкі.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // некалькі байтаў, у vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Няправільныя байты:
    ///
    /// ```
    /// // некаторыя няслушныя байты
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Расшыфраваць закадзіраваны UTF-16 vector `v` у `String`, вярнуўшы [`Err`], калі `v` змяшчае якія-небудзь недапушчальныя дадзеныя.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Гэта не робіцца праз collect: : <Result<_, _>> () па меркаваннях прадукцыйнасці.
        // FIXME: функцыя можа быць спрошчана зноў, калі #48994 закрыты.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Дэкадуйце зрэз `v`, закадзіраваны UTF-16, у `String`, замяніўшы недапушчальныя дадзеныя на [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// У адрозненне ад [`from_utf8_lossy`], які вяртае [`Cow<'a, str>`], `from_utf16_lossy` вяртае `String`, бо пераўтварэнне UTF-16 ў UTF-8 патрабуе выдзялення памяці.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Раскладае `String` на сырыя кампаненты.
    ///
    /// Вяртае неапрацаваны паказальнік на базавыя дадзеныя, даўжыню радка (у байтах) і размеркаваную ёмістасць дадзеных (у байтах).
    /// Гэта тыя самыя аргументы ў тым жа парадку, што і аргументы [`from_raw_parts`].
    ///
    /// Пасля выкліку гэтай функцыі абанент адказвае за памяць, якой раней кіраваў `String`.
    /// Адзіны спосаб зрабіць гэта-пераўтварыць неапрацаваны паказальнік, даўжыню і ёмістасць назад у `String` з функцыяй [`from_raw_parts`], дазваляючы дэструктару выконваць ачыстку.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Стварае новы `String` з даўжыні, ёмістасці і паказальніка.
    ///
    /// # Safety
    ///
    /// Гэта вельмі небяспечна з-за колькасці інварыянтаў, якія не правяраюцца:
    ///
    /// * Памяць у `buf` павінна быць раней выдзелена тым самым размеркатарам, які выкарыстоўвае стандартная бібліятэка, з неабходным выраўноўваннем роўна 1.
    /// * `length` павінна быць менш або роўна `capacity`.
    /// * `capacity` павінна быць правільным значэннем.
    /// * Першыя байты `length` у `buf` павінны быць сапраўднымі UTF-8.
    ///
    /// Парушэнне іх можа выклікаць такія праблемы, як пашкоджанне ўнутраных структур дадзеных размеркавальніка.
    ///
    /// Права ўласнасці на `buf` фактычна перадаецца `String`, які пасля можа вызваліць, пераразмеркаваць ці змяніць змесціва памяці, на якое паказвае паказальнік па жаданні.
    /// Пераканайцеся, што нішто іншае не выкарыстоўвае паказальнік пасля выкліку гэтай функцыі.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Абнавіце гэта, калі vec_into_raw_parts стабілізуецца.
    ///     // Не дапускайце аўтаматычнага падзення дадзеных радка
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Пераўтварае vector байтаў у `String`, не правяраючы, што радок утрымлівае сапраўдны UTF-8.
    ///
    /// Для больш падрабязнай інфармацыі глядзіце бяспечную версію [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Гэтая функцыя небяспечная, бо не правярае, ці перададзены ёй байты сапраўдныя UTF-8.
    /// Калі гэта абмежаванне парушаецца, гэта можа выклікаць праблемы з бяспекай памяці карыстальнікаў future `String`, бо астатняя частка стандартнай бібліятэкі мяркуе, што `String`s сапраўдныя UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // некалькі байтаў, у vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Пераўтварае `String` у байт vector.
    ///
    /// Гэта спажывае `String`, таму нам не трэба капіяваць яго змест.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Вымае зрэз радка, які змяшчае ўвесь `String`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Пераўтварае `String` у зменлівы зрэз радка.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Дадае дадзены зрэз радка ў канец гэтага `String`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Вяртае ёмістасць гэтага радка ў байтах.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Гарантуе, што ёмістасць гэтай "String" не менш як `additional` байт перавышае яе даўжыню.
    ///
    /// Пры неабходнасці ёмістасць можа быць павялічана больш, чым на `additional` байт, каб прадухіліць частыя пераразмеркаванні.
    ///
    ///
    /// Калі вы не хочаце, каб гэта паводзіны "at least", гл. Метад [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перапаўняе [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Гэта можа фактычна не павялічыць ёмістасць:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s мае даўжыню 2 і ёмістасць 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Паколькі ў нас ужо ёсць дадатковыя 8 ёмістасцяў, называючы гэта ...
    /// s.reserve(8);
    ///
    /// // ... фактычна не павялічваецца.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Забяспечвае, што ёмістасць гэтай "String" у `additional` байт большая, чым яе даўжыня.
    ///
    /// Падумайце аб выкарыстанні метаду [`reserve`], калі вы дакладна не ведаеце лепш, чым размеркатар.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, калі новая ёмістасць перапаўняе `usize`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Гэта можа фактычна не павялічыць ёмістасць:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s мае даўжыню 2 і ёмістасць 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Паколькі ў нас ужо ёсць дадатковыя 8 ёмістасцяў, называючы гэта ...
    /// s.reserve_exact(8);
    ///
    /// // ... фактычна не павялічваецца.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Спрабуе захаваць ёмістасць як мінімум для `additional`, каб у дадзены `String` было ўстаўлена больш элементаў.
    /// Калекцыя можа зарэзерваваць больш месца, каб пазбегнуць частых пераразмеркаванняў.
    /// Пасля выкліку `reserve` ёмістасць будзе большай або роўнай `self.len() + additional`.
    /// Нічога не робіць, калі ёмістасці ўжо дастаткова.
    ///
    /// # Errors
    ///
    /// Калі ёмістасць перапаўняецца альбо размеркавальнік паведамляе пра збой, вяртаецца памылка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Папярэдне зарэзервуйце памяць, выйшаўшы, калі мы не можам
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Цяпер мы ведаем, што гэта не можа OOM пасярод нашай складанай працы
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Спрабуе зарэзерваваць мінімальную ёмістасць роўна для `additional`, каб дадатковыя элементы былі ўстаўлены ў дадзены `String`.
    ///
    /// Пасля выкліку `reserve_exact` ёмістасць будзе большай або роўнай `self.len() + additional`.
    /// Нічога не робіць, калі магутнасці ўжо дастаткова.
    ///
    /// Звярніце ўвагу, што размеркавальнік можа даць калекцыі больш месца, чым ён просіць.
    /// Такім чынам, нельга разлічваць на ёмістасць як мінімум.
    /// Аддайце перавагу `reserve`, калі чакаецца ўстаўка future.
    ///
    /// # Errors
    ///
    /// Калі ёмістасць перапаўняецца альбо размеркавальнік паведамляе пра збой, вяртаецца памылка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Папярэдне зарэзервуйце памяць, выйшаўшы, калі мы не можам
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Цяпер мы ведаем, што гэта не можа OOM пасярод нашай складанай працы
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Памяншаецца ёмістасць гэтага `String` у адпаведнасці з яго даўжынёй.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Скарачаецца ёмістасць гэтага `String` з ніжняй мяжой.
    ///
    /// Ёмістасць застанецца як мінімум роўнай як даўжыні, так і пастаўленай кошту.
    ///
    ///
    /// Калі бягучая ёмістасць менш ніжняй мяжы, гэта адмоўна.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Дадае дадзены [`char`] да канца гэтага `String`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Вяртае зрэз байта змесціва гэтай "радка".
    ///
    /// Інверсія гэтага метаду-[`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Скарачае гэты `String` да зададзенай даўжыні.
    ///
    /// Калі `new_len` перавышае бягучую даўжыню радка, гэта не ўплывае.
    ///
    ///
    /// Звярніце ўвагу, што гэты метад не ўплывае на размеркаваную ёмістасць радка
    ///
    /// # Panics
    ///
    /// Panics, калі `new_len` не ляжыць на мяжы [`char`].
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Выдаляе апошні сімвал з буфера радкоў і вяртае яго.
    ///
    /// Вяртае [`None`], калі гэты `String` пусты.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Выдаляе [`char`] з гэтага `String` у байт-становішчы і вяртае яго.
    ///
    /// Гэта аперацыя *O*(*n*), бо патрабуецца капіяванне кожнага элемента ў буферы.
    ///
    /// # Panics
    ///
    /// Panics, калі `idx` большая або роўная даўжыні "радка", альбо калі яна не ляжыць на мяжы [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Выдаліце ўсе супадзенні шаблону `pat` у `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Супадзенні будуць выяўляцца і выдаляцца ітэрацыйна, таму ў выпадках, калі шаблоны перакрываюцца, выдаляецца толькі першы ўзор:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // БЯСПЕКА: пачатак і канец будуць знаходзіцца на межах байтаў utf8
        // дакументы Шукальніка
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Захоўвае толькі сімвалы, указаныя прэдыкатам.
    ///
    /// Іншымі словамі, выдаліце ўсе сімвалы `c` так, каб `f(c)` вярнуў `false`.
    /// Гэты метад дзейнічае на месцы, наведваючы кожнага героя роўна адзін раз у першапачатковым парадку, і захоўвае парадак захаваных сімвалаў.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Дакладны парадак можа быць карысны для адсочвання знешняга стану, напрыклад, індэкса.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Накіруйце idx да наступнага знака
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Устаўляе сімвал у гэты `String` у байтавай пазіцыі.
    ///
    /// Гэта аперацыя *O*(*n*), бо патрабуецца капіяванне ўсіх элементаў у буферы.
    ///
    /// # Panics
    ///
    /// Panics, калі `idx` больш, чым даўжыня радка, альбо калі ён не ляжыць на мяжы [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Устаўляе ў гэты `String` зрэз радка ў байтавым становішчы.
    ///
    /// Гэта аперацыя *O*(*n*), бо патрабуецца капіяванне ўсіх элементаў у буферы.
    ///
    /// # Panics
    ///
    /// Panics, калі `idx` больш, чым даўжыня радка, альбо калі ён не ляжыць на мяжы [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Вяртае зменную спасылку на змест гэтага `String`.
    ///
    /// # Safety
    ///
    /// Гэтая функцыя небяспечная, бо не правярае, ці перададзены ёй байты сапраўдныя UTF-8.
    /// Калі гэта абмежаванне парушаецца, гэта можа выклікаць праблемы з бяспекай памяці карыстальнікаў future `String`, бо астатняя частка стандартнай бібліятэкі мяркуе, што `String`s сапраўдныя UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Вяртае даўжыню гэтага `String`, у байтах, а не ў знаках [`char`] або графемах.
    /// Іншымі словамі, гэта можа быць не тое, што чалавек лічыць даўжынёй струны.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Вяртае `true`, калі даўжыня `String` роўная нулю, а ў адваротным выпадку `false`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Разбівае радок на дзве часткі пры зададзеным байтавым індэксе.
    ///
    /// Вяртае нядаўна выдзелены `String`.
    /// `self` змяшчае байты `[0, at)`, а вернуты `String`-байты `[at, len)`.
    /// `at` павінна знаходзіцца на мяжы кодавага пункта UTF-8.
    ///
    /// Звярніце ўвагу, што ёмістасць `self` не мяняецца.
    ///
    /// # Panics
    ///
    /// Panics, калі `at` не знаходзіцца на мяжы кодавага пункта `UTF-8`, альбо калі ён знаходзіцца за апошнім кодавым пунктам радка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Скарачае гэты `String`, выдаляючы ўсё змесціва.
    ///
    /// Хоць гэта азначае, што `String` будзе мець нулявую даўжыню, але яго ёмістасць не датычыцца.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Стварае зліўны ітэратар, які выдаляе зададзены дыяпазон у `String` і дае выдалены `chars`.
    ///
    ///
    /// Note: Дыяпазон элементаў выдаляецца, нават калі ітэратар не выкарыстоўваецца да канца.
    ///
    /// # Panics
    ///
    /// Panics, калі пачатковая і канчатковая кропкі не ляжаць на мяжы [`char`] альбо калі яны выходзяць за межы.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Выдаліце дыяпазон, пакуль β з радка
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Поўны дыяпазон ачышчае радок
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Бяспека памяці
        //
        // Версія String Drain не мае праблем з бяспекай памяці версіі vector.
        // Дадзеныя-гэта проста байты.
        // Паколькі выдаленне дыяпазону адбываецца ў Drop, то пры ўцечцы ітэратара Drain выдаленне не адбудзецца.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Вазьміце дзве адначасовыя пазыкі.
        // Радок &mut не будзе даступны, пакуль ітэрацыя не скончыцца, у Drop.
        let self_ptr = self as *mut _;
        // БЯСПЕКА: `slice::range` і `is_char_boundary` робяць адпаведныя праверкі межаў.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Выдаляе ўказаны дыяпазон у радку і замяняе яго дадзеным радком.
    /// Дадзены радок не павінен мець такую ж даўжыню, як дыяпазон.
    ///
    /// # Panics
    ///
    /// Panics, калі пачатковая і канчатковая кропкі не ляжаць на мяжы [`char`] альбо калі яны выходзяць за межы.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Замяніце дыяпазон да значэння β з радка
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Бяспека памяці
        //
        // Replace_range не мае праблем з бяспекай памяці сплайсінгу vector.
        // версіі vector.Дадзеныя-гэта проста байты.

        // УВАГА: уключэнне гэтай зменнай будзе няпраўдай (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // УВАГА: уключэнне гэтай зменнай будзе няпраўдай (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Зноў выкарыстоўваць `range` было б няправільна. (#81138) Мы мяркуем, што межы, пра якія паведамляе `range`, застаюцца ранейшымі, але спаборніцкая рэалізацыя можа змяняцца паміж выклікамі
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Пераўтварае гэты `String` у [`Box`]`<`[`str`] `>`.
    ///
    /// Гэта знізіць любую лішнюю магутнасць.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Вяртае зрэз байтаў [`u8`], якія спрабавалі пераўтварыць у `String`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // некалькі няслушных байтаў у vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Вяртае байты, якія спрабавалі пераўтварыць у `String`.
    ///
    /// Гэты спосаб старанна распрацаваны, каб пазбегнуць размеркавання.
    /// Ён будзе ўжываць памылку, выносячы байты, так што не трэба рабіць копію байтаў.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // некалькі няслушных байтаў у vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Дастаньце `Utf8Error`, каб атрымаць больш падрабязную інфармацыю пра збой пераўтварэння.
    ///
    /// Тып [`Utf8Error`], прадстаўлены [`std::str`], уяўляе сабой памылку, якая можа ўзнікнуць пры пераўтварэнні зрэзу [`u8`] s у [`&str`].
    /// У гэтым сэнсе гэта аналаг `FromUtf8Error`.
    /// Больш падрабязна пра яго выкарыстанне глядзіце ў яго дакументацыі.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // некалькі няслушных байтаў у vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // першы байт тут несапраўдны
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Паколькі мы ітэруем над `String`s, мы можам пазбегнуць хаця б аднаго размеркавання, атрымаўшы першую радок з ітэратара і дадаўшы да яе ўсе наступныя радкі.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Паколькі мы ітэруем праз каровы, мы можам пазбегнуць (potentially), па меншай меры, аднаго размеркавання, атрымаўшы першы элемент і дадаўшы да яго ўсе наступныя элементы.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Зручны impl, які дэлегуе impl для `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Стварае пусты `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Рэалізаваны аператар `+` для аб'яднання дзвюх радкоў.
///
/// Гэта спажывае `String` з левага боку і паўторна выкарыстоўвае яго буфер (павялічваючы яго пры неабходнасці).
/// Гэта робіцца для таго, каб пазбегнуць выдзялення новага `String` і капіравання ўсяго змесціва пры кожнай аперацыі, што прывяло б да часу выканання *O*(*n*^ 2) пры пабудове радка *n* байт шляхам шматразовага аб'яднання.
///
///
/// Радок з правага боку толькі запазычаны;яго змест капіюецца ў вернуты `String`.
///
/// # Examples
///
/// Канкатэнацыя дзвюх радкоў прымае першую па значэнні і запазычвае другую:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` перамешчаны і больш не можа быць выкарыстаны тут.
/// ```
///
/// Калі вы хочаце працягваць выкарыстоўваць першы `String`, вы можаце яго кланаваць і дадаць да клона:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` тут усё яшчэ дзейнічае.
/// ```
///
/// Канкатэнацыя зрэзаў `&str` можа быць зроблена шляхам пераўтварэння першага ў `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Рэалізуе аператар `+=` для дадання да `String`.
///
/// Гэта мае такія ж паводзіны, як і метад [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Тыповы псеўданім для [`Infallible`].
///
/// Гэты псеўданім існуе для зваротнай сумяшчальнасці і ў канчатковым выніку можа быць састарэлы.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Portrait для пераўтварэння значэння ў `String`.
///
/// Гэты Portrait аўтаматычна рэалізуецца для любога тыпу, які рэалізуе [`Display`] Portrait.
/// Такім чынам, `ToString` не варта рэалізоўваць непасрэдна:
/// [`Display`] павінны быць рэалізаваны замест гэтага, і вы атрымаеце рэалізацыю `ToString` бясплатна.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Пераўтварае дадзенае значэнне ў `String`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// У гэтай рэалізацыі метад `to_string` panics, калі рэалізацыя `Display` вяртае памылку.
/// Гэта сведчыць аб няправільнай рэалізацыі `Display`, бо `fmt::Write for String` ніколі не вяртае памылку.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Агульная рэкамендацыя-не ўбудоўваць агульныя функцыі.
    // Аднак выдаленне `#[inline]` з гэтага метаду выклікае нязначныя рэгрэсы.
    // Глядзіце <https://github.com/rust-lang/rust/pull/74852>, апошняя спроба яго выдалення.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Пераўтварае `&mut str` у `String`.
    ///
    /// Вынік выдзяляецца на кучу.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: тэст уцягвае libstd, што тут выклікае памылкі
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Пераўтварае дадзены зрэз `str` у скрынцы ў `String`.
    /// Характэрна, што зрэз `str` належыць.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Пераўтварае дадзены `String` у скрынку `str`, якая належыць.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Пераўтварае зрэз радка ў запазычаны варыянт.
    /// Выдзяленне кучы не выконваецца, і радок не капіруецца.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Пераўтварае радок ва ўласны варыянт.
    /// Выдзяленне кучы не выконваецца, і радок не капіруецца.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Пераўтварае спасылку на радок у запазычаны варыянт.
    /// Выдзяленне кучы не выконваецца, і радок не капіруецца.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Пераўтварае дадзены `String` у vector `Vec`, які змяшчае значэнні тыпу `u8`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Зліўны ітэратар для `String`.
///
/// Гэтая структура створана метадам [`drain`] на [`String`].
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Будзе выкарыстоўвацца як&'a mut радок у дэструктары
    string: *mut String,
    /// Пачатак часткі для выдалення
    start: usize,
    /// Канец часткі для выдалення
    end: usize,
    /// Бягучы дыяпазон, які застаўся для выдалення
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Выкарыстоўвайце Vec::drain.
            // "Reaffirm" межы правяраюць, каб пазбегнуць паўторнай устаўкі кода panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Вяртае астатнюю (пад) радок гэтага ітэратара ў выглядзе зрэзу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: каментаваць AsRef выклікае ніжэй пры стабілізацыі.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Не каментуйце пры стабілізацыі `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>для Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> для Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}