`core::arch` - Унутраныя характарыстыкі асноўнай архітэктуры бібліятэкі Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Модуль `core::arch` рэалізуе ўласцівыя архітэктуры (напрыклад, SIMD).

# Usage 

`core::arch` даступны як частка `libcore`, і ён рээкспартуецца `libstd`.Аддайце перавагу выкарыстоўваць яго праз `core::arch` альбо `std::arch`, чым праз crate.
Няўстойлівыя функцыі часта даступныя ў начным Rust праз `feature(stdsimd)`.

Выкарыстанне `core::arch` праз гэты crate патрабуе начнога Rust, і ён можа (і робіць) часта ламацца.Адзіныя выпадкі, калі вам варта разгледзець магчымасць выкарыстання гэтага crate:

* калі вам трэба паўторна скампіляваць `core::arch` самастойна, напрыклад, з уключанымі пэўнымі мэтавымі функцыямі, якія не ўключаны для `libcore`/`libstd`.
Note: калі вам трэба паўторна скампіляваць яго для нестандартнай мэты, аддайце перавагу выкарыстанню `xargo` і паўторнай кампіляцыі `libcore`/`libstd` па меры неабходнасці замест выкарыстання гэтага crate.
  
* з выкарыстаннем некаторых функцый, якія могуць быць недаступныя нават за нестабільнымі функцыямі Rust.Мы імкнемся звесці іх да мінімуму.
Калі вам трэба выкарыстоўваць некаторыя з гэтых функцый, адкрыйце пытанне, каб мы маглі раскрыць іх у начным Rust, і вы маглі б выкарыстоўваць іх адтуль.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` распаўсюджваецца ў першую чаргу на ўмовах ліцэнзіі MIT і ліцэнзіі Apache (версія 2.0), прычым часткі ахоплены рознымі ліцэнзіямі, падобнымі на BSD.

Для атрымання падрабязнай інфармацыі глядзіце LICENSE-APACHE і LICENSE-MIT.

# Contribution

Калі вы ясна не ўказваеце іншае, любы ўклад, наўмысна прадстаўлены вамі для ўключэння ў `core_arch`, як гэта вызначана ў ліцэнзіі Apache-2.0, будзе мець падвойную ліцэнзію, як паказана вышэй, без якіх-небудзь дадатковых умоў і ўмоў.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












