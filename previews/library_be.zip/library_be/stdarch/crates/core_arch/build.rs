use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Выкарыстоўваецца, каб сказаць нашым анатацыям `#[assert_instr]`, што ўсе ўласныя ўласцівасці simd даступныя для тэставання іх кодэгена, бо некаторыя стаяць за дадатковым `-Ctarget-feature=+unimplemented-simd128`, які не мае эквівалента ў `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}