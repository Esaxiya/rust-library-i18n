//! Бібліятэка падтрымкі для аўтараў макрасаў пры вызначэнні новых макрасаў.
//!
//! Гэтая бібліятэка, якая забяспечваецца стандартным размеркаваннем, забяспечвае тыпы, якія выкарыстоўваюцца ў інтэрфейсах працэдурна вызначаных азначэнняў макрасаў, такіх як функцыянальныя макрасы `#[proc_macro]`, атрыбуты макрасаў `#[proc_macro_attribute]` і ўласныя атрыбуты атрымання `#[proc_macro_derive]`.
//!
//!
//! Больш падрабязна гл. [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Вызначае, ці быў proc_macro зроблены даступным для бягучай праграмы.
///
/// Proc_macro crate прызначаны толькі для выкарыстання ўнутры рэалізацыі працэдурных макрасаў.Усе функцыі ў гэтым crate panic, калі яны выклікаюцца звонку працэдурнага макраса, напрыклад, са сцэнарыя зборкі альбо модульнага тэсту альбо звычайнага двайковага файла Rust.
///
/// З улікам бібліятэк Rust, якія распрацаваны для падтрымкі выпадкаў выкарыстання як макрасаў, так і не макрасаў, `proc_macro::is_available()` забяспечвае не панікуючы спосаб вызначыць, ці даступная на дадзены момант інфраструктура, неабходная для выкарыстання API proc_macro.
/// Вяртае true, калі выклікаецца знутры працэдурнага макраса, false, калі выклікаецца з любога іншага двайковага файла.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Асноўны тып, прадстаўлены гэтым crate, які ўяўляе сабой абстрактны паток tokens, альбо, больш дакладна, паслядоўнасць дрэў token.
/// Тып забяспечвае інтэрфейсы для ітэрацыі па гэтых дрэвах token і, наадварот, збору шэрагу дрэў token у адзін паток.
///
///
/// Гэта адначасова ўваходныя і выходныя дадзеныя азначэнняў `#[proc_macro]`, `#[proc_macro_attribute]` і `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Памылка вернута з `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Вяртае пусты `TokenStream`, які не змяшчае дрэў token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Правярае, ці пусты гэты `TokenStream`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Спробы разбіць радок на tokens і разабраць гэтыя tokens на паток token.
/// Можа не атрымацца па шэрагу прычын, напрыклад, калі радок утрымлівае незбалансаваныя раздзяляльнікі або сімвалы, якія не існуюць у мове.
///
/// Усе tokens у разабраным патоку атрымліваюць пралёты `Span::call_site()`.
///
/// NOTE: некаторыя памылкі могуць выклікаць panics замест вяртання `LexError`.Мы пакідаем за сабой права змяніць гэтыя памылкі на "LexError" пазней.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Заўвага, мост забяспечвае толькі `to_string`, рэалізаваць `fmt::Display` на яго аснове (адваротнае ад звычайных адносін паміж імі).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Друкуе паток token у выглядзе радка, які мяркуецца канвертаваць без страт назад у той жа паток token (па модулях), за выключэннем, магчыма, `TokenTree: : Group` з раздзяляльнікамі `Delimiter::None` і адмоўнымі лічбавымі літарамі.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Друкуе token у форме, зручнай для адладкі.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Стварае паток token, які змяшчае адно дрэва token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Збірае шэраг дрэў token у адзін паток.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Аперацыя "flattening" на патоках token збірае дрэвы token з некалькіх патокаў token у адзін паток.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Выкарыстоўвайце аптымізаваную рэалізацыю if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Падрабязная інфармацыя пра агульную рэалізацыю тыпу `TokenStream`, напрыклад ітэратары.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Ітэратар над `TokenStream` над`TokenTree`s.
    /// Ітэрацыя "shallow", напрыклад, ітэратар не паўтараецца ў падзеленыя групы і вяртае цэлыя групы ў выглядзе дрэў token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` прымае адвольныя tokens і пашыраецца ў `TokenStream`, які апісвае ўваходныя дадзеныя.
/// Напрыклад, `quote!(a + b)` вырабіць выраз, які пры ацэнцы стварае `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Скасаванне каціроўкі робіцца з `$`, і гэта працуе, прымаючы адзін наступны ідэнтыфікатар як тэрмін без каціроўкі.
/// Каб працытаваць сам `$`, выкарыстоўвайце `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Вобласць зыходнага кода, а таксама інфармацыя пра пашырэнне макрасаў.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Стварае новы `Diagnostic` з дадзеным `message` на размаху `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Прамежак, які вырашаецца на сайце вызначэння макраса.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Працягласць выкліку бягучага працэдурнага макраса.
    /// Ідэнтыфікатары, створаныя з гэтым інтэрвалам, будуць вырашаны так, як калі б яны былі напісаны непасрэдна ў месцы выкліку макраса (гігіена выкліку), а іншы код на сайце выкліку макрасаў таксама можа спасылацца на іх.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Прамежак, які ўяўляе гігіену `macro_rules` і часам вырашаецца на сайце вызначэння макраса (лакальныя зменныя, пазнакі, `$crate`), а часам і на сайце выкліку макраса (усё астатняе).
    ///
    /// Месца пралёта ўзята з месца выкліку.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Зыходны файл, на які паказвае гэты прамежак.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` для tokens у папярэднім пашырэнні макрасаў, з якога быў створаны `self`, калі ён быў.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Прамежак для зыходнага кода паходжання, з якога быў створаны `self`.
    /// Калі гэты `Span` не быў згенераваны з іншых пашырэнняў макрасаў, то зваротнае значэнне такое ж, як і `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Атрымлівае пачатковы line/column у зыходным файле для гэтага перыяду.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Атрымлівае канчатак line/column у зыходным файле для гэтага перыяду.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Стварае новы прамежак, які ахоплівае `self` і `other`.
    ///
    /// Вяртае `None`, калі `self` і `other` з розных файлаў.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Стварае новы прамежак з той самай інфармацыяй line/column, што і `self`, але які вырашае сімвалы, як калі б яны былі ў `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Стварае новы прамежак з тымі ж паводзінамі дазволу імёнаў, што і `self`, але з інфармацыяй line/column `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// У параўнанні з пралётамі, каб даведацца, ці роўныя яны.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Вяртае зыходны тэкст пасля размаху.
    /// Пры гэтым захоўваецца зыходны код, уключаючы прабелы і каментарыі.
    /// Ён вяртае вынік, толькі калі дыяпазон адпавядае рэальнаму зыходнаму коду.
    ///
    /// Note: Назіральны вынік макраса павінен разлічваць толькі на tokens, а не на гэты зыходны тэкст.
    ///
    /// Вынікам гэтай функцыі з'яўляецца лепшае намаганне, якое выкарыстоўваецца толькі для дыягностыкі.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Друкуе пралёт у форме, зручнай для адладкі.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Пара радкоў-слупкоў, якая прадстаўляе пачатак ці канец `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Індэксаваная 1 радок у зыходным файле, на якой інтэрвал пачынаецца альбо заканчваецца (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-індэксаваны слупок (у сімвалах UTF-8) у зыходным файле, на якім інтэрвал пачынаецца альбо заканчваецца (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Зыходны файл дадзенага `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Атрымлівае шлях да гэтага зыходнага файла.
    ///
    /// ### Note
    /// Калі дыяпазон кода, звязаны з гэтым `SourceFile`, быў згенераваны знешнім макрасам, гэты макрас, гэта можа быць не сапраўдным шляхам у файлавай сістэме.
    /// Выкарыстоўвайце [`is_real`] для праверкі.
    ///
    /// Таксама звярніце ўвагу, што нават калі `is_real` вяртае `true`, калі `--remap-path-prefix` быў перададзены ў камандным радку, шлях, як паказаны, на самай справе можа быць несапраўдным.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Вяртае `true`, калі гэты зыходны файл з'яўляецца сапраўдным зыходным файлам, а не генеруецца пры пашырэнні знешняга макраса.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Гэта ўзлом да таго часу, пакуль не будуць рэалізаваны інтэркратаваныя інтэрвалы, і мы можам мець рэальныя зыходныя файлы для інтэрвалаў, якія генеруюцца ў знешніх макрасах.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Адзінкавы token альбо раздзеленая паслядоўнасць дрэў token (напрыклад, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Паток token, акружаны раздзяляльнікамі дужак.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Ідэнтыфікатар.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Адзінкавы знак прыпынку (`+`, `,`, `$` і г.д.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Літаральны сімвал (`'a'`), радок (`"hello"`), нумар (`2.3`) і г.д.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Вяртае размах гэтага дрэва, дэлегуючы метаду `span` змешчанага token альбо падзеленага патоку.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Наладжвае дыяпазон для *толькі гэтага token*.
    ///
    /// Звярніце ўвагу, што калі гэты token з'яўляецца `Group`, то гэты метад не будзе наладжваць дыяпазон кожнага з унутраных tokens, гэта проста дэлегуе метаду `set_span` кожнага варыянту.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Друкуе дрэва token у форме, зручнай для адладкі.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Кожны з іх мае імя ў тыпе struct ў вытворнай адладцы, таму не варта турбавацца дадатковым узроўнем ўскоснага ўвагі
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Заўвага, мост забяспечвае толькі `to_string`, рэалізаваць `fmt::Display` на яго аснове (адваротнае ад звычайных адносін паміж імі).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Друкуе дрэва token у выглядзе радка, які мяркуецца канвертаваць без страт назад у тое ж дрэва token (па модулях), за выключэннем, магчыма, `TokenTree: : Group` з раздзяляльнікамі `Delimiter::None` і адмоўнымі лічбавымі літарамі.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Размежаваны паток token.
///
/// `Group` унутрана ўтрымлівае `TokenStream`, які акружаны раздзяляльнікамі.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Апісвае, як размежавана паслядоўнасць дрэў token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Няяўны падзельнік, які можа, напрыклад, з'явіцца вакол tokens, які паходзіць ад "macro variable" `$var`.
    /// Важна захаваць прыярытэты аператара ў такіх выпадках, як `$var * 3`, калі `$var`-гэта `1 + 2`.
    /// Неяўныя раздзяляльнікі могуць не перажываць кругазварот патоку token праз радок.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Стварае новы `Group` з дадзеным раздзяляльнікам і патокам token.
    ///
    /// Гэты канструктар усталюе для гэтай групы дыяпазон `Span::call_site()`.
    /// Каб змяніць дыяпазон, вы можаце выкарыстоўваць метад `set_span` ніжэй.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Вяртае падзельнік гэтага `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Вяртае `TokenStream` з tokens, размежаваныя ў гэтым `Group`.
    ///
    /// Звярніце ўвагу, што вернуты паток token не ўключае раздзяляльнік, вернуты вышэй.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Вяртае размах для раздзяляльнікаў гэтага патоку token, які ахоплівае ўвесь `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Вяртае прамежак, які паказвае на пачатковы падзельнік гэтай групы.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Вяртае прамежак, які паказвае на раздзяляльнік гэтай групы.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Наладжвае дыяпазон для раздзяляльнікаў гэтай групы, але не ўнутраных tokens.
    ///
    /// Гэты метад **не** ўсталюе дыяпазон усіх унутраных tokens, ахопленых гэтай групай, а наадварот, ён усталюе толькі дыяпазон раздзяляльніка tokens на ўзроўні `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Заўвага, мост забяспечвае толькі `to_string`, рэалізаваць `fmt::Display` на яго аснове (адваротнае ад звычайных адносін паміж імі).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Друкуе групу ў выглядзе радка, які трэба канвертаваць без страт назад у адну і тую ж групу (па модулях), за выключэннем, магчыма, `TokenTree: : Group` з раздзяляльнікамі `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct`-гэта адзінкавыя знакі прыпынку, такія як `+`, `-` або `#`.
///
/// Шматзнакавыя аператары, такія як `+=`, прадстаўлены ў выглядзе двух асобнікаў `Punct` з рознымі формамі `Spacing`.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Калі за `Punct` адразу ідзе іншы `Punct`, ці за іншым token альбо прабелам.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// напрыклад, `+`-гэта `Alone` у `+ =`, `+ident` ці `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// напрыклад, `+`-гэта `Joint` у `+=` альбо `'#`.
    /// Акрамя таго, аднаразовая цытата `'` можа аб'яднацца з ідэнтыфікатарамі, каб сфармаваць час жыцця `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Стварае новы `Punct` з зададзенага знака і інтэрвалу.
    /// Аргумент `ch` павінен быць сапраўдным знакам прыпынку, дазволеным мовай, інакш функцыя будзе panic.
    ///
    /// Вяртанне `Punct` будзе мець дыяпазон па змаўчанні `Span::call_site()`, які можна дадаткова наладзіць з дапамогай метаду `set_span` ніжэй.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Вяртае значэнне знака прыпынку як `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Вяртае інтэрвал гэтага знака прыпынку, паказваючы, ці адразу за ім ідзе іншы `Punct` у патоку token, так што яны патэнцыйна могуць быць аб'яднаны ў шматзнакавы аператар (`Joint`), альбо за ім варта іншы token альбо прабел (`Alone`), таму аператар напэўна мае скончылася.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Вяртае прамежак для гэтага знака прыпынку.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Наладзьце інтэрвал для гэтага знака прыпынку.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Заўвага, мост забяспечвае толькі `to_string`, рэалізаваць `fmt::Display` на яго аснове (адваротнае ад звычайных адносін паміж імі).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Друкуе знакі прыпынку ў выглядзе радка, які трэба канвертаваць без страт назад у той самы сімвал.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Ідэнтыфікатар (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Стварае новы `Ident` з дадзеным `string`, а таксама з указаным `span`.
    /// Аргумент `string` павінен быць сапраўдным ідэнтыфікатарам, дазволеным мовай (уключаючы ключавыя словы, напрыклад, `self` або `fn`).У адваротным выпадку функцыя будзе panic.
    ///
    /// Звярніце ўвагу, што `span`, у цяперашні час у rustc, наладжвае гігіенічную інфармацыю для гэтага ідэнтыфікатара.
    ///
    /// З гэтага часу `Span::call_site()` відавочна падключаецца да гігіены "call-site", што азначае, што ідэнтыфікатары, створаныя з гэтым прамежкам, будуць вырашаны так, як калі б яны былі напісаны непасрэдна ў месцы макра-выкліку, а іншы код на сайце макра-выклікаў зможа спасылацца на іх таксама.
    ///
    ///
    /// Пазнейшыя перыяды, такія як `Span::def_site()`, дазволяць падключыцца да гігіены "definition-site", што азначае, што ідэнтыфікатары, створаныя з гэтым інтэрвалам, будуць вырашаны ў месцы вызначэння макраса, а іншы код на сайце выкліку макрасаў не зможа на іх спасылацца.
    ///
    /// У сувязі з важнай гігіенай у цяперашні час гэты канструктар, у адрозненне ад іншых tokens, патрабуе ўказання `Span` пры будаўніцтве.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Тое ж, што і `Ident::new`, але стварае неапрацаваны ідэнтыфікатар (`r#ident`).
    /// Аргумент `string`-сапраўдны ідэнтыфікатар, дазволены мовай (уключаючы ключавыя словы, напрыклад, `fn`).
    /// Ключавыя словы, якія можна выкарыстоўваць у сегментах шляху (напрыклад,
    /// `self`, `super`) не падтрымліваюцца, і выкліча panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Вяртае прамежак гэтага `Ident`, які ахоплівае ўвесь радок, вернуты [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Наладжвае дыяпазон гэтага `Ident`, магчыма, змяняючы яго гігіенічны кантэкст.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Заўвага, мост забяспечвае толькі `to_string`, рэалізаваць `fmt::Display` на яго аснове (адваротнае ад звычайных адносін паміж імі).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Друкуе ідэнтыфікатар у выглядзе радка, які трэба канвертаваць без страт назад у той самы ідэнтыфікатар.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Літаральны радок (`"hello"`), байт-радок (`b"hello"`), сімвал (`'a'`), байт-сімвал (`b'a'`), цэлы лік альбо нумар з плаваючай кропкай з суфіксам або без яго (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Лагічныя літаралы, такія як `true` і `false`, сюды не належаць, яны з'яўляюцца "ідэнтычнымі".
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Стварае новы суфіксальны цэлы лік з указаным значэннем.
        ///
        /// Гэтая функцыя створыць цэлае лік накшталт `1u32`, дзе зададзенае цэлае значэнне з'яўляецца першай часткай token, а інтэграл таксама суфіксаваны ў канцы.
        /// Літаралы, створаныя з адмоўных лікаў, могуць не перажыць зваротных паездак праз `TokenStream` альбо радкі і могуць быць разбітыя на два tokens (`-` і дадатны літарал).
        ///
        ///
        /// Літаралы, створаныя з дапамогай гэтага метаду, па змаўчанні маюць дыяпазон `Span::call_site()`, які можна наладзіць з дапамогай метаду `set_span` ніжэй.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Стварае новы несуфіксаваны цэлы літарал з зададзеным значэннем.
        ///
        /// Гэтая функцыя створыць цэлае лік накшталт `1`, дзе зададзенае цэлае значэнне з'яўляецца першай часткай token.
        /// На гэтым token не ўказаны суфікс, што азначае, што выклікі накшталт `Literal::i8_unsuffixed(1)` эквівалентныя `Literal::u32_unsuffixed(1)`.
        /// Літаралы, створаныя з адмоўных лікаў, могуць не перажываць праходжання праз `TokenStream` альбо радкі і могуць быць разбіты на два tokens (`-` і дадатны літарал).
        ///
        ///
        /// Літаралы, створаныя з дапамогай гэтага метаду, па змаўчанні маюць дыяпазон `Span::call_site()`, які можна наладзіць з дапамогай метаду `set_span` ніжэй.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Стварае новы несуфіксаваны літарал з плаваючай коскай.
    ///
    /// Гэты канструктар падобны на такія, як `Literal::i8_unsuffixed`, дзе значэнне паплаўка выпраменьваецца непасрэдна ў token, але суфікс не выкарыстоўваецца, таму пазней у кампілятары можна зрабіць выснову, што гэта `f64`.
    ///
    /// Літаралы, створаныя з адмоўных лікаў, могуць не перажываць праходжання праз `TokenStream` альбо радкі і могуць быць разбіты на два tokens (`-` і дадатны літарал).
    ///
    /// # Panics
    ///
    /// Гэтая функцыя патрабуе, каб указаны паплавок быў канчатковым, напрыклад, калі гэта бясконцасць або NaN, гэтая функцыя будзе panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Стварае новы літарал з суфіксам з плаваючай коскай.
    ///
    /// Гэты канструктар створыць такі літарал, як `1.0f32`, дзе зададзенае значэнне з'яўляецца папярэдняй часткай token, а `f32`-суфіксам token.
    /// Гэты token заўсёды будзе выводзіцца як `f32` у кампілятары.
    /// Літаралы, створаныя з адмоўных лікаў, могуць не перажываць праходжання праз `TokenStream` альбо радкі і могуць быць разбіты на два tokens (`-` і дадатны літарал).
    ///
    ///
    /// # Panics
    ///
    /// Гэтая функцыя патрабуе, каб указаны паплавок быў канчатковым, напрыклад, калі гэта бясконцасць або NaN, гэтая функцыя будзе panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Стварае новы несуфіксаваны літарал з плаваючай коскай.
    ///
    /// Гэты канструктар падобны на такія, як `Literal::i8_unsuffixed`, дзе значэнне паплаўка выпраменьваецца непасрэдна ў token, але суфікс не выкарыстоўваецца, таму пазней у кампілятары можна зрабіць выснову, што гэта `f64`.
    ///
    /// Літаралы, створаныя з адмоўных лікаў, могуць не перажываць праходжання праз `TokenStream` альбо радкі і могуць быць разбіты на два tokens (`-` і дадатны літарал).
    ///
    /// # Panics
    ///
    /// Гэтая функцыя патрабуе, каб указаны паплавок быў канчатковым, напрыклад, калі гэта бясконцасць або NaN, гэтая функцыя будзе panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Стварае новы літарал з суфіксам з плаваючай коскай.
    ///
    /// Гэты канструктар створыць такі літарал, як `1.0f64`, дзе зададзенае значэнне з'яўляецца папярэдняй часткай token, а `f64`-суфіксам token.
    /// Гэты token заўсёды будзе выводзіцца як `f64` у кампілятары.
    /// Літаралы, створаныя з адмоўных лікаў, могуць не перажываць праходжання праз `TokenStream` альбо радкі і могуць быць разбіты на два tokens (`-` і дадатны літарал).
    ///
    ///
    /// # Panics
    ///
    /// Гэтая функцыя патрабуе, каб указаны паплавок быў канчатковым, напрыклад, калі гэта бясконцасць або NaN, гэтая функцыя будзе panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Радок літаральны.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Літаральны характар.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Літарал радка байта.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Вяртае прамежак, які ахоплівае гэты літарал.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Наладжвае прамежак, звязаны з гэтым літаралам.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Вяртае `Span`, які з'яўляецца падмноствам `self.span()`, які змяшчае толькі зыходныя байты ў дыяпазоне `range`.
    /// Вяртае `None`, калі магчымы абрэзаны прамежак знаходзіцца па-за межамі `self`.
    ///
    // FIXME(SergioBenitez): пераканайцеся, што дыяпазон байтаў пачынаецца і заканчваецца на мяжы UTF-8 крыніцы.
    // у адваротным выпадку верагодна, што panic паўстане ў іншым месцы пры надрукаванні зыходнага тэксту.
    // FIXME(SergioBenitez): карыстальнік не можа даведацца, на што на самай справе супастаўляецца `self.span()`, таму гэты метад у цяперашні час можна выклікаць толькі ўсляпую.
    // Напрыклад, `to_string()` для сімвала 'c' вяртае "'\u{63}'";карыстальнік не можа даведацца, зыходным тэкстам быў 'c' ці '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) нешта падобнае на `Option::cloned`, але для `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Заўвага, мост забяспечвае толькі `to_string`, рэалізаваць `fmt::Display` на яго аснове (адваротнае ад звычайных адносін паміж імі).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Друкуе літарал у выглядзе радка, які трэба канвертаваць без страт назад у той жа літарал (за выключэннем магчымага акруглення для літаралаў з плаваючай кропкай).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Адсочваецца доступ да зменных асяроддзя.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Атрымайце зменную асяроддзя і дадайце яе для стварэння інфармацыі пра залежнасці.
    /// Сістэма зборкі, якая выконвае кампілятар, будзе ведаць, што пераменная атрымлівала доступ падчас кампіляцыі, і зможа паўтарыць зборку пры змене значэння гэтай зменнай.
    ///
    /// Акрамя таго, адсочванне залежнасцей гэтая функцыя павінна быць эквівалентнай `env::var` са стандартнай бібліятэкі, за выключэннем таго, што аргумент павінен быць UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}