# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Бібліятэка для атрымання зваротных сігналаў падчас выканання для Rust.
Гэтая бібліятэка накіравана на ўзмацненне падтрымкі стандартнай бібліятэкі шляхам прадастаўлення праграмнага інтэрфейсу для працы, але яна таксама падтрымлівае простае раздрукоўванне бягучай зваротнай трасы, як panics libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Каб проста захапіць зваротную трасу і адкласці справу з ёй на пазнейшы час, вы можаце выкарыстоўваць тып `Backtrace` верхняга ўзроўню.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Аднак, калі вы хочаце атрымаць больш свабодны доступ да рэальнай функцыі адсочвання, вы можаце выкарыстоўваць непасрэдна функцыі `trace` і `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Вырашыце гэты паказальнік інструкцыі на імя сімвала
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // працягвайце пераходзіць да наступнага кадра
    });
}
```

# License

Гэты праект ліцэнзаваны любым з

 * Ліцэнзія Apache, версія 2.0, ([LICENSE-APACHE](LICENSE-APACHE) або http://www.apache.org/licenses/LICENSE-2.0)
 * Ліцэнзія MIT ([LICENSE-MIT](LICENSE-MIT) або http://opensource.org/licenses/MIT)

на ваш выбар.

### Contribution

Калі вы ясна не ўказваеце іншае, любы ўклад, наўмысна прадстаўлены для ўключэння вамі ў зваротныя адсочванні, як гэта вызначана ў ліцэнзіі Apache-2.0, будзе мець падвойную ліцэнзію, як паказана вышэй, без якіх-небудзь дадатковых умоў і ўмоў.







