use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr прымае зваротны выклік, які будзе атрымліваць указальнік dl_phdr_info для кожнага DSO, які быў звязаны з працэсам.
    // dl_iterate_phdr таксама гарантуе, што дынамічны звязвальнік заблакаваны ад пачатку да канца ітэрацыі.
    // Калі зваротны выклік вяртае ненулявое значэнне, ітэрацыя спыняецца датэрмінова.
    // 'data' будзе перададзены як трэці аргумент зваротнага выкліку пры кожным званку.
    // 'size' дае памер dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Нам трэба разабраць ідэнтыфікатар зборкі і некаторыя асноўныя дадзеныя загалоўка праграмы, што азначае, што нам таксама патрэбны трохі матэрыялу са спецыфікацыі ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Цяпер мы павінны тыражаваць біт за бітам структуру тыпу dl_phdr_info, які выкарыстоўваецца бягучым дынамічным лінкерам фуксіі.
// Chromium таксама мае гэтую мяжу ABI, а таксама crashpad.
// У рэшце рэшт мы хацелі б перавесці гэтыя выпадкі на выкарыстанне пошуку эльфаў, але нам трэба было б забяспечыць гэта ў SDK, а гэтага яшчэ не зроблена.
//
// Такім чынам, мы (і яны) затрымаліся, вымушаныя карыстацца гэтым метадам, які мае шчыльнае злучэнне з фуксіяй libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Мы не маем магчымасці даведацца, ці спраўджваюць e_phoff і e_phnum.
    // libc павінен забяспечыць гэта для нас, аднак таму бяспечна фармаваць тут зрэз.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr уяўляе сабой 64-разрадны загаловак праграмы ELF у адпаведнасці з мэтавай архітэктурай.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr уяўляе сапраўдны загаловак праграмы ELF і яе змест.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // У нас няма магчымасці праверыць, ці правільныя p_addr ці p_memsz.
    // Libc Фуксіі спачатку разбірае нататкі, аднак у сілу знаходжання тут гэтыя загалоўкі павінны быць сапраўднымі.
    //
    // NoteIter не патрабуе, каб базавыя дадзеныя былі сапраўднымі, але мяжы павінны быць сапраўднымі.
    // Мы верым у тое, што libc пераканаўся, што гэта так для нас тут.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Тып нататкі для ідэнтыфікатараў зборкі.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr уяўляе загаловак ноты ELF у канчатковай ступені мэты.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Нататка ўяўляе сабой нататку ELF (загаловак + змест).
// Імя пакінута як зрэз u8, таму што яно не заўсёды спыняецца на нуль, і rust дазваляе дастаткова лёгка праверыць, ці адпавядаюць байты.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter дазваляе бяспечна перабіраць сегмент ноты.
// Ён спыняецца, як толькі ўзнікае памылка альбо больш няма нататак.
// Калі вы перабіраеце недапушчальныя дадзеныя, ён будзе працаваць так, быццам нататкі не знойдзены.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Гэта інварыянт функцыі, які паказвае паказальнік і памер дапушчальнага дыяпазону байтаў, якія можна прачытаць.
    // Змест гэтых байтаў можа быць любым, але дыяпазон павінен быць сапраўдным, каб гэта было бяспечна.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to выраўноўвае 'x' па выраўноўванні байтаў, мяркуючы, што 'to' мае ступень 2.
// Гэта ідзе па стандартным шаблоне ў кодзе сінтаксічнага разбору C/C ++ ELF, дзе выкарыстоўваецца (x + да, 1)&-to.
// Rust не дазваляе вам адмаўляць usize, таму я выкарыстоўваю
// Пераўтварэнне дапаўненні 2, каб узнавіць гэта.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 спажывае колькасць байтаў з зрэзу (калі ён ёсць) і дадаткова гарантуе, што канчатковы зрэз правільна выраўнаваны.
// Калі альбо колькасць запытаных байтаў занадта вялікая, альбо зрэз пасля гэтага нельга перабудаваць з-за недастатковай колькасці астатніх байтаў, вяртаецца None і зрэз не змяняецца.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Гэтая функцыя не мае рэальных інварыянтаў, якія абанент павінен падтрымліваць, акрамя, магчыма, таго, каб 'bytes' павінен быць выраўнаваны па прадукцыйнасці (і для некаторых архітэктур правільнасці).
// Значэнні ў палях Elf_Nhdr могуць быць глупствам, але гэтая функцыя не гарантуе такога.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Гэта бяспечна, пакуль хапае месца, і мы толькі што пацвердзілі, што ў заяве if, таму гэта не павінна быць небяспечным.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Звярніце ўвагу, што sice_of: :<Elf_Nhdr>() заўсёды выраўноўваецца па 4 байты.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Праверце, ці дайшлі мы да канца.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Мы трансмутуем nhdr, але мы ўважліва разглядаем атрыманую структуру.
        // Мы не давяраем namesz і descsz і не прымаем небяспечных рашэнняў у залежнасці ад тыпу.
        //
        // Такім чынам, нават калі мы вывозім поўнае смецце, мы ўсё роўна павінны быць у бяспецы.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Паказвае, што сегмент з'яўляецца выканальным.
const PERM_X: u32 = 0b00000001;
/// Паказвае, што сегмент можна запісваць.
const PERM_W: u32 = 0b00000010;
/// Паказвае, што сегмент можна прачытаць.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Прадстаўляе сегмент ELF падчас выканання.
struct Segment {
    /// Дае віртуальны адрас выканання змесціва гэтага сегмента.
    addr: usize,
    /// Дае аб'ём памяці змесціва гэтага сегмента.
    size: usize,
    /// Дае модулю віртуальны адрас гэтага сегмента з файлам ELF.
    mod_rel_addr: usize,
    /// Дае дазволы, знойдзеныя ў файле ELF.
    /// Аднак гэтыя дазволы не абавязкова з'яўляюцца дазволамі, якія прысутнічаюць падчас выканання.
    flags: Perm,
}

/// Дазваляе перабіраць сегменты ад DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Прадстаўляе ELF DSO (дынамічны агульны аб'ект).
/// Гэты тып спасылаецца на дадзеныя, якія захоўваюцца ў фактычным DSO, а не робіць уласную копію.
struct Dso<'a> {
    /// Дынамічны звязвальнік заўсёды дае нам імя, нават калі імя пустое.
    /// У выпадку асноўнага выкананага файла гэта імя будзе пустым.
    /// У выпадку агульнага аб'екта гэта будзе soname (гл. DT_SONAME).
    name: &'a str,
    /// На Fuchsia практычна ўсе бінарныя файлы маюць ідэнтыфікатары зборкі, але гэта не з'яўляецца строгім патрабаваннем.
    /// Пазней няма магчымасці супаставіць інфармацыю пра DSO з рэальным файлам ELF, калі няма build_id, таму мы патрабуем, каб у кожнага DSO быў адзін.
    ///
    /// DSO без build_id ігнаруюцца.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Вяртае ітэратар над сегментамі ў гэтым DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Гэтыя памылкі кадуюць праблемы, якія ўзнікаюць пры разборы інфармацыі аб кожным DSO.
///
enum Error {
    /// NameError азначае, што адбылася памылка пры пераўтварэнні радка стылю C у радок rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError азначае, што мы не знайшлі ідэнтыфікатар зборкі.
    /// Гэта можа быць таму, што ў DSO не было ідэнтыфікатара зборкі, альбо таму, што сегмент, які змяшчае ідэнтыфікатар зборкі, быў няправільна сфармаваны.
    ///
    BuildIDError,
}

/// Выклікі альбо 'dso', альбо 'error' для кожнага DSO, звязанага ў працэс дынамічным звязваючым звяном.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, які будзе мець адзін з метадаў, які называецца foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr гарантуе, што info.name будзе паказваць на правільнае месцазнаходжанне.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Гэтая функцыя друкуе разметку сімвалізатара Фуксіі для ўсёй інфармацыі, якая змяшчаецца ў DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}