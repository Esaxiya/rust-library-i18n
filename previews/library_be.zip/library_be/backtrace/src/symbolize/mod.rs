use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Вызначце адрас з сімвалам, перадаўшы яго ў паказанае закрыццё.
///
/// Гэтая функцыя будзе шукаць дадзены адрас у такіх абласцях, як лакальная табліца сімвалаў, дынамічная табліца сімвалаў альбо інфармацыя пра адладку DWARF (у залежнасці ад актываванай рэалізацыі), каб знайсці сімвалы для выхаду.
///
///
/// Закрыццё не можа быць выклікана, калі дазвол не можа быць выканана, а таксама можа быць выклікана больш чым адзін раз у выпадку ўбудаваных функцый.
///
/// Выдадзеныя сімвалы ўяўляюць сабой выкананне ў паказаным `addr`, вяртаючы пары file/line для гэтага адраса (калі такія маюцца).
///
/// Звярніце ўвагу, што калі ў вас ёсць `Frame`, то рэкамендуецца выкарыстоўваць функцыю `resolve_frame` замест гэтай.
///
/// # Неабходныя функцыі
///
/// Для гэтай функцыі патрабуецца ўключыць функцыю `std` для `backtrace` crate, а функцыя `std` уключана па змаўчанні.
///
/// # Panics
///
/// Гэтая функцыя імкнецца ніколі не panic, але калі `cb` забяспечвае panics, то некаторыя платформы прымусяць двайны panic спыніць працэс.
/// Некаторыя платформы выкарыстоўваюць бібліятэку C, якая ўнутрана выкарыстоўвае зваротныя выклікі, якія немагчыма развязаць, таму паніка з `cb` можа выклікаць перапыненне працэсу.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // паглядзіце толькі на верхнюю рамку
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Вырашыце раней кадр захопу ў сімвал, перадаўшы сімвал у паказанае закрыццё.
///
/// Гэты функцыя выконвае тую ж функцыю, што і `resolve`, за выключэннем таго, што ён прымае `Frame` як аргумент замест адраса.
/// Гэта можа дазволіць некаторым рэалізацыям зваротнай трасіроўкі на платформе прадаставіць больш дакладную інфармацыю пра сімвал альбо інфармацыю пра ўбудаваныя кадры, напрыклад.
///
/// Рэкамендуецца выкарыстоўваць гэта, калі можаце.
///
/// # Неабходныя функцыі
///
/// Для гэтай функцыі патрабуецца ўключыць функцыю `std` для `backtrace` crate, а функцыя `std` уключана па змаўчанні.
///
/// # Panics
///
/// Гэтая функцыя імкнецца ніколі не panic, але калі `cb` забяспечвае panics, то некаторыя платформы прымусяць двайны panic спыніць працэс.
/// Некаторыя платформы выкарыстоўваюць бібліятэку C, якая ўнутрана выкарыстоўвае зваротныя выклікі, якія немагчыма развязаць, таму паніка з `cb` можа выклікаць перапыненне працэсу.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // паглядзіце толькі на верхнюю рамку
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Значэнні IP з кадраў стэка звычайна з'яўляюцца інструкцыяй (always?)*пасля* выкліку, які з'яўляецца фактычнай трасіроўкай стэка.
// Сімвалізацыя гэтага прыводзіць да таго, што нумар filename/line апярэджвае і, магчыма, у пустэчу, калі ён блізка да канца функцыі.
//
// Здаецца, гэта ў асноўным заўсёды мае месца на ўсіх платформах, таму мы заўсёды аднімаем адзін з дазволенага ip, каб вырашыць яго да папярэдняй інструкцыі выкліку, а не да інструкцыі, якая вяртаецца.
//
//
// У ідэале мы б гэтага не рабілі.
// У ідэале мы б патрабавалі, каб абаненты API `resolve` тут уручную рабілі -1 і ўлічвалі, што яны хочуць інфармацыю пра месцазнаходжанне для папярэдняй * інструкцыі, а не бягучай.
// У ідэале мы таксама раскрыем `Frame`, калі сапраўды будзем адрасам наступнай інструкцыі альбо бягучай.
//
// Пакуль што гэта даволі нішавая праблема, таму мы ўнутрана заўсёды адымаем адзін.
// Спажыўцы павінны працягваць працаваць і атрымліваць даволі добрыя вынікі, таму мы павінны быць дастаткова добрымі.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Тое ж, што і `resolve`, толькі небяспечна, бо не сінхранізавана.
///
/// Гэтая функцыя не мае гарантый сінхранізацыі, але даступная, калі функцыя `std` гэтага crate не скампілявана.
/// Для атрымання дадатковай дакументацыі і прыкладаў глядзіце функцыю `resolve`.
///
/// # Panics
///
/// Глядзіце інфармацыю пра `resolve`, каб даведацца пра асцярогі, звязаныя з панікай `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Тое ж, што і `resolve_frame`, толькі небяспечна, бо не сінхранізавана.
///
/// Гэтая функцыя не мае гарантый сінхранізацыі, але даступная, калі функцыя `std` гэтага crate не скампілявана.
/// Для атрымання дадатковай дакументацыі і прыкладаў глядзіце функцыю `resolve_frame`.
///
/// # Panics
///
/// Глядзіце інфармацыю пра `resolve_frame`, каб даведацца пра асцярогі па паводзінах `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Portrait, які ўяўляе дазвол сімвала ў файле.
///
/// Гэты Portrait выдаецца як аб'ект Portrait да закрыцця, дадзенага функцыі `backtrace::resolve`, і ён практычна адпраўляецца, бо невядома, якая рэалізацыя стаіць за ім.
///
///
/// Сімвал можа даць кантэкстную інфармацыю пра функцыю, напрыклад, імя, імя файла, нумар радка, дакладны адрас і г.д.
/// Аднак не ўся інфармацыя заўсёды даступная ў сімвале, таму ўсе метады вяртаюць `Option`.
///
///
pub struct Symbol {
    // TODO: гэта пажыццёвае абмежаванне неабходна ў рэшце рэшт захаваць да `Symbol`,
    // але гэта ў цяперашні час значныя змены.
    // На дадзены момант гэта бяспечна, бо `Symbol` раздаецца толькі па спасылцы і не можа быць кланавана.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Вяртае імя гэтай функцыі.
    ///
    /// Вяртаная структура можа быць выкарыстана для запыту розных уласцівасцей пра імя сімвала:
    ///
    ///
    /// * Рэалізацыя `Display` раздрукуе дэмантаваны сімвал.
    /// * Даступнае неапрацаванае значэнне `str` сімвала (калі яно сапраўднае utf-8).
    /// * Можна атрымаць доступ да сырых байтаў для назвы сімвала.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Вяртае пачатковы адрас гэтай функцыі.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Вяртае неапрацаванае імя файла ў выглядзе зрэзу.
    /// Гэта ў асноўным карысна для асяроддзя `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Вяртае нумар слупка, дзе гэты сімвал выконваецца ў цяперашні час.
    ///
    /// У цяперашні час толькі gimli прадастаўляе значэнне тут, і нават тады, толькі калі `filename` вяртае `Some`, і, такім чынам, ён падвяргаецца аналагічным агаворкам.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Вяртае нумар радка, дзе гэты сімвал выконваецца ў цяперашні час.
    ///
    /// Гэта вяртаецца значэнне звычайна `Some`, калі `filename` вяртае `Some`, і, такім чынам, падлягае аналагічным агаворкам.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Вяртае імя файла, дзе была вызначана гэтая функцыя.
    ///
    /// У цяперашні час гэта даступна толькі тады, калі выкарыстоўваецца libbacktrace або gimli (напрыклад,
    /// unix платформы іншыя) і калі двайковы файл кампілюецца з дапамогай debuginfo.
    /// Калі ні адно з гэтых умоў не будзе выканана, гэта, верагодна, верне `None`.
    ///
    /// # Неабходныя функцыі
    ///
    /// Для гэтай функцыі патрабуецца ўключыць функцыю `std` для `backtrace` crate, а функцыя `std` уключана па змаўчанні.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Можа быць, разабраны сімвал C++ , калі разбор сапсаванага сімвала як Rust не атрымаўся.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Абавязкова захавайце гэты нулявы памер, каб функцыя `cpp_demangle` не каштавала, калі яна адключана.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Абгортка вакол імя сімвала для прадастаўлення эрганамічных аксесуараў да дэмантаванага імя, неапрацаваных байтаў, неапрацаванага радка і г.д.
///
// Дазволіць мёртвы код, калі функцыя `cpp_demangle` не ўключана.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Стварае новую назву сімвала з неапрацаваных базавых байтаў.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Вяртае неапрацаванае імя сімвала (mangled) як `str`, калі сімвал сапраўдны utf-8.
    ///
    /// Выкарыстоўвайце рэалізацыю `Display`, калі хочаце дэмантаваную версію.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Вяртае неапрацаванае імя сімвала ў выглядзе спісу байтаў
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Гэта можа надрукаваць, калі дэмантаваны сімвал на самай справе не з'яўляецца сапраўдным, таму апрацоўвайце памылку тут хупава, не распаўсюджваючы яе вонкі.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Спроба вярнуць гэтую кэшаваную памяць, якая выкарыстоўвалася для сімвалізацыі адрасоў.
///
/// Гэты метад будзе спрабаваць вызваліць любыя глабальныя структуры дадзеных, якія інакш былі кэшаваныя глабальна альбо ў патоку, якія звычайна ўяўляюць аналізаваную інфармацыю DWARF ці падобнае.
///
///
/// # Caveats
///
/// Хоць гэтая функцыя заўсёды даступная, яна фактычна нічога не робіць для большасці рэалізацый.
/// Бібліятэкі, такія як dbghelp або libbacktrace, не прадастаўляюць сродкаў для вызвалення стану і кіравання выдзеленай памяццю.
/// У цяперашні час асаблівасць `gimli-symbolize` гэтага crate з'яўляецца адзінай функцыяй, дзе гэтая функцыя мае нейкі эфект.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}