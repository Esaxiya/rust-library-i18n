//! Стратэгія сімвалізацыі з выкарыстаннем кода разбору DWARF у libbacktrace.
//!
//! Бібліятэка libbacktrace C, якая звычайна распаўсюджваецца разам з gcc, падтрымлівае не толькі генерацыю зваротнай трасы (якую мы фактычна не выкарыстоўваем), але і сімвалізацыю зваротнай трасы і апрацоўку карлікавай інфармацыі пра адладку пра такія рэчы, як убудаваныя кадры і шмат чаго іншага.
//!
//!
//! Гэта адносна складана з-за мноства розных праблем, але асноўная ідэя:
//!
//! * Спачатку мы называем `backtrace_syminfo`.Калі мы можам, гэта атрымлівае інфармацыю пра сімвал з дынамічнай табліцы сімвалаў.
//! * Далей мы называем `backtrace_pcinfo`.Гэта разбярэ табліцы debuginfo, калі яны даступныя, і дазволіць нам аднавіць інфармацыю пра ўбудаваныя кадры, імёны файлаў, нумары радкоў і г.д.
//!
//! Ёсць мноства хітрасцей, каб прывесці табліцы карлікаў у libbacktrace, але, спадзяюся, гэта яшчэ не канец свету, і гэта дастаткова зразумела, калі прачытаць ніжэй.
//!
//! Гэта стратэгія сімвалізацыі па змаўчанні для платформаў, якія не з'яўляюцца MSVC і не OSX.У libstd гэта стратэгія па змаўчанні для OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Калі магчыма, аддайце перавагу назве `function`, якая паходзіць ад debuginfo і, як правіла, можа быць больш дакладнай для ўбудаваных кадраў, напрыклад.
                // Калі гэтага няма, вярніцеся да назвы табліцы сімвалаў, указанай у `symname`.
                //
                // Звярніце ўвагу, што часам `function` можа адчуваць сябе некалькі менш дакладна, напрыклад, уключаны ў спіс `try<i32,closure>`, чым `std::panicking::try::do_call`.
                //
                // Не зусім зразумела, чаму, але ў цэлым назва `function` здаецца больш дакладнай.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // пакуль нічога не рабіць
}

/// Тып указальніка `data` перайшоў у `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Пасля таго, як гэты зваротны выклік выклікаецца з `backtrace_syminfo`, калі мы пачынаем вырашаць, мы пераходзім далей да выкліку `backtrace_pcinfo`.
    // Функцыя `backtrace_pcinfo` будзе звяртацца да інфармацыі аб адладцы і рабіць спробы аднаўляць інфармацыю file/line, а таксама ўбудаваныя кадры.
    // Звярніце ўвагу, што `backtrace_pcinfo` можа пацярпець няўдачу альбо не зрабіць шмат, калі няма інфармацыі пра адладку, таму, калі гэта адбудзецца, мы абавязкова выклічам зваротны выклік прынамсі з адным сімвалам з `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Тып указальніка `data` перайшоў у `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace падтрымлівае стварэнне стану, але не падтрымлівае разбурэнне стану.
// Я асабіста разумею, што дзяржава азначае стварэнне, а потым жыццё вечна.
//
// Я хацеў бы зарэгістраваць апрацоўшчык at_exit(), які ачышчае гэты стан, але libbacktrace не дазваляе гэтага зрабіць.
//
// З гэтымі абмежаваннямі гэтая функцыя мае статычна кэшаванае стан, якое вылічваецца пры першым запыце.
//
// Памятаеце, што зваротная траса ўсё адбываецца паслядоўна (адзін глабальны замак).
//
// Звярніце ўвагу, недахоп сінхранізацыі тут звязаны з патрабаваннем, каб `resolve` сінхранізаваўся звонку.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Не выкарыстоўвайце бяспечныя магчымасці libbacktrace, паколькі мы заўсёды называем яго сінхранізавана.
        //
        0,
        error_cb,
        ptr::null_mut(), // няма дадатковых дадзеных
    );

    return STATE;

    // Звярніце ўвагу, што для таго, каб libbacktrace наогул працаваў, яму трэба знайсці інфармацыю пра адладку DWARF для бягучага выкананага файла.Звычайна гэта адбываецца з дапамогай шэрагу механізмаў, уключаючы, але не абмяжоўваючыся:
    //
    // * /proc/self/exe на падтрымоўваных платформах
    // * Імя файла перададзена відавочна пры стварэнні стану
    //
    // Бібліятэка libbacktrace-гэта вялікая пачка кода C.Гэта, натуральна, азначае, што ў яго ёсць уразлівасці ў галіне бяспекі памяці, асабліва пры апрацоўцы дэфармаванага файла дэфармацыі.
    // Гістарычна Libstd сутыкаўся з многімі з іх.
    //
    // Калі выкарыстоўваецца /proc/self/exe, мы звычайна можам ігнараваць іх, бо мы мяркуем, што libbacktrace-гэта "mostly correct", і ў адваротным выпадку не робіць дзіўных рэчаў з інфармацыяй пра адладку карлікавага "attempted to be correct".
    //
    //
    // Аднак, калі мы перадаем імя файла, гэта магчыма на некаторых платформах (напрыклад, BSD), дзе шкоднасны акцёр можа выклікаць размяшчэнне адвольнага файла ў гэтым месцы.
    // Гэта азначае, што калі мы скажам libbacktrace пра імя файла, ён можа выкарыстоўваць адвольны файл, магчыма, выклікаючы сегментацыйныя памылкі.
    // Калі мы нічога не скажам libbacktrace, ён нічога не зробіць на платформах, якія не падтрымліваюць такія шляху, як /proc/self/exe!
    //
    // Улічваючы ўсё, што мы стараемся як мага больш *не* перадаваць імя файла, але мы павінны на платформах, якія зусім не падтрымліваюць /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Звярніце ўвагу, што ў ідэале мы б выкарыстоўвалі `std::env::current_exe`, але нам не патрабуецца `std`.
            //
            // Выкарыстоўвайце `_NSGetExecutablePath` для загрузкі бягучага выканальнага шляху ў статычную вобласць (калі яна занадта малая, проста адмоўцеся).
            //
            //
            // Звярніце ўвагу, што мы сур'ёзна давяраем libbacktrace тут, каб не памерці на карумпаваных выкананых файлах, але гэта, безумоўна, робіць ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows мае рэжым адкрыцця файлаў, дзе пасля яго адкрыцця яго нельга выдаліць.
            // Гэта ўвогуле тое, што мы хочам тут, таму што мы хочам пераканацца, што наш выкананы файл не змяняецца з-пад нас пасля таго, як мы перадаем яго ў libbacktrace, спадзяючыся змякчыць магчымасць перадачы адвольных дадзеных у libbacktrace (які можа быць няправільна апрацаваны).
            //
            //
            // Улічваючы, што мы тут крыху танцуем, каб паспрабаваць атрымаць нейкі замак на ўласным вобразе:
            //
            // * Атрымайце ручку бягучага працэсу, загрузіце яго імя файла.
            // * Адкрыйце файл з такой назвай з патрэбнымі сцягамі.
            // * Перазагрузіце імя файла бягучага працэсу, пераканаўшыся, што яно аднолькавае
            //
            // Калі ўсё гэта праходзіць, мы тэарэтычна адкрылі файл нашага працэсу, і мы гарантаваны, што гэта не зменіцца.FWIW куча гэтага капіюецца з libstd гістарычна, таму гэта мая лепшая інтэрпрэтацыя таго, што адбывалася.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Гэта жыве ў статычнай памяці, таму мы можам вярнуць яго ..
                static mut BUF: [i8; N] = [0; N];
                // ... і гэта жыве ў стэку, бо гэта часова
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // наўмысна ўцечкі `handle` сюды, таму што адкрыццё павінна захаваць наш замак на імя гэтага файла.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Мы хочам вярнуць зрэз, які спыняецца на нуль, таму, калі ўсё было запоўнена і яно роўна агульнай даўжыні, прыраўнуйце да адмовы.
                //
                //
                // У адваротным выпадку пры вяртанні поспеху пераканайцеся, што нулявы байт уключаны ў зрэз.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // памылкі зваротнага адсочвання ў цяперашні час зачышчаюцца пад дываном
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Патэлефануйце ў API `backtrace_syminfo`, які (з чытання кода) павінен выклікаць `syminfo_cb` роўна адзін раз (альбо, магчыма, памыліцца).
    // Затым мы працуем з большым у рамках `syminfo_cb`.
    //
    // Звярніце ўвагу, што мы робім гэта, так як `syminfo` будзе звяртацца да табліцы сімвалаў, знаходзячы імёны сімвалаў, нават калі ў двайковым файле няма інфармацыі пра адладку.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}