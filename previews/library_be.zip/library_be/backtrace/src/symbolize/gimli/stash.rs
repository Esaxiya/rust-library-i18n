// зараз выкарыстоўваецца толькі на Linux, таму дазваляйце мёртвы код у любым іншым месцы
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Просты размеркавальнік арэны для байтавых буфераў.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Выдзяляе буфер зададзенага памеру і вяртае зменлівую спасылку на яго.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // БЯСПЕКА: гэта адзіная функцыя, якая калі-небудзь стварае зменлівую
        // спасылка на `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // БЯСПЕКА: мы ніколі не выдаляем элементы з `self.buffers`, таму спасылка
        // да дадзеных у любым буферы будзе жыць да тых часоў, як гэта робіць `self`.
        &mut buffers[i]
    }
}