#![feature(no_core)]
#![no_core]

// Глядзіце rustc-std-workspace-core, дзеля чаго патрэбны гэты crate.

// Перайменаваць crate, каб пазбегнуць канфлікту з модулем alloc у liballoc.
extern crate alloc as foo;

pub use foo::*;