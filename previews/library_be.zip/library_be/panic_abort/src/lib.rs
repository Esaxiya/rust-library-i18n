//! Рэалізацыя Rust panics праз перапыненне працэсу
//!
//! У параўнанні з рэалізацыяй з дапамогай раскручвання, гэты crate *нашмат* прасцей!Гэта, як гаворыцца, не настолькі ўніверсальны, але тут ідзе!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" карысную нагрузку і падкладку да адпаведнага перапынення на адпаведнай платформе.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // патэлефануйце ў std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // На Windows выкарыстоўвайце механізм __fastfail, характэрны для працэсара.У Windows 8 і больш позняй версіі гэта неадкладна спыніць працэс без запуску апрацоўшчыкаў выключэнняў у працэсе.
            // У больш ранніх версіях Windows гэтая паслядоўнасць інструкцый будзе разглядацца як парушэнне доступу, спыняючы працэс, але не абавязкова абыходзячы ўсе апрацоўшчыкі выключэнняў.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: гэта такая ж рэалізацыя, як і ў `abort_internal` libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Гэта ... трохі дзіўна.Tl; dr;у тым, што гэта патрабуецца для правільнай спасылкі, больш доўгае тлумачэнне прыводзіцца ніжэй.
//
// Зараз двайковыя файлы libcore/libstd, якія мы пастаўляем, сабраны з `-C panic=unwind`.Гэта робіцца для таго, каб бінарныя файлы былі максімальна сумяшчальныя з максімальнай колькасцю сітуацый.
// Аднак кампілятар патрабуе "personality function" для ўсіх функцый, скампіляваных з `-C panic=unwind`.Гэтая асобасная функцыя закадавана ў сімвал `rust_eh_personality` і вызначаецца элементам `eh_personality` lang.
//
// So...
// чаму б проста не вызначыць гэты элемент lang тут?Добрае пытанне!Тое, як звязаны час выканання panic, на самай справе крыху тонкае тым, што яны з'яўляюцца "sort of" у краме crate кампілятара, але фактычна звязаны толькі ў тым выпадку, калі на самой справе не звязана.
//
// Гэта азначае, што і crate, і panic_unwind crate могуць з'явіцца ў сховішчы crate кампілятара, і калі абодва вызначаюць элемент `eh_personality` lang, гэта выкліча памылку.
//
// Каб справіцца з гэтым, кампілятару патрабуецца толькі тое, што `eh_personality` вызначаны, калі час выканання panic, да якога звязана, з'яўляецца часам разгортвання, і ў адваротным выпадку яго не трэба вызначаць (гэта правільна).
// У гэтым выпадку, аднак, гэтая бібліятэка проста вызначае гэты сімвал, каб дзесьці была хоць нейкая асоба.
//
// Па сутнасці, гэты сімвал проста вызначаны для падключэння да бінарных файлаў libcore/libstd, але яго ніколі не трэба выклікаць, бо мы наогул не звязваем час разгортвання.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // У x86_64-pc-windows-gnu мы выкарыстоўваем уласную функцыю асобы, якая павінна вярнуць `ExceptionContinueSearch`, калі мы перадаем усе нашы кадры.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Як і вышэй, гэта адпавядае элементу `eh_catch_typeinfo` lang, які ў цяперашні час выкарыстоўваецца толькі ў Emscripten.
    //
    // Паколькі panics не стварае выключэнняў, а замежныя выключэнні ў цяперашні час з'яўляюцца UB з -C panic=перапыніць (хаця гэта можа быць зменена), любыя выклікі catch_unwind ніколі не будуць выкарыстоўваць гэты typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Гэтыя два выклікаюцца нашымі аб'ектамі запуску на i686-pc-windows-gnu, але ім нічога не трэба рабіць, таму целы не працуюць.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}