# `rustc-std-workspace-core` crate

Гэты crate-гэта простая і пустая crate, якая проста залежыць ад `libcore` і рээкспартуе ўсё яе змесціва.
crate-гэта сутнасць пашырэння магчымасцей стандартнай бібліятэкі залежыць ад crates ад crates.io

Crates на crates.io, ад якой залежыць стандартная бібліятэка, павінен залежаць ад `rustc-std-workspace-core` crate ад crates.io, які пусты.

Мы выкарыстоўваем `[patch]`, каб замяніць яго на гэты crate у гэтым сховішчы.
У выніку crates на crates.io вывядзе залежнасць edge да `libcore`, версія, вызначаная ў гэтым сховішчы.
Гэта павінна зрабіць усе краю залежнасці, каб Cargo паспяхова будаваў crates!

Звярніце ўвагу, што crates на crates.io павінен залежаць ад гэтага crate з імем `core`, каб усё працавала карэктна.Для гэтага яны могуць выкарыстоўваць:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

З дапамогай ключа `package` crate перайменаваны ў `core`, гэта значыць будзе выглядаць як

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

калі Cargo выклікае кампілятар, задавальняючы няяўную дырэктыву `extern crate core`, якую ўводзіць кампілятар.




