use crate::marker::Unsize;

/// Trait, які паказвае, што гэта ўказальнік альбо абгортка для аднаго, дзе можна змяніць памер указальніка.
///
/// Для больш падрабязнай інфармацыі глядзіце [DST coercion RFC][dst-coerce] і [the nomicon entry on coercion][nomicon-coerce].
///
/// Для тыпаў убудаваных паказальнікаў паказальнікі на `T` прымушаюць паказальнікі на `U`, калі `T: Unsize<U>`, пераўтвараючыся з тонкага ў тлушчавы.
///
/// Для карыстацкіх тыпаў прымус тут працуе шляхам прымусу `Foo<T>` да `Foo<U>` пры ўмове, што існуе impl `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Такі impl можа быць запісаны толькі ў тым выпадку, калі `Foo<T>` мае толькі адно нефантаматычнае поле з удзелам `T`.
/// Калі тып гэтага поля `Bar<T>`, павінна існаваць рэалізацыя `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Прымус будзе дзейнічаць шляхам прымусу поля `Bar<T>` да `Bar<U>` і запаўнення астатніх палёў з `Foo<T>` для стварэння `Foo<U>`.
/// Гэта эфектыўна разбярэцца да поля ўказальніка і прымусіць яго.
///
/// Як правіла, для разумных паказальнікаў вы будзеце ўкараняць `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, а дадатковы `?Sized` будзе прывязаны да самога `T`.
/// Для тыпаў абгортак, якія непасрэдна ўбудоўваюць `T`, такіх як `Cell<T>` і `RefCell<T>`, вы можаце непасрэдна ўкараніць `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Гэта дазволіць працаваць прымусам такіх тыпаў, як `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] выкарыстоўваецца для пазначэння тыпаў, якія можна прымусіць да пераходу на летняе час, калі знаходзяцца за паказальнікамі.Ён рэалізуецца аўтаматычна кампілятарам.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Гэта выкарыстоўваецца для бяспекі аб'екта, каб праверыць, ці можа быць адпраўлены тып прымача метаду.
///
/// Прыклад рэалізацыі Portrait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}