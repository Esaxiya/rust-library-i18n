/// Выкарыстоўваецца для нязменных аперацый разметкі, напрыклад `*v`.
///
/// У дадатак да таго, што `Deref` выкарыстоўваецца для відавочных аперацый разметкі з аператарам (unary) `*` ва ўмовах нязменнага кантэксту, кампілятар у многіх абставінах выкарыстоўвае і імпліцытна.
/// Гэты механізм называецца ['`Deref` coercion'][more].
/// У зменлівых кантэкстах выкарыстоўваецца [`DerefMut`].
///
/// Укараненне `Deref` для разумных паказальнікаў робіць доступ да дадзеных за імі зручным, таму яны рэалізуюць `Deref`.
/// З іншага боку, правілы ў дачыненні да `Deref` і [`DerefMut`] былі распрацаваны спецыяльна для размяшчэння разумных паказальнікаў.
/// З-за гэтага **`Deref` варта ўкараняць толькі для разумных паказальнікаў**, каб пазбегнуць блытаніны.
///
/// Па аналагічных прычынах **гэты Portrait ніколі не павінен выйсці з ладу**.Збой падчас разметкі спасылак можа выклікаць вялікую заблытанасць, калі `Deref` выклікаецца няяўна.
///
/// # Больш падрабязна пра прымус `Deref`
///
/// Калі `T` рэалізуе `Deref<Target = U>`, а `x`-гэта значэнне тыпу `T`, то:
///
/// * У нязменным кантэксце `*x` (дзе `T` не з'яўляецца ні спасылкай, ні неапрацаваным паказальнікам) эквівалентны `* Deref::deref(&x)`.
/// * Значэнні тыпу `&T` прыводзяцца да значэнняў тыпу `&U`
/// * `T` няяўна рэалізуе ўсе метады (immutable) тыпу `U`.
///
/// Для атрымання больш падрабязнай інфармацыі наведайце [the chapter in *The Rust Programming Language*][book], а таксама даведачныя раздзелы па [the dereference operator][ref-deref-op], [method resolution] і [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура з адзіным полем, якая даступная шляхам адмена спасылкі на структуру.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Атрыманы тып пасля разметкі.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferences значэнне.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Выкарыстоўваецца для зменных аперацый разметкі, як у `*v = 1;`.
///
/// У дадатак да таго, што `DerefMut` выкарыстоўваецца для відавочных аперацый разметкі з аператарам (unary) `*` у зменлівых кантэкстах, кампілятар у многіх абставінах выкарыстоўвае і імпліцытна.
/// Гэты механізм называецца ['`Deref` coercion'][more].
/// У нязменным кантэксце выкарыстоўваецца [`Deref`].
///
/// Рэалізацыя `DerefMut` для разумных паказальнікаў робіць зручным мутаванне дадзеных, таму яны рэалізуюць `DerefMut`.
/// З іншага боку, правілы ў дачыненні да [`Deref`] і `DerefMut` былі распрацаваны спецыяльна для размяшчэння разумных паказальнікаў.
/// З-за гэтага **`DerefMut` варта ўкараняць толькі для разумных паказальнікаў**, каб пазбегнуць блытаніны.
///
/// Па аналагічных прычынах **гэты Portrait ніколі не павінен выйсці з ладу**.Збой падчас разметкі спасылак можа выклікаць вялікую заблытанасць, калі `DerefMut` выклікаецца няяўна.
///
/// # Больш падрабязна пра прымус `Deref`
///
/// Калі `T` рэалізуе `DerefMut<Target = U>`, а `x`-гэта значэнне тыпу `T`, то:
///
/// * У зменлівых кантэкстах `*x` (дзе `T` не з'яўляецца ні спасылкай, ні неапрацаваным паказальнікам) эквівалентны `* DerefMut::deref_mut(&mut x)`.
/// * Значэнні тыпу `&mut T` прыводзяцца да значэнняў тыпу `&mut U`
/// * `T` няяўна рэалізуе ўсе метады (mutable) тыпу `U`.
///
/// Для атрымання больш падрабязнай інфармацыі наведайце [the chapter in *The Rust Programming Language*][book], а таксама даведачныя раздзелы па [the dereference operator][ref-deref-op], [method resolution] і [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура з адзіным полем, якую можна змяніць шляхам дэрэферырацыі структуры.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Змяняецца дэрэферэнцыя значэння.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Паказвае, што структура можа быць выкарыстана ў якасці прыёмніка метада без функцыі `arbitrary_self_types`.
///
/// Гэта рэалізавана з дапамогай тыпаў указальнікаў stdlib, такіх як `Box<T>`, `Rc<T>`, `&T` і `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}