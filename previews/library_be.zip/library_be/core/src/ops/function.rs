/// Версія аператара выкліку, які прымае нязменны прымач.
///
/// Экземпляры `Fn` можна выклікаць неаднаразова, не мутуючы стан.
///
/// *Гэта Portrait (`Fn`) нельга блытаць з [function pointers] (`fn`).*
///
/// `Fn` рэалізуецца аўтаматычна шляхам закрыцця, якое бярэ толькі нязменныя спасылкі на захопленыя зменныя альбо наогул нічога не захоплівае, а таксама (safe) [function pointers] (з некаторымі агаворкамі, больш падрабязна гл. у іх дакументацыі).
///
/// Акрамя таго, для любога тыпу `F`, які рэалізуе `Fn`, `&F` таксама рэалізуе `Fn`.
///
/// Паколькі і [`FnMut`], і [`FnOnce`] з'яўляюцца супертыпамі `Fn`, любы экземпляр `Fn` можа быць выкарыстаны ў якасці параметра, дзе чакаецца [`FnMut`] або [`FnOnce`].
///
/// Выкарыстоўвайце `Fn` у якасці прывязкі, калі вы хочаце прыняць параметр функцыянальнага тыпу і трэба выклікаць яго неаднаразова і без мутацыйнага стану (напрыклад, пры адначасовым выкліку).
/// Калі вам не патрэбныя такія строгія патрабаванні, выкарыстоўвайце [`FnMut`] або [`FnOnce`] як абмежаванні.
///
/// Для атрымання дадатковай інфармацыі па гэтай тэме глядзіце [chapter on closures in *The Rust Programming Language*][book].
///
/// Таксама варта адзначыць спецыяльны сінтаксіс для `Fn` traits (напрыклад,
/// `Fn(usize, bool) -> usize`).Тыя, хто цікавіцца тэхнічнымі дэталямі гэтага, могуць звярнуцца да [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Выклік закрыцця
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Выкарыстанне параметра `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так што regex можа разлічваць на гэты `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Выконвае аперацыю выкліку.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Версія аператара выкліку, які прымае зменлівы прымач.
///
/// Экземпляры `FnMut` можна выклікаць неаднаразова і могуць змяняць стан.
///
/// `FnMut` рэалізуецца аўтаматычна шляхам закрыццяў, якія прымаюць зменныя спасылкі на захопленыя зменныя, а таксама ўсіх тыпаў, якія рэалізуюць [`Fn`], напрыклад, (safe) [function pointers] (паколькі `FnMut`-супертрэт [`Fn`]).
/// Акрамя таго, для любога тыпу `F`, які рэалізуе `FnMut`, `&mut F` таксама рэалізуе `FnMut`.
///
/// Паколькі [`FnOnce`]-супертрэт `FnMut`, любы экземпляр `FnMut` можа быць выкарыстаны там, дзе чакаецца [`FnOnce`], а паколькі [`Fn`]-гэта субпартрэт `FnMut`, любы экземпляр [`Fn`] можна выкарыстоўваць там, дзе чакаецца `FnMut`.
///
/// Выкарыстоўвайце `FnMut` у якасці прывязанага, калі вы хочаце прыняць параметр функцыянальнага тыпу і трэба неаднаразова выклікаць яго, дазваляючы яму мутаваць стан.
/// Калі вы не хочаце, каб параметр мутаваў стан, выкарыстоўвайце [`Fn`] у якасці звязанага;калі вам не трэба тэлефанаваць паўторна, выкарыстоўвайце [`FnOnce`].
///
/// Для атрымання дадатковай інфармацыі па гэтай тэме глядзіце [chapter on closures in *The Rust Programming Language*][book].
///
/// Таксама варта адзначыць спецыяльны сінтаксіс для `Fn` traits (напрыклад,
/// `Fn(usize, bool) -> usize`).Тыя, хто цікавіцца тэхнічнымі дэталямі гэтага, могуць звярнуцца да [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Выклік мутаванага захопу закрыцця
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Выкарыстанне параметра `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так што regex можа разлічваць на гэты `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Выконвае аперацыю выкліку.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Версія аператара выкліку, якая прымае дадатковы прыёмнік.
///
/// Можна выклікаць асобнікі `FnOnce`, але яны не могуць быць выкліканы некалькі разоў.З-за гэтага, калі адзінае, што вядома пра тып, гэта тое, што ён рэалізуе `FnOnce`, яго можна выклікаць толькі адзін раз.
///
/// `FnOnce` рэалізуецца аўтаматычна шляхам закрыццяў, якія могуць спажываць захопленыя зменныя, а таксама ўсіх тыпаў, якія рэалізуюць [`FnMut`], напрыклад, (safe) [function pointers] (паколькі `FnOnce`-супертрэт [`FnMut`]).
///
///
/// Паколькі і [`Fn`], і [`FnMut`] з'яўляюцца падменкамі `FnOnce`, любы экземпляр [`Fn`] або [`FnMut`] можа быць выкарыстаны там, дзе чакаецца `FnOnce`.
///
/// Выкарыстоўвайце `FnOnce` у якасці прывязкі, калі вы хочаце прыняць параметр функцыянальнага тыпу і вам трэба выклікаць яго толькі адзін раз.
/// Калі вам трэба неаднаразова выклікаць параметр, выкарыстоўвайце [`FnMut`] як прывязаны;калі вам таксама трэба, каб не мутаваць стан, выкарыстоўвайце [`Fn`].
///
/// Для атрымання дадатковай інфармацыі па гэтай тэме глядзіце [chapter on closures in *The Rust Programming Language*][book].
///
/// Таксама варта адзначыць спецыяльны сінтаксіс для `Fn` traits (напрыклад,
/// `Fn(usize, bool) -> usize`).Тыя, хто цікавіцца тэхнічнымі дэталямі гэтага, могуць звярнуцца да [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Выкарыстанне параметра `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` спажывае захопленыя зменныя, таму яго нельга запускаць больш за адзін раз.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Спроба зноў выклікаць `func()` выкліча памылку `use of moved value` для `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` у гэты момант больш нельга выклікаць
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так што regex можа разлічваць на гэты `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Вяртаецца тып пасля аператара выкліку.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Выконвае аперацыю выкліку.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}