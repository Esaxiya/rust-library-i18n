//! Аператары, якія можна загрузіць.
//!
//! Рэалізацыя гэтых traits дазваляе перагрузіць пэўныя аператары.
//!
//! Некаторыя з гэтых traits імпартуюцца prelude, таму яны даступныя ў кожнай праграме Rust.Перагружаць можна толькі аператары, падтрыманыя traits.
//! Напрыклад, аператар складання (`+`) можа быць перагружаны праз [`Add`] Portrait, але паколькі аператар прысваення (`=`) не мае падстаўкі Portrait, няма магчымасці перагрузіць яго семантыку.
//! Акрамя таго, гэты модуль не прадугледжвае механізму стварэння новых аператараў.
//! Калі патрабуецца бязменная перагрузка альбо карыстацкія аператары, вам варта звярнуць увагу на макрасы ці ўбудовы кампілятара, каб пашырыць сінтаксіс Rust.
//!
//! Рэалізацыі аператара traits не павінны здзіўляць у адпаведных кантэкстах, маючы на ўвазе іх звычайныя значэнні і [operator precedence].
//! Напрыклад, пры рэалізацыі [`Mul`] аперацыя павінна мець нейкае падабенства множання (і падзяляць чаканыя ўласцівасці, такія як асацыятыўнасць).
//!
//! Звярніце ўвагу, што аператары `&&` і `||` атрымліваюць кароткае замыканне, гэта значыць яны ацэньваюць свой другі аперанд толькі ў тым выпадку, калі гэта спрыяе выніку.Паколькі traits не забяспечвае такога паводзіны, `&&` і `||` не падтрымліваюцца як аператары, якія можна загружаць.
//!
//! Шмат хто з аператараў бярэ свае аперанды па вартасці.У неагульных кантэкстах, якія ўключаюць убудаваныя тыпы, гэта звычайна не з'яўляецца праблемай.
//! Аднак выкарыстанне гэтых аператараў у агульным кодзе патрабуе пэўнай увагі, калі значэнні трэба выкарыстоўваць паўторна, а не дазваляць аператарам іх спажываць.Адзін з варыянтаў-час ад часу выкарыстоўваць [`clone`].
//! Іншы варыянт-абапірацца на тыпы, якія прадастаўляюць дадатковыя рэалізацыі аператараў для даведак.
//! Напрыклад, для вызначанага карыстальнікам тыпу `T`, які павінен падтрымліваць даданне, напэўна, было б добра, каб `T` і `&T` рэалізоўвалі traits [`Add<T>`][`Add`] і [`Add<&T>`][`Add`], каб агульны код можна было пісаць без лішняга кланавання.
//!
//!
//! # Examples
//!
//! У гэтым прыкладзе ствараецца структура `Point`, якая рэалізуе [`Add`] і [`Sub`], а затым дэманструе складанне і адніманне двух `Кропак '.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Глядзіце дакументацыю для кожнага Portrait для прыкладу рэалізацыі.
//!
//! [`Fn`], [`FnMut`] і [`FnOnce`] traits рэалізаваны па тыпах, якія можна выклікаць як функцыі.Звярніце ўвагу, што [`Fn`] займае `&self`, [`FnMut`]-`&mut self`, а [`FnOnce`]-`self`.
//! Яны адпавядаюць тром відам метадаў, якія можна выклікаць у асобніку: выклік па спасылцы, выклік па зменлівай спасылцы і выклік па значэнні.
//! Самае распаўсюджанае выкарыстанне гэтых traits-дзейнічаць як межы функцыяў больш высокага ўзроўню, якія прымаюць функцыі альбо закрыцці ў якасці аргументаў.
//!
//! Прымаючы [`Fn`] як параметр:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Прымаючы [`FnMut`] як параметр:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Прымаючы [`FnOnce`] як параметр:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` спажывае захопленыя зменныя, таму яго нельга запускаць больш за адзін раз
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Спроба зноў выклікаць `func()` выкліча памылку `use of moved value` для `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` у гэты момант больш нельга выклікаць
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;