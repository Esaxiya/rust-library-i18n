/// Portrait для налады паводзін аператара `?`.
///
/// Тып, які рэалізуе `Try`-гэта той, які мае кананічны спосаб разглядаць яго з пункту гледжання раздвоенасці success/failure.
/// Гэты Portrait дазваляе як здабываць гэтыя значэнні паспяховасці альбо няўдачы з існуючага асобніка, так і ствараць новы экземпляр з значэння паспяховасці або няўдачы.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Тып гэтага значэння, калі ён разглядаецца як паспяховы.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Тып гэтага значэння пры разглядзе як няўдалым.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Прымяняе аператар "?".Вяртанне `Ok(t)` азначае, што выкананне павінна працягвацца звычайна, а вынікам `?` з'яўляецца значэнне `t`.
    /// Вяртанне `Err(e)` азначае, што выкананне павінна branch да самага ўнутранага закрыцця `catch`, альбо вяртанне з функцыі.
    ///
    /// Калі вяртаецца вынік `Err(e)`, значэнне `e` будзе "wrapped" у тыпе звароту ахоўнай вобласці (які сам павінен рэалізаваць `Try`).
    ///
    /// У прыватнасці, вяртаецца значэнне `X::from_error(From::from(e))`, дзе `X`-тып вяртання функцыі, якая заключае.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Абгарніце значэнне памылкі для пабудовы складанага выніку.
    /// Напрыклад, `Result::Err(x)` і `Result::from_error(x)` эквівалентныя.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Абгарніце значэнне ОК, каб пабудаваць састаўны вынік.
    /// Напрыклад, `Result::Ok(x)` і `Result::from_ok(x)` эквівалентныя.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}