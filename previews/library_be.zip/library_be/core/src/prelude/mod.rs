//! Лібкор prelude
//!
//! Гэты модуль прызначаны для карыстальнікаў libcore, якія таксама не спасылаюцца на libstd.
//! Гэты модуль імпартуецца па змаўчанні, калі `#![no_std]` выкарыстоўваецца такім жа чынам, як і стандартная бібліятэка prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Версія ядра prelude 2015 года.
///
/// Глядзіце [module-level documentation](self) для атрымання дадатковай інфармацыі.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Версія ядра 2018 prelude.
///
/// Глядзіце [module-level documentation](self) для атрымання дадатковай інфармацыі.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Версія ядра prelude 2021 года.
///
/// Глядзіце [module-level documentation](self) для атрымання дадатковай інфармацыі.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Дадайце яшчэ рэчы.
}