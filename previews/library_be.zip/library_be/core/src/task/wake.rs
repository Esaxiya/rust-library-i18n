#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` дазваляе рэалізатару выканаўцы задачы стварыць [`Waker`], які забяспечвае індывідуальнае паводзіны абуджэння.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ён складаецца з указальніка дадзеных і [virtual function pointer table (vtable)][vtable], які наладжвае паводзіны `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Паказальнік дадзеных, які можа выкарыстоўвацца для захоўвання адвольных дадзеных, як патрабуе выканаўца.
    /// Гэта можа быць напрыклад
    /// сціраны тып паказальнік на `Arc`, які звязаны з задачай.
    /// Значэнне гэтага поля перадаецца ўсім функцыям, якія ўваходзяць у vtable як першы параметр.
    ///
    data: *const (),
    /// Табліца віртуальных паказальнікаў функцый, якая наладжвае паводзіны гэтага вакера.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Стварае новы `RawWaker` з прадстаўленага паказальніка `data` і `vtable`.
    ///
    /// Паказальнік `data` можа выкарыстоўвацца для захоўвання адвольных дадзеных, як патрабуе выканаўца.Гэта можа быць напрыклад
    /// сціраны тып паказальнік на `Arc`, які звязаны з задачай.
    /// Значэнне гэтага паказальніка будзе перададзена ўсім функцыям, якія ўваходзяць у `vtable` у якасці першага параметру.
    ///
    /// `vtable` наладжвае паводзіны `Waker`, які ствараецца з `RawWaker`.
    /// Для кожнай аперацыі на `Waker` будзе выклікана звязаная з гэтым функцыя ў `vtable` асноўнага `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Табліца паказальнікаў віртуальных функцый (vtable), якая вызначае паводзіны [`RawWaker`].
///
/// Паказальнік, які перадаецца на ўсе функцыі ўнутры vtable,-гэта паказальнік `data` ад які змяшчае аб'екта [`RawWaker`].
///
/// Функцыі ўнутры гэтай структуры прызначаны толькі для выкліку ўказальніка `data` правільна пабудаванага аб'екта [`RawWaker`] знутры рэалізацыі [`RawWaker`].
/// Выклік адной з функцый, якія змяшчаюцца, з выкарыстаннем любога іншага паказальніка `data` прывядзе да нявызначаных паводзін.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Гэтая функцыя будзе выклікана пры кланаванні [`RawWaker`], напрыклад, калі кладуецца [`Waker`], у якім захоўваецца [`RawWaker`].
    ///
    /// Рэалізацыя гэтай функцыі павінна захоўваць усе рэсурсы, неабходныя для гэтага дадатковага асобніка [`RawWaker`] і звязанай з ім задачы.
    /// Выклік `wake` на атрыманым [`RawWaker`] павінен прывесці да абуджэння той самай задачы, якая была б абуджана арыгінальнай [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Гэтая функцыя будзе выклікана пры выкліку `wake` на [`Waker`].
    /// Ён павінен абудзіць задачу, звязаную з гэтым [`RawWaker`].
    ///
    /// Рэалізацыя гэтай функцыі павінна забяспечыць вызваленне любых рэсурсаў, звязаных з гэтым асобнікам [`RawWaker`] і звязанай з ім задачай.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Гэтая функцыя будзе выклікана пры выкліку `wake_by_ref` на [`Waker`].
    /// Ён павінен абудзіць задачу, звязаную з гэтым [`RawWaker`].
    ///
    /// Гэтая функцыя падобная на `wake`, але не павінна ўжываць паказальнік дадзеных.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Гэтая функцыя выклікаецца пры падзенні [`RawWaker`].
    ///
    /// Рэалізацыя гэтай функцыі павінна забяспечыць вызваленне любых рэсурсаў, звязаных з гэтым асобнікам [`RawWaker`] і звязанай з ім задачай.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Стварае новы `RawWakerVTable` з прадстаўленых функцый `clone`, `wake`, `wake_by_ref` і `drop`.
    ///
    /// # `clone`
    ///
    /// Гэтая функцыя будзе выклікана пры кланаванні [`RawWaker`], напрыклад, калі кладуецца [`Waker`], у якім захоўваецца [`RawWaker`].
    ///
    /// Рэалізацыя гэтай функцыі павінна захоўваць усе рэсурсы, неабходныя для гэтага дадатковага асобніка [`RawWaker`] і звязанай з ім задачы.
    /// Выклік `wake` на атрыманым [`RawWaker`] павінен прывесці да абуджэння той самай задачы, якая была б абуджана арыгінальнай [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Гэтая функцыя будзе выклікана пры выкліку `wake` на [`Waker`].
    /// Ён павінен абудзіць задачу, звязаную з гэтым [`RawWaker`].
    ///
    /// Рэалізацыя гэтай функцыі павінна забяспечыць вызваленне любых рэсурсаў, звязаных з гэтым асобнікам [`RawWaker`] і звязанай з ім задачай.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Гэтая функцыя будзе выклікана пры выкліку `wake_by_ref` на [`Waker`].
    /// Ён павінен абудзіць задачу, звязаную з гэтым [`RawWaker`].
    ///
    /// Гэтая функцыя падобная на `wake`, але не павінна ўжываць паказальнік дадзеных.
    ///
    /// # `drop`
    ///
    /// Гэтая функцыя выклікаецца пры падзенні [`RawWaker`].
    ///
    /// Рэалізацыя гэтай функцыі павінна забяспечыць вызваленне любых рэсурсаў, звязаных з гэтым асобнікам [`RawWaker`] і звязанай з ім задачай.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` асінхроннай задачы.
///
/// У цяперашні час `Context` служыць толькі для забеспячэння доступу да `&Waker`, які можна выкарыстоўваць для абуджэння бягучай задачы.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Пераканайцеся, што мы маем future устойлівасці да змен дысперсіі, прымушаючы час жыцця быць нязменным (час жыцця аргумента-пазіцыі супярэчлівы, а час вяртання-пазіцыі каварыянтны).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Стварыце новы `Context` з `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Вяртае спасылку на `Waker` для бягучай задачы.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker`-гэта ручка для абуджэння задачы, паведамляючы выканаўцу, што яна гатовая да запуску.
///
/// Гэтая ручка інкапсулюе экземпляр [`RawWaker`], які вызначае паводзіны абуджэння для канкрэтнага выканаўцы.
///
///
/// Рэалізуе [`Clone`], [`Send`] і [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Абудзіце задачу, звязаную з гэтым `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Фактычны выклік абуджэння дэлегуецца праз выклік віртуальнай функцыі да рэалізацыі, якую вызначае выканаўца.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Не тэлефануйце ў `drop`-вандэр будзе спажываны `wake`.
        crate::mem::forget(self);

        // БЯСПЕКА: Гэта бяспечна, таму што `Waker::from_raw`-гэта адзіны спосаб
        // для ініцыялізацыі `wake` і `data`, патрабуючы ад карыстальніка прызнаць, што кантракт `RawWaker` выконваецца.
        //
        unsafe { (wake)(data) };
    }

    /// Абудзіце задачу, звязаную з гэтым `Waker`, не спажываючы `Waker`.
    ///
    /// Гэта падобна на `wake`, але можа быць крыху менш эфектыўным у выпадку наяўнасці ўласнага `Waker`.
    /// Гэты спосаб варта аддаваць перавагу выкліку `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Фактычны выклік абуджэння дэлегуецца праз выклік віртуальнай функцыі да рэалізацыі, якую вызначае выканаўца.
        //

        // БЯСПЕКА: гл. `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Вяртае `true`, калі гэты `Waker` і іншы `Waker` выклікалі тую ж задачу.
    ///
    /// Гэтая функцыя працуе з найлепшымі намаганнямі і можа вярнуць ілжывае значэнне, нават калі "Waker`s абудзіць тую ж задачу.
    /// Аднак, калі гэтая функцыя вяртае `true`, гарантавана, што `Waker`s абудзіць тую ж задачу.
    ///
    /// Гэтая функцыя ў асноўным выкарыстоўваецца для мэт аптымізацыі.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Стварае новы `Waker` з [`RawWaker`].
    ///
    /// Паводзіны вернутага `Waker` не вызначана, калі кантракт, вызначаны ў дакументацыі [`RawWaker`] і [`RawWakerVTable`], не падтрымліваецца.
    ///
    /// Таму гэты спосаб небяспечны.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // БЯСПЕКА: Гэта бяспечна, таму што `Waker::from_raw`-гэта адзіны спосаб
            // для ініцыялізацыі `clone` і `data`, патрабуючы ад карыстальніка прызнаць, што кантракт [`RawWaker`] выконваецца.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // БЯСПЕКА: Гэта бяспечна, таму што `Waker::from_raw`-гэта адзіны спосаб
        // для ініцыялізацыі `drop` і `data`, патрабуючы ад карыстальніка прызнаць, што кантракт `RawWaker` выконваецца.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}