use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Тып абгорткі для стварэння неініцыялізаваных асобнікаў `T`.
///
/// # Ініцыялізацыя інварыянтная
///
/// Увогуле, кампілятар мяркуе, што зменная правільна ініцыялізуецца ў адпаведнасці з патрабаваннямі тыпу зменнай.Напрыклад, зменная апорнага тыпу павінна быць выраўнавана і не мець значэння NULL.
/// Гэта інварыянт, які трэба *заўсёды* падтрымліваць, нават у небяспечным кодзе.
/// Як следства, нулявая ініцыялізацыя зменнай спасылачнага тыпу выклікае імгненны [undefined behavior][ub], незалежна ад таго, ці выкарыстоўваецца гэтая спасылка для доступу да памяці:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // неакрэсленыя паводзіны!⚠️
/// // Эквівалентны код з `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // неакрэсленыя паводзіны!⚠️
/// ```
///
/// Гэта выкарыстоўваецца кампілятарам для розных аптымізацый, такіх як выдаленне праверкі часу выканання і аптымізацыя макета `enum`.
///
/// Аналагічна, цалкам неініцыялізаваная памяць можа мець любы змест, у той час як `bool` заўсёды павінна быць `true` або `false`.Такім чынам, стварэнне неініцыялізаванага `bool`-гэта неакрэсленае паводзіны:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // неакрэсленыя паводзіны!⚠️
/// // Эквівалентны код з `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // неакрэсленыя паводзіны!⚠️
/// ```
///
/// Больш за тое, неініцыялізаваная памяць асаблівая тым, што не мае фіксаванага значэння ("fixed", што азначае "it won't change without being written to").Чытанне аднаго і таго ж неініцыялізаванага байта некалькі разоў можа даць розныя вынікі.
/// Гэта робіць нявызначаным паводзінамі наяўнасць неініцыялізаваных дадзеных у зменнай, нават калі гэтая зменная мае цэлачыповы тып, які ў адваротным выпадку можа ўтрымліваць любы *фіксаваны* бітавы ўзор:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // неакрэсленыя паводзіны!⚠️
/// // Эквівалентны код з `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // неакрэсленыя паводзіны!⚠️
/// ```
/// (Звярніце ўвагу, што правілы ў дачыненні да неініцыялізаваных цэлых лікаў яшчэ не дапрацаваны, але пакуль яны не з'явіліся, пажадана іх пазбягаць)
///
/// Акрамя гэтага, памятайце, што большасць тыпаў маюць дадатковыя інварыянты, акрамя таго, што яны проста лічацца ініцыялізаванымі на ўзроўні тыпу.
/// Напрыклад, ініцыялізаваны `1` [`Vec<T>`] лічыцца ініцыялізаваным (пры бягучай рэалізацыі; гэта не з'яўляецца стабільнай гарантыяй), паколькі адзінае патрабаванне, якое кампілятар ведае пра яго,-гэта тое, што паказальнік дадзеных не павінен быць нулявым.
/// Стварэнне такога `Vec<T>` не выклікае *неадкладнага* нявызначанага паводзінаў, але прывядзе да неакрэсленых паводзін пры большасці бяспечных аперацый (у тым ліку падзенне яго).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` служыць для ўключэння небяспечнага кода для апрацоўкі неініцыялізаваных дадзеных.
/// Гэта сігнал для кампілятара, які паказвае, што дадзеныя тут могуць *не* быць ініцыялізаваны:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Стварыце відавочна неініцыялізаваную спасылку.
/// // Кампілятар ведае, што дадзеныя ўнутры `MaybeUninit<T>` могуць быць несапраўднымі, і, такім чынам, гэта не UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Усталюйце дапушчальнае значэнне.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Здабыць ініцыялізаваныя дадзеныя-гэта дазволена *толькі пасля* правільнай ініцыялізацыі `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Тады кампілятар ведае, што не робіць няправільных здагадак і аптымізацый для гэтага кода.
///
/// Вы можаце думаць, што `MaybeUninit<T>` падобны на `Option<T>`, але без адсочвання часу выканання і без праверкі бяспекі.
///
/// ## out-pointers
///
/// Вы можаце выкарыстоўваць `MaybeUninit<T>` для рэалізацыі "out-pointers": замест таго, каб вяртаць дадзеныя з функцыі, перадайце ёй паказальнік на памяць (uninitialized), каб змясціць вынік.
/// Гэта можа быць карысна, калі абаненту важна кантраляваць, як выдзяляецца памяць, у якой захоўваецца вынік, і вы хочаце пазбегнуць непатрэбных хадоў.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` не скідае старое змест, што вельмі важна.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Цяпер мы ведаем, што `v` ініцыялізаваны!Гэта таксама гарантуе, што vector правільна скінуты.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Ініцыялізацыя масіва паэтапна
///
/// `MaybeUninit<T>` можа выкарыстоўвацца для ініцыялізацыі вялікага масіва паэтапна:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Стварыце неініцыялізаваны масіў `MaybeUninit`.
///     // `assume_init` бяспечны, таму што тып, які мы сцвярджаем, што ініцыялізаваны тут,-гэта куча `MaybeUninit`, якія не патрабуюць ініцыялізацыі.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Адмова ад `MaybeUninit` нічога не робіць.
///     // Такім чынам, выкарыстанне сырога прысваення паказальніка замест `ptr::write` не прыводзіць да выпадзення старога неініцыялізаванага значэння.
/////
///     // Акрамя таго, калі падчас гэтага цыкла ёсць panic, у нас узнікае ўцечка памяці, але праблемы бяспекі памяці няма.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Усё ініцыялізавана.
///     // Пераўтварыць масіў у ініцыялізаваны тып.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Вы таксама можаце працаваць з часткова ініцыялізаванымі масівамі, якія можна знайсці ў структурах дадзеных нізкага ўзроўню.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Стварыце неініцыялізаваны масіў `MaybeUninit`.
/// // `assume_init` бяспечны, таму што тып, які мы сцвярджаем, што ініцыялізаваны тут,-гэта куча `MaybeUninit`, якія не патрабуюць ініцыялізацыі.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Падлічыце колькасць прызначаных намі элементаў.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Для кожнага элемента ў масіве адкіньце, калі мы яго выдзелілі.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Ініцыялізацыя структуры поле за полем
///
/// Вы можаце выкарыстоўваць `MaybeUninit<T>` і макрас [`std::ptr::addr_of_mut`] для ініцыялізацыі структураў поле за полем:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Ініцыялізацыя поля `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ініцыялізацыя поля `list` Калі тут ёсць panic, то `String` у полі `name` выцеча.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Усе палі ініцыялізаваны, таму мы выклікаем `assume_init`, каб атрымаць ініцыялізаваны Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` гарантуецца мець той жа памер, выраўноўванне і ABI, што і `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Аднак памятайце, што тып *, які змяшчае*`MaybeUninit<T>`, не абавязкова мае аднолькавы макет;Rust наогул не гарантуе, што палі `Foo<T>` маюць аднолькавы парадак з `Foo<U>`, нават калі `T` і `U` маюць аднолькавы памер і выраўноўванне.
///
/// Акрамя таго, паколькі любое бітавае значэнне сапраўднае для `MaybeUninit<T>`, кампілятар не можа прымяніць аптымізацыі non-zero/niche-filling, што можа прывесці да большага памеру:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Калі `T` бяспечны для FFI, значыць, і `MaybeUninit<T>`.
///
/// У той час як `MaybeUninit`-гэта `#[repr(transparent)]` (што азначае, што ён гарантуе той жа памер, выраўноўванне і ABI, што і `T`), гэта *не* змяняе любы з папярэдніх агаворак.
/// `Option<T>` і `Option<MaybeUninit<T>>` па-ранейшаму могуць мець розныя памеры, а тыпы, якія змяшчаюць поле тыпу `T`, могуць быць размешчаны (і памерамі) інакш, чым калі б гэта поле было `MaybeUninit<T>`.
/// `MaybeUninit` з'яўляецца тыпам аб'яднання, а `#[repr(transparent)]` на аб'яднаннях няўстойлівы (гл. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// З цягам часу дакладныя гарантыі `#[repr(transparent)]` для прафсаюзаў могуць развівацца, а `MaybeUninit` можа заставацца ці не заставацца `#[repr(transparent)]`.
/// Тым не менш, `MaybeUninit<T>`*заўсёды* гарантуе, што мае той жа памер, выраўноўванне і ABI, што і `T`;проста спосаб рэалізацыі `MaybeUninit` гэтай гарантыі можа развівацца.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Элемент Lang, каб мы маглі загарнуць у яго іншыя тыпы.Гэта карысна для генератараў.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Не выклікаючы `T::clone()`, мы не можам ведаць, ці дастаткова мы для гэтага ініцыялізаваны.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Стварае новы `MaybeUninit<T>`, ініцыялізаваны зададзеным значэннем.
    /// З бяспекай можна патэлефанаваць у [`assume_init`] па зваротным значэнні гэтай функцыі.
    ///
    /// Звярніце ўвагу, што адмова ад `MaybeUninit<T>` ніколі не выклікае код падзення "T".
    /// Вы абавязаны пераканацца, што `T` будзе скінуты, калі ён будзе ініцыялізаваны.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Стварае новы `MaybeUninit<T>` у неініцыялізаваным стане.
    ///
    /// Звярніце ўвагу, што адмова ад `MaybeUninit<T>` ніколі не выклікае код падзення "T".
    /// Вы абавязаны пераканацца, што `T` будзе скінуты, калі ён будзе ініцыялізаваны.
    ///
    /// Глядзіце прыклады [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Стварыце новы масіў элементаў `MaybeUninit<T>` у неініцыялізаваным стане.
    ///
    /// Note: у версіі future Rust гэты метад можа стаць непатрэбным, калі сінтаксіс літаральнага масіва дазваляе [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// У прыведзеным ніжэй прыкладзе можна выкарыстоўваць `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Вяртае (магчыма, меншы) зрэз дадзеных, які быў фактычна прачытаны
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // БЯСПЕКА: неініцыялізаваны `[MaybeUninit<_>; LEN]` сапраўдны.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Стварае новы `MaybeUninit<T>` у неініцыялізаваным стане, памяць запаўняецца байтамі `0`.Ад `T` залежыць, ці будзе гэта ўжо зрабіць належную ініцыялізацыю.
    ///
    /// Напрыклад, `MaybeUninit<usize>::zeroed()` ініцыялізаваны, але `MaybeUninit<&'static i32>::zeroed()` не таму, што спасылкі не павінны быць нулявымі.
    ///
    /// Звярніце ўвагу, што адмова ад `MaybeUninit<T>` ніколі не выклікае код падзення "T".
    /// Вы абавязаны пераканацца, што `T` будзе скінуты, калі ён будзе ініцыялізаваны.
    ///
    /// # Example
    ///
    /// Правільнае выкарыстанне гэтай функцыі: ініцыялізацыя структуры нулём, дзе ўсе палі структуры могуць утрымліваць бітавы ўзор 0 у якасці дапушчальнага значэння.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Няправільнае* выкарыстанне гэтай функцыі: выклік `x.zeroed().assume_init()`, калі `0` не з'яўляецца сапраўдным бітавым шаблонам для тыпу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Унутры пары мы ствараем `NotZero`, які не мае сапраўднага дыскрымінанта.
    /// // Гэта неакрэсленыя паводзіны.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // БЯСПЕКА: `u.as_mut_ptr()` паказвае на выдзеленую памяць.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Усталёўвае значэнне `MaybeUninit<T>`.
    /// Гэта замяняе любое папярэдняе значэнне, не выкідваючы яго, таму будзьце асцярожныя, каб не выкарыстоўваць яго двойчы, калі вы не хочаце прапусціць запуск дэструктара.
    ///
    /// Для вашага зручнасці гэта таксама вяртае зменную спасылку на (зараз бяспечна ініцыялізаванае) змест `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // БЯСПЕКА: Мы толькі што ініцыялізавалі гэта значэнне.
        unsafe { self.assume_init_mut() }
    }

    /// Атрымлівае паказальнік на змешчанае значэнне.
    /// Чытанне з гэтага паказальніка альбо пераўтварэнне яго ў спасылку з'яўляецца паводзінамі не вызначана, калі `MaybeUninit<T>` не ініцыялізаваны.
    /// Запіс у памяць, на якую паказвае гэты паказальнік (non-transitively), з'яўляецца нявызначаным паводзінамі (за выключэннем унутры `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Правільнае выкарыстанне гэтага метаду:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Стварыце спасылку на `MaybeUninit<T>`.Гэта нармальна, таму што мы яго ініцыялізавалі.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Няправільнае* выкарыстанне гэтага метаду:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Мы стварылі спасылку на неініцыялізаваны vector!Гэта неакрэсленыя паводзіны.⚠️
    /// ```
    ///
    /// (Звярніце ўвагу, што правілы, якія тычацца спасылак на неініцыялізаваныя дадзеныя, яшчэ не дапрацаваны, але пакуль яны не з'явіліся, пажадана іх пазбягаць.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` і `ManuallyDrop`-гэта і `repr(transparent)`, таму мы можам кінуць паказальнік.
        self as *const _ as *const T
    }

    /// Атрымлівае зменлівы паказальнік на змешчанае значэнне.
    /// Чытанне з гэтага паказальніка альбо пераўтварэнне яго ў спасылку з'яўляецца паводзінамі не вызначана, калі `MaybeUninit<T>` не ініцыялізаваны.
    ///
    /// # Examples
    ///
    /// Правільнае выкарыстанне гэтага метаду:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Стварыце спасылку на `MaybeUninit<Vec<u32>>`.
    /// // Гэта нармальна, таму што мы яго ініцыялізавалі.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Няправільнае* выкарыстанне гэтага метаду:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Мы стварылі спасылку на неініцыялізаваны vector!Гэта неакрэсленыя паводзіны.⚠️
    /// ```
    ///
    /// (Звярніце ўвагу, што правілы, якія тычацца спасылак на неініцыялізаваныя дадзеныя, яшчэ не дапрацаваны, але пакуль яны не з'явіліся, пажадана іх пазбягаць.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` і `ManuallyDrop`-гэта і `repr(transparent)`, таму мы можам кінуць паказальнік.
        self as *mut _ as *mut T
    }

    /// Вымае значэнне з кантэйнера `MaybeUninit<T>`.Гэта выдатны спосаб гарантаваць, што дадзеныя будуць скінуты, таму што атрыманы `T` падлягае звычайнай апрацоўцы.
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што `MaybeUninit<T>` сапраўды знаходзіцца ў ініцыялізаваным стане.Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае неадкладныя паводзіны.
    /// [type-level documentation][inv] змяшчае дадатковую інфармацыю пра гэты інварыянт ініцыялізацыі.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Акрамя гэтага, памятайце, што большасць тыпаў маюць дадатковыя інварыянты, акрамя таго, што яны проста лічацца ініцыялізаванымі на ўзроўні тыпу.
    /// Напрыклад, ініцыялізаваны `1` [`Vec<T>`] лічыцца ініцыялізаваным (пры бягучай рэалізацыі; гэта не з'яўляецца стабільнай гарантыяй), паколькі адзінае патрабаванне, якое кампілятар ведае пра яго,-гэта тое, што паказальнік дадзеных не павінен быць нулявым.
    ///
    /// Стварэнне такога `Vec<T>` не выклікае *неадкладнага* нявызначанага паводзінаў, але прывядзе да неакрэсленых паводзін пры большасці бяспечных аперацый (у тым ліку падзенне яго).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Правільнае выкарыстанне гэтага метаду:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Няправільнае* выкарыстанне гэтага метаду:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` яшчэ не быў ініцыялізаваны, таму гэты апошні радок выклікаў нявызначаныя паводзіны.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // БЯСПЕКА: абанент павінен гарантаваць ініцыялізацыю `self`.
        // Гэта таксама азначае, што `self` павінен быць варыянтам `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Чытае значэнне з кантэйнера `MaybeUninit<T>`.Атрыманы `T` падлягае звычайнай апрацоўцы.
    ///
    /// Па магчымасці, пераважна замест гэтага выкарыстоўваць [`assume_init`], які прадухіляе дубліраванне змесціва `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што `MaybeUninit<T>` сапраўды знаходзіцца ў ініцыялізаваным стане.Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае нявызначаныя паводзіны.
    /// [type-level documentation][inv] змяшчае дадатковую інфармацыю пра гэты інварыянт ініцыялізацыі.
    ///
    /// Больш за тое, гэта пакідае тыя ж дадзеныя, што і ў `MaybeUninit<T>`.
    /// Пры выкарыстанні некалькіх копій дадзеных (некалькі разоў патэлефанаваўшы ў `assume_init_read` альбо спачатку патэлефанаваўшы ў `assume_init_read`, а потым у [`assume_init`]), вы абавязаны пераканацца, што дадзеныя сапраўды могуць быць прадубляваны.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Правільнае выкарыстанне гэтага метаду:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` гэта `Copy`, таму мы можам чытаць некалькі разоў.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Дубліраванне значэння `None`-гэта нармальна, таму мы можам прачытаць некалькі разоў.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Няправільнае* выкарыстанне гэтага метаду:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Цяпер мы стварылі дзве копіі аднаго і таго ж vector, што прывяло да падвойнага бясплатнага ⚠️, калі яны абодва выпадуць!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // БЯСПЕКА: абанент павінен гарантаваць ініцыялізацыю `self`.
        // Чытанне з `self.as_ptr()` бяспечна, бо `self` трэба ініцыялізаваць.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Скідвае змешчанае значэнне на месца.
    ///
    /// Калі вы валодаеце `MaybeUninit`, вы можаце выкарыстоўваць [`assume_init`].
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што `MaybeUninit<T>` сапраўды знаходзіцца ў ініцыялізаваным стане.Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае нявызначаныя паводзіны.
    ///
    /// У дадатак да гэтага павінны быць задаволены ўсе дадатковыя інварыянты тыпу `T`, бо рэалізацыя `Drop` `T` (альбо яго членаў) можа на гэта разлічваць.
    /// Напрыклад, ініцыялізаваны `1` [`Vec<T>`] лічыцца ініцыялізаваным (пры бягучай рэалізацыі; гэта не з'яўляецца стабільнай гарантыяй), паколькі адзінае патрабаванне, якое кампілятар ведае пра яго,-гэта тое, што паказальнік дадзеных не павінен быць нулявым.
    ///
    /// Падзенне такога `Vec<T>`, аднак, прывядзе да нявызначаных паводзін.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // БЯСПЕКА: абанент павінен гарантаваць, што `self` ініцыялізаваны і
        // задавальняе ўсім інварыянтам `T`.
        // Падзенне значэння на месцы бяспечна, калі гэта так.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Атрымлівае агульную спасылку на змешчанае значэнне.
    ///
    /// Гэта можа быць карысна, калі мы хочам атрымаць доступ да `MaybeUninit`, які быў ініцыялізаваны, але не мае права ўласнасці на `MaybeUninit` (прадухіляе выкарыстанне `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае нявызначаныя паводзіны: абанент павінен гарантаваць, што `MaybeUninit<T>` сапраўды знаходзіцца ў ініцыялізаваным стане.
    ///
    ///
    /// # Examples
    ///
    /// ### Правільнае выкарыстанне гэтага метаду:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Ініцыялізацыя `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Цяпер, калі вядома, што наш `MaybeUninit<_>` ініцыялізаваны, можна стварыць агульную спасылку на яго:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // БЯСПЕКА: `x` ініцыялізаваны.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Няправільнае* выкарыстанне гэтага метаду:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Мы стварылі спасылку на неініцыялізаваны vector!Гэта неакрэсленыя паводзіны.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Ініцыялізуйце `MaybeUninit` з дапамогай `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Спасылка на неініцыялізаваны `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // БЯСПЕКА: абанент павінен гарантаваць ініцыялізацыю `self`.
        // Гэта таксама азначае, што `self` павінен быць варыянтам `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Атрымлівае зменлівую спасылку (unique) на якое змяшчаецца значэнне.
    ///
    /// Гэта можа быць карысна, калі мы хочам атрымаць доступ да `MaybeUninit`, які быў ініцыялізаваны, але не мае права ўласнасці на `MaybeUninit` (прадухіляе выкарыстанне `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае нявызначаныя паводзіны: абанент павінен гарантаваць, што `MaybeUninit<T>` сапраўды знаходзіцца ў ініцыялізаваным стане.
    /// Напрыклад, `.assume_init_mut()` нельга выкарыстоўваць для ініцыялізацыі `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Правільнае выкарыстанне гэтага метаду:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Ініцыялізуе *усе* байты ўваходнага буфера.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Ініцыялізацыя `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Цяпер мы ведаем, што `buf` быў ініцыялізаваны, таму мы маглі б яго `.assume_init()`.
    /// // Аднак выкарыстанне `.assume_init()` можа выклікаць `memcpy` з 2048 байт.
    /// // Каб сцвярджаць, што наш буфер быў ініцыялізаваны без капіравання, мы абнаўляем `&mut MaybeUninit<[u8; 2048]>` да `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // БЯСПЕКА: `buf` ініцыялізаваны.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Цяпер мы можам выкарыстоўваць `buf` як звычайны зрэз:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Няправільнае* выкарыстанне гэтага метаду:
    ///
    /// Вы не можаце выкарыстоўваць `.assume_init_mut()` для ініцыялізацыі значэння:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Мы стварылі спасылку (mutable) на неініцыялізаваны `bool`!
    ///     // Гэта неакрэсленыя паводзіны.⚠️
    /// }
    /// ```
    ///
    /// Напрыклад, вы не можаце [`Read`] перайсці ў неініцыялізаваны буфер:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) спасылка на неініцыялізаваную памяць!
    ///                             // Гэта неакрэсленыя паводзіны.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Таксама вы не можаце выкарыстоўваць прамы доступ да палёў для паэтапнай ініцыялізацыі палёў:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) спасылка на неініцыялізаваную памяць!
    ///                  // Гэта неакрэсленыя паводзіны.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) спасылка на неініцыялізаваную памяць!
    ///                  // Гэта неакрэсленыя паводзіны.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): У цяперашні час мы разлічваем на тое, што вышэйсказанае было няправільным, гэта значыць, мы маем спасылкі на неініцыялізаваныя дадзеныя (напрыклад, у `libcore/fmt/float.rs`).
    // Мы павінны прыняць канчатковае рашэнне аб правілах да стабілізацыі.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // БЯСПЕКА: абанент павінен гарантаваць ініцыялізацыю `self`.
        // Гэта таксама азначае, што `self` павінен быць варыянтам `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Вымае значэнні з масіва кантэйнераў `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што ўсе элементы масіва знаходзяцца ў ініцыялізаваным стане.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // БЯСПЕКА: Цяпер бяспечна, бо мы ініцыялізавалі ўсе элементы
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Абанент гарантуе ініцыялізацыю ўсіх элементаў масіва
        // * `MaybeUninit<T>` і T гарантавана маюць аднолькавы макет
        // * MaybeUnint не падае, таму падвойных бясплатных няма і, такім чынам, пераўтварэнне бяспечна
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Мяркуючы, што ўсе элементы ініцыялізаваны, атрымаем да іх зрэз.
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што элементы `MaybeUninit<T>` сапраўды знаходзяцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае нявызначаныя паводзіны.
    ///
    /// Для больш падрабязнай інфармацыі і прыкладаў глядзіце [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // БЯСПЕКА: прывязка лустачкі да `*const [T]` бяспечная, бо абанент гарантуе гэта
        // `slice` ініцыялізуецца, і`MaybeUninit` гарантавана будзе мець той жа макет, што і `T`.
        // Атрыманы паказальнік з'яўляецца сапраўдным, паколькі ён спасылаецца на памяць, якая належыць `slice`, якая з'яўляецца спасылкай і, такім чынам, гарантавана сапраўднай для чытанняў.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Мяркуючы, што ўсе элементы ініцыялізаваны, атрымайце зменлівы зрэз да іх.
    ///
    /// # Safety
    ///
    /// Абанент павінен гарантаваць, што элементы `MaybeUninit<T>` сапраўды знаходзяцца ў ініцыялізаваным стане.
    ///
    /// Выклік гэтага, калі змест яшчэ не цалкам ініцыялізаваны, выклікае нявызначаныя паводзіны.
    ///
    /// Для больш падрабязнай інфармацыі і прыкладаў глядзіце [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // БЯСПЕКА: аналагічна інструкцыям па бяспецы для `slice_get_ref`, але ў нас ёсць
        // зменлівая спасылка, якая таксама гарантавана будзе сапраўднай для запісаў.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Атрымлівае паказальнік на першы элемент масіва.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Атрымлівае зменлівы паказальнік на першы элемент масіва.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Капіруе элементы з `src` на `this`, вяртаючы зменлівую спасылку на зараз пачатае змесціва `this`.
    ///
    /// Калі `T` не рэалізуе `Copy`, выкарыстоўвайце [`write_slice_cloned`]
    ///
    /// Гэта падобна на [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі два зрэзы маюць розную даўжыню.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЯСПЕКА: мы толькі што скапіравалі ўсе элементы len у свабодную ёмістасць
    /// // першыя элементы src.len() vec сапраўдныя зараз.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // БЯСПЕКА: &[T] і&[MaybeUninit<T>] маюць аднолькавы макет
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // БЯСПЕКА: Сапраўдныя элементы толькі што былі скапіяваны ў `this`, таму ён італіфікаваны
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Кланіруе элементы ад `src` да `this`, вяртаючы зменлівую спасылку на зараз пачатае змесціва `this`.
    /// Усе ўжо ініцыялізаваныя элементы не будуць выдалены.
    ///
    /// Калі `T` рэалізуе `Copy`, выкарыстоўвайце [`write_slice`]
    ///
    /// Гэта падобна на [`slice::clone_from_slice`], але не адпускае існуючыя элементы.
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі два зрэзы маюць розную даўжыню, альбо калі рэалізацыя `Clone` panics.
    ///
    /// Калі ёсць panic, ужо кланаваныя элементы будуць выдалены.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЯСПЕКА: мы толькі што кланавалі ўсе элементы лен у свабодную ёмістасць
    /// // першыя элементы src.len() vec сапраўдныя зараз.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // у адрозненне ад copy_from_slice гэта не выклікае clone_from_slice на зрэзе, таму што `MaybeUninit<T: Clone>` не рэалізуе Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // БЯСПЕКА: гэты неапрацаваны зрэз будзе ўтрымліваць толькі ініцыялізаваныя аб'екты
                // вось чаму, дазволена яго кінуць.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Нам трэба відавочна нарэзаць іх аднолькавай даўжыні
        // для выдалення праверкі межаў, і аптымізатар генеруе memcpy для простых выпадкаў (напрыклад, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // патрэбны ахоўнік b/c panic можа здарыцца падчас клона
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // БЯСПЕКА: Дапушчальныя элементы толькі што былі запісаны ў `this`, таму ён італіфікаваны
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}