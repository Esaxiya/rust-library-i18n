//! Асноўныя функцыі для працы з памяццю.
//!
//! Гэты модуль змяшчае функцыі для запыту памеру і выраўноўвання тыпаў, ініцыялізацыі і маніпуляцыі памяццю.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Бярэ ўласнасць і "forgets" пра значэнне **без запуску яго дэструктара**.
///
/// Любыя рэсурсы, якімі кіруецца значэнне, такія як памяць кучы альбо дэсклератар файла, назаўсёды застануцца ў недаступным стане.Аднак гэта не гарантуе захавання паказальнікаў на гэтую памяць.
///
/// * Калі вы хочаце прасачыць памяць, глядзіце [`Box::leak`].
/// * Калі вы хочаце атрымаць неапрацаваны паказальнік на памяць, см. [`Box::into_raw`].
/// * Калі вы хочаце правільна распарадзіцца значэннем, запусціўшы яго дэструктар, см. [`mem::drop`].
///
/// # Safety
///
/// `forget` не пазначана як `unsafe`, таму што гарантыі бяспекі Rust не ўключаюць гарантыі таго, што дэструктары будуць працаваць заўсёды.
/// Напрыклад, праграма можа стварыць эталонны цыкл з выкарыстаннем [`Rc`][rc] альбо выклікаць [`process::exit`][exit] для выхаду без запуску дэструктараў.
/// Такім чынам, дазвол `mem::forget` з бяспечнага кода прынцыпова не змяняе гарантыі бяспекі Rust.
///
/// Тым не менш, уцечка такіх рэсурсаў, як памяць альбо аб'екты I/O, звычайна непажаданая.
/// Патрэба ўзнікае ў некаторых спецыялізаваных выпадках выкарыстання FFI або небяспечнага кода, але нават тады звычайна аддаюць перавагу [`ManuallyDrop`].
///
/// Паколькі забыццё значэння дазволена, любы код `unsafe`, які вы пішаце, павінен улічваць такую магчымасць.Вы не можаце вярнуць значэнне і чакаць, што абанент абавязкова запусціць дэструктар значэння.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Кананічнае бяспечнае выкарыстанне `mem::forget` заключаецца ў абыходзе дэструктара значэння, рэалізаванага `Drop` Portrait.Напрыклад, гэта выцякае з `File`, г.зн.
/// вярнуць месца, якое займае зменная, але ніколі не зачыняць асноўны рэсурс сістэмы:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Гэта карысна, калі ўласнасць на базавы рэсурс раней была перададзена коду па-за межамі Rust, напрыклад, шляхам перадачы дэскрыптара неапрацаванага файла ў код C.
///
/// # Адносіны з `ManuallyDrop`
///
/// У той час як `mem::forget` таксама можа быць выкарыстаны для перадачы *памяці* уласнасці, рабіць гэта падвяргаецца памылкам.
/// [`ManuallyDrop`] варта выкарыстоўваць замест гэтага.Разгледзім, напрыклад, гэты код:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Стварыце `String`, выкарыстоўваючы змест `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // уцечка `v`, таму што яе памяць цяпер кіруецца `s`
/// mem::forget(v);  // ПАМЫЛКА, v несапраўдны і не павінен перадавацца функцыі
/// assert_eq!(s, "Az");
/// // `s` імпліцытна скідаецца і памяць вызваляецца.
/// ```
///
/// З прыведзеным прыкладам ёсць дзве праблемы:
///
/// * Калі паміж канструкцыяй `String` і выклікам `mem::forget()` было дададзена больш кода, panic у ім выкліча двайную вызваленне, таму што адна і тая ж памяць апрацоўваецца як `v`, так і `s`.
/// * Пасля выкліку `v.as_mut_ptr()` і перадачы права ўласнасці на дадзеныя `s`, значэнне `v` з'яўляецца недапушчальным.
/// Нават калі значэнне проста перамяшчаецца ў `mem::forget` (які не будзе яго правяраць), некаторыя тыпы маюць строгія патрабаванні да сваіх значэнняў, якія робяць іх несапраўднымі пры боўтанні альбо больш не належаць ім.
/// Любое выкарыстанне недапушчальных значэнняў, уключаючы перадачу іх функцыям альбо вяртанне іх з функцый, уяўляе сабой неакрэсленыя паводзіны і можа парушыць здагадкі, зробленыя кампілятарам.
///
/// Пераход на `ManuallyDrop` дазваляе пазбегнуць абодвух праблем:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Перш чым разбіраць `v` на яго сырыя часткі, пераканайцеся, што ён не ўпадзе!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Цяпер разбярыце `v`.Гэтыя аперацыі не могуць panic, таму не можа быць уцечкі.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Нарэшце, пабудуйце `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` імпліцытна скідаецца і памяць вызваляецца.
/// ```
///
/// `ManuallyDrop` надзейна прадухіляе падвойнае вызваленне, таму што мы адключаем дэструктар `v`, перш чым рабіць што-небудзь іншае.
/// `mem::forget()` не дазваляе гэтага, бо ён спажывае свой аргумент, прымушаючы выклікаць яго толькі пасля вымання ўсяго, што нам трэба з `v`.
/// Нават калі б паміж пабудовай `ManuallyDrop` і пабудовай радка быў уведзены panic (што не можа адбыцца ў кодзе, як паказана), гэта прывядзе да ўцечкі, а не ў два разы.
/// Іншымі словамі, `ManuallyDrop` памыляецца на баку ўцечкі замест памылкі на баку (падвойнага) падзення.
///
/// Акрамя таго, `ManuallyDrop` перашкаджае нам мець "touch" `v` пасля перадачы права ўласнасці на `s`-канчатковага этапу ўзаемадзеяння з `v` для ўтылізацыі без запуску яго дэструктара цалкам пазбягаюць.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Як і [`forget`], але таксама прымае невялікае значэнне.
///
/// Гэтая функцыя-проста падкладка, прызначаная для выдалення, калі функцыя `unsized_locals` стабілізуецца.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Вяртае памер тыпу ў байтах.
///
/// Больш канкрэтна, гэта зрушэнне ў байтах паміж паслядоўнымі элементамі масіва з такім тыпам элемента, уключаючы выраўноўванне.
///
/// Такім чынам, для любога тыпу `T` і даўжыні `n` `[T; n]` мае памер `n * size_of::<T>()`.
///
/// Увогуле, памер тыпу не з'яўляецца стабільным для кампіляцый, але пэўныя тыпы, такія як прымітывы.
///
/// У наступнай табліцы прыведзены памер прымітываў.
///
/// Тып |памер: :<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 знакаў |4
///
/// Акрамя таго, `usize` і `isize` маюць аднолькавы памер.
///
/// Тыпы `*const T`, `&T`, `Box<T>`, `Option<&T>` і `Option<Box<T>>` маюць аднолькавы памер.
/// Калі `T` мае памер, усе гэтыя тыпы маюць той жа памер, што і `usize`.
///
/// Зменлівасць паказальніка не змяняе яго памер.Такім чынам, `&T` і `&mut T` маюць аднолькавы памер.
/// Сапраўды гэтак жа для `*const T` і `* mut T`.
///
/// # Памер элементаў `#[repr(C)]`
///
/// Прадстаўленне `C` для элементаў мае пэўную кампаноўку.
/// Пры такім макеце памер элементаў таксама стабільны, пакуль усе палі маюць стабільны памер.
///
/// ## Памер канструкцый
///
/// Для `structs` памер вызначаецца па наступным алгарытме.
///
/// Для кожнага поля ў структуры, упарадкаванай па парадку дэкларацыі:
///
/// 1. Дадайце памер поля.
/// 2. Акругліце бягучы памер да бліжэйшага кратнага [alignment] наступнага поля.
///
/// Нарэшце, акругліце памер структуры да бліжэйшага кратнага яе [alignment].
/// Выраўноўванне структуры звычайна з'яўляецца найбуйнейшым выраўноўваннем усіх яе палёў;гэта можна змяніць з выкарыстаннем `repr(align(N))`.
///
/// У адрозненне ад `C`, структуры нулявога памеру не акругляюцца да аднаго байта.
///
/// ## Памер пералічэнняў
///
/// Пералічэнні, якія не нясуць іншых дадзеных, акрамя дыскрымінанта, маюць той самы памер, што і пералікі С на платформе, для якой яны складзены.
///
/// ## Памер прафсаюзаў
///
/// Памер саюза-гэта памер яго найбольшага поля.
///
/// У адрозненне ад `C`, аб'яднанні нулявога памеру не акругляюцца да аднаго байта.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Некаторыя прымітывы
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Некалькі масіваў
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Роўнасць памеру паказальніка
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Выкарыстанне `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Памер першага поля роўны 1, таму дадайце 1 да памеру.Памер-1.
/// // Выраўноўванне другога поля роўна 2, таму дадайце 1 да памеру для запаўнення.Памер-2.
/// // Памер другога поля роўны 2, таму дадайце да памеру 2.Памер 4.
/// // Выраўноўванне трэцяга поля роўна 1, таму дадайце 0 да памеру для запаўнення.Памер 4.
/// // Памер трэцяга поля роўны 1, таму дадайце 1 да памеру.Памер-5.
/// // Нарэшце, выраўноўванне структуры роўна 2 (паколькі найбольшае выраўноўванне сярод яе палёў-2), таму дадайце 1 да памеру для абіўкі.
/// // Памер 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Каркасныя структуры выконваюць тыя ж правілы.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Звярніце ўвагу, што змяненне парадку палёў можа паменшыць памер.
/// // Мы можам выдаліць абодва байта пракладкі, паставіўшы `third` перад `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Памер саюза-гэта памер самага вялікага поля.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Вяртае памер указанага значэння ў байтах.
///
/// Звычайна гэта тое ж самае, што і `size_of::<T>()`.
/// Аднак, калі `T`*не мае* статычна вядомага памеру, напрыклад, зрэз [`[T]`][slice] або [trait object], тады `size_of_val` можа быць выкарыстаны для атрымання дынамічна вядомага памеру.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // БЯСПЕКА: `val` з'яўляецца спасылкай, таму гэта сапраўдны сыравінны паказальнік
    unsafe { intrinsics::size_of_val(val) }
}

/// Вяртае памер указанага значэння ў байтах.
///
/// Звычайна гэта тое ж самае, што і `size_of::<T>()`.Аднак калі `T`*не мае* статычна вядомага памеру, напрыклад, зрэз [`[T]`][slice] або [trait object], тады `size_of_val_raw` можа быць выкарыстаны для атрымання дынамічна вядомага памеру.
///
/// # Safety
///
/// Выклік гэтай функцыі бяспечны толькі пры выкананні наступных умоў:
///
/// - Калі `T`-гэта `Sized`, выклік гэтай функцыі заўсёды бяспечны.
/// - Калі хвост `T` невялікага памеру:
///     - [slice], тады даўжыня зрэзу хваста павінна быць ініцыялізаваным цэлым лікам, а памер *усяго значэння*(дынамічная даўжыня хваста + статычны памер прэфікс) павінен змяшчацца ў `isize`.
///     - [trait object], тады частка паказальніка vtable павінна паказваць на сапраўдную vtable, набытую прымусам без змянення памеру, а памер *цэлага значэння*(дынамічная даўжыня хваста + прэфікс са статычным памерам) павінен змяшчацца ў `isize`.
///
///     - (unstable) [extern type], тады гэтую функцыю заўсёды бяспечна выклікаць, але panic можа вярнуць няправільнае значэнне, бо макет знешняга тыпу невядомы.
///     Гэта тое самае паводзіны, што і [`size_of_val`] пры спасылцы на тып з хвастом вонкавага тыпу.
///     - у адваротным выпадку кансерватыўна забараняецца выклікаць гэтую функцыю.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // БЯСПЕКА: абанент павінен прадаставіць сапраўдны сыравінны паказальнік
    unsafe { intrinsics::size_of_val(val) }
}

/// Вяртае мінімальнае выраўноўванне тыпу, неабходнае для [ABI].
///
/// Кожная спасылка на значэнне тыпу `T` павінна быць кратнай гэтаму ліку.
///
/// Гэта выраўноўванне, якое выкарыстоўваецца для палёў структуры.Гэта можа быць менш, чым пераважнае выраўноўванне.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Вяртае мінімальнае выраўноўванне тыпу значэння, на якое паказвае `val`, неабходнае для [ABI].
///
/// Кожная спасылка на значэнне тыпу `T` павінна быць кратнай гэтаму ліку.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // БЯСПЕКА: val-гэта спасылка, таму гэта сапраўдны сыравінны паказальнік
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Вяртае мінімальнае выраўноўванне тыпу, неабходнае для [ABI].
///
/// Кожная спасылка на значэнне тыпу `T` павінна быць кратнай гэтаму ліку.
///
/// Гэта выраўноўванне, якое выкарыстоўваецца для палёў структуры.Гэта можа быць менш, чым пераважнае выраўноўванне.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Вяртае мінімальнае выраўноўванне тыпу значэння, на якое паказвае `val`, неабходнае для [ABI].
///
/// Кожная спасылка на значэнне тыпу `T` павінна быць кратнай гэтаму ліку.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // БЯСПЕКА: val-гэта спасылка, таму гэта сапраўдны сыравінны паказальнік
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Вяртае мінімальнае выраўноўванне тыпу значэння, на якое паказвае `val`, неабходнае для [ABI].
///
/// Кожная спасылка на значэнне тыпу `T` павінна быць кратнай гэтаму ліку.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Выклік гэтай функцыі бяспечны толькі пры выкананні наступных умоў:
///
/// - Калі `T`-гэта `Sized`, выклік гэтай функцыі заўсёды бяспечны.
/// - Калі хвост `T` невялікага памеру:
///     - [slice], тады даўжыня зрэзу хваста павінна быць ініцыялізаваным цэлым лікам, а памер *усяго значэння*(дынамічная даўжыня хваста + статычны памер прэфікс) павінен змяшчацца ў `isize`.
///     - [trait object], тады частка паказальніка vtable павінна паказваць на сапраўдную vtable, набытую прымусам без змянення памеру, а памер *цэлага значэння*(дынамічная даўжыня хваста + прэфікс са статычным памерам) павінен змяшчацца ў `isize`.
///
///     - (unstable) [extern type], тады гэтую функцыю заўсёды бяспечна выклікаць, але panic можа вярнуць няправільнае значэнне, бо макет знешняга тыпу невядомы.
///     Гэта тое самае паводзіны, што і [`align_of_val`] пры спасылцы на тып з хвастом вонкавага тыпу.
///     - у адваротным выпадку кансерватыўна забараняецца выклікаць гэтую функцыю.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // БЯСПЕКА: абанент павінен прадаставіць сапраўдны сыравінны паказальнік
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Вяртае `true`, калі апусканне значэнняў тыпу `T` мае значэнне.
///
/// Гэта чыста намёк на аптымізацыю і можа быць рэалізаваны кансерватыўна:
/// ён можа вярнуць `true` для тыпаў, якія на самой справе не трэба адкідаць.
/// Такім чынам, заўсёды вяртанне `true` было б сапраўднай рэалізацыяй гэтай функцыі.Аднак калі гэтая функцыя на самай справе вяртае `false`, вы можаце быць упэўнены, што падзенне `T` не мае пабочнага эфекту.
///
/// Рэалізацыі такога ўзроўню, як калекцыі, на нізкім узроўні, якія павінны выдаляць свае дадзеныя ўручную, павінны выкарыстоўваць гэтую функцыю, каб пазбегнуць залішняй спробы скінуць усё іх змесціва пры іх разбурэнні.
///
/// Гэта можа не мець значэння ў зборках выпуску (калі цыкл, які не мае пабочных эфектаў, лёгка выяўляецца і ўхіляецца), але часта з'яўляецца вялікім выйгрышам для зборкі адладкі.
///
/// Звярніце ўвагу, што [`drop_in_place`] ужо выконвае гэтую праверку, таму, калі ваша нагрузка можа быць зменшана да невялікай колькасці выклікаў [`drop_in_place`], выкарыстоўваць гэта непатрэбна.
/// У прыватнасці, звярніце ўвагу, што вы можаце [`drop_in_place`] зрэз, і гэта зробіць адзіную праверку needs_drop для ўсіх значэнняў.
///
/// Таму такія тыпы, як Vec, проста `drop_in_place(&mut self[..])` без відавочнага выкарыстання `needs_drop`.
/// Такія тыпы, як [`HashMap`], з іншага боку, павінны скідваць значэнні па адным і павінны выкарыстоўваць гэты API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Вось прыклад таго, як калекцыя можа выкарыстоўваць `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // скінуць дадзеныя
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Вяртае значэнне тыпу `T`, прадстаўленае нулявым байт-шаблонам.
///
/// Гэта азначае, што, напрыклад, байт запаўнення ў `(u8, u16)` не абавязкова абнулены.
///
/// Няма ніякай гарантыі, што зусім нулявы шаблон байта ўяўляе сапраўднае значэнне нейкага тыпу `T`.
/// Напрыклад, зусім нулявы шаблон байта не з'яўляецца дапушчальным значэннем для спасылачных тыпаў (`&T`, `&mut T`) і паказальнікаў на функцыі.
/// Выкарыстанне `zeroed` на такіх тыпах выклікае непасрэдны [undefined behavior][ub], таму што [the Rust compiler assumes][inv] заўсёды мае правільнае значэнне ў зменнай, якую яна лічыць ініцыялізаванай.
///
///
/// Гэта мае той самы эфект, што і [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Часам гэта карысна для FFI, але яго, як правіла, трэба пазбягаць.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Правільнае выкарыстанне гэтай функцыі: ініцыялізацыя цэлага ліку нулём.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Няправільнае* выкарыстанне гэтай функцыі: ініцыялізацыя спасылкі нулём.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Неакрэсленыя паводзіны!
/// let _y: fn() = unsafe { mem::zeroed() }; // І яшчэ раз!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // БЯСПЕКА: абанент павінен гарантаваць, што для `T` сапраўднае нулявое значэнне.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Абыходзіць звычайныя праверкі ініцыялізацыі памяці Rust, робячы выгляд, што вырабляе значэнне тыпу `T`, і ўвогуле нічога не робіць.
///
/// **Гэтая функцыя састарэла.** Выкарыстоўвайце замест яе [`MaybeUninit<T>`].
///
/// Прычына састарэння складаецца ў тым, што функцыя ў асноўным не можа быць выкарыстана правільна: яна мае той жа эфект, што і [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Як тлумачыць [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] гэтыя значэнні правільна ініцыялізуюцца.
/// Як следства, выклік напрыклад
/// `mem::uninitialized::<bool>()` выклікае неадкладныя паводзіны для вяртання `bool`, які дакладна не з'яўляецца `true` або `false`.
/// Горш, па-сапраўднаму неініцыялізаваная памяць, як тое, што вяртаецца сюды, асаблівая тым, што кампілятар ведае, што яна не мае фіксаванага значэння.
/// Гэта робіць нявызначаным паводзіны наяўнасцю неініцыялізаваных дадзеных у зменнай, нават калі гэтая зменная мае цэлы тып.
/// (Звярніце ўвагу, што правілы ў дачыненні да неініцыялізаваных цэлых лікаў яшчэ не дапрацаваны, але пакуль яны не з'явіліся, пажадана іх пазбягаць)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // БЯСПЕКА: абанент павінен гарантаваць, што неіцыялізаванае значэнне сапраўднае для `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Мяняецца значэннямі ў двух зменных месцах, не дэініцыялізуючы ні адно.
///
/// * Калі вы хочаце памяняць месцамі па змаўчанні альбо фіктыўным значэннем, см. [`take`].
/// * Калі вы хочаце памяняць месцамі з перададзеным значэннем, вярнуўшы старое значэнне, глядзіце [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // БЯСПЕКА: сырыя паказальнікі былі створаны з бяспечных зменных спасылак, якія задавальняюць усім
    // абмежаванні на `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Замяняе `dest` на значэнне па змаўчанні `T`, вяртаючы папярэдняе значэнне `dest`.
///
/// * Калі вы хочаце замяніць значэнні дзвюх зменных, глядзіце [`swap`].
/// * Калі вы хочаце замяніць перададзенае значэнне замест значэння па змаўчанні, см. [`replace`].
///
/// # Examples
///
/// Просты прыклад:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` дазваляе атрымаць права ўласнасці на поле структуры, замяніўшы яго значэннем "empty".
/// Без `take` вы можаце сутыкнуцца з такімі праблемамі:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Звярніце ўвагу, што `T` не абавязкова рэалізуе [`Clone`], таму ён нават не можа кланаваць і скідваць `self.buf`.
/// Але `take` можна выкарыстоўваць для адмежавання зыходнага значэння `self.buf` ад `self`, дазваляючы вярнуць яго:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Перамяшчае `src` у спасылачны `dest`, вяртаючы папярэдняе значэнне `dest`.
///
/// Ні адно значэнне не выпадае.
///
/// * Калі вы хочаце замяніць значэнні дзвюх зменных, глядзіце [`swap`].
/// * Калі вы хочаце замяніць значэнне па змаўчанні, см. [`take`].
///
/// # Examples
///
/// Просты прыклад:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` дазваляе спажываць поле структуры, замяняючы яго іншым значэннем.
/// Без `replace` вы можаце сутыкнуцца з такімі праблемамі:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Звярніце ўвагу, што `T` не абавязкова рэалізуе [`Clone`], таму мы нават не можам кланаваць `self.buf[i]`, каб пазбегнуць пераезду.
/// Але `replace` можна выкарыстоўваць для адмежавання зыходнага значэння па гэтым індэксе ад `self`, дазваляючы вярнуць яго:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // БЯСПЕКА: Мы чытаем з `dest`, але пасля непасрэдна пішам у яго `src`,
    // такі, што старое значэнне не дублюецца.
    // Нічога не выпадае і нічога тут panic не можа.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Распараджаецца каштоўнасцю.
///
/// Гэта робіцца шляхам выкліку рэалізацыі аргумента [`Drop`][drop].
///
/// Гэта фактычна нічога не робіць для тыпаў, якія рэалізуюць `Copy`, напрыклад
/// integers.
/// Такія значэнні капіруюцца і _then_ перамяшчаецца ў функцыю, таму значэнне захоўваецца і пасля выкліку гэтай функцыі.
///
///
/// Гэтая функцыя не з'яўляецца магіяй;гэта літаральна вызначаецца як
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Паколькі `_x` перамешчаны ў функцыю, ён аўтаматычна скідаецца да вяртання функцыі.
///
/// [drop]: Drop
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // відавочна адкіньце vector
/// ```
///
/// Паколькі [`RefCell`] выконвае правілы пазыкі падчас выканання, `drop` можа вызваліць пазыку [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // адмоўцеся ад зменлівага запазычання на гэтым слоце
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// На цэлыя і іншыя тыпы, якія рэалізуюць [`Copy`], `drop` не ўплывае.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // копія `x` перамяшчаецца і выдаляецца
/// drop(y); // копія `y` перамяшчаецца і выдаляецца
///
/// println!("x: {}, y: {}", x, y.0); // усё яшчэ даступны
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Інтэрпрэтуе `src` як тып `&U`, а затым счытвае `src` без перамяшчэння змешчанага значэння.
///
/// Гэтая функцыя будзе небяспечна лічыць, што паказальнік `src` сапраўдны для байтаў [`size_of::<U>`][size_of], пераўтвараючы `&T` у `&U`, а затым счытваючы `&U` (за выключэннем таго, што гэта робіцца правільна, нават калі `&U` прад'яўляе больш строгія патрабаванні да выраўноўвання, чым `&T`).
/// Ён таксама небяспечна створыць копію змешчанага значэння замест перамяшчэння з `src`.
///
/// Гэта не памылка падчас кампіляцыі, калі `T` і `U` маюць розныя памеры, але настойліва рэкамендуецца выклікаць гэтую функцыю толькі там, дзе `T` і `U` маюць аднолькавы памер.Гэтая функцыя запускае [undefined behavior][ub], калі `U` больш, чым `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Скапіруйце дадзеныя з 'foo_array' і разглядайце іх як 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Змяніце скапіраваныя дадзеныя
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Змест 'foo_array' не павінна было мяняцца
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Калі U мае больш высокае патрабаванне выраўноўвання, src можа быць не выраўнаваны належным чынам.
    if align_of::<U>() > align_of::<T>() {
        // БЯСПЕКА: `src`-гэта спасылка, якая гарантавана будзе сапраўднай для чытання.
        // Абанент павінен гарантаваць, што рэальная трансмутацыя бяспечная.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // БЯСПЕКА: `src`-гэта спасылка, якая гарантавана будзе сапраўднай для чытання.
        // Мы толькі што праверылі правільнасць выраўноўвання `src as *const U`.
        // Абанент павінен гарантаваць, што рэальная трансмутацыя бяспечная.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Непразрысты тып, які прадстаўляе дыскрымінант пералічэння.
///
/// Для атрымання дадатковай інфармацыі глядзіце функцыю [`discriminant`] у гэтым модулі.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Гэтыя рэалізацыі Portrait немагчыма вывесці, таму што мы не хочам мець ніякіх межаў для T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Вяртае значэнне, якое адназначна ідэнтыфікуе варыянт пералічэння ў `v`.
///
/// Калі `T` не з'яўляецца пералічэннем, выклік гэтай функцыі не прывядзе да нявызначаных паводзін, але зваротнае значэнне не вызначана.
///
///
/// # Stability
///
/// Дыскрымінант варыянта пералічэння можа змяніцца пры змене вызначэння пераліку.
/// Дыскрымінант нейкага варыянту не зменіцца паміж складанкамі з адным і тым жа кампілятарам.
///
/// # Examples
///
/// Гэта можа быць выкарыстана для параўнання пералікаў, якія нясуць дадзеныя, ігнаруючы фактычныя дадзеныя:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Вяртае колькасць варыянтаў у тыпе пералічэння `T`.
///
/// Калі `T` не з'яўляецца пералічэннем, выклік гэтай функцыі не прывядзе да нявызначаных паводзін, але зваротнае значэнне не вызначана.
/// Гэтак жа, калі `T`-гэта пералік з большай колькасцю варыянтаў, чым `usize::MAX`, зваротнае значэнне не вызначана.
/// Нежылыя варыянты будуць улічаны.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}