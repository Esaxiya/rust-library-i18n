use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Абгортка, якая перашкаджае кампілятару аўтаматычна выклікаць "дэструктар".
/// Гэта абгортка 0-кошт.
///
/// `ManuallyDrop<T>` падлягае той жа аптымізацыі кампаноўкі, што і `T`.
/// Як следства, гэта не аказвае *ніякага ўплыву* на здагадкі кампілятара пра яго змест.
/// Напрыклад, ініцыялізацыя `ManuallyDrop<&mut T>` з [`mem::zeroed`]-гэта неакрэсленыя паводзіны.
/// Калі вам трэба апрацоўваць неініцыялізаваныя дадзеныя, выкарыстоўвайце замест гэтага [`MaybeUninit<T>`].
///
/// Звярніце ўвагу, што доступ да значэння ўнутры `ManuallyDrop<T>` бяспечны.
/// Гэта азначае, што `ManuallyDrop<T>`, змесціва якога было ўпушчана, нельга падвяргаць бяспечнаму публічнаму API.
/// Адпаведна, `ManuallyDrop::drop` небяспечны.
///
/// # `ManuallyDrop` і падзенне замовы.
///
/// Rust мае дакладна вызначаныя значэнні [drop order].
/// Каб пераканацца, што палі альбо лакальныя файлы адкідаюцца ў пэўным парадку, пераўпарадкуйце дэкларацыі так, каб няяўны парадак скідання быў правільным.
///
/// Можна выкарыстоўваць `ManuallyDrop` для кіравання парадкам падзення, але для гэтага патрэбны небяспечны код, і гэта цяжка зрабіць правільна пры наяўнасці раскручвання.
///
///
/// Напрыклад, калі вы хочаце пераканацца, што пэўнае поле адкінута пасля астатніх, зрабіце гэта апошнім полем структуры:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` будзе скінуты пасля `children`.
///     // Rust гарантуе выпадзенне палёў у парадку дэкларацыі.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Абгарнуць значэнне, якое трэба ўпасці ўручную.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Вы ўсё яшчэ можаце бяспечна кіраваць значэннем
    /// assert_eq!(*x, "Hello");
    /// // Але `Drop` тут працаваць не будзе
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Вымае значэнне з кантэйнера `ManuallyDrop`.
    ///
    /// Гэта дазваляе зноў скінуць значэнне.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Гэта падае `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Дастае значэнне з кантэйнера `ManuallyDrop<T>`.
    ///
    /// Гэты метад у першую чаргу прызначаны для вываду значэнняў па падзенні.
    /// Замест таго, каб выкарыстоўваць [`ManuallyDrop::drop`] для падзення значэння ўручную, вы можаце выкарыстоўваць гэты метад, каб узяць значэнне і выкарыстоўваць яго, як заўгодна.
    ///
    /// Па магчымасці, пераважна замест гэтага выкарыстоўваць [`into_inner`][`ManuallyDrop::into_inner`], які прадухіляе дубліраванне змесціва `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Гэтая функцыя семантычна перамяшчае змешчанае значэнне, не перашкаджаючы далейшаму выкарыстанню, пакідаючы стан гэтага кантэйнера нязменным.
    /// Вы абавязаны пераканацца, што гэты `ManuallyDrop` больш не выкарыстоўваецца.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // БЯСПЕКА: мы чытаем спасылку, якая гарантавана
        // быць сапраўдным для чытання.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Уручную скідае змешчанае значэнне.Гэта дакладна эквівалентна выкліку [`ptr::drop_in_place`] з указальнікам на якое змяшчаецца значэнне.
    /// Такім чынам, калі змешчанае значэнне не з'яўляецца упакаванай структурай, дэструктар будзе выкліканы на месцы без перамяшчэння значэння і, такім чынам, можа быць выкарыстаны для бяспечнага выдалення дадзеных [pinned].
    ///
    /// Калі вы валодаеце каштоўнасцю, вы можаце выкарыстоўваць [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Гэтая функцыя запускае дэструктар змешчанага значэння.
    /// Акрамя змен, унесеных самім дэструктарам, памяць застаецца нязменнай, і таму што тычыцца кампілятара, усё яшчэ захоўваецца бітавы ўзор, які дзейнічае для тыпу `T`.
    ///
    ///
    /// Аднак гэта значэнне "zombie" не павінна падвяргацца бяспечнаму коду, і гэтая функцыя не павінна быць выклікана больш за адзін раз.
    /// Выкарыстанне значэння пасля таго, як яно было скінута або падзенне значэння некалькі разоў, можа выклікаць "Невызначанае паводзіны" (у залежнасці ад таго, што робіць `drop`).
    /// Звычайна гэтаму перашкаджае сістэма тыпаў, але карыстальнікі `ManuallyDrop` павінны падтрымліваць гэтыя гарантыі без дапамогі кампілятара.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // БЯСПЕКА: мы скідаем значэнне, на якое паказвае зменлівая спасылка
        // які гарантавана будзе сапраўдным для запісаў.
        // Абанент павінен пераканацца, што `slot` зноў не будзе скінуты.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}