//! Макрасы, якія выкарыстоўваюцца ітэратарамі зрэзу.

// Убудаванне is_empty і len істотна адрозніваецца ў прадукцыйнасці
macro_rules! is_empty {
    // Як мы кадуем даўжыню ітэратара ZST, гэта працуе як для ZST, так і для ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Каб пазбавіцца ад некаторых праверак межаў (гл. `position`), мы вылічваем даўжыню некалькі нечакана.
// (Праверана `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // нас часам выкарыстоўваюць у небяспечным блоку

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // У гэтым _cannot_ выкарыстоўваецца `unchecked_sub`, таму што мы залежым ад абгорткі, каб прадставіць даўжыню доўгіх ітэратараў зрэзу ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Мы ведаем, што `start <= end`, таму можа зрабіць лепш, чым `offset_from`, які павінен мець справу ў падпісаным.
            // Усталяваўшы тут адпаведныя сцягі, мы можам сказаць LLVM пра гэта, што дапамагае выдаляць праверкі межаў.
            // БЯСПЕКА: Па тыпу інварыянт, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Таксама кажучы LLVM, што паказальнікі размешчаны дакладна па кратнасці памеру тыпу, ён можа аптымізаваць `len() == 0` да `start == end` замест `(end - start) < size`.
            //
            // БЯСПЕКА: Па тыпу інварыянта, паказальнікі выраўнаваны так
            //         адлегласць паміж імі павінна быць кратнай памеру пуанты
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Агульнае вызначэнне ітэратараў `Iter` і `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Вяртае першы элемент і перасоўвае пачатак ітэратара наперад на 1.
        // Значна паляпшае прадукцыйнасць у параўнанні са ўбудаванай функцыяй.
        // Ітэратар не павінен быць пустым.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Вяртае апошні элемент і перамяшчае канец ітэратара назад на 1.
        // Значна паляпшае прадукцыйнасць у параўнанні са ўбудаванай функцыяй.
        // Ітэратар не павінен быць пустым.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Змяншае ітэратар, калі T-ZST, перамяшчаючы канец ітэратара назад на `n`.
        // `n` не павінна перавышаць `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Дапаможная функцыя для стварэння зрэзу з ітэратара.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // БЯСПЕКА: ітэратар быў створаны з зрэзу з паказальнікам
                // `self.ptr` і даўжыня `len!(self)`.
                // Гэта гарантуе выкананне ўсіх перадумоў для `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Дапаможная функцыя для перамяшчэння пачатку ітэратара элементамі `offset` наперад, вяртаючы стары пачатак.
            //
            // Небяспечна, бо зрушэнне не павінна перавышаць `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // БЯСПЕКА: абанент гарантуе, што `offset` не перавышае `self.len()`,
                    // такім чынам, гэты новы паказальнік знаходзіцца ўнутры `self` і, такім чынам, гарантуе, што ён не з'яўляецца нулявым.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Дапаможная функцыя для перамяшчэння канца ітэратара элементамі `offset` назад, вяртаючы новы канец.
            //
            // Небяспечна, бо зрушэнне не павінна перавышаць `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // БЯСПЕКА: абанент гарантуе, што `offset` не перавышае `self.len()`,
                    // які гарантавана не перапоўніць `isize`.
                    // Акрамя таго, атрыманы паказальнік знаходзіцца ў межах `slice`, які адпавядае астатнім патрабаванням да `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // можа быць рэалізавана з фрагментамі, але гэта дазваляе пазбегнуць праверкі межаў

                // БЯСПЕКА: выклікі `assume` бяспечныя, паколькі ўказальнік пачатку зрэзу
                // павінны быць не нулявымі, а зрэзы па-за ZST таксама павінны мець ненулевы канцавы паказальнік.
                // Званок на `next_unchecked!` бяспечны, бо мы правяраем, ці ітэратар пусты.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Гэты ітэратар цяпер пусты.
                    if mem::size_of::<T>() == 0 {
                        // Мы павінны зрабіць гэта такім чынам, бо `ptr` ніколі не можа быць 0, але `end` можа быць (з-за абкручванні).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // БЯСПЕКА: end не можа быць 0, калі T не ZST, таму што ptr не 0 і end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // БЯСПЕКА: Мы ў абмежаваннях.`post_inc_start` паступае правільна нават для ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Мы адмяняем рэалізацыю па змаўчанні, якая выкарыстоўвае `try_fold`, таму што гэтая простая рэалізацыя генеруе менш ВК LLVM і хутчэй кампілюецца.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Мы адмяняем рэалізацыю па змаўчанні, якая выкарыстоўвае `try_fold`, таму што гэтая простая рэалізацыя генеруе менш ВК LLVM і хутчэй кампілюецца.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Мы адмяняем рэалізацыю па змаўчанні, якая выкарыстоўвае `try_fold`, таму што гэтая простая рэалізацыя генеруе менш ВК LLVM і хутчэй кампілюецца.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Мы адмяняем рэалізацыю па змаўчанні, якая выкарыстоўвае `try_fold`, таму што гэтая простая рэалізацыя генеруе менш ВК LLVM і хутчэй кампілюецца.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Мы адмяняем рэалізацыю па змаўчанні, якая выкарыстоўвае `try_fold`, таму што гэтая простая рэалізацыя генеруе менш ВК LLVM і хутчэй кампілюецца.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Мы адмяняем рэалізацыю па змаўчанні, якая выкарыстоўвае `try_fold`, таму што гэтая простая рэалізацыя генеруе менш ВК LLVM і хутчэй кампілюецца.
            // Акрамя таго, `assume` пазбягае праверкі межаў.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // БЯСПЕКА: нам гарантавана знаходзіцца ў межах інварыянта цыкла:
                        // калі `i >= n`, `self.next()` вяртае `None` і цыкл абрываецца.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Мы адмяняем рэалізацыю па змаўчанні, якая выкарыстоўвае `try_fold`, таму што гэтая простая рэалізацыя генеруе менш ВК LLVM і хутчэй кампілюецца.
            // Акрамя таго, `assume` пазбягае праверкі межаў.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // БЯСПЕКА: `i` павінна быць ніжэй, чым `n`, бо пачынаецца з `n`
                        // і толькі памяншаецца.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // БЯСПЕКА: абанент павінен гарантаваць, што `i` знаходзіцца ў межах
                // асноўны зрэз, таму `i` не можа перапоўніць `isize`, і вернутыя спасылкі гарантавана спасылаюцца на элемент зрэзу і, такім чынам, гарантуюць сваю сапраўднасць.
                //
                // Таксама звярніце ўвагу, што абанент таксама гарантуе, што нас больш ніколі не выклікаюць з адным і тым жа індэксам, і што ніякія іншыя метады, якія будуць атрымліваць доступ да гэтага падразрэзу, не выклікаюцца, таму сапраўдная зваротная спасылка можа быць зменнай у выпадку
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // можа быць рэалізавана з фрагментамі, але гэта дазваляе пазбегнуць праверкі межаў

                // БЯСПЕКА: выклікі `assume` бяспечныя, паколькі паказальнік запуску зрэзу павінен быць роўным нулю,
                // і зрэзы па-за ZST таксама павінны мець не нулявы ўказальнік канца.
                // Званок на `next_back_unchecked!` бяспечны, бо мы правяраем, ці ітэратар пусты.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Гэты ітэратар цяпер пусты.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // БЯСПЕКА: Мы ў абмежаваннях.`pre_dec_end` паступае правільна нават для ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}