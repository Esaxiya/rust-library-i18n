// ignore-tidy-filelength

//! Кіраванне зрэзамі і маніпуляцыі.
//!
//! Больш падрабязна гл. [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Чыстая рэалізацыя rust memchr, узята з rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Гэтая функцыя з'яўляецца агульнадаступнай толькі таму, што няма іншага спосабу адзінкавага тэставання тэмпсорту.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Вяртае колькасць элементаў у зрэзе.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // БЯСПЕКА: const гук, таму што мы трансмутуем поле даўжыні ў памер (які ён павінен быць)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // БЯСПЕКА: гэта бяспечна, паколькі `&[T]` і `FatPtr<T>` маюць аднолькавую кампаноўку.
            // Гэтую гарантыю можа даць толькі `std`.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Заменіце на `crate::ptr::metadata(self)`, калі ён стабільны на кантролі.
            // На момант напісання артыкула гэта выклікае памылку "Const-stable functions can only call other const-stable functions".
            //

            // БЯСПЕКА: Доступ да значэння з аб'яднання `PtrRepr` бяспечны, бо * const T
            // і PtrComponents<T>маюць аднолькавыя макеты памяці.
            // Гэтую гарантыю можа даць толькі std.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Вяртае `true`, калі зрэз мае даўжыню 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Вяртае першы элемент зрэзу альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Вяртае зменлівы паказальнік на першы элемент зрэзу альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Вяртае першы і ўсе астатнія элементы зрэзу альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Вяртае першы і ўсе астатнія элементы зрэзу альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Вяртае апошні і ўсе астатнія элементы зрэзу альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Вяртае апошні і ўсе астатнія элементы зрэзу альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Вяртае апошні элемент зрэзу альбо `None`, калі ён пусты.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Вяртае зменлівы паказальнік на апошні элемент зрэзу.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Вяртае спасылку на элемент альбо падраздзел у залежнасці ад тыпу індэкса.
    ///
    /// - Калі дадзена пазіцыя, вяртаецца спасылка на элемент у гэтай пазіцыі альбо `None`, калі яна выходзіць за межы.
    ///
    /// - Калі яму дадзены дыяпазон, вяртае падраздзел, які адпавядае гэтаму дыяпазону, альбо `None`, калі ён выходзіць за межы.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Вяртае зменлівую спасылку на элемент альбо падраздзел у залежнасці ад тыпу індэкса (гл. [`get`]) альбо `None`, калі індэкс выходзіць за межы.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Вяртае спасылку на элемент альбо падразак без праверкі межаў.
    ///
    /// Для бяспечнай альтэрнатывы глядзіце [`get`].
    ///
    /// # Safety
    ///
    /// Выклік гэтага метаду з індэксам па-за межамі-*[нявызначанае паводзіны]*, нават калі атрыманая спасылка не выкарыстоўваецца.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // БЯСПЕКА: абанент павінен выконваць большасць патрабаванняў бяспекі для `get_unchecked`;
        // фрагмент не паддаецца спасылцы, таму што `self` з'яўляецца бяспечнай спасылкай.
        // Вяртаецца паказальнік бяспечны, таму што імпульсы `SliceIndex` павінны гарантаваць, што ён ёсць.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Вяртае зменлівую спасылку на элемент альбо падразрэз без праверкі межаў.
    ///
    /// Для бяспечнай альтэрнатывы глядзіце [`get_mut`].
    ///
    /// # Safety
    ///
    /// Выклік гэтага метаду з індэксам па-за межамі-*[нявызначанае паводзіны]*, нават калі атрыманая спасылка не выкарыстоўваецца.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // БЯСПЕКА: абанент павінен выконваць патрабаванні бяспекі для `get_unchecked_mut`;
        // фрагмент не паддаецца спасылцы, таму што `self` з'яўляецца бяспечнай спасылкай.
        // Вяртаецца паказальнік бяспечны, таму што імпульсы `SliceIndex` павінны гарантаваць, што ён ёсць.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Вяртае неапрацаваны паказальнік на буфер зрэзу.
    ///
    /// Абанент павінен пераканацца, што зрэз перажывае паказальнік, які гэтая функцыя вяртае, інакш ён у канчатковым выніку ўказвае на смецце.
    ///
    /// Абанент таксама павінен пераканацца, што памяць, на якую паказвае паказальнік (non-transitively), ніколі не запісваецца (за выключэннем унутры `UnsafeCell`), выкарыстоўваючы гэты паказальнік альбо любы паказальнік, атрыманы з яго.
    /// Калі вам трэба змяніць змесціва зрэзу, выкарыстоўвайце [`as_mut_ptr`].
    ///
    /// Змяненне кантэйнера, на які спасылаецца гэты зрэз, можа прывесці да пераразмеркавання яго буфера, што таксама зробіць несапраўднымі ўказальнікі на яго.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Вяртае небяспечны зменлівы паказальнік на буфер зрэзу.
    ///
    /// Абанент павінен пераканацца, што зрэз перажывае паказальнік, які гэтая функцыя вяртае, інакш ён у канчатковым выніку ўказвае на смецце.
    ///
    /// Змяненне кантэйнера, на які спасылаецца гэты зрэз, можа прывесці да пераразмеркавання яго буфера, што таксама зробіць несапраўднымі ўказальнікі на яго.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Вяртае два сырыя паказальнікі, якія ахопліваюць зрэз.
    ///
    /// Вяртаецца дыяпазон напалову адкрыты, што азначае, што канцавы паказальнік паказвае *адзін мінулы* апошні элемент зрэзу.
    /// Такім чынам, пусты зрэз прадстаўлены двума аднолькавымі паказальнікамі, а розніца паміж двума паказальнікамі ўяўляе памер зрэзу.
    ///
    /// См. [`as_ptr`] для папярэджанняў аб выкарыстанні гэтых паказальнікаў.Канцавы паказальнік патрабуе асаблівай асцярожнасці, бо не паказвае на сапраўдны элемент у зрэзе.
    ///
    /// Гэтая функцыя карысная для ўзаемадзеяння з замежнымі інтэрфейсамі, якія выкарыстоўваюць два паказальнікі для спасылкі на шэраг элементаў у памяці, як гэта часта сустракаецца ў C++ .
    ///
    ///
    /// Таксама можа быць карысна праверыць, ці паказвае паказальнік на элемент на элемент гэтага зрэзу:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // БЯСПЕКА: `add` тут бяспечны, бо:
        //
        //   - Абодва паказальнікі з'яўляюцца часткай аднаго і таго ж аб'екта, бо ўказанне непасрэдна міма аб'екта таксама лічыцца.
        //
        //   - Памер зрэзу ніколі не перавышае байтаў isize::MAX, як адзначана тут:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Тут няма абкручванняў, бо зрэзы не пераносяцца міма канца адраснай прасторы.
        //
        // Глядзіце дакументацыю pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Вяртае два небяспечныя змяняемыя паказальнікі, якія ахопліваюць зрэз.
    ///
    /// Вяртаецца дыяпазон напалову адкрыты, што азначае, што канцавы паказальнік паказвае *адзін мінулы* апошні элемент зрэзу.
    /// Такім чынам, пусты зрэз прадстаўлены двума аднолькавымі паказальнікамі, а розніца паміж двума паказальнікамі ўяўляе памер зрэзу.
    ///
    /// См. [`as_mut_ptr`] для папярэджанняў аб выкарыстанні гэтых паказальнікаў.
    /// Канцавы паказальнік патрабуе асаблівай асцярожнасці, бо не паказвае на сапраўдны элемент у зрэзе.
    ///
    /// Гэтая функцыя карысная для ўзаемадзеяння з замежнымі інтэрфейсамі, якія выкарыстоўваюць два паказальнікі для спасылкі на шэраг элементаў у памяці, як гэта часта сустракаецца ў C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // БЯСПЕКА: Глядзіце as_ptr_range() вышэй, каб даведацца, чаму `add` тут бяспечны.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Мяняе два фрагменты ў зрэзе.
    ///
    /// # Arguments
    ///
    /// * a, Індэкс першага элемента
    /// * b, індэкс другога элемента
    ///
    /// # Panics
    ///
    /// Panics, калі `a` або `b` выходзяць за межы.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Немагчыма ўзяць два зменлівыя крэдыты ў аднаго vector, таму замест гэтага выкарыстоўвайце сырыя паказальнікі.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // БЯСПЕКА: `pa` і `pb` створаны з бяспечных зменных спасылак і спасылак
        // да элементаў у зрэзе і таму гарантавана справядлівыя і выраўнаваныя.
        // Звярніце ўвагу, што доступ да элементаў, якія стаяць за `a` і `b`, правераны і будзе panic, калі ён выходзіць за межы.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Змяняе парадак элементаў у зрэзе на месцы.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Для вельмі маленькіх тыпаў усе асобныя чытанні ў звычайным шляху дрэнна працуюць.
        // Мы можам зрабіць лепш, улічваючы эфектыўны невыраўнаваны load/store, загрузіўшы большы кавалак і развярнуўшы рэгістр.
        //

        // У ідэале LLVM зробіць гэта за нас, бо лепш, чым мы, ведаем, ці неэфектыўныя чытанні эфектыўныя (паколькі гэта змяняецца паміж рознымі версіямі ARM) і які лепшы памер кавалка будзе.
        // На жаль, па стане на LLVM 4.0 (2017-05) ён толькі раскочвае цыкл, таму нам трэба зрабіць гэта самастойна.
        // (Гіпотэза: зваротны бок клапотна, таму што бакі можна выраўноўваць па-рознаму-будзе, калі даўжыня няцотная-таму няма магчымасці выпраменьваць папярэднія і наступныя скачкі, каб выкарыстоўваць цалкам выраўнаваны SIMD пасярэдзіне.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Выкарыстоўвайце ўласную llvm.bswap, каб адмяніць u8 з выкарыстаннем памеру
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // БЯСПЕКА: Тут трэба праверыць некалькі рэчаў:
                //
                // - Звярніце ўвагу, што `chunk` складае 4 альбо 8 з-за праверкі CFG вышэй.Такім чынам, `chunk - 1` з'яўляецца станоўчым.
                // - Індэксацыя з дапамогай індэкса `i` выдатна, бо гарантыя правядзення цыкла
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Індэксацыя з дапамогай індэкса `ln - i - chunk = ln - (i + chunk)` выдатная:
                //   - `i + chunk > 0` трывіяльна дакладна.
                //   - Праверка цыкла гарантуе:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, такім чынам, адніманне не будзе недастатковым.
                // - Званкі `read_unaligned` і `write_unaligned` выдатныя:
                //   - `pa` паказвае на індэкс `i`, дзе `i < ln / 2 - (chunk - 1)` (гл. вышэй) і `pb` паказвае на індэкс `ln - i - chunk`, таму абодва знаходзяцца як мінімум на `chunk` на шмат байтаў ад канца `self`.
                //
                //   - Любая ініцыялізаваная памяць сапраўдная `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Выкарыстоўвайце "паварот на 16", каб змяніць нумар 16 у u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // БЯСПЕКА: неадпаведнае u32 можна прачытаць з `i`, калі `i + 1 < ln`
                // (і, відавочна, `i < ln`), таму што кожны элемент складае 2 байты, і мы чытаем 4.
                //
                // `i + chunk - 1 < ln / 2` # у той час як стан
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Паколькі гэта менш, чым даўжыня, падзеленая на 2, то яна павінна быць у межах.
                //
                // Гэта таксама азначае, што ўмова `0 < i + chunk <= ln` заўсёды выконваецца, забяспечваючы бяспечнае выкарыстанне паказальніка `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // БЯСПЕКА: `i` саступае палове даўжыні зрэзу
            // доступ да `i` і `ln - i - 1` бяспечны (`i` пачынаецца з 0 і не будзе ісці далей, чым `ln / 2 - 1`).
            // Атрыманыя ўказальнікі `pa` і `pb`, такім чынам, сапраўдныя і выраўнаваныя, і іх можна чытаць і запісваць у.
            //
            //
            unsafe {
                // Небяспечны своп, каб пазбегнуць абмежаванняў праверыць бяспечны своп.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Вяртае ітэратар па зрэзе.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Вяртае ітэратар, які дазваляе змяняць кожнае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Вяртае ітэратар па ўсім сумежным windows даўжынёй `size`.
    /// windows перакрываюцца.
    /// Калі зрэз карацейшы за `size`, ітэратар не вяртае значэнняў.
    ///
    /// # Panics
    ///
    /// Panics, калі `size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Калі зрэз карацейшы за `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з пачатку зрэзу.
    ///
    /// Кавалкі з'яўляюцца лустачкамі і не перакрываюцца.Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошні кавалак не будзе мець даўжыню `chunk_size`.
    ///
    /// Глядзіце [`chunks_exact`] для варыянта гэтага ітэратара, які вяртае кавалкі заўсёды дакладна элементаў `chunk_size`, і [`rchunks`] для таго ж ітэратара, але пачынаючы з канца зрэзу.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з пачатку зрэзу.
    ///
    /// Кавалкі з'яўляюцца зменнымі лустачкамі і не перакрываюцца.Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошні кавалак не будзе мець даўжыню `chunk_size`.
    ///
    /// Глядзіце [`chunks_exact_mut`] для варыянта гэтага ітэратара, які вяртае кавалкі заўсёды дакладна элементаў `chunk_size`, і [`rchunks_mut`] для таго ж ітэратара, але пачынаючы з канца зрэзу.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з пачатку зрэзу.
    ///
    /// Кавалкі з'яўляюцца лустачкамі і не перакрываюцца.
    /// Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошнія да `chunk_size-1` элементы будуць апушчаны і могуць быць атрыманы з функцыі `remainder` ітэратара.
    ///
    ///
    /// З-за таго, што кожны кавалак мае дакладна элементы `chunk_size`, кампілятар часта можа аптымізаваць атрыманы код лепш, чым у выпадку з [`chunks`].
    ///
    /// Глядзіце [`chunks`] для варыянта гэтага ітэратара, які таксама вяртае астатнюю частку ў выглядзе меншага фрагмента, і [`rchunks_exact`] для таго ж ітэратара, але пачынаючы з канца зрэзу.
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з пачатку зрэзу.
    ///
    /// Кавалкі з'яўляюцца зменнымі лустачкамі і не перакрываюцца.
    /// Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошнія да `chunk_size-1` элементы будуць апушчаны і могуць быць атрыманы з функцыі `into_remainder` ітэратара.
    ///
    ///
    /// З-за таго, што кожны кавалак мае дакладна элементы `chunk_size`, кампілятар часта можа аптымізаваць атрыманы код лепш, чым у выпадку з [`chunks_mut`].
    ///
    /// Глядзіце [`chunks_mut`] для варыянта гэтага ітэратара, які таксама вяртае астатнюю частку ў выглядзе меншага фрагмента, і [`rchunks_exact_mut`] для таго ж ітэратара, але пачынаючы з канца зрэзу.
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Разбівае зрэз на зрэз масіваў `N`-элементаў, мяркуючы, што астатку няма.
    ///
    ///
    /// # Safety
    ///
    /// Гэта можна назваць толькі тады
    /// - Зрэз дакладна распадаецца на кавалкі N-элемента (ён жа `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // БЯСПЕКА: кавалкі з 1 элемента ніколі не маюць астатку
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // БЯСПЕКА: даўжыня зрэзу (6) кратная 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Гэта было б беспадстаўна:
    /// // хай кавалкі: &[[_;5]]= slice.as_chunks_unchecked()//Даўжыня зрэзу не кратная 5 кавалкам:&[[_;0]]= slice.as_chunks_unchecked()//Кавалкі нулявой даўжыні ніколі не дапускаюцца
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // БЯСПЕКА: Наша перадумова-менавіта тое, што трэба назваць гэтым
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // БЯСПЕКА: Мы адліваем кавалак элементаў `new_len * N`
        // фрагмент `new_len` шмат кавалкаў элементаў `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Разбівае зрэз на зрэз масіваў з N-элементамі, пачынаючы з пачатку зрэзу, і астатні зрэз даўжынёй строга менш за `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `N` роўны 0. Гэта праверка хутчэй за ўсё зменіцца на памылку часу кампіляцыі, перш чым гэты метад стабілізуецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // БЯСПЕКА: Мы ўжо панікавалі за нуль, і гэта забяспечваецца будаўніцтвам
        // што даўжыня падразрэза кратная N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Разбівае зрэз на зрэз масіваў з N-элементамі, пачынаючы з канца зрэзу, і астатні зрэз даўжынёй строга менш за `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `N` роўны 0. Гэта праверка хутчэй за ўсё зменіцца на памылку часу кампіляцыі, перш чым гэты метад стабілізуецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // БЯСПЕКА: Мы ўжо панікавалі за нуль, і гэта забяспечваецца будаўніцтвам
        // што даўжыня падразрэза кратная N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Вяртае ітэратар над элементамі `N` зрэзу адначасова, пачынаючы з пачатку зрэзу.
    ///
    /// Кавалкі з'яўляюцца спасылкамі на масівы і не перакрываюцца.
    /// Калі `N` не падзяляе даўжыню зрэзу, то апошнія да `N-1` элементы будуць апушчаны і могуць быць атрыманы з функцыі `remainder` ітэратара.
    ///
    ///
    /// Гэты метад з'яўляецца агульным эквівалентам [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics, калі `N` роўны 0. Гэта праверка хутчэй за ўсё зменіцца на памылку часу кампіляцыі, перш чым гэты метад стабілізуецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Разбівае зрэз на зрэз масіваў `N`-элементаў, мяркуючы, што астатку няма.
    ///
    ///
    /// # Safety
    ///
    /// Гэта можна назваць толькі тады
    /// - Зрэз дакладна распадаецца на кавалкі N-элемента (ён жа `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // БЯСПЕКА: кавалкі з 1 элемента ніколі не маюць астатку
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // БЯСПЕКА: даўжыня зрэзу (6) кратная 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Гэта было б беспадстаўна:
    /// // хай кавалкі: &[[_;5]]= slice.as_chunks_unchecked_mut()//Даўжыня зрэзу не кратная 5 кавалкам:&[[_;0]]= slice.as_chunks_unchecked_mut()//Кавалкі нулявой даўжыні ніколі не дапускаюцца
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // БЯСПЕКА: Наша перадумова-менавіта тое, што трэба назваць гэтым
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // БЯСПЕКА: Мы адліваем кавалак элементаў `new_len * N`
        // фрагмент `new_len` шмат кавалкаў элементаў `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Разбівае зрэз на зрэз масіваў з N-элементамі, пачынаючы з пачатку зрэзу, і астатні зрэз даўжынёй строга менш за `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `N` роўны 0. Гэта праверка хутчэй за ўсё зменіцца на памылку часу кампіляцыі, перш чым гэты метад стабілізуецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // БЯСПЕКА: Мы ўжо панікавалі за нуль, і гэта забяспечваецца будаўніцтвам
        // што даўжыня падразрэза кратная N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Разбівае зрэз на зрэз масіваў з N-элементамі, пачынаючы з канца зрэзу, і астатні зрэз даўжынёй строга менш за `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `N` роўны 0. Гэта праверка хутчэй за ўсё зменіцца на памылку часу кампіляцыі, перш чым гэты метад стабілізуецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // БЯСПЕКА: Мы ўжо панікавалі за нуль, і гэта забяспечваецца будаўніцтвам
        // што даўжыня падразрэза кратная N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Вяртае ітэратар над элементамі `N` зрэзу адначасова, пачынаючы з пачатку зрэзу.
    ///
    /// Кавалкі з'яўляюцца зменлівымі спасылкамі на масівы і не перакрываюцца.
    /// Калі `N` не падзяляе даўжыню зрэзу, то апошнія да `N-1` элементы будуць апушчаны і могуць быць атрыманы з функцыі `into_remainder` ітэратара.
    ///
    ///
    /// Гэты метад з'яўляецца агульным эквівалентам [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics, калі `N` роўны 0. Гэта праверка хутчэй за ўсё зменіцца на памылку часу кампіляцыі, перш чым гэты метад стабілізуецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Вяртае ітэратар, які перакрывае windows элементаў `N` зрэзу, пачынаючы з пачатку зрэзу.
    ///
    ///
    /// Гэта агульны агульны эквівалент [`windows`].
    ///
    /// Калі `N` больш, чым памер зрэзу, ён не верне windows.
    ///
    /// # Panics
    ///
    /// Panics, калі `N` роўны 0.
    /// Гэтая праверка хутчэй за ўсё зменіцца на памылку часу кампіляцыі, перш чым гэты метад стабілізуецца.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з канца зрэзу.
    ///
    /// Кавалкі з'яўляюцца лустачкамі і не перакрываюцца.Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошні кавалак не будзе мець даўжыню `chunk_size`.
    ///
    /// Глядзіце [`rchunks_exact`] для варыянту гэтага ітэратара, які вяртае кавалкі заўсёды дакладна элементаў `chunk_size`, і [`chunks`] для таго ж ітэратара, але пачынаючы з пачатку зрэзу.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з канца зрэзу.
    ///
    /// Кавалкі з'яўляюцца зменнымі лустачкамі і не перакрываюцца.Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошні кавалак не будзе мець даўжыню `chunk_size`.
    ///
    /// Глядзіце [`rchunks_exact_mut`] для варыянту гэтага ітэратара, які вяртае кавалкі заўсёды дакладна элементаў `chunk_size`, і [`chunks_mut`] для таго ж ітэратара, але пачынаючы з пачатку зрэзу.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з канца зрэзу.
    ///
    /// Кавалкі з'яўляюцца лустачкамі і не перакрываюцца.
    /// Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошнія да `chunk_size-1` элементы будуць апушчаны і могуць быць атрыманы з функцыі `remainder` ітэратара.
    ///
    /// З-за таго, што кожны кавалак мае дакладна элементы `chunk_size`, кампілятар часта можа аптымізаваць атрыманы код лепш, чым у выпадку з [`chunks`].
    ///
    /// Глядзіце [`rchunks`] для варыянта гэтага ітэратара, які таксама вяртае астатнюю частку ў выглядзе меншага фрагмента, і [`chunks_exact`] для таго ж ітэратара, але пачынаючы з пачатку зрэзу.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Вяртае ітэратар над элементамі `chunk_size` зрэзу адначасова, пачынаючы з канца зрэзу.
    ///
    /// Кавалкі з'яўляюцца зменнымі лустачкамі і не перакрываюцца.
    /// Калі `chunk_size` не падзяляе даўжыню зрэзу, то апошнія да `chunk_size-1` элементы будуць апушчаны і могуць быць атрыманы з функцыі `into_remainder` ітэратара.
    ///
    /// З-за таго, што кожны кавалак мае дакладна элементы `chunk_size`, кампілятар часта можа аптымізаваць атрыманы код лепш, чым у выпадку з [`chunks_mut`].
    ///
    /// Глядзіце [`rchunks_mut`] для варыянта гэтага ітэратара, які таксама вяртае астатнюю частку ў выглядзе меншага фрагмента, і [`chunks_exact_mut`] для таго ж ітэратара, але пачынаючы з пачатку зрэзу.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `chunk_size` роўны 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Вяртае ітэратар над зрэзам, які вырабляе неперакрываюцца прагоны элементаў з выкарыстаннем прэдыката для іх падзелу.
    ///
    /// Прэдыкат называецца двума элементамі, якія ідуць за сабой, гэта азначае, што прэдыкат называецца на `slice[0]` і `slice[1]`, потым на `slice[1]` і `slice[2]` і гэтак далей.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Гэты метад можа быць выкарыстаны для вылучэння адсартаваных падлістаў:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Вяртае ітэратар па зрэзе, вырабляючы неперакрываюцца зменлівыя прагоны элементаў, выкарыстоўваючы прэдыкат для іх падзелу.
    ///
    /// Прэдыкат называецца двума элементамі, якія ідуць за сабой, гэта азначае, што прэдыкат называецца на `slice[0]` і `slice[1]`, потым на `slice[1]` і `slice[2]` і гэтак далей.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Гэты метад можа быць выкарыстаны для вылучэння адсартаваных падлістаў:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Дзеліць адзін зрэз на два па індэксе.
    ///
    /// Першы будзе ўтрымліваць усе індэксы з `[0, mid)` (за выключэннем самога індэкса `mid`), а другі будзе ўтрымліваць усе індэксы з `[mid, len)` (за выключэннем самога індэкса `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // БЯСПЕКА: `[ptr; mid]` і `[mid; len]` знаходзяцца ўнутры `self`, які
        // адпавядае патрабаванням `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Дзеліць адзін зменлівы зрэз на два па індэксе.
    ///
    /// Першы будзе ўтрымліваць усе індэксы з `[0, mid)` (за выключэннем самога індэкса `mid`), а другі будзе ўтрымліваць усе індэксы з `[mid, len)` (за выключэннем самога індэкса `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // БЯСПЕКА: `[ptr; mid]` і `[mid; len]` знаходзяцца ўнутры `self`, які
        // адпавядае патрабаванням `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Дзеліць адзін зрэз на два па індэксе, не правяраючы межы.
    ///
    /// Першы будзе ўтрымліваць усе індэксы з `[0, mid)` (за выключэннем самога індэкса `mid`), а другі будзе ўтрымліваць усе індэксы з `[mid, len)` (за выключэннем самога індэкса `len`).
    ///
    ///
    /// Для бяспечнай альтэрнатывы глядзіце [`split_at`].
    ///
    /// # Safety
    ///
    /// Выклік гэтага метаду з індэксам па-за межамі-*[нявызначанае паводзіны]*, нават калі атрыманая спасылка не выкарыстоўваецца.Абанент павінен пераканацца, што `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // БЯСПЕКА: Абанент павінен праверыць, ці ёсць `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Дзеліць адзін зменны зрэз на два па індэксе, не правяраючы межы.
    ///
    /// Першы будзе ўтрымліваць усе індэксы з `[0, mid)` (за выключэннем самога індэкса `mid`), а другі будзе ўтрымліваць усе індэксы з `[mid, len)` (за выключэннем самога індэкса `len`).
    ///
    ///
    /// Для бяспечнай альтэрнатывы глядзіце [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Выклік гэтага метаду з індэксам па-за межамі-*[нявызначанае паводзіны]*, нават калі атрыманая спасылка не выкарыстоўваецца.Абанент павінен пераканацца, што `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // БЯСПЕКА: Абанент павінен праверыць, ці ёсць `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` і `[mid; len]` не перакрываюцца, таму вяртанне зменнай спасылкі цалкам нармальна.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Вяртае ітэратар па падліцы, падзеленых элементамі, якія адпавядаюць `pred`.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Калі адпавядае першы элемент, пусты зрэз будзе першым элементам, вернутым ітэратарам.
    /// Сапраўды гэтак жа, калі супадае апошні элемент у зрэзе, пусты зрэз будзе апошнім элементам, вернутым ітэратарам:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Калі два супадаючыя элементы знаходзяцца непасрэдна побач, паміж імі будзе пусты зрэз:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Вяртае ітэратар па зменных падблісках, падзеленых элементамі, якія адпавядаюць `pred`.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Вяртае ітэратар па падліцы, падзеленых элементамі, якія адпавядаюць `pred`.
    /// Узгоднены элемент змяшчаецца ў канцы папярэдняга падразрэза як тэрмінатар.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Калі супадзе апошні элемент зрэзу, гэты элемент будзе лічыцца тэрмінатарам папярэдняга зрэзу.
    ///
    /// Гэты зрэз будзе апошнім элементам, вернутым ітэратарам.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Вяртае ітэратар па зменных падблісках, падзеленых элементамі, якія адпавядаюць `pred`.
    /// Узгоднены элемент утрымліваецца ў папярэднім падразрэзе ў якасці тэрмінатара.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Вяртае ітэратар па падслабках, падзеленых элементамі, якія адпавядаюць `pred`, пачынаючы з канца зрэзу і працуючы назад.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Як і ў выпадку з `split()`, пры супадзенні першага або апошняга элемента пусты зрэз будзе першым (альбо апошнім) элементам, які вяртаецца ітэратарам.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Вяртае ітэратар над зменлівымі падблізкамі, падзеленымі элементамі, якія адпавядаюць `pred`, пачынаючы з канца зрэзу і працуючы назад.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Вяртае ітэратар па падліцы, падзеленых элементамі, якія адпавядаюць `pred`, абмежаваны вяртаннем большасці элементаў `n`.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// Апошні вернуты элемент, калі ён ёсць, будзе ўтрымліваць астатнюю частку зрэзу.
    ///
    /// # Examples
    ///
    /// Раздрукуйце зрэз, раздзелены адзін раз на лічбы, якія дзеляцца на 3 (г.зн. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Вяртае ітэратар па падліцы, падзеленых элементамі, якія адпавядаюць `pred`, абмежаваны вяртаннем большасці элементаў `n`.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// Апошні вернуты элемент, калі ён ёсць, будзе ўтрымліваць астатнюю частку зрэзу.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Вяртае ітэратар па падблісках, падзеленых элементамі, якія адпавядаюць `pred`, абмежаваны вяртаннем не больш за элементы `n`.
    /// Гэта пачынаецца ў канцы зрэзу і працуе назад.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// Апошні вернуты элемент, калі ён ёсць, будзе ўтрымліваць астатнюю частку зрэзу.
    ///
    /// # Examples
    ///
    /// Раздрукуйце зрэз, падзелены адзін раз, пачынаючы з канца, на лічбы, якія дзеляцца на 3 (г.зн. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Вяртае ітэратар па падблісках, падзеленых элементамі, якія адпавядаюць `pred`, абмежаваны вяртаннем не больш за элементы `n`.
    /// Гэта пачынаецца ў канцы зрэзу і працуе назад.
    /// Адпаведны элемент не змяшчаецца ў падліках.
    ///
    /// Апошні вернуты элемент, калі ён ёсць, будзе ўтрымліваць астатнюю частку зрэзу.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Вяртае `true`, калі зрэз змяшчае элемент з зададзеным значэннем.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Калі ў вас няма `&T`, а проста `&U`, такі як `T: Borrow<U>` (напрыклад,
    /// `Радок: Пазычай<str>`), вы можаце выкарыстоўваць `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // кавалачак `String`
    /// assert!(v.iter().any(|e| e == "hello")); // пошук з `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Вяртае `true`, калі `needle` з'яўляецца прэфіксам зрэзу.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Заўсёды вяртае `true`, калі `needle` пусты зрэз:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Вяртае `true`, калі `needle`-гэта суфікс зрэзу.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Заўсёды вяртае `true`, калі `needle` пусты зрэз:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Вяртае падразак з выдаленым прэфіксам.
    ///
    /// Калі зрэз пачынаецца з `prefix`, вяртае падразак пасля прэфікса, загорнутага ў `Some`.
    /// Калі `prefix` пусты, проста вяртаецца зыходны зрэз.
    ///
    /// Калі зрэз не пачынаецца з `prefix`, вяртаецца `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Гэтую функцыю спатрэбіцца перапісаць, калі і калі SlicePattern стане больш дасканалым.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Вяртае падразак з выдаленым суфіксам.
    ///
    /// Калі зрэз заканчваецца `suffix`, вяртае падразак перад суфіксам, загорнутым у `Some`.
    /// Калі `suffix` пусты, проста вяртаецца зыходны зрэз.
    ///
    /// Калі зрэз не заканчваецца на `suffix`, вяртаецца `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Гэтую функцыю спатрэбіцца перапісаць, калі і калі SlicePattern стане больш дасканалым.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Бінарны пошук шукае дадзены элемент у гэтым адсартаваным зрэзе.
    ///
    /// Калі значэнне знойдзена, вяртаецца [`Result::Ok`], які змяшчае індэкс супадаючага элемента.
    /// Калі супадзенняў некалькі, можна вярнуць любы з матчаў.
    /// Калі значэнне не знойдзена, вяртаецца [`Result::Err`], які змяшчае індэкс, куды можна ўставіць адпаведны элемент, захоўваючы адсартаваны парадак.
    ///
    ///
    /// Глядзіце таксама [`binary_search_by`], [`binary_search_by_key`] і [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Шукае серыю з чатырох элементаў.
    /// Першы знойдзены з адназначна вызначаным становішчам;другі і трэці не знойдзены;чацвёрты можа адпавядаць любой пазіцыі ў `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Калі вы хочаце ўставіць элемент у адсартаваны vector, захоўваючы парадак сартавання:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Бінарны пошук гэтага сартаванага зрэзу з дапамогай функцыі параўнання.
    ///
    /// Функцыя параўнання павінна рэалізоўваць парадак, які адпавядае парадку сартавання базавага зрэзу, вяртаючы код замовы, які паказвае, ці з'яўляецца яго аргумент `Less`, `Equal` ці `Greater` жаданай мэтай.
    ///
    ///
    /// Калі значэнне знойдзена, вяртаецца [`Result::Ok`], які змяшчае індэкс супадаючага элемента.Калі супадзенняў некалькі, можна вярнуць любы з матчаў.
    /// Калі значэнне не знойдзена, вяртаецца [`Result::Err`], які змяшчае індэкс, куды можна ўставіць адпаведны элемент, захоўваючы адсартаваны парадак.
    ///
    /// Глядзіце таксама [`binary_search`], [`binary_search_by_key`] і [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Шукае серыю з чатырох элементаў.Першы знойдзены з адназначна вызначаным становішчам;другі і трэці не знойдзены;чацвёрты можа адпавядаць любой пазіцыі ў `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // БЯСПЕКА: званок робіцца бяспечным з дапамогай наступных інварыянтаў:
            // - `mid >= 0`
            // - `mid < size`: `mid` абмежаваны `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Прычына, па якой мы выкарыстоўваем кіраванне if/else, а не супадзенне, заключаецца ў тым, што супадзенне пераўпарадкоўвае аперацыі параўнання, што вельмі адчувальна.
            //
            // Гэта x86 ASM для u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Бінарны пошук шукае гэты адсартаваны фрагмент з дапамогай функцыі вымання ключа.
    ///
    /// Мяркуецца, што зрэз адсартаваны па ключы, напрыклад з [`sort_by_key`] з выкарыстаннем той жа функцыі вымання ключа.
    ///
    /// Калі значэнне знойдзена, вяртаецца [`Result::Ok`], які змяшчае індэкс супадаючага элемента.
    /// Калі супадзенняў некалькі, можна вярнуць любы з матчаў.
    /// Калі значэнне не знойдзена, вяртаецца [`Result::Err`], які змяшчае індэкс, куды можна ўставіць адпаведны элемент, захоўваючы адсартаваны парадак.
    ///
    ///
    /// Глядзіце таксама [`binary_search`], [`binary_search_by`] і [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Шукае серыю з чатырох элементаў у зрэзе пар, адсартаваных па іх другіх элементах.
    /// Першы знойдзены з адназначна вызначаным становішчам;другі і трэці не знойдзены;чацвёрты можа адпавядаць любой пазіцыі ў `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links дазволены, бо `slice::sort_by_key` ёсць у crate `alloc`, і як такі яшчэ не існуе пры стварэнні `core`.
    //
    // спасылкі на ніжэйшыя па crate: #74481.Паколькі прымітывы зафіксаваны толькі ў libstd (#73423), на практыцы гэта ніколі не прыводзіць да разрыву спасылак.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Сартуе зрэз, але можа не захаваць парадак роўных элементаў.
    ///
    /// Гэта сартаванне нестабільнае (г.зн. можа змяніць парадак роўных элементаў), на месцы (г.зн. не выдзяляе) і *O*(*n*\*log(* n*)) у горшым выпадку.
    ///
    /// # Бягучая рэалізацыя
    ///
    /// Сучасны алгарытм заснаваны на [pattern-defeating quicksort][pdqsort] ад Орсана Пітэрса, які спалучае ў сабе сярэдні хуткі выпадак рандомізаванай хуткай сартавання і хуткі найгоршы выпадак сартавання, дабіваючыся лінейнага часу на зрэзах з пэўнымі ўзорамі.
    /// Ён выкарыстоўвае некаторую рандомізацыю, каб пазбегнуць дэгенератыўных выпадкаў, але з фіксаваным seed заўсёды забяспечвае дэтэрмінаванае паводзіны.
    ///
    /// Як правіла, гэта хутчэй, чым стабільная сартаванне, за выключэннем некаторых асаблівых выпадкаў, напрыклад, калі зрэз складаецца з некалькіх аб'яднаных адсартаваных паслядоўнасцей.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Сартуе зрэз з функцыяй параўнання, але можа не захаваць парадак роўных элементаў.
    ///
    /// Гэта сартаванне нестабільнае (г.зн. можа змяніць парадак роўных элементаў), на месцы (г.зн. не выдзяляе) і *O*(*n*\*log(* n*)) у горшым выпадку.
    ///
    /// Функцыя параўнання павінна вызначаць агульны парадак элементаў зрэзу.Калі парадак не поўны, парадак элементаў не вызначаны.Заказ-гэта агульны заказ, калі ён ёсць (для ўсіх `a`, `b` і `c`):
    ///
    /// * агульны і антысіметрычны: дакладна адзін з `a < b`, `a == b` або `a > b` праўдзівы, і
    /// * пераходны, `a < b` і `b < c` мае на ўвазе `a < c`.Тое ж самае павінна быць і для `==`, і для `>`.
    ///
    /// Напрыклад, у той час як [`f64`] не рэалізуе [`Ord`], таму што `NaN != NaN`, мы можам выкарыстоўваць `partial_cmp` у якасці нашай функцыі сартавання, калі мы ведаем, што зрэз не ўтрымлівае `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Бягучая рэалізацыя
    ///
    /// Сучасны алгарытм заснаваны на [pattern-defeating quicksort][pdqsort] ад Орсана Пітэрса, які спалучае ў сабе сярэдні хуткі выпадак рандомізаванай хуткай сартавання і хуткі найгоршы выпадак сартавання, дабіваючыся лінейнага часу на зрэзах з пэўнымі ўзорамі.
    /// Ён выкарыстоўвае некаторую рандомізацыю, каб пазбегнуць дэгенератыўных выпадкаў, але з фіксаваным seed заўсёды забяспечвае дэтэрмінаванае паводзіны.
    ///
    /// Як правіла, гэта хутчэй, чым стабільная сартаванне, за выключэннем некаторых асаблівых выпадкаў, напрыклад, калі зрэз складаецца з некалькіх аб'яднаных адсартаваных паслядоўнасцей.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // зваротная сартаванне
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Сартуе зрэз з функцыяй вымання ключа, але можа не захаваць парадак роўных элементаў.
    ///
    /// Гэта сартаванне нестабільнае (г.зн. можа змяніць парадак роўных элементаў), на месцы (г.зн. не выдзяляе) і *O*(m\* * n *\* log(*n*)) у горшым выпадку, дзе ключавой функцыяй з'яўляецца *O*(*м*).
    ///
    /// # Бягучая рэалізацыя
    ///
    /// Сучасны алгарытм заснаваны на [pattern-defeating quicksort][pdqsort] ад Орсана Пітэрса, які спалучае ў сабе сярэдні хуткі выпадак рандомізаванай хуткай сартавання і хуткі найгоршы выпадак сартавання, дабіваючыся лінейнага часу на зрэзах з пэўнымі ўзорамі.
    /// Ён выкарыстоўвае некаторую рандомізацыю, каб пазбегнуць дэгенератыўных выпадкаў, але з фіксаваным seed заўсёды забяспечвае дэтэрмінаванае паводзіны.
    ///
    /// З-за сваёй стратэгіі ключавых выклікаў [`sort_unstable_by_key`](#method.sort_unstable_by_key), верагодна, будзе павольней, чым [`sort_by_cached_key`](#method.sort_by_cached_key), у тых выпадках, калі ключавая функцыя дарагая.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Змяніце парадак зрэзу так, каб элемент у `index` знаходзіўся ў канчатковым адсартаваным становішчы.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Змяніце парадак зрэзу з дапамогай функцыі параўнання, каб элемент у `index` знаходзіўся ў канчатковым сартаваным становішчы.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Змяніце парадак зрэзу з дапамогай функцыі вымання ключа, каб элемент у `index` знаходзіўся ў канчатковым сартаваным становішчы.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Змяніце парадак зрэзу так, каб элемент у `index` знаходзіўся ў канчатковым адсартаваным становішчы.
    ///
    /// Гэтая ўпарадкаванне мае дадатковае ўласцівасць, што любое значэнне ў пазіцыі `i < index` будзе менш альбо роўнае любому значэнню ў пазіцыі `j > index`.
    /// Акрамя таго, гэта пераўпарадкаванне нестабільна (г.зн.
    /// любая колькасць роўных элементаў можа апынуцца ў становішчы `index`), на месцы (г.зн.
    /// не выдзяляе) і *O*(*n*) у горшым выпадку.
    /// Гэтая функцыя таксама/вядомая як "kth element" у іншых бібліятэках.
    /// Ён вяртае трыплет наступных значэнняў: усе элементы менш, чым адзін у дадзеным індэксе, значэнне ў дадзеным індэксе і ўсе элементы, большыя за адзін у дадзеным індэксе.
    ///
    ///
    /// # Бягучая рэалізацыя
    ///
    /// Бягучы алгарытм заснаваны на частцы хуткага выбару таго ж алгарытму хуткай сартавання, які выкарыстоўваецца для [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, калі `index >= len()`, гэта азначае, што заўсёды panics на пустых зрэзах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Знайдзіце медыяну
    /// v.select_nth_unstable(2);
    ///
    /// // Мы гарантуем толькі, што зрэз будзе адным з наступных, заснаваны на спосабе сартавання па зададзеным індэксе.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Змяніце парадак зрэзу з дапамогай функцыі параўнання, каб элемент у `index` знаходзіўся ў канчатковым сартаваным становішчы.
    ///
    /// Гэтая пераўпарадкаванне мае дадатковае ўласцівасць, што любое значэнне ў пазіцыі `i < index` будзе менш альбо роўна любому значэнню ў пазіцыі `j > index` з выкарыстаннем функцыі параўнання.
    /// Акрамя таго, гэта пераўпарадкаванне нестабільна (г.зн. любая колькасць роўных элементаў можа апынуцца ў становішчы `index`), на месцы (г. зн. Не выдзяляецца) і *O*(*n*) у горшым выпадку.
    /// У іншых бібліятэках гэтая функцыя таксама вядомая як "kth element".
    /// Ён вяртае трыплет наступных значэнняў: усе элементы, меншыя за адзін у дадзеным індэксе, значэнне ў дадзеным індэксе, і ўсе элементы, большыя за адзін у дадзеным індэксе, з выкарыстаннем прадстаўленай функцыі параўнання.
    ///
    ///
    /// # Бягучая рэалізацыя
    ///
    /// Бягучы алгарытм заснаваны на частцы хуткага выбару таго ж алгарытму хуткай сартавання, які выкарыстоўваецца для [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, калі `index >= len()`, гэта азначае, што заўсёды panics на пустых зрэзах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Знайдзіце медыяну, як бы зрэз быў адсартаваны ў парадку змяншэння.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Мы гарантуем толькі, што зрэз будзе адным з наступных, заснаваны на спосабе сартавання па зададзеным індэксе.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Змяніце парадак зрэзу з дапамогай функцыі вымання ключа, каб элемент у `index` знаходзіўся ў канчатковым сартаваным становішчы.
    ///
    /// Гэтая пераўпарадкаванне мае дадатковае ўласцівасць, што любое значэнне ў пазіцыі `i < index` будзе менш альбо роўна любому значэнню ў пазіцыі `j > index` з выкарыстаннем функцыі вымання ключа.
    /// Акрамя таго, гэта пераўпарадкаванне нестабільна (г.зн. любая колькасць роўных элементаў можа апынуцца ў становішчы `index`), на месцы (г. зн. Не выдзяляецца) і *O*(*n*) у горшым выпадку.
    /// У іншых бібліятэках гэтая функцыя таксама вядомая як "kth element".
    /// Ён вяртае трыплет наступных значэнняў: усе элементы, меншыя за адзін у дадзеным індэксе, значэнне ў дадзеным індэксе і ўсе элементы, большыя за адзін у дадзеным індэксе, з выкарыстаннем прадастаўленай функцыі вымання ключа.
    ///
    ///
    /// # Бягучая рэалізацыя
    ///
    /// Бягучы алгарытм заснаваны на частцы хуткага выбару таго ж алгарытму хуткай сартавання, які выкарыстоўваецца для [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, калі `index >= len()`, гэта азначае, што заўсёды panics на пустых зрэзах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Вяртае медыяну, як калі б масіў быў адсартаваны па абсалютным значэнні.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Мы гарантуем толькі, што зрэз будзе адным з наступных, заснаваны на спосабе сартавання па зададзеным індэксе.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Перамяшчае ўсе паслядоўныя паўтараюцца элементы ў канец зрэзу ў адпаведнасці з рэалізацыяй [`PartialEq`] Portrait.
    ///
    ///
    /// Вяртае два зрэзы.Першы не ўтрымлівае паслядоўных паўтаральных элементаў.
    /// Другі змяшчае ўсе дублікаты ў не вызначаным парадку.
    ///
    /// Калі зрэз адсартаваны, першы вернуты зрэз не ўтрымлівае дублікатаў.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Перамяшчае ўсе, акрамя першага з паслядоўных элементаў, у канец зрэзу, задавальняючы зададзенае суадносіны роўнасці.
    ///
    /// Вяртае два зрэзы.Першы не ўтрымлівае паслядоўных паўтаральных элементаў.
    /// Другі змяшчае ўсе дублікаты ў не вызначаным парадку.
    ///
    /// Функцыя `same_bucket` перадае спасылкі на два элементы з зрэзу і павінна вызначыць, калі элементы параўноўваюцца роўнымі.
    /// Элементы перадаюцца ў парадку, процілеглым парадку ў зрэзе, таму, калі `same_bucket(a, b)` вяртае `true`, `a` перамяшчаецца ў канец зрэзу.
    ///
    ///
    /// Калі зрэз адсартаваны, першы вернуты зрэз не ўтрымлівае дублікатаў.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Хоць у нас ёсць зменная спасылка на `self`, мы не можам уносіць *адвольныя* змены.Званкі `same_bucket` могуць мець panic, таму мы павінны пераканацца, што зрэз увесь час знаходзіцца ў сапраўдным стане.
        //
        // Мы спраўляемся з гэтым, выкарыстоўваючы свопы;мы перабіраем усе элементы, мяняючыся месцамі, каб у канцы элементы, якія мы хочам захаваць, былі спераду, а тыя, якіх мы хочам адхіліць,-ззаду.
        // Затым мы можам падзяліць лустачку.
        // Гэта аперацыя па-ранейшаму `O(n)`.
        //
        // Прыклад: Мы пачынаем з гэтага стану, дзе `r` азначае "наступны"
        // чытаць "і `w` ўяўляе" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Параўноўваючы self[r] з самастойным [w-1], гэта не дублікат, таму мы памяняем месцамі self[r] і self[w] (эфекту няма як r==w), а затым павялічым і r, і ш, пакінуўшы нам:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Параўноўваючы self[r] з самастойным [w-1], гэта значэнне паўтараецца, таму мы павялічваем `r`, але ўсё астатняе пакідаем нязменным:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Параўноўваючы self[r] з уласным [w-1], гэта не дублікат, таму памяняйце месцамі self[r] і self[w] і пракруціце r і w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Не дублікат, паўтарыце:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Дублікат, advance r. End зрэзу.Раскол на ж.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // БЯСПЕКА: умова `while` гарантуе `next_read` і `next_write`
        // менш `len`, такім чынам, знаходзяцца ўнутры `self`.
        // `prev_ptr_write` паказвае на адзін элемент перад `ptr_write`, але `next_write` пачынаецца з 1, таму `prev_ptr_write` ніколі не менш за 0 і знаходзіцца ўнутры зрэзу.
        // Гэта адпавядае патрабаванням для разметкі `ptr_read`, `prev_ptr_write` і `ptr_write`, а таксама для выкарыстання `ptr.add(next_read)`, `ptr.add(next_write - 1)` і `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` таксама павялічваецца не больш за адзін раз за цыкл, максімум азначае, што не прапускаецца ні адзін элемент, калі яго, магчыма, трэба памяняць.
        //
        // `ptr_read` і `prev_ptr_write` ніколі не паказваюць на адзін і той жа элемент.Гэта неабходна для бяспекі `&mut *ptr_read`, `&mut* prev_ptr_write`.
        // Тлумачэнне проста ў тым, што `next_read >= next_write` заўсёды адпавядае рэчаіснасці, таму `next_read > next_write - 1`-таксама.
        //
        //
        //
        //
        //
        unsafe {
            // Пазбягайце праверкі межаў, выкарыстоўваючы сырыя паказальнікі.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Перамяшчае ўсе, акрамя першага, паслядоўных элементаў у канец зрэзу, які вырашаецца ў адзін і той жа ключ.
    ///
    ///
    /// Вяртае два зрэзы.Першы не ўтрымлівае паслядоўных паўтаральных элементаў.
    /// Другі змяшчае ўсе дублікаты ў не вызначаным парадку.
    ///
    /// Калі зрэз адсартаваны, першы вернуты зрэз не ўтрымлівае дублікатаў.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Паварочвае зрэз на месцы так, што першыя элементы `mid` зрэзу перамяшчаюцца ў канец, а апошнія элементы `self.len() - mid`-у пярэднюю.
    /// Пасля выкліку `rotate_left` элемент, які раней быў з індэксам `mid`, стане першым элементам у зрэзе.
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі `mid` перавышае даўжыню зрэзу.Звярніце ўвагу, што `mid == self.len()` робіць _not_ panic і не абарачаецца.
    ///
    /// # Complexity
    ///
    /// Прымае лінейны (у `self.len()`) час.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Паварот падразрэзу:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // БЯСПЕКА: Дыяпазон `[p.add(mid) - mid, p.add(mid) + k)` трывіяльны
        // сапраўдны для чытання і пісьма, як патрабуе `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Паварочвае зрэз на месцы так, што першыя элементы `self.len() - k` зрэзу перамяшчаюцца ў канец, а апошнія элементы `k`-у пярэднюю.
    /// Пасля выкліку `rotate_right` элемент, які раней быў з індэксам `self.len() - k`, стане першым элементам у зрэзе.
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі `k` перавышае даўжыню зрэзу.Звярніце ўвагу, што `k == self.len()` робіць _not_ panic і не абарачаецца.
    ///
    /// # Complexity
    ///
    /// Прымае лінейны (у `self.len()`) час.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Павярнуць субсліца:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // БЯСПЕКА: Дыяпазон `[p.add(mid) - mid, p.add(mid) + k)` трывіяльны
        // сапраўдны для чытання і пісьма, як патрабуе `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Запаўняе элементы `self` элементамі шляхам кланавання `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Запаўняе `self` элементамі, якія вяртаюцца шляхам неаднаразовага выкліку закрыцця.
    ///
    /// Гэты метад выкарыстоўвае закрыццё для стварэння новых значэнняў.Калі вы аддаеце перавагу [`Clone`] зададзенага значэння, выкарыстоўвайце [`fill`].
    /// Калі вы хочаце выкарыстоўваць [`Default`] Portrait для генерацыі значэнняў, вы можаце перадаць [`Default::default`] у якасці аргумента.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Капіруе элементы з `src` у `self`.
    ///
    /// Даўжыня `src` павінна быць такой жа, як і `self`.
    ///
    /// Калі `T` рэалізуе `Copy`, выкарыстанне [`copy_from_slice`] можа быць больш эфектыўным.
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі два зрэзы маюць розную даўжыню.
    ///
    /// # Examples
    ///
    /// Кланаванне двух элементаў з зрэзу ў іншы:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Паколькі зрэзы павінны быць аднолькавай даўжыні, мы разразаем зыходны зрэз з чатырох элементаў на два.
    /// // Калі мы гэтага не зробім, гэта будзе panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust забяспечвае, што можа быць толькі адна зменная спасылка без нязменных спасылак на пэўную частку дадзеных у пэўным аб'ёме.
    /// З-за гэтага спроба выкарыстання `clone_from_slice` на адным зрэзе прывядзе да збою кампіляцыі:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Каб абысці гэта, мы можам выкарыстоўваць [`split_at_mut`] для стварэння двух асобных падразрэзаў з зрэзу:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Капіруе ўсе элементы з `src` у `self`, выкарыстоўваючы memcpy.
    ///
    /// Даўжыня `src` павінна быць такой жа, як і `self`.
    ///
    /// Калі `T` не рэалізуе `Copy`, выкарыстоўвайце [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі два зрэзы маюць розную даўжыню.
    ///
    /// # Examples
    ///
    /// Капіраванне двух элементаў з зрэзу ў іншы:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Паколькі зрэзы павінны быць аднолькавай даўжыні, мы разразаем зыходны зрэз з чатырох элементаў на два.
    /// // Калі мы гэтага не зробім, гэта будзе panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust забяспечвае, што можа быць толькі адна зменная спасылка без нязменных спасылак на пэўную частку дадзеных у пэўным аб'ёме.
    /// З-за гэтага спроба выкарыстання `copy_from_slice` на адным зрэзе прывядзе да збою кампіляцыі:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Каб абысці гэта, мы можам выкарыстоўваць [`split_at_mut`] для стварэння двух асобных падразрэзаў з зрэзу:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Шлях кода panic быў пераведзены ў халодную функцыю, каб не раздуваць сайт выкліку.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // БЯСПЕКА: `self` сапраўдны для элементаў `self.len()` па вызначэнні, і `src` быў
        // праверана, каб мець аднолькавую даўжыню.
        // Зрэзы не могуць перакрывацца, таму што змяняныя спасылкі з'яўляюцца эксклюзіўнымі.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Капіруе элементы з адной часткі зрэзу ў іншую частку сябе, выкарыстоўваючы меммове.
    ///
    /// `src` гэта дыяпазон у межах `self` для капіравання.
    /// `dest` - пачатковы індэкс дыяпазону ў межах `self` для капіравання, які будзе мець тую ж даўжыню, што і `src`.
    /// Два дыяпазоны могуць перакрывацца.
    /// Канцы двух дыяпазонаў павінны быць менш або роўныя `self.len()`.
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі альбо дыяпазон перавышае канец зрэзу, альбо калі канец `src` перад пачаткам.
    ///
    ///
    /// # Examples
    ///
    /// Капіраванне чатырох байтаў у зрэзе:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // БЯСПЕКА: усе ўмовы для `ptr::copy` былі правераны вышэй,
        // як і для `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Замяняе ўсе элементы ў `self` з элементамі ў `other`.
    ///
    /// Даўжыня `other` павінна быць такой жа, як і `self`.
    ///
    /// # Panics
    ///
    /// Гэтая функцыя будзе panic, калі два зрэзы маюць розную даўжыню.
    ///
    /// # Example
    ///
    /// Абмен двума элементамі па зрэзах:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust забяспечвае, што можа быць толькі адна зменная спасылка на пэўную частку дадзеных у пэўным аб'ёме.
    ///
    /// З-за гэтага спроба выкарыстання `swap_with_slice` на адным зрэзе прывядзе да збою кампіляцыі:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Каб абысці гэта, мы можам выкарыстоўваць [`split_at_mut`] для стварэння двух асобных зменных падрэзаў з зрэзу:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // БЯСПЕКА: `self` сапраўдны для элементаў `self.len()` па вызначэнні, і `src` быў
        // праверана, каб мець аднолькавую даўжыню.
        // Зрэзы не могуць перакрывацца, таму што змяняныя спасылкі з'яўляюцца эксклюзіўнымі.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Функцыя вылічэння даўжыні сярэдняга і задняга зрэзу для `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Што мы зробім з `rest`, так гэта высветліць, колькі кратных знакаў мы можам змясціць у найменшую колькасць "T".
        //
        // І колькі "Т" нам трэба для кожнага такога "multiple".
        //
        // Разгледзім, напрыклад, T=u8 U=u16.Тады мы можам паставіць 1 U у 2 Ts.Просты.
        // Зараз, разгледзім напрыклад выпадак, калі size_of: :<T>=16, памер_::::<U>24.</u>
        // Мы можам паставіць 2 Us замест кожных 3 Ts ў зрэзе `rest`.
        // Крыху больш складана.
        //
        // Формула для разліку:
        //
        // Нас= lcm(size_of::<T>, size_of::<U>)/памер_з: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/памер_а::</u><T>
        //
        // Пашыраны і спрошчаны:
        //
        // Нас=памер_: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=памер_::::<U>gcd(size_of::<T>, size_of::<U>)</u>
        //
        // На шчасце, бо ўсё гэта пастаянна ацэньваецца ... прадукцыйнасць тут не мае значэння!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // ітэратыўны алгарытм Штэйна Мы ўсё роўна павінны зрабіць гэты `const fn` (і вярнуцца да рэкурсіўнага алгарытму, калі мы гэта зробім), таму што спадзяванне на llvm для суцяшэння ўсё гэта ... ну, мне няёмка.
            //
            //

            // БЯСПЕКА: `a` і `b` правяраюцца як ненулявыя значэнні.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // выдаліць усе фактары 2 з b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // БЯСПЕКА: `b` правераны як ненулявы.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Узброіўшыся гэтымі ведамі, мы можам знайсці, колькі мы можам змясціць!
        let us_len = self.len() / ts * us;
        // А колькі "T" будзе ў завяршальным зрэзе!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Трансмутуйце зрэз у зрэз іншага тыпу, забяспечваючы выраўноўванне тыпаў.
    ///
    /// Гэты метад падзяляе зрэз на тры розныя зрэзы: прэфікс, правільна выраўнаваны сярэдні зрэз новага тыпу і зрэз суфікса.
    /// Метад можа зрабіць сярэдні зрэз максімальна магчымай даўжынёй для дадзенага тыпу і ўводнага зрэзу, але толькі прадукцыйнасць вашага алгарытму павінна залежаць ад гэтага, а не яго правільнасці.
    ///
    /// Дапушчальна, каб усе зыходныя дадзеныя вярталіся ў якасці зрэзу прэфікса або суфікса.
    ///
    /// Гэты метад не мае мэты, калі альбо ўводны элемент `T`, альбо выхадны элемент `U` маюць нулявы памер і вернуць зыходны зрэз, нічога не падзяляючы.
    ///
    /// # Safety
    ///
    /// Гэты метад па сутнасці з'яўляецца `transmute` у дачыненні да элементаў у вернутым сярэднім зрэзе, таму тут таксама прымяняюцца ўсе звычайныя агаворкі, якія тычацца `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Звярніце ўвагу, што большая частка гэтай функцыі будзе ацэньвацца пастаянна,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // звяртайцеся з ZST спецыяльна, а гэта значыць-зусім не звяртайцеся з імі.
            return (self, &[], &[]);
        }

        // Па-першае, знайдзіце, у які момант мы падзяляем першы і другі зрэзы.
        // З ptr.align_offset лёгка.
        let ptr = self.as_ptr();
        // БЯСПЕКА: Падрабязныя каментарыі па бяспецы гл. Метад `align_to_mut`.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // БЯСПЕКА: зараз `rest` дакладна выраўнаваны, таму `from_raw_parts` ніжэй-гэта нармальна,
            // паколькі абанент гарантуе, што мы можам бяспечна пераўтварыць `T` у `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Трансмутуйце зрэз у зрэз іншага тыпу, забяспечваючы выраўноўванне тыпаў.
    ///
    /// Гэты метад падзяляе зрэз на тры розныя зрэзы: прэфікс, правільна выраўнаваны сярэдні зрэз новага тыпу і зрэз суфікса.
    /// Метад можа зрабіць сярэдні зрэз максімальна магчымай даўжынёй для дадзенага тыпу і ўводнага зрэзу, але толькі прадукцыйнасць вашага алгарытму павінна залежаць ад гэтага, а не яго правільнасці.
    ///
    /// Дапушчальна, каб усе зыходныя дадзеныя вярталіся ў якасці зрэзу прэфікса або суфікса.
    ///
    /// Гэты метад не мае мэты, калі альбо ўводны элемент `T`, альбо выхадны элемент `U` маюць нулявы памер і вернуць зыходны зрэз, нічога не падзяляючы.
    ///
    /// # Safety
    ///
    /// Гэты метад па сутнасці з'яўляецца `transmute` у дачыненні да элементаў у вернутым сярэднім зрэзе, таму тут таксама прымяняюцца ўсе звычайныя агаворкі, якія тычацца `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Звярніце ўвагу, што большая частка гэтай функцыі будзе ацэньвацца пастаянна,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // звяртайцеся з ZST спецыяльна, а гэта значыць-зусім не звяртайцеся з імі.
            return (self, &mut [], &mut []);
        }

        // Па-першае, знайдзіце, у які момант мы падзяляем першы і другі зрэзы.
        // З ptr.align_offset лёгка.
        let ptr = self.as_ptr();
        // БЯСПЕКА: Тут мы гарантуем, што будзем выкарыстоўваць выраўнаваныя паказальнікі для U для
        // астатняя частка метаду.Гэта робіцца шляхам перадачы паказальніка на&[T] з выраўноўваннем, прызначаным для U.
        // `crate::ptr::align_offset` выклікаецца з правільна выраўнаваным і сапраўдным паказальнікам `ptr` (ён паходзіць ад спасылкі на `self`) і з памерам, які складае ступень у два (бо паходзіць ад адчужэння для U), задавальняючы яго абмежаванням бяспекі.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Пасля гэтага мы не можам выкарыстоўваць `rest` яшчэ раз, што скасавала б яго псеўданім `mut_ptr`!БЯСПЕКА: гл. Каментарыі да `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Правярае, ці адсартаваны элементы гэтага зрэзу.
    ///
    /// Гэта значыць, для кожнага элемента `a` і яго наступнага элемента `b` павінен мець месца `a <= b`.Калі зрэз дае роўна нуль альбо адзін элемент, вяртаецца `true`.
    ///
    /// Звярніце ўвагу, што калі `Self::Item`-гэта толькі `PartialOrd`, але не `Ord`, прыведзенае вышэй вызначэнне азначае, што гэтая функцыя вяртае `false`, калі любыя два паслядоўныя элементы не супастаўныя.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Правярае, ці адсартаваны элементы гэтага зрэзу з выкарыстаннем зададзенай функцыі параўнання.
    ///
    /// Замест выкарыстання `PartialOrd::partial_cmp` гэтая функцыя выкарыстоўвае зададзеную функцыю `compare` для вызначэння ўпарадкавання двух элементаў.
    /// Акрамя гэтага, гэта эквівалентна [`is_sorted`];для атрымання дадатковай інфармацыі глядзіце яго дакументацыю.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Правярае, ці адсартаваны элементы гэтага зрэзу з выкарыстаннем зададзенай функцыі вымання ключа.
    ///
    /// Замест таго, каб параўноўваць элементы зрэзу непасрэдна, гэтая функцыя параўноўвае ключы элементаў, як гэта вызначана `f`.
    /// Акрамя гэтага, гэта эквівалентна [`is_sorted`];для атрымання дадатковай інфармацыі глядзіце яго дакументацыю.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Вяртае індэкс пункту раздзела ў адпаведнасці з дадзеным прэдыкатам (індэкс першага элемента другога раздзела).
    ///
    /// Мяркуецца, што зрэз падзелены ў адпаведнасці з дадзеным прэдыкатам.
    /// Гэта азначае, што ўсе элементы, для якіх прэдыкат вяртае true, знаходзяцца ў пачатку зрэзу, а ўсе элементы, для якіх прэдыкат вяртае false, знаходзяцца ў канцы.
    ///
    /// Напрыклад, [7, 15, 3, 5, 4, 12, 6]-гэта раздзелены пад прэдыкатам x% 2!=0 (усе няцотныя лікі ў пачатку, усе цотныя ў канцы).
    ///
    /// Калі гэты зрэз не падзелены, атрыманы вынік не вызначаны і бессэнсоўны, бо гэты метад выконвае свайго роду двайковы пошук.
    ///
    /// Глядзіце таксама [`binary_search`], [`binary_search_by`] і [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // БЯСПЕКА: калі `left < right`, `left <= mid < right`.
            // Таму `left` заўсёды павялічваецца, а `right` заўсёды памяншаецца, і выбіраецца любы з іх.У абодвух выпадках `left <= right` задаволены.Такім чынам, калі `left < right` у кроку, `left <= right` задаволены на наступным этапе.
            //
            // Такім чынам, пакуль `left != right`, `0 <= left < right <= len` задаволены, і калі гэты выпадак `0 <= mid < len` таксама задаволены.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Нам трэба відавочна нарэзаць іх аднолькавай даўжыні
        // каб палегчыць аптымізатар праверку межаў.
        // Але паколькі на гэта нельга разлічваць, мы таксама маем відавочную спецыялізацыю для T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Стварае пусты зрэз.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Стварае зменлівы пусты зрэз.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Шаблоны ў зрэзах, у цяперашні час выкарыстоўваюцца толькі ў `strip_prefix` і `strip_suffix`.
/// У кропцы future мы спадзяемся абагульніць `core::str::Pattern` (які на момант напісання артыкула абмежаваны `str`) на зрэзы, а потым гэты Portrait будзе заменены альбо адменены.
///
pub trait SlicePattern {
    /// Тып элемента зрэзу, з якім супастаўляецца.
    type Item;

    /// У цяперашні час спажыўцам `SlicePattern` патрэбны кавалачак.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}