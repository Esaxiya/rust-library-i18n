// Арыгінальная рэалізацыя ўзята з rust-memchr.
// Аўтарскае права 2015 Эндру Галант, Блюс і Нікалас Кох

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Выкарыстоўвайце ўсеканне.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Вяртае `true`, калі `x` змяшчае нулявы байт.
///
/// З *Matters Computational*, Дж. Арндт:
///
/// "Ідэя складаецца ў тым, каб з кожнага байта адняць па адным, а потым шукаць байты, дзе запазычанне распаўсюджваецца аж да найбольш значных
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Вяртае першы індэкс, які адпавядае байту `x` у `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Хуткі шлях для невялікіх лустачак
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Адшукайце адно байтавае значэнне, прачытаўшы адначасова два словы `usize`.
    //
    // Раскол `text` на тры часткі
    // - неадпаведная пачатковая частка перад тэкставым адрасам, выраўнаваным па першым слове
    // - цела, скануйце па 2 словы адначасова
    // - апошняя частка, якая засталася, <2 памер слова

    // пошук да выраўнаванай мяжы
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // шукаць тэкст
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // БЯСПЕКА: прэдыкат while гарантуе адлегласць не менш за 2 * usize_bytes
        // паміж зрушэннем і канцом зрэзу.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break, калі ёсць адпаведны байт
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Знайдзіце байт пасля таго, як пятля цела спынілася.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Вяртае апошні індэкс, які адпавядае байту `x` у `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Адшукайце адно байтавае значэнне, прачытаўшы адначасова два словы `usize`.
    //
    // Раскол `text` на тры часткі:
    // - нявыраўнаваны хвост пасля выраўнаванага па тэксце адраса ў тэксце,
    // - цела, сканаванае па 2 словы адначасова,
    // - першыя байты, якія засталіся, памер <2 словы.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Мы называем гэта проста для атрымання даўжыні прэфікса і суфікса.
        // У сярэдзіне мы заўсёды апрацоўваем адразу два кавалкі.
        // БЯСПЕКА: пераўтварэнне `[u8]` у `[usize]` бяспечна, за выключэннем адрозненняў у памерах, якія апрацоўваюцца `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Шукайце тэкст тэксту, пераканайцеся, што мы не перасякаем min_aligned_offset.
    // зрушэнне заўсёды выраўноўваецца, таму дастаткова праверыць `>` і пазбегнуць магчымага перапаўнення.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // БЯСПЕКА: зрушэнне пачынаецца з len, suffix.len(), пакуль яно большае за
        // min_aligned_offset (prefix.len()) астатняя адлегласць складае не менш за 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Перапынак, калі ёсць адпаведны байт.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Знайдзіце байт да кропкі, калі цыкл цела спыніўся.
    text[..offset].iter().rposition(|elt| *elt == x)
}