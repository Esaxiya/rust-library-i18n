//! Сартаванне зрэзаў
//!
//! Гэты модуль утрымлівае алгарытм сартавання, заснаваны на хуткай сартыроўцы Орсона Пітэрса, апублікаванай па адрасе: <https://github.com/orlp/pdqsort>
//!
//!
//! Няўстойлівае сартаванне сумяшчальна з libcore, паколькі не выдзяляе памяці, у адрозненне ад нашай стабільнай рэалізацыі.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Пры падзенні капіруе з `src` у `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // БЯСПЕКА: Гэта дапаможны клас.
        //          Звярніцеся да правільнасці яго выкарыстання.
        //          А менавіта, трэба быць упэўненым, што `src` і `dst` не перакрываюцца, як таго патрабуе `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Змяшчае першы элемент направа, пакуль не сустрэне большы альбо роўны элемент.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЯСПЕКА: Небяспечныя аперацыі ніжэй уключаюць індэксацыю без абавязковай праверкі (`get_unchecked` і `get_unchecked_mut`)
    // і капіраванне памяці (`ptr::copy_nonoverlapping`).
    //
    // а.Індэксацыя:
    //  1. Мы праверылі памер масіва на>=2.
    //  2. Усе індэксацыі, якія мы будзем рабіць, заўсёды складаюць не больш за {0 <= index < len}.
    //
    // б.Капіраванне памяці
    //  1. Мы атрымліваем указальнікі на спасылкі, якія гарантавана будуць сапраўднымі.
    //  2. Яны не могуць перакрывацца, таму што мы атрымліваем паказальнікі на індэксы адрозненняў зрэзу.
    //     А менавіта `i` і `i-1`.
    //  3. Калі зрэз правільна выраўнаваны, элементы правільна выраўнаваны.
    //     Абавязак абанента-пераканацца, што зрэз правільна выраўнаваны.
    //
    // Больш падрабязна глядзіце каментары ніжэй.
    unsafe {
        // Калі першыя два элементы не працуюць ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Прачытайце першы элемент у выдзеленай стэку зменнай.
            // Калі наступная аперацыя параўнання panics, `hole` будзе скінута і аўтаматычна запіша элемент назад у зрэз.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Перамясціце `i`-ы элемент на адно месца налева, перамясціўшы такім чынам адтуліну направа.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` трапляе і, такім чынам, капіруе `tmp` у пакінутую дзірку ў `v`.
        }
    }
}

/// Зрушвае апошні элемент налева, пакуль ён не сустрэне меншы альбо роўны элемент.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЯСПЕКА: Небяспечныя аперацыі ніжэй уключаюць індэксацыю без абавязковай праверкі (`get_unchecked` і `get_unchecked_mut`)
    // і капіраванне памяці (`ptr::copy_nonoverlapping`).
    //
    // а.Індэксацыя:
    //  1. Мы праверылі памер масіва на>=2.
    //  2. Усе індэксацыі, якія мы будзем рабіць, заўсёды складаюць не больш за `0 <= index < len-1`.
    //
    // б.Капіраванне памяці
    //  1. Мы атрымліваем указальнікі на спасылкі, якія гарантавана будуць сапраўднымі.
    //  2. Яны не могуць перакрывацца, таму што мы атрымліваем паказальнікі на індэксы адрозненняў зрэзу.
    //     А менавіта `i` і `i+1`.
    //  3. Калі зрэз правільна выраўнаваны, элементы правільна выраўнаваны.
    //     Абавязак абанента-пераканацца, што зрэз правільна выраўнаваны.
    //
    // Больш падрабязна глядзіце каментары ніжэй.
    unsafe {
        // Калі два апошнія элементы не працуюць ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Прачытайце апошні элемент у пераменнай, выдзеленай стэку.
            // Калі наступная аперацыя параўнання panics, `hole` будзе скінута і аўтаматычна запіша элемент назад у зрэз.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Перамясціце `i`-ы элемент на адно месца направа, зрушыўшы адтуліну налева.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` трапляе і, такім чынам, капіруе `tmp` у пакінутую дзірку ў `v`.
        }
    }
}

/// Часткова сартуе зрэз, перамяшчаючы вакол некалькі несапраўдных элементаў.
///
/// Вяртае `true`, калі зрэз адсартаваны ў канцы.Гэтая функцыя *O*(*n*) у горшым выпадку.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Максімальная колькасць суседніх парушаных пар, якія будуць зрушаны.
    const MAX_STEPS: usize = 5;
    // Калі зрэз карацейшы за гэты, не зрушвайце ніякіх элементаў.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // БЯСПЕКА: Мы ўжо відавочна зрабілі абавязковую праверку з `i < len`.
        // Усе нашы наступныя індэксацыі толькі ў дыяпазоне `0 <= index < len`
        unsafe {
            // Знайдзіце наступную пару суседніх не ў парадку элементаў.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Мы скончылі?
        if i == len {
            return true;
        }

        // Не зрушвайце элементы на кароткіх масівах, што каштуе прадукцыйнасць.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Памяняйце месцамі знойдзеную пару элементаў.Гэта прыводзіць іх у правільны парадак.
        v.swap(i - 1, i);

        // Зрушыце меншы элемент налева.
        shift_tail(&mut v[..i], is_less);
        // Ссуньце большы элемент направа.
        shift_head(&mut v[i..], is_less);
    }

    // Не ўдалося адсартаваць зрэз за абмежаваную колькасць крокаў.
    false
}

/// Сартуе зрэз з выкарыстаннем сартавання ўстаўкі, якое з'яўляецца *O*(*n*^ 2) у горшым выпадку.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Сартуе `v`, выкарыстоўваючы тэмп, які гарантуе *O*(*n*\*log(* n*)) у горшым выпадку.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Гэта двайковая куча паважае інварыянт `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Дзеці `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Выбірайце большага дзіцяці.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Спыніцеся, калі інварыянт мае месца ў `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Памяняйце `node` вялікім дзіцём, перайдзіце на адну прыступку і працягвайце прасейваць.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Пабудуйце кучу ў лінейны час.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Вывядзіце максімальныя элементы з кучы.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Разбівае `v` на элементы меншыя за `pivot`, за якімі ідуць элементы, большыя або роўныя `pivot`.
///
///
/// Вяртае колькасць элементаў, меншых за `pivot`.
///
/// Раздзел ажыццяўляецца па блоках з мэтай мінімізацыі выдаткаў на разгалінаванне.
/// Гэта ідэя прадстаўлена ў артыкуле [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Колькасць элементаў у тыповым блоку.
    const BLOCK: usize = 128;

    // Алгарытм падзелу паўтарае наступныя этапы да завяршэння:
    //
    // 1. Правядзіце блок з левага боку, каб вызначыць элементы, большыя або роўныя павароту.
    // 2. Правядзіце блок з правага боку, каб вызначыць элементы, меншыя за аселыя.
    // 3. Абменьвайцеся выяўленымі элементамі паміж левым і правым бокам.
    //
    // Мы захоўваем наступныя зменныя для блока элементаў:
    //
    // 1. `block` - Колькасць элементаў у блоку.
    // 2. `start` - Пачніце паказальнік на масіў `offsets`.
    // 3. `end` - Канечны паказальнік на масіў `offsets`.
    // 4. `offset, Індэксы несапраўдных элементаў у блоку.

    // Бягучы блок з левага боку (ад `l` да `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Бягучы блок з правага боку (ад `r.sub(block_r)` to `r`).
    // БЯСПЕКА: У дакументацыі для .add() канкрэтна згадваецца, што `vec.as_ptr().add(vec.len())` заўсёды ў бяспецы`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Калі мы атрымаем VLA, паспрабуйце стварыць адзін масіў даўжынёй `min(v.len(), 2 * BLOCK) `
    // чым два масівы фіксаванага памеру даўжынёй `BLOCK`.VLA могуць быць больш эфектыўнымі ў кэшы.

    // Вяртае колькасць элементаў паміж паказальнікамі `l` (inclusive) і `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Мы скончылі з раздзелам па блоках, калі `l` і `r` набліжаюцца.
        // Затым мы робім некаторыя выпраўленні, каб разбіць астатнія элементы паміж імі.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Колькасць астатніх элементаў (па-ранейшаму не параўноўваецца са зводным элементам).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Адрэгулюйце памеры блокаў так, каб левы і правы блокі не перакрываліся, але былі ідэальна выраўнаваны, каб пакрыць увесь пакінуты зазор.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Правядзіце элементы `block_l` з левага боку.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // БЯСПЕКА: Апісаныя ніжэй аперацыі па бяспецы звязаны з выкарыстаннем `offset`.
                //         У адпаведнасці з умовамі, якія патрабуе функцыя, мы іх задавальняем, бо:
                //         1. `offsets_l` вылучаецца ў стэк і, такім чынам, лічыцца асобным выдзеленым аб'ектам.
                //         2. Функцыя `is_less` вяртае `bool`.
                //            Кастынг `bool` ніколі не перапоўніць `isize`.
                //         3. Мы гарантавалі, што `block_l` будзе `<= BLOCK`.
                //            Плюс, `end_l` першапачаткова быў усталяваны ў пачатковы паказальнік `offsets_`, які быў абвешчаны ў стэку.
                //            Такім чынам, мы ведаем, што нават у горшым выпадку (усе выклікі `is_less` вяртае ілжывыя) мы атрымаем не больш за 1 байт.
                //        Яшчэ адна аперацыя, якая не забяспечвае бяспекі,-гэта пераадрасоўка `elem`.
                //        Аднак `elem` першапачаткова быў указальнікам на зрэз, які заўсёды дзейнічае.
                unsafe {
                    // Параўнанне без галінак.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Правядзіце элементы `block_r` з правага боку.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // БЯСПЕКА: Апісаныя ніжэй аперацыі па бяспецы звязаны з выкарыстаннем `offset`.
                //         У адпаведнасці з умовамі, якія патрабуе функцыя, мы іх задавальняем, бо:
                //         1. `offsets_r` вылучаецца ў стэк і, такім чынам, лічыцца асобным выдзеленым аб'ектам.
                //         2. Функцыя `is_less` вяртае `bool`.
                //            Кастынг `bool` ніколі не перапоўніць `isize`.
                //         3. Мы гарантавалі, што `block_r` будзе `<= BLOCK`.
                //            Плюс, `end_r` першапачаткова быў усталяваны ў пачатковы паказальнік `offsets_`, які быў абвешчаны ў стэку.
                //            Такім чынам, мы ведаем, што нават у горшым выпадку (усе выклікі `is_less` вяртаюць ісціну) у нас будзе праходзіць не больш за 1 байт.
                //        Яшчэ адна аперацыя, якая не забяспечвае бяспекі,-гэта пераадрасоўка `elem`.
                //        Аднак `elem` першапачаткова быў `1 *sizeof(T)` пасля канца, і мы памяншаем яго на `1* sizeof(T)` перад доступам да яго.
                //        Акрамя таго, `block_r` быў сцверджаны як меншы за `BLOCK`, а таму `elem` будзе, як правіла, паказваць на пачатак зрэзу.
                unsafe {
                    // Параўнанне без галінак.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Колькасць несапраўдных элементаў для пераключэння паміж левым і правым бокам.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Замест таго, каб памяняць па адной пары адначасова, больш эфектыўна выконваць цыклічную перастаноўку.
            // Гэта не дакладна эквівалентна замене, але дае аналагічны вынік, выкарыстоўваючы менш аперацый памяці.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Усе не ў парадку элементы ў левым блоку былі перамешчаны.Пераход да наступнага блока.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Усе непаладкі ў правым блоку былі перамешчаны.Перайсці да папярэдняга блока.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Зараз застаецца не больш за адзін блок (альбо злева, альбо справа) з несапраўднымі элементамі, якія трэба перамясціць.
    // Такія астатнія элементы можна проста перанесці да канца ў межах свайго блока.
    //

    if start_l < end_l {
        // Левы блок застаецца.
        // Перамясціце астатнія не ў парадку элементы ў крайні правы бок.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Правы блок застаецца.
        // Перамясціце пакінутыя не ў парадку элементы ў крайні левы кут.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Больш нічога не рабіць, мы скончылі.
        width(v.as_mut_ptr(), l)
    }
}

/// Разбівае `v` на элементы меншыя за `v[pivot]`, за якімі ідуць элементы, большыя або роўныя `v[pivot]`.
///
///
/// Вяртае набор:
///
/// 1. Колькасць элементаў менш, чым `v[pivot]`.
/// 2. Праўда, калі `v` ужо быў падзелены.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Змесціце шарнір у пачатку зрэзу.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Прачытайце півот у пераменную, выдзеленую стэку, для павышэння эфектыўнасці.
        // Калі будзе праведзена наступная аперацыя параўнання panics, паварот будзе аўтаматычна запісаны назад у зрэз.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Знайдзіце першую пару не ў парадку элементаў.
        let mut l = 0;
        let mut r = v.len();

        // БЯСПЕКА: Указаная ніжэй бяспека ўключае індэксацыю масіва.
        // Па-першае: мы ўжо праходзім праверку межаў тут з `l < r`.
        // Другі: у нас першапачаткова ёсць `l == 0` і `r == v.len()`, і мы правяралі `l < r` пры кожнай аперацыі індэксацыі.
        //                     Адсюль мы ведаем, што `r` павінен быць як мінімум `r == l`, які быў паказаны сапраўдным з першага.
        unsafe {
            // Знайдзіце першы элемент, большы або роўны стрыжню.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Знайдзіце апошні элемент, меншы за аснову.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` выходзіць за межы вобласці і запісвае півот (які з'яўляецца зменнай, выдзеленай стэку) назад у зрэз, дзе ён быў першапачаткова.
        // Гэты крок мае вырашальнае значэнне для забеспячэння бяспекі!
        //
    };

    // Змесціце шарнір паміж двума перагародкамі.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Разбівае `v` на элементы, роўныя `v[pivot]`, за якімі ідуць элементы, большыя за `v[pivot]`.
///
/// Вяртае колькасць элементаў, роўнае зводной.
/// Мяркуецца, што `v` не ўтрымлівае элементаў, меншых за аснову.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Змесціце шарнір у пачатку зрэзу.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Прачытайце півот у пераменную, выдзеленую стэку, для павышэння эфектыўнасці.
    // Калі будзе праведзена наступная аперацыя параўнання panics, паварот будзе аўтаматычна запісаны назад у зрэз.
    // БЯСПЕКА: паказальнік тут сапраўдны, бо атрыманы са спасылкі на зрэз.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Цяпер падзеліце зрэз.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // БЯСПЕКА: Указаная ніжэй бяспека ўключае індэксацыю масіва.
        // Па-першае: мы ўжо праходзім праверку межаў тут з `l < r`.
        // Другі: у нас першапачаткова ёсць `l == 0` і `r == v.len()`, і мы правяралі `l < r` пры кожнай аперацыі індэксацыі.
        //                     Адсюль мы ведаем, што `r` павінен быць як мінімум `r == l`, які быў паказаны сапраўдным з першага.
        unsafe {
            // Знайдзіце першы элемент, большы за стрыжань.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Знайдзіце апошні элемент, роўны стрыжню.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Мы скончылі?
            if l >= r {
                break;
            }

            // Памяняйце месцамі знойдзеную пару непаўнавартасных элементаў.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Мы знайшлі элементы `l`, роўныя павароце.Дадайце 1 да ўліковага запісу.
    l + 1

    // `_pivot_guard` выходзіць за межы вобласці і запісвае півот (які з'яўляецца зменнай, выдзеленай стэку) назад у зрэз, дзе ён быў першапачаткова.
    // Гэты крок мае вырашальнае значэнне для забеспячэння бяспекі!
}

/// Раскідвае некаторыя элементы вакол, спрабуючы разбіць шаблоны, якія могуць выклікаць незбалансаваныя раздзелы ў хуткай сартаванні.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Генератар псеўдавыпадковых лікаў з артыкула "Xorshift RNGs" Джорджа Марсальі.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Вазьміце выпадковыя лікі па модулі гэтага ліку.
        // Лік адпавядае `usize`, таму што `len` не большы за `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Некалькі асноўных кандыдатаў будуць знаходзіцца побач з гэтым індэксам.Давайце рандомізуем іх.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Стварыць выпадковае лік па модулі `len`.
            // Аднак, каб пазбегнуць дарагіх аперацый, мы спачатку прымаем яго па модулі ў два разы, а потым памяншаем на `len`, пакуль ён не ўвойдзе ў дыяпазон `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` гарантавана будзе менш за `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Выбірае півот у `v` і вяртае індэкс і `true`, калі зрэз, верагодна, ужо адсартаваны.
///
/// Элементы ў `v` могуць быць пераўпарадкаваны ў працэсе.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Мінімальная даўжыня для выбару метаду медыяны медыяны.
    // Больш кароткія зрэзы выкарыстоўваюць просты метад сярэдняга з трох.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Максімальная колькасць свопаў, якія можна выканаць у гэтай функцыі.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Тры індэкса, побач з якімі мы збіраемся выбраць паваротную кропку.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Падлічвае агульную колькасць свопаў, якія мы збіраемся выканаць падчас сартавання індэксаў.
    let mut swaps = 0;

    if len >= 8 {
        // Мяняе індэксы так, што `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Мяняе індэксы так, што `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Знаходзіць медыяну `v[a - 1], v[a], v[a + 1]` і захоўвае індэкс у `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Знайдзіце медыяны ў наваколлях `a`, `b` і `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Знайдзіце медыяну сярод `a`, `b` і `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Была праведзена максімальная колькасць свопаў.
        // Хутчэй за ўсё, зрэз змяншаецца альбо ў асноўным сыходзіць, таму зваротнае рух, верагодна, дапаможа хутчэй яго сартаваць.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Сартуе `v` рэкурсіўна.
///
/// Калі ў зрэзе быў папярэднік у зыходным масіве, ён пазначаецца як `pred`.
///
/// `limit` - колькасць дазволеных незбалансаваных раздзелаў перад пераходам на `heapsort`.
/// Калі нуль, гэтая функцыя неадкладна пераключыцца на рэжым пераключэння.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Зрэзы да гэтай даўжыні сартуюцца пры дапамозе сартавання ўстаўкі.
    const MAX_INSERTION: usize = 20;

    // Праўда, калі апошні раздзел быў дастаткова разумным.
    let mut was_balanced = true;
    // Праўда, калі апошні раздзел не ператасаваў элементы (зрэз ужо быў раздзелены).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Вельмі кароткія зрэзы сартуюцца пры дапамозе сартавання ўстаўкі.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Калі было зроблена занадта шмат дрэнных варыянтаў павароту, проста вярніцеся да хіпсарта, каб гарантаваць `O(n * log(n))` найгоршы выпадак.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Калі апошні раздзел быў разбалансаваны, паспрабуйце разбіць шаблоны ў зрэзе, ператасаваўшы некаторыя элементы вакол.
        // Будзем спадзявацца, што на гэты раз мы абярэм лепшы арэал.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Выберыце шарнір і паспрабуйце здагадацца, ці зрэз ужо адсартаваны.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Калі мінулы раздзел быў прыстойна збалансаваны і не ператасоўваў элементы, і калі вылучэнне павароту прадказвае зрэз, хутчэй за ўсё, ужо адсартаваны ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Паспрабуйце вызначыць некалькі няправільных элементаў і перанесці іх у правільныя пазіцыі.
            // Калі зрэз у выніку будзе цалкам адсартаваны, мы скончым.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Калі абраны шарнір роўны папярэдніку, то гэта найменшы элемент зрэзу.
        // Разбіце зрэз на элементы, роўныя і элементы, большыя за зводную.
        // Звычайна гэты выпадак трапляе, калі зрэз змяшчае мноства паўтаральных элементаў.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Працягвайце сартаваць элементы, большыя за аснову.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Раздзеліце зрэз.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Разбіце зрэз на `left`, `pivot` і `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Звярніцеся ў больш кароткі бок толькі для таго, каб мінімізаваць агульную колькасць рэкурсіўных выклікаў і заняць менш месца ў стэку.
        // Затым проста працягвайце з больш доўгага боку (гэта падобна на рэкурсію хваста).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Сартуе `v` з выкарыстаннем хуткай сартавання, якая перамагае ўзор, што з'яўляецца *O*(*n*\*log(* n*)) у горшым выпадку.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Сартаванне не мае значнага паводзінаў для тыпаў нулявых памераў.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Абмяжуйце колькасць незбалансаваных раздзелаў да `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Для зрэзаў да гэтай даўжыні хутчэй за ўсё проста адсартаваць.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Абярыце стрыжань
        let (pivot, _) = choose_pivot(v, is_less);

        // Калі абраны шарнір роўны папярэдніку, то гэта найменшы элемент зрэзу.
        // Разбіце зрэз на элементы, роўныя і элементы, большыя за зводную.
        // Звычайна гэты выпадак трапляе, калі зрэз змяшчае мноства паўтаральных элементаў.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Калі мы здалі індэкс, значыць, усё добра.
                if mid > index {
                    return;
                }

                // У адваротным выпадку працягвайце сартаваць элементы, большыя за зводныя.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Разбіце зрэз на `left`, `pivot` і `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Калі mid==індэкс, то мы скончылі, бо partition() гарантаваў, што ўсе элементы пасля mid больш альбо роўныя mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Сартаванне не мае значнага паводзінаў для тыпаў нулявых памераў.Нічога не рабіць.
    } else if index == v.len() - 1 {
        // Знайдзіце максімальны элемент і пастаўце яго ў апошняе становішча масіва.
        // Мы можам выкарыстоўваць `unwrap()` тут, бо ведаем, што v не павінен быць пустым.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Знайдзіце элемент min і пастаўце яго ў першае становішча масіва.
        // Мы можам выкарыстоўваць `unwrap()` тут, бо ведаем, што v не павінен быць пустым.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}