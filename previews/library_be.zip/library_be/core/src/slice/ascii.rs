//! Аперацыі на ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Правярае, ці знаходзяцца ўсе байты ў гэтым зрэзе ў дыяпазоне ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Правярае, што два зрэзы не супадаюць з улікам рэгістра ASCII.
    ///
    /// Тое ж, што і `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, але без выдзялення і капіравання часоў.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Пераўтварае гэты зрэз у яго верхні эквівалент ASCII на месцы.
    ///
    /// Літары ASCII ад 'a' да 'z' супастаўляюцца з 'A' да 'Z', але літары, не звязаныя з ASCII, застаюцца нязменнымі.
    ///
    /// Каб вярнуць новае значэнне з вялікай літарай без змены існуючага, выкарыстоўвайце [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Пераўтварае гэты зрэз у яго эквівалент ASCII, які эквівалентны на месцы.
    ///
    /// Літары ASCII ад 'A' да 'Z' супастаўляюцца з 'a' да 'z', але літары, не звязаныя з ASCII, застаюцца нязменнымі.
    ///
    /// Каб вярнуць новае малое значэнне без змены існуючага, выкарыстоўвайце [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Вяртае `true`, калі які-небудзь байт у слове `v` не мае значэння (>=128).
/// Snarfed ад `../str/mod.rs`, які робіць нешта падобнае для праверкі utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Аптымізаваны тэст ASCII, які будзе выкарыстоўваць аперацыі "выкарыстанне за раз" замест аперацый "байт за раз" (калі гэта магчыма).
///
/// Алгарытм, які мы тут выкарыстоўваем, даволі просты.Калі `s` занадта кароткі, мы проста правяраем кожны байт і скончым з ім.У адваротным выпадку:
///
/// - Прачытайце першае слова з нявыраўнаванай нагрузкай.
/// - Выраўняйце паказальнік, прачытайце наступныя словы да канца з выраўнаванымі нагрузкамі.
/// - Прачытайце апошнюю версію `usize` з `s` з нагрузкай без выраўноўвання.
///
/// Калі любая з гэтых нагрузак дае нешта, для чаго `contains_nonascii` (above) вяртае праўду, значыць, мы ведаем, што адказ непраўдзівы.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Калі мы нічога не атрымаем ад рэалізацыі "за раз", вернемся да скалярнай пятлі.
    //
    // Мы таксама робім гэта для архітэктур, дзе `size_of::<usize>()` недастаткова выраўноўвае `usize`, таму што гэта дзіўны выпадак edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Мы заўсёды чытаем першае слова без выраўноўвання, што азначае, што `align_offset` ёсць
    // 0, мы б зноў прачыталі тое ж значэнне для выраўнаванага чытання.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // БЯСПЕКА: Мы правяраем `len < USIZE_SIZE` вышэй.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Мы праверылі гэта вышэй, неяк няяўна.
    // Звярніце ўвагу, што `offset_to_aligned`-гэта альбо `align_offset`, альбо `USIZE_SIZE`, абодва яны відавочна пазначаны вышэй.
    //
    debug_assert!(offset_to_aligned <= len);

    // БЯСПЕКА: word_ptr-гэта (правільна выраўнаваны) ptr выкарыстання, які мы выкарыстоўваем для чытання
    // сярэдні кавалачак зрэзу.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` - байтавы індэкс `word_ptr`, які выкарыстоўваецца для праверкі канца цыкла.
    let mut byte_pos = offset_to_aligned;

    // Праверка параноі наконт выраўноўвання, бо мы збіраемся зрабіць кучу няўстаноўленых нагрузак.
    // На практыцы гэта можа быць немагчыма, калі не ўлічваць памылку ў `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Прачытайце наступныя словы да апошняга выраўнаванага слова, за выключэннем самога апошняга выраўнаванага слова, якое будзе зроблена пазней пры праверцы хваста, каб гарантаваць, што хвост заўсёды складае не больш за адзін `usize` да дадатковага branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Разумнасць правярае, што чытанне знаходзіцца ў межах
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // І гэта адпавядае нашым здагадкам пра `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // БЯСПЕКА: Мы ведаем, што `word_ptr` правільна выраўнаваны (з-за
        // `align_offset`), і мы ведаем, што ў нас дастаткова байтаў паміж `word_ptr` і канцом
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // БЯСПЕКА: Мы ведаем, што `byte_pos <= len - USIZE_SIZE`, а гэта значыць
        // пасля гэтага `add`, `word_ptr` будзе максімум адным мінулым.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Праверка абгрунтаванасці, каб пераканацца, што на самой справе застаўся толькі адзін `usize`.
    // Гэта павінна быць гарантавана нашай умовай цыкла.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // БЯСПЕКА: Гэта залежыць ад `len >= USIZE_SIZE`, які мы правяраем у самым пачатку.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}