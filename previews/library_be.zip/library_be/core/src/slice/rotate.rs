// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Паварочвае дыяпазон `[mid-left, mid+right)` так, што элемент у `mid` становіцца першым элементам.Аналагічна, паварочвае элементы дыяпазону `left` налева або элементы `right` направа.
///
/// # Safety
///
/// Указаны дыяпазон павінен быць сапраўдным для чытання і пісьма.
///
/// # Algorithm
///
/// Алгарытм 1 выкарыстоўваецца для малых значэнняў `left + right` або для вялікіх `T`.
/// Элементы перамяшчаюцца ў свае канчатковыя пазіцыі па чарзе, пачынаючы з `mid - left` і прасоўваючыся па прыступках `right` па модулі `left + right`, так што патрэбен толькі адзін часовы.
/// У рэшце рэшт, мы вяртаемся ў `mid - left`.
/// Аднак, калі `gcd(left + right, right)` не 1, вышэйапісаныя этапы прапускалі элементы.
/// Напрыклад:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// На шчасце, колькасць прапушчаных элементаў паміж дапрацаванымі элементамі заўсёды роўна, таму мы можам проста кампенсаваць зыходную пазіцыю і зрабіць больш раўндаў (агульная колькасць раўндаў складае `gcd(left + right, right)` value).
///
/// У выніку атрымліваецца, што ўсе элементы дапрацоўваюцца адзін раз і толькі адзін раз.
///
/// Алгарытм 2 выкарыстоўваецца, калі `left + right` вялікі, але `min(left, right)` досыць малы, каб змясціцца ў буфер стэка.
/// Элементы `min(left, right)` капіруюцца ў буфер, `memmove` прымяняецца да астатніх, а элементы ў буферы перамяшчаюцца назад у адтуліну на супрацьлеглым баку, адкуль яны пайшлі.
///
/// Алгарытмы, якія можна вектарызаваць, пераўзыходзяць вышэйпералічаныя, калі `left + right` стане дастаткова вялікім.
/// Алгарытм 1 можна вектарызаваць, разбіваючы і выконваючы шмат раўндаў адначасова, але ў сярэднім занадта мала раўндаў, пакуль `left + right` не стане велізарным, і горшы выпадак з аднаго раўнда заўсёды ёсць.
/// Замест гэтага алгарытм 3 выкарыстоўвае паўторную замену элементаў `min(left, right)`, пакуль не застаецца меншая праблема павароту.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// калі `left < right` адбываецца замена злева замест гэтага.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ніжэйпрыведзеныя алгарытмы могуць выйсці з ладу, калі гэтыя выпадкі не правераны
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Алгарытм 1 Microbenchmarks паказвае, што сярэдняя прадукцыйнасць для выпадковых зрухаў лепш да канца `left + right == 32`, але ў горшым выпадку прадукцыйнасць перапыняецца нават каля 16.
            // 24 быў абраны ў якасці сярэдзіны.
            // Калі памер `T` перавышае 4 `usize`s, гэты алгарытм таксама пераўзыходзіць іншыя алгарытмы.
            //
            //
            let x = unsafe { mid.sub(left) };
            // пачатак першага тура
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` можна знайсці перад пачаткам, вылічыўшы `gcd(left + right, right)`, але хутчэй зрабіць адзін цыкл, які вылічвае gcd як пабочны эфект, а потым зрабіць астатнюю частку
            //
            //
            let mut gcd = right;
            // тэсты паказваюць, што хутчэй памяняць часопіс на ўвесь час, а не прачытаць адзін часовы раз, скапіраваць назад і потым напісаць гэты часовы ў самым канцы.
            // Гэта магчыма з-за таго, што пры замене альбо замене часоў выкарыстоўваецца толькі адзін адрас памяці ў цыкле, а не неабходнасць кіраваць двума.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // замест таго, каб павялічваць `i`, а потым правяраць, ці не выходзіць ён за межы, мы правяраем, ці выйдзе `i` за межы наступнага павелічэння.
                // Гэта прадухіляе ўпакоўку паказальнікаў ці `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // канец першага тура
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // гэты ўмоўны павінен быць тут, калі `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // скончыць кавалак яшчэ раундамі
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` не з'яўляецца нулявым тыпам, таму яго можна падзяліць на яго памер.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгарытм 2 `[T; 0]` тут павінен пераканацца, што ён адпавядае T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгарытм 3 Існуе альтэрнатыўны спосаб замены, які прадугледжвае пошук месца апошняга свопу гэтага алгарытму, а таксама абмен з выкарыстаннем гэтага апошняга кавалка замест замены суседніх кавалкаў, як гэта робіць гэты алгарытм, але гэты спосаб усё ж хутчэй.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгарытм 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}