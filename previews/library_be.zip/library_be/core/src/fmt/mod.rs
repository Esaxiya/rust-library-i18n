//! Службовыя праграмы для фарматавання і друку радкоў.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Магчымыя выраўноўванні, вернутыя `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Указанне на тое, што змест трэба выраўноўваць па левым краі.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Указанне на тое, што змесціва павінна быць выраўнавана па правым краі.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Указанне на тое, што змесціва павінна быць выраўнавана па цэнтры.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Тып, які вяртаецца метадамі фарматавання.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Тып памылкі, які вяртаецца пры фарматаванні паведамлення ў паток.
///
/// Гэты тып не падтрымлівае перадачу памылкі, акрамя таго, што адбылася памылка.
/// Любая дадатковая інфармацыя павінна быць перададзена іншымі спосабамі.
///
/// Важна памятаць, што тып `fmt::Error` нельга блытаць з [`std::io::Error`] або [`std::error::Error`], якія вы таксама можаце мець.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Portrait для запісу або фарматавання ў буферы ці патокі, якія прымаюць Unicode.
///
/// Гэты Portrait прымае толькі кадаваныя дадзеныя UTF-8 і не з'яўляецца [flushable].
/// Калі вы хочаце прыняць толькі Unicode і вам не патрэбна прамыўка, вам варта рэалізаваць гэты Portrait;
/// у адваротным выпадку вам варта ўкараніць [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Запісвае ў гэты пісьменнік зрэз радка, вяртаючы, ці атрымалася запіс.
    ///
    /// Гэты метад можа атрымаць поспех толькі ў тым выпадку, калі ўвесь зрэз радка быў паспяхова запісаны, і гэты метад не вернецца, пакуль не будуць запісаны ўсе дадзеныя альбо не ўзнікне памылка.
    ///
    ///
    /// # Errors
    ///
    /// Гэтая функцыя верне асобнік [`Error`] пры памылцы.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Запісвае [`char`] у гэты пісьменнік, вяртаючы, ці ўдалася запіс.
    ///
    /// Адзінкавы [`char`] можа кадзіравацца як больш чым адзін байт.
    /// Гэты метад можа атрымаць поспех толькі ў тым выпадку, калі ўся паслядоўнасць байтаў была паспяхова запісана, і гэты метад не вернецца, пакуль не будуць запісаны ўсе дадзеныя альбо не ўзнікне памылка.
    ///
    ///
    /// # Errors
    ///
    /// Гэтая функцыя верне асобнік [`Error`] пры памылцы.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Клей для выкарыстання макраса [`write!`] з рэалізатарамі гэтага Portrait.
    ///
    /// Звычайна гэты метад трэба выклікаць не ўручную, а праз сам макрас [`write!`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Канфігурацыя для фарматавання.
///
/// `Formatter` уяўляе розныя варыянты, звязаныя з фарматаваннем.
/// Карыстальнікі не ствараюць `Formatter`s непасрэдна;зменлівая спасылка на адзін перадаецца метаду `fmt` для ўсіх фарматаванняў traits, такіх як [`Debug`] і [`Display`].
///
///
/// Для ўзаемадзеяння з `Formatter` вы будзеце выклікаць розныя метады, каб змяніць розныя параметры, звязаныя з фарматаваннем.
/// Для прыкладаў, калі ласка, глядзіце дакументацыю па метадах, вызначаных на `Formatter`, ніжэй.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Аргумент-гэта, па сутнасці, аптымізаваная часткова ўжытая функцыя фарматавання, эквівалентная `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Гэтая структура ўяўляе агульны "argument", які выкарыстоўваецца сямействам функцый Xprintf.Ён змяшчае функцыю для фарматавання зададзенага значэння.
/// Падчас кампіляцыі гарантуецца, што функцыя і значэнне маюць правільныя тыпы, а потым гэтая структура выкарыстоўваецца для кананізацыі аргументаў да аднаго тыпу.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Гэта гарантуе адно стабільнае значэнне для паказальніка функцыі, звязанага з indices/counts, у інфраструктуры фарматавання.
//
// Звярніце ўвагу, што функцыя, вызначаная як такая, будзе няправільнай, паколькі функцыі заўсёды пазначаны unnamed_addr з бягучым паніжэннем да ВК LLVM, таму іх адрас не лічыцца важным для LLVM, і як такі прывядзенне as_usize магло быць няправільна скампілявана.
//
// На практыцы мы ніколі не называем as_usize на дадзеных, якія не выкарыстоўваюць памер (як пытанне статычнага генеравання аргументаў фарматавання), таму гэта проста дадатковая праверка.
//
// Мы ў першую чаргу хочам пераканацца, што паказальнік функцыі ў `USIZE_MARKER` мае адрас, які адпавядае *толькі* функцыям, якія таксама прымаюць `&usize` у якасці першага аргумента.
// Тут read_volatile гарантуе, што мы можам бяспечна падрыхтаваць выкарыстанне з перададзенай спасылкі і што гэты адрас не паказвае на функцыю прыняцця, якая не выкарыстоўваецца.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // БЯСПЕКА: ptr-гэта спасылка
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // БЯСПЕКА: `mem::transmute(x)` бяспечны, бо
        //     1. `&'b T` захоўвае тэрмін службы, які ўзнік з `'b` (каб не мець неабмежаванага тэрміну службы)
        //     2.
        //     `&'b T` і `&'b Opaque` маюць аднолькавы макет памяці (калі `T`-гэта `Sized`, як тут) `mem::transmute(f)` бяспечны, бо `fn(&T, &mut Formatter<'_>) -> Result` і `fn(&Opaque, &mut Formatter<'_>) -> Result` маюць аднолькавы ABI (пакуль `T`-гэта `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // БЯСПЕКА: для поля `formatter` усталявана USIZE_MARKER, толькі калі
            // значэнне з'яўляецца памерам, таму гэта бяспечна
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// сцягі, даступныя ў фармаце v1 format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Пры выкарыстанні макраса format_args! () Гэтая функцыя выкарыстоўваецца для стварэння структуры Arguments.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Гэтая функцыя выкарыстоўваецца для задання нестандартных параметраў фарматавання.
    /// Масіў `pieces` павінен мець па меншай меры столькі, колькі `fmt`, каб пабудаваць сапраўдную структуру аргументаў.
    /// Акрамя таго, любы `Count` у `fmt`, які з'яўляецца `CountIsParam` або `CountIsNextParam`, павінен паказваць на аргумент, створаны з `argumentusize`.
    ///
    /// Аднак, калі гэтага не зрабіць, гэта не прывядзе да небяспекі, але будзе ігнараваць несапраўдныя.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Ацэньвае даўжыню адфарматаванага тэксту.
    ///
    /// Ён прызначаны для ўстаноўкі пачатковай ёмістасці `String` пры выкарыстанні `format!`.
    /// Note: гэта не ніжняя і не верхняя мяжа.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Калі радок фарматавання пачынаецца з аргумента, нічога не выдзяляйце, калі даўжыня фрагментаў не з'яўляецца значнай.
            //
            //
            0
        } else {
            // Ёсць некалькі аргументаў, таму любы дадатковы націск пераразмясціць радок.
            //
            // Каб пазбегнуць гэтага, мы маем "pre-doubling".
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Гэтая структура ўяўляе сабой папярэдне скампіляваную версію радка фармату і яе аргументы.
/// Гэта нельга генераваць падчас выканання, таму што гэта немагчыма зрабіць бяспечна, таму канструктары не выдаюцца, а палі прыватныя, каб прадухіліць мадыфікацыю.
///
///
/// Макрас [`format_args!`] бяспечна створыць асобнік гэтай структуры.
/// Макрас правярае радок фармату падчас кампіляцыі, каб выкарыстанне функцый [`write()`] і [`format()`] можна было бяспечна выконваць.
///
/// Вы можаце выкарыстоўваць `Arguments<'a>`, які [`format_args!`] вяртае ў кантэкстах `Debug` і `Display`, як паказана ніжэй.
/// Прыклад таксама паказвае, што `Debug` і `Display` фарматуюць адно і тое ж: інтэрпаляваны радок фармату ў `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Адфарматаваць фрагменты радкоў для друку.
    pieces: &'a [&'static str],

    // Спецыфікацыі запаўняльніка альбо `None`, калі ўсе характарыстыкі па змаўчанні (як у "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Дынамічныя аргументы для інтэрпаляцыі, якія ўмешваюцца ў кавалкі радкоў.
    // (Кожнаму аргументу папярэднічае фрагмент радка.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Атрымайце адфарматаваны радок, калі ў ім няма аргументаў для фарматавання.
    ///
    /// Гэта можа быць выкарыстана, каб пазбегнуць размеркавання ў самым банальным выпадку.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` павінен фарматаваць выснову ў кантэксце адладкі, які стаіць перад праграмістам.
///
/// Наогул кажучы, вам трэба проста `derive` і рэалізацыю `Debug`.
///
/// Пры выкарыстанні са спецыфікатарам альтэрнатыўнага фармату `#?`, выснова даволі друкаваная.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Гэты Portrait можна выкарыстоўваць з `#[derive]`, калі ўсе палі рэалізуюць `Debug`.
/// Калі `выводзіць`d для структур, ён будзе выкарыстоўваць імя `struct`, потым `{`, потым спіс імя і значэння `Debug`, падзелены коскамі, потым `}`.
/// Для `enum`s ён будзе выкарыстоўваць імя варыянту і, калі гэта дастасавальна, `(`, затым значэнні палёў `Debug`, потым `)`.
///
/// # Stability
///
/// Выведзеныя фарматы `Debug` не стабільныя, і таму могуць мяняцца з версіямі future Rust.
/// Акрамя таго, рэалізацыі тыпаў `Debug`, якія прадастаўляюцца стандартнай бібліятэкай (`libstd`, `libcore`, `liballoc` і г.д.), не стабільныя і могуць таксама змяняцца з версіямі future Rust.
///
///
/// # Examples
///
/// Вывядзенне рэалізацыі:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Рэалізацыя ўручную:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// У структуры [`Formatter`] існуе шэраг дапаможных метадаў, якія дапамогуць вам з ручнымі рэалізацыямі, напрыклад [`debug_struct`].
///
/// `Debug` рэалізацыі з выкарыстаннем альбо `derive`, альбо API канструктара адладкі на [`Formatter`] падтрымліваюць сімпатычную друк з выкарыстаннем альтэрнатыўнага сцяга: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Даволі друк з `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Асобны модуль для рээкспарту макраса `Debug` з prelude без Portrait `Debug`.
pub(crate) mod macros {
    /// Выведзіце макрас, які генеруе impl з Portrait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Фармат Portrait для пустога фармату, `{}`.
///
/// `Display` падобны на [`Debug`], але `Display` прызначаны для вываду, арыентаванага на карыстальніка, і таму не можа быць атрыманы.
///
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Рэалізацыя `Display` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` Portrait павінен адфарматаваць вывад у выглядзе лічбы ў base-8.
///
/// Для прымітыўных цэлых лікаў са знакам (ад `i8` да `i128` і `isize`) адмоўныя значэнні адфарматаваны ў выглядзе прадстаўлення дапаўненняў.
///
///
/// Альтэрнатыўны сцяг, `#`, дадае `0o` перад выхадам.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Асноўнае выкарыстанне з `i32`:
///
/// ```
/// let x = 42; // 42-гэта '52' у васьмікратнай літары
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Рэалізацыя `Octal` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // дэлегат рэалізацыі i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` Portrait павінен адфарматаваць выснову ў выглядзе лічбы ў двайковым выглядзе.
///
/// Для прымітыўных цэлых лікаў са знакам (ад [`i8`] да [`i128`] і [`isize`]) адмоўныя значэнні адфарматаваны ў выглядзе прадстаўлення дапаўненняў.
///
///
/// Альтэрнатыўны сцяг, `#`, дадае `0b` перад выхадам.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Асноўнае выкарыстанне з [`i32`]:
///
/// ```
/// let x = 42; // 42-гэта '101010' у двайковым выглядзе
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Рэалізацыя `Binary` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // дэлегат рэалізацыі i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` Portrait павінен адфарматаваць вывад у выглядзе лічбы ў шаснаццатковым выглядзе, з `a` па `f`-з малой літары.
///
/// Для прымітыўных цэлых лікаў са знакам (ад `i8` да `i128` і `isize`) адмоўныя значэнні адфарматаваны ў выглядзе прадстаўлення дапаўненняў.
///
///
/// Альтэрнатыўны сцяг, `#`, дадае `0x` перад выхадам.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Асноўнае выкарыстанне з `i32`:
///
/// ```
/// let x = 42; // 42-гэта '2a' у шаснаццаткавай форме
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Рэалізацыя `LowerHex` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // дэлегат рэалізацыі i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` Portrait павінен адфарматаваць выснову ў лічбе ў шаснаццатковым выглядзе, з `A` па `F` у верхнім рэгістры.
///
/// Для прымітыўных цэлых лікаў са знакам (ад `i8` да `i128` і `isize`) адмоўныя значэнні адфарматаваны ў выглядзе прадстаўлення дапаўненняў.
///
///
/// Альтэрнатыўны сцяг, `#`, дадае `0x` перад выхадам.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Асноўнае выкарыстанне з `i32`:
///
/// ```
/// let x = 42; // 42-гэта '2A' у шаснаццаткавай форме
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Рэалізацыя `UpperHex` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // дэлегат рэалізацыі i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` Portrait павінен адфарматаваць свой выхад як месца памяці.
/// Гэта звычайна ўяўляецца як шаснаццатковае.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Асноўнае выкарыстанне з `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // гэта стварае нешта накшталт '0x7f06092ac6d0'
/// ```
///
/// Рэалізацыя `Pointer` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // выкарыстоўвайце `as` для пераўтварэння ў `*const T`, які рэалізуе паказальнік, які мы можам выкарыстоўваць
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` Portrait павінен фарматаваць сваю прадукцыю ў навуковых абазначэннях з малой літары `e`.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Асноўнае выкарыстанне з `f64`:
///
/// ```
/// let x = 42.0; // 42.0 з'яўляецца '4.2e1' у навуковых абазначэннях
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Рэалізацыя `LowerExp` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // дэлегат рэалізацыі f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` Portrait павінен адфарматаваць сваю прадукцыю ў навуковых абазначэннях з вялікай літары `E`.
///
/// Для атрымання дадатковай інфармацыі пра фарматавальнікі глядзіце [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Асноўнае выкарыстанне з `f64`:
///
/// ```
/// let x = 42.0; // 42.0 з'яўляецца '4.2E1' у навуковых абазначэннях
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Рэалізацыя `UpperExp` на тыпе:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // дэлегат рэалізацыі f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Фарматуе значэнне, выкарыстоўваючы зададзены фарматавальнік.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Функцыя `write` прымае выходны паток і структуру `Arguments`, якую можна папярэдне скампіляваць з макрасам `format_args!`.
///
///
/// Аргументы будуць адфарматаваны ў адпаведнасці з зададзеным радком фармату ў прадастаўленым выходным патоку.
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Звярніце ўвагу, што выкарыстанне [`write!`] можа быць пераважней.Прыклад:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Мы можам выкарыстоўваць параметры фарматавання па змаўчанні для ўсіх аргументаў.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Кожная спецыфікацыя мае адпаведны аргумент, перад якім стаіць радок.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // БЯСПЕКА: arg і args.args паходзяць з тых самых аргументаў,
                // што гарантуе, што індэксы заўсёды ў межах.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Застаецца толькі адна задняя частка радка.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // БЯСПЕКА: аргументы і аргументы паходзяць з тых самых аргументаў,
    // што гарантуе, што індэксы заўсёды ў межах.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Вылучыце правільны аргумент
    debug_assert!(arg.position < args.len());
    // БЯСПЕКА: аргументы і аргументы паходзяць з тых самых аргументаў,
    // што гарантуе, што яго індэкс заўсёды ў межах.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Тады на самай справе зрабіць друк
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // БЯСПЕКА: cnt і аргументы паходзяць з тых самых аргументаў,
            // што гарантуе, што гэты паказчык заўсёды ў межах.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Абіванне пасля заканчэння чаго-небудзь.Вяртаецца `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Напішыце гэты запіс.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Мы хочам гэта змяніць
            buf: wrap(self.buf),

            // І захаваць іх
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Дапаможныя метады, якія выкарыстоўваюцца для запаўнення і апрацоўкі аргументаў фарматавання, якія могуць выкарыстоўваць усе фарматаванні traits.
    //

    /// Выконвае правільнае запаўненне цэлага ліку, якое ўжо было выдадзена ў str.
    /// Str павінен *не* утрымліваць знак для цэлага ліку, які будзе дададзены гэтым метадам.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, незалежна ад таго, зыходны цэлы лік быў станоўчым альбо нулявым.
    /// * прэфікс, калі даецца сімвал '#' (Alternate), гэта прэфікс, які трэба паставіць перад нумарам.
    ///
    /// * buf, байтавы масіў, у які быў адфарматаваны нумар
    ///
    /// Гэтая функцыя будзе карэктна ўлічваць прадастаўленыя сцягі, а таксама мінімальную шырыню.
    /// Не будзе ўлічвацца дакладнасць.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Нам трэба выдаліць "-" з вываду нумара.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Піша знак, калі ён існуе, а потым прэфікс, калі ён быў запытаны
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // На дадзены момант поле `width`-гэта хутчэй параметр `min-width`.
        match self.width {
            // Калі няма мінімальных патрабаванняў да даўжыні, мы можам проста запісаць байты.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Праверце, калі мы перавышаем мінімальную шырыню, калі так, то мы таксама можам проста запісаць байты.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Знак і прэфікс ідуць перад запаўненнем, калі сімвал запаўнення роўны нулю
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // У адваротным выпадку знак і прэфікс ідуць пасля запаўнення
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Гэтая функцыя прымае зрэз радка і выдае яго ва ўнутраны буфер пасля прымянення адпаведных сцягоў фарматавання.
    /// Сцягі, распазнаныя для агульных радкоў:
    ///
    /// * шырыня, мінімальная шырыня таго, што выпраменьваць
    /// * fill/align - што выпраменьваць і дзе яго выпраменьваць, калі ўказаны радок трэба дапоўніць
    /// * дакладнасць, максімальная даўжыня для выпраменьвання, радок усекаецца, калі яна даўжэйшая за гэтую даўжыню
    ///
    /// Характэрна, што гэтая функцыя ігнаруе параметры `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Пераканайцеся, што наперадзе ёсць хуткі шлях
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Поле `precision` можа быць інтэрпрэтавана як `max-width` для радка, які фарматуецца.
        //
        let s = if let Some(max) = self.precision {
            // Калі наш радок даўжэйшы за дакладнасць, мы павінны мець усечэнне.
            // Аднак іншыя сцягі, такія як `fill`, `width` і `align`, павінны дзейнічаць як заўсёды.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM тут не можа даказаць, што `..i` не будзе panic `&s[..i]`, але мы ведаем, што не можа panic.
                // Выкарыстоўвайце `get` + `unwrap_or`, каб пазбегнуць `unsafe` і ў адваротным выпадку не выпраменьвайце тут ніякі код, звязаны з panic.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // На дадзены момант поле `width`-гэта хутчэй параметр `min-width`.
        match self.width {
            // Калі мы знаходзімся пад максімальнай даўжынёй і не патрабуем мінімальнай даўжыні, мы можам проста выпраменьваць радок
            //
            None => self.buf.write_str(s),
            // Калі мы знаходзімся пад максімальнай шырынёй, праверце, калі мы перавышаем мінімальную шырыню, калі гэта так проста, як проста выпраменьваць радок.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Калі мы максімальную і мінімальную шырыню, запоўніце мінімальную шырыню зададзеным радком + нейкім выраўноўваннем.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Напішыце папярэднюю пракладку і вярніце няпісаную паслядовую запраўку.
    /// Удзельнікі тэлефанавання нясуць адказнасць за тое, каб пасля таго, як падкладаюць, пісалася пасля таго, як пракладка будзе зроблена.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Бярэ адфарматаваныя часткі і прымяняе пракладкі.
    /// Мяркуецца, што абанент ужо зрабіў часткі з неабходнай дакладнасцю, так што `self.precision` можна ігнараваць.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // для нулявой пракладкі, якая ўсведамляе знакі, мы робім знак першым і паводзім сябе так, быццам у нас не было знака з самага пачатку.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // знак заўсёды ідзе першым
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // выдаліце знак з адфарматаваных частак
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // астатнія часткі праходзяць звычайны працэс набівання.
            let len = formatted.len();
            let ret = if width <= len {
                // без пракладкі
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // гэта звычайная справа, і мы бярэм ярлык
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // БЯСПЕКА: выкарыстоўваецца для `flt2dec::Part::Num` і `flt2dec::Part::Copy`.
            // Гэта бяспечна ў выкарыстанні для `flt2dec::Part::Num`, паколькі кожны знак `c` знаходзіцца паміж `b'0'` і `b'9'`, што азначае, што `s` сапраўдны UTF-8.
            // На практыцы таксама напэўна бяспечна выкарыстоўваць для `flt2dec::Part::Copy(buf)`, бо `buf` павінен быць простым ASCII, але магчыма, каб хтосьці перадаў дрэннае значэнне для `buf` у `flt2dec::to_shortest_str`, бо гэта грамадская функцыя.
            //
            // FIXME: Вызначце, ці можа гэта прывесці да УБ.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 нулі
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Запісвае некаторыя дадзеныя ў асноўны буфер, які змяшчаецца ў гэтым фармататары.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Гэта эквівалентна:
    ///         // пішы! (фарматар, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Запісвае ў гэты асобнік адфарматаваную інфармацыю.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Сцягі для фарматавання
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Сімвал выкарыстоўваецца як 'fill' пры любым выраўноўванні.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Мы задаём выраўноўванне направа з ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Сцяг, які паказвае, якая форма выраўноўвання была запытана.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Неабавязкова зададзеная цэлалікавая шырыня, якая павінна быць на выхадзе.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Калі мы атрымалі шырыню, мы выкарыстоўваем яе
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // У адваротным выпадку мы нічога асаблівага не робім
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Дадаткова зададзеная дакладнасць для лікавых тыпаў.
    /// Акрамя таго, максімальная шырыня для тыпаў радкоў.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Калі мы атрымалі дакладнасць, мы выкарыстоўваем яе.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // У адваротным выпадку мы па змаўчанні 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Вызначае, ці быў указаны сцяг `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Вызначае, ці быў указаны сцяг `-`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Вы хочаце знак мінуса?Ёсць адзін!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Вызначае, ці быў указаны сцяг `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Вызначае, ці быў указаны сцяг `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Мы ігнаруем магчымасці фарматавання.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Вырашыце, які публічны API мы хочам для гэтых двух сцягоў.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Стварае канструктар [`DebugStruct`], распрацаваны для аказання дапамогі ў стварэнні рэалізацый [`fmt::Debug`] для структур.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Стварае канструктар `DebugTuple`, распрацаваны для аказання дапамогі ў стварэнні рэалізацый `fmt::Debug` для канструкцый карандашоў.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Стварае канструктар `DebugList`, распрацаваны для аказання дапамогі ў стварэнні рэалізацый `fmt::Debug` для падобных на спіс структур.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Стварае канструктар `DebugSet`, распрацаваны для аказання дапамогі ў стварэнні рэалізацый `fmt::Debug` для набору падобных структур.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// У гэтым больш складаным прыкладзе мы выкарыстоўваем [`format_args!`] і `.debug_set()` для стварэння спісу запалкавых зброй:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Стварае канструктар `DebugMap`, распрацаваны для аказання дапамогі ў стварэнні рэалізацый `fmt::Debug` для картападобных структур.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Рэалізацыі асноўнага фарматавання traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Калі char патрабуе ўцёкаў, схіліце адставанне і напішыце, інакш прапусціце
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Альтэрнатыўны сцяг LowerHex ужо разглядае як асаблівы-ён пазначае, ці трэба прэфікс ставіць 0x.
        // Мы выкарыстоўваем яго, каб высветліць, павышаць нуль, ці не, а потым безумоўна ўсталяваць яго, каб атрымаць прэфікс.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Укараненне Display/Debug для розных тыпаў ядра

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell запазычаны, таму мы не можам паглядзець на яго значэнне тут.
                // Пакажыце замест гэтага запаўняльнік.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Калі вы чакалі, што тут будуць тэсты, паглядзіце замест гэтага файл core/tests/fmt.rs, гэта нашмат прасцей, чым ствараць тут усе структуры rt::Piece.
//
// Ёсць таксама выпрабаванні ў алоцы crate для тых, хто патрабуе размеркавання.