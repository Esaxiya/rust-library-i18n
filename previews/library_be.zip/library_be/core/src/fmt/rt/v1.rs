//! Гэта ўнутраны модуль, які выкарыстоўваецца ifmt!час выканання.Гэтыя структуры загадзя выпрацоўваюцца ў статычныя масівы для папярэдняй кампіляцыі радкоў фарматавання.
//!
//! Гэтыя азначэнні падобныя на іх эквіваленты `ct`, але адрозніваюцца тым, што іх можна статычна размеркаваць і злёгку аптымізаваць для выканання
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Магчымыя выраўноўванні, якія можна запытаць у рамках дырэктывы фарматавання.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Указанне на тое, што змест трэба выраўноўваць па левым краі.
    Left,
    /// Указанне на тое, што змесціва павінна быць выраўнавана па правым краі.
    Right,
    /// Указанне на тое, што змесціва павінна быць выраўнавана па цэнтры.
    Center,
    /// Не патрабавалася выраўноўванне.
    Unknown,
}

/// Выкарыстоўваецца спецыфікатарамі [width](https://doc.rust-lang.org/std/fmt/#width) і [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Пазначаны літаральным нумарам, захоўвае значэнне
    Is(usize),
    /// Вызначаны з выкарыстаннем сінтаксісаў `$` і `*`, захоўвае індэкс у `args`
    Param(usize),
    /// Ня вызначана
    Implied,
}