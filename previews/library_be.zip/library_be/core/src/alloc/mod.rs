//! API размеркавання памяці

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Памылка `AllocError` паказвае на збой размеркавання, які можа быць звязаны з вычарпаннем рэсурсаў альбо чымсьці няправільным пры аб'яднанні дадзеных аргументаў з гэтым размеркавальнікам.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (нам гэта трэба для наступнага ўключэння памылкі Portrait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Рэалізацыя `Allocator` можа выдзяляць, расці, скарачацца і вызваляць адвольныя блокі дадзеных, апісаныя праз [`Layout`][].
///
/// `Allocator` прызначаны для рэалізацыі на ZST, спасылках або разумных паказальніках, таму што такі размеркавальнік, як `MyAlloc([u8; N])`, нельга перамяшчаць без абнаўлення паказальнікаў у выдзеленай памяці.
///
/// У адрозненне ад [`GlobalAlloc`][], размеркаванне нулявога памеру дазволена ў `Allocator`.
/// Калі асноўны размеркатар не падтрымлівае гэта (напрыклад, jemalloc) або не вяртае нулявы паказальнік (напрыклад, `libc::malloc`), гэта павінна быць зафіксавана рэалізацыяй.
///
/// ### У цяперашні час выдзелена памяць
///
/// Некаторыя з метадаў патрабуюць, каб блок памяці *выдзяляўся* у цяперашні час * праз размеркавальнік.Гэта азначае, што:
///
/// * пачатковы адрас для гэтага блока памяці раней быў вернуты [`allocate`], [`grow`] або [`shrink`] і
///
/// * блок памяці пазней не быў вызвалены, калі блокі былі вызвалены непасрэдна шляхам перадачы ў [`deallocate`] альбо былі зменены шляхам перадачы ў [`grow`] альбо [`shrink`], які вяртае `Ok`.
///
/// Калі `grow` або `shrink` вярнулі `Err`, перададзены паказальнік застаецца сапраўдным.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Памяць памяці
///
/// Некаторыя з метадаў патрабуюць, каб макет *змяшчаў* блок памяці.
/// Што азначае для макета да "fit" блок памяці азначае (ці эквівалентна для блока памяці для "fit" макет) тое, што павінны выконвацца наступныя ўмовы:
///
/// * Блок павінен выдзяляцца з тым самым выраўноўваннем, што і [`layout.align()`], і
///
/// * Прадастаўлены [`layout.size()`] павінен знаходзіцца ў дыяпазоне `min ..= max`, дзе:
///   - `min` - памер макета, які апошні раз выкарыстоўваўся для выдзялення блока, і
///   - `max` гэта апошні фактычны памер, які вяртаецца з [`allocate`], [`grow`] ці [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Блокі памяці, вернутыя з размеркавальніка, павінны паказваць на сапраўдную памяць і захоўваць сваю сапраўднасць, пакуль экземпляр і ўсе яго клоны не будуць выдалены,
///
/// * кланаванне альбо перамяшчэнне размеркавальніка не павінна рабіць несапраўднымі блокі памяці, вернутыя з гэтага размеркатара.Кланаваны размеркатар павінен паводзіць сябе як той самы размеркатар, і
///
/// * любы паказальнік на блок памяці, які з'яўляецца [*currently allocated*], можа быць перададзены ў любы іншы спосаб размеркатара.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Спробы вылучэння блока памяці.
    ///
    /// Пасля поспеху вяртае [`NonNull<[u8]>`][NonNull], які адпавядае гарантыі памеру і выраўноўвання `layout`.
    ///
    /// Вяртаецца блок можа мець памер большы, чым паказана `layout.size()`, і можа ініцыяваць яго змесціва, а можа і не.
    ///
    /// # Errors
    ///
    /// Вяртанне `Err` азначае, што альбо памяць вычарпана, альбо `layout` не адпавядае абмежаванню памеру альбо выраўноўвання размеркатара.
    ///
    /// Рэалізацыя рэкамендуецца вяртаць `Err` пры вычарпанні памяці, а не панікаваць альбо перапыняць працу, але гэта не з'яўляецца строгім патрабаваннем.
    /// (У прыватнасці: гэта *законна* рэалізоўваць гэты Portrait на верхняй частцы базавай бібліятэкі размеркавання, якая спыняе вычарпанне памяці.)
    ///
    /// Кліентам, якія жадаюць перапыніць вылічэнні ў адказ на памылку размеркавання, рэкамендуецца выклікаць функцыю [`handle_alloc_error`], а не непасрэдна выклікаць `panic!` ці аналагічную.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Паводзіць сябе як `allocate`, але таксама забяспечвае нулявую ініцыялізацыю вернутай памяці.
    ///
    /// # Errors
    ///
    /// Вяртанне `Err` азначае, што альбо памяць вычарпана, альбо `layout` не адпавядае абмежаванню памеру альбо выраўноўвання размеркатара.
    ///
    /// Рэалізацыя рэкамендуецца вяртаць `Err` пры вычарпанні памяці, а не панікаваць альбо перапыняць працу, але гэта не з'яўляецца строгім патрабаваннем.
    /// (У прыватнасці: гэта *законна* рэалізоўваць гэты Portrait на верхняй частцы базавай бібліятэкі размеркавання, якая спыняе вычарпанне памяці.)
    ///
    /// Кліентам, якія жадаюць перапыніць вылічэнні ў адказ на памылку размеркавання, рэкамендуецца выклікаць функцыю [`handle_alloc_error`], а не непасрэдна выклікаць `panic!` ці аналагічную.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // БЯСПЕКА: `alloc` вяртае сапраўдны блок памяці
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Выдзяляе памяць, на якую спасылаецца `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` павінна абазначаць блок памяці [*currently allocated*] праз гэты размеркаталь, і
    /// * `layout` павінен [*fit*] гэты блок памяці.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Спробы пашырэння блока памяці.
    ///
    /// Вяртае новы [`NonNull<[u8]>`][NonNull], які змяшчае паказальнік і фактычны памер выдзеленай памяці.Паказальнік падыходзіць для захоўвання дадзеных, апісаных `new_layout`.
    /// Для гэтага размеркавальнік можа пашырыць размеркаванне, на якое спасылаецца `ptr`, у адпаведнасці з новым макетам.
    ///
    /// Калі гэта вяртае `Ok`, то ўладанне блокам памяці, на які спасылаецца `ptr`, было перададзена ў гэты размеркатар.
    /// Памяць можа быць вызвалена, а можа і не прызнана, і яе трэба лічыць непрыдатнай, калі яна зноў не была перададзена абаненту праз зваротнае значэнне гэтага метаду.
    ///
    /// Калі гэты метад вяртае `Err`, уласнасць блока памяці не была перададзена ў гэты размеркатар, і змест блока памяці не змяняецца.
    ///
    /// # Safety
    ///
    /// * `ptr` павінен абазначаць блок памяці [*currently allocated*] праз гэты размеркатар.
    /// * `old_layout` павінен [*fit*], які змяшчае блок памяці (аргумент `new_layout` не павінен адпавядаць яму.).
    /// * `new_layout.size()` павінна быць большай або роўнай `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Вяртае `Err`, калі новая кампаноўка не адпавядае памерам і выраўноўванню размеркавальніка размеркавальніка, альбо калі рост не атрымліваецца ў адваротным выпадку.
    ///
    /// Рэалізацыя рэкамендуецца вяртаць `Err` пры вычарпанні памяці, а не панікаваць альбо перапыняць працу, але гэта не з'яўляецца строгім патрабаваннем.
    /// (У прыватнасці: гэта *законна* рэалізоўваць гэты Portrait на верхняй частцы базавай бібліятэкі размеркавання, якая спыняе вычарпанне памяці.)
    ///
    /// Кліентам, якія жадаюць перапыніць вылічэнні ў адказ на памылку размеркавання, рэкамендуецца выклікаць функцыю [`handle_alloc_error`], а не непасрэдна выклікаць `panic!` ці аналагічную.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // БЯСПЕКА: таму што `new_layout.size()` павінна быць большай або роўнай
        // `old_layout.size()`, як старое, так і новае размеркаванне памяці сапраўдныя для чытання і запісу для байтаў `old_layout.size()`.
        // Акрамя таго, паколькі старое размеркаванне яшчэ не было вызвалена, яно не можа перакрываць `new_ptr`.
        // Такім чынам, званок на `copy_nonoverlapping` бяспечны.
        // Дамова бяспекі для `dealloc` павінна выконвацца абанентам.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Паводзіць сябе як `grow`, але таксама гарантуе, што новае змесціва будзе вернута да нуля.
    ///
    /// Блок памяці будзе ўтрымліваць наступнае змесціва пасля паспяховага звароту да
    /// `grow_zeroed`:
    ///   * Байты `0..old_layout.size()` захаваны ад першапачатковага размеркавання.
    ///   * Байты `old_layout.size()..old_size` будуць альбо захаваны, альбо абнулены, у залежнасці ад рэалізацыі размеркавальніка.
    ///   `old_size` адносіцца да памеру блока памяці да выкліку `grow_zeroed`, які можа быць большым, чым памер, які быў першапачаткова запытаны пры яго размеркаванні.
    ///   * Байты `old_size..new_size` абнулены.`new_size` адносіцца да памеру блока памяці, які вяртаецца пры выкліку `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` павінен абазначаць блок памяці [*currently allocated*] праз гэты размеркатар.
    /// * `old_layout` павінен [*fit*], які змяшчае блок памяці (аргумент `new_layout` не павінен адпавядаць яму.).
    /// * `new_layout.size()` павінна быць большай або роўнай `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Вяртае `Err`, калі новая кампаноўка не адпавядае памерам і выраўноўванню размеркавальніка размеркавальніка, альбо калі рост не атрымліваецца ў адваротным выпадку.
    ///
    /// Рэалізацыя рэкамендуецца вяртаць `Err` пры вычарпанні памяці, а не панікаваць альбо перапыняць працу, але гэта не з'яўляецца строгім патрабаваннем.
    /// (У прыватнасці: гэта *законна* рэалізоўваць гэты Portrait на верхняй частцы базавай бібліятэкі размеркавання, якая спыняе вычарпанне памяці.)
    ///
    /// Кліентам, якія жадаюць перапыніць вылічэнні ў адказ на памылку размеркавання, рэкамендуецца выклікаць функцыю [`handle_alloc_error`], а не непасрэдна выклікаць `panic!` ці аналагічную.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // БЯСПЕКА: таму што `new_layout.size()` павінна быць большай або роўнай
        // `old_layout.size()`, як старое, так і новае размеркаванне памяці сапраўдныя для чытання і запісу для байтаў `old_layout.size()`.
        // Акрамя таго, паколькі старое размеркаванне яшчэ не было вызвалена, яно не можа перакрываць `new_ptr`.
        // Такім чынам, званок на `copy_nonoverlapping` бяспечны.
        // Дамова бяспекі для `dealloc` павінна выконвацца абанентам.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Спробы скараціць блок памяці.
    ///
    /// Вяртае новы [`NonNull<[u8]>`][NonNull], які змяшчае паказальнік і фактычны памер выдзеленай памяці.Паказальнік падыходзіць для захоўвання дадзеных, апісаных `new_layout`.
    /// Для гэтага размеркавальнік можа скараціць размеркаванне, на якое спасылаецца `ptr`, у адпаведнасці з новым макетам.
    ///
    /// Калі гэта вяртае `Ok`, то ўладанне блокам памяці, на які спасылаецца `ptr`, было перададзена ў гэты размеркатар.
    /// Памяць можа быць вызвалена, а можа і не прызнана, і яе трэба лічыць непрыдатнай, калі яна зноў не была перададзена абаненту праз зваротнае значэнне гэтага метаду.
    ///
    /// Калі гэты метад вяртае `Err`, уласнасць блока памяці не была перададзена ў гэты размеркатар, і змест блока памяці не змяняецца.
    ///
    /// # Safety
    ///
    /// * `ptr` павінен абазначаць блок памяці [*currently allocated*] праз гэты размеркатар.
    /// * `old_layout` павінен [*fit*], які змяшчае блок памяці (аргумент `new_layout` не павінен адпавядаць яму.).
    /// * `new_layout.size()` павінна быць меншай або роўнай `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Вяртае `Err`, калі новая кампаноўка не адпавядае памерам і выраўноўванню размеркавальніка размеркавальніка альбо калі памяншэнне ў адваротным выпадку не ўдаецца.
    ///
    /// Рэалізацыя рэкамендуецца вяртаць `Err` пры вычарпанні памяці, а не панікаваць альбо перапыняць працу, але гэта не з'яўляецца строгім патрабаваннем.
    /// (У прыватнасці: гэта *законна* рэалізоўваць гэты Portrait на верхняй частцы базавай бібліятэкі размеркавання, якая спыняе вычарпанне памяці.)
    ///
    /// Кліентам, якія жадаюць перапыніць вылічэнні ў адказ на памылку размеркавання, рэкамендуецца выклікаць функцыю [`handle_alloc_error`], а не непасрэдна выклікаць `panic!` ці аналагічную.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // БЯСПЕКА: таму што `new_layout.size()` павінна быць ніжэйшай або роўнай
        // `old_layout.size()`, як старое, так і новае размеркаванне памяці сапраўдныя для чытання і запісу для байтаў `new_layout.size()`.
        // Акрамя таго, паколькі старое размеркаванне яшчэ не было вызвалена, яно не можа перакрываць `new_ptr`.
        // Такім чынам, званок на `copy_nonoverlapping` бяспечны.
        // Дамова бяспекі для `dealloc` павінна выконвацца абанентам.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Стварае адаптар "by reference" для гэтага асобніка `Allocator`.
    ///
    /// Вяртаецца адаптар таксама рэалізуе `Allocator` і проста запазычыць яго.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}