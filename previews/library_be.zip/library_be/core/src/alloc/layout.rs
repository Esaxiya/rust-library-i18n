use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Хоць гэтая функцыя выкарыстоўваецца ў адным месцы, і яе рэалізацыю можна было б сфармуляваць, папярэднія спробы зрабіць гэта rustc павольней:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Макет блока памяці.
///
/// Прыклад `Layout` апісвае пэўны макет памяці.
/// Вы ствараеце `Layout` у якасці ўваходных дадзеных для размеркавання.
///
/// Усе макеты маюць адпаведны памер і выраўноўванне "магутнасць-два".
///
/// (Звярніце ўвагу, што макеты *не* павінны мець ненулявы памер, нават калі `GlobalAlloc` патрабуе, каб усе запыты памяці мелі не нулявы памер.
/// Абанент павінен альбо забяспечыць выкананне падобных умоў, выкарыстоўваць пэўныя размеркавальнікі з больш слабымі патрабаваннямі альбо выкарыстоўваць больш мяккі інтэрфейс `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // памер запытанага блока памяці, вымяраецца ў байтах.
    size_: usize,

    // выраўноўванне запытанага блока памяці, вымяраецца ў байтах.
    // мы гарантуем, што гэта заўсёды мае моц, таму што API, як `posix_memalign`, гэтага патрабуе, і гэта разумнае абмежаванне для канструктараў Layout.
    //
    //
    // (Аднак мы аналагічна не патрабуем `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Канструюе `Layout` з зададзеных `size` і `align` альбо вяртае `LayoutError`, калі не выконваюцца любыя з наступных умоў:
    ///
    /// * `align` не павінна быць роўным нулю,
    ///
    /// * `align` павінна быць у два разы,
    ///
    /// * `size`, калі акругляецца да бліжэйшага кратнага `align`, не павінна пералівацца (гэта значыць, акругленае значэнне павінна быць менш або роўна `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two мае на ўвазе выраўноўванне!=0.)

        // Павялічаны памер:
        //   size_rounded_up=(памер + выраўнаваць, 1)&! (выраўнаваць, 1);
        //
        // Зверху мы ведаем, што выраўнаваць!=0.
        // Калі даданне (выраўнаванне, 1) не перапоўніцца, акругленне ўверх будзе выдатным.
        //
        // І наадварот,&-маскіроўка з! (Выраўнаванне, 1) адніме толькі біты нізкага парадку.
        // Такім чынам, калі перапаўненне адбываецца з сумай,&-mask не можа адняць дастаткова, каб адмяніць гэты перапаўненне.
        //
        //
        // Вышэй вынікае, што праверка перапаўнення сумавання неабходная і дастатковая.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // БЯСПЕКА: умовы для `from_size_align_unchecked` былі
        // праверана вышэй.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Стварае макет, абыходзячы ўсе праверкі.
    ///
    /// # Safety
    ///
    /// Гэтая функцыя небяспечная, бо не правярае перадумовы [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // БЯСПЕКА: абанент павінен пераканацца, што `align` перавышае нуль.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Мінімальны памер у байтах для блока памяці гэтай раскладкі.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Мінімальнае выраўноўванне байтаў для блока памяці гэтага макета.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Канструюе `Layout`, прыдатны для ўтрымання значэння тыпу `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // БЯСПЕКА: выраўноўванне гарантуецца Rust магутнасцю два і
        // камбінацыя памеру + выраўноўванне гарантавана ўпісваецца ў нашу адрасную прастору.
        // У выніку выкарыстоўвайце тут неправераны канструктар, каб пазбегнуць ўстаўкі кода panics, калі ён недастаткова аптымізаваны.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Вырабляе макет з апісаннем запісу, які можа быць выкарыстаны для выдзялення структуры падкладкі для `T` (якая можа быць Portrait альбо іншага тыпу невялікага памеру, напрыклад зрэзу).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЯСПЕКА: гл. Абгрунтаванне `new`, чаму выкарыстоўваецца небяспечны варыянт
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Вырабляе макет з апісаннем запісу, які можа быць выкарыстаны для выдзялення структуры падкладкі для `T` (якая можа быць Portrait альбо іншага тыпу невялікага памеру, напрыклад зрэзу).
    ///
    /// # Safety
    ///
    /// Выклік гэтай функцыі бяспечны толькі пры выкананні наступных умоў:
    ///
    /// - Калі `T`-гэта `Sized`, выклік гэтай функцыі заўсёды бяспечны.
    /// - Калі хвост `T` невялікага памеру:
    ///     - [slice], тады даўжыня зрэзавага хваста павінна быць ініцыялізаваным цэлым лікам, а памер *усяго значэння*(дынамічная даўжыня хваста + статычны памер прыстаўкі) павінен адпавядаць `isize`.
    ///     - [trait object], тады частка паказальніка vtable павінна паказваць на сапраўдную vtable для тыпу `T`, атрыманага з дапамогай прымусовай размеркавання, і памер *цэлага значэння*(дынамічная даўжыня хваста + статычны памер прыстаўкі) павінен змяшчацца ў `isize`.
    ///
    ///     - (unstable) [extern type], тады гэтую функцыю заўсёды бяспечна выклікаць, але panic можа вярнуць няправільнае значэнне, бо макет знешняга тыпу невядомы.
    ///     Гэта тое самае паводзіны, што і [`Layout::for_value`] пры спасылцы на хвост знешняга тыпу.
    ///     - у адваротным выпадку кансерватыўна забараняецца выклікаць гэтую функцыю.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // БЯСПЕКА: мы перадаем неабходныя ўмовы гэтых функцый абаненту
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЯСПЕКА: гл. Абгрунтаванне `new`, чаму выкарыстоўваецца небяспечны варыянт
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Стварае `NonNull`, які вісіць, але добра выраўнаваны для гэтага макета.
    ///
    /// Звярніце ўвагу, што значэнне паказальніка можа патэнцыйна прадстаўляць сапраўдны паказальнік, а гэта значыць, што яно не павінна выкарыстоўвацца ў якасці вартавога "not yet initialized".
    /// Тыпы, якія ляніва выдзяляюць, павінны адсочваць ініцыялізацыю іншымі спосабамі.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // БЯСПЕКА: выраўноўванне гарантавана будзе ненулявым
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Стварае макет, які апісвае запіс, які можа ўтрымліваць значэнне таго ж макета, што і `self`, але які таксама выраўноўваецца па выраўноўванні `align` (вымяраецца ў байтах).
    ///
    ///
    /// Калі `self` ужо адпавядае зададзенаму выраўноўванню, вяртаецца `self`.
    ///
    /// Звярніце ўвагу, што гэты метад не дадае аніводнай абіўкі да агульнага памеру, незалежна ад таго, ці мае вернуты макет іншае выраўноўванне.
    /// Іншымі словамі, калі `K` мае памер 16, `K.align_to(32)` будзе *па-ранейшаму* мець памер 16.
    ///
    /// Вяртае памылку, калі камбінацыя `self.size()` і дадзенага `align` парушае ўмовы, пералічаныя ў [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Вяртае колькасць запаўнення, якое мы павінны ўставіць пасля `self`, каб пераканацца, што наступны адрас задаволіць `align` (вымяраецца ў байтах).
    ///
    /// напрыклад, калі `self.size()` складае 9, то `self.padding_needed_for(4)` вяртае 3, таму што гэта мінімальная колькасць байтаў запаўнення, неабходнае для атрымання 4-выраўнаванага адраса (пры ўмове, што адпаведны блок памяці пачынаецца з 4-выраўнаванага адраса).
    ///
    ///
    /// Вяртанне значэння гэтай функцыі не мае значэння, калі `align` не з'яўляецца сілай двух.
    ///
    /// Звярніце ўвагу, што карыснасць вернутага значэння патрабуе, каб `align` быў меншы або роўны выраўноўванню пачатковага адраса для ўсяго выдзеленага блока памяці.Адзін са спосабаў задаволіць гэта абмежаванне-забяспечыць `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Акругленае значэнне:
        //   len_rounded_up=(len + выраўнаваць, 1)&! (выраўнаваць, 1);
        // а потым мы вяртаем розніцу ў запраўках: `len_rounded_up - len`.
        //
        // Мы выкарыстоўваем модульную арыфметыку на працягу:
        //
        // 1. выраўноўванне гарантавана складае> 0, таму выраўноўванне, 1 заўсёды дзейнічае.
        //
        // 2.
        // `len + align - 1` можа перапаўніць не больш за `align - 1`, таму&-маска з `!(align - 1)` забяспечыць, што ў выпадку перапаўнення `len_rounded_up` сам будзе роўны 0.
        //
        //    Такім чынам, вернутая абіўка пры даданні да `len` дае 0, што трывіяльна задавальняе выраўноўванню `align`.
        //
        // (Зразумела, спробы вылучыць блокі памяці, памер якіх і перапаўненне пералічаным спосабам вышэй, павінны прывесці да таго, што размеркатар выдасць памылку.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Стварае макет, акругляючы памер гэтага макета да кратнага выраўноўвання макета.
    ///
    ///
    /// Гэта эквівалентна даданню выніку `padding_needed_for` да бягучага памеру макета.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Гэта не можа перапоўніцца.Цытую інварыянт Layout:
        // > `size`, калі акругляецца да бліжэйшага кратнага `align`,
        // > не павінна пералівацца (г.зн. акругленае значэнне павінна быць менш за
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Стварае макет, які апісвае запіс для экземпляраў `self` `self`, з прыдатнай колькасцю пракладкі паміж кожнай, каб гарантаваць, што кожнаму асобніку дадзены патрэбны памер і выраўноўванне.
    /// Пры поспеху вяртае `(k, offs)`, дзе `k`-гэта макет масіва, а `offs`-адлегласць паміж пачаткам кожнага элемента ў масіве.
    ///
    /// Пры арыфметычным перапаўненні вяртае `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Гэта не можа перапоўніцца.Цытую інварыянт Layout:
        // > `size`, калі акругляецца да бліжэйшага кратнага `align`,
        // > не павінна пералівацца (г.зн. акругленае значэнне павінна быць менш за
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // БЯСПЕКА: self.align ужо вядомы як сапраўдны, і alloc_size быў
        // падбіты ўжо.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Стварае макет, які апісвае запіс для `self`, за якім ідзе `next`, уключаючы ўсе неабходныя пракладкі, каб `next` быў правільна выраўнаваны, але *няма задняй пракладкі*.
    ///
    /// Для таго, каб адпавядаць макету прадстаўлення C `repr(C)`, вам варта патэлефанаваць у `pad_to_align` пасля пашырэння макета з усімі палямі.
    /// (Няма ніякага спосабу параўнаць макет прадстаўлення Rust па змаўчанні `repr(Rust)`, as it is unspecified.)
    ///
    /// Звярніце ўвагу, што выраўноўванне атрыманага макета будзе максімальным для выраўноўвання `self` і `next`, каб забяспечыць выраўноўванне абедзвюх частак.
    ///
    /// Вяртае `Ok((k, offset))`, дзе `k`-гэта размяшчэнне аб'яднанай запісы, а `offset`-адноснае размяшчэнне ў байтах пачатку `next`, убудаванага ў аб'яднаную запіс (калі выказаць здагадку, што сама запіс пачынаецца са зрушэння 0).
    ///
    ///
    /// Пры арыфметычным перапаўненні вяртае `LayoutError`.
    ///
    /// # Examples
    ///
    /// Каб вылічыць макет структуры `#[repr(C)]` і зрушэнні палёў ад макетаў яе палёў:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Не забудзьцеся дапрацаваць з `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // праверыць, ці працуе
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Стварае макет, які апісвае запіс для экземпляраў `self` `self`, без афармлення паміж кожным асобнікам.
    ///
    /// Звярніце ўвагу, што, у адрозненне ад `repeat`, `repeat_packed` не гарантуе, што паўторныя асобнікі `self` будуць правільна выраўнаваны, нават калі дадзены асобнік `self` правільна выраўнаваны.
    /// Іншымі словамі, калі макет, вернуты `repeat_packed`, выкарыстоўваецца для выдзялення масіва, не гарантуецца, што ўсе элементы ў масіве будуць правільна выраўнаваны.
    ///
    /// Пры арыфметычным перапаўненні вяртае `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Стварае макет, які апісвае запіс для `self`, за якім ідзе `next`, без дадатковых пракладак паміж імі.
    /// Паколькі пракладка не ўстаўлена, выраўноўванне `next` не мае значэння і зусім не ўключана * у выніковы макет.
    ///
    ///
    /// Пры арыфметычным перапаўненні вяртае `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Стварае макет, які апісвае запіс для `[T; n]`.
    ///
    /// Пры арыфметычным перапаўненні вяртае `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Параметры, зададзеныя `Layout::from_size_align` альбо іншаму канструктару `Layout`, не адпавядаюць дакументальным абмежаванням.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (нам гэта трэба для наступнага ўключэння памылкі Portrait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}