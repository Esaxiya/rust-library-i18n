#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Пашыраецца альбо на `$crate::panic::panic_2015`, альбо на `$crate::panic::panic_2021` у залежнасці ад выпуску абанента.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Сцвярджае, што два выразы роўныя паміж сабой (з выкарыстаннем [`PartialEq`]).
///
/// На panic гэты макрас будзе выводзіць значэнні выразаў з прадстаўленнямі адладкі.
///
///
/// Як і [`assert!`], гэты макрас мае другую форму, дзе можа быць прадастаўлена карыстацкае паведамленне panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Перазагрузкі ніжэй наўмысныя.
                    // Без іх слот стэка для пазыкі ініцыялізуецца яшчэ да параўнання значэнняў, што прыводзіць да прыкметнага запаволення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Перазагрузкі ніжэй наўмысныя.
                    // Без іх слот стэка для пазыкі ініцыялізуецца яшчэ да параўнання значэнняў, што прыводзіць да прыкметнага запаволення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Сцвярджае, што два выразы не роўныя паміж сабой (з выкарыстаннем [`PartialEq`]).
///
/// На panic гэты макрас будзе выводзіць значэнні выразаў з прадстаўленнямі адладкі.
///
///
/// Як і [`assert!`], гэты макрас мае другую форму, дзе можа быць прадастаўлена карыстацкае паведамленне panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Перазагрузкі ніжэй наўмысныя.
                    // Без іх слот стэка для пазыкі ініцыялізуецца яшчэ да параўнання значэнняў, што прыводзіць да прыкметнага запаволення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Перазагрузкі ніжэй наўмысныя.
                    // Без іх слот стэка для пазыкі ініцыялізуецца яшчэ да параўнання значэнняў, што прыводзіць да прыкметнага запаволення.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Сцвярджае, што лагічным выразам з'яўляецца `true` падчас выканання.
///
/// Гэта выкліча макрас [`panic!`], калі прадастаўлены выраз не можа быць ацэнены ў `true` падчас выканання.
///
/// Як і [`assert!`], у гэтага макраса таксама ёсць другая версія, дзе можа быць прадастаўлена карыстацкае паведамленне panic.
///
/// # Uses
///
/// У адрозненне ад [`assert!`], аператары `debug_assert!` уключаны толькі ў неаптымізаваных зборках па змаўчанні.
/// Аптымізаваная зборка не будзе выконваць аператары `debug_assert!`, калі `-C debug-assertions` не перадаецца кампілятару.
/// Гэта робіць `debug_assert!` карысным для праверак, якія занадта дарагія, каб прысутнічаць у зборцы выпуску, але могуць быць карыснымі падчас распрацоўкі.
/// У выніку пашырэння `debug_assert!` заўсёды праводзіцца праверка тыпу.
///
/// Неправеранае сцвярджэнне дазваляе праграме ў непаслядоўным стане працягваць працаваць, што можа мець нечаканыя наступствы, але не стварае небяспекі, пакуль гэта адбываецца толькі ў бяспечным кодзе.
///
/// Аднак кошт прадукцыйнасці сцвярджэнняў у цэлым не паддаецца вымярэнню.
/// Такім чынам, замена [`assert!`] на `debug_assert!` рэкамендуецца толькі пасля дбайнага прафілявання, і што больш важна, толькі ў бяспечным кодзе!
///
/// # Examples
///
/// ```
/// // паведамленне panic для гэтых сцвярджэнняў-гэта стрыфікаванае значэнне дадзенага выразу.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // вельмі простая функцыя
/// debug_assert!(some_expensive_computation());
///
/// // сцвярджаць з дапамогай карыстацкага паведамлення
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Сцвярджае, што два выразы роўныя адзін аднаму.
///
/// На panic гэты макрас будзе выводзіць значэнні выразаў з прадстаўленнямі адладкі.
///
/// У адрозненне ад [`assert_eq!`], аператары `debug_assert_eq!` уключаны толькі ў неаптымізаваных зборках па змаўчанні.
/// Аптымізаваная зборка не будзе выконваць аператары `debug_assert_eq!`, калі `-C debug-assertions` не перадаецца кампілятару.
/// Гэта робіць `debug_assert_eq!` карысным для праверак, якія занадта дарагія, каб прысутнічаць у зборцы выпуску, але могуць быць карыснымі падчас распрацоўкі.
///
/// У выніку пашырэння `debug_assert_eq!` заўсёды праводзіцца праверка тыпу.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Сцвярджае, што два выразы не роўныя адзін аднаму.
///
/// На panic гэты макрас будзе выводзіць значэнні выразаў з прадстаўленнямі адладкі.
///
/// У адрозненне ад [`assert_ne!`], аператары `debug_assert_ne!` уключаны толькі ў неаптымізаваных зборках па змаўчанні.
/// Аптымізаваная зборка не будзе выконваць аператары `debug_assert_ne!`, калі `-C debug-assertions` не перадаецца кампілятару.
/// Гэта робіць `debug_assert_ne!` карысным для праверак, якія занадта дарагія, каб прысутнічаць у зборцы выпуску, але могуць быць карыснымі падчас распрацоўкі.
///
/// У выніку пашырэння `debug_assert_ne!` заўсёды праводзіцца праверка тыпу.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Вяртае, ці адпавядае дадзены выраз любому з дадзеных шаблонаў.
///
/// Як і ў выразе `match`, узор можа неабавязкова суправаджацца `if` і выразам-ахоўнікам, які мае доступ да імёнаў, абмежаваных узорам.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Распакоўвае вынік альбо распаўсюджвае яго памылку.
///
/// На змену `try!` быў дададзены аператар `?`, які павінен выкарыстоўвацца замест яго.
/// Акрамя таго, `try`-гэта зарэзерваванае слова ў Rust 2018, таму, калі вам трэба яго выкарыстоўваць, вам трэба будзе выкарыстоўваць [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` адпавядае дадзенаму [`Result`].У выпадку варыянту `Ok`, выраз мае значэнне абгорнутага значэння.
///
/// У выпадку варыянту `Err` ён атрымлівае ўнутраную памылку.Затым `try!` выконвае пераўтварэнне з выкарыстаннем `From`.
/// Гэта забяспечвае аўтаматычнае пераўтварэнне паміж спецыялізаванымі памылкамі і больш агульнымі.
/// У выніку памылка неадкладна вяртаецца.
///
/// З-за датэрміновага вяртання `try!` можна выкарыстоўваць толькі ў функцыях, якія вяртаюць [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Пераважны метад хуткага вяртання памылак
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Папярэдні метад хуткага вяртання памылак
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Гэта эквівалентна:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Запісвае адфарматаваныя дадзеныя ў буфер.
///
/// Гэты макрас прымае 'writer', радок фарматавання і спіс аргументаў.
/// Аргументы будуць адфарматаваны ў адпаведнасці з зададзеным радком фармату, а вынік будзе перададзены аўтару.
/// Сцэнар можа мець любое значэнне з метадам `write_fmt`;як правіла, гэта адбываецца ад рэалізацыі альбо [`fmt::Write`], альбо [`io::Write`] Portrait.
/// Макрас вяртае ўсё, што вяртае метад `write_fmt`;звычайна [`fmt::Result`], альбо [`io::Result`].
///
/// Для атрымання дадатковай інфармацыі пра сінтаксіс радка фармату см. [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модуль можа імпартаваць як `std::fmt::Write`, так і `std::io::Write` і выклікаць `write!` для аб'ектаў, якія рэалізуюць абодва, бо аб'екты звычайна не рэалізуюць абодва.
///
/// Аднак модуль павінен імпартаваць кваліфікаваны traits, каб іх імёны не супярэчылі:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // выкарыстоўвае fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // выкарыстоўвае io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Гэты макрас можна выкарыстоўваць і ў наладах `no_std`.
/// У наладах `no_std` вы адказваеце за дэталі рэалізацыі кампанентаў.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Запішыце адфарматаваныя дадзеныя ў буфер, дадаўшы новы радок.
///
/// На ўсіх платформах новы радок-гэта сімвал LINE FEED (`\n`/`U+000A`) (без дадатковага звароту CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Для атрымання дадатковай інфармацыі см. [`write!`].Для атрымання інфармацыі пра сінтаксіс радка фармату см. [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модуль можа імпартаваць як `std::fmt::Write`, так і `std::io::Write` і выклікаць `write!` для аб'ектаў, якія рэалізуюць абодва, бо аб'екты звычайна не рэалізуюць абодва.
/// Аднак модуль павінен імпартаваць кваліфікаваны traits, каб іх імёны не супярэчылі:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // выкарыстоўвае fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // выкарыстоўвае io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Паказвае недаступны код.
///
/// Гэта карысна ў любы час, калі кампілятар не можа вызначыць, што нейкі код недаступны.Напрыклад:
///
/// * Супастаўце зброю з умовамі аховы.
/// * Цыклы, якія дынамічна завяршаюцца.
/// * Ітэратары, якія дынамічна завяршаюцца.
///
/// Калі вызначэнне недаступнасці кода аказваецца няправільным, праграма неадкладна спыняе працу з [`panic!`].
///
/// Небяспечным аналагам гэтага макраса з'яўляецца функцыя [`unreachable_unchecked`], якая выкліча неакрэсленыя паводзіны пры дасягненні кода.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Гэта заўсёды будзе [`panic!`].
///
/// # Examples
///
/// Матч зброі:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // памылка кампіляцыі, калі каментаваць
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // адна з самых бедных рэалізацый x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Указвае на няздзейснены код пры паніцы паведамленнем "not implemented".
///
/// Гэта дазваляе вашаму коду праверыць тып, што карысна, калі вы прататыпіруеце альбо рэалізуеце Portrait, які патрабуе некалькіх метадаў, якія вы не плануеце выкарыстоўваць усе.
///
/// Розніца паміж `unimplemented!` і [`todo!`] заключаецца ў тым, што ў той час як `todo!` перадае намер рэалізаваць функцыянальнасць пазней і паведамленне "not yet implemented", `unimplemented!` не прад'яўляе такіх прэтэнзій.
/// Яго паведамленне-"not implemented".
/// Таксама некаторыя IDE будуць пазначаць `todo!` S.
///
/// # Panics
///
/// Гэта заўсёды будзе [`panic!`], таму што `unimplemented!`-гэта проста скарачэнне `panic!` з фіксаваным, канкрэтным паведамленнем.
///
/// Як і `panic!`, гэты макрас мае другую форму для адлюстравання карыстацкіх значэнняў.
///
/// # Examples
///
/// Скажам, у нас ёсць Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Мы хочам рэалізаваць `Foo` для 'MyStruct', але чамусьці мае сэнс толькі рэалізаваць функцыю `bar()`.
/// `baz()` і `qux()` яшчэ трэба будзе вызначыць у нашай рэалізацыі `Foo`, але мы можам выкарыстоўваць `unimplemented!` у іх вызначэннях, каб дазволіць кампіляваць наш код.
///
/// Мы па-ранейшаму хочам, каб наша праграма спыніла працу пры дасягненні нявыкананых метадаў.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Не мае сэнсу `baz` і `MyStruct`, таму ў нас наогул няма логікі.
/////
///         // Тут будзе адлюстроўвацца "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // У нас тут ёсць нейкая логіка, мы можам дадаць паведамленне да нерэалізаванага!каб адлюстраваць наша ўпушчэнне.
///         // Тут будзе адлюстравана: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Паказвае незавершаны код.
///
/// Гэта можа быць карысна, калі вы робіце прататыпы і проста хочаце праверыць увод кода.
///
/// Розніца паміж [`unimplemented!`] і `todo!` заключаецца ў тым, што ў той час як `todo!` перадае намер рэалізаваць функцыянальнасць пазней і паведамленне "not yet implemented", `unimplemented!` не прад'яўляе такіх прэтэнзій.
/// Яго паведамленне-"not implemented".
/// Таксама некаторыя IDE будуць пазначаць `todo!` S.
///
/// # Panics
///
/// Гэта заўсёды будзе [`panic!`].
///
/// # Examples
///
/// Вось прыклад некаторага незавершанага кода.У нас ёсць Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Мы хочам рэалізаваць `Foo` на адным з нашых тыпаў, але мы таксама хочам спачатку папрацаваць толькі над `bar()`.Для таго каб наш код скампіляваўся, нам трэба рэалізаваць `baz()`, таму мы можам выкарыстоўваць `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // рэалізацыя ідзе тут
///     }
///
///     fn baz(&self) {
///         // не будзем хвалявацца наконт рэалізацыі baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // мы нават не выкарыстоўваем baz(), так што гэта выдатна.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Вызначэнні ўбудаваных макрасаў.
///
/// Большасць уласцівасцей макрасаў (стабільнасць, бачнасць і г.д.) бяруцца з зыходнага кода тут, за выключэннем функцый пашырэння, якія пераўтвараюць макраўваходы ў выхады, гэтыя функцыі забяспечваюцца кампілятарам.
///
///
pub(crate) mod builtin {

    /// Прыводзіць да збою кампіляцыі пры зададзеным паведамленні пра памылку.
    ///
    /// Гэты макрас павінен выкарыстоўвацца, калі crate выкарыстоўвае стратэгію ўмоўнай кампіляцыі, каб забяспечваць лепшыя паведамленні пра памылкі пры памылковых умовах.
    ///
    /// Гэта форма [`panic!`] на ўзроўні кампілятара, але выдае памылку падчас *кампіляцыі*, а не падчас выканання *.
    ///
    /// # Examples
    ///
    /// Два такія прыклады-гэта макрасы і асяроддзя `#[cfg]`.
    ///
    /// Выдаваць лепшую памылку кампілятара, калі макрас перадае недапушчальныя значэнні.
    /// Без канчатковага branch кампілятар усё роўна выдасць памылку, але ў паведамленні пра памылку не будуць згаданы два сапраўдныя значэнні.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Выдаваць памылку кампілятара, калі адна з шэрагу функцый недаступная.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Стварае параметры для іншых макрасаў фарматавання радкоў.
    ///
    /// Гэты макрас функцыянуе, прымаючы літаральны радок фарматавання, які змяшчае `{}`, для кожнага перададзенага дадатковага аргументу.
    /// `format_args!` рыхтуе дадатковыя параметры для забеспячэння высновы, якая можа быць інтэрпрэтавана як радок і кананізацыі аргументаў у адзіны тып.
    /// Любое значэнне, якое рэалізуе [`Display`] Portrait, можа быць перададзена ў `format_args!`, як і любая рэалізацыя [`Debug`] у `{:?}` у радку фарматавання.
    ///
    ///
    /// Гэты макрас вырабляе значэнне тыпу [`fmt::Arguments`].Гэта значэнне можна перадаць макрасам у межах [`std::fmt`] для выканання карыснай перанакіравання.
    /// Усе астатнія макрасы фарматавання ([`фармат!`, [`write!`], [`println!`] і г.д.) праз гэты праксіруюцца.
    /// `format_args!`, у адрозненне ад атрыманых макрасаў, пазбягае размеркавання кучы.
    ///
    /// Вы можаце выкарыстоўваць значэнне [`fmt::Arguments`], якое `format_args!` вяртае ў кантэкстах `Debug` і `Display`, як паказана ніжэй.
    /// Прыклад таксама паказвае, што `Debug` і `Display` фарматуюць адно і тое ж: інтэрпаляваны радок фармату ў `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Для атрымання дадатковай інфармацыі глядзіце дакументацыю ў [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Тое самае, што і `format_args`, але ў рэшце рэшт дадае новы радок.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Аглядае зменную асяроддзя падчас кампіляцыі.
    ///
    /// Гэты макрас пашырыцца да значэння названай зменнай асяроддзя падчас кампіляцыі, атрымаўшы выраз тыпу `&'static str`.
    ///
    ///
    /// Калі зменная асяроддзя не вызначана, будзе выдадзена памылка кампіляцыі.
    /// Каб не выдаваць памылку кампіляцыі, выкарыстоўвайце макрас [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Вы можаце наладзіць паведамленне пра памылку, перадаўшы радок у якасці другога параметра:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Калі зменная асяроддзя `documentation` не вызначана, вы атрымаеце наступную памылку:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Неабавязкова правярае зменную асяроддзя падчас кампіляцыі.
    ///
    /// Калі названая зменная асяроддзя прысутнічае падчас кампіляцыі, гэта пашырыцца ў выраз тыпу `Option<&'static str>`, значэнне якога `Some` значэння зменнай асяроддзя.
    /// Калі зменнай асяроддзя няма, гэта павялічыцца да `None`.
    /// Для атрымання дадатковай інфармацыі пра гэты тып глядзіце [`Option<T>`][Option].
    ///
    /// Памылка часу кампіляцыі ніколі не выдаецца пры выкарыстанні гэтага макраса незалежна ад наяўнасці зменнай асяроддзя ці не.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Аб'ядноўвае ідэнтыфікатары ў адзін ідэнтыфікатар.
    ///
    /// Гэты макрас прымае любую колькасць ідэнтыфікатараў, падзеленых коскамі, і аб'ядноўвае іх усе ў адзін, атрымліваючы выраз, які з'яўляецца новым ідэнтыфікатарам.
    /// Звярніце ўвагу, што гігіена робіць так, што гэты макрас не можа захопліваць мясцовыя зменныя.
    /// Акрамя таго, як правіла, макрасы дапускаюцца толькі ў пазіцыі элемента, выказвання або выразу.
    /// Гэта азначае, што калі вы можаце выкарыстоўваць гэты макрас для спасылкі на існуючыя зменныя, функцыі альбо модулі і г.д., вы не можаце вызначыць новы з ім.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//не выкарыстоўваецца такім чынам!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Злучае літаралы ў статычны зрэз радка.
    ///
    /// Гэты макрас прымае любую колькасць літараў, падзеленых коскамі, што дае выраз тыпу `&'static str`, які прадстаўляе ўсе літаралы, аб'яднаныя злева направа.
    ///
    ///
    /// Цэлыя і літара з плаваючай кропкай радкіфікаваны для аб'яднання.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Пашыраецца да нумара радка, на якім ён быў выкліканы.
    ///
    /// У [`column!`] і [`file!`] гэтыя макрасы прадастаўляюць распрацоўшчыкам інфармацыю пра адладку пра месцазнаходжанне ў крыніцы.
    ///
    /// Разгорнуты выраз мае тып `u32` і заснаваны на 1, таму першы радок у кожным файле ацэньваецца ў 1, другі ў 2 і г.д.
    /// Гэта ўзгадняецца з паведамленнямі пра памылкі звычайных кампілятараў альбо папулярных рэдактараў.
    /// Вяртаецца радок *не абавязкова* радок самога выкліку `line!`, а, хутчэй, першы выклік макраса, які вядзе да выкліку макраса `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Пашыраецца да нумара слупка, пры якім ён быў выкліканы.
    ///
    /// У [`line!`] і [`file!`] гэтыя макрасы прадастаўляюць распрацоўшчыкам інфармацыю пра адладку пра месцазнаходжанне ў крыніцы.
    ///
    /// Разгорнуты выраз мае тып `u32` і заснаваны на 1, таму першы слупок у кожным радку ацэньваецца ў 1, другі ў 2 і г.д.
    /// Гэта ўзгадняецца з паведамленнямі пра памылкі звычайных кампілятараў альбо папулярных рэдактараў.
    /// Вяртаецца слупок *не абавязкова* радок самога выкліку `column!`, а, хутчэй, першы выклік макраса, які вядзе да выкліку макраса `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Пашыраецца да імя файла, у якім ён быў выкліканы.
    ///
    /// У [`line!`] і [`column!`] гэтыя макрасы прадастаўляюць распрацоўшчыкам інфармацыю пра адладку пра месцазнаходжанне ў крыніцы.
    ///
    /// Разгорнуты выраз мае тып `&'static str`, і вернуты файл з'яўляецца не выкліканнем самога макраса `file!`, а першым выклікам макраса, які вядзе да выкліку макраса `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Абгрунтоўвае свае аргументы.
    ///
    /// Гэты макрас дасць выраз тыпу `&'static str`, які з'яўляецца стрыфікацыяй усіх tokens, перададзеных макрасу.
    /// Сінтаксіс самога выкліку макраса не абмяжоўваецца.
    ///
    /// Звярніце ўвагу, што разгорнутыя вынікі ўводу tokens могуць змяніцца ў future.Вы павінны быць асцярожныя, калі спадзяецеся на выхад.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Уключае ў сябе радок, закадаваны UTF-8.
    ///
    /// Файл размешчаны адносна бягучага файла (аналагічна таму, як знаходзяцца модулі).
    /// Пададзены шлях інтэрпрэтуецца ў залежнасці ад платформы падчас кампіляцыі.
    /// Так, напрыклад, выклік з шляхам Windows, які змяшчае зваротныя касыя рысы `\`, не будзе кампілявацца правільна на Unix.
    ///
    ///
    /// Гэты макрас дасць выраз тыпу `&'static str`, які з'яўляецца змесцівам файла.
    ///
    /// # Examples
    ///
    /// Дапусцім, у адным каталогу ёсць два файлы са наступным змесцівам:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Кампіляцыя 'main.rs' і запуск атрыманага двайковага файла вывядуць "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Уключае файл у якасці спасылкі на байтавы масіў.
    ///
    /// Файл размешчаны адносна бягучага файла (аналагічна таму, як знаходзяцца модулі).
    /// Пададзены шлях інтэрпрэтуецца ў залежнасці ад платформы падчас кампіляцыі.
    /// Так, напрыклад, выклік з шляхам Windows, які змяшчае зваротныя касыя рысы `\`, не будзе кампілявацца правільна на Unix.
    ///
    ///
    /// Гэты макрас дасць выраз тыпу `&'static [u8; N]`, які з'яўляецца змесцівам файла.
    ///
    /// # Examples
    ///
    /// Дапусцім, у адным каталогу ёсць два файлы са наступным змесцівам:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Кампіляцыя 'main.rs' і запуск атрыманага двайковага файла вывядуць "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Пашыраецца да радка, які ўяўляе бягучы шлях да модуля.
    ///
    /// Бягучы шлях да модуля можна разглядаць як іерархію модуляў, якія вядуць назад да crate root.
    /// Першым кампанентам вернутага шляху з'яўляецца імя crate, якое зараз кампілюецца.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Ацэньвае лагічныя камбінацыі сцягоў канфігурацыі падчас кампіляцыі.
    ///
    /// У дадатак да атрыбута `#[cfg]`, гэты макрас прадастаўляецца, каб дазволіць ацэнку лагічнага выразу сцягоў канфігурацыі.
    /// Гэта часта прыводзіць да менш прадубліраванага кода.
    ///
    /// Сінтаксіс, дадзены гэтаму макрасу, з'яўляецца такім жа сінтаксісам, як і атрыбут [`cfg`].
    ///
    /// `cfg!`, у адрозненне ад `#[cfg]`, не выдаляе ніякага кода і ацэньвае толькі як праўдзівае ці ілжывае.
    /// Напрыклад, усе блокі ў выразе if/else павінны быць сапраўднымі, калі для ўмовы выкарыстоўваецца `cfg!`, незалежна ад таго, што ацэньвае `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Аналізуе файл як выраз альбо элемент у адпаведнасці з кантэкстам.
    ///
    /// Файл размешчаны адносна бягучага файла (аналагічна таму, як знаходзяцца модулі).Пададзены шлях інтэрпрэтуецца ў залежнасці ад платформы падчас кампіляцыі.
    /// Так, напрыклад, выклік з шляхам Windows, які змяшчае зваротныя касыя рысы `\`, не будзе кампілявацца правільна на Unix.
    ///
    /// Выкарыстанне гэтага макраса часта бывае дрэннай ідэяй, таму што калі файл аналізуецца як выраз, ён будзе размешчаны ў навакольным кодзе негігіенічна.
    /// Гэта можа прывесці да таго, што зменныя або функцыі будуць адрознівацца ад таго, што чакае файл, калі ў бягучым файле ёсць пераменныя або функцыі, якія маюць аднолькавае імя.
    ///
    ///
    /// # Examples
    ///
    /// Дапусцім, у адным каталогу ёсць два файлы са наступным змесцівам:
    ///
    /// Файл 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Кампіляцыя 'main.rs' і запуск атрыманага двайковага файла вывядуць "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Сцвярджае, што лагічным выразам з'яўляецца `true` падчас выканання.
    ///
    /// Гэта выкліча макрас [`panic!`], калі прадастаўлены выраз не можа быць ацэнены ў `true` падчас выканання.
    ///
    /// # Uses
    ///
    /// Сцвярджэнні заўсёды правяраюцца ў зборках адладкі і выпуску, і іх нельга адключыць.
    /// Глядзіце [`debug_assert!`] для сцвярджэнняў, якія не ўключаны ў зборках версій па змаўчанні.
    ///
    /// Небяспечны код можа спадзявацца на `assert!` для забеспячэння выканання інварыянтаў часу выканання, якія ў выпадку парушэння могуць прывесці да небяспекі.
    ///
    /// Іншыя выпадкі выкарыстання `assert!` уключаюць тэставанне і прымяненне інварыянтаў часу выканання ў бяспечным кодзе (парушэнне якіх не можа прывесці да небяспекі).
    ///
    ///
    /// # Карыстальніцкія паведамленні
    ///
    /// Гэты макрас мае другую форму, дзе карыстацкае паведамленне panic можа быць прадастаўлена з аргументамі для фарматавання альбо без іх.
    /// Глядзіце [`std::fmt`] для сінтаксісу гэтай формы.
    /// Выразы, якія выкарыстоўваюцца ў якасці аргументаў фармату, будуць ацэньвацца толькі ў выпадку, калі сцвярджэнне не атрымаецца.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // паведамленне panic для гэтых сцвярджэнняў-гэта стрыфікаванае значэнне дадзенага выразу.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // вельмі простая функцыя
    ///
    /// assert!(some_computation());
    ///
    /// // сцвярджаць з дапамогай карыстацкага паведамлення
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Убудаваная зборка.
    ///
    /// Прачытайце [unstable book] для выкарыстання.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Убудаваная зборка ў стылі LLVM.
    ///
    /// Прачытайце [unstable book] для выкарыстання.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Убудаваная зборка на ўзроўні модуля.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Адбіткі перадавалі tokens у стандартную прадукцыю.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Уключае або адключае функцыі адсочвання, якія выкарыстоўваюцца для адладкі іншых макрасаў.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Атрыбут макраса, які выкарыстоўваецца для прымянення макрасаў.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Макрас атрыбута, ужыты да функцыі, каб ператварыць яе ў адзінкавы тэст.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Макрас атрыбута, ужыты да функцыі, каб ператварыць яе ў тэст эталону.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Дэталь рэалізацыі макрасаў `#[test]` і `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Макрас атрыбута, ужыты да статыкі, каб зарэгістраваць яго як глабальны размеркатар.
    ///
    /// Глядзіце таксама [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Захоўвае элемент, да якога ён прымяняецца, калі перададзены шлях даступны, і ў адваротным выпадку выдаляе яго.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Пашырае ўсе атрыбуты `#[cfg]` і `#[cfg_attr]` у фрагменце кода, да якога ён ужыты.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Нестабільная дэталь рэалізацыі кампілятара `rustc` не выкарыстоўваецца.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Нестабільная дэталь рэалізацыі кампілятара `rustc` не выкарыстоўваецца.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}