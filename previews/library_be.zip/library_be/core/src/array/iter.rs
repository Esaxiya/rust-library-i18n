//! Вызначае ітэратар для масіваў, які належыць `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Ітэратар [array] па значэнні.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Гэта масіў, які мы ітэруем.
    ///
    /// Элементы з індэксам `i`, дзе `alive.start <= i < alive.end` яшчэ не атрыманы, і з'яўляюцца сапраўднымі запісамі масіва.
    /// Элементы з індэксамі `i < alive.start` або `i >= alive.end` ужо атрыманы і больш не павінны быць даступныя!Гэтыя мёртвыя элементы могуць знаходзіцца нават у зусім неініцыялізаваным стане!
    ///
    ///
    /// Такім чынам, інварыянты:
    /// - `data[alive]` жывы (г.зн. утрымлівае сапраўдныя элементы)
    /// - `data[..alive.start]` і `data[alive.end..]` мёртвыя (г.зн. элементы ўжо прачытаны, і іх нельга больш чапаць!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Элементы ў `data`, якія яшчэ не атрыманы.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Стварае новы ітэратар для дадзенага `array`.
    ///
    /// *Заўвага*: гэты метад можа быць састарэлы ў future пасля [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Тып `value` тут `i32`, а не `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // БЯСПЕКА: трансмутацыя тут на самай справе бяспечная.Дакументы `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` гарантавана будзе мець аднолькавы памер і выраўноўванне
        // > як `T`.
        //
        // У дакументах нават паказана пераўтварэнне з масіва `MaybeUninit<T>` у масіў `T`.
        //
        //
        // Пры гэтым гэтая ініцыялізацыя задавальняе інварыянтам.

        // FIXME(LukasKalbertodt): на самай справе выкарыстоўвайце тут `mem::transmute`, як толькі ён працуе з агульнымі прэпаратамі const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Да гэтага часу мы можам выкарыстоўваць `mem::transmute_copy` для стварэння разраднай копіі іншага тыпу, а потым забыць `array`, каб ён не ўпаў.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Вяртае нязменны зрэз усіх элементаў, якія яшчэ не атрыманы.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // БЯСПЕКА: Мы ведаем, што ўсе элементы ў `alive` правільна ініцыялізаваны.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Вяртае зменлівы зрэз усіх элементаў, якія яшчэ не атрыманы.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // БЯСПЕКА: Мы ведаем, што ўсе элементы ў `alive` правільна ініцыялізаваны.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Атрымаць наступны паказальнік спераду.
        //
        // Павелічэнне `alive.start` на 1 падтрымлівае інварыянт адносна `alive`.
        // Аднак з-за гэтага змены на кароткі час зона жывых ужо не `data[alive]`, а `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Прачытайце элемент з масіва.
            // БЯСПЕКА: `idx`-гэта паказальнік былой вобласці "alive" рэгіёна
            // масіў.Чытанне гэтага элемента азначае, што `data[idx]` цяпер лічыцца мёртвым (гэта значыць не чапаць).
            // Паколькі `idx` быў пачаткам жывой зоны, цяпер жывая зона зноў `data[alive]`, аднаўляючы ўсе інварыянты.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Атрымаць наступны індэкс са спіны.
        //
        // Памяншэнне `alive.end` на 1 падтрымлівае інварыянт адносна `alive`.
        // Аднак з-за гэтага змены на кароткі час зона жывых ужо не `data[alive]`, а `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Прачытайце элемент з масіва.
            // БЯСПЕКА: `idx`-гэта паказальнік былой вобласці "alive" рэгіёна
            // масіў.Чытанне гэтага элемента азначае, што `data[idx]` цяпер лічыцца мёртвым (гэта значыць не чапаць).
            // Паколькі `idx` быў канцом жывой зоны, цяпер жывая зона зноў `data[alive]`, аднаўляючы ўсе інварыянты.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // БЯСПЕКА: Гэта бяспечна: `as_mut_slice` вяртае дакладна падраздзел
        // з элементаў, якія яшчэ не вынесены і якія яшчэ трэба выкінуць.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ніколі не пацячэ з-за інварыянта `жывы.старт <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Ітэратар сапраўды паведамляе правільную даўжыню.
// Колькасць элементаў "alive" (якія ўсё яшчэ будуць выдадзены)-гэта даўжыня дыяпазону `alive`.
// Даўжыня гэтага дыяпазону памяншаецца альбо ў `next`, альбо ў `next_back`.
// У гэтых метадах ён заўсёды памяншаецца на 1, але толькі ў выпадку вяртання `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Звярніце ўвагу, нам сапраўды не трэба супастаўляць сапраўды такі ж дыяпазон жывых, таму мы можам проста кланаваць у зрушэнне 0 незалежна ад таго, дзе знаходзіцца `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Клонуйце ўсе жывыя элементы.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Запішыце клон у новы масіў, а затым абнавіце яго жывы дыяпазон.
            // Пры кланаванні panics мы правільна выдалім папярэднія элементы.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Друкуйце толькі тыя элементы, якія яшчэ не былі выдадзены: мы больш не можам атрымаць доступ да атрыманых элементаў.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}