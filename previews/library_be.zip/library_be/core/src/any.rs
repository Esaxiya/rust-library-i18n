//! Гэты модуль рэалізуе `Any` Portrait, які дазваляе дынамічна набіраць тэкст любога тыпу `'static` праз адлюстраванне падчас выканання.
//!
//! `Any` сам па сабе можа быць выкарыстаны для атрымання `TypeId` і мае больш магчымасцей пры выкарыстанні ў якасці аб'екта Portrait.
//! Як `&dyn Any` (запазычаны аб'ект Portrait), ён мае метады `is` і `downcast_ref`, каб праверыць, ці змяшчаецца значэнне дадзенага тыпу, і атрымаць спасылку на ўнутранае значэнне як тып.
//! Як і `&mut dyn Any`, існуе таксама метад `downcast_mut` для атрымання зменнай спасылкі на ўнутранае значэнне.
//! `Box<dyn Any>` дадае метад `downcast`, які спрабуе пераўтварыць у `Box<T>`.
//! Падрабязную інфармацыю глядзіце ў дакументацыі [`Box`].
//!
//! Звярніце ўвагу, што `&dyn Any` абмежаваны тэставаннем таго, ці мае значэнне пэўны тып бетону, і не можа быць выкарыстаны для праверкі, ці рэалізуе тып Portrait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Разумныя паказальнікі і `dyn Any`
//!
//! Памятаць, калі вы выкарыстоўваеце `Any` у якасці аб'екта Portrait, асабліва з тыпамі `Box<dyn Any>` або `Arc<dyn Any>`,-гэта тое, што проста выклік `.type_id()` па значэнні стварае `TypeId` кантэйнера *, а не асноўнага аб'екта Portrait.
//!
//! Гэтага можна пазбегнуць, пераўтварыўшы разумны паказальнік у `&dyn Any`, які верне аб'ект `TypeId`.
//! Напрыклад:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Вы, хутчэй за ўсё, захочаце гэтага:
//! let actual_id = (&*boxed).type_id();
//! // ... чым гэта:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Разгледзім сітуацыю, калі мы хочам выйсці са значэння, якое перадаецца функцыі.
//! Мы ведаем значэнне, над якім працуем, рэалізуе Debug, але не ведаем яго канкрэтны тып.Мы хочам звярнуць асаблівую апрацоўку да пэўных тыпаў: у гэтым выпадку раздрукоўка даўжыні значэнняў радка да іх значэння.
//! Мы не ведаем канкрэтнага тыпу нашага значэння падчас кампіляцыі, таму нам трэба выкарыстоўваць адлюстраванне падчас выканання.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Функцыя рэгістратара для любога тыпу, які рэалізуе адладку.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Паспрабуйце пераўтварыць наша значэнне ў `String`.
//!     // У выпадку поспеху мы хочам вывесці даўжыню радка, а таксама яго значэнне.
//!     // Калі няма, гэта іншы тып: проста раздрукуйце яго без упрыгожванняў.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Гэтая функцыя хоча выйсці са свайго параметру перад пачаткам працы з ім.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... зрабіць іншую працу
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Любы Portrait
///////////////////////////////////////////////////////////////////////////////

/// Portrait для эмуляцыі дынамічнага набору тэксту.
///
/// Большасць тыпаў рэалізуе `Any`.Аднак любы тып, які змяшчае нестатычную спасылку, не мае.
/// Для больш падрабязнай інфармацыі глядзіце [module-level documentation][mod].
///
/// [mod]: crate::any
// Гэты Portrait не небяспечны, хаця мы абапіраемся на асаблівасці функцыі `type_id` яго адзінага impl у небяспечным кодзе (напрыклад, `downcast`).Звычайна гэта можа быць праблемай, але паколькі адзіным імпульсам `Any` з'яўляецца агульная рэалізацыя, ніякі іншы код не можа рэалізаваць `Any`.
//
// Мы маглі б зрабіць гэты Portrait небяспечным-гэта не прывяло б да паломкі, бо мы кантралюем усе рэалізацыі,-але мы вырашылі не рабіць гэтага, бо гэта і не вельмі неабходна, і можа збянтэжыць карыстальнікаў наконт адрознення небяспечных traits і небяспечных метадаў (г.зн. `type_id` па-ранейшаму будзе бяспечна патэлефанаваць, але мы, верагодна, хочам пазначыць як такі ў дакументацыі).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Атрымлівае `TypeId` з `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Метады пашырэння для любых аб'ектаў Portrait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Пераканайцеся, што вынік, напрыклад, злучэння ніткі можа быць надрукаваны і, такім чынам, выкарыстаны разам з `unwrap`.
// У канчатковым выніку можа больш не спатрэбіцца, калі адпраўка працуе з абнаўленнем.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Вяртае `true`, калі тыпаваны ў тыпах тып `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Атрымайце `TypeId` тыпу, з якім ствараецца гэтая функцыя.
        let t = TypeId::of::<T>();

        // Атрымайце `TypeId` тыпу ў аб'екце Portrait (`self`).
        let concrete = self.type_id();

        // Параўнайце абодва `TypeId` на роўнасці.
        t == concrete
    }

    /// Вяртае спасылку на ўстаўленае ў поле значэнне, калі яно тыпу `T`, альбо `None`, калі яно не.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // БЯСПЕКА: проста праверылі, ці паказваем мы правільны тып, і можам спадзявацца
            // праверыць бяспеку памяці, бо мы ўкаранілі Any для ўсіх тыпаў;ніякія іншыя імпульсы не могуць існаваць, паколькі яны супярэчылі б нашым імпульсам.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Вяртае некаторую зменлівую спасылку на ўстаўленае ў поле значэнне, калі яно тыпу `T`, альбо `None`, калі яно не з'яўляецца.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // БЯСПЕКА: проста праверылі, ці паказваем мы правільны тып, і можам спадзявацца
            // праверыць бяспеку памяці, бо мы ўкаранілі Any для ўсіх тыпаў;ніякія іншыя імпульсы не могуць існаваць, паколькі яны супярэчылі б нашым імпульсам.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Пераходзіць да метаду, вызначанага для тыпу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Пераходзіць да метаду, вызначанага для тыпу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Пераходзіць да метаду, вызначанага для тыпу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Пераходзіць да метаду, вызначанага для тыпу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Пераходзіць да метаду, вызначанага для тыпу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Пераходзіць да метаду, вызначанага для тыпу `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID і яго метады
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` уяўляе сабой унікальны ў свеце ідэнтыфікатар тыпу.
///
/// Кожны `TypeId`-гэта непразрысты аб'ект, які не дазваляе праверыць тое, што знаходзіцца ўнутры, але дазваляе асноўныя аперацыі, такія як кланаванне, параўнанне, друк і паказ.
///
///
/// У цяперашні час `TypeId` даступны толькі для тыпаў, якія адносяцца да `'static`, але гэта абмежаванне можа быць выдалена ў future.
///
/// У той час як `TypeId` рэалізуе `Hash`, `PartialOrd` і `Ord`, варта адзначыць, што хэшы і парадак будуць адрознівацца паміж выпускамі Rust.
/// Сцеражыцеся спадзявацца на іх унутры вашага кода!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Вяртае `TypeId` тыпу, з якім была створана гэтая агульная функцыя.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Вяртае імя тыпу ў выглядзе зрэзу радка.
///
/// # Note
///
/// Гэта прызначана для дыягнастычнага выкарыстання.
/// Дакладны змест і фармат вернутай радкі не ўказваюцца, акрамя як найбольш аптымальнага апісання тыпу.
/// Напрыклад, сярод радкоў, якія можа вярнуць `type_name::<Option<String>>()`, ёсць `"Option<String>"` і `"std::option::Option<std::string::String>"`.
///
///
/// Вяртаная радок не павінна разглядацца як унікальны ідэнтыфікатар тыпу, бо некалькі тыпаў могуць супадаць з адным і тым жа імем тыпу.
/// Аналагічна, няма гарантыі, што ўсе часткі тыпу з'явяцца ў вернутай радку: напрыклад, спецыфікатары жыцця ў цяперашні час не ўключаны.
/// Акрамя таго, выснова можа мяняцца паміж версіямі кампілятара.
///
/// Цяперашняя рэалізацыя выкарыстоўвае тую ж інфраструктуру, што і дыягностыка кампілятара і debuginfo, але гэта не гарантавана.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Вяртае імя тыпу паказанага значэння як зрэз радка.
/// Гэта тое самае, што і `type_name::<T>()`, але можа быць выкарыстана там, дзе тып зменнай недаступны.
///
/// # Note
///
/// Гэта прызначана для дыягнастычнага выкарыстання.Дакладны змест і фармат радка не ўказваюцца, акрамя як найбольш аптымальнага апісання тыпу.
/// Напрыклад, `type_name_of_val::<Option<String>>(None)` можа вярнуць `"Option<String>"` або `"std::option::Option<std::string::String>"`, але не `"foobar"`.
///
/// Акрамя таго, выснова можа мяняцца паміж версіямі кампілятара.
///
/// Гэтая функцыя не вырашае аб'екты Portrait, што азначае, што `type_name_of_val(&7u32 as &dyn Debug)` можа вярнуць `"dyn Debug"`, але не `"u32"`.
///
/// Імя тыпу не варта лічыць унікальным ідэнтыфікатарам тыпу;
/// некалькі тыпаў могуць мець адно і тое ж імя.
///
/// Цяперашняя рэалізацыя выкарыстоўвае тую ж інфраструктуру, што і дыягностыка кампілятара і debuginfo, але гэта не гарантавана.
///
/// # Examples
///
/// Друкуе па змаўчанні цэлае і плаваючае тыпы.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}