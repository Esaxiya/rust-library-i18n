//! Дэкадуе значэнне з плаваючай кропкай на асобныя часткі і дыяпазоны памылак.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Расшыфраванае беззнаковае канчатковае значэнне, такое, што:
///
/// - Зыходнае значэнне роўна `mant * 2^exp`.
///
/// - Любы лік ад `(mant - minus)*2^exp` да `(mant + plus)* 2^exp` будзе акругляцца да зыходнага значэння.
/// Дыяпазон уключаны толькі тады, калі `inclusive`-гэта `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Маштабаваная мантыса.
    pub mant: u64,
    /// Ніжні дыяпазон памылак.
    pub minus: u64,
    /// Верхні дыяпазон памылак.
    pub plus: u64,
    /// Агульны паказчык у аснове 2.
    pub exp: i16,
    /// Праўда, калі дыяпазон памылак уключаны.
    ///
    /// У IEEE 754 гэта дакладна, калі першапачатковая мантыса была цотнай.
    pub inclusive: bool,
}

/// Расшыфраванае значэнне без знака.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Бясконцасці, альбо станоўчыя, альбо адмоўныя.
    Infinite,
    /// Нуль, альбо станоўчы, альбо адмоўны.
    Zero,
    /// Канечныя лікі з дадатковымі расшыфраванымі палямі.
    Finite(Decoded),
}

/// Тып з плаваючай коскай, які можна `дэкадаваць`.
pub trait DecodableFloat: RawFloat + Copy {
    /// Мінімальнае дадатнае нармаванае значэнне.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Вяртае знак (ісціна пры адмоўным значэнні) і значэнне `FullDecoded` з дадзенага нумара з плаваючай кропкай.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // суседзі: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode заўсёды захоўвае паказчык ступені, таму мантыса маштабуецца на субнармальныя.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // суседзі: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // дзе maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // суседзі: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}