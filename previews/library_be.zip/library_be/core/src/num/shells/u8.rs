//! Канстанты для 8-бітнага цэлага тыпу без знака.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Новы код павінен выкарыстоўваць звязаныя канстанты непасрэдна для прымітыўнага тыпу.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }