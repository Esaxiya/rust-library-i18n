//! Праверка і разлажэнне дзесятковага радка выгляду:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Іншымі словамі, стандартны сінтаксіс з плаваючай кропкай, за двума выключэннямі: Без знака і без апрацоўкі "inf" і "NaN".Імі кіруе функцыя драйвера (super::dec2flt).
//!
//! Нягледзячы на тое, што распазнаць сапраўдныя ўводныя дадзеныя адносна проста, гэты модуль таксама павінен адхіліць незлічоныя несапраўдныя варыяцыі, ніколі не panic, і правесці шматлікія праверкі, на якія астатнія модулі абапіраюцца не на panic (альбо на перапаўненне).
//!
//! Што яшчэ горш, усё, што адбываецца за адзін праход па ўваходзе.
//! Такім чынам, будзьце асцярожныя, калі што-небудзь змяняеце, і пераправерце з іншымі модулямі.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Цікавыя часткі дзесятковай радкі.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Дзесятковы паказчык, гарантаваны менш за 18 дзесятковых лічбаў.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Правярае, ці з'яўляецца ўваходны радок сапраўдным нумарам з плаваючай кропкай, і калі так, знайдзіце ў ім інтэгральную частку, дробавую частку і паказчык ступені.
/// Не спраўляецца са знакамі.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Няма лічбаў да 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Нам патрабуецца як мінімум адназначная лічба да або пасля кропкі.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Адставанне ад смецця пасля дробавай часткі
            }
        }
        _ => Invalid, // Адставанне ад непатрэбнага пасля радка першай лічбы
    }
}

/// Выразае дзесятковыя лічбы да першага незнакавага знака.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Выманне экспанентаў і праверка памылак.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Адставанне ад смецця пасля экспанента
    }
    if number.is_empty() {
        return Invalid; // Пусты паказчык ступені
    }
    // На дадзены момант у нас, безумоўна, ёсць сапраўдны радок лічбаў.Гэта можа быць занадта доўга, каб змясціць у `i64`, але калі ён такі велізарны, уваход, безумоўна, роўны нулю альбо бясконцасці.
    // Паколькі кожны нуль у дзесятковых лічбах рэгулюе паказчык толькі на +/-1, пры exp=10 ^ 18 увод павінен складаць 17 экзабайтаў (!) нулёў, каб нават аддалена наблізіцца да канчатковага.
    //
    // Гэта не зусім той варыянт выкарыстання, які нам трэба задаволіць.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}