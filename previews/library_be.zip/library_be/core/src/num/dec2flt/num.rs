//! Карысныя функцыі для bignum, якія не маюць вялікага сэнсу ператварацца ў метады.

// FIXME Назва гэтага модуля крыху прыкрая, бо іншыя модулі таксама імпартуюць `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Праверце, ці скарачае ўсе біты, менш значныя, чым `ones_place`, адносную хібнасць, меншую, роўную ці большую, чым 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Калі ўсе астатнія біты роўныя нулю, гэта= 0.5 ULP, у адваротным выпадку> 0.5 Калі больш няма бітаў (half_bit==0), ніжэй таксама правільна вяртаецца Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Пераўтварае радок ASCII, які змяшчае толькі дзесятковыя лічбы, у `u64`.
///
/// Не выконвае праверкі на наяўнасць перапаўнення або няправільных знакаў, таму, калі абанент не быў асцярожны, вынік з'яўляецца ілжывым і можа panic (праўда, гэта не будзе `unsafe`).
/// Акрамя таго, пустыя радкі разглядаюцца як нуль.
/// Гэтая функцыя існуе таму, што
///
/// 1. выкарыстанне `FromStr` на `&[u8]` патрабуе `from_utf8_unchecked`, што дрэнна, і
/// 2. Складанне вынікаў `integral.parse()` і `fractional.parse()` складаней, чым уся гэтая функцыя.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Пераўтварае радок ASCII лічбаў у bignum.
///
/// Як і `from_str_unchecked`, гэтая функцыя абапіраецца на сінтаксічны аналізатар, каб адсеяць незначныя лічбы.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Разгарнуць bignum у 64-бітнае цэлае лік.Panics, калі колькасць занадта вялікая.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Вылучае шэраг бітаў.

/// Індэкс 0-найменш значны біт, а дыяпазон напаўадкрыты, як звычайна.
/// Panics, калі папросяць выняць больш бітаў, чым упісана ў тып вяртання.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}