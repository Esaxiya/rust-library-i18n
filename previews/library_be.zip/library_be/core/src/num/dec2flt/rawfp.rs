//! Біт важдаецца на станоўчых плавальных паплавах IEEE 754.Адмоўныя лічбы не апрацоўваюцца і не патрабуюцца.
//! Нармальныя нумары з плаваючай кропкай маюць кананічнае ўяўленне як (frac, exp), так што значэнне роўна 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), дзе N-колькасць бітаў.
//!
//! Субнармальныя прыкметы некалькі адрозніваюцца і дзіўныя, але дзейнічае той самы прынцып.
//!
//! Аднак тут мы прадстаўляем іх як (sig, k) з f дадатным, такім чынам, што значэнне роўна f *
//! 2 <sup>е</sup> .Акрамя таго, што "hidden bit" відавочны, гэта змяняе паказчык ступені так званага зруху мантысы.
//!
//! Іншымі словамі, звычайна паплаўкі запісваюцца як (1), але тут яны пішуцца як (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Мы называем (1)**дробавым прадстаўленнем**, а (2)**інтэгральным прадстаўленнем**.
//!
//! Многія функцыі ў гэтым модулі апрацоўваюць толькі звычайныя лічбы.Працэдуры dec2flt кансерватыўна ідуць на ўніверсальна правільны павольны шлях (алгарытм М) для вельмі малых і вельмі вялікіх лікаў.
//! Для гэтага алгарытму патрэбны толькі next_float(), які апрацоўвае субнармальныя значэнні і нулі.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Памочнік Portrait, каб пазбегнуць дубліравання ў асноўным усіх кодаў пераўтварэнняў для `f32` і `f64`.
///
/// Паглядзіце, чаму гэта неабходна, у каментарыі да бацькоўскага модуля.
///
/// Павінна быць **ніколі ніколі** рэалізавана для іншых тыпаў альбо выкарыстоўвацца па-за модулем dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Тып, які выкарыстоўваецца `to_bits` і `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Выконвае сырую трансмутацыю ў цэлае лік.
    fn to_bits(self) -> Self::Bits;

    /// Выконвае сырую трансмутацыю з цэлага ліку.
    fn from_bits(v: Self::Bits) -> Self;

    /// Вяртае катэгорыю, у якую ўваходзіць гэты лік.
    fn classify(self) -> FpCategory;

    /// Вяртае мантысу, экспанент і знак у выглядзе цэлых лікаў.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Расшыфроўвае паплавок.
    fn unpack(self) -> Unpacked;

    /// Адліўкі з невялікага цэлага ліку, якое можа быць дакладна прадстаўлена.
    /// Panic, калі цэлае лік немагчыма прадставіць, астатні код гэтага модуля пераконвае ніколі не дапускаць гэтага.
    fn from_int(x: u64) -> Self;

    /// Атрымлівае значэнне 10 <sup>e</sup> з загадзя вылічанай табліцы.
    /// Panics для `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Пра што кажа назва.
    /// Гэта лягчэй для жорсткага кода, чым жангліраванне ўнутранымі характарыстыкамі і спадзяванне, што канстанта LLVM згортвае яго.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Кансерватыўная прывязка да дзесятковых лічбаў уваходных дадзеных, якія не могуць выклікаць перапаўненне альбо нуль альбо
    /// субнармальныя.Магчыма, дзесятковы паказчык максімальнага нармальнага значэння, адсюль і назва.
    const MAX_NORMAL_DIGITS: usize;

    /// Калі найбольш значная дзесятковая лічба мае значэнне месца большае за гэта, лік напэўна акругляецца да бясконцасці.
    ///
    const INF_CUTOFF: i64;

    /// Калі найбольш значная дзесятковая лічба мае значэнне месца менш за гэта, лік напэўна акругляецца да нуля.
    ///
    const ZERO_CUTOFF: i64;

    /// Колькасць бітаў у ступені.
    const EXP_BITS: u8;

    /// Колькасць бітаў у значэнні і *, уключаючы* схаваны біт.
    const SIG_BITS: u8;

    /// Колькасць бітаў у значэнні і *без уліку* схаванага біта.
    const EXPLICIT_SIG_BITS: u8;

    /// Максімальны юрыдычны паказчык дробавага прадстаўлення.
    const MAX_EXP: i16;

    /// Мінімальны юрыдычны паказчык дробавага ўяўлення, за выключэннем субнармальных.
    const MIN_EXP: i16;

    /// `MAX_EXP` для інтэгральнага ўяўлення, т. е. з ужытым зрухам.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` кадуецца (г.зн. са зрушэннем зрушэння)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` для інтэгральнага ўяўлення, т. е. з ужытым зрухам.
    const MIN_EXP_INT: i16;

    /// Максімальна нармаванае значэннеі ў інтэгральным прадстаўленні.
    const MAX_SIG: u64;

    /// Мінімальнае нармаванае значэннеі ў інтэгральным прадстаўленні.
    const MIN_SIG: u64;
}

// У асноўным абыходны шлях для #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Вяртае мантысу, экспанент і знак у выглядзе цэлых лікаў.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Экспанентны зрушэнне + мантысавы зрух
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe не ўпэўнены, ці правільна абыходзіцца `as` на ўсіх платформах.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Вяртае мантысу, экспанент і знак у выглядзе цэлых лікаў.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Экспанентны зрушэнне + мантысавы зрух
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe не ўпэўнены, ці правільна абыходзіцца `as` на ўсіх платформах.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Пераўтварае `Fp` у найбліжэйшы тып машыннага паплаўка.
/// Не працуе з ненармальнымі вынікамі.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f складае 64 біт, таму xe мае мантысавы зрух 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Акругліце 64-бітнае значэнне да бітаў T::SIG_BITS з паловай да цотных.
/// Не спраўляецца з перапаўненнем экспанентаў.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Адрэгулюйце зрух мантысы
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Інверсія `RawFloat::unpack()` для нармаваных лікаў.
/// Panics, калі значэнне або паказчык не дзейнічаюць для нармаваных лікаў.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Выдаліце схаваны біт
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Адрэгулюйце паказчык ступені для зрушэння паказчыка і зруху мантысы
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Пакіньце знакавы біт пры 0 ("+"), усе нашы лічбы станоўчыя
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Пабудаваць субнармальнае.Мантыса 0 дапускаецца і будуе нуль.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Зашыфраваны паказчык роўны 0, знакавы біт-0, таму нам проста трэба пераасэнсаваць біты.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Прыблізна bignum з Fp.Акругляе ў межах UL00 0.5 з паловай да цотнай.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Мы адрэзалі ўсе біты да індэкса `start`, гэта значыць, мы фактычна зрушылі направа на велічыню `start`, таму гэта таксама патрэбны паказчык.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Круглы (half-to-even) у залежнасці ад усечаных біт.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Знаходзіць найбольшы лік з плаваючай коскай, строга меншы за аргумент.
/// Не апрацоўвае субнармальныя, нулявыя або павышаныя паказчыкі.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Знайдзіце найменшы лік з плаваючай кропкай, строга большы за аргумент.
// Гэтая аперацыя насычае, т. Е. next_float(inf) ==інф.
// У адрозненне ад большасці кода ў гэтым модулі, гэтая функцыя апрацоўвае нуль, субнармальныя і бясконцасці.
// Аднак, як і ўсе астатнія коды, ён не мае справы з NaN і адмоўнымі лікамі.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Здаецца, гэта занадта добра, каб быць праўдай, але гэта працуе.
        // 0.0 кадуецца як нулявое слова.Субнармальныя значэнні складаюць 0x000m ... m, дзе m-мантыса.
        // У прыватнасці, найменшая субнармальная-0x0 ... 01, а самая вялікая-0x000F ... F.
        // Найменшае нармальнае лік-0x0010 ... 0, таму працуе і гэты вуглавы корпус.
        // Калі прырашчэнне перапаўняе мантысу, біт пераносу павялічвае паказчык ступені, як мы хочам, і біты мантысы становяцца нулявымі.
        // З-за схаванай згоды біт, гэта таксама тое, што мы хочам!
        // Нарэшце, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}