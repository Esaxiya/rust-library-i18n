//! Тыпы памылак для пераўтварэння ў інтэгральныя тыпы.

use crate::convert::Infallible;
use crate::fmt;

/// Тып памылкі вяртаецца, калі праверанае пераўтварэнне інтэгральнага тыпу не ўдаецца.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Супадзенні, а не прымус, каб пераканацца, што код, як `From<Infallible> for TryFromIntError` вышэй, будзе працягваць працаваць, калі `Infallible` стане псеўданімам `!`.
        //
        //
        match never {}
    }
}

/// Памылка, якую можна вярнуць пры разборы цэлага ліку.
///
/// Гэтая памылка выкарыстоўваецца ў якасці тыпу памылкі для функцый `from_str_radix()` для прымітыўных цэлых тыпаў, такіх як [`i8::from_str_radix`].
///
/// # Патэнцыйныя прычыны
///
/// Сярод іншых прычын `ParseIntError` можа быць кінуты з-за прабелу ў радку, які стаіць заднім або канчатковым, напрыклад, калі ён атрыманы са стандартнага ўводу.
///
/// Выкарыстанне метаду [`str::trim()`] гарантуе, што перад разборам не застанецца прабелаў.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum для захоўвання розных тыпаў памылак, якія могуць прывесці да збою разбору цэлага ліку.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Значэнне, якое аналізуецца, пустае.
    ///
    /// Сярод іншых прычын, гэты варыянт будзе пабудаваны пры разборы пустога радка.
    Empty,
    /// Змяшчае недапушчальную лічбу ў сваім кантэксце.
    ///
    /// Сярод іншых прычын, гэты варыянт будзе пабудаваны пры разборы радка, які змяшчае не-ASCII-сімвал.
    ///
    /// Гэты варыянт таксама ствараецца, калі `+` або `-` недарэчна размяшчаецца ў радку альбо самастойна, альбо ў сярэдзіне ліку.
    ///
    ///
    InvalidDigit,
    /// Цэлае лік занадта вялікі для захавання ў мэтавым цэласным тыпе.
    PosOverflow,
    /// Цэлае лік занадта малы для захавання ў мэтавым цэласным тыпе.
    NegOverflow,
    /// Значэнне было нулявым
    ///
    /// Гэты варыянт будзе выдадзены, калі радок разбору мае нулявое значэнне, што будзе незаконным для ненулявых тыпаў.
    ///
    Zero,
}

impl ParseIntError {
    /// Выводзіць падрабязную прычыну разбору цэлага ліку.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}