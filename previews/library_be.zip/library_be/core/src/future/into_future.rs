use crate::future::Future;

/// Пераўтварэнне ў `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Вынікі, якія future выдасць па завяршэнні.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// У які future мы ператвараем гэта?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Стварае future са значэння.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}