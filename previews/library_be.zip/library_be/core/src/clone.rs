//! `Clone` Portrait для тыпаў, якія немагчыма "імпліцытна скапіяваць".
//!
//! У Rust некаторыя простыя тыпы-гэта "implicitly copyable", і калі вы прызначаеце іх альбо перадаеце ў якасці аргументаў, атрымальнік атрымае копію, пакінуўшы арыгінальнае значэнне на месцы.
//! Гэтыя тыпы не патрабуюць выдзялення для капіравання і не маюць фіналізатараў (г.зн. яны не ўтрымліваюць уласных скрынак альбо рэалізуюць [`Drop`]), таму кампілятар лічыць іх таннымі і бяспечнымі для капіравання.
//!
//! Для астатніх тыпаў копіі павінны быць зроблены відавочна, згодна з прынцыпам рэалізацыі [`Clone`] Portrait і выклікам метаду [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Прыклад асноўнага выкарыстання:
//!
//! ```
//! let s = String::new(); // Радок тыпу рэалізуе Clone
//! let copy = s.clone(); // каб мы маглі яго кланаваць
//! ```
//!
//! Каб лёгка рэалізаваць Clone Portrait, вы таксама можаце выкарыстоўваць `#[derive(Clone)]`.Прыклад:
//!
//! ```
//! #[derive(Clone)] // мы дадаем клон Portrait да структуры Марфея
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // і зараз мы можам яго кланаваць!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Звычайны Portrait для магчымасці відавочнага дубліравання аб'екта.
///
/// Адрозніваецца ад [`Copy`] тым, што [`Copy`] няяўна і вельмі нядорага, у той час як `Clone` заўсёды відавочны і можа быць, а можа і не быць дарагім.
/// Для таго, каб забяспечыць гэтыя характарыстыкі, Rust не дазваляе пераабсталяваць [`Copy`], але вы можаце змяніць `Clone` і запусціць адвольны код.
///
/// Паколькі `Clone` з'яўляецца больш агульным, чым [`Copy`], вы можаце аўтаматычна зрабіць што заўгодна [`Copy`] таксама `Clone`.
///
/// ## Derivable
///
/// Гэты Portrait можна выкарыстоўваць з `#[derive]`, калі ўсе палі `Clone`.Рэалізацыя "вывесці" [`Clone`] выклікае [`clone`] на кожным полі.
///
/// [`clone`]: Clone::clone
///
/// Для агульнай структуры `#[derive]` рэалізуе `Clone` ўмоўна, дадаўшы звязаны `Clone` на агульныя параметры.
///
/// ```
/// // `derive` рэалізуе Clone for Reading<T>калі Т-Клон.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Як я магу рэалізаваць `Clone`?
///
/// Тыпы [`Copy`] павінны мець трывіяльную рэалізацыю `Clone`.Больш фармальна:
/// калі `T: Copy`, `x: T` і `y: &T`, то `let x = y.clone();` эквівалентна `let x = *y;`.
/// Ручныя рэалізацыі павінны быць асцярожнымі, каб падтрымліваць гэты інварыянт;аднак небяспечны код не павінен спадзявацца на яго для забеспячэння бяспекі памяці.
///
/// Прыкладам можа служыць агульная структура, якая ўтрымлівае паказальнік на функцыю.У гэтым выпадку рэалізацыю `Clone` нельга `вывесці`, але можна рэалізаваць як:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Дадатковыя рэалізатары
///
/// У дадатак да [implementors listed below][impls], наступныя тыпы таксама рэалізуюць `Clone`:
///
/// * Тыпы элементаў функцый (г.зн. розныя тыпы, вызначаныя для кожнай функцыі)
/// * Тыпы паказальнікаў функцый (напрыклад, `fn() -> i32`)
/// * Тыпы масіваў для ўсіх памераў, калі тып элемента таксама рэалізуе `Clone` (напрыклад, `[i32; 123456]`)
/// * Тыпы набораў, калі кожны кампанент таксама рэалізуе `Clone` (напрыклад, `()`, `(i32, bool)`)
/// * Тыпы закрыцця, калі яны не адлюстроўваюць ніякай каштоўнасці з навакольнага асяроддзя або калі ўсе такія захопленыя значэнні рэалізуюць `Clone` самі.
///   Звярніце ўвагу, што пераменныя, узятыя агульнай спасылкай, заўсёды рэалізуюць `Clone` (нават калі рэферэнт гэтага не робіць), у той час як зменныя, улічаныя зменнай спасылкай, ніколі не рэалізуюць `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Вяртае копію значэння.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str рэалізуе Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Выконвае прызначэнне капіравання з `source`.
    ///
    /// `a.clone_from(&b)` па функцыянальнасці эквівалентна `a = b.clone()`, але яго можна перавызначыць для паўторнага выкарыстання рэсурсаў `a`, каб пазбегнуць непатрэбных размеркаванняў.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Выведзіце макрас, які генеруе impl з Portrait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): гэтыя структуры выкарыстоўваюцца выключна#[derive], каб сцвярджаць, што кожны кампанент тыпу рэалізуе Clone або Copy.
//
//
// Гэтыя структуры ніколі не павінны з'яўляцца ў кодзе карыстальніка.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Рэалізацыі `Clone` для прымітыўных тыпаў.
///
/// Рэалізацыі, якія не могуць быць апісаны ў Rust, рэалізаваны ў `traits::SelectionContext::copy_clone_conditions()` у `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Агульныя спасылкі можна кланаваць, але змяняныя спасылкі *не могуць*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Агульныя спасылкі можна кланаваць, але змяняныя спасылкі *не могуць*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}