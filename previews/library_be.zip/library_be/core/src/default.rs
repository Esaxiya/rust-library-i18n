//! `Default` Portrait для тыпаў, якія могуць мець значныя значэнні па змаўчанні.

#![stable(feature = "rust1", since = "1.0.0")]

/// Portrait для надання тыпу карыснага значэння па змаўчанні.
///
/// Часам вам хочацца вярнуцца да нейкага значэння па змаўчанні, і вам асабліва ўсё роўна, што гэта такое.
/// Гэта часта ўзнікае са `структурамі, якія вызначаюць набор опцый:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Як мы можам вызначыць некаторыя значэнні па змаўчанні?Вы можаце выкарыстоўваць `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Цяпер вы атрымліваеце ўсе значэнні па змаўчанні.Rust рэалізуе `Default` для розных тыпаў прымітываў.
///
/// Калі вы хочаце адмяніць пэўны параметр, але захаваць іншыя па змаўчанні:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Гэты Portrait можна выкарыстоўваць з `#[derive]`, калі ўсе палі тыпу рэалізуюць `Default`.
/// Калі `derive`d, ён будзе выкарыстоўваць значэнне па змаўчанні для тыпу кожнага поля.
///
/// ## Як я магу рэалізаваць `Default`?
///
/// Забяспечце рэалізацыю для метаду `default()`, якая вяртае значэнне вашага тыпу, якое павінна быць па змаўчанні:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Вяртае "default value" для тыпу.
    ///
    /// Значэнні па змаўчанні часта ўяўляюць сабой нейкае пачатковае значэнне, значэнне ідэнтычнасці альбо што-небудзь яшчэ, што можа мець сэнс па змаўчанні.
    ///
    ///
    /// # Examples
    ///
    /// Выкарыстанне ўбудаваных значэнняў па змаўчанні:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Стварэнне ўласнага:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Вяртае значэнне па змаўчанні для тыпу ў адпаведнасці з `Default` Portrait.
///
/// Тып, які трэба вярнуць, выводзіцца з кантэксту;гэта эквівалентна `Default::default()`, але карацей для друку.
///
/// Напрыклад:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Выведзіце макрас, які генеруе impl з Portrait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }