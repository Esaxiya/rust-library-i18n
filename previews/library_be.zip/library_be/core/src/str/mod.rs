//! Маніпуляцыі са струнамі.
//!
//! Для больш падрабязнай інфармацыі глядзіце модуль [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. па-за межамі
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. пачатак <=канец
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. мяжа сімвала
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // знайсці персанажа
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` павінна быць менш за лен і мяжу знака
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Вяртае даўжыню `self`.
    ///
    /// Гэта даўжыня ў байтах, а не [`char`] і графемах.
    /// Іншымі словамі, гэта можа быць не тое, што чалавек лічыць даўжынёй струны.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // фантазія!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Вяртае `true`, калі даўжыня `self` складае нуль байтаў.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Правярае, што `index`-ы байт-гэта першы байт у паслядоўнасці кодавага кода UTF-8 альбо канец радка.
    ///
    ///
    /// Пачатак і канец радка (калі `index== self.len()`) лічацца межамі.
    ///
    /// Вяртае `false`, калі `index` больш, чым `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // пачатак `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // другі байт `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // трэці байт `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 і len-гэта заўсёды нармальна.
        // Праверце дакладнасць 0, каб можна было лёгка аптымізаваць чэк і прапусціць чытанне радкавых дадзеных для гэтага выпадку.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Гэта бітавая магія, эквівалентная: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Пераўтварае зрэз радка ў зрэз байта.
    /// Каб пераўтварыць зрэз байта назад у зрэз радка, выкарыстоўвайце функцыю [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // БЯСПЕКА: const гук, таму што мы трансмутуем два тыпы з аднолькавым макетам
        unsafe { mem::transmute(self) }
    }

    /// Пераўтварае зменлівы зрэз радка ў зменлівы зрэз байта.
    ///
    /// # Safety
    ///
    /// Абанент павінен пераканацца, што змест зрэзу сапраўдны UTF-8, перш чым пазыка скончыцца і будзе выкарыстаны асноўны `str`.
    ///
    ///
    /// Выкарыстанне `str`, змест якога не з'яўляецца сапраўдным UTF-8, не вызначана.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // БЯСПЕКА: склад з `&str` па `&[u8]` бяспечны з `str`
        // мае такую ж кампаноўку, як `&[u8]` (толькі libstd можа даць гэтую гарантыю).
        // Размежаванне паказальніка бяспечна, бо яно паходзіць ад зменнай спасылкі, якая гарантавана будзе сапраўднай для запісаў.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Пераўтварае зрэз радка ў неапрацаваны паказальнік.
    ///
    /// Паколькі зрэзы радкоў з'яўляюцца зрэзамі байтаў, неапрацаваны паказальнік паказвае на [`u8`].
    /// Гэты паказальнік будзе паказваць на першы байт зрэзу радка.
    ///
    /// Абанент павінен пераканацца, што зваротны паказальнік ніколі не запісваецца.
    /// Калі вам трэба змяніць змесціва зрэзу радка, выкарыстоўвайце [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Пераўтварае зменлівы зрэз радка ў неапрацаваны паказальнік.
    ///
    /// Паколькі зрэзы радкоў з'яўляюцца зрэзамі байтаў, неапрацаваны паказальнік паказвае на [`u8`].
    /// Гэты паказальнік будзе паказваць на першы байт зрэзу радка.
    ///
    /// Ваша адказнасць заключаецца ў тым, каб зрэз радка быў зменены толькі такім чынам, каб ён заставаўся сапраўдным UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Вяртае падраздзел `str`.
    ///
    /// Гэта не панічная альтэрнатыва індэксацыі `str`.
    /// Вяртае [`None`] кожны раз, калі эквівалентная аперацыя індэксацыі будзе panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // індэксы не на межах паслядоўнасці UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // па-за межамі
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Вяртае зменлівы падразак `str`.
    ///
    /// Гэта не панічная альтэрнатыва індэксацыі `str`.
    /// Вяртае [`None`] кожны раз, калі эквівалентная аперацыя індэксацыі будзе panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // правільная даўжыня
    /// assert!(v.get_mut(0..5).is_some());
    /// // па-за межамі
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Вяртае неправераны падраздзел `str`.
    ///
    /// Гэта неправераная альтэрнатыва індэксацыі `str`.
    ///
    /// # Safety
    ///
    /// Выклічнікі гэтай функцыі нясуць адказнасць за выкананне гэтых перадумоў:
    ///
    /// * Пачатковы індэкс не павінен перавышаць канчатковы індэкс;
    /// * Індэксы павінны знаходзіцца ў межах арыгінальнага зрэзу;
    /// * Індэксы павінны ляжаць на межах паслядоўнасці UTF-8.
    ///
    /// У адваротным выпадку вернуты зрэз радка можа спасылацца на недапушчальную памяць альбо парушаць інварыянты, паведамленыя тыпам `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked`;
        // фрагмент не паддаецца спасылцы, таму што `self` з'яўляецца бяспечнай спасылкай.
        // Вяртаецца паказальнік бяспечны, таму што імпульсы `SliceIndex` павінны гарантаваць, што ён ёсць.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Вяртае зменлівы, неправераны падраздзел `str`.
    ///
    /// Гэта неправераная альтэрнатыва індэксацыі `str`.
    ///
    /// # Safety
    ///
    /// Выклічнікі гэтай функцыі нясуць адказнасць за выкананне гэтых перадумоў:
    ///
    /// * Пачатковы індэкс не павінен перавышаць канчатковы індэкс;
    /// * Індэксы павінны знаходзіцца ў межах арыгінальнага зрэзу;
    /// * Індэксы павінны ляжаць на межах паслядоўнасці UTF-8.
    ///
    /// У адваротным выпадку вернуты зрэз радка можа спасылацца на недапушчальную памяць альбо парушаць інварыянты, паведамленыя тыпам `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked_mut`;
        // фрагмент не паддаецца спасылцы, таму што `self` з'яўляецца бяспечнай спасылкай.
        // Вяртаецца паказальнік бяспечны, таму што імпульсы `SliceIndex` павінны гарантаваць, што ён ёсць.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Стварае зрэз радка з іншага зрэзу радка, абыходзячы праверкі бяспекі.
    ///
    /// Звычайна гэта не рэкамендуецца, выкарыстоўвайце асцярожна!Для бяспечнай альтэрнатывы глядзіце [`str`] і [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Гэты новы зрэз ідзе з `begin` на `end`, уключаючы `begin`, але без `end`.
    ///
    /// Каб замест гэтага атрымаць зменлівы зрэз радка, гл. Метад [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Выклічнікі гэтай функцыі нясуць адказнасць за выкананне трох перадумоў:
    ///
    /// * `begin` не павінна перавышаць `end`.
    /// * `begin` і `end` павінны быць пазіцыямі байтаў у разрэзе радка.
    /// * `begin` і `end` павінны ляжаць на межах паслядоўнасці UTF-8.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked`;
        // фрагмент не паддаецца спасылцы, таму што `self` з'яўляецца бяспечнай спасылкай.
        // Вяртаецца паказальнік бяспечны, таму што імпульсы `SliceIndex` павінны гарантаваць, што ён ёсць.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Стварае зрэз радка з іншага зрэзу радка, абыходзячы праверкі бяспекі.
    /// Звычайна гэта не рэкамендуецца, выкарыстоўвайце асцярожна!Для бяспечнай альтэрнатывы глядзіце [`str`] і [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Гэты новы зрэз ідзе з `begin` на `end`, уключаючы `begin`, але без `end`.
    ///
    /// Каб атрымаць нязменны зрэз радка замест гэтага, гл. Метад [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Выклічнікі гэтай функцыі нясуць адказнасць за выкананне трох перадумоў:
    ///
    /// * `begin` не павінна перавышаць `end`.
    /// * `begin` і `end` павінны быць пазіцыямі байтаў у разрэзе радка.
    /// * `begin` і `end` павінны ляжаць на межах паслядоўнасці UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked_mut`;
        // фрагмент не паддаецца спасылцы, таму што `self` з'яўляецца бяспечнай спасылкай.
        // Вяртаецца паказальнік бяспечны, таму што імпульсы `SliceIndex` павінны гарантаваць, што ён ёсць.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Падзяліце адзін зрэз радка на два па індэксе.
    ///
    /// Аргумент, `mid`, павінен быць зрушэннем байта з пачатку радка.
    /// Ён таксама павінен знаходзіцца на мяжы кодавага пункта UTF-8.
    ///
    /// Два зрэзы, якія вяртаюцца, ідуць ад пачатку зрэзу радка да `mid` і ад `mid` да канца зрэзу радка.
    ///
    /// Каб замест гэтага атрымаць зменлівыя зрэзы радкоў, гл. Метад [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, калі `mid` не знаходзіцца на мяжы кодавага пункта UTF-8, альбо калі ён прайшоў канец апошняга кодавага пункта зрэзу радка.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary правярае, што індэкс знаходзіцца ў [0, .len()]
        if self.is_char_boundary(mid) {
            // БЯСПЕКА: толькі што праверыў, што `mid` знаходзіцца на мяжы знакаў.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Падзяліце адзін зменлівы зрэз радка на два па індэксе.
    ///
    /// Аргумент, `mid`, павінен быць зрушэннем байта з пачатку радка.
    /// Ён таксама павінен знаходзіцца на мяжы кодавага пункта UTF-8.
    ///
    /// Два зрэзы, якія вяртаюцца, ідуць ад пачатку зрэзу радка да `mid` і ад `mid` да канца зрэзу радка.
    ///
    /// Каб атрымаць нязменныя зрэзы радкоў замест гэтага, глядзіце метад [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, калі `mid` не знаходзіцца на мяжы кодавага пункта UTF-8, альбо калі ён прайшоў канец апошняга кодавага пункта зрэзу радка.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary правярае, што індэкс знаходзіцца ў [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // БЯСПЕКА: толькі што праверыў, што `mid` знаходзіцца на мяжы знакаў.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Вяртае ітэратар над [`char`] s зрэзу радка.
    ///
    /// Паколькі зрэз радка складаецца з сапраўднага UTF-8, мы можам перабіраць зрэз радка па [`char`].
    /// Гэты метад вяртае такі ітэратар.
    ///
    /// Важна памятаць, што [`char`] ўяўляе скалярную каштоўнасць Unicode, і, магчыма, не адпавядае вашаму ўяўленню пра тое, што такое 'character'.
    ///
    /// Ітэрацыя над графемнымі кластарамі можа быць тым, што вы на самой справе хочаце.
    /// Гэтая функцыянальнасць не прадастаўляецца ў стандартнай бібліятэцы Rust. Праверце замест гэтага crates.io.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Памятайце, што "`char`] можа не адпавядаць вашай інтуіцыі адносна персанажаў:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // не 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Вяртае ітэратар над [`char`] s зрэзу радка і іх пазіцыі.
    ///
    /// Паколькі зрэз радка складаецца з сапраўднага UTF-8, мы можам перабіраць зрэз радка па [`char`].
    /// Гэты метад вяртае ітэратар як гэтых [`char`], так і іх байт-пазіцыі.
    ///
    /// Ітэратар дае кортежи.Першае месца, [`char`]-другое.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Памятайце, што "`char`] можа не адпавядаць вашай інтуіцыі адносна персанажаў:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // не (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // звярніце ўвагу на 3 тут, апошні сімвал заняў два байты
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Ітэратар над байтамі зрэзу радка.
    ///
    /// Паколькі зрэз радка складаецца з паслядоўнасці байтаў, мы можам перабіраць зрэз радка па байтах.
    /// Гэты метад вяртае такі ітэратар.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Разбівае зрэз радка прабелам.
    ///
    /// Вяртаецца ітэратар верне зрэзы радкоў, якія з'яўляюцца падразрэзамі зыходнага зрэзу радкоў, падзеленыя любой колькасцю прабелаў.
    ///
    ///
    /// 'Whitespace' вызначаецца ў адпаведнасці з умовамі асноўнага ўласцівасці `White_Space`, атрыманага Unicode.
    /// Калі вы хочаце падзяліць толькі прабелы ASCII, выкарыстоўвайце [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Улічваюцца ўсе віды прабелаў:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Разбівае зрэз радка прабелам ASCII.
    ///
    /// Вяртаецца ітэратар верне зрэзы радкоў, якія з'яўляюцца падразрэзамі зыходнага зрэзу радкоў, падзеленыя любой колькасцю прабелаў ASCII.
    ///
    ///
    /// Каб падзяліць Unicode `Whitespace`, выкарыстоўвайце [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Улічваюцца ўсе віды прабелаў ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ітэратар па радках радка ў выглядзе зрэзаў радкоў.
    ///
    /// Радкі заканчваюцца альбо новым радком (`\n`), альбо зваротам карэткі з падачай радка (`\r\n`).
    ///
    /// Канчатковы радок не з'яўляецца абавязковым.
    /// Радок, які заканчваецца канчатковым радком, верне тыя ж радкі, што і інакш ідэнтычны радок без канчатковага радка.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Канчатковае заканчэнне радка не патрабуецца:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Ітэратар па радках радка.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Вяртае ітэратар `u16` па радку, закадаванаму як UTF-16.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Вяртае `true`, калі дадзены ўзор адпавядае падразрэзу гэтага зрэзу радка.
    ///
    /// Вяртае `false`, калі гэтага не адбываецца.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Вяртае `true`, калі дадзены ўзор адпавядае прэфіксу гэтага зрэзу радка.
    ///
    /// Вяртае `false`, калі гэтага не адбываецца.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Вяртае `true`, калі дадзены ўзор супадае з суфіксам гэтага фрагмента радка.
    ///
    /// Вяртае `false`, калі гэтага не адбываецца.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Вяртае байтавы індэкс першага сімвала гэтага зрэзу радка, які адпавядае шаблону.
    ///
    /// Вяртае [`None`], калі шаблон не супадае.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Больш складаныя ўзоры з выкарыстаннем бязкропкавага стылю і замыканняў:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Не знайсці шаблон:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Вяртае байтавы індэкс першага сімвала самага правага супадзення шаблона ў гэтым зрэзе радка.
    ///
    /// Вяртае [`None`], калі шаблон не супадае.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Больш складаныя ўзоры з замыканнямі:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Не знайсці шаблон:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Ітэратар над падрадкамі гэтага фрагмента радка, падзелены сімваламі, супастаўленымі з шаблонам.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар будзе [`DoubleEndedIterator`], калі шаблон дазваляе зваротны пошук, а пошук forward/reverse дае тыя ж элементы.
    /// Гэта дакладна, напрыклад, для [`char`], але не для `&str`.
    ///
    /// Калі шаблон дазваляе зваротны пошук, але яго вынікі могуць адрознівацца ад пошуку ўперад, можна выкарыстоўваць метад [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Калі ўзор уяўляе сабой зрэз сімвалаў, падзяліце яго пры кожным з'яўленні любога з сімвалаў:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Больш складаны ўзор з выкарыстаннем закрыцця:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Калі радок утрымлівае некалькі сумежных раздзяляльнікаў, у выніку вы атрымаеце пустыя радкі:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Сумежныя раздзяляльнікі раздзяляюцца пустым радком.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Раздзяляльнікі ў пачатку ці ў канцы радка суседнічаюць з пустымі радкамі.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Калі пусты радок выкарыстоўваецца ў якасці раздзяляльніка, ён аддзяляе кожны сімвал у радку, а таксама пачатак і канец радка.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Сумежныя раздзяляльнікі могуць прывесці да дзіўных паводзін, калі ў якасці раздзяляльніка выкарыстоўваецца прабел.Гэты код правільны:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Гэта дае _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Для гэтага выкарыстоўвайце [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Ітэратар над падрадкамі гэтага фрагмента радка, падзелены сімваламі, супастаўленымі з шаблонам.
    /// Адрозніваецца ад ітэратара, вырабленага `split`, тым, што `split_inclusive` пакідае супадзеную частку ў якасці тэрмінатара падрадка.
    ///
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Калі адпавядае апошні элемент радка, гэты элемент будзе лічыцца тэрмінатарам папярэдняй падрадка.
    /// Гэтая падрадок будзе апошнім элементам, вернутым ітэратарам.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Ітэратар над падрадкамі дадзенага зрэзу радкоў, падзелены сімваламі, супастаўленымі з шаблонам, і выдадзены ў зваротным парадку.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар патрабуе, каб узор падтрымліваў зваротны пошук, і гэта будзе [`DoubleEndedIterator`], калі пошук forward/reverse дае тыя ж элементы.
    ///
    ///
    /// Для ітэрацыі спераду можа быць выкарыстаны метад [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Больш складаны ўзор з выкарыстаннем закрыцця:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Ітэратар над падрадкамі дадзенага фрагмента радка, падзелены сімваламі, супастаўленымі з шаблонам.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Эквівалентна [`split`], за выключэннем таго, што канчатковая падрадок прапускаецца, калі яна пустая.
    ///
    /// [`split`]: str::split
    ///
    /// Гэты метад можа быць выкарыстаны для радкавых дадзеных, якія з'яўляюцца _terminated_, а не _separated_ па шаблоне.
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар будзе [`DoubleEndedIterator`], калі шаблон дазваляе зваротны пошук, а пошук forward/reverse дае тыя ж элементы.
    /// Гэта дакладна, напрыклад, для [`char`], але не для `&str`.
    ///
    /// Калі шаблон дазваляе зваротны пошук, але яго вынікі могуць адрознівацца ад пошуку ўперад, можна выкарыстоўваць метад [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Ітэратар над падрадкамі `self`, падзелены сімваламі, узгодненымі па шаблоне, і выдадзены ў зваротным парадку.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Эквівалентна [`split`], за выключэннем таго, што канчатковая падрадок прапускаецца, калі яна пустая.
    ///
    /// [`split`]: str::split
    ///
    /// Гэты метад можа быць выкарыстаны для радкавых дадзеных, якія з'яўляюцца _terminated_, а не _separated_ па шаблоне.
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар патрабуе, каб узор падтрымліваў зваротны пошук, і ён будзе двойчы скончаны, калі пошук forward/reverse дасць тыя ж элементы.
    ///
    ///
    /// Для ітэрацыі спераду можа быць выкарыстаны метад [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ітэратар над падрадкамі дадзенага зрэзу радка, падзелены шаблонам, абмежаваны для вяртання не больш за `n` элементаў.
    ///
    /// Калі вяртаюцца падрадкі `n`, апошняя падрадок (n-я падрадок) будзе ўтрымліваць астатнюю частку радка.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вярнуты ітэратар не будзе падвойным, таму што не эфектыўна падтрымліваць.
    ///
    /// Калі шаблон дазваляе зваротны пошук, можна выкарыстоўваць метад [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Больш складаны ўзор з выкарыстаннем закрыцця:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Ітэратар над падрадкамі гэтага зрэзу радка, падзелены шаблонам, пачынаючы з канца радка, абмежаваны вяртаннем не больш за `n` элементаў.
    ///
    ///
    /// Калі вяртаюцца падрадкі `n`, апошняя падрадок (n-я падрадок) будзе ўтрымліваць астатнюю частку радка.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вярнуты ітэратар не будзе падвойным, таму што не эфектыўна падтрымліваць.
    ///
    /// Для расшчаплення спераду можна выкарыстоўваць метад [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Больш складаны ўзор з выкарыстаннем закрыцця:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Разбівае радок на першае ўваходжанне названага раздзяляльніка і вяртае прэфікс перад раздзяляльнікам і суфікс пасля раздзяляльніка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Разбівае радок на апошняе ўваходжанне ўказанага раздзяляльніка і вяртае прэфікс перад раздзяляльнікам і суфікс пасля раздзяляльніка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ітэратар над несумяшчальнымі супадзеннямі шаблону ў межах дадзенага зрэзу радка.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар будзе [`DoubleEndedIterator`], калі шаблон дазваляе зваротны пошук, а пошук forward/reverse дае тыя ж элементы.
    /// Гэта дакладна, напрыклад, для [`char`], але не для `&str`.
    ///
    /// Калі шаблон дазваляе зваротны пошук, але яго вынікі могуць адрознівацца ад пошуку ўперад, можна выкарыстоўваць метад [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Ітэратар над несумяшчальнымі супадзеннямі шаблона ў гэтым зрэзе радка, выдадзены ў зваротным парадку.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар патрабуе, каб узор падтрымліваў зваротны пошук, і гэта будзе [`DoubleEndedIterator`], калі пошук forward/reverse дае тыя ж элементы.
    ///
    ///
    /// Для ітэрацыі спераду можа быць выкарыстаны метад [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Ітэратар над несумяшчальнымі супадзеннямі шаблону ў гэтым зрэзе радка, а таксама індэксам, з якога пачынаецца супадзенне.
    ///
    /// Для супадзенняў `pat` у `self`, якія перакрываюцца, вяртаюцца толькі індэксы, якія адпавядаюць першаму супадзенню.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар будзе [`DoubleEndedIterator`], калі шаблон дазваляе зваротны пошук, а пошук forward/reverse дае тыя ж элементы.
    /// Гэта дакладна, напрыклад, для [`char`], але не для `&str`.
    ///
    /// Калі шаблон дазваляе зваротны пошук, але яго вынікі могуць адрознівацца ад пошуку ўперад, можна выкарыстоўваць метад [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // толькі першы `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Ітэратар па несумяшчальных супадзеннях шаблону ў межах `self`, выдадзены ў зваротным парадку разам з індэксам супадзення.
    ///
    /// Для супадзенняў `pat` у `self`, якія перакрываюцца, вяртаюцца толькі індэксы, якія адпавядаюць апошняму супадзенню.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Паводзіны ітэратара
    ///
    /// Вяртаецца ітэратар патрабуе, каб узор падтрымліваў зваротны пошук, і гэта будзе [`DoubleEndedIterator`], калі пошук forward/reverse дае тыя ж элементы.
    ///
    ///
    /// Для ітэрацыі спераду можа быць выкарыстаны метад [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // толькі апошні `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Вяртае зрэз радка з выдаленымі прабеламі, якія стаяць заднім і заднім лікам.
    ///
    /// 'Whitespace' вызначаецца ў адпаведнасці з умовамі асноўнага ўласцівасці `White_Space`, атрыманага Unicode.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Вяртае зрэз радка з выдаленымі прабеламі.
    ///
    /// 'Whitespace' вызначаецца ў адпаведнасці з умовамі асноўнага ўласцівасці `White_Space`, атрыманага Unicode.
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// `start` у дадзеным кантэксце азначае першае становішча радка байта;для мовы злева направа, як ангельская ці руская, гэта будзе левы бок, а для моў, якія пішуць справа налева, такіх як арабская або іўрыт, гэта будзе правы бок.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Вяртае зрэз радка з выдаленымі прабеламі.
    ///
    /// 'Whitespace' вызначаецца ў адпаведнасці з умовамі асноўнага ўласцівасці `White_Space`, атрыманага Unicode.
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// `end` у гэтым кантэксце азначае апошнюю пазіцыю гэтага байтавага радка;для мовы злева направа, як ангельская ці руская, гэта будзе правы бок, а для моў справа налева, як арабская або іўрыт, гэта будзе левы бок.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Вяртае зрэз радка з выдаленымі прабеламі.
    ///
    /// 'Whitespace' вызначаецца ў адпаведнасці з умовамі асноўнага ўласцівасці `White_Space`, атрыманага Unicode.
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// 'Left' у дадзеным кантэксце азначае першае становішча радка байта;для такой мовы, як арабская альбо іўрыт, якія "справа налева", а не "злева направа", гэта будзе бок _right_, а не левы.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Вяртае зрэз радка з выдаленымі прабеламі.
    ///
    /// 'Whitespace' вызначаецца ў адпаведнасці з умовамі асноўнага ўласцівасці `White_Space`, атрыманага Unicode.
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// 'Right' у гэтым кантэксце азначае апошнюю пазіцыю гэтага байтавага радка;для такой мовы, як арабская альбо іўрыт, якія "справа налева", а не "злева направа", гэта будзе бок _left_, а не справа.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Вяртае зрэз радка з усімі прэфіксамі і суфіксамі, якія адпавядаюць неаднаразова выдаленым шаблонам.
    ///
    /// [pattern] можа быць [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Больш складаны ўзор з выкарыстаннем закрыцця:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Запомніце самы ранні вядомы матч, выправіце яго ніжэй, калі
            // апошні матч іншы
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЯСПЕКА: Як вядома, `Searcher` вяртае сапраўдныя індэксы.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Вяртае зрэз радка з усімі прэфіксамі, якія адпавядаюць шаблону, неаднаразова выдаленым.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// `start` у дадзеным кантэксце азначае першае становішча радка байта;для мовы злева направа, як ангельская ці руская, гэта будзе левы бок, а для моў, якія пішуць справа налева, такіх як арабская або іўрыт, гэта будзе правы бок.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // БЯСПЕКА: Як вядома, `Searcher` вяртае сапраўдныя індэксы.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Вяртае зрэз радка з выдаленым прэфіксам.
    ///
    /// Калі радок пачынаецца з шаблона `prefix`, вяртаецца падрадок пасля прэфікса, загорнутага ў `Some`.
    /// У адрозненне ад `trim_start_matches`, гэты метад выдаляе прэфікс роўна адзін раз.
    ///
    /// Калі радок не пачынаецца з `prefix`, вяртаецца `None`.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Вяртае зрэз радка з выдаленым суфіксам.
    ///
    /// Калі радок заканчваецца шаблонам `suffix`, вяртае падрадок перад суфіксам, абгорнутым `Some`.
    /// У адрозненне ад `trim_end_matches`, гэты метад выдаляе суфікс роўна адзін раз.
    ///
    /// Калі радок не заканчваецца на `suffix`, вяртаецца `None`.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Вяртае зрэз радка з усімі суфіксамі, якія супадаюць з неаднаразова выдаленым узорам.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// `end` у гэтым кантэксце азначае апошнюю пазіцыю гэтага байтавага радка;для мовы злева направа, як ангельская ці руская, гэта будзе правы бок, а для моў справа налева, як арабская або іўрыт, гэта будзе левы бок.
    ///
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Больш складаны ўзор з выкарыстаннем закрыцця:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЯСПЕКА: Як вядома, `Searcher` вяртае сапраўдныя індэксы.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Вяртае зрэз радка з усімі прэфіксамі, якія адпавядаюць шаблону, неаднаразова выдаленым.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// 'Left' у дадзеным кантэксце азначае першае становішча радка байта;для такой мовы, як арабская альбо іўрыт, якія "справа налева", а не "злева направа", гэта будзе бок _right_, а не левы.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Вяртае зрэз радка з усімі суфіксамі, якія супадаюць з неаднаразова выдаленым узорам.
    ///
    /// [pattern] можа быць `&str`, [`char`], зрэзам [`char`] s, альбо функцыяй альбо закрыццём, якія вызначаюць адпаведнасць персанажа.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Накіраванасць тэксту
    ///
    /// Радок-гэта паслядоўнасць байтаў.
    /// 'Right' у гэтым кантэксце азначае апошнюю пазіцыю гэтага байтавага радка;для такой мовы, як арабская альбо іўрыт, якія "справа налева", а не "злева направа", гэта будзе бок _left_, а не справа.
    ///
    ///
    /// # Examples
    ///
    /// Простыя ўзоры:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Больш складаны ўзор з выкарыстаннем закрыцця:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Аналізуе гэты зрэз радка на іншы тып.
    ///
    /// Паколькі `parse` настолькі агульны, ён можа выклікаць праблемы з вывадам тыпу.
    /// Такім чынам, `parse`-адзін з нямногіх выпадкаў, калі вы ўбачыце сінтаксіс, які называецца ласкава, як 'turbofish': `::<>`.
    ///
    /// Гэта дапамагае алгарытму вываду зразумець, які менавіта тып вы хочаце разабраць.
    ///
    /// `parse` можа аналізаваць любы тып, які рэалізуе [`FromStr`] Portrait.
    ///

    /// # Errors
    ///
    /// Вяртае [`Err`], калі немагчыма разабраць гэты зрэз радка на патрэбны тып.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Выкарыстанне 'turbofish' замест анатавання `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Не атрымалася прааналізаваць:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Правярае, ці знаходзяцца ўсе сімвалы ў гэтым радку ў дыяпазоне ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Тут мы можам разглядаць кожны байт як сімвал: усе шматбайтавыя сімвалы пачынаюцца з байта, які не ўваходзіць у дыяпазон ascii, таму мы на гэтым ужо спынімся.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Правярае, што дзве радкі не супадаюць з улікам рэгістра ASCII.
    ///
    /// Тое ж, што і `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, але без выдзялення і капіравання часоў.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Пераўтварае гэты радок у яго эквівалент ASCII у верхнім рэгістры на месцы.
    ///
    /// Літары ASCII ад 'a' да 'z' супастаўляюцца з 'A' да 'Z', але літары, не звязаныя з ASCII, застаюцца нязменнымі.
    ///
    /// Каб вярнуць новае значэнне з вялікай літарай без змены існуючага, выкарыстоўвайце [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // БЯСПЕКА: бяспечна, таму што мы трансмутуем два тыпы з аднолькавым макетам.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Пераўтварае гэты радок у яго эквівалент ASCII з малой літары на месцы.
    ///
    /// Літары ASCII ад 'A' да 'Z' супастаўляюцца з 'a' да 'z', але літары, не звязаныя з ASCII, застаюцца нязменнымі.
    ///
    /// Каб вярнуць новае малое значэнне без змены існуючага, выкарыстоўвайце [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // БЯСПЕКА: бяспечна, таму што мы трансмутуем два тыпы з аднолькавым макетам.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Вярніце ітэратар, які пазбягае кожнага знака ў `self` разам з [`char::escape_debug`].
    ///
    ///
    /// Note: будуць пазбаўлены толькі пашыраныя кодавыя кропкі, якія пачынаюць радок.
    ///
    /// # Examples
    ///
    /// У якасці ітэратара:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Непасрэдна з выкарыстаннем `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Абодва эквівалентныя:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Выкарыстанне `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Вярніце ітэратар, які пазбягае кожнага знака ў `self` разам з [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// У якасці ітэратара:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Непасрэдна з выкарыстаннем `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Абодва эквівалентныя:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Выкарыстанне `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Вярніце ітэратар, які пазбягае кожнага знака ў `self` разам з [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// У якасці ітэратара:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Непасрэдна з выкарыстаннем `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Абодва эквівалентныя:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Выкарыстанне `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Стварае пусты str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Стварае пустую зменную str
    #[inline]
    fn default() -> Self {
        // БЯСПЕКА: пусты радок сапраўдны UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Тып, які можна назваць кланаваным fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // БЯСПЕКА: не бяспечна
        unsafe { from_utf8_unchecked(bytes) }
    };
}