//! API радка радка.
//!
//! API Pattern забяспечвае агульны механізм выкарыстання розных тыпаў шаблонаў пры пошуку па радку.
//!
//! Больш падрабязна гл. traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] і [`DoubleEndedSearcher`].
//!
//! Хоць гэты API нестабільны, ён падвяргаецца стабільнаму выкарыстанню API тыпу [`str`].
//!
//! # Examples
//!
//! [`Pattern`] гэта [implemented][pattern-impls] у стабільным API для [`&str`][`str`], [`char`], зрэзы [`char`], а таксама функцыі і закрыцця, якія рэалізуюць `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // узор афарбоўкі
//! assert_eq!(s.find('n'), Some(2));
//! // зрэз узору сімвалаў
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // шаблон закрыцця
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Шаблон радка.
///
/// `Pattern<'a>` выказвае, што тып рэалізацыі можа быць выкарыстаны ў якасці радкавага шаблону для пошуку ў [`&'a str`][str].
///
/// Напрыклад, і `'a'`, і `"aa"`-гэта шаблоны, якія супадаюць па індэксе `1` у радку `"baaaab"`.
///
/// Сам Portrait выступае ў якасці зборшчыка для звязанага тыпу [`Searcher`], які выконвае фактычную працу па пошуку ўваходжання шаблона ў радок.
///
///
/// У залежнасці ад тыпу шаблону паводзіны такіх метадаў, як [`str::find`] і [`str::contains`], можа змяняцца.
/// У табліцы ніжэй апісаны некаторыя з гэтых паводзін.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Звязаны шукальнік гэтай мадэлі
    type Searcher: Searcher<'a>;

    /// Стварае звязаны пошукавы сродак для пошуку з `self` і `haystack`.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Правярае, ці адпавядае ўзор дзе-небудзь у стозе сена
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Правярае, ці супадае ўзор у пярэдняй частцы сена
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Правярае, ці адпавядае ўзор у задняй частцы сена
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Выдаляе ўзор з пярэдняй часткі сена, калі ён супадае.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // БЯСПЕКА: Як вядома, `Searcher` вяртае сапраўдныя індэксы.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Выдаляе ўзор са спіны стога сена, калі ён супадае.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // БЯСПЕКА: Як вядома, `Searcher` вяртае сапраўдныя індэксы.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Вынік выкліку [`Searcher::next()`] або [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Выказвае, што ў `haystack[a..b]` знойдзена адпаведнасць шаблону.
    ///
    Match(usize, usize),
    /// Выказвае, што `haystack[a..b]` быў адхілены як магчымае адпаведнасць шаблону.
    ///
    /// Звярніце ўвагу, што паміж двума "Супадзеннямі" можа быць больш аднаго `Reject`, аб'яднаць іх у адзін не патрабуецца.
    ///
    ///
    Reject(usize, usize),
    /// Выказвае, што кожны байт стога сена быў наведаны, заканчваючы ітэрацыю.
    ///
    Done,
}

/// Шукальнік радка.
///
/// Гэты Portrait забяспечвае метады пошуку супадаючых шаблонаў, якія не перакрываюцца, пачынаючы з пярэдняга (left) радка.
///
/// Ён будзе рэалізаваны звязанымі тыпамі `Searcher` з [`Pattern`] Portrait.
///
/// Portrait адзначаны як небяспечны, паколькі індэксы, якія вяртаюцца метадамі [`next()`][Searcher::next], павінны ляжаць на сапраўдных межах utf8 у стозе сена.
/// Гэта дазваляе спажыўцам гэтага Portrait нарэзаць стог сена без дадатковых праверак часу выканання.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter для базавай радкі, у якой трэба шукаць
    ///
    /// Заўсёды будзе вяртаць той самы [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Выконвае наступны этап пошуку, пачынаючы спераду.
    ///
    /// - Вяртае [`Match(a, b)`][SearchStep::Match], калі `haystack[a..b]` адпавядае шаблону.
    /// - Вяртае [`Reject(a, b)`][SearchStep::Reject], калі `haystack[a..b]` не можа адпавядаць шаблону, нават часткова.
    /// - Вяртае [`Done`][SearchStep::Done], калі быў наведаны кожны байт стога.
    ///
    /// Паток значэнняў [`Match`][SearchStep::Match] і [`Reject`][SearchStep::Reject] да [`Done`][SearchStep::Done] будзе ўтрымліваць дыяпазоны індэксаў, якія знаходзяцца побач, не перакрываюцца, ахопліваюць увесь стог сена і ляжаць на межах utf8.
    ///
    ///
    /// Вынік [`Match`][SearchStep::Match] павінен утрымліваць увесь узгоднены ўзор, аднак вынікі [`Reject`][SearchStep::Reject] могуць быць падзелены на адвольна шмат суседніх фрагментаў.Абодва дыяпазону могуць мець нулявую даўжыню.
    ///
    /// У якасці прыкладу ўзор `"aaa"` і стог сена `"cbaaaaab"` могуць стварыць паток
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Знаходзіць наступны вынік [`Match`][SearchStep::Match].Глядзіце [`next()`][Searcher::next].
    ///
    /// У адрозненне ад [`next()`][Searcher::next], няма гарантыі, што вернутыя дыяпазоны гэтага і [`next_reject`][Searcher::next_reject] будуць перакрывацца.
    /// Гэта верне `(start_match, end_match)`, дзе start_match-гэта індэкс таго, дзе пачынаецца матч, а end_match-індэкс пасля заканчэння матчу.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Знаходзіць наступны вынік [`Reject`][SearchStep::Reject].Глядзіце [`next()`][Searcher::next] і [`next_match()`][Searcher::next_match].
    ///
    /// У адрозненне ад [`next()`][Searcher::next], няма гарантыі, што вернутыя дыяпазоны гэтага і [`next_match`][Searcher::next_match] будуць перакрывацца.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Зваротны пошук радка.
///
/// Гэты Portrait забяспечвае метады пошуку супадаючых шаблонаў, якія не перакрываюцца, пачынаючы з задняй часткі (right) радка.
///
/// Ён будзе рэалізаваны звязанымі тыпамі [`Searcher`] з [`Pattern`] Portrait, калі ўзор падтрымлівае пошук яго са спіны.
///
///
/// Дыяпазоны індэксаў, якія вяртаюцца гэтым Portrait, не павінны дакладна адпавядаць дыяпазонам прамога пошуку ў зваротным парадку.
///
/// Па прычыне, чаму гэты Portrait пазначаны як небяспечны, звярніцеся да бацькоўскага Portrait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Выконвае наступны крок пошуку, пачынаючы са спіны.
    ///
    /// - Вяртае [`Match(a, b)`][SearchStep::Match], калі `haystack[a..b]` адпавядае шаблону.
    /// - Вяртае [`Reject(a, b)`][SearchStep::Reject], калі `haystack[a..b]` не можа адпавядаць шаблону, нават часткова.
    /// - Вяртае [`Done`][SearchStep::Done], калі быў наведаны кожны байт стога
    ///
    /// Паток значэнняў [`Match`][SearchStep::Match] і [`Reject`][SearchStep::Reject] да [`Done`][SearchStep::Done] будзе ўтрымліваць дыяпазоны індэксаў, якія знаходзяцца побач, не перакрываюцца, ахопліваюць увесь стог сена і ляжаць на межах utf8.
    ///
    ///
    /// Вынік [`Match`][SearchStep::Match] павінен утрымліваць увесь узгоднены ўзор, аднак вынікі [`Reject`][SearchStep::Reject] могуць быць падзелены на адвольна шмат суседніх фрагментаў.Абодва дыяпазону могуць мець нулявую даўжыню.
    ///
    /// У якасці прыкладу ўзор `"aaa"` і стог сена `"cbaaaaab"` могуць стварыць паток `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Знаходзіць наступны вынік [`Match`][SearchStep::Match].
    /// Глядзіце [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Знаходзіць наступны вынік [`Reject`][SearchStep::Reject].
    /// Глядзіце [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Маркер Portrait, які паказвае, што [`ReverseSearcher`] можна выкарыстоўваць для рэалізацыі [`DoubleEndedIterator`].
///
/// Для гэтага імпл [`Searcher`] і [`ReverseSearcher`] павінны выконваць наступныя ўмовы:
///
/// - Усе вынікі `next()` павінны быць ідэнтычнымі вынікам `next_back()` у зваротным парадку.
/// - `next()` і `next_back()` павінны паводзіць сябе як два канцы дыяпазону значэнняў, гэта значыць яны не могуць "walk past each other".
///
/// # Examples
///
/// `char::Searcher` з'яўляецца `DoubleEndedSearcher`, таму што пошук [`char`] патрабуе толькі прагляду аднаго за адным, які паводзіць сябе аднолькава з абодвух канцоў.
///
/// `(&str)::Searcher` не з'яўляецца `DoubleEndedSearcher`, таму што шаблон `"aa"` у стозе сена `"aaa"` супадае як `"[aa]a"` альбо `"a[aa]"`, у залежнасці ад таго, з якога боку яго шукаюць.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl для char
/////////////////////////////////////////////////////////////////////////////

/// Асацыяваны тып для `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // інварыянт бяспекі: `finger`/`finger_back` павінен быць сапраўдным байтавым індэксам utf8 `haystack`. Гэты інварыянт можна разбіць *у межах* next_match і next_match_back, аднак яны павінны выйсці пальцамі на правільных межах кодавых кропак.
    //
    //
    /// `finger` - бягучы байтавы індэкс пошуку ўперад.
    /// Уявіце, што ён існуе перад байтам па яго індэксе, г.зн.
    /// `haystack[finger]` гэта першы байт зрэзу, які мы павінны праверыць падчас пошуку ўперад
    ///
    finger: usize,
    /// `finger_back` - бягучы байтавы індэкс зваротнага пошуку.
    /// Уявіце, што ён існуе пасля байта па яго індэксе, г.зн.
    /// стог сена [finger_back, 1]-гэта апошні байт зрэзу, які мы павінны праверыць падчас пошуку ўперад (і, такім чынам, першы байт, які трэба праверыць пры выкліку next_back()).
    ///
    finger_back: usize,
    /// Персанаж, якога шукаюць
    needle: char,

    // інварыянт бяспекі: `utf8_size` павінен быць менш за 5
    /// Колькасць байтаў `needle` займае пры кадаванні ў utf8.
    utf8_size: usize,
    /// Кадзіраваная копія `needle` `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // БЯСПЕКА: 1-4 гарантуюць бяспеку `get_unchecked`
        // 1. `self.finger` і `self.finger_back` трымаюцца на межах Unicode (гэта інварыянт)
        // 2. `self.finger >= 0` бо пачынаецца з 0 і толькі павялічваецца
        // 3. `self.finger < self.finger_back` таму што ў адваротным выпадку char `iter` верне `SearchStep::Done`
        // 4.
        // `self.finger` прыходзіць да канца сена, таму што `self.finger_back` пачынаецца ў канцы і толькі памяншаецца
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // дадаць зрушэнне байта бягучага сімвала без перакадзіроўкі як utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // атрымаць стог сена пасля апошняга знойдзенага персанажа
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // апошні байт іголкі, кадаванай utf8, БЯСПЕКА: у нас ёсць інварыянт, які `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Новы палец-гэта індэкс байта, які мы знайшлі, плюс адзін, бо мы запомнілі апошні байт персанажа.
                //
                // Звярніце ўвагу, што гэта не заўсёды дае нам палец на мяжы UTF8.
                // Калі мы * не знайшлі свайго персанажа, мы маглі праіндэксаваць не апошні байт 3-байтавага альбо 4-байтавага сімвала.
                // Мы не можам проста перайсці да наступнага сапраўднага пачатковага байта, бо такі сімвал, як ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` прымусіць нас заўсёды знаходзіць другі байт пры пошуку трэцяга.
                //
                //
                // Аднак гэта цалкам нармальна.
                // Хоць у нас ёсць інварыянт, што self.finger знаходзіцца на мяжы UTF8, на гэты інварыянт у гэтым метадзе не абапіраецца (на яго спасылаюцца ў CharSearcher::next()).
                //
                // Мы выходзім з гэтага метаду толькі тады, калі даходзім да канца радка альбо калі нешта знаходзім.Калі мы нешта знойдзем, `finger` будзе ўсталяваны на мяжу UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // нічога не знайшоў, выйдзіце
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // няхай next_reject выкарыстоўвае рэалізацыю па змаўчанні з Searcher Portrait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // БЯСПЕКА: гл. Каментарый да next() вышэй
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // адніміце зрушэнне байта бягучага сімвала без перакадавання як utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // атрымаць стог сена да, але не ўлічваючы апошняга шуканага персанажа
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // апошні байт іголкі, кадаванай utf8, БЯСПЕКА: у нас ёсць інварыянт, які `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // мы шукалі зрэз, які быў кампенсаваны self.finger, дадаць self.finger, каб кампенсаваць зыходны індэкс
                //
                let index = self.finger + index;
                // memrchr верне індэкс байта, які мы хочам знайсці.
                // У выпадку сімвала ASCII, гэта сапраўды тое, што мы хацелі б, каб наш новы палец быў ("after" знойдзены знак у парадыгме зваротнай ітэрацыі).
                //
                // Для шматбайтавых сімвалаў нам трэба перайсці на колькасць большай колькасці байтаў, чым у ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // перамесціце палец на перад знаходжаннем персанажа (г.зн. у яго пачатковым індэксе)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Тут мы не можам выкарыстоўваць finger_back=index, size + 1.
                // Калі мы знайшлі апошні знак рознага памеру сімвала (альбо сярэдняга байта іншага сімвала), нам трэба перакінуць finger_back да `index`.
                // Гэта аналагічна робіць `finger_back` патэнцыялам больш не знаходзіцца на мяжы, але гэта нармальна, бо мы выходзім з гэтай функцыі толькі на мяжы альбо калі стог сена быў цалкам абшуканы.
                //
                //
                // У адрозненне ад next_match, у нас няма праблемы паўторных байтаў у utf-8, таму што мы шукаем апошні байт, і мы можам знайсці апошні байт толькі пры зваротным пошуку.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // нічога не знайшоў, выйдзіце
                return None;
            }
        }
    }

    // няхай next_reject_back выкарыстоўвае рэалізацыю па змаўчанні з Searcher Portrait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Шукае сімвалы, роўныя дадзенаму [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl для абгорткі MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Параўнайце даўжыні ўнутранага ітэратара зрэзу байтаў, каб знайсці даўжыню бягучага знака
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Параўнайце даўжыні ўнутранага ітэратара зрэзу байтаў, каб знайсці даўжыню бягучага знака
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl для&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Змяніць/выдаліць з-за неадназначнасці сэнсу.

/// Асацыяваны тып для `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Шукае сімвалы, роўныя любым з знакаў [`char '] у зрэзе.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl для F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Асацыяваны тып для `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Шукае [`char`], якія адпавядаюць дадзенаму прэдыкату.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Значэнне для&&str
/////////////////////////////////////////////////////////////////////////////

/// Дэлегаты імп. `&str`.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl для &str
/////////////////////////////////////////////////////////////////////////////

/// Пошук па падрадку, які не выдзяляецца.
///
/// Апрацуе шаблон `""` як вяртанне пустых супадзенняў на кожнай мяжы сімвалаў.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Правярае, ці супадае ўзор у пярэдняй частцы сена.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Выдаляе ўзор з пярэдняй часткі сена, калі ён супадае.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // БЯСПЕКА: прэфікс толькі што быў правераны на наяўнасць.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Правярае, ці адпавядае ўзор у задняй частцы сена.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Выдаляе ўзор са спіны стога сена, калі ён супадае.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // БЯСПЕКА: суфікс толькі што быў правераны.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Двухбаковы пошукавы радок
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Асацыяваны тып для `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // пустая іголка адхіляе кожны знак і супадае з кожным пустым радком паміж імі
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher вырабляе сапраўдныя індэксы *Match*, якія падзяляюцца на межы знакаў, пакуль ён правільна супадае, а стог сена і іголкі сапраўдныя UTF-8 *Адхіленні* ад алгарытму могуць падаць на любыя індэксы, але мы будзем праводзіць іх уручную да наступнай мяжы сімвалаў, так што яны бяспечныя для utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // перайсці да наступнай мяжы знака
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // выпішыце выпадкі `true` і `false`, каб заахвоціць кампілятар спецыялізаваць два выпадкі асобна.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // перайсці да наступнай мяжы знака
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // выпішыце `true` і `false`, як `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Унутраны стан двухбаковага алгарытму пошуку падрадкоўяў.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// індэкс крытычнай фактарызацыі
    crit_pos: usize,
    /// крытычны паказчык фактару для зваротнай іголкі
    crit_pos_back: usize,
    period: usize,
    /// `byteset` з'яўляецца пашырэннем (не з'яўляецца часткай двухбаковага алгарытму);
    /// гэта 64-разрадны "fingerprint", дзе кожны ўсталяваны біт `j` адпавядае (байту і 63)==j, прысутным у іголцы.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// паказальнік у іголку, перад якой мы ўжо адпавядалі
    memory: usize,
    /// індэкс у іголку, пасля чаго мы ўжо адпавядалі
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Асабліва чытэльнае тлумачэнне таго, што тут адбываецца, можна знайсці ў кнізе Crochemore і Rytter "Text Algorithms", гл. 13.
        // У прыватнасці, гл. Код "Algorithm CP" на стар.
        // 323.
        //
        // Што адбываецца, мы маем крытычную фактарызацыю (u, v) іголкі, і мы хочам вызначыць, ці з'яўляецца u суфіксам&v [.. перыяду].
        // Калі гэта так, мы выкарыстоўваем "Algorithm CP1".
        // У адваротным выпадку мы выкарыстоўваем "Algorithm CP2", які аптымізаваны, калі перыяд іголкі вялікі.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // выпадак кароткага перыяду-перыяд дакладна вылічыць асобную крытычную факторызацыю для зваротнай іголкі x=u 'v' дзе | v '|<period(x).
            //
            // Гэта паскорана да таго перыяду, які ўжо вядомы.
            // Звярніце ўвагу, што такі выпадак, як x= "acba", можа быць улічаны з дакладнасцю наперад (crit_pos=1, перыяд=3), пры гэтым улічваецца прыблізны перыяд у адваротным парадку (crit_pos=2, перыяд=2).
            // Мы выкарыстоўваем дадзены зваротны разбор на множнікі, але захоўваем дакладны перыяд.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // выпадак доўгага перыяду-мы маем набліжэнне да фактычнага перыяду і не выкарыстоўваем запамінанне.
            //
            //
            // Прыблізны перыяд ніжняй мяжой max(|u|, |v|) + 1.
            // Крытычную фактарызацыю эфектыўна выкарыстоўваць як для прамога пошуку, так і для зваротнага пошуку.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Фіктыўнае значэнне азначае, што перыяд доўгі
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Адна з галоўных ідэй Two-Way заключаецца ў тым, што мы раскладваем іголку на дзве паловы (u, v) і пачынаем спрабаваць знайсці v у стозе сена, скануючы злева направа.
    // Калі v супадае, мы спрабуем супаставіць u, скануючы справа налева.
    // Наколькі мы можам праскочыць, калі сутыкнемся з неадпаведнасцю, усё заснавана на тым, што (u, v) з'яўляецца найважнейшым фактарам для іголкі.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` выкарыстоўвае `self.position` у якасці курсора
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Пераканайцеся, што ў нас ёсць месца для пошуку ў пазіцыі + ігла_ласта не можа перапоўніцца, калі мы лічым, што зрэзы абмежаваныя дыяпазонам isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Хутка прапусціце вялікія порцыі, не звязаныя з нашай падрадком
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Паглядзіце, ці супадае правая частка іголкі
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Паглядзіце, ці адпавядае левая частка іголкі
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Мы знайшлі супадзенне!
            let match_pos = self.position;

            // Note: дадайце self.period замест needle.len(), каб супадалі супадзенні
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // усталяваны ў needle.len(), self.period для супадзення супадзенняў
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Выконвае ідэі `next()`.
    //
    // Вызначэнні сіметрычныя, з period(x) = period(reverse(x)) і local_period(u, v) = local_period(reverse(v), reverse(u)), таму, калі (u, v) з'яўляецца крытычнай фактарызацыяй, значыць, і (reverse(v), reverse(u)).
    //
    //
    // У адваротным выпадку мы вылічылі крытычную фактарызацыю x=u 'v' (поле `crit_pos_back`).Нам патрэбны | u |<period(x) для прамога выпадку і, такім чынам, | v '|<period(x) для рэверсу.
    //
    // Для пошуку ў зваротным кірунку праз стог сена мы шукаем наперад праз зваротны стог з зваротнай іголкай, спалучаючы спачатку u ', а потым v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` выкарыстоўвае `self.end` у якасці курсора, каб `next()` і `next_back()` былі незалежнымі.
        //
        let old_end = self.end;
        'search: loop {
            // Пераканайцеся, што ў рэшце рэшт у нас ёсць месца для пошуку, needle.len() будзе абгортвацца, калі месца больш не будзе, але з-за абмежаванняў даўжыні зрэзаў ён ніколі не зможа ахінуцца назад у даўжыню стога сена.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Хутка прапусціце вялікія порцыі, не звязаныя з нашай падрадком
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Паглядзіце, ці адпавядае левая частка іголкі
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Паглядзіце, ці супадае правая частка іголкі
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Мы знайшлі супадзенне!
            let match_pos = self.end - needle.len();
            // Note: суб self.period замест needle.len(), каб мець супадзенне супадзенняў
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Вылічыце максімальны суфікс `arr`.
    //
    // Максімальны суфікс-гэта магчымая крытычная фактарызацыя (u, v) `arr`.
    //
    // Вяртае (`i`, `p`), дзе `i`-пачатковы індэкс v, а `p`-перыяд v.
    //
    // `order_greater` вызначае, лексічны парадак `<` ці `>`.
    // Абодва заказы павінны быць вылічаны-заказ з найбуйнейшым `i` дае крытычную фактарызацыю.
    //
    //
    // Для выпадкаў працяглага перыяду выніковы перыяд не з'яўляецца дакладным (ён занадта кароткі).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Адпавядае i ў артыкуле
        let mut right = 1; // Адпавядае j у артыкуле
        let mut offset = 0; // Адпавядае k у артыкуле, але пачынаючы з 0
        // адпавядаць індэксацыі на аснове 0.
        let mut period = 1; // Адпавядае р у артыкуле

        while let Some(&a) = arr.get(right + offset) {
            // `left` будзе ўваход, калі `right` ёсць.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суфікс меншы, кропка пакуль-цэлы прэфікс.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Пераход праз паўтарэнне бягучага перыяду.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суфікс большы, пачынаць спачатку з бягучага месцазнаходжання.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Вылічыце максімальны суфікс рэверсу `arr`.
    //
    // Максімальны суфікс-гэта магчымая крытычная фактарызацыя (u ', v') `arr`.
    //
    // Вяртае `i`, дзе `i`-пачатковы індэкс v ', ззаду;
    // вяртаецца неадкладна, калі дасягнуты перыяд `known_period`.
    //
    // `order_greater` вызначае, лексічны парадак `<` ці `>`.
    // Абодва заказы павінны быць вылічаны-заказ з найбуйнейшым `i` дае крытычную фактарызацыю.
    //
    //
    // Для выпадкаў працяглага перыяду выніковы перыяд не з'яўляецца дакладным (ён занадта кароткі).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Адпавядае i ў артыкуле
        let mut right = 1; // Адпавядае j у артыкуле
        let mut offset = 0; // Адпавядае k у артыкуле, але пачынаючы з 0
        // адпавядаць індэксацыі на аснове 0.
        let mut period = 1; // Адпавядае р у артыкуле
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суфікс меншы, кропка пакуль-цэлы прэфікс.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Пераход праз паўтарэнне бягучага перыяду.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суфікс большы, пачынаць спачатку з бягучага месцазнаходжання.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy дазваляе алгарытму альбо прапускаць несупадзенні як мага хутчэй, альбо працаваць у рэжыме, дзе ён параўнальна хутка выкідвае Адхіленні.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Пераход да супадзення інтэрвалаў як мага хутчэй
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Рэгулярна адкідвайце
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}