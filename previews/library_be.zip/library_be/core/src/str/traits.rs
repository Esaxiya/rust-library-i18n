//! Рэалізацыі Trait для `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Рэалізуе ўпарадкаванне радкоў.
///
/// Радкі ўпарадкаваны [lexicographically](Ord#lexicographical-comparison) па байтавых значэннях.
/// Гэта ўпарадкоўвае коды Unicode на аснове іх пазіцый у графіках кодаў.
/// Гэта не абавязкова тое самае, што заказ "alphabetical", які залежыць ад мовы і мясцовасці.
/// Сартаванне радкоў у адпаведнасці з агульнапрынятымі стандартамі патрабуе дадзеных па мясцовасці, якія выходзяць за рамкі тыпу `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Рэалізуе аперацыі параўнання радкоў.
///
/// Радкі параўноўваюцца з [lexicographically](Ord#lexicographical-comparison) па байтавых значэннях.
/// Гэта параўноўвае кодавыя коды Unicode на аснове іх пазіцый у графіках кодаў.
/// Гэта не абавязкова тое самае, што заказ "alphabetical", які залежыць ад мовы і мясцовасці.
/// Параўнанне радкоў у адпаведнасці з агульнапрынятымі ў культуры стандартамі патрабуе дадзеных па мясцовасці, якія выходзяць за рамкі тыпу `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Рэалізуе нарэзку падрадкоўя з сінтаксісам `&self[..]` або `&mut self[..]`.
///
/// Вяртае зрэз цэлай радкі, г.зн., вяртае `&self` або `&mut self`.Эквівалентна "&self [0 ..
/// len] `або`&mut self [0 ..
/// len]`.
/// У адрозненне ад іншых аперацый індэксавання, гэта ніколі не можа panic.
///
/// Гэта аперацыя *O*(1).
///
/// Да 1.20.0 гэтыя аперацыі індэксавання па-ранейшаму падтрымліваліся непасрэднай рэалізацыяй `Index` і `IndexMut`.
///
/// Эквівалентна `&self[0 .. len]` або `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Рэалізуе нарэзку падрадкоўя з сінтаксісам `&self[begin .. end]` або `&mut self[begin .. end]`.
///
/// Вяртае зрэз дадзенага радка з дыяпазону байтаў [`begin`, `end`).
///
/// Гэта аперацыя *O*(1).
///
/// Да 1.20.0 гэтыя аперацыі індэксавання па-ранейшаму падтрымліваліся непасрэднай рэалізацыяй `Index` і `IndexMut`.
///
/// # Panics
///
/// Panics, калі `begin` альбо `end` не паказвае на зрушэнне пачатковага байта сімвала (як гэта вызначана `is_char_boundary`), калі `begin > end`, альбо калі `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // яны будуць panic:
/// // байт 2 ляжыць у `ö`:
/// // &s [2 ..3];
///
/// // байт 8 ляжыць у межах `老`&s [1 ..
/// // 8];
///
/// // байт 100 знаходзіцца па-за радком&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЯСПЕКА: толькі што праверыў, што `start` і `end` знаходзяцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            // Мы таксама праверылі межы знакаў, таму гэта сапраўдны UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЯСПЕКА: толькі што праверыў, што `start` і `end` знаходзяцца на мяжы знакаў.
            // Мы ведаем, што паказальнік унікальны, таму што мы яго атрымалі ад `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЯСПЕКА: абанент гарантуе, што `self` знаходзіцца ў межах `slice`
        // які задавальняе ўсім умовам для `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЯСПЕКА: гл. Каментарыі да `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary правярае, што індэкс знаходзіцца ў [0, .len()] не можа паўторна выкарыстоўваць `get`, як паказана вышэй, з-за непаладак NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЯСПЕКА: толькі што праверыў, што `start` і `end` знаходзяцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Рэалізуе нарэзку падрадкоўя з сінтаксісам `&self[.. end]` або `&mut self[.. end]`.
///
/// Вяртае зрэз дадзенага радка з дыяпазону байтаў [`0`, `end`).
/// Эквівалентна `&self[0 .. end]` або `&mut self[0 .. end]`.
///
/// Гэта аперацыя *O*(1).
///
/// Да 1.20.0 гэтыя аперацыі індэксавання па-ранейшаму падтрымліваліся непасрэднай рэалізацыяй `Index` і `IndexMut`.
///
/// # Panics
///
/// Panics, калі `end` не паказвае на зрушэнне пачатковага байта сімвала (як гэта вызначана `is_char_boundary`), альбо калі `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЯСПЕКА: толькі што праверыў, што `end` знаходзіцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЯСПЕКА: толькі што праверыў, што `end` знаходзіцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // БЯСПЕКА: толькі што праверыў, што `end` знаходзіцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Рэалізуе нарэзку падрадкоўя з сінтаксісам `&self[begin ..]` або `&mut self[begin ..]`.
///
/// Вяртае зрэз дадзенага радка з дыяпазону байтаў [`begin`, `len`).Эквівалентна "&self [пачаць ..
/// len] `або`&mut self [пачаць ..
/// len]`.
///
/// Гэта аперацыя *O*(1).
///
/// Да 1.20.0 гэтыя аперацыі індэксавання па-ранейшаму падтрымліваліся непасрэднай рэалізацыяй `Index` і `IndexMut`.
///
/// # Panics
///
/// Panics, калі `begin` не паказвае на зрушэнне пачатковага байта сімвала (як гэта вызначана `is_char_boundary`), альбо калі `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЯСПЕКА: толькі што праверыў, што `start` знаходзіцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЯСПЕКА: толькі што праверыў, што `start` знаходзіцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЯСПЕКА: абанент гарантуе, што `self` знаходзіцца ў межах `slice`
        // які задавальняе ўсім умовам для `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЯСПЕКА: ідэнтычны `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // БЯСПЕКА: толькі што праверыў, што `start` знаходзіцца на мяжы знакаў,
            // і мы перадаем бяспечную спасылку, таму зваротнае значэнне таксама будзе адно.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Рэалізуе нарэзку падрадкоўя з сінтаксісам `&self[begin ..= end]` або `&mut self[begin ..= end]`.
///
/// Вяртае зрэз дадзенага радка з дыяпазону байт [`begin`, `end`].Эквівалентна `&self [begin .. end + 1]` або `&mut self[begin .. end + 1]`, за выключэннем выпадкаў, калі `end` мае максімальнае значэнне для `usize`.
///
/// Гэта аперацыя *O*(1).
///
/// # Panics
///
/// Panics, калі `begin` не паказвае на зрушэнне байта пачатковага байта (як гэта вызначана `is_char_boundary`), калі `end` не паказвае на зрушэнне канца байта сімвала (`end + 1`-альбо зрушэнне стартавага байта, альбо роўнае `len`), калі `begin > end`, альбо калі `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Рэалізуе нарэзку падрадкоўя з сінтаксісам `&self[..= end]` або `&mut self[..= end]`.
///
/// Вяртае зрэз дадзенага радка з дыяпазону байтаў [0, `end`].
/// Эквівалентна `&self [0 .. end + 1]`, за выключэннем выпадкаў, калі `end` мае максімальнае значэнне для `usize`.
///
/// Гэта аперацыя *O*(1).
///
/// # Panics
///
/// Panics, калі `end` не паказвае на канчатковае зрушэнне байта сімвала (`end + 1`-гэта альбо зрушэнне пачатковага байта, як вызначана `is_char_boundary`, альбо роўнае `len`), альбо калі `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Прааналізаваць значэнне з радка
///
/// Метад [`from_str`] "FromStr" часта выкарыстоўваецца няяўна праз метад [`parse`] ["str`].
/// Глядзіце прыклады для дакументацыі "разбору".
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` не мае пажыццёвага параметра, і таму вы можаце аналізаваць толькі тыпы, якія самі не ўтрымліваюць пажыццёвы параметр.
///
/// Іншымі словамі, вы можаце прааналізаваць `i32` з `FromStr`, але не `&i32`.
/// Вы можаце прааналізаваць структуру, якая змяшчае `i32`, але не такую, якая ўтрымлівае `&i32`.
///
/// # Examples
///
/// Базавая рэалізацыя `FromStr` на прыкладзе тыпу `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Звязаная памылка, якую можна вярнуць пры разборы.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Аналізуе радок `s`, каб вярнуць значэнне гэтага тыпу.
    ///
    /// Калі разбор атрымаецца, вярніце значэнне ўнутры [`Ok`], у адваротным выпадку, калі радок няправільна адфарматаваны, вернецца памылка, характэрная для ўнутранага [`Err`].
    /// Тып памылкі характэрны для рэалізацыі Portrait.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне [`i32`], тыпу, які рэалізуе `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Прааналізаваць `bool` з радка.
    ///
    /// Дае `Result<bool, ParseBoolError>`, таму што `s` можа быць разабраны, а можа і не.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Звярніце ўвагу, у многіх выпадках метад `.parse()` на `str` з'яўляецца больш правільным.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}