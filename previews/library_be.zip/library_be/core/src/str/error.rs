//! Вызначае тып памылкі utf8.

use crate::fmt;

/// Памылкі, якія могуць узнікнуць пры спробе інтэрпрэтаваць паслядоўнасць [`u8`] як радок.
///
/// Такім чынам, сямейства функцый і метадаў `from_utf8` для [`String`] і [`&str`] s выкарыстоўвае, напрыклад, гэтую памылку.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Метады гэтага тыпу памылак можна выкарыстоўваць для стварэння функцыянальнасці, падобнай на `String::from_utf8_lossy`, без выдзялення кучы памяці:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Вяртае індэкс у дадзеным радку, да якога быў правераны сапраўдны UTF-8.
    ///
    /// Гэта максімальны індэкс, які дазваляе `from_utf8(&input[..index])` вярнуць `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// use std::str;
    ///
    /// // некалькі няслушных байтаў у vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 вяртае Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // другі байт тут несапраўдны
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Дае дадатковую інфармацыю пра няспраўнасць:
    ///
    /// * `None`: канец уводу быў дасягнуты нечакана.
    ///   `self.valid_up_to()` складае ад 1 да 3 байтаў ад канца ўводу.
    ///   Калі байтавы паток (напрыклад, файл ці сеткавы сокет) дэкадуецца паступова, гэта можа быць сапраўдны `char`, чыя байт-паслядоўнасць UTF-8 ахоплівае некалькі кавалкаў.
    ///
    ///
    /// * `Some(len)`: быў сустрэты нечаканы байт.
    ///   Прадугледжаная даўжыня несапраўднай паслядоўнасці байтаў, якая пачынаецца з індэкса, дадзенага `valid_up_to()`.
    ///   Дэкадаванне павінна аднавіцца пасля гэтай паслядоўнасці (пасля ўстаўкі [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) у выпадку дэкадавання са стратамі.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Памылка, якая вяртаецца пры разборы `bool` з выкарыстаннем [`from_str`], не атрымліваецца
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}