//! Кантэйнеры, якія можна змяняць.
//!
//! Бяспека памяці Rust заснавана на гэтым правіле: Улічваючы аб'ект `T`, магчыма толькі адно з наступнага:
//!
//! - Наяўнасць некалькіх нязменных спасылак (`&T`) на аб'ект (таксама вядомы як **псеўданім**).
//! - Наяўнасць адной зменнай спасылкі (`&mut T`) на аб'ект (таксама вядомай як **зменлівасць**).
//!
//! Гэта забяспечваецца кампілятарам Rust.Аднак бываюць сітуацыі, калі гэтае правіла недастаткова гнуткае.Часам патрабуецца мець некалькі спасылак на аб'ект і пры гэтым мутаваць яго.
//!
//! Змяняемыя кантэйнеры, якія можна абменьвацца, існуюць, каб дазволіць кантраляванасць змен, нават пры наяўнасці псеўданімаў.І [`Cell<T>`], і [`RefCell<T>`] дазваляюць рабіць гэта аднапоточным спосабам.
//! Аднак ні `Cell<T>`, ні `RefCell<T>` не бяспечныя для нітак (яны не рэалізуюць [`Sync`]).
//! Калі вам трэба зрабіць псеўданім і мутацыю паміж некалькімі патокамі, можна выкарыстоўваць тыпы [`Mutex<T>`], [`RwLock<T>`] або [`atomic`].
//!
//! Значэнні тыпаў `Cell<T>` і `RefCell<T>` могуць мутавацца праз агульныя спасылкі (г.зн.
//! распаўсюджаны тып `&T`), тады як большасць тыпаў Rust можна мутаваць толькі з дапамогай унікальных спасылак (`&mut T`).
//! Мы гаворым, што `Cell<T>` і `RefCell<T>` забяспечваюць "унутраную зменлівасць", у адрозненне ад тыповых тыпаў Rust, якія дэманструюць "спадчынную зменлівасць".
//!
//! Тыпы клетак бываюць двух відаў: `Cell<T>` і `RefCell<T>`.`Cell<T>` рэалізуе зменлівасць інтэр'еру шляхам перамяшчэння значэнняў у і з `Cell<T>`.
//! Каб выкарыстоўваць спасылкі замест значэнняў, трэба выкарыстоўваць тып `RefCell<T>`, набыўшы блакаванне запісу перад мутацыяй.`Cell<T>` забяспечвае метады атрымання і змены бягучага ўнутранага значэння:
//!
//!  - Для тыпаў, якія рэалізуюць [`Copy`], метад [`get`](Cell::get) атрымлівае бягучае ўнутранае значэнне.
//!  - Для тыпаў, якія рэалізуюць [`Default`], метад [`take`](Cell::take) замяняе бягучае ўнутранае значэнне на [`Default::default()`] і вяртае замененае значэнне.
//!  - Для ўсіх тыпаў метад [`replace`](Cell::replace) замяняе бягучае ўнутранае значэнне і вяртае замененае значэнне, а метад [`into_inner`](Cell::into_inner) спажывае `Cell<T>` і вяртае ўнутранае значэнне.
//!  Акрамя таго, метад [`set`](Cell::set) замяняе ўнутранае значэнне, скідваючы замененае значэнне.
//!
//! `RefCell<T>` выкарыстоўвае жыццё Rust для рэалізацыі "дынамічнага запазычання"-працэсу, пры якім можна запатрабаваць часовы, эксклюзіўны, зменлівы доступ да ўнутранай каштоўнасці.
//! Пазычае для `RefCell<T>"s адсочваюцца"падчас выканання", у адрозненне ад уласных тыпаў спасылак Rust, якія цалкам адсочваюцца статычна падчас компіляцыі.
//! Паколькі пазыкі `RefCell<T>` з'яўляюцца дынамічнымі, можна паспрабаваць запазычыць значэнне, якое ўжо пазычана з заменай;калі гэта адбываецца, гэта прыводзіць да патоку panic.
//!
//! # Калі абраць зменлівасць інтэр'еру
//!
//! Больш распаўсюджаная спадчынная зменлівасць, пры якой трэба мець унікальны доступ для мутацыі значэння, з'яўляецца адным з ключавых моўных элементаў, які дазваляе Rust рашуча разважаць пра змяненне ўказальніка, статычна прадухіляючы памылкі збояў.
//! З-за гэтага пераважная спадчынная зменлівасць, а ўнутраная зменлівасць-гэта крайняя мера.
//! Паколькі тыпы клетак дазваляюць мутаваць там, дзе гэта было б забаронена, хаця бываюць выпадкі, калі ўнутраная зменлівасць можа быць прыдатнай, альбо нават *трэба*, напрыклад,
//!
//! * Прадстаўляем зменлівасць 'inside' чагосьці нязменнага
//! * Падрабязнасці рэалізацыі лагічна-нязменных метадаў.
//! * Мутуюць рэалізацыі [`Clone`].
//!
//! ## Прадстаўляем зменлівасць 'inside' чагосьці нязменнага
//!
//! Шмат якія агульныя тыпы разумных паказальнікаў, у тым ліку [`Rc<T>`] і [`Arc<T>`], забяспечваюць кантэйнеры, якія можна кланаваць і абагульваць паміж сабой.
//! Паколькі змешчаныя значэнні могуць быць множанымі з псеўданімам, яны могуць быць запазычаны толькі з `&`, а не з `&mut`.
//! Без клетак наогул немагчыма будзе мутаваць дадзеныя ўнутры гэтых разумных паказальнікаў.
//!
//! Тады вельмі часта ўкладваюць `RefCell<T>` у агульныя тыпы паказальнікаў, каб аднавіць зменлівасць:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Стварыце новы блок, каб абмежаваць вобласць дынамічнага запазычання
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Звярніце ўвагу, што калі б мы не дазволілі папярэдняму запазычанню кэша выйсці за межы вобласці, то наступнае запазычанне выкліча дынамічны паток panic.
//!     //
//!     // Гэта асноўная небяспека выкарыстання `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Звярніце ўвагу, што ў гэтым прыкладзе выкарыстоўваецца `Rc<T>`, а не `Arc<T>`.`RefCell<T>`s прызначаны для аднапоточных сцэнарыяў.Падумайце над выкарыстаннем [`RwLock<T>`] або [`Mutex<T>`], калі вам патрэбна агульная зменлівасць у шматструменнай сітуацыі.
//!
//! ## Падрабязнасці рэалізацыі лагічна-нязменных метадаў
//!
//! Часам можа быць пажадана не выкрываць у API, што адбываецца мутацыя "under the hood".
//! Гэта можа быць таму, што лагічна аперацыя нязменная, але, напрыклад, кэшаванне прымушае рэалізацыю выконваць мутацыю;альбо таму, што вы павінны выкарыстоўваць мутацыю, каб рэалізаваць метад Portrait, які першапачаткова быў вызначаны як `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Тут ідуць дарагія вылічэнні
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Мутуюць рэалізацыі `Clone`
//!
//! Гэта проста асаблівы, але распаўсюджаны выпадак папярэдняга: хаванне зменлівасці для аперацый, якія ўяўляюцца нязменнымі.
//! Чакаецца, што метад [`clone`](Clone::clone) не зменіць зыходнае значэнне, і заяўлена, што ён прымае `&self`, а не `&mut self`.
//! Такім чынам, любая мутацыя, якая адбываецца ў метадзе `clone`, павінна выкарыстоўваць тыпы клетак.
//! Напрыклад, [`Rc<T>`] падтрымлівае лічбу спасылак у межах `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Змянянае месца ў памяці.
///
/// # Examples
///
/// У гэтым прыкладзе вы бачыце, што `Cell<T>` уключае мутацыю ў нязменнай структуры.
/// Іншымі словамі, гэта дазваляе "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ПАМЫЛКА: `my_struct` нязменны
/// // my_struct.regular_field =новае_значэнне;
///
/// // ПРАЦЫ: хаця `my_struct` нязменны, `special_field`-`Cell`,
/// // якія заўсёды можна мутаваць
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Глядзіце [module-level documentation](self) для атрымання дадатковай інфармацыі.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Стварае `Cell<T>` са значэннем `Default` для T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Стварае новы `Cell`, які змяшчае зададзенае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Усталёўвае змешчанае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Памяняе значэнні дзвюх вочак.
    /// Розніца з `std::mem::swap` у тым, што для гэтай функцыі не патрабуецца спасылка на `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // БЯСПЕКА: Гэта можа быць рызыкоўна, калі выклікаць з асобных патокаў, але `Cell`
        // гэта `!Sync`, таму гэтага не адбудзецца.
        // Гэта таксама не прывядзе да несапраўднасці паказальнікаў, бо `Cell` гарантуе, што нішто іншае не будзе паказваць ні на адну з гэтых "вочак".
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Замяняе змешчанае значэнне на `val` і вяртае старое змешчанае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // БЯСПЕКА: Гэта можа выклікаць разгон дадзеных, калі выклікаць яго з асобнага патоку,
        // але `Cell`-гэта `!Sync`, таму гэтага не адбудзецца.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Разгарнуць значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Вяртае копію змешчанага значэння.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // БЯСПЕКА: Гэта можа выклікаць разгон дадзеных, калі выклікаць яго з асобнага патоку,
        // але `Cell`-гэта `!Sync`, таму гэтага не адбудзецца.
        unsafe { *self.value.get() }
    }

    /// Абнаўляе змешчанае значэнне з дапамогай функцыі і вяртае новае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Вяртае неапрацаваны паказальнік на базавыя дадзеныя ў гэтай ячэйцы.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Вяртае зменную спасылку на базавыя дадзеныя.
    ///
    /// Гэты званок пазычае `Cell` мутавана (падчас кампіляцыі), што гарантуе, што мы маем адзіную спасылку.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Вяртае `&Cell<T>` з `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // БЯСПЕКА: `&mut` забяспечвае унікальны доступ.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Прымае значэнне ячэйкі, пакідаючы `Default::default()` на сваім месцы.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Вяртае `&[Cell<T>]` з `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // БЯСПЕКА: `Cell<T>` мае такі ж макет памяці, як і `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Змянянае месца памяці з дынамічна правяранымі правіламі запазычання
///
/// Глядзіце [module-level documentation](self) для атрымання дадатковай інфармацыі.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Памылка, вернутая [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Памылка, вернутая [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Станоўчыя значэнні ўяўляюць колькасць актыўных `Ref`.Адмоўныя значэнні ўяўляюць колькасць актыўных `RefMut`.
// Некалькі "RefMut" могуць быць актыўнымі адначасова, толькі калі яны спасылаюцца на розныя кампаненты `RefCell`, якія не перакрываюцца (напрыклад, розныя дыяпазоны зрэзу).
//
// `Ref` і `RefMut`-гэта два словы па памеры, таму, верагодна, ніколі не будзе дастаткова `Ref`s альбо`RefMut`s, каб перапоўніць палову дыяпазону `usize`.
// Такім чынам, `BorrowFlag`, верагодна, ніколі не перапоўніцца і не перапоўніцца.
// Аднак гэта не з'яўляецца гарантыяй, бо паталагічная праграма можа неаднаразова ствараць mem::forget `Ref`s ці`RefMut`s.
// Такім чынам, увесь код павінен відавочна правяраць наяўнасць перапаўнення і перапаўнення, каб пазбегнуць небяспекі альбо, па меншай меры, паводзіць сябе правільна ў выпадку, калі адбываецца перапаўненне або недапаўненне (напрыклад, гл. BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Стварае новы `RefCell`, які змяшчае `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Спажывае `RefCell`, вяртаючы загарнутае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Паколькі гэтая функцыя прымае `self` (`RefCell`) па значэнні, кампілятар статычна правярае, што яна ў цяперашні час не запазычана.
        //
        self.value.into_inner()
    }

    /// Замяняе загарнутае значэнне новым, вяртаючы старое значэнне, не дэініцыялізуючы ні адно.
    ///
    ///
    /// Гэтая функцыя адпавядае [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, калі кошт у цяперашні час пазычана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Замяняе загарнутае значэнне новым, вылічаным з `f`, вяртаючы старое значэнне, не дэініцыялізуючы ні адно.
    ///
    ///
    /// # Panics
    ///
    /// Panics, калі кошт у цяперашні час пазычана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Мяняе абгорнутае значэнне `self` на абгорнутае значэнне `other`, не дэініцыялізуючы ні адно.
    ///
    ///
    /// Гэтая функцыя адпавядае [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Нязменна запазычвае загорнутае значэнне.
    ///
    /// Пазыка доўжыцца да таго часу, пакуль вернуты `Ref` не выйдзе з вобласці.
    /// Адначасова можна браць некалькі нязменных пазык.
    ///
    /// # Panics
    ///
    /// Panics, калі кошт у цяперашні час пазычана з заменай.
    /// Для варыянту, які не выклікае панікі, выкарыстоўвайце [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Прыклад panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Нязменна запазычвае загорнутае значэнне, вяртаючы памылку, калі значэнне ў цяперашні час з'яўляецца пазычаным з заменай.
    ///
    ///
    /// Пазыка доўжыцца да таго часу, пакуль вернуты `Ref` не выйдзе з вобласці.
    /// Адначасова можна браць некалькі нязменных пазык.
    ///
    /// Гэта не панікавальны варыянт [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // БЯСПЕКА: `BorrowRef` гарантуе наяўнасць толькі нязменнага доступу
            // да кошту пры пазыцы.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Зменліва запазычвае загорнутае значэнне.
    ///
    /// Пазыка доўжыцца да таго часу, пакуль вернуты `RefMut` ці ўсе `RefMut`, атрыманыя з яго, не выйдуць з вобласці.
    ///
    /// Значэнне нельга пазычыць, пакуль яно актыўнае.
    ///
    /// # Panics
    ///
    /// Panics, калі кошт у цяперашні час пазычана.
    /// Для варыянту, які не выклікае панікі, выкарыстоўвайце [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Прыклад panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Змяняецца запазычанне загорнутага значэння, вяртаючы памылку, калі значэнне ў цяперашні час пазычана.
    ///
    ///
    /// Пазыка доўжыцца да таго часу, пакуль вернуты `RefMut` ці ўсе `RefMut`, атрыманыя з яго, не выйдуць з вобласці.
    /// Значэнне нельга пазычыць, пакуль яно актыўнае.
    ///
    /// Гэта не панікавальны варыянт [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // БЯСПЕКА: `BorrowRef` гарантуе унікальны доступ.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Вяртае неапрацаваны паказальнік на базавыя дадзеныя ў гэтай ячэйцы.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Вяртае зменную спасылку на базавыя дадзеныя.
    ///
    /// Гэты выклік пазычае `RefCell` мутавана (падчас кампіляцыі), таму няма неабходнасці ў дынамічных праверках.
    ///
    /// Аднак будзьце асцярожныя: гэты метад мяркуе, што `self` будзе змяняцца, што звычайна не бывае пры выкарыстанні `RefCell`.
    ///
    /// Звярніце ўвагу на метад [`borrow_mut`], калі `self` не змяняецца.
    ///
    /// Акрамя таго, майце на ўвазе, што гэты спосаб прызначаны толькі для асаблівых абставінаў і звычайна не такі, як вы хочаце.
    /// У выпадку сумневаў выкарыстоўвайце [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Скасаваць уплыў працёкаў ахоўнікаў на стан запазычання `RefCell`.
    ///
    /// Гэты званок падобны на [`get_mut`], але больш спецыялізаваны.
    /// Ён пазычае `RefCell` мутавана, каб пераканацца, што ніякіх пазык не існуе, а затым скідае дзяржаўныя адсочванні агульных пазык.
    /// Гэта актуальна, калі некаторыя пазыкі `Ref` або `RefMut` прасачыліся.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Нязменна запазычвае загорнутае значэнне, вяртаючы памылку, калі значэнне ў цяперашні час з'яўляецца пазычаным з заменай.
    ///
    /// # Safety
    ///
    /// У адрозненне ад `RefCell::borrow`, гэты метад небяспечны, бо не вяртае `Ref`, такім чынам, сцяг запазычання застаецца некранутым.
    /// З папраўкай запазычыць `RefCell`, пакуль спасылка, вернутая гэтым метадам, жывая, не вызначана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // БЯСПЕКА: Мы правяраем, што зараз ніхто актыўна не піша, але гэта так
            // адказнасць абанента за тое, каб ніхто не пісаў, пакуль вернутая спасылка больш не выкарыстоўваецца.
            // Акрамя таго, `self.value.get()` спасылаецца на кошт, якая належыць `self`, і, такім чынам, гарантуецца, што яна будзе сапраўднай на працягу ўсяго жыцця `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Прымае загорнутае значэнне, пакідаючы `Default::default()` на сваім месцы.
    ///
    /// # Panics
    ///
    /// Panics, калі кошт у цяперашні час пазычана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, калі кошт у цяперашні час пазычана з заменай.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Стварае `RefCell<T>` са значэннем `Default` для T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, калі значэнне ў любым з `RefCell` у цяперашні час пазычана.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Павелічэнне запазычання можа прывесці да значэння, якое не чытаецца (<=0), у наступных выпадках:
            // 1. Было <0, т. Е. Ёсць пазыкі для запісу, таму мы не можам дазволіць запазычанне для чытання з-за правілаў псеўданіма спасылак Rust
            // 2.
            // Гэта быў isize::MAX (максімальная колькасць запазычанняў для чытання), і ён перапаў у isize::MIN (максімальная колькасць запазычанняў для напісання), таму мы не можам дазволіць дадатковае запазычанне для чытання, таму што isize не можа прадстаўляць так шмат прачытаных запазычанняў (гэта можа адбыцца толькі ў тым выпадку, калі вы mem::forget больш, чым невялікая пастаянная колькасць `Ref`s, што не з'яўляецца добрай практыкай)
            //
            //
            //
            //
            None
        } else {
            // Павелічэнне запазычання можа прывесці да значэння чытання (> 0) у наступных выпадках:
            // 1. Было=0, гэта значыць не было запазычана, і мы бярэм першае прачытанае запазычанне
            // 2. Было> 0 і <isize::MAX, г.зн.
            // былі прачытаныя запазычанні, і isize досыць вялікі, каб адлюстроўваць яшчэ адно прачытанае запазычанне
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Паколькі гэтая спасылка існуе, мы ведаем, што сцяг запазычання-пазыка для чытання.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Прадухіліце пералічэнне лічыльніка запазычанняў у пісьмовую.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Перамяшчае запазычаную спасылку на значэнне ў поле `RefCell`.
/// Тып абгорткі для нязменна запазычанага значэння з `RefCell<T>`.
///
/// Глядзіце [module-level documentation](self) для атрымання дадатковай інфармацыі.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Капіюе `Ref`.
    ///
    /// `RefCell` ужо нязменна пазычаны, таму гэта не можа пацярпець няўдачу.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `Ref::clone(...)`.
    /// Рэалізацыя `Clone` альбо метад будуць перашкаджаць шырокаму выкарыстанню `r.borrow().clone()` для кланавання змесціва `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Стварае новы `Ref` для кампанента запазычаных дадзеных.
    ///
    /// `RefCell` ужо нязменна пазычаны, таму гэта не можа пацярпець няўдачу.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `Ref::map(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Стварае новы `Ref` для дадатковага кампанента запазычаных дадзеных.
    /// Арыгінальны ахоўнік вяртаецца як `Err(..)`, калі закрыццё вяртае `None`.
    ///
    /// `RefCell` ужо нязменна пазычаны, таму гэта не можа пацярпець няўдачу.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `Ref::filter_map(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Разбівае `Ref` на некалькі "Ref" для розных кампанентаў запазычаных дадзеных.
    ///
    /// `RefCell` ужо нязменна пазычаны, таму гэта не можа пацярпець няўдачу.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `Ref::map_split(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Пераўтварыце ў спасылку на асноўныя дадзеныя.
    ///
    /// Базавы `RefCell` ніколі больш не можа быць пазычаны з заменай і заўсёды будзе выглядаць ужо нязменна запазычаным.
    ///
    /// Гэта не добрая ідэя, каб прасачыць больш, чым пастаянная колькасць спасылак.
    /// `RefCell` можна зноў запазычыць, калі ў цэлым адбылася толькі меншая колькасць уцечак.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `Ref::leak(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Забыўшыся пра гэта, мы гарантуем, што лічыльнік запазычанняў у RefCell не можа вярнуцца да UNUSED на працягу жыцця `'b`.
        // Скід стану адсочвання спасылак запатрабуе ўнікальнай спасылкі на запазычаную RefCell.
        // З арыгінальнай ячэйкі нельга ствараць дадатковыя спасылкі, якія можна змяняць.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Стварае новы `RefMut` для кампанента запазычаных дадзеных, напрыклад, варыянта пералічэння.
    ///
    /// `RefCell` ужо запазычаны, таму гэта не можа пацярпець няўдачу.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `RefMut::map(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): выправіць пазыку-чэк
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Стварае новы `RefMut` для дадатковага кампанента запазычаных дадзеных.
    /// Арыгінальны ахоўнік вяртаецца як `Err(..)`, калі закрыццё вяртае `None`.
    ///
    /// `RefCell` ужо запазычаны, таму гэта не можа пацярпець няўдачу.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `RefMut::filter_map(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): выправіць пазыку-чэк
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // БЯСПЕКА: функцыя дзейнічае на эксклюзіўным эталоне на працягу ўсяго часу
        // яго выкліку праз `orig`, і ўказальнік не мае спасылак унутры выкліку функцыі, ніколі не дазваляючы выключыць спасылку.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // БЯСПЕКА: тое ж самае, што і вышэй.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Разбівае `RefMut` на некалькі `RefMut` для розных кампанентаў запазычаных дадзеных.
    ///
    /// Базавы `RefCell` будзе заставацца з пазыкай, пакуль абодва вернутыя `RefMut` не выйдуць за рамкі.
    ///
    /// `RefCell` ужо запазычаны, таму гэта не можа пацярпець няўдачу.
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `RefMut::map_split(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Пераўтварыце ў зменлівую спасылку на асноўныя дадзеныя.
    ///
    /// У асноўнай `RefCell` нельга зноў браць запазычанні, і яна заўсёды будзе выглядаць ужо нязменна запазычанай, робячы зваротную спасылку адзінай на інтэр'ер.
    ///
    ///
    /// Гэта звязаная функцыя, якую трэба выкарыстоўваць як `RefMut::leak(...)`.
    /// Метад будзе перашкаджаць аднайменным метадам змесціва `RefCell`, які выкарыстоўваецца праз `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Забыўшыся пра BorrowRefMut, мы гарантуем, што лічыльнік запазычанняў у RefCell не можа вярнуцца да UNUSED на працягу жыцця `'b`.
        // Скід стану адсочвання спасылак запатрабуе ўнікальнай спасылкі на запазычаную RefCell.
        // На працягу гэтага перыяду жыцця з арыгінальнай ячэйкі нельга стварыць дадатковыя спасылкі, што робіць бягучы запазычанне адзінай спасылкай на астатняе жыццё.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: У адрозненне ад BorrowRefMut::clone, новы ствараецца для стварэння пачатковага
        // зменлівая спасылка, і таму ў цяперашні час не павінна быць існуючых спасылак.
        // Такім чынам, у той час як клон павялічвае зменлівы лік, тут мы відавочна дазваляем толькі пераходзіць ад НЕВЫКАРЫСТАНАГА да НЕВЫКАРЫСТАНАГА,
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Клонуе `BorrowRefMut`.
    //
    // Гэта дзейнічае толькі ў тым выпадку, калі кожны `BorrowRefMut` выкарыстоўваецца для адсочвання зменнай спасылкі на асобны дыяпазон арыгінальнага аб'екта, які не перакрываецца.
    //
    // Гэта не ў імпульсе Clone, так што код не выклікае гэта імпліцытна.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Прадухіліце запаўненне лічыльніка пазык.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Тып абгорткі для мутавана запазычанага значэння з `RefCell<T>`.
///
/// Глядзіце [module-level documentation](self) для атрымання дадатковай інфармацыі.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Асноўны прымітыў для зменлівасці інтэр'еру ў Rust.
///
/// Калі ў вас ёсць спасылка `&T`, то звычайна ў Rust кампілятар выконвае аптымізацыю на аснове ведаў, што `&T` паказвае на нязменныя дадзеныя.Мутацыя гэтых дадзеных, напрыклад, праз псеўданім альбо пераўтварэнне `&T` у `&mut T`, лічыцца неакрэсленым паводзінамі.
/// `UnsafeCell<T>` адмова ад гарантыі нязменнасці для `&T`: агульная спасылка `&UnsafeCell<T>` можа паказваць на дадзеныя, якія муціруюцца.Гэта называецца "interior mutability".
///
/// Усе астатнія тыпы, якія дазваляюць унутраную зменлівасць, такія як `Cell<T>` і `RefCell<T>`, унутрана выкарыстоўваюць `UnsafeCell` для ахінання дадзеных.
///
/// Звярніце ўвагу, што `UnsafeCell` ўплывае толькі на гарантыю нязменнасці агульных спасылак.Гарантыя унікальнасці змяняемых спасылак не ўплывае.Не існуе * законнага спосабу атрымаць псеўданім `&mut`, нават з `UnsafeCell<T>`.
///
/// API `UnsafeCell` сам па сабе вельмі просты з тэхнічнага пункту гледжання: [`.get()`] дае вам неапрацаваны паказальнік `*mut T` на яго змест.Правільна выкарыстоўваць гэты неапрацаваны паказальнік залежыць ад _you_ як дызайнера абстракцыі.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Дакладныя правілы псеўданіма Rust некалькі змяняюцца, але асноўныя моманты не аспрэчваюцца:
///
/// - Калі вы ствараеце бяспечную спасылку з пажыццёвым `'a` (альбо спасылку `&T`, альбо `&mut T`), да якой можна атрымаць бяспечны код (напрыклад, таму, што вы яе вярнулі), вы не павінны атрымліваць доступ да дадзеных якім-небудзь чынам, што супярэчыць гэтай спасылцы ў астатнім з `'a`.
/// Напрыклад, гэта азначае, што калі вы бераце `*mut T` з `UnsafeCell<T>` і накіроўваеце яго на `&T`, дадзеныя ў `T` павінны заставацца нязменнымі (зразумела, па модулі любыя дадзеныя `UnsafeCell`, знойдзеныя ў `T`), пакуль не скончыцца тэрмін службы гэтай спасылкі.
/// Аналагічным чынам, калі вы ствараеце спасылку `&mut T`, якая вызваляецца для бяспечнага кода, вы не павінны атрымліваць доступ да дадзеных у `UnsafeCell`, пакуль гэтая спасылка не скончыцца.
///
/// - У любы час трэба пазбягаць гонак дадзеных.Калі некалькі патокаў маюць доступ да аднаго і таго ж `UnsafeCell`, любая запіс павінна мець належную сувязь "да здарэння" перад усімі іншымі доступамі (альбо выкарыстоўваць атамную сістэму).
///
/// Каб дапамагчы ў правільным дызайне, наступныя сцэнарыі відавочна абвяшчаюцца законнымі для аднапоточнага кода:
///
/// 1. Даведка `&T` можа быць вызвалена ў бяспечны код і там яна можа існаваць разам з іншымі спасылкамі `&T`, але не з `&mut T`
///
/// 2. Спасылка на `&mut T` можа быць выдадзена для бяспечнага кода, калі з ім не існуюць ні іншыя `&mut T`, ні `&T`.`&mut T` заўсёды павінен быць унікальным.
///
/// Звярніце ўвагу, што пры мутацыі змесціва `&UnsafeCell<T>` (нават калі іншыя `&UnsafeCell<T>` спасылаюцца на псеўданім клеткі) гэта нармальна (пры ўмове, што вы інцынтантуеце вышэйзгаданыя інварыянты іншым спосабам), па-ранейшаму не вызначана паводзіны мець некалькі псеўданімаў `&mut UnsafeCell<T>`.
/// Гэта значыць, `UnsafeCell`-гэта абгортка, прызначаная для асаблівага ўзаемадзеяння з _shared_ accesses (_i.e._, праз спасылку на `&UnsafeCell<_>`);пры зносінах з _exclusive_ accesses (_e.g._ праз `&mut UnsafeCell<_>` няма ніякай магіі): ні вочка, ні загорнутае значэнне не могуць быць выстаўлены на псеўданім на працягу пазыкі `&mut`.
///
/// Гэта прадэманстравана аксэсуарам [`.get_mut()`], які ўяўляе сабой _safe_ getter, які дае `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Вось прыклад, які дэманструе, як наглядна мутаваць змесціва `UnsafeCell<_>`, нягледзячы на наяўнасць некалькіх спасылак, якія змяняюць ячэйкі ў клетку:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Атрымайце некалькі/адначасовых/агульных спасылак на адзін і той жа `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // БЯСПЕКА: у гэтым абсягу няма іншых спасылак на змест `x`,
///     // таму наш фактычна ўнікальны.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- пазычыць-+
///     *p1_exclusive += 27; // |
/// } // <---------- не можа выйсці за межы гэтага пункта -------------------+
///
/// unsafe {
///     // БЯСПЕКА: у рамках гэтай сферы ніхто не разлічвае на эксклюзіўны доступ да зместу `x`,
///     // таму мы можам адначасова мець некалькі агульных доступаў.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// У наступным прыкладзе дэманструецца той факт, што эксклюзіўны доступ да `UnsafeCell<T>` прадугледжвае эксклюзіўны доступ да яго `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // з эксклюзіўным доступам,
///                         // `UnsafeCell` з'яўляецца празрыстай абгорткай без аперацыі, таму `unsafe` тут не патрэбны.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Атрымайце унікальную спасылку на `x`, правераную падчас кампіляцыі.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // З эксклюзіўнай спасылкай мы можам бясплатна змяняць змесціва.
/// *p_unique.get_mut() = 0;
/// // Ці, што эквівалентна:
/// x = UnsafeCell::new(0);
///
/// // Калі мы валодаем каштоўнасцю, мы можам здабыць змесціва бясплатна.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Стварае новы экземпляр `UnsafeCell`, які будзе пераносіць зададзенае значэнне.
    ///
    ///
    /// Увесь доступ да ўнутранага значэння праз метады-гэта `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Разгарнуць значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Атрымлівае зменлівы паказальнік на загорнутае значэнне.
    ///
    /// Гэта можа быць накіравана на паказальнік любога роду.
    /// Пераканайцеся, што доступ унікальны (без актыўных спасылак, зменлівы ці не) пры трансляцыі на `&mut T` і пераканайцеся, што пры трансляцыі на `&T` не адбываецца мутацый або зменлівых псеўданімаў.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Мы можам проста перакінуць паказальнік з `UnsafeCell<T>` на `T` з-за #[repr(transparent)].
        // Гэта выкарыстоўвае асаблівы статус libstd, няма гарантыі для карыстацкага кода, што гэта будзе працаваць у версіях future кампілятара!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Вяртае зменную спасылку на базавыя дадзеныя.
    ///
    /// Гэты званок пазычае `UnsafeCell` мутавана (падчас кампіляцыі), што гарантуе, што мы маем адзіную спасылку.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Атрымлівае зменлівы паказальнік на загорнутае значэнне.
    /// Адрозненне ад [`get`] заключаецца ў тым, што гэтая функцыя прымае неапрацаваны паказальнік, што карысна, каб пазбегнуць стварэння часовых спасылак.
    ///
    /// Вынік можна перакінуць на паказальнік любога роду.
    /// Пераканайцеся, што доступ унікальны (адсутнасць актыўных спасылак, змяняецца ці не) пры трансляцыі на `&mut T`, і пераканайцеся, што пры трансляцыі на `&T` не адбываецца мутацый і зменлівых псеўданімаў.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Паступовая ініцыялізацыя `UnsafeCell` патрабуе `raw_get`, бо для выкліку `get` спатрэбіцца стварэнне спасылкі на неініцыялізаваныя дадзеныя:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Мы можам проста перакінуць паказальнік з `UnsafeCell<T>` на `T` з-за #[repr(transparent)].
        // Гэта выкарыстоўвае асаблівы статус libstd, няма гарантыі для карыстацкага кода, што гэта будзе працаваць у версіях future кампілятара!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Стварае `UnsafeCell` са значэннем `Default` для T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}