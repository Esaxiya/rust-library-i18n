//! Пераўтварэнне сімвалаў.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Пераўтварае `u32` у `char`.
///
/// Звярніце ўвагу, што ўсе [`char`] з'яўляюцца сапраўднымі [`u32`] s, і іх можна перадаць у адзін з
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Аднак адваротнае не адпавядае рэчаіснасці: не ўсе сапраўдныя [`u32`] s з'яўляюцца сапраўднымі [`char`] s.
/// `from_u32()` верне `None`, калі ўвод не з'яўляецца сапраўдным значэннем для [`char`].
///
/// Небяспечную версію гэтай функцыі, якая ігнаруе гэтыя праверкі, см. У [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Вяртанне `None`, калі ўвод несапраўдны [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Пераўтварае `u32` у `char`, ігнаруючы сапраўднасць.
///
/// Звярніце ўвагу, што ўсе [`char`] з'яўляюцца сапраўднымі [`u32`] s, і іх можна перадаць у адзін з
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Аднак адваротнае не адпавядае рэчаіснасці: не ўсе сапраўдныя [`u32`] s з'яўляюцца сапраўднымі [`char`] s.
/// `from_u32_unchecked()` будзе ігнараваць гэта і сляпо перакідваць на [`char`], магчыма, ствараючы несапраўдны.
///
///
/// # Safety
///
/// Гэтая функцыя небяспечная, бо можа ствараць недапушчальныя значэнні `char`.
///
/// Для бяспечнай версіі гэтай функцыі глядзіце функцыю [`from_u32`].
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // БЯСПЕКА: абанент павінен гарантаваць, што `i` з'яўляецца сапраўдным значэннем знака.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Пераўтварае [`char`] у [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Пераўтварае [`char`] у [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Знак адліваецца да значэння кодавай кропкі, пасля чаго павялічваецца да нуля да 64 біта.
        // Глядзіце [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Пераўтварае [`char`] у [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Знак адліваецца да значэння кодавай кропкі, пасля чаго павялічваецца да нуля да 128 біт.
        // Глядзіце [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Адлюстраванне байта ў 0x00 ..=0xFF у `char`, кодавы пункт якога мае аднолькавае значэнне, у U + 0000 ..=U + 00FF.
///
/// Unicode распрацаваны такім чынам, што ён эфектыўна дэкадуе байты з кадаваннем сімвалаў, якое IANA называе ISO-8859-1.
/// Гэта кадаванне сумяшчальна з ASCII.
///
/// Звярніце ўвагу, што гэта адрозніваецца ад ISO/IEC 8859-1 aka
/// ISO 8859-1 (з адным злучком менш), які пакідае некаторыя значэнні байтаў "blanks", якія не прысвоены ніводнаму знаку.
/// ISO-8859-1 (IANA) прызначае іх для кантрольных кодаў C0 і C1.
///
/// Звярніце ўвагу, што гэта *таксама* адрозніваецца ад Windows-1252 aka
/// кодавая старонка 1252, якая ўяўляе сабой набор ISO/IEC 8859-1, які прызначае некаторыя (не ўсе!) прабелы знакі прыпынку і розныя лацінскія сімвалы.
///
/// Каб яшчэ больш заблытаць, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` і `windows-1252`-усе псеўданімы для набору Windows-1252, які запаўняе астатнія прабелы адпаведнымі кодамі кіравання C0 і C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Пераўтварае [`u8`] у [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Памылка, якую можна вярнуць пры разборы знака.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // БЯСПЕКА: праверана, што гэта юрыдычная каштоўнасць юнікода
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Тып памылкі вяртаецца, калі пераўтварэнне з u32 у char не атрымліваецца.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Пераўтварае лічбу ў дадзеным радыусе ў `char`.
///
/// Тут 'radix' часам таксама называюць 'base'.
/// Радыкс два паказвае двайковы лік, дзесятак дзесяці знакаў пасля коскі і радыус шаснаццаці, шаснаццатковы, для атрымання некаторых агульных значэнняў.
///
/// Падтрымліваюцца адвольныя парады.
///
/// `from_digit()` верне `None`, калі ўвод не з'яўляецца лічбай у дадзеным радыусе.
///
/// # Panics
///
/// Panics, калі дадзены радыус, большы за 36.
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Дзесятковая лічба 11-адназначная лічба ў аснове 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Вяртанне `None`, калі ўвод не з'яўляецца лічбай:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Праходжанне вялікага радыусу, выклікаючы panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}