//! Апрацоўка памылак з тыпам `Result`.
//!
//! [`Result<T, E>`][`Result`] гэта тып, які выкарыстоўваецца для вяртання і распаўсюджвання памылак.
//! Гэта пералік з варыянтамі, [`Ok(T)`], які ўяўляе поспех і які змяшчае значэнне, і [`Err(E)`], які ўяўляе памылку і які змяшчае значэнне памылкі.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Функцыі вяртаюць [`Result`] кожны раз, калі чакаюцца памылкі і іх можна аднавіць.У `std` crate [`Result`] найбольш прыкметна выкарыстоўваецца для [I/O](../../std/io/index.html).
//!
//! Простая функцыя, якая вяртае [`Result`], можа быць вызначана і выкарыстана наступным чынам:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! Супадзенне шаблонаў у [`Result`] s зразумела і зразумела для простых выпадкаў, але [`Result`] пастаўляецца з некаторымі зручнымі метадамі, якія робяць працу з ім больш сціслай.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // Метады `is_ok` і `is_err` робяць тое, што кажуць.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` спажывае `Result` і вырабляе іншы.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // Выкарыстоўвайце `and_then`, каб працягнуць вылічэнні.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // Выкарыстоўвайце `or_else` для апрацоўкі памылкі.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Спажываем вынік і вяртаем змесціва з `unwrap`.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Трэба выкарыстоўваць вынікі
//!
//! Агульная праблема выкарыстання зваротных значэнняў для ўказання на памылкі заключаецца ў тым, што лёгка ігнараваць зваротнае значэнне, не атрымліваючыся апрацаваць памылку.
//! [`Result`] анатаваны атрыбутам `#[must_use]`, што прымусіць кампілятар выдаваць папярэджанне, калі значэнне Result ігнаруецца.
//! Гэта робіць [`Result`] асабліва карысным для функцый, якія могуць сутыкнуцца з памылкамі, але ў адваротным выпадку не вяртаюць карыснае значэнне.
//!
//! Разгледзім метад [`write_all`], вызначаны для тыпаў I/O з дапамогай [`Write`] Portrait:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: Фактычнае вызначэнне [`Write`] выкарыстоўвае [`io::Result`], што проста сінонім ["Вынік`]"<T,`[`io: :Error`]`>`.*
//!
//! Гэты метад не стварае значэння, але запіс можа пацярпець няўдачу.Вельмі важна апрацоўваць выпадак памылкі, а *не* пісаць нешта накшталт гэтага:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Калі памылкі `write_all`, мы ніколі не даведаемся, таму што зваротнае значэнне ігнаруецца.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Калі вы *зробіце*, напішаце, што ў Rust, кампілятар выдасць вам папярэджанне (па змаўчанні кантралюецца `unused_must_use` lint).
//!
//! Вы можаце замест гэтага, калі вы не хочаце апрацоўваць памылку, проста сцвердзіць поспех з [`expect`].
//! Гэта прывядзе да panic, калі запіс не атрымаецца, падаючы мінімальна карыснае паведамленне з указаннем, чаму:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! Вы таксама можаце проста сцвердзіць поспех:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! Або распаўсюдзьце памылку па стэку выклікаў з [`?`]:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # Аператар знака пытання, `?`
//!
//! Пры напісанні кода, які выклікае мноства функцый, якія вяртаюць тып [`Result`], апрацоўка памылак можа быць стомнай.
//! Аператар знака пытання, [`?`], хавае некаторыя ўзоры распаўсюджвання памылак у стэку выклікаў.
//!
//! Ён замяняе гэта:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Датэрміновае вяртанне памылкі
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! Пры гэтым:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Датэрміновае вяртанне памылкі
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *Гэта нашмат прыемней!*
//!
//! Заканчэнне выразу з [`?`] прывядзе да разгорнутага значэння поспеху ([`Ok`]), калі вынік не будзе [`Err`], у гэтым выпадку [`Err`] вяртаецца датэрмінова з функцыі, якая заключае.
//!
//!
//! [`?`] можа выкарыстоўвацца толькі ў функцыях, якія вяртаюць [`Result`] з-за ранняга вяртання [`Err`], якое ён прадастаўляе.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` гэта тып, які ўяўляе альбо поспех ([`Ok`]), альбо няўдачу ([`Err`]).
///
/// Падрабязнасці глядзіце ў [module documentation](self).
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// Змяшчае значэнне поспеху
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Змяшчае значэнне памылкі
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// Рэалізацыя тыпу
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // Запыт змешчаных значэнняў
    /////////////////////////////////////////////////////////////////////////

    /// Вяртае `true`, калі вынік [`Ok`].
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Вяртае `true`, калі вынік [`Err`].
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Вяртае `true`, калі вынікам з'яўляецца значэнне [`Ok`], якое змяшчае дадзенае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Вяртае `true`, калі вынікам з'яўляецца значэнне [`Err`], якое змяшчае дадзенае значэнне.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Адаптар для кожнага варыянту
    /////////////////////////////////////////////////////////////////////////

    /// Пераўтварае з `Result<T, E>` у [`Option<T>`].
    ///
    /// Пераўтварае `self` у [`Option<T>`], спажываючы `self`, і выдаляючы памылку, калі такая маецца.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// Пераўтварае з `Result<T, E>` у [`Option<E>`].
    ///
    /// Пераўтварае `self` у [`Option<E>`], спажываючы `self`, і адкідваючы значэнне поспеху, калі яно ёсць.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Перахаднік для працы са спасылкамі
    /////////////////////////////////////////////////////////////////////////

    /// Пераўтварае з `&Result<T, E>` у `Result<&T, &E>`.
    ///
    /// Выпускае новы `Result`, які змяшчае спасылку на арыгінал, пакідаючы арыгінал на месцы.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// Пераўтварае з `&mut Result<T, E>` у `Result<&mut T, &mut E>`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Пераўтварэнне змешчаных каштоўнасцей
    /////////////////////////////////////////////////////////////////////////

    /// Адпавядае `Result<T, E>` на `Result<U, E>`, ужываючы функцыю да змешчанага значэння [`Ok`], пакідаючы значэнне [`Err`] некранутым.
    ///
    ///
    /// Гэтая функцыя можа быць выкарыстана для складання вынікаў дзвюх функцый.
    ///
    /// # Examples
    ///
    /// Надрукуйце лічбы на кожным радку радка, памножанага на два.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// Прымяняе функцыю да змешчанага значэння (калі [`Ok`]), альбо вяртае ўказаны па змаўчанні (калі [`Err`]).
    ///
    /// Аргументы, перададзеныя ў `map_or`, з нецярпеннем ацэньваюцца;калі вы перадаеце вынік выкліку функцыі, рэкамендуецца выкарыстоўваць [`map_or_else`], які ляніва ацэньваецца.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// Адпавядае `Result<T, E>` на `U`, ужываючы функцыю да змешчанага значэння [`Ok`], альбо запасную функцыю да змешчанага значэння [`Err`].
    ///
    ///
    /// Гэтая функцыя можа быць выкарыстана для распакавання паспяховага выніку пры апрацоўцы памылкі.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// Адпавядае `Result<T, E>` на `Result<T, F>`, ужываючы функцыю да змешчанага значэння [`Err`], пакідаючы значэнне [`Ok`] некранутым.
    ///
    ///
    /// Гэтая функцыя можа быць выкарыстана для праходжання паспяховага выніку падчас апрацоўкі памылкі.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Канструктары ітэратараў
    /////////////////////////////////////////////////////////////////////////

    /// Вяртае ітэратар па магчымым змесце значэння.
    ///
    /// Ітэратар дае адно значэнне, калі вынік [`Result::Ok`], у адваротным выпадку няма.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Вяртае зменлівы ітэратар над магчыма змешчаным значэннем.
    ///
    /// Ітэратар дае адно значэнне, калі вынік [`Result::Ok`], у адваротным выпадку няма.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Логічныя аперацыі над каштоўнасцямі, ахвотныя і лянівыя
    /////////////////////////////////////////////////////////////////////////

    /// Вяртае `res`, калі вынік [`Ok`], у адваротным выпадку вяртае значэнне [`Err`] `self`.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Выклікае `op`, калі вынік [`Ok`], у адваротным выпадку вяртае значэнне [`Err`] `self`.
    ///
    ///
    /// Гэтая функцыя можа быць выкарыстана для кіравання патокам на аснове значэнняў `Result`.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Вяртае `res`, калі вынік [`Err`], у адваротным выпадку вяртае значэнне [`Ok`] `self`.
    ///
    /// Аргументы, перададзеныя ў `or`, з нецярпеннем ацэньваюцца;калі вы перадаеце вынік выкліку функцыі, рэкамендуецца выкарыстоўваць [`or_else`], які ляніва ацэньваецца.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Выклікае `op`, калі вынік [`Err`], у адваротным выпадку вяртае значэнне [`Ok`] `self`.
    ///
    ///
    /// Гэтая функцыя можа быць выкарыстана для кіравання патокам на аснове значэнняў выніку.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// Вяртае якое змяшчаецца значэнне [`Ok`] альбо прадастаўленае па змаўчанні.
    ///
    /// Аргументы, перададзеныя ў `unwrap_or`, з нецярпеннем ацэньваюцца;калі вы перадаеце вынік выкліку функцыі, рэкамендуецца выкарыстоўваць [`unwrap_or_else`], які ляніва ацэньваецца.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// Вяртае змешчанае значэнне [`Ok`] альбо вылічвае яго з закрыцця.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// Вяртае змешчанае значэнне [`Ok`], спажываючы значэнне `self`, не правяраючы, што значэнне не з'яўляецца [`Err`].
    ///
    ///
    /// # Safety
    ///
    /// Выклік гэтага метаду на [`Err`]-гэта *[нявызначанае паводзіны]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Неакрэсленыя паводзіны!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// Вяртае змешчанае значэнне [`Err`], спажываючы значэнне `self`, не правяраючы, што значэнне не з'яўляецца [`Ok`].
    ///
    ///
    /// # Safety
    ///
    /// Выклік гэтага метаду на [`Ok`]-гэта *[нявызначанае паводзіны]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Неакрэсленыя паводзіны!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// Адлюстраванне `Result<&T, E>` да `Result<T, E>` шляхам капіравання змесціва часткі `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// Адлюстраванне `Result<&mut T, E>` да `Result<T, E>` шляхам капіравання змесціва часткі `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// Адлюстраванне `Result<&T, E>` у `Result<T, E>` шляхам кланавання змесціва часткі `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// Адлюстраванне `Result<&mut T, E>` у `Result<T, E>` шляхам кланавання змесціва часткі `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// Вяртае змешчанае значэнне [`Ok`], спажываючы значэнне `self`.
    ///
    /// # Panics
    ///
    /// Panics, калі значэнне [`Err`], з паведамленнем panic, уключаючы перададзенае паведамленне, і змесцівам [`Err`].
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// Вяртае змешчанае значэнне [`Ok`], спажываючы значэнне `self`.
    ///
    /// Паколькі гэтая функцыя можа panic, яе выкарыстанне, як правіла, не рэкамендуецца.
    /// Замест гэтага аддайце перавагу выкарыстоўваць супадзенне шаблонаў і відавочна апрацоўваць выпадак [`Err`], альбо патэлефануйце ў [`unwrap_or`], [`unwrap_or_else`] ці [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics, калі значэнне [`Err`], з паведамленнем panic, якое прадастаўляецца значэннем [`Err`].
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// Вяртае змешчанае значэнне [`Err`], спажываючы значэнне `self`.
    ///
    /// # Panics
    ///
    /// Panics, калі значэнне [`Ok`], з паведамленнем panic, уключаючы перададзенае паведамленне, і змесцівам [`Ok`].
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// Вяртае змешчанае значэнне [`Err`], спажываючы значэнне `self`.
    ///
    /// # Panics
    ///
    /// Panics, калі значэнне [`Ok`], з карыстацкім паведамленнем panic, прадастаўленым значэннем [`Ok`].
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// Вяртае якое змяшчаецца значэнне [`Ok`] альбо па змаўчанні
    ///
    /// Спажывае аргумент `self`, тады, калі [`Ok`], вяртае змешчанае значэнне, у адваротным выпадку, калі [`Err`], вяртае значэнне па змаўчанні для гэтага тыпу.
    ///
    ///
    /// # Examples
    ///
    /// Пераўтварае радок у цэлае, ператвараючы дрэнна сфармаваныя радкі ў 0 (значэнне па змаўчанні для цэлых лікаў).
    /// [`parse`] пераўтворыць радок у любы іншы тып, які рэалізуе [`FromStr`], вяртаючы [`Err`] пры памылцы.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// Вяртае змешчанае значэнне [`Ok`], але ніколі не panics.
    ///
    /// У адрозненне ад [`unwrap`], гэты метад, як вядома, ніколі не panic для тыпаў вынікаў, для якіх ён рэалізаваны.
    /// Такім чынам, ён можа быць выкарыстаны замест `unwrap` у якасці гарантыі рамонту, які не будзе скампіляваны, калі тып памылкі `Result` пазней зменіцца на памылку, якая можа рэальна ўзнікнуць.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// Пераўтварае з `Result<T, E>` (альбо `&Result<T, E>`) у `Result<&<T as Deref>::Target, &E>`.
    ///
    /// Прымушае варыянт [`Ok`] зыходнага [`Result`] праз [`Deref`](crate::ops::Deref) і вяртае новы [`Result`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// Пераўтварае з `Result<T, E>` (альбо `&mut Result<T, E>`) у `Result<&mut <T as DerefMut>::Target, &mut E>`.
    ///
    /// Прымушае варыянт [`Ok`] зыходнага [`Result`] праз [`DerefMut`](crate::ops::DerefMut) і вяртае новы [`Result`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// Транспануе `Result` з `Option` у `Option` з `Result`.
    ///
    /// `Ok(None)` будзе адлюстравана на `None`.
    /// `Ok(Some(_))` і `Err(_)` будзе супастаўлены з `Some(Ok(_))` і `Some(Err(_))`.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// Пераўтварае з `Result<Result<T, E>, E>` у `Result<T, E>`
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Пляшчота выдаляе толькі адзін узровень гнездавання адначасова:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// Вяртае значэнне [`Ok`], калі `self` роўна `Ok`, і значэнне [`Err`], калі `self` роўна `Err`.
    ///
    /// Іншымі словамі, гэтая функцыя вяртае значэнне (`T`) `Result<T, T>`, незалежна ад таго, ці з'яўляецца гэты вынік `Ok` ці `Err`.
    ///
    /// Гэта можа быць карысна ў спалучэнні з API, такімі як [`Atomic*::compare_exchange`] або [`slice::binary_search`], але толькі ў тых выпадках, калі вам усё роўна, вынік быў `Ok` ці не.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// Гэта асобная функцыя для памяншэння памеру кода метадаў
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Рэалізацыі Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Вяртае спажывальны ітэратар па магчымаму змешчанаму значэнню.
    ///
    /// Ітэратар дае адно значэнне, калі вынік [`Result::Ok`], у адваротным выпадку няма.
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ітэратары вынікаў
/////////////////////////////////////////////////////////////////////////////

/// Ітэратар над спасылкай на варыянт [`Ok`] [`Result`].
///
/// Ітэратар дае адно значэнне, калі вынік [`Ok`], у адваротным выпадку няма.
///
/// Створана [`Result::iter`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// Ітэратар над зменлівай спасылкай на варыянт [`Ok`] [`Result`].
///
/// Створана [`Result::iter_mut`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Ітэратар над значэннем у варыянце [`Result`] [`Result`].
///
/// Ітэратар дае адно значэнне, калі вынік [`Ok`], у адваротным выпадку няма.
///
/// Гэтая структура створана метадам [`into_iter`] на [`Result`] (забяспечана [`IntoIterator`] Portrait).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// Прымае кожны элемент у `Iterator`: калі гэта `Err`, далейшыя элементы не бяруцца, і `Err` вяртаецца.
    /// Калі `Err` не адбываецца, вяртаецца кантэйнер са значэннямі кожнага `Result`.
    ///
    /// Вось прыклад, які павялічвае кожнае цэлае ў vector, правяраючы перапаўненне:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// Вось яшчэ адзін прыклад, які спрабуе адняць адзін з іншага спісу цэлых лікаў, на гэты раз правяраючы наяўнасць недахопу:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// Вось варыянт папярэдняга прыкладу, які паказвае, што з `iter` пасля першага `Err` не бяруцца дадатковыя элементы.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Паколькі трэці элемент выклікаў недапушчэнне, дадатковыя элементы не былі прыняты, таму канчатковае значэнне `shared` роўна 6 (= `3 + 2 + 1`), а не 16.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Гэта можа быць заменена на Iterator::scan, калі гэтая памылка прадукцыйнасці будзе закрыта.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}