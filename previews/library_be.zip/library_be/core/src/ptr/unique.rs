use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Абгортка вакол сырога не нулявога `*mut T`, якая паказвае, што ўладальнік гэтай абгорткі валодае рэферэнтам.
/// Карысна для стварэння такіх абстракцый, як `Box<T>`, `Vec<T>`, `String` і `HashMap<K, V>`.
///
/// У адрозненне ад `*mut T`, `Unique<T>` паводзіць сябе "as if", гэта быў асобнік `T`.
/// Ён рэалізуе `Send`/`Sync`, калі `T`-гэта `Send`/`Sync`.
/// Гэта таксама прадугледжвае выгляд моцных псеўданімаў, якія можа чакаць асобнік `T`:
/// рэферэнт паказальніка не павінен быць зменены без унікальнага шляху да ўласнага Unique.
///
/// Калі вы не ўпэўненыя, ці правільна выкарыстоўваць `Unique` для сваіх мэтаў, падумайце аб выкарыстанні `NonNull`, які мае больш слабую семантыку.
///
///
/// У адрозненне ад `*mut T`, паказальнік заўсёды павінен быць ненулевым, нават калі ўказальнік ніколі не дэрэферэндаваны.
/// Гэта так, што пералічаныя могуць выкарыстоўваць гэта забароненае значэнне ў якасці дыскрымінанта-`Option<Unique<T>>` мае той жа памер, што і `Unique<T>`.
/// Аднак паказальнік можа па-ранейшаму вісець, калі ён не разыменаваны.
///
/// У адрозненне ад `*mut T`, `Unique<T>` з'яўляецца каварыянтнай у параўнанні з `T`.
/// Гэта заўсёды павінна быць правільна для любога тыпу, які адпавядае псеўданімным патрабаванням Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: гэты маркер не мае наступстваў для дысперсіі, але неабходны
    // для dropck, каб зразумець, што мы лагічна валодаем `T`.
    //
    // Падрабязнасці глядзіце:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` паказальнікі `Send`, калі `T` `Send`, таму што дадзеныя, на якія яны спасылаюцца, недаступныя.
/// Звярніце ўвагу, што гэты намяняльны інварыянт не выконваецца сістэмай тыпаў;абстракцыя з выкарыстаннем `Unique` павінна прымушаць яго.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` паказальнікі `Sync`, калі `T` `Sync`, таму што дадзеныя, на якія яны спасылаюцца, недаступныя.
/// Звярніце ўвагу, што гэты намяняльны інварыянт не выконваецца сістэмай тыпаў;абстракцыя з выкарыстаннем `Unique` павінна прымушаць яго.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Стварае новы `Unique`, які вісіць, але добра выраўнаваны.
    ///
    /// Гэта карысна для ініцыялізацыі тыпаў, якія ляніва выдзяляюць, як гэта робіць `Vec::new`.
    ///
    /// Звярніце ўвагу, што значэнне паказальніка можа патэнцыйна прадстаўляць сапраўдны паказальнік на `T`, а гэта значыць, што яно не павінна выкарыстоўвацца ў якасці вартавога "not yet initialized".
    /// Тыпы, якія ляніва выдзяляюць, павінны адсочваць ініцыялізацыю іншымі спосабамі.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // БЯСПЕКА: mem::align_of() вяртае сапраўдны, не нулявы паказальнік.
        // Такім чынам, паважаюцца ўмовы выкліку new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Стварае новы `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` павінна быць роўнай нулю.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЯСПЕКА: абанент павінен гарантаваць, што `ptr` не з'яўляецца нулявым.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Стварае новы `Unique`, калі `ptr` не з'яўляецца нулявым.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЯСПЕКА: Указальнік ужо правераны і не з'яўляецца нулявым.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Атрымлівае асноўны паказальнік `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Адсылае змест зместу.
    ///
    /// Атрыманы тэрмін службы звязаны з самім сабой, таму гэта паводзіць сябе "as if", на самой справе гэта быў асобнік T, які пазычаецца.
    /// Калі патрабуецца большы тэрмін службы (unbound), выкарыстоўвайце `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЯСПЕКА: абанент павінен гарантаваць, што `self` адпавядае ўсім патрабаванням
        // патрабаванні да спасылкі.
        unsafe { &*self.as_ptr() }
    }

    /// Змяняецца перанакіраванне змесціва.
    ///
    /// Атрыманы тэрмін службы звязаны з самім сабой, таму гэта паводзіць сябе "as if", на самой справе гэта быў асобнік T, які пазычаецца.
    /// Калі патрабуецца большы тэрмін службы (unbound), выкарыстоўвайце `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЯСПЕКА: абанент павінен гарантаваць, што `self` адпавядае ўсім патрабаванням
        // патрабаванні да зменнай спасылкі.
        unsafe { &mut *self.as_ptr() }
    }

    /// Прыводзіць у паказальнік іншага тыпу.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // БЯСПЕКА: Unique::new_unchecked() стварае новы унікальны і патрэбны
        // дадзены паказальнік не павінен быць нулявым.
        // Паколькі мы перадаем self як паказальнік, ён не можа быць нулявым.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЯСПЕКА: Зменлівая спасылка не можа быць нулявой
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}