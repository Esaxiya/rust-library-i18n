use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` але ненулявы і каварыянтны.
///
/// Часта гэта правільна выкарыстоўваць пры пабудове структур дадзеных з выкарыстаннем сырых указальнікаў, але ў канчатковым рахунку больш небяспечна ў сувязі з яго дадатковымі ўласцівасцямі.Калі вы не ўпэўненыя, ці варта вам выкарыстоўваць `NonNull<T>`, проста выкарыстоўвайце `*mut T`!
///
/// У адрозненне ад `*mut T`, паказальнік заўсёды павінен быць ненулевым, нават калі ўказальнік ніколі не дэрэферэндаваны.Гэта так, што пералічаныя могуць выкарыстоўваць гэта забароненае значэнне ў якасці дыскрымінанта-`Option<NonNull<T>>` мае той самы памер, што і `* mut T`.
/// Аднак паказальнік можа па-ранейшаму вісець, калі ён не разыменаваны.
///
/// У адрозненне ад `*mut T`, `NonNull<T>` абраны каварыянтным у параўнанні з `T`.Гэта дазваляе выкарыстоўваць `NonNull<T>` пры пабудове каварыянтных тыпаў, але стварае рызыку разгружанасці пры выкарыстанні ў тыпе, які на самой справе не павінен быць каварыянтным.
/// (Для `*mut T` быў зроблены супрацьлеглы выбар, хаця тэхнічна несапраўднасць магла быць выклікана толькі выкліканнем небяспечных функцый.)
///
/// Каварыянтнасць правільная для большасці бяспечных абстракцый, такіх як `Box`, `Rc`, `Arc`, `Vec` і `LinkedList`.Гэта так, таму што яны прадастаўляюць агульнадаступны API, які прытрымліваецца звычайных агульных XOR-зменных правілаў Rust.
///
/// Калі ваш тып не можа быць бяспечна каварыянтным, вы павінны пераканацца, што ён змяшчае нейкае дадатковае поле для забеспячэння нязменнасці.Часта гэта поле будзе тыпу [`PhantomData`], напрыклад `PhantomData<Cell<T>>` або `PhantomData<&'a mut T>`.
///
/// Звярніце ўвагу, што `NonNull<T>` мае экземпляр `From` для `&T`.Аднак гэта не мяняе таго факту, што мутацыя праз (паказальнік, атрыманы з) агульнай спасылкі, не вызначана, калі мутацыя не адбываецца ўнутры [`UnsafeCell<T>`].Тое ж самае тычыцца стварэння зменнай спасылкі з агульнай спасылкі.
///
/// Пры выкарыстанні гэтага экземпляра `From` без `UnsafeCell<T>` вы нясеце адказнасць за тое, каб `as_mut` ніколі не выклікаўся, а `as_ptr` ніколі не выкарыстоўваўся для мутацыі.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` паказальнікі не з'яўляюцца `Send`, таму што дадзеныя, на якія яны спасылаюцца, могуць быць сакрэтнымі.
// Звярніце ўвагу, гэты impl непатрэбны, але павінен даць лепшыя паведамленні пра памылкі.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` паказальнікі не з'яўляюцца `Sync`, таму што дадзеныя, на якія яны спасылаюцца, могуць быць сакрэтнымі.
// Звярніце ўвагу, гэты impl непатрэбны, але павінен даць лепшыя паведамленні пра памылкі.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Стварае новы `NonNull`, які вісіць, але добра выраўнаваны.
    ///
    /// Гэта карысна для ініцыялізацыі тыпаў, якія ляніва выдзяляюць, як гэта робіць `Vec::new`.
    ///
    /// Звярніце ўвагу, што значэнне паказальніка можа патэнцыйна прадстаўляць сапраўдны паказальнік на `T`, а гэта значыць, што яно не павінна выкарыстоўвацца ў якасці вартавога "not yet initialized".
    /// Тыпы, якія ляніва выдзяляюць, павінны адсочваць ініцыялізацыю іншымі спосабамі.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // БЯСПЕКА: mem::align_of() вяртае ненулявы памер, які потым адліваецца
        // да * мута Т.
        // Такім чынам, `ptr` не з'яўляецца нулявым і ўмовы для выкліку new_unchecked() выконваюцца.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Вяртае агульныя спасылкі на значэнне.У адрозненне ад [`as_ref`] для гэтага не патрабуецца ініцыялізацыя значэння.
    ///
    /// Зменлівы аналаг гл. [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Пры выкліку гэтага метаду вы павінны пераканацца, што ўсё наступнае адпавядае рэчаіснасці:
    ///
    /// * Паказальнік павінен быць правільна выраўнаваны.
    ///
    /// * Гэта павінен быць "dereferencable" у тым сэнсе, які вызначаны ў [the module documentation].
    ///
    /// * Вы павінны забяспечыць захаванне правіл псеўданіма Rust, паколькі вернуты тэрмін службы `'a` абраны адвольна і не абавязкова адлюстроўвае фактычны тэрмін службы дадзеных.
    ///
    ///   У прыватнасці, на працягу ўсяго жыцця памяць, на якую паказвае паказальнік, не павінна мутаваць (за выключэннем унутры `UnsafeCell`).
    ///
    /// Гэта датычыцца, нават калі вынік гэтага метаду не выкарыстоўваецца!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // БЯСПЕКА: абанент павінен гарантаваць, што `self` адпавядае ўсім патрабаванням
        // патрабаванні да спасылкі.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Вяртае ўнікальныя спасылкі на значэнне.У адрозненне ад [`as_mut`] для гэтага не патрабуецца ініцыялізацыя значэння.
    ///
    /// Інфармацыю пра агульны аналог гл. [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Пры выкліку гэтага метаду вы павінны пераканацца, што ўсё наступнае адпавядае рэчаіснасці:
    ///
    /// * Паказальнік павінен быць правільна выраўнаваны.
    ///
    /// * Гэта павінен быць "dereferencable" у тым сэнсе, які вызначаны ў [the module documentation].
    ///
    /// * Вы павінны забяспечыць захаванне правіл псеўданіма Rust, паколькі вернуты тэрмін службы `'a` абраны адвольна і не абавязкова адлюстроўвае фактычны тэрмін службы дадзеных.
    ///
    ///   У прыватнасці, на працягу ўсяго жыцця памяць, на якую паказвае паказальнік, не павінна атрымліваць доступ (чытаць альбо пісаць) праз любы іншы паказальнік.
    ///
    /// Гэта датычыцца, нават калі вынік гэтага метаду не выкарыстоўваецца!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // БЯСПЕКА: абанент павінен гарантаваць, што `self` адпавядае ўсім патрабаванням
        // патрабаванні да спасылкі.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Стварае новы `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` павінна быць роўнай нулю.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЯСПЕКА: абанент павінен гарантаваць, што `ptr` не з'яўляецца нулявым.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Стварае новы `NonNull`, калі `ptr` не з'яўляецца нулявым.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЯСПЕКА: Указальнік ужо правераны і не з'яўляецца нулявым
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Выконвае тую ж функцыянальнасць, што і [`std::ptr::from_raw_parts`], за выключэннем таго, што вяртаецца паказальнік `NonNull`, у адрозненне ад сырога паказальніка `*const`.
    ///
    ///
    /// Для больш падрабязнай інфармацыі глядзіце дакументацыю [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // БЯСПЕКА: Вынік `ptr::from::raw_parts_mut` не з'яўляецца нулявым, таму што `data_address` ёсць.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Разбярыце (магчыма, шырокі) паказальнік на адрас і кампаненты метададзеных.
    ///
    /// Пазней паказальнік можна аднавіць з дапамогай [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Атрымлівае асноўны паказальнік `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Вяртае агульную спасылку на значэнне.Калі значэнне можа быць неініцыялізавана, замест яго трэба выкарыстоўваць [`as_uninit_ref`].
    ///
    /// Зменлівы аналаг гл. [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Пры выкліку гэтага метаду вы павінны пераканацца, што ўсё наступнае адпавядае рэчаіснасці:
    ///
    /// * Паказальнік павінен быць правільна выраўнаваны.
    ///
    /// * Гэта павінен быць "dereferencable" у тым сэнсе, які вызначаны ў [the module documentation].
    ///
    /// * Паказальнік павінен паказваць на ініцыялізаваны асобнік `T`.
    ///
    /// * Вы павінны забяспечыць захаванне правіл псеўданіма Rust, паколькі вернуты тэрмін службы `'a` абраны адвольна і не абавязкова адлюстроўвае фактычны тэрмін службы дадзеных.
    ///
    ///   У прыватнасці, на працягу ўсяго жыцця памяць, на якую паказвае паказальнік, не павінна мутаваць (за выключэннем унутры `UnsafeCell`).
    ///
    /// Гэта датычыцца, нават калі вынік гэтага метаду не выкарыстоўваецца!
    /// (Частка пра ініцыялізацыю яшчэ не вырашана да канца, але пакуль гэта не так, адзіным бяспечным падыходам з'яўляецца забеспячэнне таго, каб яны сапраўды былі ініцыялізаваны.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЯСПЕКА: абанент павінен гарантаваць, што `self` адпавядае ўсім патрабаванням
        // патрабаванні да спасылкі.
        unsafe { &*self.as_ptr() }
    }

    /// Вяртае ўнікальную спасылку на значэнне.Калі значэнне можа быць неініцыялізавана, замест яго трэба выкарыстоўваць [`as_uninit_mut`].
    ///
    /// Інфармацыю пра агульны аналог гл. [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Пры выкліку гэтага метаду вы павінны пераканацца, што ўсё наступнае адпавядае рэчаіснасці:
    ///
    /// * Паказальнік павінен быць правільна выраўнаваны.
    ///
    /// * Гэта павінен быць "dereferencable" у тым сэнсе, які вызначаны ў [the module documentation].
    ///
    /// * Паказальнік павінен паказваць на ініцыялізаваны асобнік `T`.
    ///
    /// * Вы павінны забяспечыць захаванне правіл псеўданіма Rust, паколькі вернуты тэрмін службы `'a` абраны адвольна і не абавязкова адлюстроўвае фактычны тэрмін службы дадзеных.
    ///
    ///   У прыватнасці, на працягу ўсяго жыцця памяць, на якую паказвае паказальнік, не павінна атрымліваць доступ (чытаць альбо пісаць) праз любы іншы паказальнік.
    ///
    /// Гэта датычыцца, нават калі вынік гэтага метаду не выкарыстоўваецца!
    /// (Частка пра ініцыялізацыю яшчэ не вырашана да канца, але пакуль гэта не так, адзіным бяспечным падыходам з'яўляецца забеспячэнне таго, каб яны сапраўды былі ініцыялізаваны.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЯСПЕКА: абанент павінен гарантаваць, што `self` адпавядае ўсім патрабаванням
        // патрабаванні да зменнай спасылкі.
        unsafe { &mut *self.as_ptr() }
    }

    /// Прыводзіць у паказальнік іншага тыпу.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // БЯСПЕКА: `self`-гэта паказальнік `NonNull`, які абавязкова не з'яўляецца нулявым
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Стварае ненулявы зрэз з тонкага паказальніка і даўжыні.
    ///
    /// Аргумент `len`-гэта колькасць **элементаў**, а не колькасць байтаў.
    ///
    /// Гэтая функцыя бяспечная, але адсылка да зваротнага значэння небяспечная.
    /// Паглядзіце патрабаванні бяспекі зрэзаў у дакументацыі [`slice::from_raw_parts`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // стварыць паказальнік на зрэз, пачынаючы з указальніка на першы элемент
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Звярніце ўвагу, што гэты прыклад штучна дэманструе выкарыстанне гэтага метаду, але `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // БЯСПЕКА: `data`-гэта паказальнік `NonNull`, які абавязкова не з'яўляецца нулявым
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Вяртае даўжыню ненулявога сырога зрэзу.
    ///
    /// Вяртаецца значэнне-гэта колькасць **элементаў**, а не колькасць байтаў.
    ///
    /// Гэтая функцыя бяспечная, нават калі неадпаведны зрэз не можа быць перанакіраваны на зрэз, паколькі ўказальнік не мае правільнага адраса.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Вяртае ненулевы паказальнік на буфер зрэзу.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // БЯСПЕКА: Мы ведаем, што `self` не з'яўляецца нулявым.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Вяртае неапрацаваны паказальнік на буфер зрэзу.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Вяртае агульную спасылку на зрэз магчыма неініцыялізаваных значэнняў.У адрозненне ад [`as_ref`] для гэтага не патрабуецца ініцыялізацыя значэння.
    ///
    /// Зменлівы аналаг гл. [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Пры выкліку гэтага метаду вы павінны пераканацца, што ўсё наступнае адпавядае рэчаіснасці:
    ///
    /// * Паказальнік павінен быць [valid] для чытання шматбайт `ptr.len() * mem::size_of::<T>()`, і ён павінен быць правільна выраўнаваны.Гэта, у прыватнасці, азначае:
    ///
    ///     * Увесь дыяпазон памяці гэтага зрэзу павінен змяшчацца ў адным выдзеленым аб'екце!
    ///       Зрэзы ніколі не могуць ахопліваць некалькі выдзеленых аб'ектаў.
    ///
    ///     * Паказальнік павінен быць выраўнаваны нават для зрэзаў нулявой даўжыні.
    ///     Адна з прычын гэтага заключаецца ў тым, што аптымізацыя макета пералічэння можа спадзявацца на выраўноўванне спасылак (уключаючы зрэзы любой даўжыні) і ненулявых значэнняў, каб адрозніць іх ад іншых дадзеных.
    ///
    ///     Вы можаце атрымаць паказальнік, які можна выкарыстоўваць як `data` для зрэзаў нулявой даўжыні, выкарыстоўваючы [`NonNull::dangling()`].
    ///
    /// * Агульны памер зрэзу `ptr.len() * mem::size_of::<T>()` не павінен перавышаць `isize::MAX`.
    ///   Глядзіце дакументацыю па бяспецы [`pointer::offset`].
    ///
    /// * Вы павінны забяспечыць захаванне правіл псеўданіма Rust, паколькі вернуты тэрмін службы `'a` абраны адвольна і не абавязкова адлюстроўвае фактычны тэрмін службы дадзеных.
    ///   У прыватнасці, на працягу ўсяго жыцця памяць, на якую паказвае паказальнік, не павінна мутаваць (за выключэннем унутры `UnsafeCell`).
    ///
    /// Гэта датычыцца, нават калі вынік гэтага метаду не выкарыстоўваецца!
    ///
    /// Глядзіце таксама [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Вяртае ўнікальную спасылку на зрэз магчыма неініцыялізаваных значэнняў.У адрозненне ад [`as_mut`] для гэтага не патрабуецца ініцыялізацыя значэння.
    ///
    /// Інфармацыю пра агульны аналог гл. [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Пры выкліку гэтага метаду вы павінны пераканацца, што ўсё наступнае адпавядае рэчаіснасці:
    ///
    /// * Паказальнік павінен быць [valid] для чытання і запісу для `ptr.len() * mem::size_of::<T>()` шмат байт, і ён павінен быць правільна выраўнаваны.Гэта, у прыватнасці, азначае:
    ///
    ///     * Увесь дыяпазон памяці гэтага зрэзу павінен змяшчацца ў адным выдзеленым аб'екце!
    ///       Зрэзы ніколі не могуць ахопліваць некалькі выдзеленых аб'ектаў.
    ///
    ///     * Паказальнік павінен быць выраўнаваны нават для зрэзаў нулявой даўжыні.
    ///     Адна з прычын гэтага заключаецца ў тым, што аптымізацыя макета пералічэння можа спадзявацца на выраўноўванне спасылак (уключаючы зрэзы любой даўжыні) і ненулявых значэнняў, каб адрозніць іх ад іншых дадзеных.
    ///
    ///     Вы можаце атрымаць паказальнік, які можна выкарыстоўваць як `data` для зрэзаў нулявой даўжыні, выкарыстоўваючы [`NonNull::dangling()`].
    ///
    /// * Агульны памер зрэзу `ptr.len() * mem::size_of::<T>()` не павінен перавышаць `isize::MAX`.
    ///   Глядзіце дакументацыю па бяспецы [`pointer::offset`].
    ///
    /// * Вы павінны забяспечыць захаванне правіл псеўданіма Rust, паколькі вернуты тэрмін службы `'a` абраны адвольна і не абавязкова адлюстроўвае фактычны тэрмін службы дадзеных.
    ///   У прыватнасці, на працягу ўсяго жыцця памяць, на якую паказвае паказальнік, не павінна атрымліваць доступ (чытаць альбо пісаць) праз любы іншы паказальнік.
    ///
    /// Гэта датычыцца, нават калі вынік гэтага метаду не выкарыстоўваецца!
    ///
    /// Глядзіце таксама [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Гэта бяспечна, паколькі `memory` сапраўдны для чытання і запісу для многіх байт `memory.len()`.
    /// // Звярніце ўвагу, што выклік `memory.as_mut()` тут забаронены, бо змест можа быць неініцыялізаваны.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Вяртае неапрацаваны паказальнік на элемент альбо падразак без праверкі межаў.
    ///
    /// Выклік гэтага метаду з індэксам, які выходзіць за межы, альбо калі `self` немагчыма разабраць, гэта *[нявызначанае паводзіны]*, нават калі атрыманы паказальнік не выкарыстоўваецца.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // БЯСПЕКА: абанент гарантуе, што `self` не паддаецца спасылцы і `index` знаходзіцца ў межах.
        // Як следства, атрыманы паказальнік не можа быць роўны NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // БЯСПЕКА: Унікальны паказальнік не можа быць роўны нулю, таму ўмовы для
        // new_unchecked() паважаюць.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЯСПЕКА: Зменлівая спасылка не можа быць нулявой.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // БЯСПЕКА: спасылка не можа быць нулявой, таму ўмовы для
        // new_unchecked() паважаюць.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}