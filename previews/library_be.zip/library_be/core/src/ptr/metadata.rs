#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Забяспечвае тып метададзеных указальніка любога накіраванага тыпу.
///
/// # Метаданыя паказальніка
///
/// Тыпы сырых паказальнікаў і даведачныя тыпы ў Rust можна разглядаць як зробленыя з дзвюх частак:
/// паказальнік дадзеных, які змяшчае адрас памяці значэння і некаторыя метаданыя.
///
/// Для тыпаў са статычным памерам (якія рэалізуюць `Sized` traits), а таксама для тыпаў `extern`, паказальнікі называюцца "тонкімі": метаданыя маюць нулявы памер, а іх тып-`()`.
///
///
/// Указальнікі на [dynamically-sized types][dst] называюцца "шырокімі" альбо "тлустымі", у іх ёсць метаданыя не нулявога памеру:
///
/// * Для структур, апошняе поле якіх-DST, метаданыя-гэта метаданыя апошняга поля
/// * Для тыпу `str` метададзеныя-гэта даўжыня ў байтах як `usize`
/// * Для тыпаў зрэзаў, такіх як `[T]`, метададзеныя-гэта даўжыня элементаў як `usize`
/// * Для аб'ектаў Portrait, такіх як `dyn SomeTrait`, метададзеныя-[`DynMetadata<Self>`][DynMetadata] (напрыклад, `DynMetadata<dyn SomeTrait>`)
///
/// У future мова Rust можа атрымаць новыя віды тыпаў, якія маюць розныя метаданыя паказальніка.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` Portrait
///
/// Сэнс гэтага Portrait-гэта звязаны з `Metadata` тып, які з'яўляецца `()`, `usize` альбо `DynMetadata<_>`, як апісана вышэй.
/// Ён аўтаматычна рэалізуецца для любога тыпу.
/// Можна меркаваць, што гэта можа быць рэалізавана ў агульным кантэксце, нават без адпаведнай сувязі.
///
/// # Usage
///
/// Неапрацаваныя паказальнікі можна раскласці на адрасы дадзеных і кампаненты метададзеных метадам [`to_raw_parts`].
///
/// У якасці альтэрнатывы метададзеныя можна атрымаць толькі з дапамогай функцыі [`metadata`].
/// Спасылка можа перадавацца на [`metadata`] і імпліцытна прымушацца.
///
/// Паказальнік (possibly-wide) можна скласці з адраса і метададзеных з [`from_raw_parts`] або [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Тып для метададзеных у паказальніках і спасылкі на `Self`.
    #[lang = "metadata_type"]
    // NOTE: Трымайце Portrait bounds у `static_assert_expected_bounds_for_metadata`
    //
    // у `library/core/src/ptr/metadata.rs` сінхранізавана з тымі, што тут:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Паказальнікі на тыпы, якія рэалізуюць гэты псеўданім Portrait, "тонкія".
///
/// Сюды ўваходзяць тыпы са статычным памерам і тыпы `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: не стабілізаваць гэта да таго, як псеўданімы Portrait будуць стабільнымі ў мове?
pub trait Thin = Pointee<Metadata = ()>;

/// Вылучыце кампанент метададзеных паказальніка.
///
/// Значэнні тыпу `*mut T`, `&T` або `&mut T` могуць быць перададзены непасрэдна гэтай функцыі, паколькі яны імпліцытна прымушаюць `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // БЯСПЕКА: Доступ да значэння з аб'яднання `PtrRepr` бяспечны, бо * const T
    // і PtrComponents<T>маюць аднолькавыя макеты памяці.
    // Гэтую гарантыю можа даць толькі std.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Фарміруе неапрацаваны паказальнік (possibly-wide) з адраса дадзеных і метададзеных.
///
/// Гэтая функцыя бяспечная, але зваротны паказальнік не абавязкова бяспечны для аднаўлення.
/// Зрэзы глядзіце ў дакументацыі [`slice::from_raw_parts`], каб даведацца пра патрабаванні бяспекі.
/// Для аб'ектаў Portrait метаданыя павінны паступаць з паказальніка на той самы асноўны сцёрты тып.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // БЯСПЕКА: Доступ да значэння з аб'яднання `PtrRepr` бяспечны, бо * const T
    // і PtrComponents<T>маюць аднолькавыя макеты памяці.
    // Гэтую гарантыю можа даць толькі std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Выконвае тую ж функцыянальнасць, што і [`from_raw_parts`], за выключэннем таго, што вяртаецца неапрацаваны паказальнік `*mut`, у адрозненне ад сырога паказальніка `* const`.
///
///
/// Для больш падрабязнай інфармацыі глядзіце дакументацыю [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // БЯСПЕКА: Доступ да значэння з аб'яднання `PtrRepr` бяспечны, бо * const T
    // і PtrComponents<T>маюць аднолькавыя макеты памяці.
    // Гэтую гарантыю можа даць толькі std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Уручную impl неабходна, каб пазбегнуць `T: Copy` звязаны.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Уручную impl неабходна, каб пазбегнуць `T: Clone` звязаны.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Метаданыя для тыпу аб'екта `Dyn = dyn SomeTrait` Portrait.
///
/// Гэта паказальнік на vtable (віртуальная табліца выклікаў), які ўяўляе ўсю неабходную інфармацыю для маніпуляцыі з канкрэтным тыпам, які захоўваецца ў аб'екце Portrait.
/// Vtable, у прыватнасці, ён змяшчае:
///
/// * памер тыпу
/// * выраўноўванне тыпу
/// * паказальнік на імпл `drop_in_place` тыпу (можа быць недапушчальным для простых-старых дадзеных)
/// * паказвае на ўсе метады рэалізацыі тыпу Portrait
///
/// Звярніце ўвагу, што першыя тры спецыяльныя, таму што яны неабходныя для выдзялення, выпадзення і вызвалення любога аб'екта Portrait.
///
/// Можна назваць гэтую структуру параметрам тыпу, які не з'яўляецца аб'ектам `dyn` Portrait (напрыклад, `DynMetadata<u64>`), але не атрымаць значнае значэнне гэтай структуры.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Агульны прэфікс усіх vtables.За ім ідуць паказальнікі на функцыі для метадаў Portrait.
///
/// Прыватная дэталь рэалізацыі `DynMetadata::size_of` і г.д.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Вяртае памер тыпу, звязанага з гэтай vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Вяртае выраўноўванне тыпу, звязанага з гэтай vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Вяртае памер і выраўноўванне ў выглядзе `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // БЯСПЕКА: кампілятар выпусціў гэтую vtable для канкрэтнага тыпу Rust, які
        // вядома, што ён мае сапраўдны макет.Такое ж абгрунтаванне, як і ў `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ручныя імпульсы, неабходныя, каб пазбегнуць межаў `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}