//! Прымітыўныя traits і тыпы, якія прадстаўляюць асноўныя ўласцівасці тыпаў.
//!
//! Тыпы Rust можна класіфікаваць рознымі карыснымі спосабамі ў адпаведнасці з іх уласцівасцямі.
//! Гэтыя класіфікацыі прадстаўлены як traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Тыпы, якія можна пераносіць праз межы патокаў.
///
/// Гэты Portrait аўтаматычна рэалізуецца, калі кампілятар вызначыць, што гэта падыходзіць.
///
/// Прыкладам тыпу, які не з'яўляецца "Адпраўкай", з'яўляецца паказальнік падліку спасылак [`rc::Rc`][`Rc`].
/// Калі два патокі спрабуюць кланаваць [`Rc`], якія паказваюць на адно і тое ж значэнне, улічанае спасылкамі, яны могуць паспрабаваць аднавіць колькасць спасылак адначасова, гэта [undefined behavior][ub], таму што [`Rc`] не выкарыстоўвае атамныя аперацыі.
///
/// Яго стрыечны брат [`sync::Arc`][arc] сапраўды выкарыстоўвае атамныя аперацыі (накладныя выдаткі) і, такім чынам, з'яўляецца `Send`.
///
/// Для больш падрабязнай інфармацыі глядзіце [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Тыпы з пастаянным памерам, вядомыя падчас кампіляцыі.
///
/// Усе параметры тыпу маюць няяўную мяжу `Sized`.Спецыяльны сінтаксіс `?Sized` можа быць выкарыстаны для выдалення гэтай прывязкі, калі яна не падыходзіць.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // структура FooUse(Foo<[i32]>);//памылка: Памер не рэалізаваны для [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Адзіным выключэннем з'яўляецца няяўны тып `Self` для Portrait.
/// Portrait не мае няяўнай прывязкі `Sized`, паколькі гэта несумяшчальна з аб'ектам [Portrait], дзе, па вызначэнні, Portrait неабходна працаваць з усімі магчымымі рэалізатарамі, і, такім чынам, можа быць любога памеру.
///
///
/// Хоць Rust дазволіць вам звязаць `Sized` з Portrait, пазней вы не зможаце выкарыстоўваць яго для фарміравання аб'екта Portrait:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // хай y: &dyn Bar= &Impl;//памылка: Portrait `Bar` немагчыма зрабіць аб'ектам
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // напрыклад, па змаўчанні, які патрабуе ацэнкі `[T]: !Default`
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Тыпы, якія могуць быць ад "unsized" да дынамічных памераў.
///
/// Напрыклад, маштабны тып `[i8; 2]` рэалізуе `Unsize<[i8]>` і `Unsize<dyn fmt::Debug>`.
///
/// Усе рэалізацыі `Unsize` забяспечваюцца аўтаматычна кампілятарам.
///
/// `Unsize` рэалізаваны для:
///
/// - `[T; N]` з'яўляецца `Unsize<[T]>`
/// - `T` гэта `Unsize<dyn Trait>`, калі `T: Trait`
/// - `Foo<..., T, ...>` з'яўляецца `Unsize<Foo<..., U, ...>>`, калі:
///   - `T: Unsize<U>`
///   - Фу-гэта структура
///   - Толькі апошняе поле `Foo` мае тып з удзелам `T`
///   - `T` не ўваходзіць у тып любых іншых палёў
///   - `Bar<T>: Unsize<Bar<U>>`, калі апошняе поле `Foo` мае тып `Bar<T>`
///
/// `Unsize` выкарыстоўваецца разам з [`ops::CoerceUnsized`], каб кантэйнеры "user-defined", такія як [`Rc`], маглі ўтрымліваць тыпы дынамічных памераў.
/// Для больш падрабязнай інфармацыі глядзіце [DST coercion RFC][RFC982] і [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Патрабуецца Portrait для канстант, якія выкарыстоўваюцца пры супадзенні шаблонаў.
///
/// Любы тып, які атрымлівае `PartialEq`, аўтаматычна рэалізуе гэты Portrait,*незалежна* ад таго, ці рэалізуюць яго параметры тыпу `Eq`.
///
/// Калі элемент `const` змяшчае нейкі тып, які не рэалізуе гэты Portrait, то гэты тып альбо (1.) не рэалізуе `PartialEq` (што азначае, што канстанта не забяспечвае той метад параўнання, які, як мяркуецца, генерацыя кода), альбо (2.) ён рэалізуе *уласны* версія `PartialEq` (якая, як мы мяркуем, не адпавядае параўнанню структурных роўнасцей).
///
///
/// У любым з двух прыведзеных вышэй сцэнарыяў мы адмаўляемся ад выкарыстання такой канстанты ў адпаведнасці шаблону.
///
/// Глядзіце таксама [structural match RFC][RFC1445] і [issue 63438], якія матывавалі пераход ад дызайну на аснове атрыбутаў да гэтага Portrait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Патрабуецца Portrait для канстант, якія выкарыстоўваюцца пры супадзенні шаблонаў.
///
/// Любы тып, які атрымлівае `Eq`, аўтаматычна рэалізуе гэты Portrait,*незалежна* ад таго, рэалізуюць Ці яго параметры тып `Eq`.
///
/// Гэта хак, каб абыйсці абмежаванні ў нашай сістэме тыпаў.
///
/// # Background
///
/// Мы хочам патрабаваць, каб тыпы consts, якія выкарыстоўваюцца ў шаблонах, мелі атрыбут `#[derive(PartialEq, Eq)]`.
///
/// У больш ідэальным свеце мы маглі б праверыць гэта патрабаванне, проста праверыўшы, што дадзены тып рэалізуе як `StructuralPartialEq` Portrait *, так і*`Eq` Portrait.
/// Аднак вы можаце мець ADT, якія *робяць*`derive(PartialEq, Eq)`, і быць выпадкам, які мы хочам прыняць кампілятарам, і ўсё ж тып канстанты не можа рэалізаваць `Eq`.
///
/// А менавіта такі выпадак:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Праблема ў прыведзеным кодзе заключаецца ў тым, што `Wrap<fn(&())>` не рэалізуе `PartialEq` і `Eq`, таму што `для <'a> fn(&'a _)` does not implement those traits.)
///
/// Такім чынам, мы не можам спадзявацца на наіўную праверку на наяўнасць `StructuralPartialEq` і проста `Eq`.
///
/// У якасці ўзлому, каб абыйсці гэта, мы выкарыстоўваем два асобныя traits, якія ўводзяцца кожным з двух вытворных (`#[derive(PartialEq)]` і `#[derive(Eq)]`), і правяраем, каб абодва яны прысутнічалі ў рамках праверкі структурных супадзенняў.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Тыпы, значэнні якіх можна паўтарыць, проста скапіраваўшы біты.
///
/// Па змаўчанні прывязкі зменных маюць "семантыку перамяшчэння".Іншымі словамі:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` перайшоў у `y`, і таму не можа быць выкарыстаны
///
/// // println! ("{: ?}", x);//памылка: выкарыстанне перамешчанага значэння
/// ```
///
/// Аднак, калі тып рэалізуе `Copy`, ён замест гэтага мае "семантыку капіравання":
///
/// ```
/// // Мы можам атрымаць рэалізацыю `Copy`.
/// // `Clone` таксама патрабуецца, бо гэта супертрэт `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` з'яўляецца копіяй `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Важна адзначыць, што ў гэтых двух прыкладах адзіная розніца заключаецца ў тым, ці дазволена вам атрымаць доступ да `x` пасля прызначэння.
/// Пад капотам і копія, і ход могуць прывесці да капіравання бітаў у памяці, хоць гэта часам аптымізуецца.
///
/// ## Як я магу рэалізаваць `Copy`?
///
/// Ёсць два спосабы рэалізацыі `Copy` на вашым тыпе.Прасцей за ўсё выкарыстоўваць `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Вы таксама можаце ўкараніць `Copy` і `Clone` ўручную:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Існуе невялікая розніца паміж імі: стратэгія `derive` таксама будзе змяшчаць `Copy`, прывязаны да параметраў тыпу, што не заўсёды пажадана.
///
/// ## У чым розніца паміж `Copy` і `Clone`?
///
/// Капіі адбываюцца няяўна, напрыклад, у рамках задання `y = x`.Паводзіны `Copy` немагчыма загрузіць;гэта заўсёды простая бітавая копія.
///
/// Кланаванне-гэта відавочнае дзеянне, `x.clone()`.Рэалізацыя [`Clone`] можа забяспечыць любое тыповае паводзіны, неабходнае для бяспечнага дубліравання значэнняў.
/// Напрыклад, для рэалізацыі [`Clone`] для [`String`] неабходна скапіяваць буфер радкоў з указаннем на кучу.
/// Простая разрадная копія значэнняў [`String`] проста скапіруе паказальнік, што прывядзе да двайнога бясплатнага па лініі.
/// Па гэтай прычыне [`String`]-гэта [`Clone`], але не `Copy`.
///
/// [`Clone`] з'яўляецца супертрэйтам `Copy`, таму ўсё, што ёсць `Copy`, павінна таксама ўкараняць [`Clone`].
/// Калі тып `Copy`, то яго рэалізацыя [`Clone`] павінна вярнуць толькі `*self` (гл. Прыклад вышэй).
///
/// ## Калі мой тып можа быць `Copy`?
///
/// Тып можа рэалізаваць `Copy`, калі ўсе яго кампаненты рэалізуюць `Copy`.Напрыклад, гэтая структура можа быць `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Структура можа быць `Copy`, а [`i32`]-`Copy`, таму `Point` мае права быць `Copy`.
/// Наадварот, разгледзім
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Структура `PointList` не можа рэалізаваць `Copy`, таму што [`Vec<T>`]-гэта не `Copy`.Калі мы паспрабуем атрымаць рэалізацыю `Copy`, мы атрымаем памылку:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Агульныя спасылкі (`&T`) таксама з'яўляюцца `Copy`, таму тып можа быць `Copy`, нават калі ён змяшчае агульныя спасылкі тыпаў `T`, якія *не*`Copy`.
/// Разгледзім наступную структуру, якая можа рэалізаваць `Copy`, таму што яна ўтрымлівае толькі *агульную спасылку* на наш не `Капіявы 'тып `PointList` зверху:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Калі *не можа* мой тып быць `Copy`?
///
/// Некаторыя тыпы нельга скапіраваць бяспечна.Напрыклад, капіраванне `&mut T` стварыла б псеўданімна змяняную спасылку.
/// Капіраванне [`String`] можа паўтарыць адказнасць за кіраванне буферам [`String`], што прывядзе да падвойнага бясплатнага.
///
/// Абагульняючы апошні выпадак, любы тып, які рэалізуе [`Drop`], не можа быць `Copy`, таму што ён кіруе некаторымі рэсурсамі, акрамя ўласных байтаў [`size_of::<T>`].
///
/// Калі вы паспрабуеце рэалізаваць `Copy` на структуры або пераліку, якія ўтрымліваюць дадзеныя, якія не з'яўляюцца `Copy`, вы атрымаеце памылку [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Калі *павінен* мой тып быць `Copy`?
///
/// Наогул кажучы, калі ваш тып _can_ рэалізуе `Copy`, ён павінен.
/// Аднак майце на ўвазе, што рэалізацыя `Copy` з'яўляецца часткай агульнадаступнага API вашага тыпу.
/// Калі ў future гэты тып можа стаць не копіяй, разумна апусціць рэалізацыю `Copy`, каб пазбегнуць парушэння змены API.
///
/// ## Дадатковыя рэалізатары
///
/// У дадатак да [implementors listed below][impls], наступныя тыпы таксама рэалізуюць `Copy`:
///
/// * Тыпы элементаў функцый (г.зн. розныя тыпы, вызначаныя для кожнай функцыі)
/// * Тыпы паказальнікаў функцый (напрыклад, `fn() -> i32`)
/// * Тыпы масіваў для ўсіх памераў, калі тып элемента таксама рэалізуе `Copy` (напрыклад, `[i32; 123456]`)
/// * Тыпы набораў, калі кожны кампанент таксама рэалізуе `Copy` (напрыклад, `()`, `(i32, bool)`)
/// * Тыпы закрыцця, калі яны не адлюстроўваюць ніякай каштоўнасці з навакольнага асяроддзя або калі ўсе такія захопленыя значэнні рэалізуюць `Copy` самі.
///   Звярніце ўвагу, што пераменныя, узятыя агульнай спасылкай, заўсёды рэалізуюць `Copy` (нават калі рэферэнт гэтага не робіць), у той час як зменныя, улічаныя зменнай спасылкай, ніколі не рэалізуюць `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Гэта дазваляе капіраваць тып, які не рэалізуе `Copy` з-за незадаволеных межаў жыцця (капіраванне `A<'_>`, калі толькі `A<'static>: Copy` і `A<'_>: Clone`).
// Зараз у нас ёсць гэты атрыбут толькі таму, што на `Copy` існуе нямала спецыялізацый, якія ўжо існуюць у стандартнай бібліятэцы, і зараз няма магчымасці бяспечна паводзіць сябе.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Выведзіце макрас, які генеруе impl з Portrait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Тыпы, для якіх бяспечна абменьвацца спасылкамі паміж патокамі.
///
/// Гэты Portrait аўтаматычна рэалізуецца, калі кампілятар вызначыць, што гэта падыходзіць.
///
/// Дакладнае вызначэнне: тып `T`-гэта [`Sync`] тады і толькі тады, калі `&T`-гэта [`Send`].
/// Іншымі словамі, калі няма магчымасці [undefined behavior][ub] (уключаючы гонкі дадзеных) пры перадачы спасылак `&T` паміж патокамі.
///
/// Як і варта было чакаць, прымітыўныя тыпы, такія як [`u8`] і [`f64`],-усе [`Sync`], а таксама простыя сукупныя тыпы, якія іх утрымліваюць, такія як наборы, структуры і пералічэнні.
/// Іншыя прыклады асноўных тыпаў [`Sync`] ўключаюць тыпы "immutable", такія як `&T`, і тыпы з простай спадчыннай зменлівасцю, такія як [`Box<T>`][box], [`Vec<T>`][vec] і большасць іншых тыпаў калекцый.
///
/// (Агульныя параметры павінны быць [`Sync`], каб іх кантэйнер быў [`Sync`].)
///
/// Некалькі дзіўным наступствам вызначэння з'яўляецца тое, што `&mut T`-гэта `Sync` (калі `T`-гэта `Sync`), нават калі здаецца, што гэта можа забяспечыць несінхранізаваную мутацыю.
/// Фокус у тым, што зменлівая спасылка, якая стаіць за агульнай спасылкай (гэта значыць `& &mut T`), становіцца толькі для чытання, як калі б гэта была `& &T`.
/// Такім чынам, няма рызыкі гонкі дадзеных.
///
/// Тыпы, якія не з'яўляюцца `Sync`, гэта тыпы, якія маюць "interior mutability" у не бяспечнай для разьбы форме, напрыклад [`Cell`][cell] і [`RefCell`][refcell].
/// Гэтыя тыпы дазваляюць мутаваць іх змест нават праз нязменную агульную спасылку.
/// Напрыклад, метад `set` на [`Cell<T>`][cell] бярэ `&self`, таму патрабуецца толькі агульная спасылка [`&Cell<T>`][cell].
/// Метад не выконвае сінхранізацыю, таму [`Cell`][cell] не можа быць `Sync`.
///
/// Іншым прыкладам тыпу, які не з'яўляецца "Sync", з'яўляецца паказальнік падліку спасылак [`Rc`][rc].
/// Улічваючы любую спасылку [`&Rc<T>`][rc], вы можаце кланаваць новы [`Rc<T>`][rc], змяняючы колькасць спасылак неатамным спосабам.
///
/// У выпадках, калі патрэбна бяспечная ніткавая зменлівасць інтэр'еру, Rust забяспечвае [atomic data types], а таксама відавочную блакаванне праз [`sync::Mutex`][mutex] і [`sync::RwLock`][rwlock].
/// Гэтыя тыпы гарантуюць, што любая мутацыя не можа выклікаць расныя дадзеныя, таму тыпамі з'яўляюцца `Sync`.
/// Аналагічна [`sync::Arc`][arc] забяспечвае бяспечны для нітак аналаг [`Rc`][rc].
///
/// Любыя тыпы з унутранай зменлівасцю таксама павінны выкарыстоўваць абгортку [`cell::UnsafeCell`][unsafecell] вакол value(s), якую можна мутаваць праз агульную спасылку.
/// Не ўдаецца зрабіць гэта [undefined behavior][ub].
/// Напрыклад, ["пераўтварыць"][пераўтварыць]-ing з `&T` у `&mut T` недапушчальны.
///
/// Больш падрабязна пра `Sync` глядзіце ў раздзеле [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): як толькі падтрымка для дадання нататак у `rustc_on_unimplemented` пераходзіць у бэта-версію, і яна была пашырана, каб праверыць, ці ёсць закрыццё дзе-небудзь у ланцужку патрабаванняў, пашырыце яе як такую (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Нулявы памер, які выкарыстоўваецца для маркіроўкі рэчаў, якія належаць "act like" да `T`.
///
/// Даданне поля `PhantomData<T>` да вашага тыпу кажа кампілятару, што ваш тып дзейнічае так, як быццам ён захоўвае значэнне тыпу `T`, хоць гэта і не так.
/// Гэтая інфармацыя выкарыстоўваецца пры вылічэнні пэўных уласцівасцей бяспекі.
///
/// Больш падрабязнае тлумачэнне таго, як карыстацца `PhantomData<T>`, знаходзіцца ў [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Жудасная нататка 👻👻👻
///
/// Хоць у іх абодвух страшныя назвы, `PhantomData` і "тыпы фантомаў" звязаны, але не аднолькавыя.Параметр фантомнага тыпу-гэта проста параметр тыпу, які ніколі не выкарыстоўваецца.
/// У Rust гэта часта выклікае скаргу кампілятара, і рашэнне заключаецца ў даданні выкарыстання "dummy" шляхам `PhantomData`.
///
/// # Examples
///
/// ## Невыкарыстоўваныя пажыццёвыя параметры
///
/// Мабыць, найбольш распаўсюджаным выпадкам выкарыстання `PhantomData` з'яўляецца структура, якая мае нявыкарыстаны параметр жыцця, звычайна як частка нейкага небяспечнага кода.
/// Напрыклад, вось структура `Slice`, якая мае два паказальнікі тыпу `*const T`, якія, магчыма, паказваюць на нейкі масіў:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Намер заключаецца ў тым, што базавыя дадзеныя сапраўдныя толькі на працягу ўсяго жыцця `'a`, таму `Slice` не павінен перажыць `'a`.
/// Аднак гэты намер не выяўлены ў кодзе, бо не выкарыстоўваецца `'a` за ўвесь час жыцця, і таму незразумела, да якіх дадзеных ён адносіцца.
/// Мы можам выправіць гэта, сказаўшы кампілятару дзейнічаць так, быццам бы * структура `Slice` утрымлівала спасылку `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Гэта, у сваю чаргу, патрабуе анатацыі `T: 'a`, якая паказвае, што любыя спасылкі ў `T` сапраўдныя на працягу ўсяго жыцця `'a`.
///
/// Пры ініцыялізацыі `Slice` вы проста ўводзіце значэнне `PhantomData` для поля `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Параметры нявыкарыстанага тыпу
///
/// Часам здараецца, што ў вас ёсць нявыкарыстаныя параметры тыпу, якія паказваюць, да якога тыпу дадзеных адносіцца структура "tied", нават калі гэтыя дадзеныя фактычна не знаходзяцца ў самой структуры.
/// Вось прыклад, калі гэта ўзнікае з [FFI].
/// Замежны інтэрфейс выкарыстоўвае ручкі тыпу `*mut ()` для спасылак на значэнні Rust розных тыпаў.
/// Мы адсочваем тып Rust, выкарыстоўваючы параметр фантомнага тыпу на структуры `ExternalResource`, якая абгортвае ручку.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Права ўласнасці і праверка падзення
///
/// Даданне поля тыпу `PhantomData<T>` азначае, што ваш тып валодае дадзенымі тыпу `T`.Гэта, у сваю чаргу, азначае, што калі ваш тып будзе адкінуты, ён можа скінуць адзін або некалькі асобнікаў тыпу `T`.
/// Гэта звязана з аналізам [drop check] кампілятара Rust.
///
/// Калі ваша структура на самай справе не валодае *дадзенымі тыпу `T`, лепш выкарыстоўваць спасылачны тып, напрыклад, `PhantomData<&'a T>` (ideally) або `PhantomData<* const T>` (калі не дзейнічае тэрмін службы), каб не паказваць права ўласнасці.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Унутраны кампілятар Portrait выкарыстоўваецца для пазначэння тыпу дыскрымінантаў пералічэння.
///
/// Гэты Portrait аўтаматычна рэалізуецца для любога тыпу і не дадае ніякіх гарантый для [`mem::Discriminant`].
/// Гэта **нявызначанае паводзіны** для пераўтварэння паміж `DiscriminantKind::Discriminant` і `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Тып дыскрымінанта, які павінен задавальняць Portrait bounds, патрабаваны `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Унутраны кампілятар Portrait выкарыстоўваецца для вызначэння таго, ці ўтрымлівае тып які-небудзь `UnsafeCell` унутры, але не праз апасродкаваны выгляд.
///
/// Гэта ўплывае, напрыклад, на тое, ці змяшчаецца `static` такога тыпу ў статычную памяць, даступную толькі для чытання, альбо ў статычную памяць, якую можна запісваць.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Тыпы, якія можна бяспечна перамяшчаць пасля замацавання.
///
/// Сам Rust не мае ўяўлення пра нерухомыя тыпы і лічыць хады (напрыклад, шляхам прызначэння альбо [`mem::replace`]) заўсёды бяспечнымі.
///
/// Замест гэтага выкарыстоўваецца тып [`Pin`][Pin] для прадухілення перамяшчэння праз сістэму тыпаў.Паказальнікі `P<T>`, загорнутыя ў абгортку [`Pin<P<T>>`][Pin], нельга перамяшчаць.
/// Для атрымання дадатковай інфармацыі аб замацаванні глядзіце дакументацыю [`pin` module].
///
/// Рэалізацыя `Unpin` Portrait для `T` здымае абмежаванні адмацавання тыпу, што дазваляе перамяшчаць `T` з [`Pin<P<T>>`][Pin] з такімі функцыямі, як [`mem::replace`].
///
///
/// `Unpin` не мае ніякіх наступстваў для незамацаваных дадзеных.
/// У прыватнасці, [`mem::replace`] з задавальненнем перамяшчае дадзеныя `!Unpin` (ён працуе для любых `&mut T`, а не толькі для `T: Unpin`).
/// Аднак вы не можаце выкарыстоўваць [`mem::replace`] на дадзеных, загорнутых у [`Pin<P<T>>`][Pin], таму што вы не можаце атрымаць патрэбны для гэтага `&mut T`, і * менавіта гэта прымушае гэтую сістэму працаваць.
///
/// Так, напрыклад, гэта можна зрабіць толькі на тыпах, якія рэалізуюць `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Нам патрэбна зменная спасылка для выкліку `mem::replace`.
/// // Мы можам атрымаць такую спасылку, калі (implicitly) выклікае `Pin::deref_mut`, але гэта магчыма толькі таму, што `String` рэалізуе `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Гэты Portrait аўтаматычна рэалізуецца практычна для ўсіх тыпаў.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Тып маркера, які не рэалізуе `Unpin`.
///
/// Калі тып змяшчае `PhantomPinned`, ён не будзе рэалізоўваць `Unpin` па змаўчанні.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Рэалізацыі `Copy` для прымітыўных тыпаў.
///
/// Рэалізацыі, якія не могуць быць апісаны ў Rust, рэалізаваны ў `traits::SelectionContext::copy_clone_conditions()` у `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Агульныя спасылкі можна капіяваць, але змяняныя спасылкі *не могуць*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}