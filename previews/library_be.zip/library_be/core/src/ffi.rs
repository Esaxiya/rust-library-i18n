#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Службовыя праграмы, звязаныя з прывязкамі (FFI) да замежных функцый.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Эквівалентна тыпу `void` C, калі выкарыстоўваецца ў якасці [pointer].
///
/// Па сутнасці, `*const c_void` эквівалентны `const void*` C, а `*mut c_void`-`void*` C.
/// Тым не менш, гэта *не* тое ж самае, што і зваротны тып `void`, які з'яўляецца тыпам `void` Rust.
///
/// Для мадэлявання паказальнікаў на непразрыстыя тыпы ў FFI, пакуль `extern type` не стабілізуецца, рэкамендуецца выкарыстоўваць абгортку newtype вакол пустога байтавага масіва.
///
/// Падрабязнасці глядзіце ў [Nomicon].
///
/// Можна выкарыстоўваць `std::os::raw::c_void`, калі яны хочуць падтрымліваць стары кампілятар Rust аж да 1.1.0.
/// Пасля Rust 1.30.0 ён быў рээкспартаваны паводле гэтага вызначэння.
/// Для атрымання дадатковай інфармацыі прачытайце [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// Заўвага: каб LLVM распазнаваў тып паказальніка пустаты і з дапамогай функцый пашырэння, такіх як malloc(), нам трэба, каб ён быў прадстаўлены як i8 * у біт-кодзе LLVM.
// Пералік, які тут выкарыстоўваецца, гарантуе гэта і прадухіляе злоўжыванне тыпам "raw", маючы толькі прыватныя варыянты.
// Нам патрэбныя два варыянты, таму што кампілятар скардзіцца на атрыбут repr у адваротным выпадку, і нам патрэбен хаця б адзін варыянт, бо ў адваротным выпадку пералічэнне было б нежылым, і, па меншай меры, адметкаванне такіх паказальнікаў было б UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Базавая рэалізацыя `va_list`.
// Імя WIP, на дадзены момант выкарыстоўваецца `VaListImpl`.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Інварыянт у параўнанні з `'f`, таму кожны аб'ект `VaListImpl<'f>` прывязаны да вобласці функцыі, у якой ён вызначаны
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Рэалізацыя ABI `va_list`.
/// Для больш падрабязнай інфармацыі глядзіце [AArch64 Procedure Call Standard].
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Рэалізацыя ABI `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Рэалізацыя ABI `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Абгортка для `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Пераўтварыце `VaListImpl` у `VaList`, які бінарна сумяшчальны з `va_list` C.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Пераўтварыце `VaListImpl` у `VaList`, які бінарна сумяшчальны з `va_list` C.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe Portrait трэба выкарыстоўваць у агульнадаступных інтэрфейсах, аднак нельга дазваляць выкарыстоўваць сам Portrait па-за гэтым модулем.
// Дазвол карыстальнікам рэалізаваць Portrait для новага тыпу (тым самым дазваляючы выкарыстоўваць va_arg intrinsic для новага тыпу), верагодна, можа выклікаць неакрэсленыя паводзіны.
//
// FIXME(dlrobertson): Для таго, каб выкарыстоўваць VaArgSafe Portrait у агульнадаступным інтэрфейсе, але таксама пераканацца, што ён не можа быць выкарыстаны ў іншым месцы, Portrait павінен быць агульнадаступным у прыватным модулі.
// Пасля рэалізацыі RFC 2145 паглядзіце на паляпшэнне гэтага.
//
//
//
//
mod sealed_trait {
    /// Trait, які дазваляе выкарыстоўваць дазволеныя тыпы з [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Пераход да наступнага аргумента.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Капіюе `va_list` у бягучым месцы.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // БЯСПЕКА: абанент павінен выконваць кантракт бяспекі для `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // БЯСПЕКА: мы пішам на `MaybeUninit`, такім чынам, ён ініцыялізуецца і `assume_init` з'яўляецца законным
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: гэта павінна выклікаць `va_end`, але няма чыстага спосабу
        // гарантуем, што `drop` заўсёды ўбудоўваецца ў абанента, таму `va_end` будзе непасрэдна выкліканы з той самай функцыі, што і адпаведны `va_copy`.
        // `man va_end` сцвярджае, што C патрабуе гэтага, а LLVM у асноўным прытрымліваецца семантыкі C, таму нам трэба пераканацца, што `va_end` заўсёды выклікаецца з той самай функцыі, што і `va_copy`.
        //
        // Больш падрабязна see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Пакуль гэта працуе, бо `va_end` не прымае ўсіх бягучых мэтаў LLVM.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Знішчыце спіс аргументаў `ap` пасля ініцыялізацыі з дапамогай `va_start` або `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Капіруе бягучае месцазнаходжанне спісу аргументаў `src` у спіс аргументаў `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Загружае аргумент тыпу `T` з `va_list` `ap` і павялічвае аргумент `ap`, на які паказвае.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}