//! Падтрымка Panic для libcore
//!
//! Асноўная бібліятэка не можа вызначыць паніку, але *дэкларуе* паніку.
//! Гэта азначае, што функцыі ўнутры libcore дазволены panic, але для таго, каб быць карысным, crate, які знаходзіцца ўверсе, павінен вызначыць паніку для выкарыстання libcore.
//! Бягучы інтэрфейс для панікі:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Гэта вызначэнне дазваляе выклікаць паніку з любым агульным паведамленнем, але не дазваляе адмовіцца са значэннем `Box<Any>`.
//! (`PanicInfo` проста ўтрымлівае `&(dyn Any + Send)`, для якога мы ўводзім фіктыўнае значэнне ў `PanicInfo: : internal_constructor`.) Прычына гэтага ў тым, што Libcore не мае права выдзяляць.
//!
//!
//! Гэты модуль змяшчае некалькі іншых функцый, якія выклікаюць паніку, але гэта толькі неабходныя элементы lang для кампілятара.Усе panics праходзяць праз гэтую адну функцыю.
//! Сапраўдны сімвал аб'яўляецца праз атрыбут `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Асноўная рэалізацыя макраса `panic!` libcore, калі не выкарыстоўваецца фарматаванне.
#[cold]
// ніколі не ўбудаваныя, калі panic_immediate_abort, каб пазбегнуць раздуцця кода на сайтах выклікаў, наколькі гэта магчыма
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // неабходны кодэгену для panic на перапаўненні і іншых тэрмінатараў MIR `Assert`
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Выкарыстоўвайце Arguments::new_v1 замест format_args! ("{}", Expr), каб патэнцыйна паменшыць накладныя выдаткі.
    // Формат_арг!макрас выкарыстоўвае дысплей str0000Z str для напісання выраза, які выклікае Formatter::pad, які павінен улічваць абрэзку радкоў і адступы (хаця тут і не выкарыстоўваецца).
    //
    // Выкарыстанне Arguments::new_v1 можа дазволіць кампілятару апусціць Formatter::pad з выходных двайковых файлаў, зэканоміўшы да некалькіх кілабайт.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // неабходны для ацэнкі const panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // неабходны кодэгену для panic пры доступе OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Пры фарматаванні выкарыстоўваецца асноўная рэалізацыя макраса `panic!` libcore.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // УВАГА. Гэтая функцыя ніколі не пераходзіць мяжы FFI;гэта выклік Rust-to-Rust, які атрымлівае дазвол на функцыю `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // БЯСПЕКА: `panic_impl` вызначаны ў бяспечным кодзе Rust і, такім чынам, бяспечна тэлефанаваць.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Унутраная функцыя для макрасаў `assert_eq!` і `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}