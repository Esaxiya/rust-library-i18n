#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Змяшчае азначэнні структур для макета ўбудаваных тыпаў кампілятара.
//!
//! Яны могуць быць выкарыстаны ў якасці мішэняў для пераўтварэнняў у небяспечным кодзе для непасрэднай маніпуляцыі з неапрацаванымі ўяўленнямі.
//!
//!
//! Іх вызначэнне заўсёды павінна адпавядаць ABI, вызначанаму ў `rustc_middle::ty::layout`.
//!

/// Прадстаўленне такога аб'екта Portrait, як `&dyn SomeTrait`.
///
/// Гэтая структура мае той жа макет, што і тыпы, такія як `&dyn SomeTrait` і `Box<dyn AnotherTrait>`.
///
/// `TraitObject` гарантавана адпавядае макетам, але гэта не тып аб'ектаў Portrait (напрыклад, палі непасрэдна даступныя на `&dyn SomeTrait`) і не кіруе гэтым макетам (змена вызначэння не зменіць макет `&dyn SomeTrait`).
///
/// Ён прызначаны толькі для выкарыстання небяспечным кодам, які павінен маніпуляваць дэталямі нізкага ўзроўню.
///
/// Немагчыма зрабіць агульную спасылку на ўсе аб'екты Portrait, таму адзіны спосаб стварыць значэнні гэтага тыпу-з дапамогай такіх функцый, як [`std::mem::transmute`][transmute].
/// Аналагічным чынам, адзіны спосаб стварыць сапраўдны аб'ект Portrait са значэння `TraitObject`-гэта з `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Сінтэз аб'екта Portrait з неадпаведнымі тыпамі-такім, дзе vtable не адпавядае тыпу значэння, на якое паказвае паказальнік дадзеных-з вялікай верагоднасцю можа прывесці да нявызначаных паводзін.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // прыклад Portrait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // няхай кампілятар зробіць аб'ект Portrait
/// let object: &dyn Foo = &value;
///
/// // паглядзіце на сырое прадстаўленне
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // паказальнік дадзеных-гэта адрас `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // пабудаваць новы аб'ект, паказваючы на іншы `i32`, асцярожна карыстаючыся `i32` vtable з `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ён павінен працаваць так, як калі б мы пабудавалі аб'ект Portrait непасрэдна з `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}