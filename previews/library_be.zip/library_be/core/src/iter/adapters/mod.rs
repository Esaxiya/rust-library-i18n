use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Гэты Portrait забяспечвае пераходны доступ да стадыі крыніцы ў канвееры інтэратар-адаптар пры такіх умовах
/// * крыніца ітэратара `S` сама рэалізуе `SourceIter<Source = S>`
/// * існуе дэлегуючая рэалізацыя гэтага Portrait для кожнага адаптара ў трубаправодзе паміж крыніцай і спажыўцом трубаправода.
///
/// Калі крыніцай з'яўляецца ўладальная структура ітэратара (звычайна называецца `IntoIter`), гэта можа быць карысна для спецыялізаваных рэалізацый [`FromIterator`] або аднаўлення астатніх элементаў пасля частковага вычарпання ітэратара.
///
///
/// Звярніце ўвагу, што рэалізацыі не абавязкова павінны забяспечваць доступ да самай унутранай крыніцы трубаправода.Прамежкавы адаптар са статусам можа ахвотна ацаніць частку трубаправода і выставіць яго ўнутраную памяць як крыніцу.
///
/// Portrait небяспечны, таму што выканаўцы павінны падтрымліваць дадатковыя ўласцівасці бяспекі.
/// Падрабязнасці гл. У [`as_inner`].
///
/// # Examples
///
/// Атрыманне часткова спажытай крыніцы:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Зыходны этап у ітэратарным канвееры.
    type Source: Iterator;

    /// Атрыманне крыніцы канвеера ітэратара.
    ///
    /// # Safety
    ///
    /// Рэалізацыі мусяць вяртаць адну і тую ж зменную спасылку на працягу ўсяго жыцця, калі яна не заменена выклікаючай.
    /// Выклічнікі могуць замяніць спасылку толькі тады, калі яны спынілі ітэрацыю і кінулі канвеер ітэратара пасля здабывання крыніцы.
    ///
    /// Гэта азначае, што адаптары ітэратараў могуць спадзявацца на тое, што крыніца не зменіцца падчас ітэрацыі, але яны не могуць спадзявацца на яго ў сваіх рэалізацыях Drop.
    ///
    /// Рэалізацыя гэтага метаду азначае, што адаптары адмаўляюцца ад прыватнага доступу да сваёй крыніцы і могуць разлічваць толькі на гарантыі, зробленыя на аснове тыпаў прымачоў метадаў.
    /// Адсутнасць абмежаванага доступу таксама патрабуе, каб адаптары павінны падтрымліваць агульнадаступны API крыніцы, нават калі яны маюць доступ да яго ўнутраных элементаў.
    ///
    /// Выклічнікі, у сваю чаргу, павінны чакаць, што крыніца знаходзіцца ў любым стане, які адпавядае яе агульнадаступнаму API, бо адаптары, якія знаходзяцца паміж ёй і крыніцай, маюць аднолькавы доступ.
    /// У прыватнасці, адаптар мог расходаваць больш элементаў, чым гэта строга неабходна.
    ///
    /// Агульная мэта гэтых патрабаванняў-дазволіць спажыўцу трубаправода выкарыстоўваць
    /// * усё, што застанецца ў крыніцы пасля спынення ітэрацыі
    /// * памяць, якая стала невыкарыстоўванай пры прасоўванні спажывальнага ітэратара
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Адаптар ітэратара, які вырабляе выснову, пакуль асноўны ітэратар вырабляе значэнні `Result::Ok`.
///
///
/// Пры выяўленні памылкі ітэратар спыняецца і памылка захоўваецца.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Апрацуйце дадзены ітэратар, як быццам бы ён даў `T` замест `Result<T, _>`.
/// Любыя памылкі спыняць унутраны ітэратар, а агульны вынік будзе памылкай.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}