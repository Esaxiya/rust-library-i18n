/// Ітэратар, які ведае яго дакладную даўжыню.
///
/// Многія [`Iterator`] не ведаюць, колькі разоў будуць паўтарацца, але некаторыя ведаюць.
/// Калі ітэратар ведае, колькі разоў ён можа ітэраваць, прадастаўленне доступу да гэтай інфармацыі можа быць карысным.
/// Напрыклад, калі вы хочаце зрабіць паўтор назад, добры пачатак-ведаць, дзе канец.
///
/// Пры рэалізацыі `ExactSizeIterator` вы таксама павінны ўкараніць [`Iterator`].
/// Пры гэтым рэалізацыя [`Iterator::size_hint`]*павінна* вярнуць дакладны памер ітэратара.
///
/// Метад [`len`] мае рэалізацыю па змаўчанні, таму звычайна яго не варта рэалізоўваць.
/// Аднак вы можаце забяспечыць больш эфектыўную рэалізацыю, чым па змаўчанні, таму перавызначэнне яе ў гэтым выпадку мае сэнс.
///
///
/// Звярніце ўвагу, што гэты Portrait з'яўляецца бяспечным Portrait, і таму як *не* і *не можа* гарантаваць правільнасць атрыманай даўжыні.
/// Гэта азначае, што код `unsafe`**не павінен** спадзявацца на правільнасць [`Iterator::size_hint`].
/// Нестабільны і небяспечны [`TrustedLen`](super::marker::TrustedLen) Portrait дае гэтую дадатковую гарантыю.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// // канечны дыяпазон дакладна ведае, колькі разоў ён будзе паўтарацца
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// У [module-level docs] мы ўкаранілі [`Iterator`], `Counter`.
/// Давайце ўкаранім `ExactSizeIterator` і для яго:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Мы можам лёгка вылічыць астатнюю колькасць ітэрацый.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // І зараз мы можам ім скарыстацца!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Вяртае дакладную даўжыню ітэратара.
    ///
    /// Рэалізацыя гарантуе, што ітэратар верне роўна `len()`, большае за значэнне [`Some(T)`], перш чым вярнуць [`None`].
    ///
    /// Гэты метад мае рэалізацыю па змаўчанні, таму звычайна не варта рэалізоўваць яго непасрэдна.
    /// Аднак, калі вы можаце забяспечыць больш эфектыўную рэалізацыю, вы можаце зрабіць гэта.
    /// Для прыкладу глядзіце дакументы [trait-level].
    ///
    /// Гэтая функцыя мае тыя ж гарантыі бяспекі, што і функцыя [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// // канечны дыяпазон дакладна ведае, колькі разоў ён будзе паўтарацца
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Гэта зацвярджэнне з'яўляецца занадта абарончым, але правярае інварыянт
        // гарантавана Portrait.
        // Калі б гэты Portrait быў rust-унутраны, мы маглі б выкарыстаць debug_assert !;assert_eq!таксама праверыць усе рэалізацыі карыстальнікаў Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Вяртае `true`, калі ітэратар пусты.
    ///
    /// Гэты метад мае рэалізацыю па змаўчанні з выкарыстаннем [`ExactSizeIterator::len()`], таму вам не трэба рэалізоўваць яго самастойна.
    ///
    ///
    /// # Examples
    ///
    /// Асноўнае выкарыстанне:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}