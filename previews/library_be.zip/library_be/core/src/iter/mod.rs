//! Кампазіцыйная знешняя ітэрацыя.
//!
//! Калі вы апынуліся ў нейкай калекцыі і вам трэба выканаць аперацыю над элементамі згаданай калекцыі, вы хутка натрапіце на 'iterators'.
//! Ітэратары актыўна выкарыстоўваюцца ў ідыяматычным кодзе Rust, таму варта азнаёміцца з імі.
//!
//! Перш чым тлумачыць больш, пагаворым пра тое, як структураваны гэты модуль:
//!
//! # Organization
//!
//! Гэты модуль у асноўным арганізаваны па тыпах:
//!
//! * [Traits] з'яўляюцца асноўнай часткай: гэтыя traits вызначаюць, якія ітэратары існуюць і што з імі можна рабіць.Метады гэтых traits вартыя дадатковага часу на вывучэнне.
//! * [Functions] Прапануем некалькі карысных спосабаў стварэння асноўных ітэратараў.
//! * [Structs] часта з'яўляюцца тыпамі вяртання розных метадаў на traits гэтага модуля.Звычайна вы хочаце паглядзець на метад, які стварае `struct`, а не на сам `struct`.
//! Больш падрабязна пра тое, чаму, глядзіце ў раздзеле "[Рэалізацыя ітэратара](#Implementation-iterator)".
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Вось і ўсё!Давайце пакапаемся ў ітэратарах.
//!
//! # Iterator
//!
//! Сэрцам і душой гэтага модуля з'яўляецца [`Iterator`] Portrait.Ядро [`Iterator`] выглядае так:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! У ітэратара ёсць метад, [`next`], які пры выкліку вяртае [`Option`]`<Item>`.
//! [`next`] верне [`Some(Item)`], пакуль ёсць элементы, і як толькі яны будуць вычарпаны, верне `None`, каб паказаць, што ітэрацыя скончана.
//! Асобныя ітэратары могуць выбраць аднаўленне ітэрацыі, і таму выклік [`next`] зноў можа альбо не можа пачаць вяртаць [`Some(Item)`] у нейкі момант (напрыклад, гл. [`TryIter`]).
//!
//!
//! Поўнае вызначэнне ["Iterator`] уключае і шэраг іншых метадаў, але гэта метады па змаўчанні, пабудаваныя на верхняй частцы [`next`], і таму вы атрымліваеце іх бясплатна.
//!
//! Ітэратары таксама можна скласці, і звычайна іх аб'ядноўваюць для больш складаных формаў апрацоўкі.Для больш падрабязнай інфармацыі глядзіце раздзел [Adapters](#adapters) ніжэй.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Тры формы ітэрацыі
//!
//! Ёсць тры распаўсюджаныя метады, якія могуць стварыць ітэратары з калекцыі:
//!
//! * `iter()`, які паўтарае `&T`.
//! * `iter_mut()`, які паўтарае `&mut T`.
//! * `into_iter()`, які паўтарае `T`.
//!
//! Розныя рэчы ў стандартнай бібліятэцы могуць рэалізоўваць адзін ці некалькі з трох, дзе гэта дарэчы.
//!
//! # Рэалізацыя Iterator
//!
//! Стварэнне ўласнага ітэратара ўключае два этапы: стварэнне `struct` для ўтрымання стану ітэратара, а затым рэалізацыя [`Iterator`] для гэтага `struct`.
//! Вось чаму ў гэтым модулі так шмат `структур`: па адным для кожнага ітэратара і адаптара ітэратара.
//!
//! Давайце зробім ітэратар з імем `Counter`, які разлічвае ад `1` да `5`:
//!
//! ```
//! // Па-першае, структура:
//!
//! /// Ітэратар, які налічвае ад аднаго да пяці
//! struct Counter {
//!     count: usize,
//! }
//!
//! // мы хочам, каб наш падлік пачынаўся з аднаго, таму давайце дапаможам метаду new().
//! // Гэта не з'яўляецца строга неабходным, але зручна.
//! // Звярніце ўвагу, што мы пачынаем `count` з нуля, і мы ўбачым, чаму ў рэалізацыі `next()`'s ніжэй.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Затым мы рэалізуем `Iterator` для нашага `Counter`:
//!
//! impl Iterator for Counter {
//!     // мы будзем лічыць з выкарыстаннем
//!     type Item = usize;
//!
//!     // next() гэта адзіны неабходны метад
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Павялічце наш лік.Вось чаму мы пачалі з нуля.
//!         self.count += 1;
//!
//!         // Праверце, скончылі мы з падлікам ці не.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // І зараз мы можам ім скарыстацца!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Выклік [`next`] такім чынам становіцца паўторным.Rust мае канструкцыю, якая можа выклікаць [`next`] на вашым ітэратары, пакуль ён не дасягне `None`.Давайце пойдзем далей.
//!
//! Таксама звярніце ўвагу, што `Iterator` забяспечвае рэалізацыю па змаўчанні такіх метадаў, як `nth` і `fold`, якія ўнутрана выклікаюць `next`.
//! Аднак можна таксама напісаць уласную рэалізацыю такіх метадаў, як `nth` і `fold`, калі ітэратар можа вылічыць іх больш эфектыўна, не выклікаючы `next`.
//!
//! # `for` завесы і `IntoIterator`
//!
//! Сінтаксіс цыкла `for` Rust на самай справе з'яўляецца цукрам для ітэратараў.Вось асноўны прыклад `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Гэта выведзе лічбы ад аднаго да пяці, кожны на сваім радку.Але вы тут нешта заўважыце: мы ніколі не выклікалі нічога на нашым vector для стварэння ітэратара.Што дае?
//!
//! У стандартнай бібліятэцы ёсць Portrait для пераўтварэння чагосьці ў ітэратар: [`IntoIterator`].
//! Гэты Portrait мае адзін метад, [`into_iter`], які пераўтворыць рэч, якая рэалізуе [`IntoIterator`], у ітэратар.
//! Давайце зноў паглядзім на гэты цыкл `for` і ў тое, у што яго пераўтварае кампілятар:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust абясшкоджвае гэта:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Па-першае, мы называем `into_iter()` па значэнні.Затым мы супастаўляем ітэратар, які вяртаецца, выклікаючы [`next`] зноў і зноў, пакуль не ўбачым `None`.
//! На гэты момант мы выйшлі з цыкла `break` і скончылі ітэрацыю.
//!
//! Тут ёсць яшчэ адзін тонкі біт: стандартная бібліятэка змяшчае цікавую рэалізацыю [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Іншымі словамі, усе [`Iterator`] рэалізуюць [`IntoIterator`], проста вярнуўшы сябе.Гэта азначае дзве рэчы:
//!
//! 1. Калі вы пішаце [`Iterator`], вы можаце выкарыстоўваць яго з цыклам `for`.
//! 2. Калі вы ствараеце калекцыю, укараненне [`IntoIterator`] для яе дазволіць выкарыстоўваць вашу калекцыю з цыклам `for`.
//!
//! # Ітэрацыя па спасылцы
//!
//! Паколькі [`into_iter()`] прымае `self` па значэнні, выкарыстанне цыкла `for` для ітэрацыі па калекцыі спажывае гэтую калекцыю.Часта вы можаце перабіраць калекцыю, не спажываючы яе.
//! Шматлікія калекцыі прапануюць метады, якія забяспечваюць ітэратары над спасылкамі, якія звычайна называюць `iter()` і `iter_mut()` адпаведна:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` па-ранейшаму належыць гэтай функцыі.
//! ```
//!
//! Калі тып калекцыі `C` забяспечвае `iter()`, ён звычайна таксама рэалізуе `IntoIterator` для `&C`, з рэалізацыяй, якая проста выклікае `iter()`.
//! Сапраўды гэтак жа калекцыя `C`, якая забяспечвае `iter_mut()`, звычайна рэалізуе `IntoIterator` для `&mut C`, дэлегуючы да `iter_mut()`.Гэта дазваляе зручны стэнаграфія:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // тое ж самае, што і `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // тое ж самае, што і `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! У той час як многія калекцыі прапануюць `iter()`, не ўсе прапануюць `iter_mut()`.
//! Напрыклад, мутацыя клавіш [`HashSet<T>`] або [`HashMap<K, V>`] можа перавесці калекцыю ў супярэчлівы стан, калі змяняюцца хэшы ключоў, таму гэтыя калекцыі прапануюць толькі `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Функцыі, якія прымаюць [`Iterator`] і вяртаюць іншы [`Iterator`], часта называюць "адаптарамі ітэратара", бо яны з'яўляюцца формай "адаптара"
//! pattern'.
//!
//! Агульныя адаптары ітэратараў ўключаюць [`map`], [`take`] і [`filter`].
//! Больш падрабязна глядзіце ў іх дакументацыі.
//!
//! Калі адаптар ітэратара panics, ітэратар будзе знаходзіцца ў неўстаноўленым (але бяспечным для памяці) стане.
//! Таксама не гарантуецца, што гэты стан застанецца аднолькавым у розных версіях Rust, таму варта пазбягаць спадзявання на дакладныя значэнні, якія вяртае ітэратар, які панікаваў.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Ітэратары (і ітэратар [adapters](#adapters))*лянівы*. Гэта азначае, што проста стварэнне ітэратара не вельмі шмат _do_. Нічога на самой справе не адбываецца, пакуль вы не патэлефануеце ў [`next`].
//! Гэта часам выклікае блытаніну пры стварэнні ітэратара выключна для яго пабочных эфектаў.
//! Напрыклад, метад [`map`] выклікае закрыццё кожнага элемента, які ён ітэруе:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Гэта не прывядзе да друку якіх-небудзь значэнняў, бо мы стварылі толькі ітэратар, а не выкарыстоўваем яго.Кампілятар папярэдзіць нас пра такія паводзіны:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Ідыяматычным спосабам напісання [`map`] для яго пабочных эфектаў з'яўляецца выкарыстанне цыкла `for` альбо выклік метаду [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Іншы распаўсюджаны спосаб ацэнкі ітэратара-выкарыстанне метаду [`collect`] для стварэння новай калекцыі.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ітэратары не павінны быць абмежаванымі.У якасці прыкладу, адкрыты дыяпазон з'яўляецца бясконцым ітэратарам:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Звычайна выкарыстоўваць пераходнік ітэратара [`take`] для пераўтварэння бясконцага ітэратара ў канечны:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Гэта выведзе лічбы ад `0` да `4`, кожны на сваім радку.
//!
//! Майце на ўвазе, што метады на бясконцых ітэратарах, нават тыя, для якіх вынік можна матэматычна вызначыць за канечны час, могуць не спыніцца.
//! У прыватнасці, такія метады, як [`min`], якія ў агульным выпадку патрабуюць абходу кожнага элемента ў ітэратары, хутчэй за ўсё, не вернуцца паспяхова для любых бясконцых ітэратараў.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // О не!Бясконцая пятля!
//! // `ones.min()` выклікае бясконцую пятлю, таму мы не дойдзем да гэтага!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;