use crate::iter::{FusedIterator, TrustedLen};

/// Стварае новы ітэратар, які бясконца паўтарае адзін элемент.
///
/// Функцыя `repeat()` паўтарае адно значэнне зноў і зноў.
///
/// Бясконцыя ітэратары, такія як `repeat()`, часта выкарыстоўваюцца з такімі адаптарамі, як [`Iterator::take()`], каб зрабіць іх канчатковымі.
///
/// Калі тып элемента ітэратара, які вам патрэбен, не рэалізуе `Clone`, альбо калі вы не хочаце захоўваць паўторны элемент у памяці, вы можаце замест гэтага выкарыстоўваць функцыю [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::iter;
///
/// // лік чатыры 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // так, яшчэ чатыры
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Будзеце канчатковым з [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // апошні прыклад-занадта шмат чацвярых.Давайце толькі чатыры чацвёркі.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... і цяпер мы скончылі
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ітэратар, які бясконца паўтарае элемент.
///
/// Гэты `struct` створаны функцыяй [`repeat()`].Больш падрабязна глядзіце яго дакументацыю.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}