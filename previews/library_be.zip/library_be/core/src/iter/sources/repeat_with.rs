use crate::iter::{FusedIterator, TrustedLen};

/// Стварае новы ітэратар, які бясконца паўтарае элементы тыпу `A`, ужываючы прадастаўленае закрыццё, рэтранслятар, `F: FnMut() -> A`.
///
/// Функцыя `repeat_with()` зноў і зноў выклікае рэтранслятар.
///
/// Бясконцыя ітэратары, такія як `repeat_with()`, часта выкарыстоўваюцца з такімі адаптарамі, як [`Iterator::take()`], каб зрабіць іх канчатковымі.
///
/// Калі тып элемента ітэратара, які вам патрэбен, рэалізуе [`Clone`], і нармальна захоўваць зыходны элемент у памяці, замест гэтага варта выкарыстоўваць функцыю [`repeat()`].
///
///
/// Ітэратар, выраблены `repeat_with()`, не з'яўляецца [`DoubleEndedIterator`].
/// Калі вам патрэбна `repeat_with()`, каб вярнуць [`DoubleEndedIterator`], адкрыйце праблему GitHub, якая тлумачыць ваш выпадак выкарыстання.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::iter;
///
/// // давайце выкажам здагадку, што ў нас ёсць нейкае значэнне тыпу, які не з'яўляецца `Clone` або які не хоча мець у памяці толькі таму, што гэта дорага:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // пэўнае значэнне назаўжды:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Выкарыстанне мутацыі і пераход да канца:
///
/// ```rust
/// use std::iter;
///
/// // Ад нулявой да трэцяй ступені два:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... і цяпер мы скончылі
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ітэратар, які бясконца паўтарае элементы тыпу `A`, ужываючы прадастаўленае закрыццё `F: FnMut() -> A`.
///
///
/// Гэты `struct` створаны функцыяй [`repeat_with()`].
/// Больш падрабязна глядзіце яго дакументацыю.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}