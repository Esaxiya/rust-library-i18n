use crate::iter::{FusedIterator, TrustedLen};

/// Стварае ітэратар, які ляніва генеруе значэнне роўна адзін раз, выклікаючы прадастаўленае закрыццё.
///
/// Гэта звычайна выкарыстоўваецца для адаптацыі аднаго генератара значэнняў да [`chain()`] іншых відаў ітэрацый.
/// Магчыма, у вас ёсць ітэратар, які ахоплівае амаль усё, але вам патрэбен дадатковы спецыяльны выпадак.
/// Магчыма, у вас ёсць функцыя, якая працуе на ітэратарах, але вам трэба апрацаваць толькі адно значэнне.
///
/// У адрозненне ад [`once()`], гэтая функцыя лянотна генеруе значэнне па запыце.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::iter;
///
/// // адзін-самая адзінокая лічба
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // толькі адзін, гэта ўсё, што мы атрымліваем
/// assert_eq!(None, one.next());
/// ```
///
/// Злучэнне разам з іншым ітэратарам.
/// Скажам, мы хочам перагледзець кожны файл каталога `.foo`, але таксама файл канфігурацыі,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // нам трэба пераўтварыць з ітэратара DirEntry-s у ітэратар PathBufs, таму мы выкарыстоўваем карту
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // зараз, наш ітэратар толькі для нашага файла канфігурацыі
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // звяжыце два ітэратары разам у адзін вялікі ітэратар
/// let files = dirs.chain(config);
///
/// // гэта дасць нам усе файлы ў .foo, а таксама .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ітэратар, які дае адзін элемент тыпу `A`, ужываючы прадастаўленае закрыццё `F: FnOnce() -> A`.
///
///
/// Гэты `struct` створаны функцыяй [`once_with()`].
/// Больш падрабязна глядзіце яго дакументацыю.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}