use crate::fmt;

/// Стварае новы ітэратар, дзе кожная ітэрацыя выклікае прадугледжанае закрыццё `F: FnMut() -> Option<T>`.
///
/// Гэта дазваляе стварыць уласны ітэратар з любымі паводзінамі, не выкарыстоўваючы больш падрабязны сінтаксіс стварэння выдзеленага тыпу і рэалізацыі для яго [`Iterator`] Portrait.
///
/// Звярніце ўвагу, што ітэратар `FromFn` не робіць здагадак аб паводзінах закрыцця, і таму кансерватыўна не рэалізуе [`FusedIterator`] і не адмяняе [`Iterator::size_hint()`] ад стандартнага `(0, None)`.
///
///
/// Закрыццё можа выкарыстоўваць захопы і навакольнае асяроддзе для адсочвання стану ў ітэрацыях.У залежнасці ад таго, як выкарыстоўваецца ітэратар, для гэтага можа спатрэбіцца ўказаць ключавое слова [`move`] у закрыцці.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Давайце паўторна рэалізуем ітэратар лічыльніка з [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Павялічце наш лік.Вось чаму мы пачалі з нуля.
///     count += 1;
///
///     // Праверце, скончылі мы з падлікам ці не.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Ітэратар, дзе кожная ітэрацыя выклікае прадугледжанае закрыццё `F: FnMut() -> Option<T>`.
///
/// Гэты `struct` створаны функцыяй [`iter::from_fn()`].
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}