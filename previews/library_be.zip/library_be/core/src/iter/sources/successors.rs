use crate::{fmt, iter::FusedIterator};

/// Стварае новы ітэратар, дзе кожны наступны элемент вылічваецца на аснове папярэдняга.
///
/// Ітэратар пачынаецца з дадзенага першага элемента (калі ён ёсць) і выклікае дадзенае закрыццё `FnMut(&T) -> Option<T>`, каб вылічыць пераемніка кожнага элемента.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Калі гэтая функцыя вяртае `impl Iterator<Item=T>`, яна можа быць заснавана на `unfold` і не патрабуе выдзеленага тыпу.
    //
    // Аднак наяўнасць названага тыпу `Successors<T, F>` дазваляе яму быць `Clone`, калі `T` і `F` ёсць.
    Successors { next: first, succ }
}

/// Новы ітэратар, дзе кожны наступны элемент вылічваецца на аснове папярэдняга.
///
/// Гэты `struct` створаны функцыяй [`iter::successors()`].
/// Больш падрабязна глядзіце яго дакументацыю.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}