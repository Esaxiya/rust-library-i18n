use crate::iter::{FusedIterator, TrustedLen};

/// Стварае ітэратар, які дае элемент роўна адзін раз.
///
/// Гэта звычайна выкарыстоўваецца для адаптацыі аднаго значэння да [`chain()`] іншых відаў ітэрацый.
/// Магчыма, у вас ёсць ітэратар, які ахоплівае амаль усё, але вам патрэбен дадатковы спецыяльны выпадак.
/// Магчыма, у вас ёсць функцыя, якая працуе на ітэратарах, але вам трэба апрацаваць толькі адно значэнне.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Асноўнае выкарыстанне:
///
/// ```
/// use std::iter;
///
/// // адзін-самая адзінокая лічба
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // толькі адзін, гэта ўсё, што мы атрымліваем
/// assert_eq!(None, one.next());
/// ```
///
/// Злучэнне разам з іншым ітэратарам.
/// Скажам, мы хочам перагледзець кожны файл каталога `.foo`, але таксама файл канфігурацыі,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // нам трэба пераўтварыць з ітэратара DirEntry-s у ітэратар PathBufs, таму мы выкарыстоўваем карту
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // зараз, наш ітэратар толькі для нашага файла канфігурацыі
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // звяжыце два ітэратары разам у адзін вялікі ітэратар
/// let files = dirs.chain(config);
///
/// // гэта дасць нам усе файлы ў .foo, а таксама .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Ітэратар, які дае элемент роўна адзін раз.
///
/// Гэты `struct` створаны функцыяй [`once()`].Больш падрабязна глядзіце яго дакументацыю.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}