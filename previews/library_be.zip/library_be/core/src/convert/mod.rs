//! Traits для пераўтварэнняў паміж тыпамі.
//!
//! traits у гэтым модулі забяспечвае спосаб пераўтварэння з аднаго тыпу ў іншы.
//! Кожны Portrait мае розныя мэты:
//!
//! - Укараніце [`AsRef`] Portrait для танных пераўтварэнняў з спасылкі на спасылку
//! - Укараніце [`AsMut`] Portrait для танных пераўтваральных пераўтварэнняў
//! - Укараніце [`From`] Portrait для спажывання пераўтварэнняў кошту ў значэнне
//! - Рэалізаваць [`Into`] Portrait для спажывання пераўтварэнняў значэння ў значэнне ў тыпы, якія не ўваходзяць у бягучы crate
//! - [`TryFrom`] і [`TryInto`] traits паводзяць сябе як [`From`] і [`Into`], але павінны быць рэалізаваны, калі пераўтварэнне можа пацярпець няўдачу.
//!
//! traits у гэтым модулі часта выкарыстоўваюцца як Portrait bounds для агульных функцый, так што падтрымліваюцца аргументы некалькіх тыпаў.Для прыкладаў глядзіце дакументацыю па кожным Portrait.
//!
//! Як аўтар бібліятэкі, вы заўсёды павінны аддаваць перавагу ўкараненню [`From<T>`][`From`] альбо [`TryFrom<T>`][`TryFrom`], а не [`Into<U>`][`Into`] ці [`TryInto<U>`][`TryInto`], бо [`From`] і [`TryFrom`] забяспечваюць вялікую гнуткасць і прапануюць эквівалентныя рэалізацыі [`Into`] або [`TryInto`] бясплатна, дзякуючы агульнай рэалізацыі ў стандартнай бібліятэцы.
//! Пры арыентацыі на версію да Rust 1.41 можа спатрэбіцца рэалізацыя [`Into`] альбо [`TryInto`] непасрэдна пры пераўтварэнні ў тып, які знаходзіцца па-за бягучым crate.
//!
//! # Агульныя рэалізацыі
//!
//! - [`AsRef`] і аўтаматычнае аднаўленне [`AsMut`], калі ўнутраны тып з'яўляецца спасылкай
//! - [`From`]`<U>для T` мае на ўвазе [`Into`]`</u><T><U>для U`</u>
//! - [`TryFrom`]`<U>для T` мае на ўвазе [`TryInto`]`</u><T><U>для U`</u>
//! - [`From`] і [`Into`] з'яўляюцца рэфлексіўнымі, што азначае, што ўсе тыпы могуць `into` самі і `from` самі
//!
//! Глядзіце кожны Portrait для прыкладаў выкарыстання.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Функцыя ідэнтычнасці.
///
/// Аб гэтай функцыі важна адзначыць дзве рэчы:
///
/// - Гэта не заўсёды эквівалентна закрыццю, як `|x| x`, паколькі закрыццё можа прымусіць `x` перайсці ў іншы тып.
///
/// - Ён перамяшчае ўваход `x`, перададзены функцыі.
///
/// Хоць гэта можа здацца дзіўным мець функцыю, якая проста вяртае ўвод, ёсць некалькі цікавых спосабаў выкарыстання.
///
///
/// # Examples
///
/// Выкарыстанне `identity`, каб нічога не рабіць у шэрагу іншых цікавых функцый:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Давайце зробім выгляд, што даданне-цікавая функцыя.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Выкарыстанне `identity` у якасці базавага выпадку "do nothing" ва ўмоўным:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Рабіце яшчэ цікавыя рэчы ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Выкарыстанне `identity` для захавання варыянтаў `Some` ітэратара `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Выкарыстоўваецца для таннага пераўтварэння спасылкі ў спасылку.
///
/// Гэты Portrait падобны на [`AsMut`], які выкарыстоўваецца для пераўтварэння паміж зменлівымі спасылкамі.
/// Калі вам трэба зрабіць дарагую канверсію, лепш укараніць [`From`] з тыпам `&T` альбо напісаць уласную функцыю.
///
/// `AsRef` мае тую ж сігнатуру, што і [`Borrow`], але [`Borrow`] адрозніваецца ў некалькіх аспектах:
///
/// - У адрозненне ад `AsRef`, [`Borrow`] мае коўдру impl для любога `T` і можа быць выкарыстаны як для спасылкі, так і для значэння.
/// - [`Borrow`] таксама патрабуе, каб [`Hash`], [`Eq`] і [`Ord`] для пазыковай кошту былі эквівалентныя значэнням уласнасці.
/// Па гэтай прычыне, калі вы хочаце пазычыць толькі адно поле структуры, вы можаце рэалізаваць `AsRef`, але не [`Borrow`].
///
/// **Note: Гэты Portrait не павінен выходзіць з ладу **.Калі пераўтварэнне не атрымалася, выкарыстоўвайце спецыяльны метад, які вяртае [`Option<T>`] або [`Result<T, E>`].
///
/// # Агульныя рэалізацыі
///
/// - `AsRef` аўтаматычныя спасылкі, калі ўнутраны тып з'яўляецца спасылкай або змянянай спасылкай (напрыклад: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Выкарыстоўваючы Portrait bounds, мы можам прымаць аргументы розных тыпаў, пакуль іх можна пераўтварыць у зададзены тып `T`.
///
/// Напрыклад: Ствараючы агульную функцыю, якая прымае `AsRef<str>`, мы выказваем жаданне прыняць у якасці аргумента ўсе спасылкі, якія можна пераўтварыць у [`&str`].
/// Паколькі [`String`] і [`&str`] рэалізуюць `AsRef<str>`, мы можам прыняць і тое, і іншае як уваходны аргумент.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Выконвае пераўтварэнне.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Выкарыстоўваецца для таннага пераўтварэнні пераўтваральнага эталона.
///
/// Гэты Portrait падобны на [`AsRef`], але выкарыстоўваецца для пераўтварэння паміж зменлівымі спасылкамі.
/// Калі вам трэба зрабіць дарагую канверсію, лепш укараніць [`From`] з тыпам `&mut T` альбо напісаць уласную функцыю.
///
/// **Note: Гэты Portrait не павінен выходзіць з ладу **.Калі пераўтварэнне не атрымалася, выкарыстоўвайце спецыяльны метад, які вяртае [`Option<T>`] або [`Result<T, E>`].
///
/// # Агульныя рэалізацыі
///
/// - `AsMut` аўтаматычныя спасылкі, калі ўнутраны тып з'яўляецца змянянай спасылкай (напрыклад: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Выкарыстоўваючы `AsMut` у якасці Portrait bound для агульнай функцыі, мы можам прыняць усе зменныя спасылкі, якія можна пераўтварыць у тып `&mut T`.
/// Паколькі [`Box<T>`] рэалізуе `AsMut<T>`, мы можам напісаць функцыю `add_one`, якая прымае ўсе аргументы, якія можна пераўтварыць у `&mut u64`.
/// Паколькі [`Box<T>`] рэалізуе `AsMut<T>`, `add_one` таксама прымае аргументы тыпу `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Выконвае пераўтварэнне.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Пераўтварэнне значэння ў значэнне, якое спажывае ўваходнае значэнне.Супрацьлегласць [`From`].
///
/// Трэба пазбягаць рэалізацыі [`Into`] і замест гэтага ўкараняць [`From`].
/// Рэалізацыя [`From`] аўтаматычна забяспечвае рэалізацыю [`Into`] дзякуючы агульнай рэалізацыі ў стандартнай бібліятэцы.
///
/// Аддавайце перавагу выкарыстанню [`Into`] перад [`From`] пры ўказанні Portrait bounds для агульнай функцыі, каб гарантаваць, што тыпы, якія рэалізуюць толькі [`Into`], таксама могуць быць выкарыстаны.
///
/// **Note: Гэты Portrait не павінен выходзіць з ладу **.Калі пераўтварэнне не атрымалася, выкарыстоўвайце [`TryInto`].
///
/// # Агульныя рэалізацыі
///
/// - [`Ад`]`<T>для U` маецца на ўвазе `Into<U> for T`
/// - [`Into`] з'яўляецца рэфлексіўным, што азначае, што `Into<T> for T` рэалізаваны
///
/// # Укараненне [`Into`] для пераўтварэння ў знешнія тыпы ў старых версіях Rust
///
/// Да Rust 1.41, калі тып прызначэння не быў часткай бягучага crate, вы не маглі непасрэдна рэалізаваць [`From`].
/// Напрыклад, возьмем гэты код:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Гэта не атрымаецца скампіляваць у старых версіях мовы, бо правілы сіроцтва Rust раней былі крыху больш строгімі.
/// Каб абыйсці гэта, вы можаце ўкараніць [`Into`] непасрэдна:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Важна разумець, што [`Into`] не забяспечвае рэалізацыю [`From`] (як [`From`] з [`Into`]).
/// Такім чынам, вы заўсёды павінны паспрабаваць рэалізаваць [`From`], а потым вярнуцца да [`Into`], калі [`From`] немагчыма рэалізаваць.
///
/// # Examples
///
/// [`String`] рэалізуе [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Для таго, каб выказаць, што мы хочам, каб агульная функцыя прымала ўсе аргументы, якія можна пераўтварыць у зададзены тып `T`, мы можам выкарыстоўваць Portrait bound з [`Into`]`<T>`.
///
/// Напрыклад: Функцыя `is_hello` прымае ўсе аргументы, якія можна пераўтварыць у [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Выконвае пераўтварэнне.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Выкарыстоўваецца для пераўтварэння значэння ў значэнне пры спажыванні ўваходнага значэння.Гэта ўзаемнасць [`Into`].
///
/// Заўсёды трэба аддаваць перавагу рэалізацыі `From` перад [`Into`], таму што рэалізацыя `From` аўтаматычна забяспечвае рэалізацыю [`Into`] дзякуючы агульнай рэалізацыі ў стандартнай бібліятэцы.
///
///
/// Укараняйце [`Into`] толькі пры арыентацыі на версію да Rust 1.41 і пераўтварэнні ў тып па-за бягучым crate.
/// `From` не змог зрабіць гэтыя тыпы пераўтварэнняў у больш ранніх версіях з-за правілаў сіроцтва Rust.
/// Для больш падрабязнай інфармацыі глядзіце [`Into`].
///
/// Аддавайце перавагу выкарыстанню [`Into`] перад выкарыстаннем `From` пры ўказанні Portrait bounds на агульнай функцыі.
/// Такім чынам, тыпы, якія непасрэдна рэалізуюць [`Into`], могуць быць выкарыстаны ў якасці аргументаў.
///
/// `From` таксама вельмі карысны пры апрацоўцы памылак.Пры пабудове функцыі, якая можа пацярпець няўдачу, тып вяртання звычайна будзе выглядаць у выглядзе `Result<T, E>`.
/// `From` Portrait спрашчае апрацоўку памылак, дазваляючы функцыі вярнуць адзін тып памылкі, які інкапсулюе некалькі тыпаў памылак.Для больш падрабязнай інфармацыі глядзіце раздзел "Examples" і [the book][book].
///
/// **Note: Гэты Portrait не павінен выходзіць з ладу **.Калі пераўтварэнне не атрымалася, выкарыстоўвайце [`TryFrom`].
///
/// # Агульныя рэалізацыі
///
/// - `From<T> for U` азначае [`Into`]`<U>для T`</u>
/// - `From` з'яўляецца рэфлексіўным, што азначае, што `From<T> for T` рэалізаваны
///
/// # Examples
///
/// [`String`] рэалізуе `From<&str>`:
///
/// Яўнае пераўтварэнне з `&str` у радок вырабляецца наступным чынам:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Падчас апрацоўкі памылак часта бывае карысна ўкараніць `From` для ўласнага тыпу памылак.
/// Пераўтвараючы тыпы асноўных памылак у наш уласны тып памылак, які інкапсулюе асноўны тып памылак, мы можам вярнуць адзін тып памылкі без страты інфармацыі аб асноўнай прычыне.
/// Аператар '?' аўтаматычна пераўтварае асноўны тып памылкі ў наш уласны тып памылкі, выклікаючы `Into<CliError>::into`, які аўтаматычна прадастаўляецца пры рэалізацыі `From`.
/// Затым кампілятар высветляе, якую рэалізацыю `Into` трэба выкарыстоўваць.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Выконвае пераўтварэнне.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Спроба пераўтварэння, якое спажывае `self`, што можа быць дарагім, а можа і не.
///
/// Аўтары бібліятэк звычайна не павінны непасрэдна рэалізоўваць гэты Portrait, але аддаюць перавагу ўкараненню [`TryFrom`] Portrait, які забяспечвае вялікую гнуткасць і забяспечвае эквівалентную рэалізацыю `TryInto` бясплатна, дзякуючы агульнай рэалізацыі ў стандартнай бібліятэцы.
/// Для атрымання дадатковай інфармацыі пра гэта глядзіце дакументацыю па [`Into`].
///
/// # Укараненне `TryInto`
///
/// Гэта пакутуе ад тых жа абмежаванняў і разваг, што і рэалізацыя [`Into`], падрабязней.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Тып, які вяртаецца ў выпадку памылкі пераўтварэння.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Выконвае пераўтварэнне.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Простыя і бяспечныя пераўтварэнні, якія пры некаторых абставінах могуць кантралявана не атрымацца.Гэта ўзаемнасць [`TryInto`].
///
/// Гэта карысна, калі вы робіце пераўтварэнне тыпу, якое можа быць трывіяльна паспяховым, але можа таксама спатрэбіцца спецыяльная апрацоўка.
/// Напрыклад, няма магчымасці пераўтварыць [`i64`] у [`i32`], выкарыстоўваючы [`From`] Portrait, таму што [`i64`] можа ўтрымліваць значэнне, якое [`i32`] не можа прадстаўляць, і таму пры пераўтварэнні будуць страчаны дадзеныя.
///
/// Гэта можа быць вырашана шляхам скарачэння [`i64`] да [`i32`] (па сутнасці, падаўшы значэнне [`i64`] па модулі [`i32::MAX`]) альбо проста вярнуўшы [`i32::MAX`] альбо іншым спосабам.
/// [`From`] Portrait прызначаны для ідэальных пераўтварэнняў, таму `TryFrom` Portrait паведамляе праграмісту, калі пераўтварэнне тыпу можа сапсавацца, і дазваляе ім вырашыць, як з гэтым справіцца.
///
/// # Агульныя рэалізацыі
///
/// - `TryFrom<T> for U` азначае [`TryInto`]`<U>для T`</u>
/// - [`try_from`] з'яўляецца рэфлексіўным, што азначае, што `TryFrom<T> for T` рэалізаваны і не можа выйсці з ладу-звязаны тып `Error` для выкліку `T::try_from()` для значэння тыпу `T`-гэта [`Infallible`].
/// Калі тып [`!`] стабілізуецца, [`Infallible`] і [`!`] будуць эквівалентнымі.
///
/// `TryFrom<T>` можна рэалізаваць наступным чынам:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Як апісана, [`i32`] рэалізуе `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Моўчкі скарачае `big_number`, патрабуе выяўлення і апрацоўкі абрэзкі пасля факту.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Вяртае памылку, таму што `big_number` занадта вялікі, каб змясціцца ў `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Вяртае `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Тып, які вяртаецца ў выпадку памылкі пераўтварэння.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Выконвае пераўтварэнне.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// АГУЛЬНЫЯ ЎЗНАЧАННІ
////////////////////////////////////////////////////////////////////////////////

// Як уздымы над&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Як пад'ёмнікі над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): заменіце вышэйзгаданыя імпульсы для&/&mut наступным больш агульным:
// // Як уздымы над Дэрэфам
// імпл <D: ?Sized + Deref<Target: AsRef<U>>, U:? Памер> AsRef <U>для D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut падымаецца над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): заменіце вышэйзгаданы impl для &mut наступным больш агульным:
// // AsMut падымаецца над DerefMut
// імпл <D: ?Sized + Deref<Target: AsMut<U>>, U:? Памер> AsMut <U>для D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// З мае на ўвазе Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Ад (і, такім чынам, Into) з'яўляецца рэфлексіўным
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Заўвага аб стабільнасці:** Гэты impl яшчэ не існуе, але мы "reserving space", каб дадаць яго ў future.
/// Падрабязнасці гл. У [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): замест гэтага зрабіце прынцыповае выпраўленне.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom азначае TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Беспамылковыя пераўтварэнні семантычна эквівалентныя беспамылковым пераўтварэнням з нежылым тыпам памылак.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОННЫЯ ІМПЛ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ТЫП НЕ ПАМЫЛКІ ПАМЫЛКІ
////////////////////////////////////////////////////////////////////////////////

/// Тып памылкі для памылак, якія ніколі не могуць адбыцца.
///
/// Паколькі гэты пералік не мае варыянту, значэнне гэтага тыпу ніколі не можа існаваць.
/// Гэта можа быць карысна для агульных API, якія выкарыстоўваюць [`Result`] і параметрызуюць тып памылкі, каб паказаць, што вынік заўсёды [`Ok`].
///
/// Напрыклад, [`TryFrom`] Portrait (пераўтварэнне, якое вяртае [`Result`]) мае агульную рэалізацыю для ўсіх тыпаў, дзе існуе зваротная рэалізацыя [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Сумяшчальнасць Future
///
/// Гэты пералік выконвае тую ж ролю, што і [the `!`“never”type][never], які нестабільны ў гэтай версіі Rust.
/// Калі `!` стабілізуецца, мы плануем зрабіць `Infallible` тыповым псеўданімам:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... і ў выніку састарэе `Infallible`.
///
/// Аднак ёсць адзін выпадак, калі сінтаксіс `!` можа быць выкарыстаны да таго, як `!` стабілізуецца як паўнавартасны тып: у пазіцыі тыпу вяртання функцыі.
/// У прыватнасці, магчымыя рэалізацыі для двух розных тыпаў паказальнікаў функцый:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Паколькі `Infallible` з'яўляецца пералікам, гэты код сапраўдны.
/// Аднак, калі `Infallible` стане псеўданімам для never type, два "impl" пачнуць перакрывацца і, такім чынам, будуць забаронены правіламі ўзгодненасці Portrait мовы.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}