use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Міры занадта павольная
fn exact_sanity_test() {
    // Гэты тэст у канчатковым выніку запускае тое, што я магу толькі выказаць здагадку, што гэта нейкі вуглавы выпадак з функцыяй бібліятэкі `exp2`, вызначаны ў любым выкананні C, якое мы выкарыстоўваем.
    // У VS 2013 у гэтай функцыі, мабыць, была памылка, бо пры тэставанні гэты тэст не атрымліваецца, але ў VS 2015 памылка выглядае выпраўленай, бо тэст працуе нармальна.
    //
    // Падобная памылка ўяўляе сабой розніцу ў значэнні вяртання `exp2(-1057)`, дзе ў VS 2013 ён вяртае двайнік з бітавым шаблонам 0x2, а ў VS 2015-0x20000.
    //
    //
    // На дадзены момант проста ігнаруйце гэты тэст цалкам на MSVC, бо ён і так пратэставаны ў любым іншым месцы, і мы не вельмі зацікаўлены ў тэставанні рэалізацыі exp2 кожнай платформы.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}