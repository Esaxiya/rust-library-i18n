// rsbegin.o і rsend.o-гэта так званыя "compiler runtime startup objects".
// Яны ўтрымліваюць код, неабходны для правільнай ініцыялізацыі часу працы кампілятара.
//
// Калі звязаны выканальны малюнак альбо выява dylib, усе карыстацкія коды і бібліятэкі з'яўляюцца "sandwiched" паміж гэтымі двума аб'ектнымі файламі, таму код альбо дадзеныя з rsbegin.o становяцца першымі ў адпаведных раздзелах выявы, тады як код і дадзеныя з rsend.o становяцца апошнімі.
// Гэты эфект можна выкарыстоўваць для размяшчэння сімвалаў у пачатку ці ў канцы раздзела, а таксама для ўстаўкі любых патрэбных калонтытулаў.
//
// Звярніце ўвагу, што фактычная кропка ўваходу ў модуль знаходзіцца ў аб'екце запуску C (звычайна называецца `crtX.o`), які затым выклікае зваротныя выклікі іншых кампанентаў выканання (зарэгістраваныя праз яшчэ адзін спецыяльны раздзел малюнка).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Адзначае пачатак кадра стэка, разгарнуць інфармацыйны раздзел
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Скрэтч для ўнутранага вядзення бухгалтэрыі раскручвальніка.
    // Гэта вызначана як `struct object` у $ GCC/wraind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Адпусціце інфармацыйныя працэдуры registration/deregistration.
    // Глядзіце дакументы libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // зарэгістраваць інфармацыю пра расслабленне пры запуску модуля
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // адмяніць рэгістрацыю пры адключэнні
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Спецыяльная рэгістрацыя init/uninit для MinGW
    pub mod mingw_init {
        // Аб'екты запуску MinGW (crt0.o/dllcrt0.o) будуць запускаць глабальныя канструктары ў раздзелах .ctors і .dtors пры запуску і выхадзе.
        // У выпадку DLL гэта робіцца пры загрузцы і разгрузцы DLL.
        //
        // Ссылка будзе сартаваць раздзелы, што гарантуе, што нашы зваротныя выклікі размешчаны ў канцы спісу.
        // Паколькі канструктары запускаюцца ў зваротным парадку, гэта гарантуе, што нашы зваротныя выклікі з'яўляюцца першым і апошнім.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Зваротныя выклікі ініцыялізацыі C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: зваротныя зваротныя выклікі
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}