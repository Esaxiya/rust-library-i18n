//! Implementarea panics prin derularea stivei
//!
//! Acest crate este o implementare a panics în Rust utilizând mecanismul de derulare a stivei "most native" a platformei pentru care este compilat.
//! În esență, acest lucru este clasificat în trei găleți în prezent:
//!
//! 1. Țintele MSVC folosesc SEH în fișierul `seh.rs`.
//! 2. Emscripten folosește excepții C++ în fișierul `emcc.rs`.
//! 3. Toate celelalte ținte folosesc libunwind/libgcc în fișierul `gcc.rs`.
//!
//! Mai multe documentații despre fiecare implementare pot fi găsite în modulul respectiv.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` este nefolosit cu Miri, deci avertismentele de liniște.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Obiectele de pornire ale Runtime-ului Rust depind de aceste simboluri, deci faceți-le publice.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ținte care nu acceptă derularea.
        // - arch=wasm32
        // - os=none (ținte "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Folosiți runtime-ul Miri.
        // Încă trebuie să încărcăm timpul de rulare normal de mai sus, deoarece rustc se așteaptă să fie definite anumite elemente lang de acolo.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Folosiți timpul real de rulare.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler în libstd este apelat atunci când un obiect panic este scăzut în afara `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler în libstd este apelat atunci când este surprinsă o excepție străină.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Punct de intrare pentru ridicarea unei excepții, doar delegați la implementarea specifică platformei.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}