//! Se desfășoară pentru ținta *wasm32*.
//!
//! În momentul de față nu susținem acest lucru, așa că este vorba doar de butoane.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}