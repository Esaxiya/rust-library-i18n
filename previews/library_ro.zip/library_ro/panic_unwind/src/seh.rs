//! Windows SEH
//!
//! Pe Windows (în prezent numai pe MSVC), mecanismul implicit de gestionare a excepțiilor este Structured Exception Handling (SEH).
//! Acest lucru este destul de diferit de gestionarea excepțiilor bazate pe Dwarf (de exemplu, ce utilizează alte platforme unix) în ceea ce privește compușii interni, așa că LLVM este obligat să aibă o cantitate mare de suport suplimentar pentru SEH.
//!
//! Pe scurt, ceea ce se întâmplă aici este:
//!
//! 1. Funcția `panic` apelează funcția Windows standard `_CxxThrowException` pentru a arunca o excepție de tip C++ , declanșând procesul de derulare.
//! 2.
//! Toate platformele de aterizare generate de compilator utilizează funcția de personalitate `__CxxFrameHandler3`, o funcție din CRT, iar codul de derulare din Windows va utiliza această funcție de personalitate pentru a executa tot codul de curățare din stivă.
//!
//! 3. Toate apelurile generate de compilator către `invoke` au un dispozitiv de aterizare setat ca o instrucțiune `cleanuppad` LLVM, care indică începutul rutinei de curățare.
//! Personalitatea (la pasul 2, definită în CRT) este responsabilă pentru rularea rutinelor de curățare.
//! 4. În cele din urmă, codul "catch" din intrinsecul `try` (generat de compilator) este executat și indică faptul că controlul ar trebui să revină la Rust.
//! Acest lucru se face printr-o instrucțiune `catchswitch` plus o instrucțiune `catchpad` în termeni LLVM IR, returnând în cele din urmă controlul normal programului cu o instrucțiune `catchret`.
//!
//! Unele diferențe specifice față de gestionarea excepțiilor bazate pe gcc sunt:
//!
//! * Rust nu are funcție personalizată personalizată, este în schimb *întotdeauna*`__CxxFrameHandler3`.În plus, nu se efectuează nicio filtrare suplimentară, așa că ajungem să prindem orice excepții C++ care se întâmplă să arate ca cele pe care le aruncăm.
//! Rețineți că aruncarea unei excepții în Rust este oricum un comportament nedefinit, deci ar trebui să fie bine.
//! * Avem câteva date pe care să le transmitem peste granița de desfășurare, în special un `Box<dyn Any + Send>`.Ca și în cazul excepțiilor Dwarf, aceste două indicatoare sunt stocate ca o sarcină utilă în excepția însăși.
//! Cu toate acestea, pe MSVC, nu este nevoie de o alocare de heap suplimentară, deoarece stiva de apeluri este păstrată în timp ce funcțiile de filtrare sunt executate.
//! Aceasta înseamnă că pointerele sunt transmise direct către `_CxxThrowException`, care sunt apoi recuperate în funcția de filtrare pentru a fi scrise în cadrul stivei din `try` intrinsec.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Aceasta trebuie să fie o opțiune, deoarece surprindem excepția prin referință, iar destructorul său este executat de runtime C++ .
    // Când scoatem caseta din excepție, trebuie să lăsăm excepția într-o stare validă pentru ca distructorul să ruleze fără a lăsa de două ori caseta.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// În primul rând, o grămadă de definiții de tip.Există câteva ciudățenii specifice platformei aici și multe care sunt doar copiate în mod flagrant din LLVM.Scopul tuturor este de a implementa funcția `panic` de mai jos printr-un apel către `_CxxThrowException`.
//
// Această funcție ia două argumente.Primul este un indicator către datele pe care le transmitem, care în acest caz este obiectul nostru trait.Destul de ușor de găsit!Următorul, însă, este mai complicat.
// Acesta este un indicator către o structură `_ThrowInfo` și, în general, este destinat doar să descrie excepția care este aruncată.
//
// În prezent, definiția acestui tip [1] este puțin păroasă, iar ciudățenia principală (și diferența față de articolul online) este că pe 32 de biți pointerii sunt pointeri, dar pe 64 de biți pointerii sunt exprimați ca compensări pe 32 de biți din Simbolul `__ImageBase`.
//
// Pentru a exprima acest lucru sunt utilizate macro-urile `ptr_t` și `ptr!` din modulele de mai jos.
//
// Labirintul definițiilor de tip urmează îndeaproape ceea ce emite LLVM pentru acest tip de operație.De exemplu, dacă compilați acest cod C++ pe MSVC și emiteți IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      nul foo() { rust_panic a = {0, 1};
//          arunca o;}
//
// În esență, asta încercăm să imităm.Majoritatea valorilor constante de mai jos au fost doar copiate din LLVM,
//
// În orice caz, aceste structuri sunt construite într-un mod similar și este oarecum detaliată pentru noi.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Rețineți că ignorăm intenționat regulile de manipulare a numelor aici: nu vrem ca C++ să poată prinde Rust panics prin simpla declarare a unui `struct rust_panic`.
//
//
// Când modificați, asigurați-vă că șirul de nume de tip se potrivește exact cu cel utilizat în `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Primul octet `\x01` de aici este de fapt un semnal magic către LLVM pentru a *nu* aplica nicio altă problemă, cum ar fi prefixarea cu un caracter `_`.
    //
    //
    // Acest simbol este tabelul vtable folosit de `std::type_info`-ul lui C++ .
    // Obiectele de tipul `std::type_info`, descriptorii de tip, au un indicator către acest tabel.
    // Descriptorii de tip sunt menționați de structurile C++ EH definite mai sus și pe care le construim mai jos.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Acest descriptor de tip este utilizat numai atunci când se lansează o excepție.
// Partea de captură este gestionată de try intrinsec, care își generează propriul TypeDescriptor.
//
// Acest lucru este în regulă, deoarece runtime-ul MSVC folosește comparația șirurilor pe numele tipului pentru a se potrivi cu TypeDescriptors mai degrabă decât cu egalitatea indicatorului.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor utilizat în cazul în care codul C++ decide să captureze excepția și să o renunțe fără a o propaga.
// Partea de captură a încercării intrinseci va seta primul cuvânt al obiectului de excepție la 0, astfel încât să fie omis de către destructor.
//
// Rețineți că x86 Windows folosește convenția de apelare "thiscall" pentru funcțiile de membru C++ în loc de convenția de apelare implicită "C".
//
// Funcția exception_copy este puțin specială aici: este invocată de runtime-ul MSVC sub un bloc try/catch și panic pe care îl generăm aici va fi folosit ca rezultat al copiei de excepție.
//
// Acesta este folosit de runtime-ul C++ pentru a accepta captarea excepțiilor cu std::exception_ptr, pe care nu le putem suporta deoarece Box<dyn Any>nu este clonabil.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException se execută în totalitate pe acest cadru de stivă, deci nu este nevoie să transferați altfel `data` în heap.
    // Trecem doar un indicator de stivă la această funcție.
    //
    // ManuallyDrop este necesar aici, deoarece nu vrem ca excepția să fie abandonată atunci când vă derulați.
    // În schimb, va fi eliminat de exception_cleanup, care este invocat de runtime-ul C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Acest lucru ... poate părea surprinzător și, în mod justificat.Pe MSVC pe 32 de biți, indicatorii dintre aceste structuri sunt doar asta, indicii.
    // Cu toate acestea, pe MSVC pe 64 de biți, indicatoarele dintre structuri sunt exprimate mai degrabă ca compensări pe 32 de biți de la `__ImageBase`.
    //
    // În consecință, pe MSVC pe 32 de biți putem declara toate aceste indicii în " static` de mai sus.
    // Pe MSVC pe 64 de biți, ar trebui să exprimăm scăderea de indicatori în statică, lucru pe care Rust nu îl permite în prezent, deci nu putem face acest lucru.
    //
    // Următorul lucru cel mai bun este atunci să completați aceste structuri în timpul rulării (panica este oricum deja "slow path").
    // Așadar, aici reinterpretăm toate aceste câmpuri de pointer ca numere întregi pe 32 de biți și apoi stocăm valoarea relevantă în el (atomic, deoarece se poate întâmpla panics concurent).
    //
    // Din punct de vedere tehnic, timpul de execuție va face probabil o citire nonatomică a acestor câmpuri, dar în teorie nu au citit niciodată valoarea *greșită*, deci nu ar trebui să fie prea rău ...
    //
    // În orice caz, practic trebuie să facem așa ceva până când putem exprima mai multe operații în statică (și poate că nu vom putea niciodată).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // O sarcină utilă NULL aici înseamnă că am ajuns aici din captura (...) a __rust_try.
    // Acest lucru se întâmplă atunci când este surprinsă o excepție străină non-Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Acest lucru este necesar de către compilator pentru a exista (de exemplu, este un element lang), dar niciodată nu este apelat de fapt de către compilator, deoarece __C_specific_handler sau_except_handler3 este funcția de personalitate care este întotdeauna utilizată.
//
// Prin urmare, acesta este doar un ciot de avort.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}