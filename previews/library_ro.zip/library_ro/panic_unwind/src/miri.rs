//! Deconectarea panics pentru Miri.
use alloc::boxed::Box;
use core::any::Any;

// Tipul de sarcină utilă pe care motorul Miri îl propagă prin derulare pentru noi.
// Trebuie să fie de dimensiunea indicatorului.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Funcția externă oferită de Miri pentru a începe desfacerea.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Sarcina utilă pe care o transmitem către `miri_start_panic` va fi exact argumentul pe care îl obținem în `cleanup` de mai jos.
    // Așa că o boxăm o singură dată, pentru a obține ceva de dimensiunea indicatorului.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Recuperați `Box`-ul subiacent.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}