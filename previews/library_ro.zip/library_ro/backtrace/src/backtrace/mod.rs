use core::ffi::c_void;
use core::fmt;

/// Inspectează stiva de apel curentă, trecând toate cadrele active în închiderea furnizată pentru a calcula o urmă de stivă.
///
/// Această funcție este calul de lucru al acestei biblioteci în calcularea urmelor stivei pentru un program.Închiderea dată `cb` este dată de instanțe ale unui `Frame` care reprezintă informații despre acel cadru de apel din stivă.
/// Închiderea este cedată cadrelor într-un mod de sus în jos (cel mai recent numit funcții mai întâi).
///
/// Valoarea returnată a închiderii este o indicație a faptului dacă urmărirea înapoi ar trebui să continue.O valoare de returnare `false` va termina retragerea și va reveni imediat.
///
/// Odată ce un `Frame` este achiziționat, probabil că veți dori să apelați `backtrace::resolve` pentru a converti adresa `ip` (indicatorul de instrucțiuni) sau adresa simbolului într-un `Symbol` prin care se poate afla numele și/sau numele fișierului/numărul liniei.
///
///
/// Rețineți că aceasta este o funcție de nivel relativ scăzut și dacă doriți, de exemplu, să capturați o urmă de urmărire pentru a fi inspectată ulterior, atunci tipul `Backtrace` poate fi mai potrivit.
///
/// # Caracteristici necesare
///
/// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
///
/// # Panics
///
/// Această funcție se străduiește să nu facă niciodată panic, dar dacă `cb` a furnizat panics, atunci unele platforme vor forța un panic dublu să întrerupă procesul.
/// Unele platforme utilizează o bibliotecă C care utilizează intern apeluri de apel care nu pot fi derulate, astfel încât panica de la `cb` poate declanșa o întrerupere a procesului.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // continuați retragerea
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// La fel ca `trace`, doar nesigur, deoarece este nesincronizat.
///
/// Această funcție nu are garanții de sincronizare, dar este disponibilă atunci când caracteristica `std` a acestui crate nu este compilată în.
/// Consultați funcția `trace` pentru mai multe documente și exemple.
///
/// # Panics
///
/// Vedeți informații despre `trace` pentru avertizări privind panica `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Un trait reprezentând un cadru al unui backtrace, cedat funcției `trace` a acestui crate.
///
/// Închiderea funcției de urmărire va avea cadrele cedate, iar cadrul este expediat practic, deoarece implementarea de bază nu este întotdeauna cunoscută până la runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Returnează indicatorul de instrucțiuni curent al acestui cadru.
    ///
    /// Aceasta este în mod normal următoarea instrucțiune de executat în cadru, dar nu toate implementările o listează cu o precizie de 100% (dar, în general, este destul de apropiată).
    ///
    ///
    /// Este recomandat să treceți această valoare către `backtrace::resolve` pentru a o transforma într-un nume de simbol.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Returnează indicatorul curent de stivă al acestui cadru.
    ///
    /// În cazul în care un backend nu poate recupera indicatorul stivei pentru acest cadru, se returnează un indicator nul.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Returnează adresa simbolului de pornire al cadrului acestei funcții.
    ///
    /// Aceasta va încerca să deruleze indicatorul de instrucțiuni returnat de `ip` la începutul funcției, returnând acea valoare.
    ///
    /// Cu toate acestea, în unele cazuri, backend-urile vor returna doar `ip` din această funcție.
    ///
    /// Valoarea returnată poate fi uneori utilizată dacă `backtrace::resolve` a eșuat pe `ip` dat mai sus.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Returnează adresa de bază a modulului căruia îi aparține cadrul.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Acest lucru trebuie să fie primul, pentru a se asigura că Miri are prioritate față de platforma gazdă
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // folosit doar în dbghelp simbolizează
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}