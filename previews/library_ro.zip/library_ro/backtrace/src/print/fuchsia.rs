use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr preia un callback care va primi un indicator dl_phdr_info pentru fiecare DSO care a fost conectat la proces.
    // dl_iterate_phdr asigură, de asemenea, că linkerul dinamic este blocat de la începutul până la sfârșitul iterației.
    // Dacă apelul invers returnează o valoare diferită de zero, iterația se termină mai devreme.
    // 'data' va fi transmis ca al treilea argument pentru apelare la fiecare apel.
    // 'size' oferă dimensiunea dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Trebuie să analizăm ID-ul de compilare și câteva date de bază ale antetului programului, ceea ce înseamnă că avem nevoie și de un pic de lucruri din specificațiile ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Acum trebuie să reproducem, bit pentru bit, structura tipului dl_phdr_info folosit de linkerul dinamic actual al fucsia.
// Chromium are, de asemenea, această limită ABI, precum și crashpad.
// În cele din urmă, am dori să mutăm aceste cazuri pentru a utiliza elf-search, dar ar trebui să oferim acest lucru în SDK și asta nu a fost încă realizat.
//
// Astfel, noi (și ei) suntem blocați să folosim această metodă care implică o cuplare strânsă cu libc fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nu avem nicio modalitate de a ști dacă verificăm dacă e_phoff și e_phnum sunt valide.
    // libc ar trebui să ne asigure acest lucru, totuși, deci este sigur să formăm o felie aici.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr reprezintă un antet de program ELF pe 64 de biți în endianitatea arhitecturii țintă.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr reprezintă un antet de program ELF valid și conținutul acestuia.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Nu avem nicio modalitate de a verifica dacă p_addr sau p_memsz sunt valide.
    // Libc-ul lui Fuchsia analizează notele mai întâi, totuși, prin faptul că sunt aici, aceste anteturi trebuie să fie valabile.
    //
    // NoteIter nu necesită ca datele subiacente să fie valide, dar necesită ca limitele să fie valide.
    // Avem încredere că libc ne-a asigurat că acesta este cazul nostru aici.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Tipul de notă pentru ID-urile de compilare.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr reprezintă un antet de notă ELF în endianitatea țintei.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nota reprezintă o notă ELF (antet + conținut).
// Numele este lăsat sub formă de felie u8, deoarece nu este întotdeauna terminat nul, iar rust face suficient de ușor să verificați dacă octeții se potrivesc oricum.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter vă permite să iterați în siguranță pe un segment de notă.
// Se termină de îndată ce apare o eroare sau nu mai există note.
// Dacă iterați peste date nevalide, acesta va funcționa ca și cum nu s-ar fi găsit note.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Este o funcție invariantă că indicatorul și dimensiunea date indică o gamă validă de octeți care poate fi citită.
    // Conținutul acestor octeți poate fi orice, dar intervalul trebuie să fie valid pentru ca acesta să fie sigur.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aliniază 'x' la alinierea " la` octet presupunând că 'to' este o putere de 2.
// Acesta urmează un model standard în codul de analiză ELF C/C ++ unde se utilizează (x + până la, 1) și -to.
// Rust nu vă lasă să negați folosirea, așa că îl folosesc
// Conversia complementului 2 pentru a recrea asta.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consumă un număr de octeți din felie (dacă este prezent) și se asigură în plus că felia finală este corect aliniată.
// Dacă fie numărul de octeți solicitați este prea mare, fie felia nu poate fi realiniată ulterior din cauza existenței insuficiente de octeți, nu se returnează Niciuna și felia nu este modificată.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Această funcție nu are invarianți reali pe care trebuie să îi susțină apelantul, în afară de faptul că 'bytes' ar trebui aliniat pentru performanță (și pentru anumite arhitecturi corectitudinea).
// Valorile din câmpurile Elf_Nhdr pot fi prostii, dar această funcție nu asigură așa ceva.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Acest lucru este sigur atât timp cât există suficient spațiu și tocmai am confirmat că în declarația if de mai sus, deci acest lucru nu ar trebui să fie nesigur.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Rețineți că sice_of: :<Elf_Nhdr>() este întotdeauna aliniat pe 4 octeți.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Verifică dacă am ajuns la final.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutăm un nhdr, dar luăm în considerare cu atenție structura rezultată.
        // Nu avem încredere în namesz sau descsz și nu luăm decizii nesigure pe baza tipului.
        //
        // Deci, chiar dacă scoatem gunoi complet, ar trebui să fim în siguranță.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indică faptul că un segment este executabil.
const PERM_X: u32 = 0b00000001;
/// Indică faptul că un segment se poate scrie.
const PERM_W: u32 = 0b00000010;
/// Indică faptul că un segment este lizibil.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Reprezintă un segment ELF în timpul rulării.
struct Segment {
    /// Oferă adresa virtuală de execuție a conținutului acestui segment.
    addr: usize,
    /// Oferă dimensiunea memoriei conținutului acestui segment.
    size: usize,
    /// Oferă adresa virtuală a modulului acestui segment cu fișierul ELF.
    mod_rel_addr: usize,
    /// Oferă permisiunile găsite în fișierul ELF.
    /// Cu toate acestea, aceste permisiuni nu sunt neapărat permisiuni prezente în timpul rulării.
    flags: Perm,
}

/// Permite o iterație pe Segmente dintr-un DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Reprezintă un ELF DSO (Dynamic Shared Object).
/// Acest tip face referire la datele stocate în DSO-ul real, mai degrabă decât să-și facă propria copie.
struct Dso<'a> {
    /// Linkerul dinamic ne oferă întotdeauna un nume, chiar dacă numele este gol.
    /// În cazul executabilului principal, acest nume va fi gol.
    /// În cazul unui obiect partajat, acesta va fi soname (vezi DT_SONAME).
    name: &'a str,
    /// Pe Fuchsia, practic toate binare au ID-uri de construcție, dar aceasta nu este o cerință strictă.
    /// Nu există nicio modalitate de a corela informațiile DSO cu un fișier ELF real dacă nu există build_id, deci este necesar ca fiecare DSO să aibă unul aici.
    ///
    /// DSO-urile fără build_id sunt ignorate.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Returnează un iterator peste Segmente în acest DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Aceste erori codifică problemele care apar în timpul analizării informațiilor despre fiecare DSO.
///
enum Error {
    /// NameError înseamnă că a apărut o eroare la conversia unui șir de stil C într-un șir rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError înseamnă că nu am găsit un ID de compilare.
    /// Acest lucru se poate datora faptului că DSO nu avea ID de compilare sau că segmentul care conține ID-ul de compilare a fost malformat.
    ///
    BuildIDError,
}

/// Apelează fie 'dso', fie 'error' pentru fiecare DSO conectat în proces de linkerul dinamic.
///
///
/// # Arguments
///
/// * `visitor` - Un DsoPrinter care va avea una dintre metodele de mâncare numită foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr se asigură că info.name va indica o locație validă.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Această funcție imprimă marcajul simbolizator Fuchsia pentru toate informațiile conținute într-un DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}