#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Un formatator pentru backtraces.
///
/// Acest tip poate fi utilizat pentru a imprima un backtrace indiferent de unde provine backtrace în sine.
/// Dacă aveți un tip `Backtrace`, atunci implementarea sa `Debug` utilizează deja acest format de imprimare.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Stilurile de tipărire pe care le putem imprima
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Tipărește un traseu terser care în mod ideal conține doar informații relevante
    Short,
    /// Tipărește un backtrace care conține toate informațiile posibile
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Creați un nou `BacktraceFmt` care va scrie ieșirea pe `fmt` furnizat.
    ///
    /// Argumentul `format` va controla stilul în care se tipărește backtrace, iar argumentul `print_path` va fi utilizat pentru a imprima instanțele `BytesOrWideString` ale numelor de fișiere.
    /// Acest tip în sine nu face nici o tipărire a numelor de fișiere, dar acest apel invers este necesar pentru a face acest lucru.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Tipărește un preambul pentru urmele urmând a fi tipărite.
    ///
    /// Acest lucru este necesar pe unele platforme pentru ca backtraces-urile să fie simbolizate pe deplin ulterior și altfel aceasta ar trebui să fie doar prima metodă pe care o apelați după crearea unui `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Adaugă un cadru la ieșirea backtrace.
    ///
    /// Acest commit returnează o instanță RAII a unui `BacktraceFrameFmt` care poate fi utilizată pentru a imprima efectiv un cadru, iar la distrugere va crește contorul de cadre.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Finalizează ieșirea backtrace.
    ///
    /// Acesta este în prezent un no-op, dar este adăugat pentru compatibilitatea future cu formatele de backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // În prezent, nu există opțiuni-inclusiv acest hook pentru a permite adăugiri future.
        Ok(())
    }
}

/// Un formatator pentru un singur cadru dintr-un traseu.
///
/// Acest tip este creat de funcția `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Tipărește un `BacktraceFrame` cu acest formatator de cadre.
    ///
    /// Aceasta va imprima recursiv toate instanțele `BacktraceSymbol` din `BacktraceFrame`.
    ///
    /// # Caracteristici necesare
    ///
    /// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Tipărește un `BacktraceSymbol` într-un `BacktraceFrame`.
    ///
    /// # Caracteristici necesare
    ///
    /// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: nu este grozav că nu ajungem să tipărim nimic
            // cu nume de fișiere non-utf8.
            // Din fericire, aproape totul este utf8, deci nu ar trebui să fie prea rău.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Tipărește un `Frame` și `Symbol` urmărite brute, de obicei din callback-urile brute ale acestui crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Adaugă un cadru brut la ieșirea backtrace.
    ///
    /// Această metodă, spre deosebire de cea anterioară, ia argumentele brute în cazul în care sunt surse din locații diferite.
    /// Rețineți că acest lucru poate fi apelat de mai multe ori pentru un singur cadru.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Adaugă un cadru brut la ieșirea backtrace, inclusiv informații despre coloană.
    ///
    /// Această metodă, ca și cea precedentă, ia argumentele brute în cazul în care sunt surse din locații diferite.
    /// Rețineți că acest lucru poate fi apelat de mai multe ori pentru un singur cadru.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia nu poate simboliza într-un proces, astfel încât are un format special care poate fi folosit pentru a simboliza mai târziu.
        // Imprimați asta în loc să imprimați adrese în formatul nostru aici.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Nu este nevoie să imprimați cadre "null", practic înseamnă doar că sistemul de urmărire a sistemului era puțin dornic să urmărească foarte departe.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Pentru a reduce dimensiunea TCB în enclava Sgx, nu dorim să implementăm funcționalitatea de rezoluție a simbolurilor.
        // Mai degrabă, putem imprima aici offset-ul adresei, care ar putea fi ulterior mapat pentru a corecta funcția.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Imprimați indexul cadrului, precum și indicatorul de instrucțiuni opțional al cadrului.
        // Dacă suntem dincolo de primul simbol al acestui cadru, deși imprimăm doar spații albe adecvate.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // În continuare, scrieți numele simbolului, utilizând formatarea alternativă pentru mai multe informații, dacă suntem un backtrace complet.
        // Aici ne ocupăm și de simboluri care nu au un nume,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Și la final, tipăriți numărul filename/line dacă sunt disponibile.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line sunt tipărite pe linii sub numele simbolului, așa că tipăriți niște spațiu alb adecvat pentru a ne alinia la dreapta.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegați la apelul nostru intern pentru a imprima numele fișierului și apoi imprimați numărul liniei.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Adăugați numărul coloanei, dacă este disponibil.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Ne pasă doar de primul simbol al unui cadru
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}