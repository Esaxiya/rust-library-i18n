//! Tipuri dependente de platformă.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// O reprezentare independentă a unei șiruri de platformă.
/// Când lucrați cu `std` activat, se recomandă metodele de comoditate pentru furnizarea de conversii la tipurile `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// O felie, de obicei furnizată pe platformele Unix.
    Bytes(&'a [u8]),
    /// Șiruri largi de obicei de la Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy se convertește într-un `Cow<str>`, va aloca dacă `Bytes` nu este valid UTF-8 sau dacă `BytesOrWideString` este `Wide`.
    ///
    /// # Caracteristici necesare
    ///
    /// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Oferă o reprezentare `Path` a `BytesOrWideString`.
    ///
    /// # Caracteristici necesare
    ///
    /// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}