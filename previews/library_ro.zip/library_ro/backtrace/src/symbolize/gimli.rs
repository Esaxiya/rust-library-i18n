//! Suport pentru simbolizare utilizând `gimli` crate pe crates.io
//!
//! Aceasta este implementarea implicită de simbolizare pentru Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // " Durata de viață statică este o minciună de a spori lipsa de sprijin pentru structurile auto-referențiale.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Treceți la " durate de viață statice`, deoarece simbolurile ar trebui să împrumute doar `map` și `stash` și le păstrăm mai jos.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Pentru încărcarea bibliotecilor native pe Windows, consultați câteva discuții despre rust-lang/rust#71060 pentru diferitele strategii aici.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Bibliotecile MinGW în prezent nu acceptă ASLR (rust-lang/rust#16514), dar DLL-urile pot fi încă mutate în spațiul de adrese.
            // Se pare că adresele din informațiile de depanare sunt toate de parcă această bibliotecă ar fi încărcată la "image base", care este un câmp din antetele de fișiere COFF.
            // Deoarece acest lucru pare a fi listat de debuginfo, analizăm tabelul de simboluri și stocăm adresele ca și când biblioteca ar fi fost încărcată și la "image base".
            //
            // Cu toate acestea, biblioteca nu poate fi încărcată la "image base".
            // (probabil se poate încărca altceva acolo?) Aici intră în joc câmpul `bias` și trebuie să ne dăm seama de valoarea lui `bias` aici.Din păcate, deși nu este clar cum să obțineți acest lucru de la un modul încărcat.
            // Cu toate acestea, ceea ce avem este adresa de încărcare reală (`modBaseAddr`).
            //
            // Ca un pic de cop-out, deocamdată, am mapat fișierul, citim informațiile despre antetul fișierului, apoi aruncăm mmap-ul.Acest lucru este risipitor, deoarece probabil vom redeschide mai târziu mmap-ul, dar acest lucru ar trebui să funcționeze suficient de bine pentru moment.
            //
            // Odată ce avem `image_base` (locația de încărcare dorită) și `base_addr` (locația de încărcare reală) putem completa `bias` (diferența dintre cea reală și cea dorită) și apoi adresa specificată a fiecărui segment este `image_base`, deoarece asta spune fișierul.
            //
            //
            // Deocamdată se pare că spre deosebire de ELF/MachO ne putem descurca cu un segment pe bibliotecă, folosind `modBaseSize` ca dimensiune întreagă.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS folosește formatul de fișier Mach-O și folosește API-uri specifice DYLD pentru a încărca o listă de biblioteci native care fac parte din aplicație.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Aduceți numele acestei biblioteci care corespunde și calea unde să o încărcați.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Încărcați antetul de imagine al acestei biblioteci și delegați la `object` pentru a analiza toate comenzile de încărcare, astfel încât să putem afla toate segmentele implicate aici.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Repetați segmentele și înregistrați regiunile cunoscute pentru segmentele pe care le găsim.
            // În plus, înregistrați informații despre segmentele de text pentru procesare ulterioară, consultați comentariile de mai jos.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Determinați "slide" pentru această bibliotecă care ajunge să fie prejudecata pe care o folosim pentru a afla unde sunt încărcate obiecte din memorie.
            // Totuși, acest lucru este un pic cam ciudat și este rezultatul încercării câtorva lucruri în sălbăticie și de a vedea ce se lipeste.
            //
            // Ideea generală este că `bias` plus un segment `stated_virtual_memory_address` va fi locul în care se află spațiul de adresă real.
            // Celălalt lucru pe care ne bazăm este că o adresă reală minus `bias` este indexul pentru a căuta în tabelul de simboluri și în debuginfo.
            //
            // Se pare, totuși, că pentru bibliotecile încărcate de sistem aceste calcule sunt incorecte.Cu toate acestea, pentru executabile native, pare corect.
            // Ridicând o oarecare logică din sursa LLDB, aceasta are o anumită carcasă specială pentru prima secțiune `__TEXT` încărcată din fișierul 0 cu o dimensiune diferită de zero.
            // Indiferent de motiv, atunci când acest lucru este prezent, pare să însemne că tabelul de simboluri este relativ la doar diapozitivul vmaddr pentru bibliotecă.
            // Dacă este *nu* prezent, tabelul de simboluri este relativ la diapozitivul vmaddr plus adresa indicată a segmentului.
            //
            // Pentru a rezolva această situație dacă *nu* găsim o secțiune de text la zero, atunci creștem tendința cu adresa indicată a primelor secțiuni de text și micșorăm și toate adresele declarate cu suma respectivă.
            //
            // În acest fel, tabelul de simboluri apare întotdeauna în raport cu valoarea de părtinire a bibliotecii.
            // Acest lucru pare să aibă rezultatele potrivite pentru simbolizare prin intermediul tabelului cu simboluri.
            //
            // Sincer, nu sunt pe deplin sigur dacă acest lucru este corect sau dacă mai există ceva care ar trebui să indice cum să faci acest lucru.
            // Deocamdată, acest lucru pare să funcționeze suficient de bine (?) și ar trebui să putem întotdeauna să modificăm acest lucru în timp, dacă este necesar.
            //
            // Pentru mai multe informații, consultați #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Alte Unix (de ex
        // Platformele Linux) folosesc ELF ca format de fișier obiect și implementează de obicei un API numit `dl_iterate_phdr` pentru a încărca biblioteci native.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ar trebui să fie un indiciu valid.
        // `vec` ar trebui să fie un indicator valid pentru un `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 nu acceptă în mod nativ informațiile de depanare, dar sistemul de construcție va plasa informațiile de depanare pe calea `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Toate celelalte ar trebui să utilizeze ELF, dar nu știe cum să încarce bibliotecile native.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Toate bibliotecile partajate cunoscute care au fost încărcate.
    libraries: Vec<Library>,

    /// Cache de mapări în care păstrăm informații pitice analizate.
    ///
    /// Această listă are o capacitate fixă pentru întreaga sa durată de ridicare, care nu crește niciodată.
    /// Elementul `usize` al fiecărei perechi este un index în `libraries` de mai sus, unde `usize::max_value()` reprezintă executabilul curent.
    ///
    /// `Mapping` este o informație pitică analizată corespunzătoare.
    ///
    /// Rețineți că acesta este practic un cache LRU și vom schimba lucrurile aici în timp ce simbolizăm adresele.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmente ale acestei biblioteci încărcate în memorie și unde sunt încărcate.
    segments: Vec<LibrarySegment>,
    /// "bias"-ul acestei biblioteci, de obicei acolo unde este încărcat în memorie.
    /// Această valoare este adăugată la adresa specificată a fiecărui segment pentru a obține adresa de memorie virtuală reală în care este încărcat segmentul.
    /// În plus, această prejudecată este scăzută din adresele reale de memorie virtuală pentru a indexa în debuginfo și în tabelul de simboluri.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Adresa indicată a acestui segment în fișierul obiect.
    /// Acesta nu este de fapt locul în care este încărcat segmentul, ci mai degrabă această adresă, plus `bias`-ul bibliotecii care conține, este locul unde îl puteți găsi.
    ///
    stated_virtual_memory_address: usize,
    /// Dimensiunea segmentului din memorie.
    len: usize,
}

// nesigur, deoarece este necesar să fie sincronizat extern
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // nesigur, deoarece este necesar să fie sincronizat extern
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Un cache LRU foarte mic, foarte simplu, pentru mapări de informații de depanare.
        //
        // Rata de accesare ar trebui să fie foarte mare, deoarece stiva tipică nu traversează multe biblioteci partajate.
        //
        // Structurile `addr2line::Context` sunt destul de scumpe de creat.
        // Costul său este de așteptat să fie amortizat de interogările ulterioare `locate`, care valorifică structurile construite atunci când se construiește `addr2line: : Context`s pentru a obține accelerații frumoase.
        //
        // Dacă nu am avea acest cache, acea amortizare nu s-ar întâmpla niciodată, iar simbolurile backtraces ar fi ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Mai întâi, testați dacă acest `lib` are vreun segment care conține `addr` (gestionarea relocării).Dacă această verificare trece, putem continua mai jos și traduce adresa.
                //
                // Rețineți că folosim `wrapping_add` aici pentru a evita verificările de depășire.S-a văzut în sălbăticie că calculul de prejudecată SVMA + se revarsă.
                // Pare puțin ciudat că s-ar întâmpla, dar nu putem face o cantitate uriașă în afară de asta, decât să ignorăm doar aceste segmente, deoarece probabil că sunt îndreptate spre spațiu.
                //
                // Acest lucru a apărut inițial în rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Acum, că știm că `lib` conține `addr`, putem compensa cu părtinirea pentru a găsi adresa de memorie virală declarată.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: după ce acest condițional se completează fără revenire timpurie
        // dintr-o eroare, intrarea cache pentru această cale este la indexul 0.

        if let Some(idx) = idx {
            // Când maparea este deja în cache, mutați-o în față.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Când maparea nu se află în cache, creați o nouă mapare, introduceți-o în partea din față a cache-ului și evacuați cea mai veche intrare cache, dacă este necesar.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // nu pierdeți durata de viață a `'static`, asigurați-vă că este doar pentru noi înșine
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Extindeți durata de viață a `sym` la `'static`, deoarece, din păcate, ni se cere aici, dar va ieși mereu ca referință, astfel încât nicio referire la acesta nu ar trebui să fie persistată dincolo de acest cadru.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // În cele din urmă, obțineți o mapare cache sau creați o nouă mapare pentru acest fișier și evaluați informațiile DWARF pentru a găsi file/line/name pentru această adresă.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Am reușit să localizăm informații despre cadru pentru acest simbol, iar cadrul " addr2line` are în interior toate detaliile minunate.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Nu am putut găsi informații de depanare, dar le-am găsit în tabelul de simboluri al executabilului elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}