// folosit doar pe Linux chiar acum, așa că permiteți codul mort în altă parte
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Un simplu alocator de arenă pentru tampoane de octeți.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Alocă un buffer de dimensiunea specificată și returnează o referință mutabilă la acesta.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SIGURANȚĂ: aceasta este singura funcție care construiește vreodată un mutabil
        // referință la `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SIGURANȚĂ: nu eliminăm niciodată elemente din `self.buffers`, deci o referință
        // la datele din interiorul oricărui tampon va trăi atâta timp cât `self` o face.
        &mut buffers[i]
    }
}