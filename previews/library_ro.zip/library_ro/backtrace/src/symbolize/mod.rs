use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Rezolvați o adresă către un simbol, trecând simbolul la închiderea specificată.
///
/// Această funcție va căuta adresa dată în zone precum tabelul de simboluri local, tabelul de simboluri dinamic sau informațiile de depanare DWARF (în funcție de implementarea activată) pentru a găsi simboluri de cedat.
///
///
/// Închiderea nu poate fi apelată dacă nu s-a putut efectua rezoluția și, de asemenea, poate fi apelată de mai multe ori în cazul funcțiilor înclinate.
///
/// Simbolurile oferite reprezintă execuția la `addr` specificat, returnând perechile file/line pentru acea adresă (dacă sunt disponibile).
///
/// Rețineți că, dacă aveți un `Frame`, atunci este recomandat să utilizați funcția `resolve_frame` în locul acestei.
///
/// # Caracteristici necesare
///
/// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
///
/// # Panics
///
/// Această funcție se străduiește să nu facă niciodată panic, dar dacă `cb` a furnizat panics, atunci unele platforme vor forța un panic dublu să întrerupă procesul.
/// Unele platforme utilizează o bibliotecă C care utilizează intern apeluri de apel care nu pot fi derulate, astfel încât panica de la `cb` poate declanșa o întrerupere a procesului.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // uită-te doar la cadrul superior
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Rezolvați un cadru de captură anterior la un simbol, trecând simbolul la închiderea specificată.
///
/// Această funcție îndeplinește aceeași funcție ca `resolve`, cu excepția faptului că ia un `Frame` ca argument în loc de adresă.
/// Acest lucru poate permite unele implementări de platformă de backtracing pentru a oferi informații mai precise despre simbol sau informații despre cadre inline, de exemplu.
///
/// Este recomandat să utilizați acest lucru, dacă puteți.
///
/// # Caracteristici necesare
///
/// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
///
/// # Panics
///
/// Această funcție se străduiește să nu facă niciodată panic, dar dacă `cb` a furnizat panics, atunci unele platforme vor forța un panic dublu să întrerupă procesul.
/// Unele platforme utilizează o bibliotecă C care utilizează intern apeluri de apel care nu pot fi derulate, astfel încât panica de la `cb` poate declanșa o întrerupere a procesului.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // uită-te doar la cadrul superior
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Valorile IP din cadrele stivei sunt de obicei (always?) instrucțiunea *după* apelul care este urmărirea reală a stivei.
// Simbolizarea acestei activări face ca numărul filename/line să fie cu un avans și poate în gol dacă este aproape de sfârșitul funcției.
//
// Acest lucru pare să fie întotdeauna cazul pe toate platformele, așa că scădem întotdeauna unul dintr-un ip rezolvat pentru a-l rezolva la instrucțiunea de apel anterioară în loc să fie returnată instrucțiunii.
//
//
// În mod ideal, nu am face acest lucru.
// În mod ideal, am solicita apelanților API-urilor `resolve` aici să facă manual -1 și să afle că vor informații despre locație pentru instrucțiunea *anterioară*, nu pentru cea curentă.
// Ideal ar fi să expunem și pe `Frame` dacă suntem într-adevăr adresa următoarei instrucțiuni sau a curentului.
//
// Deocamdată, deși aceasta este o preocupare destul de nișă, așa că doar pe scară internă o scădem întotdeauna.
// Consumatorii ar trebui să continue să lucreze și să obțină rezultate destul de bune, așa că ar trebui să fim suficient de buni.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// La fel ca `resolve`, doar nesigur, deoarece este nesincronizat.
///
/// Această funcție nu are garanții de sincronizare, dar este disponibilă atunci când caracteristica `std` a acestui crate nu este compilată în.
/// Consultați funcția `resolve` pentru mai multe documente și exemple.
///
/// # Panics
///
/// Vedeți informații despre `resolve` pentru avertizări privind panica `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// La fel ca `resolve_frame`, doar nesigur, deoarece este nesincronizat.
///
/// Această funcție nu are garanții de sincronizare, dar este disponibilă atunci când caracteristica `std` a acestui crate nu este compilată în.
/// Consultați funcția `resolve_frame` pentru mai multe documente și exemple.
///
/// # Panics
///
/// Vedeți informații despre `resolve_frame` pentru avertizări privind panica `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Un trait reprezentând rezoluția unui simbol într-un fișier.
///
/// Acest trait este cedat ca obiect trait închiderii date funcției `backtrace::resolve` și este practic expediat deoarece nu se știe ce implementare se află în spatele acestuia.
///
///
/// Un simbol poate oferi informații contextuale despre o funcție, de exemplu numele, numele fișierului, numărul liniei, adresa precisă etc.
/// Cu toate acestea, nu toate informațiile sunt întotdeauna disponibile într-un simbol, deci toate metodele returnează un `Option`.
///
///
pub struct Symbol {
    // TODO: această legătură pe viață trebuie persistată în cele din urmă până la `Symbol`,
    // dar aceasta este în prezent o schimbare de rupere.
    // Deocamdată, acest lucru este sigur, deoarece `Symbol` este distribuit doar prin referință și nu poate fi clonat.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Returnează numele acestei funcții.
    ///
    /// Structura returnată poate fi utilizată pentru interogarea diferitelor proprietăți despre numele simbolului:
    ///
    ///
    /// * Implementarea `Display` va imprima simbolul demanglat.
    /// * Valoarea brută `str` a simbolului poate fi accesată (dacă este valabilă utf-8).
    /// * Oteții bruti pentru numele simbolului pot fi accesate.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Returnează adresa de pornire a acestei funcții.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Returnează numele de fișier brut ca o felie.
    /// Acest lucru este util în principal pentru mediile `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Returnează numărul coloanei pentru locul în care se execută în prezent acest simbol.
    ///
    /// Numai gimli oferă în prezent o valoare aici și chiar atunci numai dacă `filename` returnează `Some` și, prin urmare, este supus în consecință unor avertismente similare.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Returnează numărul liniei pentru locul în care se execută în prezent acest simbol.
    ///
    /// Această valoare returnată este de obicei `Some` dacă `filename` returnează `Some` și, prin urmare, este supusă unor avertismente similare.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Returnează numele fișierului unde a fost definită această funcție.
    ///
    /// Acest lucru este disponibil momentan doar când se utilizează libbacktrace sau gimli (de ex
    /// unix platforme altele) și atunci când un binar este compilat cu debuginfo.
    /// Dacă niciuna dintre aceste condiții nu este îndeplinită, atunci aceasta va returna probabil `None`.
    ///
    /// # Caracteristici necesare
    ///
    /// Această funcție necesită activarea caracteristicii `std` a `backtrace` crate, iar caracteristica `std` este activată în mod implicit.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Poate un simbol C++ analizat, dacă analiza simbolului modificat ca Rust a eșuat.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Asigurați-vă că păstrați această dimensiune zero, astfel încât caracteristica `cpp_demangle` să nu aibă costuri atunci când este dezactivată.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// O învelitoare în jurul unui nume de simbol pentru a oferi accesori ergonomici la numele demanglat, octeții bruti, șirul brut etc.
///
// Permiteți codul mort pentru când caracteristica `cpp_demangle` nu este activată.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Creează un nou nume de simbol din octeții subiecți bruti.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Returnează numele brut al simbolului (mangled) ca `str` dacă simbolul este utf-8 valid.
    ///
    /// Utilizați implementarea `Display` dacă doriți versiunea demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Returnează numele brut al simbolului ca listă de octeți
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Acest lucru se poate imprima dacă simbolul demanglat nu este de fapt valid, așa că rezolvați eroarea aici cu grație, nu propagându-l în exterior.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Încercați să recuperați acea memorie cache utilizată pentru a simboliza adresele.
///
/// Această metodă va încerca să elibereze orice structuri de date globale care au fost altfel memorate în cache la nivel global sau în firul care reprezintă de obicei informații DWARF analizate sau similare.
///
///
/// # Caveats
///
/// Deși această funcție este întotdeauna disponibilă, de fapt nu face nimic în majoritatea implementărilor.
/// Bibliotecile precum dbghelp sau libbacktrace nu oferă facilități pentru a deloca statul și a gestiona memoria alocată.
/// Deocamdată caracteristica `gimli-symbolize` a acestui crate este singura caracteristică în care această funcție are vreun efect.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}