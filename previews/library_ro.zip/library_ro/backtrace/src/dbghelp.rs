//! Un modul pentru a ajuta la gestionarea legărilor dbghelp pe Windows
//!
//! Backtraces pe Windows (cel puțin pentru MSVC) sunt alimentate în mare parte prin `dbghelp.dll` și diferitele funcții pe care le conține.
//! Aceste funcții sunt încărcate în mod curent *dinamic* mai degrabă decât conectarea statică la `dbghelp.dll`.
//! Acest lucru este realizat în prezent de biblioteca standard (și este teoretic necesar acolo), dar este un efort de a ajuta la reducerea dependențelor statice dll ale unei biblioteci, deoarece backtraces sunt de obicei destul de opționale.
//!
//! Acestea fiind spuse, `dbghelp.dll` se încarcă aproape întotdeauna cu succes pe Windows.
//!
//! Rețineți însă că, din moment ce încărcăm tot acest suport dinamic, nu putem folosi definițiile brute în `winapi`, ci mai degrabă trebuie să definim noi înșine tipul de pointer funcțional și să îl folosim.
//! Nu vrem cu adevărat să ne ocupăm de duplicarea winapi, așa că avem o caracteristică Cargo `verify-winapi` care afirmă că toate legările se potrivesc cu cele din winapi și această caracteristică este activată pe CI.
//!
//! În cele din urmă, veți observa aici că DLL pentru `dbghelp.dll` nu este niciodată descărcat și acest lucru este în mod intenționat.
//! Gândirea este că o putem cache la nivel global și o putem folosi între apeluri către API, evitând loads/unloads scump.
//! Dacă aceasta este o problemă pentru detectoarele de scurgere sau ceva de genul acesta, putem trece podul când ajungem acolo.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Lucrați în jurul `SymGetOptions` și `SymSetOptions` nefiind prezent în Winapi în sine.
// În caz contrar, acest lucru este utilizat numai atunci când verificăm dublu tipurile împotriva winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Nu este definit încă în winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Acest lucru este definit în winapi, dar este incorect (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Nu este definit încă în winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Această macrocomandă este utilizată pentru a defini o structură `Dbghelp` care conține intern toate indicatoarele funcționale pe care le-am putea încărca.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL-ul încărcat pentru `dbghelp.dll`
            dll: HMODULE,

            // Fiecare indicator de funcție pentru fiecare funcție pe care l-am putea folosi
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inițial nu am încărcat DLL-ul
            dll: 0 as *mut _,
            // Inițial, toate funcțiile sunt setate la zero pentru a spune că trebuie încărcate dinamic.
            //
            $($name: 0,)*
        };

        // Comoditate tip pentru fiecare tip de funcție.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Încearcă să deschidă `dbghelp.dll`.
            /// Returnează succesul dacă funcționează sau eroare dacă `LoadLibraryW` eșuează.
            ///
            /// Panics dacă biblioteca este deja încărcată.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funcția pentru fiecare metodă pe care am dori să o folosim.
            // Când este apelat, fie va citi indicatorul funcției cache, fie îl va încărca și va returna valoarea încărcată.
            // Sarcinile sunt afirmate pentru a reuși.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Comoditate proxy pentru a utiliza încuietorile de curățare pentru a face referire la funcțiile dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inițializați tot suportul necesar pentru a accesa funcțiile API `dbghelp` din acest crate.
///
///
/// Rețineți că această funcție este **sigură**, intern are propria sincronizare.
/// De asemenea, rețineți că este sigur să apelați această funcție de mai multe ori recursiv.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Primul lucru pe care trebuie să-l facem este să sincronizăm această funcție.Acest lucru poate fi apelat concomitent din alte fire sau recursiv într-un fir.
        // Rețineți că este mai complicat decât asta, deoarece ceea ce folosim aici, `dbghelp`,*de asemenea,* trebuie sincronizat cu toți ceilalți apelanți la `dbghelp` în acest proces.
        //
        // De obicei, nu există prea multe apeluri către `dbghelp` în cadrul aceluiași proces și probabil putem presupune în siguranță că suntem singurii care îl accesează.
        // Cu toate acestea, există un alt utilizator principal pe care trebuie să ne îngrijorăm, care este în mod ironic noi înșine, dar în biblioteca standard.
        // Biblioteca standard Rust depinde de acest crate pentru suport pentru backtrace, iar acest crate există și pe crates.io.
        // Acest lucru înseamnă că, dacă biblioteca standard tipărește un backtrace panic, acesta se poate concura cu acest crate provenind de la crates.io, provocând defecte.
        //
        // Pentru a ajuta la rezolvarea acestei probleme de sincronizare, folosim aici un truc specific Windows (este, la urma urmei, o restricție specifică Windows despre sincronizare).
        // Creăm un *session-local* numit mutex pentru a proteja acest apel.
        // Aici intenția este că biblioteca standard și acest crate nu trebuie să partajeze API-uri de nivel Rust pentru a se sincroniza aici, ci pot lucra în spatele scenei pentru a vă asigura că se sincronizează între ele.
        //
        // În acest fel, când această funcție este apelată prin biblioteca standard sau prin crates.io, putem fi siguri că același mutex este achiziționat.
        //
        // Deci, toate acestea sunt de a spune că primul lucru pe care îl facem aici este să creăm atomic un `HANDLE` care este un mutex numit pe Windows.
        // Sincronizăm un pic cu alte fire care împart în mod specific această funcție și ne asigurăm că este creat un singur handle pentru fiecare instanță a acestei funcții.
        // Rețineți că mânerul nu este niciodată închis odată ce este stocat în global.
        //
        // După ce am intrat de fapt încuietoarea, o achiziționăm pur și simplu, iar mânerul nostru `Init` pe care îl înmânăm va fi responsabil pentru căderea acestuia în cele din urmă.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Acum, că suntem sincronizați cu toții, să începem de fapt să procesăm totul.
        // În primul rând, trebuie să ne asigurăm că `dbghelp.dll` este de fapt încărcat în acest proces.
        // Facem acest lucru dinamic pentru a evita o dependență statică.
        // Acest lucru s-a făcut în mod istoric pentru a rezolva problemele ciudate de legătură și este destinat să facă binarele puțin mai portabile, deoarece acesta este în mare parte doar un utilitar de depanare.
        //
        //
        // Odată ce am deschis `dbghelp.dll`, trebuie să apelăm câteva funcții de inițializare în acesta, iar acest lucru este detaliat mai jos.
        // Totuși, facem acest lucru o singură dată, deci avem un boolean global care indică dacă am terminat sau nu.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Asigurați-vă că semnalizatorul `SYMOPT_DEFERRED_LOADS` este setat, deoarece conform propriilor documente MSVC despre acest lucru: "This is the fastest, most efficient way to use the symbol handler.", deci să facem asta!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // De fapt, inițializați simbolurile cu MSVC.Rețineți că acest lucru poate eșua, dar îl ignorăm.
        // Nu există o grămadă de tehnică anterioară pentru aceasta în sine, dar LLVM intern pare să ignore valoarea returnată aici și una dintre bibliotecile de dezinfectant din LLVM tipărește un avertisment înfricoșător dacă acest lucru eșuează, dar practic îl ignoră pe termen lung.
        //
        //
        // Un caz care apare foarte mult pentru Rust este că biblioteca standard și acest crate de pe crates.io doresc să concureze pentru `SymInitializeW`.
        // Biblioteca standard a vrut să inițializeze apoi curățarea de cele mai multe ori, dar acum că folosește acest crate înseamnă că cineva va ajunge mai întâi la inițializare, iar celălalt va prelua acea inițializare.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}