# backtrace-rs

[Documentation](https://docs.rs/backtrace)

O bibliotecă pentru achiziționarea de backtraces în timp de execuție pentru Rust.
Această bibliotecă își propune să îmbunătățească suportul bibliotecii standard, oferind o interfață programatică cu care să lucreze, dar acceptă, de asemenea, imprimarea cu ușurință a backtrace-ului curent, precum panics a libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Pentru a captura pur și simplu un backtrace și a amâna tratarea acestuia până mai târziu, puteți utiliza tipul `Backtrace` de nivel superior.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Cu toate acestea, dacă doriți un acces mai brut la funcționalitatea de urmărire reală, puteți utiliza direct funcțiile `trace` și `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Rezolvați acest indicator al instrucțiunii la un nume de simbol
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // continuați la următorul cadru
    });
}
```

# License

Acest proiect este licențiat sub oricare dintre

 * Licență Apache, versiunea 2.0, ([LICENSE-APACHE](LICENSE-APACHE) sau http://www.apache.org/licenses/LICENSE-2.0)
 * Licență MIT ([LICENSE-MIT](LICENSE-MIT) sau http://opensource.org/licenses/MIT)

la alegerea ta.

### Contribution

Cu excepția cazului în care declarați în mod explicit altfel, orice contribuție trimisă în mod intenționat pentru includerea în backtrace-rs de către dvs., așa cum este definit în licența Apache-2.0, va fi licențiată dublu ca mai sus, fără termeni sau condiții suplimentare.







