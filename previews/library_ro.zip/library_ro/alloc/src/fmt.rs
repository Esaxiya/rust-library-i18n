//! Utilitare pentru formatare și tipărire `String`s.
//!
//! Acest modul conține suportul de execuție pentru extensia de sintaxă [`format!`].
//! Această macrocomandă este implementată în compilator pentru a emite apeluri către acest modul pentru a forma argumente în timpul rulării în șiruri.
//!
//! # Usage
//!
//! Macro-ul [`format!`] este destinat să fie familiar celor care provin din funcțiile C's `printf`/`fprintf` sau funcția `str.format` a lui Python.
//!
//! Câteva exemple de extensie [`format!`] sunt:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" cu zerouri de frunte
//! ```
//!
//! Din acestea, puteți vedea că primul argument este un șir de format.De către compilator este necesar ca acesta să fie un șir literal;nu poate fi o variabilă transmisă (pentru a efectua verificarea validității).
//! Compilatorul va analiza apoi șirul de format și va determina dacă lista argumentelor furnizate este potrivită pentru a trece la acest șir de format.
//!
//! Pentru a converti o singură valoare într-un șir, utilizați metoda [`to_string`].Aceasta va utiliza formatarea [`Display`] trait.
//!
//! ## Parametrii poziționali
//!
//! Fiecare argument de formatare este permis să specifice care este argumentul de valoare la care face referință și, dacă este omis, se presupune că este "the next argument".
//! De exemplu, șirul de format `{} {} {}` ar lua trei parametri și ar fi formatate în aceeași ordine în care sunt date.
//! Cu toate acestea, șirul de format `{2} {1} {0}` ar format formatele în ordine inversă.
//!
//! Lucrurile pot deveni puțin dificile odată ce începeți să amestecați cele două tipuri de specificatori de poziție.Specificatorul "next argument" poate fi considerat un iterator asupra argumentului.
//! De fiecare dată când este văzut un specificator "next argument", iteratorul avansează.Acest lucru duce la un comportament ca acesta:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iteratorul intern asupra argumentului nu a fost avansat până când este văzut primul `{}`, deci imprimă primul argument.Apoi, la atingerea celui de-al doilea `{}`, iteratorul a avansat la al doilea argument.
//! În esență, parametrii care își denumesc în mod explicit argumentul nu afectează parametrii care nu denumesc un argument în termeni de specificatori de poziție.
//!
//! Un șir de format este necesar pentru a utiliza toate argumentele sale, altfel este o eroare în timpul compilării.Puteți face referire la același argument de mai multe ori în șirul de format.
//!
//! ## Parametrii denumiți
//!
//! Rust în sine nu are un echivalent asemănător cu Python al parametrilor numiți la o funcție, dar macrocomanda [`format!`] este o extensie de sintaxă care îi permite să valorifice parametrii numiți.
//! Parametrii numiți sunt enumerați la sfârșitul listei de argumente și au sintaxa:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! De exemplu, următoarele expresii [`format!`] folosesc toate argumentul denumit:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nu este valid să puneți parametri de poziție (cei fără nume) după argumente care au nume.Ca și în cazul parametrilor de poziție, nu este valid să furnizați parametri numiți care nu sunt utilizați de șirul de format.
//!
//! # Parametrii de formatare
//!
//! Fiecare argument formatat poate fi transformat printr-un număr de parametri de formatare (corespunzător lui `format_spec` în [the syntax](#syntax)). Acești parametri afectează reprezentarea șirului a ceea ce este formatat.
//!
//! ## Width
//!
//! ```
//! // Toate acestea imprimă "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Acesta este un parametru pentru "minimum width" pe care ar trebui să îl ia formatul.
//! Dacă șirul valorii nu umple atât de multe caractere, atunci umplutura specificată de fill/alignment va fi utilizată pentru a ocupa spațiul necesar (vezi mai jos).
//!
//! Valoarea lățimii poate fi furnizată și ca [`usize`] în lista de parametri prin adăugarea unui postfix `$`, indicând faptul că al doilea argument este un [`usize`] care specifică lățimea.
//!
//! Referirea la un argument cu sintaxa dolarului nu afectează contorul "next argument", deci este de obicei o idee bună să te referi la argumente după poziție sau să folosești argumente numite.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Caracterul de umplere și alinierea opționale sunt furnizate în mod normal împreună cu parametrul [`width`](#width).Trebuie definit înainte de `width`, imediat după `:`.
//! Acest lucru indică faptul că, dacă valoarea formatată este mai mică decât `width`, vor fi imprimate câteva caractere suplimentare în jurul acesteia.
//! Umplerea vine în următoarele variante pentru diferite alinieri:
//!
//! * `[fill]<` - argumentul este aliniat la stânga în coloanele `width`
//! * `[fill]^` - argumentul este aliniat în centru în coloane `width`
//! * `[fill]>` - argumentul este aliniat la dreapta în coloanele `width`
//!
//! [fill/alignment](#fillalignment) implicit pentru non-numerice este un spațiu și aliniat la stânga.Implicit pentru formatatorii numerici este, de asemenea, un caracter spațial, dar cu alinierea la dreapta.
//! Dacă semnalizatorul `0` (vezi mai jos) este specificat pentru numerică, atunci caracterul de umplere implicit este `0`.
//!
//! Rețineți că alinierea nu poate fi implementată de unele tipuri.În special, nu este în general implementat pentru `Debug` trait.
//! O modalitate bună de a vă asigura că se aplică umplutura este să vă formatați intrarea, apoi să blocați acest șir rezultat pentru a obține rezultatul:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Bună ziua Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Acestea sunt toate steaguri care modifică comportamentul formatatorului.
//!
//! * `+` - Acesta este destinat tipurilor numerice și indică faptul că semnul trebuie întotdeauna tipărit.Semnele pozitive nu sunt niciodată tipărite în mod implicit, iar semnul negativ este tipărit numai în mod implicit pentru `Signed` trait.
//! Acest indicator indică faptul că semnul corect (`+` sau `-`) ar trebui să fie întotdeauna tipărit.
//! * `-` - În prezent nu este utilizat
//! * `#` - Acest semnalizator indică faptul că trebuie utilizată forma de imprimare "alternate".Formele alternative sunt:
//!     * `#?` - imprimați destul formatarea [`Debug`]
//!     * `#x` - precedă argumentul cu un `0x`
//!     * `#X` - precedă argumentul cu un `0x`
//!     * `#b` - precedă argumentul cu un `0b`
//!     * `#o` - precedă argumentul cu un `0o`
//! * `0` - Aceasta este utilizată pentru a indica pentru formatele întregi că umplerea la `width` ar trebui să se facă atât cu un caracter `0`, cât și să fie conștientă de semn.
//! Un format ca `{:08}` ar produce `00000001` pentru întregul `1`, în timp ce același format ar produce `-0000001` pentru întregul `-1`.
//! Observați că versiunea negativă are cu zero mai puțin decât versiunea pozitivă.
//!         Rețineți că zerourile de umplere sunt întotdeauna plasate după semn (dacă există) și înainte de cifre.Atunci când este utilizat împreună cu steagul `#`, se aplică o regulă similară: zerourile de umplere sunt inserate după prefix, dar înainte de cifre.
//!         Prefixul este inclus în lățimea totală.
//!
//! ## Precision
//!
//! Pentru tipurile nenumerice, acesta poate fi considerat un "maximum width".
//! Dacă șirul rezultat este mai lung decât această lățime, atunci este trunchiat până la atâtea caractere și acea valoare trunchiată este emisă cu `fill`, `alignment` și `width` corespunzătoare dacă acești parametri sunt setați.
//!
//! Pentru tipurile integrale, acest lucru este ignorat.
//!
//! Pentru tipurile cu virgulă mobilă, aceasta indică câte cifre după virgulă trebuie imprimate.
//!
//! Există trei modalități posibile de a specifica `precision` dorit:
//!
//! 1. Un număr întreg `.N`:
//!
//!    întregul `N` în sine este precizia.
//!
//! 2. Un număr întreg sau un nume urmat de semnul dolar `.N$`:
//!
//!    folosiți formatul *argument*`N` (care trebuie să fie un `usize`) ca precizie.
//!
//! 3. Un asterisc `.*`:
//!
//!    `.*` înseamnă că acest `{...}` este asociat cu intrări de format *două* mai degrabă decât cu una: prima intrare deține precizia `usize`, iar a doua deține valoarea de imprimat.
//!    Rețineți că, în acest caz, dacă se folosește șirul de format `{<arg>:<spec>.*}`, partea `<arg>` se referă la valoarea* de imprimat, iar `precision` trebuie să intre în intrarea precedentă `<arg>`.
//!
//! De exemplu, următoarele apeluri imprimă același lucru `Hello x is 0.01000`:
//!
//! ```
//! // Bună ziua {arg 0 ("x")} este {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Bună ziua {arg 1 ("x")} este {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Bună ziua {arg 0 ("x")} este {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Bună ziua {next arg ("x")} este {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Bună ziua {next arg ("x")} este {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Bună ziua {next arg ("x")} este {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! În timp ce acestea:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! tipăriți trei lucruri semnificativ diferite:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! În unele limbaje de programare, comportamentul funcțiilor de formatare a șirurilor depinde de setările locale ale sistemului de operare.
//! Funcțiile de format furnizate de biblioteca standard a Rust nu au niciun concept de localizare și vor produce aceleași rezultate pe toate sistemele, indiferent de configurația utilizatorului.
//!
//! De exemplu, următorul cod va imprima întotdeauna `1.5` chiar dacă localizarea sistemului folosește un separator zecimal, altul decât un punct.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Caracterele literal `{` și `}` pot fi incluse într-un șir precedându-le cu același caracter.De exemplu, caracterul `{` este scăpat cu `{{` și caracterul `}` este scăpat cu `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Pentru a rezuma, aici puteți găsi gramatica completă a șirurilor de format.
//! Sintaxa pentru limba de formatare utilizată este extrasă din alte limbi, deci nu ar trebui să fie prea străină.Argumentele sunt formatate cu sintaxa de tip Python, ceea ce înseamnă că argumentele sunt înconjurate de `{}` în loc de `%` de tip C.
//! Gramatica reală pentru sintaxa de formatare este:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! În gramatica de mai sus, `text` nu poate conține caractere `'{'` sau `'}'`.
//!
//! # Formatarea traits
//!
//! Când solicitați ca un argument să fie formatat cu un anumit tip, solicitați de fapt ca un argument să fie atribuit unui anumit trait.
//! Acest lucru permite formatarea mai multor tipuri reale prin `{:x}` (cum ar fi [`i8`], precum și [`isize`]).Cartarea curentă a tipurilor la traits este:
//!
//! * *nimic* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] cu numere întregi hexazecimale minuscule
//! * `X?` ⇒ [`Debug`] cu numere întregi majuscule hexazecimale
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ceea ce înseamnă acest lucru este că orice tip de argument care implementează [`fmt::Binary`][`Binary`] trait poate fi apoi formatat cu `{:b}`.Implementările sunt furnizate pentru aceste traits pentru un număr de tipuri primitive și de biblioteca standard.
//!
//! Dacă nu este specificat niciun format (ca în `{}` sau `{:6}`), atunci formatul trait utilizat este [`Display`] trait.
//!
//! Când implementați un format trait pentru propriul tip, va trebui să implementați o metodă de semnătură:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // tipul nostru personalizat
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Tipul dvs. va fi transmis ca referință secundară `self`, iar apoi funcția ar trebui să emită ieșire în fluxul `f.buf`.Depinde de fiecare implementare a formatului trait să adere corect la parametrii de formatare solicitați.
//! Valorile acestor parametri vor fi listate în câmpurile structurii [`Formatter`].Pentru a ajuta la acest lucru, struct [`Formatter`] oferă, de asemenea, câteva metode de ajutor.
//!
//! În plus, valoarea returnată a acestei funcții este [`fmt::Result`], care este un alias de tip [[Rezultat]] `<(),` [`std: : fmt::Error`]`>`.
//! Implementările de formatare ar trebui să se asigure că propagă erorile de pe [`Formatter`] (de exemplu, atunci când se apelează [`write!`]).
//! Cu toate acestea, nu ar trebui să returneze niciodată erorile în mod eronat.
//! Adică, o implementare de formatare trebuie și poate returna o eroare numai dacă [`Formatter`]-ul transmis returnează o eroare.
//! Acest lucru se datorează faptului că, spre deosebire de ceea ce ar putea sugera semnătura funcției, formatarea șirurilor este o operație infailibilă.
//! Această funcție returnează doar un rezultat, deoarece scrierea în fluxul de bază ar putea eșua și trebuie să ofere o modalitate de propagare a faptului că a apărut o eroare înapoi în stiva.
//!
//! Un exemplu de implementare a formatării traits ar arăta ca:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Valoarea `f` implementează `Write` trait, ceea ce scrie!macro se așteaptă.
//!         // Rețineți că această formatare ignoră diferitele semnalizări furnizate pentru formatarea șirurilor.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits diferite permit diferite forme de ieșire de un tip.
//! // Semnificația acestui format este de a imprima magnitudinea unui vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respectați semnalizatoarele de formatare utilizând metoda de ajutor `pad_integral` pe obiectul Formatter.
//!         // Consultați documentația metodei pentru detalii, iar funcția `pad` poate fi utilizată pentru tamponarea șirurilor.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Aceste două formatări traits au scopuri distincte:
//!
//! - [`fmt::Display`][`Display`] implementările afirmă că tipul poate fi reprezentat fidel ca un șir UTF-8 în orice moment.**Nu este** de așteptat ca toate tipurile să implementeze [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementările ar trebui implementate pentru **toate** tipurile publice.
//!   Rezultatul va reprezenta de obicei starea internă cât mai fidel posibil.
//!   Scopul [`Debug`] trait este de a facilita depanarea codului Rust.În majoritatea cazurilor, utilizarea `#[derive(Debug)]` este suficientă și recomandată.
//!
//! Câteva exemple de ieșire din ambele traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macrocomenzi conexe
//!
//! Există o serie de macro-uri conexe din familia [`format!`].Cele care sunt implementate în prezent sunt:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Aceasta și [`writeln!`] sunt două macrocomenzi care sunt utilizate pentru a emite șirul de format către un flux specificat.Aceasta este utilizată pentru a preveni alocările intermediare ale șirurilor de format și, în schimb, pentru a scrie direct ieșirea.
//! Sub capotă, această funcție invocă de fapt funcția [`write_fmt`] definită pe [`std::io::Write`] trait.
//! Exemplul de utilizare este:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Acesta și [`println!`] își emit ieșirea către stdout.În mod similar cu macrocomanda [`write!`], scopul acestor macrocomenzi este de a evita alocările intermediare la imprimarea rezultatelor.Exemplul de utilizare este:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Macro-urile [`eprint!`] și [`eprintln!`] sunt identice cu [`print!`] și, respectiv, [`println!`], cu excepția faptului că își emit ieșirea către stderr.
//!
//! ### `format_args!`
//!
//! Aceasta este o macro curioasă utilizată pentru a trece în siguranță în jurul unui obiect opac care descrie șirul de format.Acest obiect nu necesită nicio alocare de heap pentru a crea și face referire doar la informații din stivă.
//! Sub capotă, toate macrocomenzile aferente sunt implementate în acest sens.
//! În primul rând, un exemplu de utilizare este:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Rezultatul macro-ului [`format_args!`] este o valoare de tip [`fmt::Arguments`].
//! Această structură poate fi apoi transmisă funcțiilor [`write`] și [`format`] din acest modul pentru a procesa șirul de format.
//! Scopul acestei macro este de a preveni și mai mult alocările intermediare atunci când se ocupă de formatarea șirurilor.
//!
//! De exemplu, o bibliotecă de jurnalizare ar putea utiliza sintaxa de formatare standard, dar ar trece intern în jurul acestei structuri până când s-a stabilit unde ar trebui să meargă ieșirea.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funcția `format` ia o structură [`Arguments`] și returnează șirul formatat rezultat.
///
///
/// Instanța [`Arguments`] poate fi creată cu macrocomanda [`format_args!`].
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Vă rugăm să rețineți că utilizarea [`format!`] ar putea fi preferabilă.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}