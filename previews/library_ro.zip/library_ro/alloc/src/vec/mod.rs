//! Un tip de matrice cultivabil contigu cu conținut alocat heap, scris `Vec<T>`.
//!
//! Vectors are indexare `O(1)`, amortizare `O(1)` push (până la capăt) și `O(1)` pop (de la final).
//!
//!
//! Vectors se asigură că nu alocă niciodată mai mult de `isize::MAX` octeți.
//!
//! # Examples
//!
//! Puteți crea în mod explicit un [`Vec`] cu [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... sau folosind macrocomanda [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // zece zerouri
//! ```
//!
//! Puteți [`push`] valori la sfârșitul unui vector (care va crește vector după cum este necesar):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping valori funcționează în același mod:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors acceptă, de asemenea, indexarea (prin [`Index`] și [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Un tip de matrice cultivabilă contiguu, scris ca `Vec<T>` și pronunțat 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Macro-ul [`vec!`] este furnizat pentru a facilita inițializarea:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// De asemenea, poate inițializa fiecare element al unui `Vec<T>` cu o valoare dată.
/// Acest lucru poate fi mai eficient decât efectuarea alocării și inițializării în pași separați, mai ales atunci când inițializați un vector de zerouri:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Următorul este echivalent, dar potențial mai lent:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Pentru mai multe informații, consultați [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Utilizați un `Vec<T>` ca un teanc eficient:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Tipăriri 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Tipul `Vec` permite accesarea valorilor după index, deoarece implementează [`Index`] trait.Un exemplu va fi mai explicit:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // va afișa '2'
/// ```
///
/// Cu toate acestea, aveți grijă: dacă încercați să accesați un index care nu se află în `Vec`, software-ul dvs. va panic!Nu poți face asta:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Utilizați [`get`] și [`get_mut`] dacă doriți să verificați dacă indexul este în `Vec`.
///
/// # Slicing
///
/// Un `Vec` poate fi modificat.Pe de altă parte, feliile sunt obiecte numai în citire.
/// Pentru a obține un [slice][prim@slice], utilizați [`&`].Exemplu:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... Și asta e tot!
/// // o poți face și așa:
/// let u: &[usize] = &v;
/// // sau așa:
/// let u: &[_] = &v;
/// ```
///
/// În Rust, este mai frecvent să treceți felii ca argumente mai degrabă decât vectors atunci când doriți doar să oferiți acces la citire.Același lucru este valabil și pentru [`String`] și [`&str`].
///
/// # Capacitate și realocare
///
/// Capacitatea unui vector este cantitatea de spațiu alocat pentru orice element future care va fi adăugat pe vector.Acest lucru nu trebuie confundat cu *lungimea* unui vector, care specifică numărul de elemente reale din vector.
/// Dacă lungimea unui vector își depășește capacitatea, capacitatea sa va fi crescută automat, dar elementele sale vor trebui realocate.
///
/// De exemplu, un vector cu capacitatea 10 și lungimea 0 ar fi un vector gol cu spațiu pentru încă 10 elemente.Împingerea a 10 sau mai puține elemente pe vector nu îi va schimba capacitatea sau va provoca realocarea.
/// Cu toate acestea, dacă lungimea vector este mărită la 11, va trebui să se realoce, ceea ce poate fi lent.Din acest motiv, se recomandă utilizarea [`Vec::with_capacity`] ori de câte ori este posibil pentru a specifica cât de mare este de așteptat vector.
///
/// # Guarantees
///
/// Datorită naturii sale incredibil de fundamentale, `Vec` oferă multe garanții cu privire la designul său.Acest lucru asigură că este cât se poate de redus în general, și poate fi manipulat corect în moduri primitive prin cod nesigur.Rețineți că aceste garanții se referă la un `Vec<T>` necalificat.
/// Dacă se adaugă parametri de tip suplimentari (de exemplu, pentru a accepta alocatori personalizați), suprascrierea valorilor implicite poate schimba comportamentul.
///
/// Cel mai fundamental, `Vec` este și va fi întotdeauna un triplet (pointer, capacitate, lungime).Nici mai mult nici mai puțin.Ordinea acestor câmpuri este complet nespecificată și ar trebui să utilizați metodele adecvate pentru a le modifica.
/// Pointerul nu va fi niciodată nul, deci acest tip este optimizat cu pointerul nul.
///
/// Cu toate acestea, este posibil ca indicatorul să nu indice de fapt memoria alocată.
/// În special, dacă construiți un `Vec` cu capacitatea 0 prin [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] sau apelând [`shrink_to_fit`] pe un Vec gol, acesta nu va aloca memorie.În mod similar, dacă stocați tipuri de dimensiuni zero într-un `Vec`, acesta nu va aloca spațiu pentru acestea.
/// *Rețineți că în acest caz este posibil ca `Vec` să nu raporteze un [`capacity`] de 0*.
/// `Vec` va aloca dacă și numai dacă [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// În general, detaliile de alocare ale " Vec` sunt foarte subtile-dacă intenționați să alocați memorie utilizând un `Vec` și să o utilizați pentru altceva (fie pentru a trece la cod nesigur, fie pentru a vă crea propria colecție susținută de memorie), asigurați-vă pentru a repartiza această memorie folosind `from_raw_parts` pentru a recupera `Vec` și apoi pentru a o lăsa.
///
/// Dacă un `Vec`*are* alocată memorie, atunci memoria către care se referă este pe heap (așa cum este definită de alocatorul Rust este configurată pentru a fi utilizată în mod implicit), iar indicatorul său indică [`len`] inițializat, elemente contigue în ordine (ceea ce ați dori vezi dacă l-ai constrâns la o felie), urmat de [`capacitate`]`,`[`len`] elemente logice neinitializate, adiacente.
///
///
/// Un vector care conține elementele `'a'` și `'b'` cu capacitatea 4 poate fi vizualizat după cum urmează.Partea de sus este structura `Vec`, conține un pointer către capul alocării în heap, lungime și capacitate.
/// Partea de jos este alocarea pe heap, un bloc de memorie contigu.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** reprezintă memoria care nu este inițializată, vezi [`MaybeUninit`].
/// - Note: ABI nu este stabil și `Vec` nu oferă garanții cu privire la aspectul memoriei sale (inclusiv ordinea câmpurilor).
///
/// `Vec` nu va efectua niciodată un "small optimization" în care elementele sunt stocate efectiv în stivă din două motive:
///
/// * Ar face mai dificilă manipularea corectă a unui `Vec` pentru codul nesigur.Conținutul unui `Vec` nu ar avea o adresă stabilă dacă ar fi mutat doar și ar fi mai dificil să se determine dacă un `Vec` a alocat de fapt memorie.
///
/// * Ar penaliza cazul general, provocând un branch suplimentar la fiecare acces.
///
/// `Vec` nu se va micșora niciodată automat, chiar dacă este complet gol.Acest lucru asigură că nu au loc alocări sau dealocări inutile.Golirea unui `Vec` și apoi completarea acestuia înapoi la același [`len`] nu ar trebui să antreneze apeluri către alocator.Dacă doriți să eliberați memoria neutilizată, utilizați [`shrink_to_fit`] sau [`shrink_to`].
///
/// [`push`] iar [`insert`] nu va (re) aloca niciodată dacă capacitatea raportată este suficientă.[`push`] și [`insert`]*vor*(re) aloca dacă [`len`]`==`[`capacity`].Adică, capacitatea raportată este complet precisă și se poate baza pe ea.Poate fi folosit chiar și pentru a elibera manual memoria alocată de un `Vec`, dacă se dorește.
/// Metodele de inserare în bloc *pot* realoca, chiar și atunci când nu este necesar.
///
/// `Vec` nu garantează nicio strategie specială de creștere atunci când realocarea este completă și nici când este apelat [`reserve`].Strategia actuală este de bază și se poate dovedi de dorit să se utilizeze un factor de creștere neconstant.Orice strategie utilizată va garanta, desigur,*O*(1) [`push`] amortizat.
///
/// `vec![x; n]`, `vec![a, b, c, d]` și [`Vec::with_capacity(n)`][`Vec::with_capacity`] vor produce toate un `Vec` cu exact capacitatea solicitată.
/// Dacă [`len`]`==`[`capacity`], (așa cum este cazul macro-ului [`vec!`]), atunci un `Vec<T>` poate fi convertit la și de la un [`Box<[T]>`][owned slice] fără realocarea sau mutarea elementelor.
///
/// `Vec` nu va suprascrie în mod specific niciun fel de date care sunt eliminate, dar nu le va păstra în mod specific.Memoria sa neinițializată este spațiu de zgârieturi pe care îl poate folosi oricum dorește.În general, va face tot ce este mai eficient sau altfel ușor de implementat.Nu vă bazați pe datele eliminate pentru a fi șterse din motive de securitate.
/// Chiar dacă renunțați la un `Vec`, tamponul său poate fi pur și simplu reutilizat de un alt `Vec`.
/// Chiar dacă zeroți mai întâi memoria unui " Vec`, este posibil să nu se întâmple de fapt, deoarece optimizatorul nu consideră acest lucru un efect secundar care trebuie păstrat.
/// Există totuși un caz pe care nu îl vom sparge: utilizarea codului `unsafe` pentru a scrie la capacitatea în exces și apoi creșterea lungimii pentru a se potrivi, este întotdeauna valabilă.
///
/// În prezent, `Vec` nu garantează ordinea în care sunt abandonate elementele.
/// Comanda s-a schimbat în trecut și s-ar putea schimba din nou.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metode inerente
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Construiește un `Vec<T>` nou, gol.
    ///
    /// vector nu se va aloca până când elementele nu sunt împinse pe el.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Construiește un `Vec<T>` nou, gol, cu capacitatea specificată.
    ///
    /// vector va putea să păstreze exact elemente `capacity` fără realocare.
    /// Dacă `capacity` este 0, vector nu va aloca.
    ///
    /// Este important de reținut că, deși vector returnat are *capacitatea* specificată, vector va avea o lungime zero *.
    ///
    /// Pentru o explicație a diferenței dintre lungime și capacitate, consultați *[Capacitate și realocare]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector nu conține articole, chiar dacă are capacitate pentru mai multe
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Toate acestea se fac fără realocare ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... dar acest lucru poate face ca vector să fie realocat
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Creează un `Vec<T>` direct din componentele brute ale altui vector.
    ///
    /// # Safety
    ///
    /// Acest lucru este extrem de nesigur, datorită numărului de invarianți care nu sunt verificați:
    ///
    /// * `ptr` trebuie să fi fost alocate anterior prin [`String`]/` Vec<T>" (cel puțin, este foarte probabil să fie incorect dacă nu ar fi fost).
    /// * `T` trebuie să aibă aceeași dimensiune și aliniament cu ce a fost alocat `ptr`.
    ///   (`T` având o aliniere mai puțin strictă nu este suficient, alinierea trebuie să fie cu adevărat egală pentru a satisface cerința [`dealloc`] conform căreia memoria trebuie alocată și alocată cu același aspect.)
    ///
    /// * `length` trebuie să fie mai mic sau egal cu `capacity`.
    /// * `capacity` trebuie să fie capacitatea cu care a fost alocat indicatorul.
    ///
    /// Încălcarea acestora poate cauza probleme cum ar fi coruperea structurilor de date interne ale alocatorului.De exemplu, nu este **sigur** să construiți un `Vec<u8>` de la un pointer la un tablou C `char` cu lungimea `size_t`.
    /// De asemenea, nu este sigur să construiți unul dintr-un `Vec<u16>` și lungimea acestuia, deoarece alocatorului îi pasă de aliniere, iar aceste două tipuri au alinieri diferite.
    /// Tamponul a fost alocat cu aliniamentul 2 (pentru `u16`), dar după ce l-ați transformat într-un `Vec<u8>` va fi repartizat cu alinierea 1.
    ///
    /// Proprietatea asupra `ptr` este transferată efectiv către `Vec<T>`, care poate apoi să aloce, să realoce sau să schimbe conținutul memoriei indicat de pointer după bunul plac.
    /// Asigurați-vă că nimic altceva nu folosește indicatorul după ce ați apelat această funcție.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Actualizați acest lucru când vec_into_raw_parts este stabilizat.
    ///     // Împiedicați rularea distructorului " v`, astfel încât să avem controlul complet asupra alocării.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Scoateți diversele informații importante despre `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Suprascrieți memoria cu 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Puneți totul la loc într-un Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Construiește un `Vec<T, A>` nou, gol.
    ///
    /// vector nu se va aloca până când elementele nu sunt împinse pe el.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Construiește un `Vec<T, A>` nou, gol, cu capacitatea specificată cu alocatorul furnizat.
    ///
    /// vector va putea să păstreze exact elemente `capacity` fără realocare.
    /// Dacă `capacity` este 0, vector nu va aloca.
    ///
    /// Este important de reținut că, deși vector returnat are *capacitatea* specificată, vector va avea o lungime zero *.
    ///
    /// Pentru o explicație a diferenței dintre lungime și capacitate, consultați *[Capacitate și realocare]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector nu conține articole, chiar dacă are capacitate pentru mai multe
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Toate acestea se fac fără realocare ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... dar acest lucru poate face ca vector să fie realocat
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Creează un `Vec<T, A>` direct din componentele brute ale altui vector.
    ///
    /// # Safety
    ///
    /// Acest lucru este extrem de nesigur, datorită numărului de invarianți care nu sunt verificați:
    ///
    /// * `ptr` trebuie să fi fost alocate anterior prin [`String`]/` Vec<T>" (cel puțin, este foarte probabil să fie incorect dacă nu ar fi fost).
    /// * `T` trebuie să aibă aceeași dimensiune și aliniament cu ce a fost alocat `ptr`.
    ///   (`T` având o aliniere mai puțin strictă nu este suficient, alinierea trebuie să fie cu adevărat egală pentru a satisface cerința [`dealloc`] conform căreia memoria trebuie alocată și alocată cu același aspect.)
    ///
    /// * `length` trebuie să fie mai mic sau egal cu `capacity`.
    /// * `capacity` trebuie să fie capacitatea cu care a fost alocat indicatorul.
    ///
    /// Încălcarea acestora poate cauza probleme cum ar fi coruperea structurilor de date interne ale alocatorului.De exemplu, nu este **sigur** să construiți un `Vec<u8>` de la un pointer la un tablou C `char` cu lungimea `size_t`.
    /// De asemenea, nu este sigur să construiți unul dintr-un `Vec<u16>` și lungimea acestuia, deoarece alocatorului îi pasă de aliniere, iar aceste două tipuri au alinieri diferite.
    /// Tamponul a fost alocat cu aliniamentul 2 (pentru `u16`), dar după ce l-ați transformat într-un `Vec<u8>` va fi repartizat cu alinierea 1.
    ///
    /// Proprietatea asupra `ptr` este transferată efectiv către `Vec<T>`, care poate apoi să aloce, să realoce sau să schimbe conținutul memoriei indicat de pointer după bunul plac.
    /// Asigurați-vă că nimic altceva nu folosește indicatorul după ce ați apelat această funcție.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Actualizați acest lucru când vec_into_raw_parts este stabilizat.
    ///     // Împiedicați rularea distructorului " v`, astfel încât să avem controlul complet asupra alocării.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Scoateți diversele informații importante despre `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Suprascrieți memoria cu 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Puneți totul la loc într-un Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Descompune un `Vec<T>` în componentele sale brute.
    ///
    /// Returnează indicatorul brut la datele de bază, lungimea vector (în elemente) și capacitatea alocată a datelor (în elemente).
    /// Acestea sunt aceleași argumente în aceeași ordine ca argumentele pentru [`from_raw_parts`].
    ///
    /// După apelarea acestei funcții, apelantul este responsabil pentru memoria gestionată anterior de `Vec`.
    /// Singura modalitate de a face acest lucru este de a converti înapoi indicatorul brut, lungimea și capacitatea într-un `Vec` cu funcția [`from_raw_parts`], permițând distructorului să efectueze curățarea.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Acum putem aduce modificări componentelor, cum ar fi transmutarea indicatorului brut la un tip compatibil.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Descompune un `Vec<T>` în componentele sale brute.
    ///
    /// Returnează indicatorul brut la datele subiacente, lungimea vector (în elemente), capacitatea alocată a datelor (în elemente) și alocatorul.
    /// Acestea sunt aceleași argumente în aceeași ordine ca argumentele pentru [`from_raw_parts_in`].
    ///
    /// După apelarea acestei funcții, apelantul este responsabil pentru memoria gestionată anterior de `Vec`.
    /// Singura modalitate de a face acest lucru este de a converti înapoi indicatorul brut, lungimea și capacitatea într-un `Vec` cu funcția [`from_raw_parts_in`], permițând distructorului să efectueze curățarea.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Acum putem aduce modificări componentelor, cum ar fi transmutarea indicatorului brut la un tip compatibil.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Returnează numărul de elemente pe care vector le poate deține fără realocare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezervă capacitatea pentru cel puțin `additional` mai multe elemente care urmează să fie inserate în `Vec<T>` dat.
    /// Colecția poate rezerva mai mult spațiu pentru a evita realocările frecvente.
    /// După apelarea `reserve`, capacitatea va fi mai mare sau egală cu `self.len() + additional`.
    /// Nu face nimic dacă capacitatea este deja suficientă.
    ///
    /// # Panics
    ///
    /// Panics dacă noua capacitate depășește `isize::MAX` octeți.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezervă capacitatea minimă pentru ca `additional` să fie inserate mai multe elemente în `Vec<T>` dat.
    ///
    /// După apelarea `reserve_exact`, capacitatea va fi mai mare sau egală cu `self.len() + additional`.
    /// Nu face nimic dacă capacitatea este deja suficientă.
    ///
    /// Rețineți că distribuitorul poate oferi colecției mai mult spațiu decât solicită.
    /// Prin urmare, capacitatea nu poate fi invocată pentru a fi precis minimă.
    /// Preferă `reserve` dacă se așteaptă inserții future.
    ///
    /// # Panics
    ///
    /// Panics dacă noua capacitate depășește `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Încearcă să rezerve capacitatea pentru cel puțin `additional` mai multe elemente care urmează să fie inserate în `Vec<T>` dat.
    /// Colecția poate rezerva mai mult spațiu pentru a evita realocările frecvente.
    /// După apelarea `try_reserve`, capacitatea va fi mai mare sau egală cu `self.len() + additional`.
    /// Nu face nimic dacă capacitatea este deja suficientă.
    ///
    /// # Errors
    ///
    /// Dacă capacitatea depășește sau alocatorul raportează o eroare, atunci se returnează o eroare.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Rezervați în prealabil memoria, ieșind dacă nu putem
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Acum știm că acest lucru nu poate OOM în mijlocul muncii noastre complexe
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // foarte complicat
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Încearcă să rezerve capacitatea minimă pentru ca elementele `additional` să fie inserate în `Vec<T>` dat.
    /// După apelarea `try_reserve_exact`, capacitatea va fi mai mare sau egală cu `self.len() + additional` dacă returnează `Ok(())`.
    ///
    /// Nu face nimic dacă capacitatea este deja suficientă.
    ///
    /// Rețineți că distribuitorul poate oferi colecției mai mult spațiu decât solicită.
    /// Prin urmare, capacitatea nu poate fi invocată pentru a fi precis minimă.
    /// Preferă `reserve` dacă se așteaptă inserții future.
    ///
    /// # Errors
    ///
    /// Dacă capacitatea depășește sau alocatorul raportează o eroare, atunci se returnează o eroare.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Rezervați în prealabil memoria, ieșind dacă nu putem
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Acum știm că acest lucru nu poate OOM în mijlocul muncii noastre complexe
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // foarte complicat
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Reduce capacitatea vector cât mai mult posibil.
    ///
    /// Acesta va coborî cât mai aproape posibil de lungime, dar alocatorul poate informa în continuare vector că există spațiu pentru alte câteva elemente.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Capacitatea nu este niciodată mai mică decât lungimea și nu este nimic de făcut atunci când sunt egale, astfel încât să putem evita carcasa panic în `RawVec::shrink_to_fit` apelând-o doar cu o capacitate mai mare.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Micșorează capacitatea vector cu o limită inferioară.
    ///
    /// Capacitatea va rămâne cel puțin la fel de mare ca lungimea și valoarea furnizată.
    ///
    ///
    /// Dacă capacitatea curentă este mai mică decât limita inferioară, aceasta este o opțiune fără opțiuni.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Convertește vector în [`Box<[T]>`][owned slice].
    ///
    /// Rețineți că acest lucru va scădea orice capacitate în exces.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Capacitatea în exces este eliminată:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Scurtează vector, păstrând primele elemente `len` și lăsând restul.
    ///
    /// Dacă `len` este mai mare decât lungimea actuală a vector, aceasta nu are efect.
    ///
    /// Metoda [`drain`] poate emula `truncate`, dar face ca elementele în exces să fie returnate în loc să fie abandonate.
    ///
    ///
    /// Rețineți că această metodă nu are niciun efect asupra capacității alocate a vector.
    ///
    /// # Examples
    ///
    /// Trunchierea unui vector cu cinci elemente la două elemente:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Nu se produce trunchierea când `len` este mai mare decât lungimea curentă a vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Trunchierea când `len == 0` este echivalentă cu apelarea metodei [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Acest lucru este sigur deoarece:
        //
        // * felia trecută la `drop_in_place` este validă;carcasa `len > self.len` evită crearea unei felii nevalide și
        // * `len` al vector este micșorat înainte de a apela `drop_in_place`, astfel încât nicio valoare nu va fi scăzută de două ori în cazul în care `drop_in_place` ar fi fost la panic o dată (dacă este panics de două ori, programul se întrerupe).
        //
        //
        //
        unsafe {
            // Note: Este intenționat ca acesta să fie `>` și nu `>=`.
            //       Schimbarea acestuia la `>=` are implicații negative asupra performanței în unele cazuri.
            //       Consultați #78884 pentru mai multe.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extrage o felie care conține întregul vector.
    ///
    /// Echivalent cu `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extrage o felie mutabilă din întregul vector.
    ///
    /// Echivalent cu `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Returnează un pointer brut la buffer-ul vector.
    ///
    /// Apelantul trebuie să se asigure că vector depășește indicatorul pe care îl returnează această funcție, altfel va ajunge să arate gunoiul.
    /// Modificarea vector poate cauza realocarea bufferului său, ceea ce ar face ca orice indicatori să fie nevalizi.
    ///
    /// Apelantul trebuie, de asemenea, să se asigure că memoria către care indică indicatorul (non-transitively) nu este scrisă niciodată (cu excepția unui `UnsafeCell`) folosind acest indicator sau orice alt indicator derivat din acesta.
    /// Dacă trebuie să mutați conținutul feliei, utilizați [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Umbram metoda felie cu același nume pentru a evita trecerea prin `deref`, care creează o referință intermediară.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Returnează un pointer mutabil nesigur în buffer-ul vector.
    ///
    /// Apelantul trebuie să se asigure că vector depășește indicatorul pe care îl returnează această funcție, altfel va ajunge să arate gunoiul.
    ///
    /// Modificarea vector poate cauza realocarea bufferului său, ceea ce ar face ca orice indicatori să fie nevalizi.
    ///
    /// # Examples
    ///
    /// ```
    /// // Alocați vector suficient de mare pentru 4 elemente.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inițializați elementele prin scrierea pointerului brut, apoi setați lungimea.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Umbram metoda felie cu același nume pentru a evita trecerea prin `deref_mut`, care creează o referință intermediară.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Returnează o referință la alocatorul de bază.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Forțează lungimea vector la `new_len`.
    ///
    /// Aceasta este o operație de nivel scăzut care nu menține niciunul dintre invarianții normali de tip.
    /// Modificarea în mod normal a lungimii unui vector se face folosind una dintre operațiunile sigure, cum ar fi [`truncate`], [`resize`], [`extend`] sau [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` trebuie să fie mai mic sau egal cu [`capacity()`].
    /// - Elementele de la `old_len..new_len` trebuie inițializate.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Această metodă poate fi utilă pentru situații în care vector servește ca tampon pentru alt cod, în special pentru FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Acesta este doar un schelet minim pentru exemplul doc;
    /// # // nu folosiți acest lucru ca punct de plecare pentru o bibliotecă reală.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Conform documentelor metodei FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SIGURANȚĂ: Când `deflateGetDictionary` returnează `Z_OK`, se menține că:
    ///     // 1. `dict_length` elemente au fost inițializate.
    ///     // 2.
    ///     // `dict_length` <=capacitatea (32_768) care face `set_len` sigur în apel.
    ///     unsafe {
    ///         // Efectuați apelul FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... și actualizați lungimea la ceea ce a fost inițializat.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// În timp ce următorul exemplu este sunet, există o scurgere de memorie, deoarece vectors interioare nu au fost eliberate înainte de apelul `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` este gol, deci nu trebuie inițializate elemente.
    /// // 2. `0 <= capacity` deține întotdeauna orice este `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// În mod normal, aici, s-ar folosi în schimb [`clear`] pentru a renunța corect la conținut și, astfel, a nu pierde memoria.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Elimină un element din vector și îl returnează.
    ///
    /// Elementul eliminat este înlocuit cu ultimul element al vector.
    ///
    /// Aceasta nu păstrează comanda, dar este O(1).
    ///
    /// # Panics
    ///
    /// Panics dacă `index` este în afara limitelor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Înlocuim self [index] cu ultimul element.
            // Rețineți că, dacă verificarea limitelor de mai sus reușește, trebuie să existe un ultim element (care poate fi el însuși [index]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Inserează un element în poziția `index` din vector, deplasând toate elementele după el spre dreapta.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // spațiu pentru noul element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infailibil Locul pentru a pune noua valoare
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Mutați totul pentru a face spațiu.
                // (Duplicarea elementului `index`th în două locuri consecutive.)
                ptr::copy(p, p.offset(1), len - index);
                // Scrieți-l, suprascriind prima copie a elementului `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Îndepărtează și returnează elementul din poziția `index` din vector, deplasând toate elementele după acesta spre stânga.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `index` este în afara limitelor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // locul din care luăm.
                let ptr = self.as_mut_ptr().add(index);
                // copiați-l, având în siguranță o copie a valorii în stivă și în vector în același timp.
                //
                ret = ptr::read(ptr);

                // Mutați totul în jos pentru a completa acel loc.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Păstrează numai elementele specificate de predicat.
    ///
    /// Cu alte cuvinte, eliminați toate elementele `e` astfel încât `f(&e)` să returneze `false`.
    /// Această metodă funcționează în loc, vizitând fiecare element exact o dată în ordinea inițială și păstrează ordinea elementelor reținute.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Deoarece elementele sunt vizitate exact o dată în ordinea inițială, starea externă poate fi utilizată pentru a decide ce elemente să păstreze.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evitați căderea dublă dacă protecția împotriva căderii nu este executată, deoarece putem face unele găuri în timpul procesului.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len procesat-> |^-lângă verificare
        //                  | <-șters cnt-> |
        //      | <-original_len-> |Păstrat: Elemente care predică se întoarce adevărat.
        //
        // Gaură: slotul elementului mutat sau scăzut.
        // Unchecked: Elemente valide nebifate.
        //
        // Această protecție la cădere va fi invocată atunci când predicat sau `drop` al elementului intră în panică.
        // Mută elementele necontrolate pentru a acoperi găurile și `set_len` la lungimea corectă.
        // În cazurile în care predicatul și `drop` nu intră niciodată în panică, acesta va fi optimizat.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SIGURANȚĂ: Urmărirea articolelor necontrolate trebuie să fie valabilă deoarece nu le atingem niciodată.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SIGURANȚĂ: După umplerea găurilor, toate articolele se află în memoria contiguă.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SIGURANȚĂ: elementul nebifat trebuie să fie valid.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Înaintează devreme pentru a evita căderea dublă dacă `drop_in_place` intră în panică.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SIGURANȚĂ: Nu atingem niciodată acest element din nou după cădere.
                unsafe { ptr::drop_in_place(cur) };
                // Am avansat deja tejgheaua.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SIGURANȚĂ: `deleted_cnt`> 0, deci fanta orificiului nu trebuie să se suprapună cu elementul curent.
                // Folosim copiere pentru mutare și nu mai atingem niciodată acest element.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Toate articolele sunt procesate.Acest lucru poate fi optimizat la `set_len` de către LLVM.
        drop(g);
    }

    /// Elimină toate elementele consecutive, cu excepția primului, din vector care se rezolvă la aceeași cheie.
    ///
    ///
    /// Dacă vector este sortat, acest lucru elimină toate duplicatele.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Elimină toate elementele consecutive, cu excepția primului, din vector care îndeplinește o relație de egalitate dată.
    ///
    /// Funcția `same_bucket` este trimisă referințe la două elemente din vector și trebuie să stabilească dacă elementele sunt egale.
    /// Elementele sunt transmise în ordine opusă celei din felie, deci dacă `same_bucket(a, b)` returnează `true`, `a` este eliminat.
    ///
    ///
    /// Dacă vector este sortat, acest lucru elimină toate duplicatele.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Adaugă un element în spatele unei colecții.
    ///
    /// # Panics
    ///
    /// Panics dacă noua capacitate depășește `isize::MAX` octeți.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Acest lucru va panic sau se va întrerupe dacă am aloca> isize::MAX octeți sau dacă creșterea lungimii se va revărsa pentru tipurile de dimensiuni zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Elimină ultimul element dintr-un vector și îl returnează sau [`None`] dacă este gol.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Mută toate elementele `other` în `Self`, lăsând `other` gol.
    ///
    /// # Panics
    ///
    /// Panics dacă numărul de elemente din vector depășește un `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Adaugă elemente la `Self` din alt buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Creează un iterator de scurgere care elimină intervalul specificat în vector și produce elementele eliminate.
    ///
    /// Când iteratorul **este scăzut**, toate elementele din interval sunt eliminate din vector, chiar dacă iteratorul nu a fost complet consumat.
    /// Dacă iteratorul **nu este** eliminat (cu [`mem::forget`] de exemplu), nu este specificat câte elemente sunt eliminate.
    ///
    /// # Panics
    ///
    /// Panics dacă punctul de pornire este mai mare decât punctul final sau dacă punctul final este mai mare decât lungimea vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // O gamă completă curăță vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Siguranța memoriei
        //
        // Când Drain este creat pentru prima dată, acesta scurtează lungimea sursei vector pentru a vă asigura că niciun element neinițializat sau mutat nu este accesibil deloc dacă distructorul Drain nu reușește să ruleze niciodată.
        //
        //
        // Drain va ptr::read în afara valorilor de eliminat.
        // Când ați terminat, coada rămasă a vecului este copiată înapoi pentru a acoperi gaura, iar lungimea vector este restabilită la noua lungime.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // setați lungimea self.vec pentru a începe, pentru a fi în siguranță în cazul în care Drain se scurge
            self.set_len(start);
            // Utilizați împrumutul din IterMut pentru a indica comportamentul de împrumut al întregului iterator Drain (cum ar fi &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Șterge vector, eliminând toate valorile.
    ///
    /// Rețineți că această metodă nu are niciun efect asupra capacității alocate a vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Returnează numărul de elemente din vector, denumit și 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Returnează `true` dacă vector nu conține elemente.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Împarte colecția în două la indexul dat.
    ///
    /// Returnează un vector nou alocat care conține elementele din gama `[at, len)`.
    /// După apel, vector original va rămâne conținând elementele `[0, at)` cu capacitatea sa anterioară neschimbată.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // noul vector poate prelua bufferul original și evita copia
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` nesigur și copiați articolele în `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Redimensionează `Vec` în loc, astfel încât `len` să fie egal cu `new_len`.
    ///
    /// Dacă `new_len` este mai mare decât `len`, `Vec` este extins cu diferența, fiecare slot suplimentar fiind umplut cu rezultatul apelării închiderii `f`.
    ///
    /// Valorile returnate de la `f` vor ajunge în `Vec` în ordinea în care au fost generate.
    ///
    /// Dacă `new_len` este mai mic decât `len`, `Vec` este pur și simplu trunchiat.
    ///
    /// Această metodă folosește o închidere pentru a crea noi valori la fiecare apăsare.Dacă preferați [`Clone`] o valoare dată, utilizați [`Vec::resize`].
    /// Dacă doriți să utilizați [`Default`] trait pentru a genera valori, puteți trece [`Default::default`] ca al doilea argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Consumă și scurge `Vec`, returnând o referință mutabilă la conținut, `&'a mut [T]`.
    /// Rețineți că tipul `T` trebuie să depășească durata de viață aleasă `'a`.
    /// Dacă tipul are doar referințe statice sau deloc, atunci acesta poate fi ales pentru a fi `'static`.
    ///
    /// Această funcție este similară cu funcția [`leak`][Box::leak] de pe [`Box`], cu excepția faptului că nu există nicio modalitate de a recupera memoria scursă.
    ///
    ///
    /// Această funcție este utilă în principal pentru datele care trăiesc pentru restul vieții programului.
    /// Dacă renunțați la referința returnată, se va produce o scurgere de memorie.
    ///
    /// # Examples
    ///
    /// Utilizare simplă:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Returnează capacitatea de rezervă rămasă a vector ca o porțiune de `MaybeUninit<T>`.
    ///
    /// Felia returnată poate fi utilizată pentru a umple vector cu date (de ex
    /// prin citirea dintr-un fișier) înainte de a marca datele ca inițializate folosind metoda [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Alocați vector suficient de mare pentru 10 elemente.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Completați primele 3 elemente.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marcați primele 3 elemente ale vector ca fiind inițializate.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Această metodă nu este implementată în termeni de `split_at_spare_mut`, pentru a preveni invalidarea indicatorilor către buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Returnează conținutul vector ca o felie de `T`, împreună cu capacitatea de rezervă rămasă a vector ca o felie de `MaybeUninit<T>`.
    ///
    /// Felia de capacitate de rezervă returnată poate fi utilizată pentru a umple vector cu date (de exemplu, citind dintr-un fișier) înainte de a marca datele ca inițializate folosind metoda [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Rețineți că acesta este un API de nivel scăzut, care ar trebui utilizat cu grijă în scopul optimizării.
    /// Dacă trebuie să atașați date la un `Vec`, puteți utiliza [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] sau [`resize_with`], în funcție de nevoile dvs. exacte.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rezervați spațiu suplimentar suficient de mare pentru 10 elemente.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Completați următoarele 4 elemente.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marcați cele 4 elemente ale vector ca fiind inițializate.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len este ignorat și deci nu s-a schimbat niciodată
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Siguranță: schimbarea .2 returnată (&mut utilizează) este considerată la fel ca apelarea `.set_len(_)`.
    ///
    /// Această metodă este utilizată pentru a avea acces unic la toate piesele vec în același timp în `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` este garantat să fie valabil pentru elementele `len`
        // - `spare_ptr` indică un element dincolo de buffer, deci nu se suprapune cu `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Redimensionează `Vec` în loc, astfel încât `len` să fie egal cu `new_len`.
    ///
    /// Dacă `new_len` este mai mare decât `len`, `Vec` este extins cu diferența, fiecare slot suplimentar fiind umplut cu `value`.
    ///
    /// Dacă `new_len` este mai mic decât `len`, `Vec` este pur și simplu trunchiat.
    ///
    /// Această metodă necesită `T` pentru a implementa [`Clone`], pentru a putea clona valoarea trecută.
    /// Dacă aveți nevoie de mai multă flexibilitate (sau doriți să vă bazați pe [`Default`] în loc de [`Clone`]), utilizați [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clonează și adaugă toate elementele dintr-o felie la `Vec`.
    ///
    /// Iterează peste felia `other`, clonează fiecare element și apoi îl adaugă la acest `Vec`.
    /// `other` vector este parcurs în ordine.
    ///
    /// Rețineți că această funcție este identică cu [`extend`], cu excepția faptului că este specializată să lucreze cu felii.
    ///
    /// Dacă și când Rust devine specializată, această funcție va fi probabil depreciată (dar încă disponibilă).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Copiază elemente din gama `src` până la sfârșitul vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantează că intervalul dat este valid pentru indexarea auto
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Acest cod generalizează `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Extindeți valorile vector cu `n`, utilizând generatorul dat.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Utilizați SetLenOnDrop pentru a rezolva erorile în care este posibil ca compilatorul să nu realizeze magazinul prin `ptr` până la self.set_len() nu face alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Scrieți toate elementele, cu excepția ultimului
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Măriți lungimea la fiecare pas în cazul în care next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Putem scrie ultimul element direct fără clonare inutilă
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len setat de garda scopului
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Elimină elementele repetate consecutive din vector conform implementării [`PartialEq`] trait.
    ///
    ///
    /// Dacă vector este sortat, acest lucru elimină toate duplicatele.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metode și funcții interne
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` trebuie să fie un index valid
    /// - `self.capacity() - self.len()` trebuie să fie `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len este crescut numai după inițializarea elementelor
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - apelantul garantează că src este un index valid
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Elementul tocmai a fost inițializat cu `MaybeUninit::write`, deci este ok să crești len
            // - len este mărită după fiecare element pentru a preveni scurgerile (vezi numărul #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - apelantul garantează că `src` este un index valid
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ambele indicatoare sunt create din referințe de felie unice (`&mut [_]`), deci sunt valide și nu se suprapun.
            //
            // - Elementele sunt: Copiați, deci este OK să le copiați, fără a face nimic cu valorile originale
            // - `count` este egal cu lenul `source`, deci sursa este valabilă pentru citirile `count`
            // - `.reserve(count)` garantează că `spare.len() >= count` atât de rezervă este valid pentru scrierile `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementele au fost inițializate de `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementări comune trait pentru Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cu cfg(test) metoda `[T]::to_vec` inerentă, care este necesară pentru această definiție a metodei, nu este disponibilă.
    // În schimb, utilizați funcția `slice::to_vec`, care este disponibilă numai cu cfg(test) NB, consultați modulul slice::hack din slice.rs pentru mai multe informații
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // aruncați orice nu va fi suprascris
        self.truncate(other.len());

        // self.len <= other.len datorită trunchierii de mai sus, deci feliile de aici sunt întotdeauna în limite.
        //
        let (init, tail) = other.split_at(self.len());

        // refolosiți valorile conținute allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Creează un iterator consumator, adică unul care mută fiecare valoare din vector (de la început până la sfârșit).
    /// vector nu poate fi utilizat după ce ați apelat acest lucru.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s are tip String, nu &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // metodă leaf la care delegă diferite implementări SpecFrom/SpecExtend atunci când nu mai au alte optimizări de aplicat
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Acesta este cazul unui iterator general.
        //
        // Această funcție ar trebui să fie echivalentul moral al:
        //
        //      pentru articol în iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB nu poate depăși, deoarece ar fi trebuit să alocăm spațiul de adrese
                self.set_len(len + 1);
            }
        }
    }

    /// Creează un iterator de îmbinare care înlocuiește intervalul specificat în vector cu iteratorul `replace_with` dat și produce elementele eliminate.
    ///
    /// `replace_with` nu trebuie să aibă aceeași lungime ca `range`.
    ///
    /// `range` este eliminat chiar dacă iteratorul nu este consumat până la final.
    ///
    /// Nu este specificat câte elemente sunt eliminate din vector dacă se scurge valoarea `Splice`.
    ///
    /// Iteratorul de intrare `replace_with` este consumat numai atunci când valoarea `Splice` este scăzută.
    ///
    /// Acest lucru este optim dacă:
    ///
    /// * Coada (elementele din vector după `range`) este goală,
    /// * sau `replace_with` produce elemente mai puține sau egale decât lungimea " intervalului`
    /// * sau limita inferioară a `size_hint()`-ului său este exactă.
    ///
    /// În caz contrar, este alocat un vector temporar și coada este mutată de două ori.
    ///
    /// # Panics
    ///
    /// Panics dacă punctul de pornire este mai mare decât punctul final sau dacă punctul final este mai mare decât lungimea vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Creează un iterator care folosește o închidere pentru a determina dacă un element trebuie eliminat.
    ///
    /// Dacă închiderea revine adevărată, atunci elementul este eliminat și cedat.
    /// Dacă închiderea revine fals, elementul va rămâne în vector și nu va fi cedat de către iterator.
    ///
    /// Utilizarea acestei metode este echivalentă cu următorul cod:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // codul dvs. aici
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Dar `drain_filter` este mai ușor de utilizat.
    /// `drain_filter` este, de asemenea, mai eficient, deoarece poate modifica înapoi elementele matricei în bloc.
    ///
    /// Rețineți că `drain_filter` vă permite, de asemenea, să mutați fiecare element din închiderea filtrului, indiferent dacă alegeți să îl păstrați sau să îl eliminați.
    ///
    ///
    /// # Examples
    ///
    /// Împărțirea unui tablou în echivalenți și cote, reutilizarea alocării inițiale:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Feriți-vă de scurgerea noastră (amplificarea scurgerilor)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Extindeți implementarea care copiază elementele din referințe înainte de a le împinge pe Vec.
///
/// Această implementare este specializată pentru iteratorii de felii, unde folosește [`copy_from_slice`] pentru a adăuga întreaga porțiune simultan.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementează compararea vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementează comanda vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // utilizați drop pentru [T] utilizați o felie brută pentru a face referire la elementele vector ca fiind cel mai slab tip necesar;
            //
            // ar putea evita întrebările de validitate în anumite cazuri
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec gestionează repartizarea
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Creează un `Vec<T>` gol.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test trage în libstd, ceea ce provoacă erori aici
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test trage în libstd, ceea ce provoacă erori aici
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Obține întregul conținut al `Vec<T>` ca matrice, dacă dimensiunea sa se potrivește exact cu cea a matricei solicitate.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Dacă lungimea nu se potrivește, intrarea revine în `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Dacă sunteți bine doar să obțineți un prefix al `Vec<T>`, puteți apela mai întâi [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SIGURANȚĂ: `.set_len(0)` este întotdeauna sunet.
        unsafe { vec.set_len(0) };

        // SIGURANȚĂ: indicatorul unui " Vec` este întotdeauna aliniat corect și
        // alinierea de care are nevoie matricea este aceeași cu elementele.
        // Am verificat mai devreme că avem suficiente articole.
        // Articolele nu vor fi aruncate dublu deoarece `set_len` îi spune lui `Vec` să nu le arunce.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}