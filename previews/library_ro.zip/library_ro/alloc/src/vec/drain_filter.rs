use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Un iterator care folosește o închidere pentru a determina dacă un element trebuie eliminat.
///
/// Această structură este creată de [`Vec::drain_filter`].
/// Consultați documentația sa pentru mai multe.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Indexul articolului care va fi inspectat de următorul apel către `next`.
    pub(super) idx: usize,
    /// Numărul de articole care au fost golite până acum (removed).
    pub(super) del: usize,
    /// Lungimea originală a `vec` înainte de golire.
    pub(super) old_len: usize,
    /// Predicatul de testare a filtrului.
    pub(super) pred: F,
    /// Un semnalizator care indică un panic a apărut în predicatul de testare a filtrului.
    /// Acesta este folosit ca un indiciu în implementarea drop pentru a preveni consumul de restul `DrainFilter`.
    /// Orice articole neprelucrate vor fi schimbate înapoi în `vec`, dar niciun alt articol nu va fi scăzut sau testat de predicatul filtrului.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Returnează o referință la alocatorul de bază.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Actualizați indexul *după* predicatul este chemat.
                // Dacă indexul este actualizat anterior și predicatul panics, elementul de la acest index ar fi scurs.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Aceasta este o stare destul de încurcată și nu există cu adevărat un lucru corect de făcut.
                        // Nu vrem să continuăm să încercăm să executăm `pred`, așa că schimbăm toate elementele neprocesate și le spunem vecului că acestea încă există.
                        //
                        // Schimbarea inversă este necesară pentru a preveni o cădere dublă a ultimului element scurs cu succes înainte de un panic în predicat.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Încercați să consumați orice element rămas dacă predicatul filtrului nu a intrat încă în panică.
        // Vom schimba înapoi toate elementele rămase, indiferent dacă am intrat deja în panică sau dacă consumul de aici panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}