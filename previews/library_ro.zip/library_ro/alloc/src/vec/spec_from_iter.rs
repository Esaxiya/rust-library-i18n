use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializarea trait utilizată pentru Vec::from_iter
///
/// ## Graficul delegării:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Un caz obișnuit este trecerea unui vector într-o funcție care se recolectează imediat într-un vector.
        // Putem scurtcircuita acest lucru dacă IntoIter nu a fost deloc avansat.
        // Când a fost avansat, putem, de asemenea, să refolosim memoria și să mutăm datele în față.
        // Dar facem acest lucru numai atunci când VEC rezultat nu ar avea mai multă capacitate neutilizată decât ar fi creat-o prin implementarea generică FromIterator.
        //
        // Această limitare nu este strict necesară, deoarece comportamentul de alocare al Vec este intenționat nespecificat.
        // Dar este o alegere conservatoare.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // trebuie să delege către spec_extend(), deoarece extend() însuși delegă spec_from pentru Vecs goale
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Aceasta utilizează `iterator.as_slice().to_vec()`, deoarece spec_extend trebuie să facă mai mulți pași pentru a argumenta capacitatea finală + lungimea și, astfel, să facă mai multă muncă.
// `to_vec()` alocă direct suma corectă și o umple exact.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cu cfg(test) metoda `[T]::to_vec` inerentă, care este necesară pentru această definiție a metodei, nu este disponibilă.
    // În schimb, utilizați funcția `slice::to_vec`, care este disponibilă numai cu cfg(test) NB, consultați modulul slice::hack din slice.rs pentru mai multe informații
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}