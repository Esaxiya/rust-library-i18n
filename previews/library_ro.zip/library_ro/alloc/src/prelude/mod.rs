//! Alocarea Prelude
//!
//! Scopul acestui modul este de a atenua importurile articolelor utilizate în mod obișnuit ale `alloc` crate prin adăugarea unui import glob în partea de sus a modulelor:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;