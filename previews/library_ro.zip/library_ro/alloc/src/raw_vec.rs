#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Conținutul noii memorii nu este inițializat.
    Uninitialized,
    /// Noua memorie este garantată pentru zero.
    Zeroed,
}

/// Un utilitar de nivel scăzut pentru alocarea, realocarea și alocarea mai ergonomică a unui tampon de memorie pe heap fără a fi nevoie să vă faceți griji cu privire la toate cazurile de colț implicate.
///
/// Acest tip este excelent pentru construirea propriilor structuri de date precum Vec și VecDeque.
/// În special:
///
/// * Produce `Unique::dangling()` pe tipuri de dimensiuni zero.
/// * Produce `Unique::dangling()` pe alocări de lungime zero.
/// * Evită eliberarea `Unique::dangling()`.
/// * Prinde toate deversările în calcule de capacitate (le promovează la "capacity overflow" panics).
/// * Protejează sistemele pe 32 de biți care alocă mai mult de isize::MAX octeți.
/// * Feriți-vă de lungimea voastră.
/// * Apelează `handle_alloc_error` pentru alocări eronate.
/// * Conține un `ptr::Unique` și conferă astfel utilizatorului toate avantajele aferente.
/// * Folosește excesul returnat de la alocator pentru a utiliza cea mai mare capacitate disponibilă.
///
/// Acest tip nu inspectează oricum memoria pe care o gestionează.Când este scăpat,*își va* elibera memoria, dar nu *va* încerca să renunțe la conținut.
/// Depinde de utilizatorul `RawVec` să se ocupe de lucrurile reale *stocate* în interiorul unui `RawVec`.
///
/// Rețineți că excesul de tipuri de dimensiuni zero este întotdeauna infinit, deci `capacity()` returnează întotdeauna `usize::MAX`.
/// Aceasta înseamnă că trebuie să aveți grijă atunci când faceți acest tip cu un `Box<[T]>`, deoarece `capacity()` nu va da lungimea.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Acest lucru există deoarece `#[unstable]` `const fn`s nu trebuie să fie conform cu `min_const_fn` și, prin urmare, nu pot fi apelate nici în`min_const_fn`s.
    ///
    /// Dacă modificați `RawVec<T>::new` sau dependențe, vă rugăm să aveți grijă să nu introduceți nimic care ar încălca cu adevărat `min_const_fn`.
    ///
    /// NOTE: Am putea evita acest hack și putem verifica conformitatea cu un anumit atribut `#[rustc_force_min_const_fn]` care necesită conformitate cu `min_const_fn`, dar nu permite neapărat să îl apelați în `stable(...) const fn`/cod de utilizator care nu activează `foo` atunci când este prezent `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Creează cel mai mare `RawVec` posibil (pe heap-ul sistemului) fără alocare.
    /// Dacă `T` are o dimensiune pozitivă, atunci acesta face un `RawVec` cu capacitate `0`.
    /// Dacă `T` are dimensiunea zero, atunci face un `RawVec` cu capacitatea `usize::MAX`.
    /// Util pentru implementarea alocării întârziate.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Creează un `RawVec` (pe heap-ul sistemului) cu exact cerințele de capacitate și aliniere pentru un `[T; capacity]`.
    /// Acest lucru este echivalent cu apelarea `RawVec::new` atunci când `capacity` este `0` sau `T` are dimensiunea zero.
    /// Rețineți că, dacă `T` are dimensiunea zero, acest lucru înseamnă că nu veți obține un `RawVec` cu capacitatea solicitată.
    ///
    /// # Panics
    ///
    /// Panics dacă capacitatea solicitată depășește `isize::MAX` octeți.
    ///
    /// # Aborts
    ///
    /// Încetează pe OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// La fel ca `with_capacity`, dar garantează că tamponul este redus la zero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstituie un `RawVec` dintr-un indicator și capacitate.
    ///
    /// # Safety
    ///
    /// `ptr` trebuie alocat (pe heap-ul sistemului) și cu `capacity` dat.
    /// `capacity` nu poate depăși `isize::MAX` pentru tipurile de dimensiuni.(doar o preocupare pentru sistemele pe 32 de biți).
    /// ZST vectors poate avea o capacitate de până la `usize::MAX`.
    /// Dacă `ptr` și `capacity` provin de la un `RawVec`, atunci acest lucru este garantat.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs sunt proști.Sari la:
    // - 8 dacă dimensiunea elementului este 1, deoarece este posibil ca orice alocatori de heap să rotunjească o cerere mai mică de 8 octeți la cel puțin 8 octeți.
    //
    // - 4 dacă elementele sunt de dimensiuni moderate (<=1 KiB).
    // - 1 altfel, pentru a evita risipa prea mult spațiu pentru Vecs foarte scurți.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// La fel ca `new`, dar parametrizat în alegerea alocatorului pentru `RawVec` returnat.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` înseamnă "unallocated".tipurile de dimensiuni zero sunt ignorate.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// La fel ca `with_capacity`, dar parametrizat în alegerea alocatorului pentru `RawVec` returnat.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// La fel ca `with_capacity_zeroed`, dar parametrizat în alegerea alocatorului pentru `RawVec` returnat.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Convertește un `Box<[T]>` într-un `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Convertește întregul buffer în `Box<[MaybeUninit<T>]>` cu `len` specificat.
    ///
    /// Rețineți că acest lucru va reconstitui corect orice modificări `cap` care ar fi putut fi efectuate.(Vedeți descrierea tipului pentru detalii.)
    ///
    /// # Safety
    ///
    /// * `len` trebuie să fie mai mare sau egală cu cea mai recentă capacitate solicitată și
    /// * `len` trebuie să fie mai mic sau egal cu `self.capacity()`.
    ///
    /// Rețineți că capacitatea solicitată și `self.capacity()` pot diferi, întrucât un alocator ar putea localiza și returna un bloc de memorie mai mare decât cel solicitat.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Verificați sănătatea jumătate din cerința de siguranță (nu putem verifica cealaltă jumătate).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Aici evităm `unwrap_or_else`, deoarece umflă cantitatea de LLVM IR generată.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Reconstituie un `RawVec` dintr-un pointer, capacitate și alocator.
    ///
    /// # Safety
    ///
    /// `ptr` trebuie alocat (prin alocatorul dat `alloc`) și cu `capacity` dat.
    /// `capacity` nu poate depăși `isize::MAX` pentru tipurile de dimensiuni.
    /// (doar o preocupare pentru sistemele pe 32 de biți).
    /// ZST vectors poate avea o capacitate de până la `usize::MAX`.
    /// Dacă `ptr` și `capacity` provin de la un `RawVec` creat prin `alloc`, atunci acest lucru este garantat.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Obține un indicator brut la începutul alocării.
    /// Rețineți că acesta este `Unique::dangling()` dacă `capacity == 0` sau `T` are dimensiunea zero.
    /// În primul caz, trebuie să fii atent.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Obține capacitatea alocării.
    ///
    /// Aceasta va fi întotdeauna `usize::MAX` dacă `T` are dimensiunea zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Returnează o referință partajată la alocatorul care sprijină acest `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Avem o bucată de memorie alocată, astfel încât să putem ocoli verificările în timpul rulării pentru a obține aspectul actual.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Asigură că bufferul conține cel puțin suficient spațiu pentru a conține elemente `len + additional`.
    /// Dacă nu are deja suficientă capacitate, va realoca suficient spațiu, plus spațiu confortabil pentru a obține un comportament amortizat *O*(1).
    ///
    /// Va limita acest comportament dacă s-ar produce în mod inutil la panic.
    ///
    /// Dacă `len` depășește `self.capacity()`, acest lucru nu poate aloca efectiv spațiul solicitat.
    /// Acest lucru nu este cu adevărat nesigur, dar codul nesigur *pe care îl scrieți* care se bazează pe comportamentul acestei funcții se poate rupe.
    ///
    /// Acest lucru este ideal pentru implementarea unei operațiuni de împingere în bloc, cum ar fi `extend`.
    ///
    /// # Panics
    ///
    /// Panics dacă noua capacitate depășește `isize::MAX` octeți.
    ///
    /// # Aborts
    ///
    /// Încetează pe OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerva s-ar fi întrerupt sau ar fi intrat în panică dacă len-ul ar depăși `isize::MAX`, deci acest lucru este sigur de făcut necontrolat acum.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// La fel ca `reserve`, dar revine la erori în loc de panică sau avort.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Asigură că bufferul conține cel puțin suficient spațiu pentru a conține elemente `len + additional`.
    /// Dacă nu este deja, va realoca cantitatea minimă posibilă de memorie necesară.
    /// În general, aceasta va fi exact cantitatea de memorie necesară, dar în principiu alocatorul este liber să dea înapoi mai mult decât am cerut.
    ///
    ///
    /// Dacă `len` depășește `self.capacity()`, acest lucru nu poate aloca efectiv spațiul solicitat.
    /// Acest lucru nu este cu adevărat nesigur, dar codul nesigur *pe care îl scrieți* care se bazează pe comportamentul acestei funcții se poate rupe.
    ///
    /// # Panics
    ///
    /// Panics dacă noua capacitate depășește `isize::MAX` octeți.
    ///
    /// # Aborts
    ///
    /// Încetează pe OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// La fel ca `reserve_exact`, dar revine la erori în loc de panică sau avort.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Reduce alocarea până la suma specificată.
    /// Dacă suma dată este 0, de fapt se alocă complet.
    ///
    /// # Panics
    ///
    /// Panics dacă suma dată este *mai mare* decât capacitatea curentă.
    ///
    /// # Aborts
    ///
    /// Încetează pe OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Revine dacă bufferul trebuie să crească pentru a îndeplini capacitatea suplimentară necesară.
    /// Folosit în principal pentru a face posibilă apelurile de rezervă inlining fără a utiliza `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Această metodă este de obicei instanțiată de multe ori.Deci, dorim ca acesta să fie cât mai mic posibil, pentru a îmbunătăți timpii de compilare.
    // Dar dorim, de asemenea, ca cât mai mult din conținutul său să fie calculabil static, pentru a face ca codul generat să ruleze mai repede.
    // Prin urmare, această metodă este scrisă cu atenție, astfel încât tot codul care depinde de `T` să se afle în ea, în timp ce cât mai mult din codul care nu depinde de `T` este în funcții care nu sunt generice peste `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Acest lucru este asigurat de contextele de apelare.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Deoarece returnăm o capacitate de `usize::MAX` când `elem_size` este
            // 0, a ajunge aici înseamnă neapărat că `RawVec` este prea plin.
            return Err(CapacityOverflow);
        }

        // Din păcate, nu putem face nimic cu privire la aceste verificări.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Acest lucru garantează o creștere exponențială.
        // Dublarea nu poate revărsa deoarece `cap <= isize::MAX` și tipul de `cap` sunt `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` este non-generic peste `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Constrângerile asupra acestei metode sunt la fel ca cele de pe `grow_amortized`, dar această metodă este de obicei instanțiată mai rar, deci este mai puțin critică.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Deoarece returnăm o capacitate de `usize::MAX` când dimensiunea tipului este
            // 0, a ajunge aici înseamnă neapărat că `RawVec` este prea plin.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` este non-generic peste `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Această funcție este în afara `RawVec` pentru a minimiza timpii de compilare.Vezi comentariul de mai sus `RawVec::grow_amortized` pentru detalii.
// (Parametrul `A` nu este semnificativ, deoarece numărul diferitelor tipuri de `A` văzute în practică este mult mai mic decât numărul de tipuri `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Verificați eroarea aici pentru a minimiza dimensiunea `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alocatorul verifică egalitatea alinierii
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Eliberează memoria deținută de `RawVec`*fără a* încerca să renunțe la conținutul său.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Funcție centrală pentru gestionarea erorilor de rezervă.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Trebuie să garantăm următoarele:
// * Nu alocăm obiecte `> isize::MAX`-byte.
// * Nu depășim `usize::MAX` și alocăm prea puțin.
//
// Pe 64 de biți trebuie doar să verificăm depășirea, deoarece încercarea de a aloca octeți `> isize::MAX` va eșua cu siguranță.
// Pe 32 de biți și pe 16 biți trebuie să adăugăm o protecție suplimentară pentru acest lucru în cazul în care rulăm pe o platformă care poate folosi toți cei 4 GB în spațiul utilizatorului, de exemplu, PAE sau x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// O funcție centrală responsabilă pentru depășirea capacității de raportare.
// Acest lucru vă va asigura că generarea de cod legată de aceste panics este minimă, deoarece există o singură locație pe care panics, mai degrabă decât o grămadă în întregul modul.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}