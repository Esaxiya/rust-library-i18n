#![stable(feature = "rust1", since = "1.0.0")]

//! Indicatoare de numărare a referințelor sigure pentru fire.
//!
//! Consultați documentația [`Arc<T>`][Arc] pentru mai multe detalii.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// O limită redusă a cantității de referințe care pot fi făcute la un `Arc`.
///
/// Depășirea acestei limite va anula programul (deși nu neapărat) la referințele _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer nu acceptă gardurile de memorie.
// Pentru a evita rapoartele fals pozitive în implementarea Arc/Slab, utilizați sarcini atomice pentru sincronizare.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Un indicator de referință sigur pentru fire.'Arc' înseamnă " Număr de referințe atomice`.
///
/// Tipul `Arc<T>` oferă proprietatea partajată a unei valori de tip `T`, alocată în heap.Invocarea [`clone`][clone] pe `Arc` produce o nouă instanță `Arc`, care indică aceeași alocare pe heap ca sursa `Arc`, în timp ce crește numărul de referințe.
/// Când ultimul indicator `Arc` la o anumită alocare este distrus, valoarea stocată în acea alocare (denumită adesea "inner value") este, de asemenea, abandonată.
///
/// Referințele partajate în Rust interzic mutația în mod implicit, iar `Arc` nu face excepție: în general nu puteți obține o referință mutabilă la ceva din interiorul unui `Arc`.Dacă trebuie să mutați printr-un `Arc`, utilizați [`Mutex`][mutex], [`RwLock`][rwlock] sau unul dintre tipurile [`Atomic`][atomic].
///
/// ## Siguranța firului
///
/// Spre deosebire de [`Rc<T>`], `Arc<T>` folosește operații atomice pentru numărarea referințelor sale.Aceasta înseamnă că este sigur pentru fire.Dezavantajul este că operațiunile atomice sunt mai scumpe decât accesele obișnuite de memorie.Dacă nu partajați alocări numărate de referințe între fire, luați în considerare utilizarea [`Rc<T>`] pentru cheltuieli generale mai mici.
/// [`Rc<T>`] este o valoare implicită sigură, deoarece compilatorul va prinde orice încercare de a trimite un [`Rc<T>`] între fire.
/// Cu toate acestea, o bibliotecă ar putea alege `Arc<T>` pentru a oferi consumatorilor de bibliotecă mai multă flexibilitate.
///
/// `Arc<T>` va implementa [`Send`] și [`Sync`] atâta timp cât `T` implementează [`Send`] și [`Sync`].
/// De ce nu puteți pune un tip `T` care nu este sigur pentru fire pentru al face sigur?Acest lucru poate fi puțin contra-intuitiv la început: la urma urmei, nu este siguranța firului `Arc<T>`?Cheia este următoarea: `Arc<T>` face ca firul să fie sigur în a deține mai multe proprietăți asupra acelorași date, dar nu adaugă siguranța firelor la datele sale.
///
/// Luați în considerare `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] nu este [`Sync`], iar dacă `Arc<T>` a fost întotdeauna [`Send`], `Arc <` [`RefCell<T>`]`>`ar fi la fel de bine.
/// Dar atunci am avea o problemă:
/// [`RefCell<T>`] nu este sigur pentru fire;ține evidența numărului de împrumuturi folosind operații non-atomice.
///
/// În cele din urmă, aceasta înseamnă că poate fi necesar să împerecheați `Arc<T>` cu un fel de tip [`std::sync`], de obicei [`Mutex<T>`][mutex].
///
/// ## Cicluri de rupere cu `Weak`
///
/// Metoda [`downgrade`][downgrade] poate fi utilizată pentru a crea un indicator [`Weak`] care nu deține.Un indicator [`Weak`] poate fi [`upgrade`][upgrade] d la un `Arc`, dar acesta va returna [`None`] dacă valoarea stocată în alocare a fost deja abandonată.
/// Cu alte cuvinte, pointerele `Weak` nu păstrează în valoare valoarea din alocare;cu toate acestea, ele *păstrează* alocația (magazinul de rezervă pentru valoare) în viață.
///
/// Un ciclu între pointerele `Arc` nu va fi niciodată repartizat.
/// Din acest motiv, [`Weak`] este folosit pentru a întrerupe ciclurile.De exemplu, un copac ar putea avea pointeri puternici `Arc` de la nodurile părinte la copii și indicatori [`Weak`] de la copii înapoi la părinți.
///
/// # Referințe de clonare
///
/// Crearea unei noi referințe dintr-un indicator de referință existent se face folosind `Clone` trait implementat pentru [`Arc<T>`][Arc] și [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Cele două sintaxi de mai jos sunt echivalente.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b și foo sunt toate arcurile care indică aceeași locație de memorie
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` anulează automat referințele la `T` (prin [`Deref`][deref] trait), astfel încât să puteți apela metodele `T` pe o valoare de tip `Arc<T>`.Pentru a evita ciocnirile de nume cu metodele lui `T`, metodele `Arc<T>` în sine sunt funcții asociate, numite folosind [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Implementările lui traits precum `Clone` pot fi, de asemenea, apelate folosind o sintaxă complet calificată.
/// Unii oameni preferă să utilizeze sintaxa complet calificată, în timp ce alții preferă să utilizeze sintaxa metodă-apel.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaxă metodă-apel
/// let arc2 = arc.clone();
/// // Sintaxă complet calificată
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] nu derereferă automat la `T`, deoarece este posibil ca valoarea interioară să fi fost deja scăzută.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Partajarea unor date imuabile între fire:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Rețineți că **nu** efectuăm aceste teste aici.
// Constructorii windows devin foarte nemulțumiți dacă un thread depășește firul principal și apoi iese în același timp (ceva este blocat), așa că evităm acest lucru în totalitate, neexecutând aceste teste.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Partajarea unui [`AtomicUsize`] mutabil:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Consultați [`rc` documentation][rc_examples] pentru mai multe exemple de numărare a referințelor în general.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` este o versiune a [`Arc`] care deține o referință care nu deține proprietatea asupra alocării gestionate.
/// Alocarea este accesată apelând [`upgrade`] pe indicatorul `Weak`, care returnează o [`Opțiune`]`<`[`Arc`] `<T>>`.
///
/// Deoarece o referință `Weak` nu este luată în considerare pentru proprietate, nu va împiedica renunțarea la valoarea stocată în alocare, iar `Weak` în sine nu oferă nicio garanție cu privire la valoarea care este încă prezentă.
///
/// Astfel se poate returna [`None`] când [`upgrade`] d.
/// Rețineți însă că o referință `Weak`*nu* împiedică alocarea în sine (magazinul de suport) să fie alocată.
///
/// Un indicator `Weak` este util pentru păstrarea unei referințe temporare la alocarea gestionată de [`Arc`] fără a împiedica scăderea valorii sale interne.
/// De asemenea, este utilizat pentru a preveni referințele circulare între pointerii [`Arc`], deoarece referințele reciproce nu ar permite niciodată ca niciunul dintre [`Arc`] să fie abandonat.
/// De exemplu, un copac ar putea avea indicatori [`Arc`] puternici de la nodurile părinte la copii și indicatori `Weak` de la copii înapoi la părinți.
///
/// Modul tipic de a obține un pointer `Weak` este să apelați [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Acesta este un `NonNull` pentru a permite optimizarea dimensiunii acestui tip în enumerări, dar nu este neapărat un indicator valid.
    //
    // `Weak::new` setează acest lucru la `usize::MAX` astfel încât să nu fie nevoie să aloce spațiu pe heap.
    // Aceasta nu este o valoare pe care un pointer real o va avea vreodată, deoarece RcBox are alinierea cel puțin 2.
    // Acest lucru este posibil doar când `T: Sized`;`T` unsized nu atârnă niciodată.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Aceasta este rezistentă la repr(C) la future împotriva unei posibile reordonări a câmpului, care ar interfera cu [into|from]_raw() altfel sigur, de tipuri interioare transmutabile.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // valoarea usize::MAX acționează ca o santinelă pentru temporar "locking" capacitatea de a actualiza pointerii slabi sau de a retrograda pe cei puternici;aceasta este utilizată pentru a evita cursele în `make_mut` și `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Construiește un nou `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Porniți numărul indicatorului slab ca 1, care este indicatorul slab ținut de toți indicatorii puternici (kinda), consultați std/rc.rs pentru mai multe informații
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Construiește un nou `Arc<T>` folosind o referință slabă la sine.
    /// Încercarea de a actualiza referința slabă înainte ca această funcție să revină va avea ca rezultat o valoare `None`.
    /// Cu toate acestea, referința slabă poate fi clonată liber și stocată pentru utilizare ulterioară.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Construiți interiorul în starea "uninitialized" cu o singură referință slabă.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Este important să nu renunțăm la proprietatea indicatorului slab, altfel memoria ar putea fi eliberată până la întoarcerea `data_fn`.
        // Dacă am dori cu adevărat să trecem drepturile de proprietate, am putea crea un indicator slab suplimentar pentru noi înșine, dar acest lucru ar duce la actualizări suplimentare ale numărului de referințe slabe, care altfel ar putea să nu fie necesar.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Acum putem inițializa corect valoarea interioară și transforma referința noastră slabă într-o referință puternică.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Scrierea de mai sus în câmpul de date trebuie să fie vizibilă pentru orice fire care observă un număr puternic diferit de zero.
            // Prin urmare, avem nevoie de cel puțin o comandă "Release" pentru a ne sincroniza cu `compare_exchange_weak` în `Weak::upgrade`.
            //
            // "Acquire" comanda nu este necesară.
            // Când luăm în considerare comportamentele posibile ale `data_fn`, trebuie doar să analizăm ce ar putea face cu o referință la un `Weak` care nu poate fi actualizat:
            //
            // - Poate *clona*`Weak`, crescând numărul de referințe slab.
            // - Poate renunța la aceste clone, scăzând numărul de referință slab (dar niciodată la zero).
            //
            // Aceste efecte secundare nu ne afectează în niciun fel și nu sunt posibile alte efecte secundare numai cu codul sigur.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Referințele puternice ar trebui să dețină în mod colectiv o referință comună slabă, deci nu rulați distructorul pentru vechea noastră referință slabă.
        //
        mem::forget(weak);
        strong
    }

    /// Construiește un nou `Arc` cu conținut neinițializat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inițializare amânată:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construiește un nou `Arc` cu conținut neinițializat, memoria fiind umplută cu octeți `0`.
    ///
    ///
    /// Consultați [`MaybeUninit::zeroed`][zeroed] pentru exemple de utilizare corectă și incorectă a acestei metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construiește un nou `Pin<Arc<T>>`.
    /// Dacă `T` nu implementează `Unpin`, atunci `data` va fi fixat în memorie și nu va putea fi mutat.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Construiește un nou `Arc<T>`, returnând o eroare dacă alocarea eșuează.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Porniți numărul indicatorului slab ca 1, care este indicatorul slab ținut de toți indicatorii puternici (kinda), consultați std/rc.rs pentru mai multe informații
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Construiește un nou `Arc` cu conținut neinițializat, returnând o eroare dacă alocarea eșuează.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inițializare amânată:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construiește un nou `Arc` cu conținut neinițializat, memoria fiind umplută cu octeți `0`, returnând o eroare dacă alocarea eșuează.
    ///
    ///
    /// Consultați [`MaybeUninit::zeroed`][zeroed] pentru exemple de utilizare corectă și incorectă a acestei metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Returnează valoarea interioară, dacă `Arc` are exact o referință puternică.
    ///
    /// În caz contrar, un [`Err`] este returnat cu același `Arc` care a fost transmis.
    ///
    ///
    /// Acest lucru va reuși chiar dacă există referințe slabe remarcabile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Faceți un indicator slab pentru a curăța referința implicită puternic-slab
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Construiește o nouă felie cu număr de referințe atomice cu conținut neinițializat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inițializare amânată:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Construiește o nouă felie cu referințe atomice cu conținut neinițializat, memoria fiind umplută cu octeți `0`.
    ///
    ///
    /// Consultați [`MaybeUninit::zeroed`][zeroed] pentru exemple de utilizare corectă și incorectă a acestei metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Convertește în `Arc<T>`.
    ///
    /// # Safety
    ///
    /// La fel ca în cazul [`MaybeUninit::assume_init`], depinde de apelant să garanteze că valoarea interioară este într-adevăr într-o stare inițializată.
    ///
    /// Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament imediat nedefinit.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inițializare amânată:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Convertește în `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// La fel ca în cazul [`MaybeUninit::assume_init`], depinde de apelant să garanteze că valoarea interioară este într-adevăr într-o stare inițializată.
    ///
    /// Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament imediat nedefinit.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inițializare amânată:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consumă `Arc`, returnând indicatorul înfășurat.
    ///
    /// Pentru a evita scurgerile de memorie, indicatorul trebuie convertit înapoi la un `Arc` folosind [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Oferă un indicator brut pentru date.
    ///
    /// Numărul nu este afectat în niciun fel, iar `Arc` nu este consumat.
    /// Pointerul este valabil atâta timp cât există un număr puternic în `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SIGURANȚĂ: Acest lucru nu poate trece prin Deref::deref sau RcBoxPtr::inner deoarece
        // acest lucru este necesar pentru a păstra proveniența raw/mut astfel încât, de ex
        // `get_mut` poate scrie prin pointer după ce Rc este recuperat prin `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Construiește un `Arc<T>` dintr-un pointer brut.
    ///
    /// Pointerul brut trebuie să fi fost returnat anterior printr-un apel către [`Arc<U>::into_raw`][into_raw] unde `U` trebuie să aibă aceeași dimensiune și aliniere ca `T`.
    /// Acest lucru este trivial adevărat dacă `U` este `T`.
    /// Rețineți că dacă `U` nu este `T`, dar are aceeași dimensiune și aliniere, acesta este practic ca transmutarea referințelor de diferite tipuri.
    /// Consultați [`mem::transmute`][transmute] pentru mai multe informații despre restricțiile care se aplică în acest caz.
    ///
    /// Utilizatorul `from_raw` trebuie să se asigure că o anumită valoare `T` este scăzută o singură dată.
    ///
    /// Această funcție este nesigură, deoarece utilizarea necorespunzătoare poate duce la siguranța memoriei, chiar dacă `Arc<T>` returnat nu este accesat niciodată.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Conversia înapoi la un `Arc` pentru a preveni scurgerea.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Apelurile suplimentare către `Arc::from_raw(x_ptr)` ar fi nesigure pentru memorie.
    /// }
    ///
    /// // Memoria a fost eliberată când `x` a ieșit din sfera de aplicare de mai sus, așa că `x_ptr` este acum suspendat!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Inversați offsetul pentru a găsi ArcInner original.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Creează un nou indicator [`Weak`] la această alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Acest Relaxed este OK pentru că verificăm valoarea din CAS de mai jos.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // verificați dacă contorul slab este în prezent "locked";dacă da, învârtiți.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: acest cod ignoră în prezent posibilitatea de revărsare
            // în usize::MAX;în general, atât Rc, cât și Arc trebuie ajustate pentru a face față revărsării.
            //

            // Spre deosebire de Clone(), avem nevoie ca aceasta să fie o citire Achiziție pentru sincronizare cu scrierea provenită de la `is_unique`, astfel încât evenimentele anterioare acelei scrieri să se întâmple înainte de această citire.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Asigurați-vă că nu creăm un Punct Slab
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Obține numărul de indicatori [`Weak`] la această alocare.
    ///
    /// # Safety
    ///
    /// Această metodă în sine este sigură, dar folosirea ei corectă necesită o îngrijire suplimentară.
    /// Un alt fir poate modifica oricând numărul scăzut, inclusiv potențial între apelarea acestei metode și acționarea asupra rezultatului.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Această afirmație este deterministă, deoarece nu am împărțit `Arc` sau `Weak` între fire.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Dacă numărul slab este blocat în prezent, valoarea numărării a fost 0 chiar înainte de a lua blocarea.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Obține numărul de indicatori (`Arc`) puternici pentru această alocare.
    ///
    /// # Safety
    ///
    /// Această metodă în sine este sigură, dar folosirea ei corectă necesită o îngrijire suplimentară.
    /// Un alt fir poate modifica oricând numărul puternic, inclusiv potențial între apelarea acestei metode și acționarea asupra rezultatului.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Această afirmație este deterministă, deoarece nu am împărțit `Arc` între fire.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Mărește numărul de referințe puternice pe `Arc<T>` asociat cu indicatorul furnizat cu unul.
    ///
    /// # Safety
    ///
    /// Pointerul trebuie să fi fost obținut prin `Arc::into_raw`, iar instanța `Arc` asociată trebuie să fie validă (adică
    /// numărul puternic trebuie să fie de cel puțin 1) pe durata acestei metode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Această afirmație este deterministă, deoarece nu am împărțit `Arc` între fire.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Păstrați Arc, dar nu atingeți refcount prin împachetarea în ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Acum măriți numărul de refc, dar nu renunțați nici la refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Scade numărul de referințe puternice de pe `Arc<T>` asociat cu indicatorul furnizat cu unul.
    ///
    /// # Safety
    ///
    /// Pointerul trebuie să fi fost obținut prin `Arc::into_raw`, iar instanța `Arc` asociată trebuie să fie validă (adică
    /// numărul puternic trebuie să fie cel puțin 1) la invocarea acestei metode.
    /// Această metodă poate fi utilizată pentru a elibera `Arc` final și pentru stocarea de rezervă, dar **nu ar trebui** apelat după ce `Arc` final a fost lansat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Aceste afirmații sunt deterministe, deoarece nu am împărțit `Arc` între fire.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Această nesiguranță este ok, deoarece în timp ce acest arc este în viață, avem garanția că indicatorul interior este valid.
        // Mai mult, știm că structura `ArcInner` în sine este `Sync`, deoarece datele interioare sunt și `Sync`, așa că suntem ok să împrumutăm un pointer imuabil pentru acest conținut.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Partea neliniată a `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Distrugeți datele în acest moment, chiar dacă este posibil să nu eliberăm alocarea casetei în sine (pot exista totuși indicatori slabi).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Aruncați ref. Slab deținut colectiv de toate referințele puternice
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returnează `true` dacă cele două ʻArc` indică aceeași alocare (într-o venă similară cu [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Alocă un `ArcInner<T>` cu spațiu suficient pentru o valoare interioară posibil nedimensionată unde valoarea are aspectul furnizat.
    ///
    /// Funcția `mem_to_arcinner` este apelată cu indicatorul de date și trebuie să returneze înapoi un indicator (potențial gras) pentru `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calculați aspectul utilizând aspectul valorii date.
        // Anterior, aspectul a fost calculat pe expresia `&*(ptr as* const ArcInner<T>)`, dar aceasta a creat o referință nealiniată (vezi #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alocă un `ArcInner<T>` cu spațiu suficient pentru o valoare interioară posibil nedimensionată în care valoarea are aspectul furnizat, returnând o eroare dacă alocarea eșuează.
    ///
    ///
    /// Funcția `mem_to_arcinner` este apelată cu indicatorul de date și trebuie să returneze înapoi un indicator (potențial gras) pentru `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calculați aspectul utilizând aspectul valorii date.
        // Anterior, aspectul a fost calculat pe expresia `&*(ptr as* const ArcInner<T>)`, dar aceasta a creat o referință nealiniată (vezi #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inițializați ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Alocă un `ArcInner<T>` cu spațiu suficient pentru o valoare interioară nedimensionată.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Alocați pentru `ArcInner<T>` folosind valoarea dată.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copiați valoarea ca octeți
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Eliberați alocarea fără a renunța la conținutul acesteia
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Alocă un `ArcInner<[T]>` cu lungimea dată.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copiați elementele din felie în Arc nou alocat <\[T\]>
    ///
    /// Nesigur, deoarece apelantul trebuie să fie proprietar sau să asocieze `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Construiește un `Arc<[T]>` dintr-un iterator despre care se știe că are o anumită dimensiune.
    ///
    /// Comportamentul este nedefinit dacă dimensiunea este greșită.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic protejează în timp ce clonează elemente T.
        // În cazul unui panic, elementele care au fost scrise în noul ArcInner vor fi abandonate, apoi memoria va fi eliberată.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer către primul element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Totul clar.Uitați de gardă pentru a nu elibera noul ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializarea trait utilizată pentru `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Face o clonă a indicatorului `Arc`.
    ///
    /// Acest lucru creează un alt indicator către aceeași alocare, mărind numărul de referințe puternic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Folosirea unei ordonări relaxate este în regulă aici, deoarece cunoașterea referinței originale împiedică alte fire să șteargă în mod eronat obiectul.
        //
        // Așa cum se explică în [Boost documentation][1], creșterea contorului de referință se poate face întotdeauna cu memory_order_relaxed: Noile referințe la un obiect pot fi formate numai dintr-o referință existentă și trecerea unei referințe existente dintr-un fir în altul trebuie să furnizeze deja orice sincronizare necesară.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Cu toate acestea, trebuie să ne ferim de recompensele masive în cazul în care cineva este " mem: : forget`ing Arcs.
        // Dacă nu facem acest lucru, numărul poate depăși și utilizatorii vor folosi-după gratuit.
        // Ne saturăm rasial până la `isize::MAX`, presupunând că nu există ~2 miliarde de fire care incrementează numărul de referințe simultan.
        //
        // Acest branch nu va fi luat niciodată în niciun program realist.
        //
        // Avortăm pentru că un astfel de program este incredibil de degenerat și nu ne interesează să îl susținem.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Face o referință mutabilă în `Arc` dat.
    ///
    /// Dacă există alți indicatori `Arc` sau [`Weak`] către aceeași alocare, atunci `make_mut` va crea o nouă alocare și va invoca [`clone`][clone] pe valoarea interioară pentru a asigura proprietatea unică.
    /// Acest lucru este, de asemenea, denumit clone-on-write.
    ///
    /// Rețineți că acest lucru diferă de comportamentul [`Rc::make_mut`], care disociază orice pointeri `Weak` rămași.
    ///
    /// Vezi și [`get_mut`][get_mut], care va eșua mai degrabă decât clonarea.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Nu va clona nimic
    /// let mut other_data = Arc::clone(&data); // Nu va clona date interioare
    /// *Arc::make_mut(&mut data) += 1;         // Clonează date interioare
    /// *Arc::make_mut(&mut data) += 1;         // Nu va clona nimic
    /// *Arc::make_mut(&mut other_data) *= 2;   // Nu va clona nimic
    ///
    /// // Acum `data` și `other_data` indică alocări diferite.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Rețineți că deținem atât o referință puternică, cât și o referință slabă.
        // Astfel, eliberarea referinței noastre puternice nu va provoca, prin ea însăși, repartizarea memoriei.
        //
        // Folosiți Achiziție pentru a vă asigura că vedem orice scrieri pe `weak` care se întâmplă înainte de scrierea versiunii (adică scăderi) pe `strong`.
        // Deoarece avem un număr slab, nu există nicio șansă ca ArcInner în sine să poată fi repartizat.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Există un alt indicator puternic, deci trebuie să clonăm.
            // Pre-alocați memoria pentru a permite scrierea directă a valorii clonate.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relaxat este suficient în cele de mai sus, deoarece aceasta este, în esență, o optimizare: întrecem mereu cu indicii slabi căzuți.
            // În cel mai rău caz, ajungem să alocăm un arc nou inutil.
            //

            // Am eliminat ultima referință puternică, dar mai sunt referințe slabe suplimentare.
            // Vom muta conținutul într-un arc nou și le vom invalida pe ceilalți referinți slabi.
            //

            // Rețineți că nu este posibil ca citirea `weak` să producă usize::MAX (adică blocat), deoarece numărul slab poate fi blocat doar de un fir cu o referință puternică.
            //
            //

            // Materializați propriul nostru indicator slab implicit, astfel încât să poată curăța ArcInner după cum este necesar.
            //
            let _weak = Weak { ptr: this.ptr };

            // Poate fura datele, tot ce a mai rămas este Slab
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Am fost singura referință de ambele tipuri;reveniți la numărul puternic de ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Ca și în cazul `get_mut()`, nesiguranța este ok, deoarece referința noastră a fost fie unică pentru început, fie a devenit una după clonarea conținutului.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Returnează o referință mutabilă în `Arc` dat, dacă nu există alți indicatori `Arc` sau [`Weak`] la aceeași alocare.
    ///
    ///
    /// Returnează [`None`] în caz contrar, deoarece nu este sigur să mutați o valoare partajată.
    ///
    /// A se vedea, de asemenea, [`make_mut`][make_mut], care va [`clone`][clone] valoarea interioară atunci când există alți indicatori.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Această nesiguranță este ok, deoarece avem garanția că indicatorul returnat este singurul indicator care va fi returnat vreodată lui T.
            // Numărul nostru de referințe este garantat să fie 1 în acest moment și am cerut ca Arc în sine să fie `mut`, deci returnăm singura referință posibilă la datele interioare.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Returnează o referință mutabilă în `Arc` dat, fără nicio verificare.
    ///
    /// A se vedea, de asemenea, [`get_mut`], care este sigur și efectuează verificări adecvate.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Orice alți indicatori `Arc` sau [`Weak`] către aceeași alocare nu trebuie derecați pe durata împrumutului returnat.
    ///
    /// Acest lucru este banal dacă nu există astfel de indicatori, de exemplu imediat după `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Avem grijă să *nu* creăm o referință care să acopere câmpurile "count", deoarece acest lucru ar fi un alias cu acces simultan la numărul de referințe (de ex.
        // de `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determinați dacă aceasta este referința unică (inclusiv referințele slabe) la datele subiacente.
    ///
    ///
    /// Rețineți că acest lucru necesită blocarea numărului redus de ref.
    fn is_unique(&mut self) -> bool {
        // blocați numărul indicatorului slab dacă parem a fi singurul suport pentru indicatorul slab.
        //
        // Eticheta de achiziție de aici asigură o relație care se întâmplă înainte de orice scrieri pe `strong` (în special în `Weak::upgrade`) înainte de scăderea numărului `weak` (prin `Weak::drop`, care utilizează versiunea).
        // Dacă refuzul slab actualizat nu a fost renunțat niciodată, CAS nu va reuși, așa că nu ne interesează sincronizarea.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Acesta trebuie să fie un `Acquire` pentru a se sincroniza cu scăderea contorului `strong` din `drop`-singurul acces care se întâmplă atunci când se renunță la orice referință în afară de ultima.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Versiunea de scriere aici se sincronizează cu o citire în `downgrade`, împiedicând efectiv citirea de mai sus a `strong` să se întâmple după scriere.
            //
            //
            self.inner().weak.store(1, Release); // eliberați încuietoarea
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Renunță la `Arc`.
    ///
    /// Acest lucru va scădea numărul de referințe puternic.
    /// Dacă numărul de referințe puternice ajunge la zero, atunci singurele alte referințe (dacă există) sunt [`Weak`], deci `drop` valoarea interioară.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Nu tipărește nimic
    /// drop(foo2);   // Tipărește "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Deoarece `fetch_sub` este deja atomic, nu trebuie să ne sincronizăm cu alte fire decât dacă vom șterge obiectul.
        // Aceeași logică se aplică pentru `fetch_sub` de mai jos la numărul `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Acest gard este necesar pentru a preveni reordonarea utilizării datelor și ștergerea datelor.
        // Deoarece este marcat `Release`, scăderea numărului de referință se sincronizează cu acest gard `Acquire`.
        // Aceasta înseamnă că utilizarea datelor are loc înainte de scăderea numărului de referințe, ceea ce se întâmplă înainte de acest gard, care se întâmplă înainte de ștergerea datelor.
        //
        // După cum sa explicat în [Boost documentation][1],
        //
        // > Este important să se impună orice posibil acces la obiect într-unul
        // > fir (printr-o referință existentă) pentru a *se întâmpla înainte de* ștergere
        // > obiectul într-un alt fir.Acest lucru este realizat de un "release"
        // > operație după renunțarea la o referință (orice acces la obiect
        // > prin această referință trebuie să se întâmple în mod evident înainte), și un
        // > "acquire" operație înainte de ștergerea obiectului.
        //
        // În special, în timp ce conținutul unui arc este de obicei imuabil, este posibil să aveți scrieri interioare la ceva de genul unui Mutex<T>.
        // Deoarece un Mutex nu este dobândit atunci când este șters, nu ne putem baza pe logica sa de sincronizare pentru a face vizibile scrierile din firul A pentru un destructor care rulează în firul B.
        //
        //
        // De asemenea, rețineți că gardul Achiziție de aici ar putea fi probabil înlocuit cu o sarcină Achiziție, care ar putea îmbunătăți performanța în situații extrem de susținute.Vezi [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Încercați să descărcați `Arc<dyn Any + Send + Sync>` într-un tip concret.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Construiește un nou `Weak<T>`, fără a aloca nicio memorie.
    /// Apelarea [`upgrade`] la valoarea returnată dă întotdeauna [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tipul de ajutor pentru a permite accesarea numărului de referințe fără a face nicio afirmație despre câmpul de date.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Returnează un indicator brut la obiectul `T` la care se referă acest `Weak<T>`.
    ///
    /// Pointerul este valid numai dacă există câteva referințe puternice.
    /// Pointerul poate fi suspendat, nealiniat sau chiar [`null`] în caz contrar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ambele indică același obiect
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Cel puternic de aici îl menține în viață, astfel încât să putem accesa obiectul.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Dar nu mai.
    /// // Putem face weak.as_ptr(), dar accesarea indicatorului ar duce la un comportament nedefinit.
    /// // assert_eq! ("salut", nesigur {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Dacă indicatorul atârnă, returnăm santinela direct.
            // Aceasta nu poate fi o adresă validă a încărcăturii utile, deoarece sarcina utilă este cel puțin la fel de aliniată ca ArcInner (usize).
            ptr as *const T
        } else {
            // SIGURANȚĂ: dacă is_dangling returnează false, atunci indicatorul este dereferențial.
            // Sarcina utilă poate fi scăzută în acest moment și trebuie să menținem proveniența, așa că folosiți manipularea indicatorului brut.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consumă `Weak<T>` și îl transformă într-un indicator brut.
    ///
    /// Aceasta convertește indicatorul slab într-un indicator brut, păstrând totuși proprietatea unei referințe slabe (numărul slab nu este modificat de această operație).
    /// Poate fi transformat înapoi în `Weak<T>` cu [`from_raw`].
    ///
    /// Se aplică aceleași restricții privind accesarea țintei indicatorului ca și în cazul [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Convertește un pointer brut creat anterior de [`into_raw`] în `Weak<T>`.
    ///
    /// Aceasta poate fi utilizată pentru a obține în siguranță o referință puternică (apelând [`upgrade`] mai târziu) sau pentru a aloca numărul scăzut prin renunțarea la `Weak<T>`.
    ///
    /// Preluează o referință slabă (cu excepția indicatorilor creați de [`new`], deoarece aceștia nu dețin nimic; metoda funcționează în continuare pe ei).
    ///
    /// # Safety
    ///
    /// Pointerul trebuie să fi provenit de la [`into_raw`] și trebuie să dețină în continuare potențialul său punct de referință slab.
    ///
    /// Este permis ca numărul puternic să fie 0 la momentul apelării.
    /// Cu toate acestea, acest lucru își asumă proprietatea unei referințe slabe reprezentate în prezent ca un pointer brut (numărul slab nu este modificat de această operațiune) și, prin urmare, trebuie asociat cu un apel anterior către [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Reduceți ultimul număr slab.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Consultați Weak::as_ptr pentru contextul despre modul în care este derivat indicatorul de intrare.

        let ptr = if is_dangling(ptr as *mut T) {
            // Acesta este un punct slab.
            ptr as *mut ArcInner<T>
        } else {
            // În caz contrar, avem garanția că indicatorul a venit dintr-un punct slab nedumeritor.
            // SIGURANȚĂ: data_offset este sigur de apelat, deoarece ptr face referire la un real (potențial abandonat) T.
            let offset = unsafe { data_offset(ptr) };
            // Astfel, inversăm offsetul pentru a obține întregul RcBox.
            // SIGURANȚĂ: indicatorul provine dintr-un punct slab, deci acest decalaj este sigur.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIGURANȚĂ: acum am recuperat indicatorul Weak original, deci putem crea Weak.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Încearcă să actualizezi indicatorul `Weak` la un [`Arc`], amânând scăderea valorii interioare dacă reușește.
    ///
    ///
    /// Returnează [`None`] dacă valoarea interioară a fost scăzută de atunci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Distrugeți toate indicațiile puternice.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Folosim o buclă CAS pentru a crește numărul puternic în loc de fetch_add, deoarece această funcție nu ar trebui să ia niciodată numărul de referință de la zero la unu.
        //
        //
        let inner = self.inner()?;

        // Sarcină relaxată, deoarece orice scriere de 0 pe care o putem observa lasă câmpul într-o stare permanent zero (deci o citire "stale" de 0 este bună), iar orice altă valoare este confirmată prin CAS de mai jos.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Vedeți comentariile din `Arc::clone` pentru a afla de ce facem acest lucru (pentru `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxat este bine pentru cazul eșecului, deoarece nu avem nicio așteptare cu privire la noul stat.
            // Achiziția este necesară pentru ca cazul de succes să se sincronizeze cu `Arc::new_cyclic`, când valoarea interioară poate fi inițializată după ce au fost deja create referințe `Weak`.
            // În acest caz, ne așteptăm să observăm valoarea inițializată complet.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nul verificat mai sus
                Err(old) => n = old,
            }
        }
    }

    /// Obține numărul de indicatori puternici (`Arc`) care indică această alocare.
    ///
    /// Dacă `self` a fost creat folosind [`Weak::new`], acesta va întoarce 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Obține o aproximare a numărului de indicatori `Weak` care indică această alocare.
    ///
    /// Dacă `self` a fost creat folosind [`Weak::new`] sau dacă nu mai sunt indicatori puternici rămași, acesta va întoarce 0.
    ///
    /// # Accuracy
    ///
    /// Datorită detaliilor de implementare, valoarea returnată poate fi oprită cu 1 în ambele direcții atunci când alte fire manipulează orice " Arc`sau " Slab` care indică aceeași alocare.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Deoarece am observat că a existat cel puțin un indicator puternic după citirea numărului slab, știm că referința slabă implicită (prezentă ori de câte ori există vreo referință puternică) era încă în jur când am observat numărul slab și, prin urmare, o putem scădea în siguranță.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Returnează `None` atunci când indicatorul este suspendat și nu există niciun `ArcInner` alocat, (de exemplu, atunci când acest `Weak` a fost creat de `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Avem grijă să *nu* creăm o referință care să acopere câmpul "data", deoarece câmpul poate fi mutat concomitent (de exemplu, dacă ultimul `Arc` este abandonat, câmpul de date va fi lăsat în loc).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returnează `true` dacă cele două " Slabe` indică aceeași alocare (similară cu [`ptr::eq`]) sau dacă ambele nu indică nicio alocare (deoarece au fost create cu `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Deoarece acest lucru compară indicii, înseamnă că `Weak::new()` se va egala unul cu celălalt, chiar dacă nu indică nicio alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparând `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Face o clonă a indicatorului `Weak` care indică aceeași alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vedeți comentariile din Arc::clone() pentru a afla de ce este relaxat.
        // Acest lucru poate utiliza un fetch_add (ignorând blocarea), deoarece numărul slab este blocat numai acolo unde nu există *alți* indicatori slabi.
        //
        // (Deci, nu putem rula acest cod în acest caz).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Vedeți comentariile din Arc::clone() pentru a afla de ce facem acest lucru (pentru mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construiește un nou `Weak<T>`, fără a aloca memorie.
    /// Apelarea [`upgrade`] la valoarea returnată dă întotdeauna [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Renunță la indicatorul `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nu tipărește nimic
    /// drop(foo);        // Tipărește "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Dacă aflăm că am fost ultimul indicator slab, atunci este timpul să alocăm datele în întregime.Vedeți discuția din Arc::drop() despre ordinea memoriei
        //
        // Nu este necesar să verificați starea blocată aici, deoarece numărul slab poate fi blocat numai dacă a existat exact o referință slabă, ceea ce înseamnă că picătura ar putea rula ulterior doar pe ref-ul slab rămas, care se poate întâmpla numai după ce blocarea este eliberată.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Facem această specializare aici și nu ca o optimizare mai generală pe `&T`, deoarece altfel ar adăuga un cost tuturor verificărilor de egalitate la referințe.
/// Presupunem că " Arc`-urile sunt folosite pentru a stoca valori mari, care sunt lent de clonat, dar și greu de verificat pentru egalitate, ceea ce face ca acest cost să se plătească mai ușor.
///
/// De asemenea, este mai probabil să aveți două clone `Arc`, care indică aceeași valoare, decât două `&T`s.
///
/// Putem face acest lucru numai atunci când `T: Eq` ca `PartialEq` ar putea fi deliberat ireflexiv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Egalitate pentru doi `Arc`s.
    ///
    /// Două arcuri sunt egale dacă valorile lor interioare sunt egale, chiar dacă sunt stocate într-o alocare diferită.
    ///
    /// Dacă `T` implementează și `Eq` (implicând reflexivitate de egalitate), două `Arc` care indică aceeași alocare sunt întotdeauna egale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Inegalitate pentru doi `Arc`s.
    ///
    /// Două " arcuri` sunt inegale dacă valorile lor interioare sunt inegale.
    ///
    /// Dacă `T` implementează și `Eq` (care implică reflexivitatea egalității), doi `Arc`s care indică aceeași valoare nu sunt niciodată inegali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Comparație parțială pentru două `Arc`s.
    ///
    /// Cele două sunt comparate apelând `partial_cmp()` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparație mai mică decât pentru două `Arc`s.
    ///
    /// Cele două sunt comparate apelând `<` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Comparație " mai mică sau egală cu`pentru două " Arc`.
    ///
    /// Cele două sunt comparate apelând `<=` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// O comparație mai mare decât cea a două `Arc`s.
    ///
    /// Cele două sunt comparate apelând `>` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Comparație " mai mare sau egală cu`pentru două " Arc`.
    ///
    /// Cele două sunt comparate apelând `>=` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparație pentru două `Arc`s.
    ///
    /// Cele două sunt comparate apelând `cmp()` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Creează un nou `Arc<T>`, cu valoarea `Default` pentru `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Alocați o felie cu număr de referință și umpleți-o prin clonarea articolelor `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Alocați un `str` numărat cu referințe și copiați `v` în el.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Alocați un `str` numărat cu referințe și copiați `v` în el.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Mutați un obiect în cutie la o alocare nouă, numărată de referințe.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Alocați o felie numărată de referințe și mutați elementele `v` în ea.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Permiteți Vec să-și elibereze memoria, dar să nu-i distrugă conținutul
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Preia fiecare element din `Iterator` și îl colectează într-un `Arc<[T]>`.
    ///
    /// # Caracteristici de performanta
    ///
    /// ## Cazul general
    ///
    /// În cazul general, colectarea în `Arc<[T]>` se face prin colectarea mai întâi într-un `Vec<T>`.Adică, atunci când scrieți următoarele:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// acest lucru se comportă de parcă am scrie:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Primul set de alocări are loc aici.
    ///     .into(); // A doua alocare pentru `Arc<[T]>` se întâmplă aici.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Aceasta va aloca de câte ori este nevoie pentru construirea `Vec<T>` și apoi va aloca o dată pentru transformarea `Vec<T>` în `Arc<[T]>`.
    ///
    ///
    /// ## Iteratori de lungime cunoscută
    ///
    /// Când `Iterator` dvs. implementează `TrustedLen` și are o dimensiune exactă, se va face o singură alocare pentru `Arc<[T]>`.De exemplu:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Aici se întâmplă doar o singură alocare.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializarea trait utilizată pentru colectarea în `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Acesta este cazul unui iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIGURANȚĂ: Trebuie să ne asigurăm că iteratorul are o lungime exactă și o avem.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Reveniți la implementarea normală.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Obțineți offsetul într-un `ArcInner` pentru sarcina utilă din spatele unui indicator.
///
/// # Safety
///
/// Pointerul trebuie să indice (și să aibă metadate valide pentru) o instanță validă anterior a lui T, dar T este permis să fie abandonat.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Aliniați valoarea nedimensionată la capătul ArcInner.
    // Deoarece RcBox este repr(C), va fi întotdeauna ultimul câmp din memorie.
    // SIGURANȚĂ: deoarece singurele tipuri nedimensionate posibile sunt felii, obiecte trait,
    // și tipuri externe, cerința de siguranță a intrării este în prezent suficientă pentru a satisface cerințele alin_of_val_raw;acesta este un detaliu de implementare a limbajului pe care este posibil să nu se bazeze pe std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}