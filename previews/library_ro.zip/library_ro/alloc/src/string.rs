//! Un șir cultivabil codificat UTF-8.
//!
//! Acest modul conține tipul [`String`], [`ToString`] trait pentru conversia în șiruri și mai multe tipuri de erori care pot rezulta din lucrul cu [" Șiruri`].
//!
//!
//! # Examples
//!
//! Există mai multe moduri de a crea un nou [`String`] dintr-un șir literal:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Puteți crea un nou [`String`] dintr-unul existent concatenând cu
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Dacă aveți un vector de octeți UTF-8 valabili, puteți crea un [`String`] din acesta.Puteți face și invers.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Știm că acești octeți sunt valabili, așa că vom folosi `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Un șir cultivabil codificat UTF-8.
///
/// Tipul `String` este cel mai comun tip de șir care deține proprietatea asupra conținutului șirului.Are o relație strânsă cu omologul său împrumutat, [`str`] primitiv.
///
/// # Examples
///
/// Puteți crea un `String` din [a literal string][`str`] cu [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Puteți adăuga un [`char`] la un `String` cu metoda [`push`] și puteți adăuga un [`&str`] cu metoda [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Dacă aveți un vector de octeți UTF-8, puteți crea un `String` din acesta cu metoda [`from_utf8`]:
///
/// ```
/// // unii octeți, într-un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Știm că acești octeți sunt valabili, așa că vom folosi `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// " Șirurile` sunt întotdeauna valabile UTF-8.Acest lucru are câteva implicații, dintre care primul este că, dacă aveți nevoie de un șir non-UTF-8, luați în considerare [`OsString`].Este similar, dar fără constrângerea UTF-8.A doua implicație este că nu puteți indexa într-un `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexarea se dorește a fi o operație în timp constant, dar codificarea UTF-8 nu ne permite să facem acest lucru.Mai mult decât atât, nu este clar ce fel de lucruri ar trebui să returneze indexul: un octet, un punct de cod sau un cluster grafem.
/// Metodele [`bytes`] și [`chars`] returnează iteratorii în primele două, respectiv.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implement [`Deref`] `<Target=str>`, și astfel moștenesc toate metodele lui [`str`].În plus, aceasta înseamnă că puteți transmite un `String` la o funcție care ia un [`&str`] utilizând un ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Aceasta va crea un [`&str`] din `String` și îl va transmite. Această conversie este foarte ieftină și, în general, funcțiile vor accepta [`&str`] ca argumente, cu excepția cazului în care au nevoie de un `String` din anumite motive.
///
/// În anumite cazuri, Rust nu are suficiente informații pentru a face această conversie, cunoscută sub numele de coerciție [`Deref`].În exemplul următor, o secțiune de șir [`&'a str`][`&str`] implementează trait `TraitExample`, iar funcția `example_func` ia tot ceea ce implementează trait.
/// În acest caz, Rust ar trebui să facă două conversii implicite, pe care Rust nu le are mijloacele necesare.
/// Din acest motiv, următorul exemplu nu se va compila.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Există două opțiuni care ar funcționa în schimb.Prima ar fi schimbarea liniei `example_func(&example_string);` la `example_func(example_string.as_str());`, folosind metoda [`as_str()`] pentru a extrage explicit felia de șir care conține șirul.
/// A doua cale schimbă `example_func(&example_string);` în `example_func(&*example_string);`.
/// În acest caz, ne referim un `String` la un [`str`][`&str`], apoi referim [`str`][`&str`] la [`&str`].
/// A doua cale este mai idiomatică, cu toate acestea, ambele funcționează pentru a face conversia în mod explicit, mai degrabă decât să se bazeze pe conversia implicită.
///
/// # Representation
///
/// Un `String` este alcătuit din trei componente: un pointer către unii octeți, o lungime și o capacitate.Pointerul indică un tampon intern pe care `String` îl folosește pentru a-și stoca datele.Lungimea este numărul de octeți stocați în prezent în buffer, iar capacitatea este dimensiunea bufferului în octeți.
///
/// Ca atare, lungimea va fi întotdeauna mai mică sau egală cu capacitatea.
///
/// Acest buffer este întotdeauna stocat pe heap.
///
/// Vă puteți uita la acestea cu metodele [`as_ptr`], [`len`] și [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Actualizați acest lucru când vec_into_raw_parts este stabilizat.
/// // Preveniți căderea automată a datelor șirului
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // povestea are nouăsprezece octeți
/// assert_eq!(19, len);
///
/// // Putem reconstrui un șir din ptr, len și capacitate.
/// // Toate acestea sunt nesigure, deoarece suntem responsabili să ne asigurăm că componentele sunt valide:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Dacă un `String` are suficientă capacitate, adăugarea de elemente la acesta nu se va aloca din nou.De exemplu, luați în considerare acest program:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Aceasta va genera următoarele:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// La început, nu avem deloc memorie alocată, dar pe măsură ce adăugăm șirul, acesta își mărește capacitatea în mod corespunzător.Dacă folosim în schimb metoda [`with_capacity`] pentru a aloca capacitatea corectă inițial:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Ajungem cu o ieșire diferită:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Aici, nu este nevoie să alocați mai multă memorie în interiorul buclei.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// O posibilă valoare de eroare la conversia unui `String` dintr-un octet UTF-8 vector.
///
/// Acest tip este tipul de eroare pentru metoda [`from_utf8`] pe [`String`].
/// Este conceput în așa fel încât să evite cu atenție realocările: metoda [`into_bytes`] va reda octetul vector care a fost utilizat în încercarea de conversie.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Tipul [`Utf8Error`] furnizat de [`std::str`] reprezintă o eroare care poate apărea la conversia unei felii de [`u8`] s la un [`&str`].
/// În acest sens, este un analog cu `FromUtf8Error` și puteți obține unul de la un `FromUtf8Error` prin metoda [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// // niște octeți invalizi, într-un vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// O posibilă valoare de eroare la conversia unui `String` dintr-o porțiune de octeți UTF-16.
///
/// Acest tip este tipul de eroare pentru metoda [`from_utf16`] pe [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Creează un nou `String` gol.
    ///
    /// Având în vedere că `String` este gol, acest lucru nu va aloca niciun tampon inițial.Deși asta înseamnă că această operațiune inițială este foarte ieftină, poate cauza alocarea excesivă mai târziu atunci când adăugați date.
    ///
    /// Dacă aveți o idee despre cât de multe date va deține `String`, luați în considerare metoda [`with_capacity`] pentru a preveni realocarea excesivă.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Creează un nou `String` gol cu o anumită capacitate.
    ///
    /// " Șirurile` au un tampon intern pentru a-și păstra datele.
    /// Capacitatea este lungimea acestui tampon și poate fi interogată cu metoda [`capacity`].
    /// Această metodă creează un `String` gol, dar unul cu un buffer inițial care poate conține `capacity` octeți.
    /// Acest lucru este util atunci când este posibil să adăugați o grămadă de date la `String`, reducând numărul de realocări pe care trebuie să le facă.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Dacă capacitatea dată este `0`, nu va avea loc nicio alocare, iar această metodă este identică cu metoda [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Șirul nu conține caractere, chiar dacă are capacitate pentru mai multe
    /// assert_eq!(s.len(), 0);
    ///
    /// // Toate acestea se fac fără realocare ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... dar acest lucru poate face ca șirul să fie realocat
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cu cfg(test) metoda `[T]::to_vec` inerentă, care este necesară pentru această definiție a metodei, nu este disponibilă.
    // Deoarece nu avem nevoie de această metodă în scopuri de testare, o voi înțelege. NB consultați modulul slice::hack în slice.rs pentru mai multe informații
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Convertește un vector de octeți într-un `String`.
    ///
    /// Un șir ([`String`]) este format din octeți ([`u8`]), iar un vector de octeți ([`Vec<u8>`]) este format din octeți, deci această funcție convertește între cele două.
    /// Nu toate secțiunile de octeți sunt valabile `String`s, totuși: `String` necesită ca acesta să fie UTF-8 valid.
    /// `from_utf8()` verifică pentru a se asigura că octeții sunt valizi UTF-8 și apoi efectuează conversia.
    ///
    /// Dacă sunteți sigur că felia de octeți este UTF-8 validă și nu doriți să suportați cheltuielile generale ale verificării de validitate, există o versiune nesigură a acestei funcții, [`from_utf8_unchecked`], care are același comportament, dar omite verificarea.
    ///
    ///
    /// Această metodă va avea grijă să nu copiați vector, din motive de eficiență.
    ///
    /// Dacă aveți nevoie de un [`&str`] în loc de un `String`, luați în considerare [`str::from_utf8`].
    ///
    /// Inversul acestei metode este [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Returnează [`Err`] dacă felia nu este UTF-8 cu o descriere a motivului pentru care octeții furnizați nu sunt UTF-8.vector în care v-ați mutat este, de asemenea, inclus.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // unii octeți, într-un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Știm că acești octeți sunt valabili, așa că vom folosi `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Octet incorect:
    ///
    /// ```
    /// // niște octeți invalizi, într-un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Consultați documentele pentru [`FromUtf8Error`] pentru mai multe detalii despre ce puteți face cu această eroare.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Convertește o felie de octeți într-un șir, inclusiv caractere nevalide.
    ///
    /// Șirurile sunt formate din octeți ([`u8`]), iar o porțiune de octeți ([`&[u8]`][byteslice]) este formată din octeți, astfel încât această funcție convertește între cele două.Cu toate acestea, nu toate secțiunile de octeți sunt șiruri valide: șirurile trebuie să fie UTF-8 valide.
    /// În timpul acestei conversii, `from_utf8_lossy()` va înlocui orice secvență UTF-8 nevalidă cu [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], care arată astfel:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Dacă sunteți sigur că porțiunea de octeți este UTF-8 validă și nu doriți să suportați cheltuielile generale ale conversiei, există o versiune nesigură a acestei funcții, [`from_utf8_unchecked`], care are același comportament, dar omite verificările.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Această funcție returnează un [`Cow<'a, str>`].Dacă felia noastră de octeți este invalidă UTF-8, atunci trebuie să inserăm caracterele de înlocuire, care vor schimba dimensiunea șirului și, prin urmare, vor necesita un `String`.
    /// Dar dacă este deja valabil UTF-8, nu avem nevoie de o nouă alocare.
    /// Acest tip de returnare ne permite să gestionăm ambele cazuri.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // unii octeți, într-un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Octet incorect:
    ///
    /// ```
    /// // niște octeți nevalizi
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Decodează un vector `v` codificat UTF-16 într-un `String`, returnând [`Err`] dacă `v` conține date nevalide.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Acest lucru nu se face prin colectare: : <Result<_, _>> () din motive de performanță.
        // FIXME: funcția poate fi simplificată din nou când #48994 este închis.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decodează o secțiune codificată UTF-16 `v` într-un `String`, înlocuind datele nevalide cu [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Spre deosebire de [`from_utf8_lossy`] care returnează un [`Cow<'a, str>`], `from_utf16_lossy` returnează un `String`, deoarece conversia UTF-16 în UTF-8 necesită o alocare de memorie.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Descompune un `String` în componentele sale brute.
    ///
    /// Returnează indicatorul brut la datele subiacente, lungimea șirului (în octeți) și capacitatea alocată a datelor (în octeți).
    /// Acestea sunt aceleași argumente în aceeași ordine ca argumentele pentru [`from_raw_parts`].
    ///
    /// După apelarea acestei funcții, apelantul este responsabil pentru memoria gestionată anterior de `String`.
    /// Singura modalitate de a face acest lucru este de a converti înapoi indicatorul brut, lungimea și capacitatea într-un `String` cu funcția [`from_raw_parts`], permițând distructorului să efectueze curățarea.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Creează un nou `String` dintr-o lungime, capacitate și pointer.
    ///
    /// # Safety
    ///
    /// Acest lucru este extrem de nesigur, datorită numărului de invarianți care nu sunt verificați:
    ///
    /// * Memoria de la `buf` trebuie să fi fost alocată anterior de același alocator pe care îl folosește biblioteca standard, cu o aliniere necesară de exact 1.
    /// * `length` trebuie să fie mai mic sau egal cu `capacity`.
    /// * `capacity` trebuie să fie valoarea corectă.
    /// * Primii octeți `length` la `buf` trebuie să fie UTF-8 valid.
    ///
    /// Încălcarea acestora poate cauza probleme precum coruperea structurilor de date interne ale alocatorului.
    ///
    /// Proprietatea asupra `buf` este transferată efectiv către `String`, care poate apoi să aloce, să realoce sau să schimbe conținutul memoriei indicat de pointer după bunul plac.
    /// Asigurați-vă că nimic altceva nu folosește indicatorul după ce ați apelat această funcție.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Actualizați acest lucru când vec_into_raw_parts este stabilizat.
    ///     // Preveniți căderea automată a datelor șirului
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Convertește un vector de octeți într-un `String` fără a verifica dacă șirul conține UTF-8 valid.
    ///
    /// Consultați versiunea sigură, [`from_utf8`], pentru mai multe detalii.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Această funcție nu este sigură, deoarece nu verifică dacă octeții care i-au fost trecuți sunt valabili UTF-8.
    /// Dacă această constrângere este încălcată, aceasta poate cauza probleme de securitate a memoriei cu utilizatorii future ai `String`, deoarece restul bibliotecii standard presupune că " Șirurile` sunt UTF-8 valide.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // unii octeți, într-un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Convertește un `String` într-un octet vector.
    ///
    /// Acest lucru consumă `String`, deci nu este nevoie să îi copiem conținutul.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extrage o felie de șir care conține întregul `String`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Convertește un `String` într-o felie de șir modificabilă.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Adaugă o felie de șir dată la sfârșitul acestui `String`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Returnează capacitatea acestui " șir`, în octeți.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Asigură că capacitatea acestui " șir` este de cel puțin `additional` octeți mai mare decât lungimea sa.
    ///
    /// Capacitatea poate fi mărită cu mai mult de `additional` octeți dacă alege, pentru a preveni realocările frecvente.
    ///
    ///
    /// Dacă nu doriți acest comportament "at least", consultați metoda [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics dacă noua capacitate depășește [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Acest lucru nu poate crește efectiv capacitatea:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s are acum o lungime de 2 și o capacitate de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Deoarece avem deja o capacitate suplimentară de 8, apelăm la acest ...
    /// s.reserve(8);
    ///
    /// // ... de fapt nu crește.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Asigură că capacitatea acestui " șir` este `additional` octeți mai mare decât lungimea sa.
    ///
    /// Luați în considerare utilizarea metodei [`reserve`], cu excepția cazului în care știți absolut mai bine decât alocatorul.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics dacă noua capacitate depășește `usize`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Acest lucru nu poate crește efectiv capacitatea:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s are acum o lungime de 2 și o capacitate de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Deoarece avem deja o capacitate suplimentară de 8, apelăm la acest ...
    /// s.reserve_exact(8);
    ///
    /// // ... de fapt nu crește.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Încearcă să rezerve capacitatea pentru cel puțin `additional` mai multe elemente care urmează să fie inserate în `String` dat.
    /// Colecția poate rezerva mai mult spațiu pentru a evita realocările frecvente.
    /// După apelarea `reserve`, capacitatea va fi mai mare sau egală cu `self.len() + additional`.
    /// Nu face nimic dacă capacitatea este deja suficientă.
    ///
    /// # Errors
    ///
    /// Dacă capacitatea depășește sau alocatorul raportează o eroare, atunci se returnează o eroare.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Rezervați în prealabil memoria, ieșind dacă nu putem
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Acum știm că acest lucru nu poate OOM în mijlocul muncii noastre complexe
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Încearcă să rezerve capacitatea minimă pentru mai multe elemente `additional` care urmează să fie inserate în `String` dat.
    ///
    /// După apelarea `reserve_exact`, capacitatea va fi mai mare sau egală cu `self.len() + additional`.
    /// Nu face nimic dacă capacitatea este deja suficientă.
    ///
    /// Rețineți că distribuitorul poate oferi colecției mai mult spațiu decât solicită.
    /// Prin urmare, capacitatea nu poate fi invocată pentru a fi precis minimă.
    /// Preferă `reserve` dacă se așteaptă inserții future.
    ///
    /// # Errors
    ///
    /// Dacă capacitatea depășește sau alocatorul raportează o eroare, atunci se returnează o eroare.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Rezervați în prealabil memoria, ieșind dacă nu putem
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Acum știm că acest lucru nu poate OOM în mijlocul muncii noastre complexe
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Micșorează capacitatea acestui `String` de a se potrivi cu lungimea sa.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Reduce capacitatea acestui `String` cu o limită inferioară.
    ///
    /// Capacitatea va rămâne cel puțin la fel de mare ca lungimea și valoarea furnizată.
    ///
    ///
    /// Dacă capacitatea curentă este mai mică decât limita inferioară, aceasta este o opțiune fără opțiuni.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Adaugă [`char`] dat la sfârșitul acestui `String`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Returnează o porțiune de octeți din conținutul acestui " șir`.
    ///
    /// Inversul acestei metode este [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Scurtați acest `String` la lungimea specificată.
    ///
    /// Dacă `new_len` este mai mare decât lungimea curentă a șirului, acest lucru nu are efect.
    ///
    ///
    /// Rețineți că această metodă nu are niciun efect asupra capacității alocate a șirului
    ///
    /// # Panics
    ///
    /// Panics dacă `new_len` nu se află pe o limită [`char`].
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Elimină ultimul caracter din buffer-ul șirului și îl returnează.
    ///
    /// Returnează [`None`] dacă acest `String` este gol.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Elimină un [`char`] din acest `String` într-o poziție de octet și îl returnează.
    ///
    /// Aceasta este o operațiune *O*(*n*), deoarece necesită copierea fiecărui element din buffer.
    ///
    /// # Panics
    ///
    /// Panics dacă `idx` este mai mare sau egală cu lungimea " șirului` sau dacă nu se află pe o limită [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Eliminați toate potrivirile modelului `pat` din `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Meciurile vor fi detectate și eliminate în mod iterativ, deci în cazurile în care modelele se suprapun, doar primul model va fi eliminat:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SIGURANȚĂ: începutul și sfârșitul vor fi pe limitele de octeți utf8 per
        // documentele Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Păstrează numai caracterele specificate de predicat.
    ///
    /// Cu alte cuvinte, eliminați toate caracterele `c` astfel încât `f(c)` să returneze `false`.
    /// Această metodă funcționează în loc, vizitând fiecare personaj exact o dată în ordinea originală și păstrează ordinea caracterelor reținute.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Ordinea exactă poate fi utilă pentru urmărirea stării externe, cum ar fi un index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Indicați idx către următorul caracter
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Inserează un caracter în acest `String` într-o poziție de octet.
    ///
    /// Aceasta este o operațiune *O*(*n*) deoarece necesită copierea fiecărui element din buffer.
    ///
    /// # Panics
    ///
    /// Panics dacă `idx` este mai mare decât lungimea " șirului` sau dacă nu se află pe o limită [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Inserează o felie de șir în acest `String` într-o poziție de octet.
    ///
    /// Aceasta este o operațiune *O*(*n*) deoarece necesită copierea fiecărui element din buffer.
    ///
    /// # Panics
    ///
    /// Panics dacă `idx` este mai mare decât lungimea " șirului` sau dacă nu se află pe o limită [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Returnează o referință mutabilă la conținutul acestui `String`.
    ///
    /// # Safety
    ///
    /// Această funcție nu este sigură, deoarece nu verifică dacă octeții care i-au fost trecuți sunt valabili UTF-8.
    /// Dacă această constrângere este încălcată, aceasta poate cauza probleme de securitate a memoriei cu utilizatorii future ai `String`, deoarece restul bibliotecii standard presupune că " Șirurile` sunt UTF-8 valide.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Returnează lungimea acestui `String`, în octeți, nu [`char`] sau grafeme.
    /// Cu alte cuvinte, este posibil să nu fie ceea ce un om consideră lungimea șirului.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Returnează `true` dacă acest `String` are o lungime zero, iar `false` în caz contrar.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Împarte șirul în două la indexul de octeți dat.
    ///
    /// Returnează un `String` nou alocat.
    /// `self` conține octeți `[0, at)`, iar `String` returnat conține octeți `[at, len)`.
    /// `at` trebuie să se afle la limita unui punct de cod UTF-8.
    ///
    /// Rețineți că capacitatea `self` nu se schimbă.
    ///
    /// # Panics
    ///
    /// Panics dacă `at` nu se află la o limită a punctului de cod `UTF-8` sau dacă este dincolo de ultimul punct de cod al șirului.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Trunchiază acest `String`, eliminând tot conținutul.
    ///
    /// Deși acest lucru înseamnă că `String` va avea o lungime de zero, nu atinge capacitatea sa.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Creează un iterator de scurgere care elimină intervalul specificat în `String` și produce `chars` eliminat.
    ///
    ///
    /// Note: Gama de elemente este eliminată chiar dacă iteratorul nu este consumat până la sfârșit.
    ///
    /// # Panics
    ///
    /// Panics dacă punctul de pornire sau punctul final nu se află pe o limită [`char`] sau dacă sunt în afara limitelor.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Eliminați gama până la β din șir
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // O gamă completă șterge șirul
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Siguranța memoriei
        //
        // Versiunea String a Drain nu are probleme de siguranță în memorie a versiunii vector.
        // Datele sunt doar octeți simpli.
        // Deoarece eliminarea intervalului are loc în Drop, dacă iteratorul Drain este scurs, eliminarea nu se va întâmpla.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Scoateți două împrumuturi simultane.
        // Șirul &mut nu va fi accesat până când nu se termină iterația, în Drop.
        let self_ptr = self as *mut _;
        // SIGURANȚĂ: `slice::range` și `is_char_boundary` efectuează verificările corespunzătoare ale limitelor.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Elimină intervalul specificat în șir și îl înlocuiește cu șirul dat.
    /// Șirul dat nu trebuie să aibă aceeași lungime ca intervalul.
    ///
    /// # Panics
    ///
    /// Panics dacă punctul de pornire sau punctul final nu se află pe o limită [`char`] sau dacă sunt în afara limitelor.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Înlocuiți gama până la β din șir
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Siguranța memoriei
        //
        // Replace_range nu are problemele de siguranță a memoriei unui vector Splice.
        // a versiunii vector.Datele sunt doar octeți simpli.

        // AVERTISMENT: înclinarea acestei variabile ar fi (#81138) neîntemeiat
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // AVERTISMENT: înclinarea acestei variabile ar fi (#81138) neîntemeiat
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Folosirea din nou a `range` ar fi nefondată (#81138) Presupunem că limitele raportate de `range` rămân aceleași, dar o implementare contradictorie s-ar putea schimba între apeluri
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Convertește acest `String` într-o [`Box`]`<`[`str`] `>`.
    ///
    /// Aceasta va scădea orice capacitate în exces.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Returnează o porțiune de [`u8`] s octeți care au fost încercate să se convertească la un `String`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // niște octeți invalizi, într-un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Returnează octeții care au fost încercați să se convertească la un `String`.
    ///
    /// Această metodă este construită cu atenție pentru a evita alocarea.
    /// Va consuma eroarea, mutând octeții, astfel încât să nu fie necesară o copie a octeților.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // niște octeți invalizi, într-un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Obțineți un `Utf8Error` pentru a obține mai multe detalii despre eșecul conversiei.
    ///
    /// Tipul [`Utf8Error`] furnizat de [`std::str`] reprezintă o eroare care poate apărea la conversia unei felii de [`u8`] s la un [`&str`].
    /// În acest sens, este un analog cu `FromUtf8Error`.
    /// Consultați documentația pentru mai multe detalii despre utilizarea acestuia.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // niște octeți invalizi, într-un vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // primul octet este invalid aici
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Deoarece vom itera peste " Șiruri`, putem evita cel puțin o alocare primind primul șir de la iterator și adăugându-i toate șirurile ulterioare.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Deoarece facem o iterație peste CoW, putem (potentially) să evităm cel puțin o alocare obținând primul articol și adăugând la acesta toate articolele ulterioare.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Un instrument de comoditate care deleagă instrumentul pentru `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Creează un `String` gol.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementează operatorul `+` pentru concatenarea a două șiruri.
///
/// Aceasta consumă `String` pe partea stângă și își folosește din nou buffer-ul (crescând-o dacă este necesar).
/// Acest lucru se face pentru a evita alocarea unui nou `String` și copierea întregului conținut pe fiecare operație, ceea ce ar duce la timpul de rulare *O*(*n*^ 2) atunci când se construiește un șir *n*-byte prin concatenare repetată.
///
///
/// Șirul din partea dreaptă este împrumutat doar;conținutul său este copiat în `String` returnat.
///
/// # Examples
///
/// Concatenarea a două " șiruri` îl ia pe primul după valoare și îl împrumută pe al doilea:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` este mutat și nu mai poate fi folosit aici.
/// ```
///
/// Dacă doriți să continuați să utilizați primul `String`, îl puteți clona și adăuga în schimb la clonă:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` este încă valabil aici.
/// ```
///
/// Concatenarea feliilor `&str` se poate face prin conversia primei în `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementează operatorul `+=` pentru atașarea la un `String`.
///
/// Acesta are același comportament ca și metoda [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Un alias de tip pentru [`Infallible`].
///
/// Acest alias există pentru compatibilitatea cu versiunile anterioare și poate fi în cele din urmă depreciat.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Un trait pentru conversia unei valori într-un `String`.
///
/// Acest trait este implementat automat pentru orice tip care implementează [`Display`] trait.
/// Ca atare, `ToString` nu ar trebui implementat direct:
/// [`Display`] ar trebui să fie implementat în schimb și veți obține implementarea `ToString` gratuit.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Convertește valoarea dată într-un `String`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// În această implementare, metoda `to_string` panics dacă implementarea `Display` returnează o eroare.
/// Aceasta indică o implementare incorectă a `Display`, deoarece `fmt::Write for String` nu returnează niciodată o eroare în sine.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // O orientare comună este de a nu include funcțiile generice.
    // Cu toate acestea, eliminarea `#[inline]` din această metodă provoacă regresii deloc neglijabile.
    // Vedeți <https://github.com/rust-lang/rust/pull/74852>, ultima încercare de a încerca să o eliminați.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Convertește un `&mut str` într-un `String`.
    ///
    /// Rezultatul este alocat pe heap.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test trage în libstd, ceea ce provoacă erori aici
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Convertește felia `str` în cutie dată într-un `String`.
    /// Este remarcabil faptul că felia `str` este deținută.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Convertește `String`-ul dat într-o felie de cutie `str` care este deținută.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Convertește o felie de șir într-o variantă împrumutată.
    /// Nu se efectuează nicio alocare de heap, iar șirul nu este copiat.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Convertește un șir într-o variantă deținută.
    /// Nu se efectuează nicio alocare de heap, iar șirul nu este copiat.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Convertește o referință String într-o variantă împrumutată.
    /// Nu se efectuează nicio alocare de heap, iar șirul nu este copiat.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Convertește `String` dat într-un vector `Vec` care deține valori de tip `u8`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Un iterator de scurgere pentru `String`.
///
/// Această structură este creată prin metoda [`drain`] pe [`String`].
/// Consultați documentația sa pentru mai multe.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Va fi folosit ca&'un șir mut în destructor
    string: *mut String,
    /// Începutul piesei de eliminat
    start: usize,
    /// Sfârșitul piesei de eliminat
    end: usize,
    /// Intervalul curent rămas de eliminat
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Folosiți Vec::drain.
            // "Reaffirm" limitele verifică pentru a evita introducerea din nou a codului panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Returnează restul (sub) șirului acestui iterator sub formă de felie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef sugerează mai jos la stabilizare.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Descomentați la stabilizarea `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>pentru Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> pentru Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}