//! Pointeri de numărare a referințelor cu un singur fir.'Rc' înseamnă " Referință
//! Counted'.
//!
//! Tipul [`Rc<T>`][`Rc`] oferă proprietatea partajată a unei valori de tip `T`, alocată în heap.
//! Invocarea [`clone`][clone] pe [`Rc`] produce un nou pointer către aceeași alocare în heap.
//! Când ultimul indicator [`Rc`] la o anumită alocare este distrus, valoarea stocată în acea alocare (denumită adesea "inner value") este, de asemenea, abandonată.
//!
//! Referințele partajate în Rust interzic mutația în mod implicit, iar [`Rc`] nu face excepție: în general nu puteți obține o referință mutabilă la ceva din interiorul unui [`Rc`].
//! Dacă aveți nevoie de mutabilitate, puneți un [`Cell`] sau [`RefCell`] în interiorul [`Rc`];vezi [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] folosește numărarea non-atomică a referințelor.
//! Aceasta înseamnă că cheltuielile generale sunt foarte mici, dar un [`Rc`] nu poate fi trimis între fire și, în consecință, [`Rc`] nu implementează [`Send`][send].
//! Ca rezultat, compilatorul Rust va verifica *la compilare* dacă nu trimiteți [`Rc`] s între fire.
//! Dacă aveți nevoie de numărare de referințe atomice cu mai multe fire, utilizați [`sync::Arc`][arc].
//!
//! Metoda [`downgrade`][downgrade] poate fi utilizată pentru a crea un pointer [`Weak`] care nu este proprietar.
//! Un indicator [`Weak`] poate fi [`upgrade`][upgrade] d la un [`Rc`], dar acesta va returna [`None`] dacă valoarea stocată în alocare a fost deja abandonată.
//! Cu alte cuvinte, pointerele `Weak` nu păstrează în valoare valoarea din alocare;cu toate acestea, ele *păstrează* alocația (magazinul de rezervă pentru valoarea interioară) în viață.
//!
//! Un ciclu între pointerele [`Rc`] nu va fi niciodată repartizat.
//! Din acest motiv, [`Weak`] este folosit pentru a întrerupe ciclurile.
//! De exemplu, un copac ar putea avea indicatori [`Rc`] puternici de la nodurile părinte la copii și indicatori [`Weak`] de la copii înapoi la părinți.
//!
//! `Rc<T>` anulează automat referințele la `T` (prin [`Deref`] trait), astfel încât să puteți apela metodele `T` pe o valoare de tip [`Rc<T>`][`Rc`].
//! Pentru a evita ciocnirile de nume cu metodele `T`, metodele [`Rc<T>`][`Rc`] în sine sunt funcții asociate, numite folosind [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Implementările lui traits precum `Clone` pot fi, de asemenea, apelate folosind o sintaxă complet calificată.
//! Unii oameni preferă să utilizeze sintaxa complet calificată, în timp ce alții preferă să utilizeze sintaxa metodă-apel.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaxă metodă-apel
//! let rc2 = rc.clone();
//! // Sintaxă complet calificată
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] nu derereferă automat la `T`, deoarece este posibil ca valoarea interioară să fi fost deja scăzută.
//!
//! # Referințe de clonare
//!
//! Crearea unei noi referințe la aceeași alocare ca un pointer contorizat cu referințe existente se face folosind `Clone` trait implementat pentru [`Rc<T>`][`Rc`] și [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Cele două sintaxi de mai jos sunt echivalente.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a și b ambele indică aceeași locație de memorie ca foo.
//! ```
//!
//! Sintaxa `Rc::clone(&from)` este cea mai idiomatică, deoarece transmite mai explicit semnificația codului.
//! În exemplul de mai sus, această sintaxă face mai ușor să vedeți că acest cod creează o nouă referință, mai degrabă decât să copieze întregul conținut al foo.
//!
//! # Examples
//!
//! Luați în considerare un scenariu în care un set de " gadget-uri` sunt deținute de un anumit `Owner`.
//! Vrem să indicăm " Gadget-ul` nostru către `Owner`.Nu putem face acest lucru cu o proprietate unică, deoarece mai multe gadgeturi pot aparține aceluiași `Owner`.
//! [`Rc`] ne permite să partajăm un `Owner` între mai multe " Gadget-uri` și să avem `Owner` să rămână alocat atâta timp cât orice punct `Gadget` se află pe acesta.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... alte domenii
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... alte domenii
//! }
//!
//! fn main() {
//!     // Creați un `Owner` cu referință.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Creați `Gadget` aparținând `gadget_owner`.
//!     // Clonarea `Rc<Owner>` ne oferă un nou indicator către aceeași alocare `Owner`, incrementând numărul de referințe în proces.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Eliminați variabila noastră locală `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // În ciuda renunțării la `gadget_owner`, putem în continuare să imprimăm numele `Owner` al " Gadgetului`.
//!     // Acest lucru se datorează faptului că am scăpat doar un singur `Rc<Owner>`, nu `Owner` la care se referă.
//!     // Atâta timp cât există alte `Rc<Owner>` care indică aceeași alocare `Owner`, acesta va rămâne activ.
//!     // Proiecția de câmp `gadget1.owner.name` funcționează deoarece `Rc<Owner>` anulează automat referințele la `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // La sfârșitul funcției, `gadget1` și `gadget2` sunt distruse, iar odată cu acestea ultimele referințe numărate la `Owner`.
//!     // Gadget Man este acum distrus și el.
//!     //
//! }
//! ```
//!
//! Dacă cerințele noastre se schimbă și trebuie, de asemenea, să putem trece de la `Owner` la `Gadget`, vom întâmpina probleme.
//! Un indicator [`Rc`] de la `Owner` la `Gadget` introduce un ciclu.
//! Aceasta înseamnă că numărul lor de referință nu poate ajunge niciodată la 0, iar alocarea nu va fi niciodată distrusă:
//! o scurgere de memorie.Pentru a evita acest lucru, putem folosi indicatoare [`Weak`].
//!
//! Rust face de fapt oarecum dificilă producerea acestei bucle în primul rând.Pentru a sfârși cu două valori care se îndreaptă una către cealaltă, una dintre ele trebuie să fie modificabilă.
//! Acest lucru este dificil, deoarece [`Rc`] impune siguranța memoriei oferind doar referințe comune la valoarea pe care o înfășoară, iar acestea nu permit mutația directă.
//! Trebuie să înfășurăm partea din valoarea pe care dorim să o mutăm într-un [`RefCell`], care oferă *mutabilitate interioară*: o metodă de realizare a mutabilității printr-o referință partajată.
//! [`RefCell`] aplică regulile de împrumut ale Rust în timpul rulării.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... alte domenii
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... alte domenii
//! }
//!
//! fn main() {
//!     // Creați un `Owner` cu referință.
//!     // Rețineți că am pus vector al " Proprietarului` gadgetului într-un `RefCell`, astfel încât să îl putem muta printr-o referință partajată.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Creați `Gadget` aparținând `gadget_owner`, ca și până acum.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Adăugați gadgetul la `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` împrumutul dinamic se termină aici.
//!     }
//!
//!     // Repetați " Gadget-ul` nostru, imprimând detaliile lor.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` este un `Weak<Gadget>`.
//!         // Deoarece pointerii `Weak` nu pot garanta că alocarea există încă, trebuie să apelăm `upgrade`, care returnează un `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // În acest caz știm că alocarea încă există, așa că pur și simplu `unwrap` `Option`.
//!         // Într-un program mai complicat, este posibil să aveți nevoie de o manipulare grațională a erorilor pentru un rezultat `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // La sfârșitul funcției, `gadget_owner`, `gadget1` și `gadget2` sunt distruse.
//!     // Acum nu există indicii (`Rc`) puternici pentru gadget-uri, așa că sunt distruse.
//!     // Acest lucru pune la zero numărul de referințe pentru Gadget Man, așa că și el este distrus.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Aceasta este rezistentă la repr(C) la future împotriva unei posibile reordonări a câmpului, care ar interfera cu [into|from]_raw() altfel sigur, de tipuri interioare transmutabile.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Un pointer de numărare a referințelor cu un singur fir.'Rc' înseamnă " Referință
/// Counted'.
///
/// Consultați [module-level documentation](./index.html) pentru mai multe detalii.
///
/// Metodele inerente ale `Rc` sunt toate funcții asociate, ceea ce înseamnă că trebuie să le apelați ca, de exemplu, [`Rc::get_mut(&mut value)`][get_mut] în loc de `value.get_mut()`.
/// Acest lucru evită conflictele cu metodele de tip interior `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Această nesiguranță este ok pentru că, în timp ce acest Rc este viu, avem garanția că indicatorul interior este valid.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Construiește un nou `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Există un indicator slab implicit deținut de toți indicatorii puternici, care asigură faptul că destructorul slab nu eliberează niciodată alocarea în timp ce distructorul puternic rulează, chiar dacă indicatorul slab este stocat în interiorul celui puternic.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Construiește un nou `Rc<T>` folosind o referință slabă la sine.
    /// Încercarea de a actualiza referința slabă înainte ca această funcție să revină va avea ca rezultat o valoare `None`.
    ///
    /// Cu toate acestea, referința slabă poate fi clonată liber și stocată pentru utilizare ulterioară.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... mai multe câmpuri
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Construiți interiorul în starea "uninitialized" cu o singură referință slabă.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Este important să nu renunțăm la proprietatea indicatorului slab, altfel memoria ar putea fi eliberată până la întoarcerea `data_fn`.
        // Dacă am dori cu adevărat să trecem drepturile de proprietate, am putea crea un indicator slab suplimentar pentru noi înșine, dar acest lucru ar duce la actualizări suplimentare ale numărului de referințe slabe, care altfel ar putea să nu fie necesar.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Referințele puternice ar trebui să dețină în mod colectiv o referință comună slabă, deci nu rulați distructorul pentru vechea noastră referință slabă.
        //
        mem::forget(weak);
        strong
    }

    /// Construiește un nou `Rc` cu conținut neinițializat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inițializare amânată:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construiește un nou `Rc` cu conținut neinițializat, memoria fiind umplută cu octeți `0`.
    ///
    ///
    /// Consultați [`MaybeUninit::zeroed`][zeroed] pentru exemple de utilizare corectă și incorectă a acestei metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construiește un nou `Rc<T>`, returnând o eroare dacă alocarea eșuează
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Există un indicator slab implicit deținut de toți indicatorii puternici, care asigură faptul că destructorul slab nu eliberează niciodată alocarea în timp ce distructorul puternic rulează, chiar dacă indicatorul slab este stocat în interiorul celui puternic.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Construiește un nou `Rc` cu conținut neinițializat, returnând o eroare dacă alocarea eșuează
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inițializare amânată:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construiește un nou `Rc` cu conținut neinițializat, memoria fiind umplută cu octeți `0`, returnând o eroare dacă alocarea eșuează
    ///
    ///
    /// Consultați [`MaybeUninit::zeroed`][zeroed] pentru exemple de utilizare corectă și incorectă a acestei metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Construiește un nou `Pin<Rc<T>>`.
    /// Dacă `T` nu implementează `Unpin`, atunci `value` va fi fixat în memorie și nu va putea fi mutat.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Returnează valoarea interioară, dacă `Rc` are exact o referință puternică.
    ///
    /// În caz contrar, un [`Err`] este returnat cu același `Rc` care a fost transmis.
    ///
    ///
    /// Acest lucru va reuși chiar dacă există referințe slabe remarcabile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copiați obiectul conținut

                // Indicați celor slabi că nu pot fi promovați prin scăderea numărului puternic, apoi eliminați indicatorul "strong weak" implicit, gestionând în același timp logica de scădere, realizând doar un fals slab.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Construiește o nouă felie de referință cu conținut neinițializat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inițializare amânată:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Construiește o nouă felie de referință cu conținut neinițializat, memoria fiind umplută cu octeți `0`.
    ///
    ///
    /// Consultați [`MaybeUninit::zeroed`][zeroed] pentru exemple de utilizare corectă și incorectă a acestei metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Convertește în `Rc<T>`.
    ///
    /// # Safety
    ///
    /// La fel ca în cazul [`MaybeUninit::assume_init`], depinde de apelant să garanteze că valoarea interioară este într-adevăr într-o stare inițializată.
    ///
    /// Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament imediat nedefinit.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inițializare amânată:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Convertește în `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// La fel ca în cazul [`MaybeUninit::assume_init`], depinde de apelant să garanteze că valoarea interioară este într-adevăr într-o stare inițializată.
    ///
    /// Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament imediat nedefinit.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inițializare amânată:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consumă `Rc`, returnând indicatorul înfășurat.
    ///
    /// Pentru a evita scurgerile de memorie, indicatorul trebuie convertit înapoi la un `Rc` folosind [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Oferă un indicator brut pentru date.
    ///
    /// Numărul nu este afectat în niciun fel, iar `Rc` nu este consumat.
    /// Indicatorul este valabil atât timp cât există un număr puternic în `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SIGURANȚĂ: Acest lucru nu poate trece prin Deref::deref sau Rc::inner deoarece
        // acest lucru este necesar pentru a păstra proveniența raw/mut astfel încât, de ex
        // `get_mut` poate scrie prin pointer după ce Rc este recuperat prin `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Construiește un `Rc<T>` dintr-un pointer brut.
    ///
    /// Pointerul brut trebuie să fi fost returnat anterior printr-un apel către [`Rc<U>::into_raw`][into_raw] unde `U` trebuie să aibă aceeași dimensiune și aliniere ca `T`.
    /// Acest lucru este trivial adevărat dacă `U` este `T`.
    /// Rețineți că dacă `U` nu este `T`, dar are aceeași dimensiune și aliniere, acesta este practic ca transmutarea referințelor de diferite tipuri.
    /// Consultați [`mem::transmute`][transmute] pentru mai multe informații despre restricțiile care se aplică în acest caz.
    ///
    /// Utilizatorul `from_raw` trebuie să se asigure că o anumită valoare `T` este scăzută o singură dată.
    ///
    /// Această funcție este nesigură, deoarece utilizarea necorespunzătoare poate duce la siguranța memoriei, chiar dacă `Rc<T>` returnat nu este accesat niciodată.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Conversia înapoi la un `Rc` pentru a preveni scurgerea.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Apelurile suplimentare către `Rc::from_raw(x_ptr)` ar fi nesigure pentru memorie.
    /// }
    ///
    /// // Memoria a fost eliberată când `x` a ieșit din sfera de aplicare de mai sus, așa că `x_ptr` este acum suspendat!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Inversați offsetul pentru a găsi RcBox-ul original.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Creează un nou indicator [`Weak`] la această alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Asigurați-vă că nu creăm un Punct Slab
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Obține numărul de indicatori [`Weak`] la această alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Obține numărul de indicatori (`Rc`) puternici pentru această alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Returnează `true` dacă nu există alți indicatori `Rc` sau [`Weak`] la această alocare.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Returnează o referință mutabilă în `Rc` dat, dacă nu există alți indicatori `Rc` sau [`Weak`] la aceeași alocare.
    ///
    ///
    /// Returnează [`None`] în caz contrar, deoarece nu este sigur să mutați o valoare partajată.
    ///
    /// A se vedea, de asemenea, [`make_mut`][make_mut], care va [`clone`][clone] valoarea interioară atunci când există alți indicatori.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Returnează o referință mutabilă în `Rc` dat, fără nicio verificare.
    ///
    /// A se vedea, de asemenea, [`get_mut`], care este sigur și efectuează verificări adecvate.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Orice alți indicatori `Rc` sau [`Weak`] către aceeași alocare nu trebuie derecați pe durata împrumutului returnat.
    ///
    /// Acest lucru este banal dacă nu există astfel de indicatori, de exemplu imediat după `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Avem grijă să *nu* creăm o referință care să acopere câmpurile "count", deoarece acest lucru ar intra în conflict cu accesurile la numărul de referințe (de ex.
        // de `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returnează `true` dacă cele două " Rc` indică aceeași alocare (într-o linie similară cu [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Face o referință mutabilă în `Rc` dat.
    ///
    /// Dacă există alți indicatori `Rc` pentru aceeași alocare, atunci `make_mut` va [`clone`] valoarea interioară pentru o nouă alocare pentru a asigura proprietatea unică.
    /// Acest lucru este, de asemenea, denumit clone-on-write.
    ///
    /// Dacă nu există alți indicatori `Rc` pentru această alocare, atunci indicatorii [`Weak`] pentru această alocare vor fi disociați.
    ///
    /// Vezi și [`get_mut`], care va eșua mai degrabă decât clonarea.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Nu va clona nimic
    /// let mut other_data = Rc::clone(&data);    // Nu va clona date interioare
    /// *Rc::make_mut(&mut data) += 1;        // Clonează date interioare
    /// *Rc::make_mut(&mut data) += 1;        // Nu va clona nimic
    /// *Rc::make_mut(&mut other_data) *= 2;  // Nu va clona nimic
    ///
    /// // Acum `data` și `other_data` indică alocări diferite.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] indicatorii vor fi disociați:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Trebuie să clonez datele, există și alte Rcs.
            // Pre-alocați memoria pentru a permite scrierea directă a valorii clonate.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Poate fura datele, tot ce a mai rămas este Slab
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Eliminați ref-ul implicit puternic-slab (nu este nevoie să creați un fals slab aici-știm că alte deficiențe pot curăța pentru noi)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Această nesiguranță este ok, deoarece avem garanția că indicatorul returnat este singurul indicator care va fi returnat vreodată lui T.
        // Numărul nostru de referințe este garantat să fie 1 în acest moment și am cerut ca `Rc<T>` în sine să fie `mut`, deci returnăm singura referință posibilă la alocare.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Încercați să descărcați `Rc<dyn Any>` într-un tip concret.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Alocă un `RcBox<T>` cu spațiu suficient pentru o valoare interioară posibil nedimensionată unde valoarea are aspectul furnizat.
    ///
    /// Funcția `mem_to_rcbox` este apelată cu indicatorul de date și trebuie să returneze înapoi un indicator (potențial gras) pentru `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calculați aspectul utilizând aspectul valorii date.
        // Anterior, aspectul a fost calculat pe expresia `&*(ptr as* const RcBox<T>)`, dar aceasta a creat o referință nealiniată (vezi #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alocă un `RcBox<T>` cu spațiu suficient pentru o valoare interioară posibil nedimensionată în care valoarea are aspectul furnizat, returnând o eroare dacă alocarea eșuează.
    ///
    ///
    /// Funcția `mem_to_rcbox` este apelată cu indicatorul de date și trebuie să returneze înapoi un indicator (potențial gras) pentru `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calculați aspectul utilizând aspectul valorii date.
        // Anterior, aspectul a fost calculat pe expresia `&*(ptr as* const RcBox<T>)`, dar aceasta a creat o referință nealiniată (vezi #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Alocați pentru aspect.
        let ptr = allocate(layout)?;

        // Inițializați RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Alocă un `RcBox<T>` cu spațiu suficient pentru o valoare interioară nedimensionată
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Alocați pentru `RcBox<T>` folosind valoarea dată.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copiați valoarea ca octeți
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Eliberați alocarea fără a renunța la conținutul acesteia
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Alocă un `RcBox<[T]>` cu lungimea dată.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copiați elementele din felie în Rc nou alocat <\[T\]>
    ///
    /// Nesigur, deoarece apelantul trebuie să fie proprietar sau să asocieze `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Construiește un `Rc<[T]>` dintr-un iterator despre care se știe că are o anumită dimensiune.
    ///
    /// Comportamentul este nedefinit dacă dimensiunea este greșită.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic protejează în timp ce clonează elemente T.
        // În cazul unui panic, elementele care au fost scrise în noul RcBox vor fi abandonate, apoi memoria va fi eliberată.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer către primul element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Totul clar.Uitați de gardă pentru a nu elibera noul RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializarea trait utilizată pentru `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Renunță la `Rc`.
    ///
    /// Acest lucru va scădea numărul de referințe puternic.
    /// Dacă numărul de referințe puternice ajunge la zero, atunci singurele alte referințe (dacă există) sunt [`Weak`], deci `drop` valoarea interioară.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Nu tipărește nimic
    /// drop(foo2);   // Tipărește "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // distruge obiectul conținut
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // eliminați indicatorul "strong weak" implicit acum că am distrus conținutul.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Face o clonă a indicatorului `Rc`.
    ///
    /// Acest lucru creează un alt indicator către aceeași alocare, mărind numărul de referințe puternic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Creează un nou `Rc<T>`, cu valoarea `Default` pentru `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack pentru a permite specializarea pe `Eq`, chiar dacă `Eq` are o metodă.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Facem această specializare aici și nu ca o optimizare mai generală pe `&T`, deoarece altfel ar adăuga un cost tuturor verificărilor de egalitate la referințe.
/// Presupunem că " Rc`-urile sunt folosite pentru a stoca valori mari, care sunt lent de clonat, dar și greu de verificat pentru egalitate, ceea ce face ca acest cost să se plătească mai ușor.
///
/// De asemenea, este mai probabil să aveți două clone `Rc`, care indică aceeași valoare, decât două `&T`s.
///
/// Putem face acest lucru numai atunci când `T: Eq` ca `PartialEq` ar putea fi deliberat ireflexiv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Egalitate pentru două `Rc`s.
    ///
    /// Două " Rc` sunt egale dacă valorile lor interioare sunt egale, chiar dacă sunt stocate într-o alocare diferită.
    ///
    /// Dacă `T` implementează și `Eq` (implicând reflexivitatea egalității), două " Rc` care indică aceeași alocare sunt întotdeauna egale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Inegalitate pentru doi `Rc`s.
    ///
    /// Două " Rc` sunt inegale dacă valorile lor interioare sunt inegale.
    ///
    /// Dacă `T` implementează și `Eq` (implicând reflexivitatea egalității), două " Rc` care indică aceeași alocare nu sunt niciodată inegale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Comparație parțială pentru două `Rc`s.
    ///
    /// Cele două sunt comparate apelând `partial_cmp()` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparație mai mică decât pentru două " Rc`.
    ///
    /// Cele două sunt comparate apelând `<` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Comparație " mai mică sau egală cu`pentru două " Rc`.
    ///
    /// Cele două sunt comparate apelând `<=` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// O comparație mai mare decât pentru două " Rc`.
    ///
    /// Cele două sunt comparate apelând `>` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Comparația " mai mare sau egală cu`pentru două " Rc`.
    ///
    /// Cele două sunt comparate apelând `>=` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparație pentru două `Rc`s.
    ///
    /// Cele două sunt comparate apelând `cmp()` la valorile lor interioare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Alocați o felie cu număr de referință și umpleți-o prin clonarea articolelor `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Alocați o felie de șir contorizată cu referințe și copiați `v` în ea.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Alocați o felie de șir contorizată cu referințe și copiați `v` în ea.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Mutați un obiect în cutie într-o alocare nouă, numărată cu referințe.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Alocați o felie numărată de referințe și mutați elementele `v` în ea.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Permiteți Vec să-și elibereze memoria, dar să nu-i distrugă conținutul
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Preia fiecare element din `Iterator` și îl colectează într-un `Rc<[T]>`.
    ///
    /// # Caracteristici de performanta
    ///
    /// ## Cazul general
    ///
    /// În cazul general, colectarea în `Rc<[T]>` se face prin colectarea mai întâi într-un `Vec<T>`.Adică, atunci când scrieți următoarele:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// acest lucru se comportă de parcă am scrie:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Primul set de alocări are loc aici.
    ///     .into(); // A doua alocare pentru `Rc<[T]>` se întâmplă aici.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Aceasta va aloca de câte ori este nevoie pentru construirea `Vec<T>` și apoi va aloca o dată pentru transformarea `Vec<T>` în `Rc<[T]>`.
    ///
    ///
    /// ## Iteratori de lungime cunoscută
    ///
    /// Când `Iterator` dvs. implementează `TrustedLen` și are o dimensiune exactă, se va face o singură alocare pentru `Rc<[T]>`.De exemplu:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Aici se întâmplă doar o singură alocare.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializarea trait utilizată pentru colectarea în `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Acesta este cazul unui iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIGURANȚĂ: Trebuie să ne asigurăm că iteratorul are o lungime exactă și o avem.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Reveniți la implementarea normală.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` este o versiune a [`Rc`] care deține o referință care nu deține proprietatea asupra alocării gestionate.Alocarea este accesată apelând [`upgrade`] pe indicatorul `Weak`, care returnează o [`Opțiune`]`<`[`Rc`] `<T>>`.
///
/// Deoarece o referință `Weak` nu este luată în considerare pentru proprietate, nu va împiedica renunțarea la valoarea stocată în alocare, iar `Weak` în sine nu oferă nicio garanție cu privire la valoarea care este încă prezentă.
/// Astfel se poate returna [`None`] când [`upgrade`] d.
/// Rețineți însă că o referință `Weak`*nu* împiedică alocarea în sine (magazinul de suport) să fie alocată.
///
/// Un indicator `Weak` este util pentru păstrarea unei referințe temporare la alocarea gestionată de [`Rc`] fără a împiedica scăderea valorii sale interne.
/// De asemenea, este utilizat pentru a preveni referințele circulare între pointerii [`Rc`], deoarece referințele reciproce nu ar permite niciodată ca niciunul dintre [`Rc`] să fie abandonat.
/// De exemplu, un copac ar putea avea indicatori [`Rc`] puternici de la nodurile părinte la copii și indicatori `Weak` de la copii înapoi la părinți.
///
/// Modul tipic de a obține un pointer `Weak` este să apelați [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Acesta este un `NonNull` pentru a permite optimizarea dimensiunii acestui tip în enumerări, dar nu este neapărat un indicator valid.
    //
    // `Weak::new` setează acest lucru la `usize::MAX` astfel încât să nu fie nevoie să aloce spațiu pe heap.
    // Aceasta nu este o valoare pe care un pointer real o va avea vreodată, deoarece RcBox are alinierea cel puțin 2.
    // Acest lucru este posibil doar când `T: Sized`;`T` unsized nu atârnă niciodată.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Construiește un nou `Weak<T>`, fără a aloca nicio memorie.
    /// Apelarea [`upgrade`] la valoarea returnată dă întotdeauna [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tipul de ajutor pentru a permite accesarea numărului de referințe fără a face nicio afirmație despre câmpul de date.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Returnează un indicator brut la obiectul `T` la care se referă acest `Weak<T>`.
    ///
    /// Pointerul este valid numai dacă există câteva referințe puternice.
    /// Pointerul poate fi suspendat, nealiniat sau chiar [`null`] în caz contrar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ambele indică același obiect
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Cel puternic de aici îl menține în viață, astfel încât să putem accesa obiectul.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Dar nu mai.
    /// // Putem face weak.as_ptr(), dar accesarea indicatorului ar duce la un comportament nedefinit.
    /// // assert_eq! ("salut", nesigur {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Dacă indicatorul atârnă, returnăm santinela direct.
            // Aceasta nu poate fi o adresă validă a sarcinii utile, deoarece sarcina utilă este cel puțin la fel de aliniată ca RcBox (usize).
            ptr as *const T
        } else {
            // SIGURANȚĂ: dacă is_dangling returnează false, atunci indicatorul este dereferențial.
            // Sarcina utilă poate fi scăzută în acest moment și trebuie să menținem proveniența, așa că folosiți manipularea indicatorului brut.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consumă `Weak<T>` și îl transformă într-un indicator brut.
    ///
    /// Aceasta convertește indicatorul slab într-un indicator brut, păstrând totuși proprietatea unei referințe slabe (numărul slab nu este modificat de această operație).
    /// Poate fi transformat înapoi în `Weak<T>` cu [`from_raw`].
    ///
    /// Se aplică aceleași restricții privind accesarea țintei indicatorului ca și în cazul [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Convertește un pointer brut creat anterior de [`into_raw`] în `Weak<T>`.
    ///
    /// Aceasta poate fi utilizată pentru a obține în siguranță o referință puternică (apelând [`upgrade`] mai târziu) sau pentru a aloca numărul scăzut prin renunțarea la `Weak<T>`.
    ///
    /// Preluează o referință slabă (cu excepția indicatorilor creați de [`new`], deoarece aceștia nu dețin nimic; metoda funcționează în continuare pe ei).
    ///
    /// # Safety
    ///
    /// Pointerul trebuie să fi provenit de la [`into_raw`] și trebuie să dețină în continuare potențialul său punct de referință slab.
    ///
    /// Este permis ca numărul puternic să fie 0 la momentul apelării.
    /// Cu toate acestea, acest lucru își asumă proprietatea unei referințe slabe reprezentate în prezent ca un pointer brut (numărul slab nu este modificat de această operațiune) și, prin urmare, trebuie asociat cu un apel anterior către [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Reduceți ultimul număr slab.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Consultați Weak::as_ptr pentru contextul despre modul în care este derivat indicatorul de intrare.

        let ptr = if is_dangling(ptr as *mut T) {
            // Acesta este un punct slab.
            ptr as *mut RcBox<T>
        } else {
            // În caz contrar, avem garanția că indicatorul a venit dintr-un punct slab nedumeritor.
            // SIGURANȚĂ: data_offset este sigur de apelat, deoarece ptr face referire la un real (potențial abandonat) T.
            let offset = unsafe { data_offset(ptr) };
            // Astfel, inversăm offsetul pentru a obține întregul RcBox.
            // SIGURANȚĂ: indicatorul provine dintr-un punct slab, deci acest decalaj este sigur.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIGURANȚĂ: acum am recuperat indicatorul Weak original, deci putem crea Weak.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Încearcă să actualizezi indicatorul `Weak` la un [`Rc`], amânând scăderea valorii interioare dacă reușește.
    ///
    ///
    /// Returnează [`None`] dacă valoarea interioară a fost scăzută de atunci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Distrugeți toate indicațiile puternice.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Obține numărul de indicatori puternici (`Rc`) care indică această alocare.
    ///
    /// Dacă `self` a fost creat folosind [`Weak::new`], acesta va întoarce 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Obține numărul de indicatori `Weak` care indică această alocare.
    ///
    /// Dacă nu rămân indicatori puternici, acest lucru va reveni la zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // scade ptr-ul slab implicit
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Returnează `None` atunci când indicatorul este suspendat și nu există niciun `RcBox` alocat, (de exemplu, atunci când acest `Weak` a fost creat de `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Avem grijă să *nu* creăm o referință care să acopere câmpul "data", deoarece câmpul poate fi mutat concomitent (de exemplu, dacă ultimul `Rc` este abandonat, câmpul de date va fi lăsat în loc).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returnează `true` dacă cele două " Slabe` indică aceeași alocare (similară cu [`ptr::eq`]) sau dacă ambele nu indică nicio alocare (deoarece au fost create cu `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Deoarece acest lucru compară indicii, înseamnă că `Weak::new()` se va egala unul cu celălalt, chiar dacă nu indică nicio alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparând `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Renunță la indicatorul `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nu tipărește nimic
    /// drop(foo);        // Tipărește "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // numărul scăzut începe de la 1 și va merge la zero numai dacă au dispărut toți indicatorii puternici.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Face o clonă a indicatorului `Weak` care indică aceeași alocare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construiește un nou `Weak<T>`, alocând memorie pentru `T` fără a-l inițializa.
    /// Apelarea [`upgrade`] la valoarea returnată dă întotdeauna [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Am verificat_adăugați aici pentru a trata mem::forget în siguranță.În special
// dacă mem::forget Rcs (sau Weaks), numărul de ref-uri se poate revărsa, iar apoi puteți elibera alocarea în timp ce există Rcs (sau Weaks) restante.
//
// Avortăm pentru că acesta este un scenariu atât de degenerat încât nu ne pasă de ce se întâmplă-niciun program real nu ar trebui să experimenteze acest lucru.
//
// Acest lucru ar trebui să aibă o cheltuială neglijabilă, deoarece nu este nevoie să clonați atât de mult în Rust datorită proprietății și semanticii de mișcare.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Vrem să renunțăm la revărsare în loc să scăpăm valoarea.
        // Numărul de referință nu va fi niciodată zero atunci când este apelat;
        // cu toate acestea, introducem un avort aici pentru a sugera LLVM la o altfel ratată optimizare.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Vrem să renunțăm la revărsare în loc să scăpăm valoarea.
        // Numărul de referință nu va fi niciodată zero atunci când este apelat;
        // cu toate acestea, introducem un avort aici pentru a sugera LLVM la o altfel ratată optimizare.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Obțineți offsetul într-un `RcBox` pentru sarcina utilă din spatele unui indicator.
///
/// # Safety
///
/// Pointerul trebuie să indice (și să aibă metadate valide pentru) o instanță validă anterior a lui T, dar T este permis să fie abandonat.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Aliniați valoarea nedimensionată la sfârșitul RcBox.
    // Deoarece RcBox este repr(C), va fi întotdeauna ultimul câmp din memorie.
    // SIGURANȚĂ: deoarece singurele tipuri nedimensionate posibile sunt felii, obiecte trait,
    // și tipuri externe, cerința de siguranță a intrării este în prezent suficientă pentru a satisface cerințele alin_of_val_raw;acesta este un detaliu de implementare a limbajului pe care este posibil să nu se bazeze pe std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}