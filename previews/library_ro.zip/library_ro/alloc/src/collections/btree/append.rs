use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Adaugă toate perechile cheie-valoare de la unirea a doi iteratori ascendenți, incrementând o variabilă `length` pe parcurs.Acesta din urmă face mai ușor pentru apelant să evite o scurgere atunci când un manipulator de cădere intră în panică.
    ///
    /// Dacă ambii iteratori produc aceeași cheie, această metodă elimină perechea din iteratorul stâng și adaugă perechea din iteratorul drept.
    ///
    /// Dacă doriți ca arborele să ajungă într-o ordine strict crescătoare, ca pentru un `BTreeMap`, ambii iteratori ar trebui să producă chei în ordine strict crescătoare, fiecare mai mare decât toate cheile din arbore, inclusiv orice chei deja în arbore la intrare.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ne pregătim să fuzionăm `left` și `right` într-o secvență sortată în timp liniar.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Între timp, construim un copac din secvența sortată în timp liniar.
        self.bulk_push(iter, length)
    }

    /// Împinge toate perechile cheie-valoare până la capătul arborelui, incrementând o variabilă `length` pe parcurs.
    /// Acesta din urmă face mai ușor pentru apelant să evite o scurgere atunci când iteratorul intră în panică.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterează toate perechile cheie-valoare, împingându-le în noduri la nivelul corect.
        for (key, value) in iter {
            // Încercați să împingeți perechea cheie-valoare în nodul frunzei curent.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Nu mai rămâne spațiu, urcă și împinge acolo.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Am găsit un nod cu spațiu rămas, împingeți aici.
                                open_node = parent;
                                break;
                            } else {
                                // Urcă din nou.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Suntem în partea de sus, creăm un nou nod rădăcină și împingem acolo.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Împingeți perechea cheie-valoare și noul subarborescent drept.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Coborâți din nou la cea mai dreaptă frunză.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Măriți lungimea fiecărei iterații, pentru a vă asigura că harta renunță la elementele adăugate chiar dacă avansarea iteratorului se panică.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Un iterator pentru fuzionarea a două secvențe sortate într-una singură
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Dacă două chei sunt egale, returnează perechea cheie-valoare de la sursa potrivită.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}