use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelează un reborrow al unei referințe unice, când știi că reborrow și toți descendenții săi (adică, toate indicațiile și referințele derivate din ea) nu vor mai fi folosite la un moment dat, după care vrei să folosești din nou referința unică originală .
///
///
/// Verificatorul împrumuturilor gestionează de obicei această stivuire a împrumuturilor pentru dvs., dar unele fluxuri de control care realizează această stivuire sunt prea complicate pentru ca compilatorul să le urmeze.
/// Un `DormantMutRef` vă permite să verificați singuri împrumuturile, exprimându-vă totuși natura stivuită, și încapsulând codul brut al indicatorului necesar pentru a face acest lucru fără un comportament nedefinit.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Captează un împrumut unic și împrumută-l imediat.
    /// Pentru compilator, durata de viață a noii referințe este aceeași cu durata de viață a referinței inițiale, dar promise să o utilizați pentru o perioadă mai scurtă.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SIGURANȚĂ: deținem împrumutul pe tot parcursul 'a prin `_marker` și expunem
        // numai această referință, deci este unică.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Reveniți la împrumutul unic capturat inițial.
    ///
    /// # Safety
    ///
    /// Reimprumutul trebuie să se fi încheiat, adică referința returnată de `new` și toate indicatoarele și referințele derivate din acesta nu mai trebuie folosite.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SIGURANȚĂ: propriile noastre condiții de siguranță implică faptul că această referință este din nou unică.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;