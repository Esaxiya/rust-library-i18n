/// Creează un [`Vec`] care conține argumentele.
///
/// `vec!` permite ca Vec să fie definit cu aceeași sintaxă ca și expresiile matrice.
/// Există două forme ale acestei macro:
///
/// - Creați un [`Vec`] care conține o listă dată de elemente:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Creați un [`Vec`] dintr-un anumit element și dimensiune:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Rețineți că, spre deosebire de expresiile matrice, această sintaxă acceptă toate elementele care implementează [`Clone`] și numărul de elemente nu trebuie să fie o constantă.
///
/// Aceasta va folosi `clone` pentru a duplica o expresie, deci ar trebui să aveți grijă să o utilizați cu tipuri care au o implementare `Clone` non-standard.
/// De exemplu, `vec![Rc::new(1);5] `va crea un vector de cinci referințe la aceeași valoare întreagă la cutie, nu cinci referințe care indică numere întregi la cutie independentă.
///
///
/// De asemenea, rețineți că `vec![expr; 0]` este permis și produce un vector gol.
/// Cu toate acestea, acest lucru va evalua `expr` și va scădea imediat valoarea rezultată, deci fiți atenți la efectele secundare.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cu cfg(test) metoda `[T]::into_vec` inerentă, care este necesară pentru această definiție macro, nu este disponibilă.
// În schimb, utilizați funcția `slice::into_vec`, care este disponibilă numai cu cfg(test) NB, consultați modulul slice::hack din slice.rs pentru mai multe informații
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Creează un `String` folosind interpolare de expresii runtime.
///
/// Primul argument pe care îl primește `format!` este un șir de format.Acesta trebuie să fie un literal șir.Puterea șirului de formatare se află în conținutul " {}`.
///
/// Parametrii suplimentari trecuți către `format!` înlocuiesc " {}` s din șirul de formatare în ordinea dată, cu excepția cazului în care sunt utilizați parametri numiți sau poziționali;vezi [`std::fmt`] pentru mai multe informații.
///
///
/// O utilizare obișnuită pentru `format!` este concatenarea și interpolarea șirurilor.
/// Aceeași convenție este utilizată cu macro-urile [`print!`] și [`write!`], în funcție de destinația intenționată a șirului.
///
/// Pentru a converti o singură valoare într-un șir, utilizați metoda [`to_string`].Aceasta va utiliza formatarea [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics dacă o implementare de formatare trait returnează o eroare.
/// Aceasta indică o implementare incorectă, deoarece `fmt::Write for String` nu returnează niciodată o eroare în sine.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Forțează nodul AST la o expresie pentru a îmbunătăți diagnosticul în poziția modelului.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}