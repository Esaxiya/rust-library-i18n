`core::arch` - Intrinsecele specifice arhitecturii bibliotecii de bază ale lui Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modulul `core::arch` implementează elemente intrinseci dependente de arhitectură (de ex. SIMD).

# Usage 

`core::arch` este disponibil ca parte a `libcore` și este reexportat de `libstd`.Preferați să-l utilizați prin `core::arch` sau `std::arch` decât prin acest crate.
Funcțiile instabile sunt adesea disponibile în Rust noaptea prin `feature(stdsimd)`.

Utilizarea `core::arch` prin intermediul acestui crate necesită Rust pe noapte și se poate (și se poate) rupe des.Singurele cazuri în care ar trebui să luați în considerare utilizarea acestuia prin intermediul acestui crate sunt:

* dacă trebuie să recompilați singur `core::arch`, de exemplu, cu anumite funcții țintă activate care nu sunt activate pentru `libcore`/`libstd`.
Note: dacă trebuie să îl recompilați pentru o țintă non-standard, vă rugăm să preferați să utilizați `xargo` și să recompilați `libcore`/`libstd` după caz în loc să utilizați acest crate.
  
* folosind unele funcții care ar putea să nu fie disponibile chiar și în spatele caracteristicilor instabile Rust.Încercăm să le menținem la minimum.
Dacă trebuie să utilizați unele dintre aceste caracteristici, vă rugăm să deschideți o problemă, astfel încât să le putem expune în Rust noaptea și să le puteți utiliza de acolo.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` este distribuit în principal în condițiile licenței MIT și licenței Apache (versiunea 2.0), cu porțiuni acoperite de diferite licențe de tip BSD.

Consultați LICENȚIA-APACHE și LICENȚIA-MIT pentru detalii.

# Contribution

Cu excepția cazului în care specificați în mod explicit altfel, orice contribuție trimisă în mod intenționat pentru includerea în `core_arch` de către dvs., așa cum este definit în licența Apache-2.0, va fi licențiată dublu ca mai sus, fără termeni sau condiții suplimentare.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












