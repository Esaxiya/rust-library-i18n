use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Obișnuiam să spunem adnotărilor noastre `#[assert_instr]` că toate intrinsecurile simd sunt disponibile pentru a-și testa codegenul, deoarece unele sunt închise în spatele unui `-Ctarget-feature=+unimplemented-simd128` suplimentar care nu are niciun echivalent în `#[target_feature]` chiar acum.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}