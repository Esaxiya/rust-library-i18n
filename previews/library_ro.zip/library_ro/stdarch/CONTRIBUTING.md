# Contribuind la stdarch

`stdarch` crate este mai mult decât dispus să accepte contribuții!Mai întâi veți dori probabil să verificați depozitul și să vă asigurați că testele trec pentru dvs.:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

În cazul în care `<your-target-arch>` este triplul țintă așa cum este folosit de `rustup`, de exemplu `x86_x64-unknown-linux-gnu` (fără niciun `nightly-` precedent sau similar).
Amintiți-vă, de asemenea, că acest depozit necesită canalul nocturn al Rust!
Testele de mai sus necesită, de fapt, ca rust de noapte să fie implicit în sistemul dvs., pentru a seta utilizarea `rustup default nightly` (și `rustup default stable` pentru a reveni).

Dacă oricare dintre pașii de mai sus nu funcționează, [please let us know][new]!

În continuare puteți folosi [find an issue][issues] pentru a vă ajuta, am selectat câteva cu etichetele [`help wanted`][help] și [`impl-period`][impl], care ar putea folosi în special ajutor. 
S-ar putea să fiți cel mai interesat de [#40][vendor], implementarea tuturor produselor intrinseci pe x86.Această problemă are câteva indicii bune despre unde să începem!

Dacă aveți întrebări generale, nu ezitați să [join us on gitter][gitter] și să întrebați!Simțiți-vă liber să faceți ping fie@BurntSushi, fie@alexcrichton cu întrebări.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Cum se scrie exemple pentru intrinseci stdarch

Există câteva caracteristici care trebuie activate pentru ca intrinsecul dat să funcționeze corect și exemplul trebuie rulat doar de `cargo test --doc` atunci când caracteristica este acceptată de CPU.

Ca urmare, `fn main` implicit generat de `rustdoc` nu va funcționa (în majoritatea cazurilor).
Luați în considerare utilizarea următoarelor ca ghid pentru a vă asigura că exemplul dvs. funcționează conform așteptărilor.

```rust
/// # // Avem nevoie de cfg_target_feature pentru a ne asigura că exemplul este numai
/// # // rulat de `cargo test --doc` când CPU acceptă această funcție
/// # #![feature(cfg_target_feature)]
/// # // Avem nevoie de target_feature pentru ca intrinsecul să funcționeze
/// # #![feature(target_feature)]
/// #
/// # // rustdoc implicit folosește `extern crate stdarch`, dar avem nevoie de
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Funcția principală reală
/// # fn main() {
/// #     // Rulați acest lucru numai dacă este acceptat `<target feature>`
/// #     dacă cfg_feature_enabled! ("<target feature>"){
/// #         // Creați o funcție `worker` care va fi rulată numai dacă caracteristica țintă
/// #         // este acceptat și asigurați-vă că `target_feature` este activat pentru lucrătorul dvs.
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn worker() nesigur {
/// // Scrieți exemplul aici.Caracteristicile specifice intrinseci vor funcționa aici!Fii salbatic!
///
/// #         }
///
/// #         { worker(); } nesigur
/// #     }
/// # }
```

Dacă unele dintre sintaxele de mai sus nu par familiare, secțiunea [Documentation as tests] a [Rust Book] descrie sintaxa `rustdoc` destul de bine.
Ca întotdeauna, nu ezitați să [join us on gitter][gitter] și întrebați-ne dacă ați lovit orice probleme și vă mulțumim că ați contribuit la îmbunătățirea documentației `stdarch`!

# Instrucțiuni alternative de testare

În general, este recomandat să utilizați `ci/run.sh` pentru a rula testele.
Cu toate acestea, este posibil ca acest lucru să nu funcționeze pentru dvs., de exemplu, dacă sunteți pe Windows.

În acest caz, puteți reveni la rularea `cargo +nightly test` și `cargo +nightly test --release -p core_arch` pentru testarea generării de cod.
Rețineți că acestea necesită instalarea lanțului de instrumente pe timp de noapte și pentru ca `rustc` să știe despre ținta triplă și CPU-ul său.
În special, trebuie să setați variabila de mediu `TARGET` așa cum ați face pentru `ci/run.sh`.
În plus, trebuie să setați `RUSTCFLAGS` (aveți nevoie de `C`) pentru a indica caracteristicile țintă, de ex `RUSTCFLAGS="-C -target-features=+avx2"`.
De asemenea, puteți seta `-C -target-cpu=native` dacă dezvoltați "just" în funcție de procesorul dvs. curent.

Fiți avertizat că atunci când utilizați aceste instrucțiuni alternative, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], de ex
testele de generare a instrucțiunilor pot eșua deoarece dezasamblatorul le-a denumit diferit, de ex
poate genera instrucțiuni `vaesenc` în loc de instrucțiuni `aesenc`, în ciuda faptului că se comportă la fel.
De asemenea, aceste instrucțiuni execută mai puține teste decât s-ar face în mod normal, așa că nu vă mirați că, atunci când trageți în cele din urmă cereri, pot apărea unele erori pentru testele care nu sunt acoperite aici.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






