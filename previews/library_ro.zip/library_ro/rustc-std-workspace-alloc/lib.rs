#![feature(no_core)]
#![no_core]

// Consultați rustc-std-workspace-core pentru a afla de ce este nevoie de acest crate.

// Redenumiți crate pentru a evita conflictul cu modulul alloc din liballoc.
extern crate alloc as foo;

pub use foo::*;