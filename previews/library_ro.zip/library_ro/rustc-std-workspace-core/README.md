# `rustc-std-workspace-core` crate

Acest crate este un crate subțire și gol, care depinde pur și simplu de `libcore` și reexportează tot conținutul său.
crate este esența împuternicirii bibliotecii standard pentru a depinde de crates de la crates.io

Crates pe crates.io de care depinde biblioteca standard trebuie să depindă de `rustc-std-workspace-core` crate de la crates.io, care este gol.

Folosim `[patch]` pentru a-l suprascrie la acest crate din acest depozit.
Ca rezultat, crates pe crates.io va desena o dependență edge la `libcore`, versiunea definită în acest depozit.
Asta ar trebui să atragă toate marginile dependenței pentru a se asigura că Cargo construiește crates cu succes!

Rețineți că crates pe crates.io trebuie să depindă de acest crate cu numele `core` pentru ca totul să funcționeze corect.Pentru a face acest lucru, ei pot folosi:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Prin utilizarea tastei `package`, crate este redenumit în `core`, ceea ce înseamnă că va arăta ca

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

când Cargo invocă compilatorul, satisfăcând directiva implicită `extern crate core` injectată de compilator.




