use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri este prea lent
fn exact_sanity_test() {
    // Acest test ajunge să ruleze ceea ce pot presupune doar că este un caz de colț al funcției de bibliotecă `exp2`, definit în orice timp de rulare C pe care îl folosim.
    // În VS 2013, această funcție pare să aibă o eroare, deoarece acest test eșuează atunci când este conectat, dar cu VS 2015, eroarea pare remediată, deoarece testul rulează foarte bine.
    //
    // Bug-ul pare a fi o diferență în valoarea de returnare `exp2(-1057)`, unde în VS 2013 returnează o dublă cu modelul de biți 0x2 și în VS 2015 returnează 0x20000.
    //
    //
    // Deocamdată ignorați acest test în întregime pe MSVC, deoarece oricum este testat în altă parte și nu suntem foarte interesați să testăm implementarea exp2 a fiecărei platforme.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}