use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Aceasta nu este o suprafață stabilă, dar ajută la menținerea `?` ieftină între ele, chiar dacă LLVM nu poate profita întotdeauna de ea chiar acum.
    //
    // (Din păcate, rezultatul și opțiunea sunt inconsistente, deci ControlFlow nu se poate potrivi cu ambele.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}