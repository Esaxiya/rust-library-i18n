//! API-uri de alocare a memoriei

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Eroarea `AllocError` indică o eroare de alocare care poate fi cauzată de epuizarea resurselor sau de ceva în neregulă la combinarea argumentelor de intrare date cu acest alocator.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (avem nevoie de asta pentru implementarea din aval a erorii trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// O implementare a `Allocator` poate aloca, crește, micșora și aloca blocuri arbitrare de date descrise prin [`Layout`][].
///
/// `Allocator` este conceput pentru a fi implementat pe ZST-uri, referințe sau indicatoare inteligente deoarece având un alocator precum `MyAlloc([u8; N])` nu poate fi mutat, fără actualizarea indicatoarelor în memoria alocată.
///
/// Spre deosebire de [`GlobalAlloc`][], alocările de dimensiuni zero sunt permise în `Allocator`.
/// Dacă un alocator de bază nu acceptă acest lucru (cum ar fi jemalloc) sau returnează un pointer nul (cum ar fi `libc::malloc`), acesta trebuie să fie prins de implementare.
///
/// ### Memorie alocată în prezent
///
/// Unele dintre metode necesită ca un bloc de memorie să fie *alocat în prezent* prin intermediul unui alocator.Aceasta înseamnă că:
///
/// * adresa de pornire pentru acel bloc de memorie a fost returnată anterior de [`allocate`], [`grow`] sau [`shrink`] și
///
/// * blocul de memorie nu a fost ulterior repartizat, unde blocurile sunt fie repartizate direct prin trecerea la [`deallocate`] sau au fost modificate prin trecerea la [`grow`] sau [`shrink`] care returnează `Ok`.
///
/// Dacă `grow` sau `shrink` au returnat `Err`, indicatorul trecut rămâne valid.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Montarea memoriei
///
/// Unele dintre metode necesită ca un aspect *să se potrivească* unui bloc de memorie.
/// Ce înseamnă pentru un aspect pentru "fit" un bloc de memorie înseamnă (sau în mod echivalent, pentru un bloc de memorie pentru "fit" un aspect) este că trebuie să îndeplinească următoarele condiții:
///
/// * Blocul trebuie alocat cu aceeași aliniere ca [`layout.align()`] și
///
/// * [`layout.size()`] furnizat trebuie să se încadreze în intervalul `min ..= max`, unde:
///   - `min` este dimensiunea aspectului folosit recent pentru alocarea blocului și
///   - `max` este cea mai recentă dimensiune reală returnată de la [`allocate`], [`grow`] sau [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blocurile de memorie returnate de la un alocator trebuie să indice spre memoria validă și să-și păstreze valabilitatea până când instanța și toate clonele sale sunt abandonate,
///
/// * clonarea sau mutarea alocatorului nu trebuie să invalideze blocurile de memorie returnate de la acest alocator.Un alocator clonat trebuie să se comporte ca același alocator și
///
/// * orice pointer către un bloc de memorie care este [*currently allocated*] poate fi trecut la orice altă metodă a alocatorului.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Încearcă să aloce un bloc de memorie.
    ///
    /// La succes, returnează un [`NonNull<[u8]>`][NonNull] care îndeplinește dimensiunile și garanțiile de aliniere ale `layout`.
    ///
    /// Blocul returnat poate avea o dimensiune mai mare decât cea specificată de `layout.size()` și poate avea sau nu conținutul inițializat.
    ///
    /// # Errors
    ///
    /// Revenirea `Err` indică faptul că fie memoria este epuizată, fie `layout` nu îndeplinește dimensiunile alocatorului sau constrângerile de aliniere.
    ///
    /// Implementările sunt încurajate să returneze `Err` după epuizarea memoriei, mai degrabă decât în panică sau întrerupere, dar aceasta nu este o cerință strictă.
    /// (Mai exact: este *legal* să implementați acest trait deasupra unei biblioteci de alocare native subiacente care se întrerupe la epuizarea memoriei.)
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de alocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Se comportă ca `allocate`, dar asigură, de asemenea, că memoria returnată este inițializată zero.
    ///
    /// # Errors
    ///
    /// Revenirea `Err` indică faptul că fie memoria este epuizată, fie `layout` nu îndeplinește dimensiunile alocatorului sau constrângerile de aliniere.
    ///
    /// Implementările sunt încurajate să returneze `Err` după epuizarea memoriei, mai degrabă decât în panică sau întrerupere, dar aceasta nu este o cerință strictă.
    /// (Mai exact: este *legal* să implementați acest trait deasupra unei biblioteci de alocare native subiacente care se întrerupe la epuizarea memoriei.)
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de alocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SIGURANȚĂ: `alloc` returnează un bloc de memorie valid
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Repartizează memoria la care face referire `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` trebuie să denoteze un bloc de memorie [*currently allocated*] prin intermediul acestui alocator și
    /// * `layout` trebuie să [*fit*] acel bloc de memorie.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Încearcă să extindă blocul de memorie.
    ///
    /// Returnează un nou [`NonNull<[u8]>`][NonNull] care conține un pointer și dimensiunea reală a memoriei alocate.Pointerul este potrivit pentru păstrarea datelor descrise de `new_layout`.
    /// Pentru a realiza acest lucru, alocatorul poate extinde alocarea la care face referire `ptr` pentru a se potrivi noului aspect.
    ///
    /// Dacă acest lucru returnează `Ok`, atunci proprietatea asupra blocului de memorie la care face referire `ptr` a fost transferată către acest alocator.
    /// Este posibil ca memoria să fi fost sau nu eliberată și ar trebui considerată inutilizabilă, cu excepția cazului în care a fost transferată din nou către apelant din nou prin valoarea returnată a acestei metode.
    ///
    /// Dacă această metodă returnează `Err`, atunci proprietatea asupra blocului de memorie nu a fost transferată către acest alocator, iar conținutul blocului de memorie este nealterat.
    ///
    /// # Safety
    ///
    /// * `ptr` trebuie să denoteze un bloc de memorie [*currently allocated*] prin intermediul acestui alocator.
    /// * `old_layout` trebuie să [*fit*] acel bloc de memorie (argumentul `new_layout` nu trebuie să se potrivească acestuia).
    /// * `new_layout.size()` trebuie să fie mai mare sau egal cu `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnează `Err` dacă noul aspect nu îndeplinește dimensiunile alocatorului și constrângerile de aliniere ale alocatorului sau dacă creșterea în caz contrar eșuează.
    ///
    /// Implementările sunt încurajate să returneze `Err` după epuizarea memoriei, mai degrabă decât în panică sau întrerupere, dar aceasta nu este o cerință strictă.
    /// (Mai exact: este *legal* să implementați acest trait deasupra unei biblioteci de alocare native subiacente care se întrerupe la epuizarea memoriei.)
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de alocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURANȚĂ: deoarece `new_layout.size()` trebuie să fie mai mare sau egal cu
        // `old_layout.size()`, atât vechea, cât și noua alocare a memoriei sunt valabile pentru citiri și scrieri pentru octeți `old_layout.size()`.
        // De asemenea, deoarece vechea alocare nu era încă alocată, nu se poate suprapune peste `new_ptr`.
        // Astfel, apelul către `copy_nonoverlapping` este sigur.
        // Contractul de siguranță pentru `dealloc` trebuie confirmat de către apelant.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Se comportă ca `grow`, dar se asigură și că noul conținut este setat la zero înainte de a fi returnat.
    ///
    /// Blocul de memorie va conține următorul conținut după un apel reușit către
    /// `grow_zeroed`:
    ///   * Octii `0..old_layout.size()` sunt păstrați din alocarea inițială.
    ///   * Octecții `old_layout.size()..old_size` vor fi fie păstrați, fie reduși la zero, în funcție de implementarea alocatorului.
    ///   `old_size` se referă la dimensiunea blocului de memorie anterior apelului `grow_zeroed`, care poate fi mai mare decât dimensiunea solicitată inițial la alocare.
    ///   * Octetii `old_size..new_size` sunt zero.`new_size` se referă la dimensiunea blocului de memorie returnat de apelul `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` trebuie să denoteze un bloc de memorie [*currently allocated*] prin intermediul acestui alocator.
    /// * `old_layout` trebuie să [*fit*] acel bloc de memorie (argumentul `new_layout` nu trebuie să se potrivească acestuia).
    /// * `new_layout.size()` trebuie să fie mai mare sau egal cu `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnează `Err` dacă noul aspect nu îndeplinește dimensiunile alocatorului și constrângerile de aliniere ale alocatorului sau dacă creșterea în caz contrar eșuează.
    ///
    /// Implementările sunt încurajate să returneze `Err` după epuizarea memoriei, mai degrabă decât în panică sau întrerupere, dar aceasta nu este o cerință strictă.
    /// (Mai exact: este *legal* să implementați acest trait deasupra unei biblioteci de alocare native subiacente care se întrerupe la epuizarea memoriei.)
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de alocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SIGURANȚĂ: deoarece `new_layout.size()` trebuie să fie mai mare sau egal cu
        // `old_layout.size()`, atât vechea, cât și noua alocare a memoriei sunt valabile pentru citiri și scrieri pentru octeți `old_layout.size()`.
        // De asemenea, deoarece vechea alocare nu era încă alocată, nu se poate suprapune peste `new_ptr`.
        // Astfel, apelul către `copy_nonoverlapping` este sigur.
        // Contractul de siguranță pentru `dealloc` trebuie confirmat de către apelant.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Încearcă să micșoreze blocul de memorie.
    ///
    /// Returnează un nou [`NonNull<[u8]>`][NonNull] care conține un pointer și dimensiunea reală a memoriei alocate.Pointerul este potrivit pentru păstrarea datelor descrise de `new_layout`.
    /// Pentru a realiza acest lucru, alocatorul poate micșora alocarea la care face referire `ptr` pentru a se potrivi noului aspect.
    ///
    /// Dacă acest lucru returnează `Ok`, atunci proprietatea asupra blocului de memorie la care face referire `ptr` a fost transferată către acest alocator.
    /// Este posibil ca memoria să fi fost sau nu eliberată și ar trebui considerată inutilizabilă, cu excepția cazului în care a fost transferată din nou către apelant din nou prin valoarea returnată a acestei metode.
    ///
    /// Dacă această metodă returnează `Err`, atunci proprietatea asupra blocului de memorie nu a fost transferată către acest alocator, iar conținutul blocului de memorie este nealterat.
    ///
    /// # Safety
    ///
    /// * `ptr` trebuie să denoteze un bloc de memorie [*currently allocated*] prin intermediul acestui alocator.
    /// * `old_layout` trebuie să [*fit*] acel bloc de memorie (argumentul `new_layout` nu trebuie să se potrivească acestuia).
    /// * `new_layout.size()` trebuie să fie mai mic sau egal cu `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnează `Err` dacă noul aspect nu îndeplinește dimensiunile și constrângerile de aliniere ale alocatorului, sau dacă restrângerea eșuează altfel.
    ///
    /// Implementările sunt încurajate să returneze `Err` după epuizarea memoriei, mai degrabă decât în panică sau întrerupere, dar aceasta nu este o cerință strictă.
    /// (Mai exact: este *legal* să implementați acest trait deasupra unei biblioteci de alocare native subiacente care se întrerupe la epuizarea memoriei.)
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de alocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURANȚĂ: deoarece `new_layout.size()` trebuie să fie mai mic sau egal cu
        // `old_layout.size()`, atât vechea, cât și noua alocare a memoriei sunt valabile pentru citiri și scrieri pentru octeți `new_layout.size()`.
        // De asemenea, deoarece vechea alocare nu era încă alocată, nu se poate suprapune peste `new_ptr`.
        // Astfel, apelul către `copy_nonoverlapping` este sigur.
        // Contractul de siguranță pentru `dealloc` trebuie confirmat de către apelant.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Creează un adaptor "by reference" pentru această instanță a `Allocator`.
    ///
    /// Adaptorul returnat implementează și `Allocator` și va împrumuta pur și simplu acest lucru.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SIGURANȚĂ: contractul de siguranță trebuie confirmat de către apelant
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURANȚĂ: contractul de siguranță trebuie confirmat de către apelant
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURANȚĂ: contractul de siguranță trebuie confirmat de către apelant
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURANȚĂ: contractul de siguranță trebuie confirmat de către apelant
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}