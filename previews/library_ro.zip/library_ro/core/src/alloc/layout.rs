use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// În timp ce această funcție este utilizată într-un singur loc și implementarea sa ar putea fi subliniată, încercările anterioare de a face acest lucru au făcut rustc mai lent:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Dispunerea unui bloc de memorie.
///
/// O instanță de `Layout` descrie un aspect particular al memoriei.
/// Construiți un `Layout` ca intrare pentru a da unui alocator.
///
/// Toate aspectele au o dimensiune asociată și o aliniere a puterii de două.
///
/// (Rețineți că aspectele nu sunt *obligatorii* pentru a avea dimensiuni diferite de zero, chiar dacă `GlobalAlloc` necesită ca toate cererile de memorie să fie diferite de zero.
/// Un apelant trebuie fie să se asigure că sunt îndeplinite astfel de condiții, să utilizeze alocatori specifici cu cerințe mai slabe, fie să utilizeze interfața `Allocator` mai îngăduitoare.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // dimensiunea blocului de memorie solicitat, măsurată în octeți.
    size_: usize,

    // alinierea blocului de memorie solicitat, măsurat în octeți.
    // ne asigurăm că aceasta este întotdeauna o putere de două, deoarece API-urile precum `posix_memalign` o necesită și este o constrângere rezonabilă de impus constructorilor de Layout.
    //
    //
    // (Cu toate acestea, în mod analog nu avem nevoie de `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Construiește un `Layout` dintr-un anumit `size` și `align` sau returnează `LayoutError` dacă oricare dintre următoarele condiții nu este îndeplinită:
    ///
    /// * `align` nu trebuie să fie zero,
    ///
    /// * `align` trebuie să fie o putere de doi,
    ///
    /// * `size`, atunci când este rotunjit la cel mai apropiat multiplu de `align`, nu trebuie să depășească (de exemplu, valoarea rotunjită trebuie să fie mai mică sau egală cu `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (puterea a două implică alinierea!=0.)

        // Dimensiunea rotunjită este:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Știm de sus că aliniază!=0.
        // Dacă adăugarea (alinierea, 1) nu depășește, atunci rotunjirea în sus va fi bine.
        //
        // În schimb,&-masking cu! (Align, 1) va scădea numai biții de ordin scăzut.
        // Astfel, dacă deversarea are loc cu suma,&-mask nu poate scădea suficient pentru a anula acea revărsare.
        //
        //
        // Mai sus implică faptul că verificarea depășirii sumelor este atât necesară, cât și suficientă.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SIGURANȚĂ: condițiile pentru `from_size_align_unchecked` au fost
        // verificat mai sus.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Creează un aspect, ocolind toate verificările.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură, deoarece nu verifică condițiile prealabile de la [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SIGURANȚĂ: apelantul trebuie să se asigure că `align` este mai mare decât zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Dimensiunea minimă în octeți pentru un bloc de memorie al acestui aspect.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Alinierea minimă de octeți pentru un bloc de memorie al acestui aspect.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Construiește un `Layout` potrivit pentru a deține o valoare de tip `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SIGURANȚĂ: alinierea este garantată de Rust pentru a fi o putere de două și
        // combo-ul size + align este garantat să se potrivească în spațiul nostru de adrese.
        // Ca rezultat, utilizați constructorul nebifat aici pentru a evita inserarea codului care panics dacă nu este optimizat suficient de bine.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un aspect care descrie o înregistrare care ar putea fi utilizată pentru a aloca structura de sprijin pentru `T` (care ar putea fi un trait sau alt tip nedimensionat, cum ar fi o felie).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIGURANȚĂ: consultați raționamentul din `new` pentru a afla de ce se folosește varianta nesigură
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un aspect care descrie o înregistrare care ar putea fi utilizată pentru a aloca structura de sprijin pentru `T` (care ar putea fi un trait sau alt tip nedimensionat, cum ar fi o felie).
    ///
    /// # Safety
    ///
    /// Această funcție poate fi apelată în siguranță numai dacă sunt îndeplinite următoarele condiții:
    ///
    /// - Dacă `T` este `Sized`, această funcție este întotdeauna sigură de apelat.
    /// - Dacă coada nedimensionată a lui `T` este:
    ///     - un [slice], atunci lungimea cozii feliei trebuie să fie un număr întreg inițializat, iar dimensiunea *întregii valori*(lungimea cozii dinamice + prefixul dimensiunii statice) trebuie să se potrivească în `isize`.
    ///     - un [trait object], atunci partea vtable a indicatorului trebuie să indice o tabelă vtable validă pentru tipul `T` dobândit printr-o coersiune de dimensiune, iar dimensiunea *întregii valori*(lungimea cozii dinamice + prefixul dimensiunii statice) trebuie să se potrivească în `isize`.
    ///
    ///     - un (unstable) [extern type], atunci această funcție este întotdeauna sigură de apelat, dar poate panic sau altfel să returneze valoarea greșită, deoarece aspectul tipului extern nu este cunoscut.
    ///     Acesta este același comportament ca [`Layout::for_value`] la o referință la o coadă de tip extern.
    ///     - în caz contrar, nu este permis conservator să se apeleze această funcție.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SIGURANȚĂ: trecem de-a lungul condițiilor prealabile ale acestor funcții către apelant
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIGURANȚĂ: consultați raționamentul din `new` pentru a afla de ce se folosește varianta nesigură
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Creează un `NonNull` care atârnă, dar bine aliniat pentru acest aspect.
    ///
    /// Rețineți că valoarea indicatorului poate reprezenta potențial un indicator valid, ceea ce înseamnă că acest lucru nu trebuie utilizat ca valoare santinelă "not yet initialized".
    /// Tipurile care alocă leneș trebuie să urmărească inițializarea prin alte mijloace.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SIGURANȚĂ: alinierea este garantată să fie diferită de zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Creează un aspect care descrie înregistrarea care poate deține o valoare de același aspect ca `self`, dar care este, de asemenea, aliniată la alinierea `align` (măsurată în octeți).
    ///
    ///
    /// Dacă `self` îndeplinește deja alinierea prescrisă, atunci returnează `self`.
    ///
    /// Rețineți că această metodă nu adaugă nicio umplutură la dimensiunea totală, indiferent dacă aspectul returnat are o aliniere diferită.
    /// Cu alte cuvinte, dacă `K` are dimensiunea 16, `K.align_to(32)` va avea *încă* dimensiunea 16.
    ///
    /// Returnează o eroare dacă combinația `self.size()` și `align` dată încalcă condițiile enumerate în [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Returnează cantitatea de umplutură pe care trebuie să o introducem după `self` pentru a ne asigura că următoarea adresă va satisface `align` (măsurată în octeți).
    ///
    /// de exemplu, dacă `self.size()` este 9, atunci `self.padding_needed_for(4)` returnează 3, deoarece acesta este numărul minim de octeți de umplere necesari pentru a obține o adresă cu 4 alinieri (presupunând că blocul de memorie corespunzător începe la o adresă cu 4 alinieri).
    ///
    ///
    /// Valoarea returnată a acestei funcții nu are nicio semnificație dacă `align` nu este o putere de doi.
    ///
    /// Rețineți că utilitatea valorii returnate necesită ca `align` să fie mai mic sau egal cu alinierea adresei de pornire pentru întregul bloc alocat de memorie.O modalitate de a satisface această constrângere este asigurarea `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Valoarea rotunjită este:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // și apoi returnăm diferența de umplere: `len_rounded_up - len`.
        //
        // Folosim aritmetica modulară în:
        //
        // 1. alin este garantat să fie> 0, deci alin, 1 este întotdeauna valid.
        //
        // 2.
        // `len + align - 1` poate depăși cel mult `align - 1`, astfel încât&-mask cu `!(align - 1)` va asigura că, în cazul depășirii, `len_rounded_up` va fi el însuși 0.
        //
        //    Astfel, umplutura returnată, atunci când este adăugată la `len`, produce 0, ceea ce satisface în mod trivial alinierea `align`.
        //
        // (Desigur, încercările de a aloca blocuri de memorie a căror dimensiune și umplutură de umplere în maniera de mai sus ar trebui să determine alocatorul să producă o eroare oricum.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Creează un aspect rotunjind dimensiunea acestui aspect la un multiplu al alinierii aspectului.
    ///
    ///
    /// Acest lucru este echivalent cu adăugarea rezultatului `padding_needed_for` la dimensiunea curentă a aspectului.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Acest lucru nu se poate revărsa.Citat din invariantul Layout:
        // > `size`, când este rotunjit la cel mai apropiat multiplu de `align`,
        // > nu trebuie să depășească (de exemplu, valoarea rotunjită trebuie să fie mai mică decât
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Creează un aspect care descrie înregistrarea pentru instanțele `n` ale `self`, cu o cantitate adecvată de umplere între fiecare pentru a se asigura că fiecărei instanțe i se oferă dimensiunea și alinierea solicitate.
    /// La succes, returnează `(k, offs)` unde `k` este aspectul matricei și `offs` este distanța dintre începutul fiecărui element din matrice.
    ///
    /// La depășirea aritmetică, returnează `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Acest lucru nu se poate revărsa.Citat din invariantul Layout:
        // > `size`, când este rotunjit la cel mai apropiat multiplu de `align`,
        // > nu trebuie să depășească (de exemplu, valoarea rotunjită trebuie să fie mai mică decât
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SIGURANȚĂ: self.align este deja cunoscut ca fiind valid și alloc_size a fost
        // căptușit deja.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Creează un aspect care descrie înregistrarea pentru `self` urmată de `next`, incluzând orice umplutură necesară pentru a se asigura că `next` va fi aliniat corect, dar *nu există o umplere finală*.
    ///
    /// Pentru a se potrivi cu aspectul de reprezentare C `repr(C)`, trebuie să apelați `pad_to_align` după extinderea aspectului cu toate câmpurile.
    /// (Nu există nicio modalitate de a se potrivi cu aspectul implicit de reprezentare Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Rețineți că alinierea aspectului rezultat va fi maximul celor de la `self` și `next`, pentru a asigura alinierea ambelor părți.
    ///
    /// Returnează `Ok((k, offset))`, unde `k` este aspectul înregistrării concatenate, iar `offset` este locația relativă, în octeți, a începutului `next` încorporat în înregistrarea concatenată (presupunând că înregistrarea în sine începe la offset 0).
    ///
    ///
    /// La depășirea aritmetică, returnează `LayoutError`.
    ///
    /// # Examples
    ///
    /// Pentru a calcula aspectul unei structuri `#[repr(C)]` și compensările câmpurilor din aspectele câmpurilor sale:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Nu uitați să finalizați cu `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // testați că funcționează
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Creează un aspect care descrie înregistrarea pentru instanțele `n` ale `self`, fără nicio umplere între fiecare instanță.
    ///
    /// Rețineți că, spre deosebire de `repeat`, `repeat_packed` nu garantează că instanțele repetate ale `self` vor fi aliniate corect, chiar dacă o instanță dată de `self` este aliniată corect.
    /// Cu alte cuvinte, dacă aspectul returnat de `repeat_packed` este utilizat pentru a aloca o matrice, nu este garantat că toate elementele din matrice vor fi aliniate corect.
    ///
    /// La depășirea aritmetică, returnează `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Creează un aspect care descrie înregistrarea pentru `self` urmată de `next` fără nicio umplutură suplimentară între cele două.
    /// Deoarece nu este inserată nicio umplutură, alinierea `next` este irelevantă și nu este încorporată *deloc* în aspectul rezultat.
    ///
    ///
    /// La depășirea aritmetică, returnează `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Creează un aspect care descrie înregistrarea pentru un `[T; n]`.
    ///
    /// La depășirea aritmetică, returnează `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametrii dați `Layout::from_size_align` sau altui constructor `Layout` nu își îndeplinesc constrângerile documentate.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (avem nevoie de asta pentru implementarea din aval a erorii trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}