use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Un alocator de memorie care poate fi înregistrat ca implicit al bibliotecii standard prin atributul `#[global_allocator]`.
///
/// Unele dintre metode necesită ca un bloc de memorie să fie *alocat în prezent* prin intermediul unui alocator.Aceasta înseamnă că:
///
/// * adresa de pornire pentru acel bloc de memorie a fost returnată anterior de un apel anterior către o metodă de alocare, cum ar fi `alloc` și
///
/// * blocul de memorie nu a fost ulterior repartizat, unde blocurile sunt repartizate fie prin trecerea către o metodă de repartizare, cum ar fi `dealloc`, fie prin trecerea către o metodă de realocare care returnează un pointer non-nul.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait este un `unsafe` trait din mai multe motive și implementatorii trebuie să se asigure că aderă la aceste contracte:
///
/// * Este un comportament nedefinit dacă alocații globali se relaxează.Această restricție poate fi ridicată în future, dar în prezent un panic din oricare dintre aceste funcții poate duce la nesiguranță în memorie.
///
/// * `Layout` interogările și calculele în general trebuie să fie corecte.Apelanții acestui trait au voie să se bazeze pe contractele definite pe fiecare metodă, iar implementatorii trebuie să se asigure că astfel de contracte rămân adevărate.
///
/// * Este posibil să nu vă bazați pe alocările care se întâmplă efectiv, chiar dacă există surse explicative de heap.
/// Optimizatorul poate detecta alocațiile neutilizate pe care le poate elimina în totalitate sau se poate muta în stivă și astfel nu poate invoca niciodată alocatorul.
/// Optimizatorul poate presupune în continuare că alocarea este infailibilă, astfel încât codul care a eșuat din cauza defecțiunilor alocatorului poate funcționa brusc, deoarece optimizatorul a lucrat în jurul nevoii unei alocări.
/// Mai concret, următorul exemplu de cod este nefondat, indiferent dacă alocatorul dvs. personalizat permite numărarea câte alocări s-au întâmplat.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Rețineți că optimizările menționate mai sus nu sunt singura optimizare care poate fi aplicată.Este posibil să nu vă bazați pe alocările de heap care se întâmplă dacă acestea pot fi eliminate fără a schimba comportamentul programului.
///   Indiferent dacă se întâmplă sau nu alocările nu face parte din comportamentul programului, chiar dacă ar putea fi detectat printr-un alocator care urmărește alocările prin imprimare sau cu alte efecte secundare.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Alocați memoria așa cum este descris de `layout` dat.
    ///
    /// Returnează un pointer în memoria nou-alocată sau nul pentru a indica eșecul alocării.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură, deoarece poate rezulta un comportament nedefinit dacă apelantul nu se asigură că `layout` are dimensiuni diferite de zero.
    ///
    /// (Trăsăturile de extensie ar putea oferi limite mai specifice comportamentului, de exemplu, să garanteze o adresă santinelă sau un indicator nul ca răspuns la o cerere de alocare de dimensiuni zero.)
    ///
    /// Blocul de memorie alocat poate fi inițializat sau nu.
    ///
    /// # Errors
    ///
    /// Revenirea unui pointer nul indică faptul că fie memoria este epuizată, fie `layout` nu îndeplinește dimensiunile acestui limitator sau constrângerile de aliniere.
    ///
    /// Implementările sunt încurajate să returneze nul pe epuizarea memoriei, mai degrabă decât întreruperea, dar aceasta nu este o cerință strictă.
    /// (Mai exact: este *legal* să implementați acest trait deasupra unei biblioteci de alocare native subiacente care se întrerupe la epuizarea memoriei.)
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de alocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Alocați blocul de memorie la indicatorul `ptr` dat cu `layout` dat.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură, deoarece poate rezulta un comportament nedefinit dacă apelantul nu asigură toate următoarele:
    ///
    ///
    /// * `ptr` trebuie să denotă un bloc de memorie alocat în prezent prin acest alocator,
    ///
    /// * `layout` trebuie să fie același aspect care a fost utilizat pentru a aloca acel bloc de memorie.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Se comportă ca `alloc`, dar se asigură, de asemenea, că conținutul este setat la zero înainte de a fi returnat.
    ///
    /// # Safety
    ///
    /// Această funcție nu este sigură din aceleași motive ca și `alloc`.
    /// Cu toate acestea, este garantat că blocul de memorie alocat este inițializat.
    ///
    /// # Errors
    ///
    /// Returnarea unui pointer nul indică faptul că fie memoria este epuizată, fie `layout` nu îndeplinește dimensiunile sau restricțiile de aliniere ale alocatorului, la fel ca în `alloc`.
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de alocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SIGURANȚĂ: contractul de siguranță pentru `alloc` trebuie confirmat de către apelant.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SIGURANȚĂ: pe măsură ce alocarea a reușit, regiunea de la `ptr`
            // de dimensiunea `size` este garantat pentru a fi valabil pentru scrieri.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Reduceți sau măriți un bloc de memorie la `new_size` dat.
    /// Blocul este descris de indicatorul `ptr` dat și de `layout`.
    ///
    /// Dacă acesta returnează un pointer care nu este nul, atunci proprietatea asupra blocului de memorie la care face referire `ptr` a fost transferată acestui alocator.
    /// Este posibil ca memoria să fi fost sau nu alocată și ar trebui considerată inutilizabilă (cu excepția cazului în care, desigur, a fost transferată înapoi către apelant din nou prin valoarea returnată a acestei metode).
    /// Noul bloc de memorie este alocat cu `layout`, dar cu `size` actualizat la `new_size`.
    /// Acest nou aspect ar trebui utilizat atunci când alocați noul bloc de memorie cu `dealloc`.
    /// Gama `0..min(layout.size(), new_size) `a noului bloc de memorie este garantată să aibă aceleași valori ca și blocul original.
    ///
    /// Dacă această metodă revine nulă, atunci proprietatea asupra blocului de memorie nu a fost transferată către acest alocator, iar conținutul blocului de memorie este nealterat.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură, deoarece poate rezulta un comportament nedefinit dacă apelantul nu asigură toate următoarele:
    ///
    /// * `ptr` trebuie alocat în prezent prin intermediul acestui alocator,
    ///
    /// * `layout` trebuie să fie același aspect care a fost folosit pentru a aloca acel bloc de memorie,
    ///
    /// * `new_size` trebuie să fie mai mare decât zero.
    ///
    /// * `new_size`, atunci când este rotunjit la cel mai apropiat multiplu de `layout.align()`, nu trebuie să depășească (de exemplu, valoarea rotunjită trebuie să fie mai mică decât `usize::MAX`).
    ///
    /// (Trăsăturile de extensie ar putea oferi limite mai specifice comportamentului, de exemplu, să garanteze o adresă santinelă sau un indicator nul ca răspuns la o cerere de alocare de dimensiuni zero.)
    ///
    /// # Errors
    ///
    /// Returnează nul dacă noul aspect nu îndeplinește constrângerile de dimensiune și aliniere ale alocatorului sau dacă realocarea nu reușește altfel.
    ///
    /// Implementările sunt încurajate să revină la epuizarea memoriei, mai degrabă decât la panică sau avort, dar aceasta nu este o cerință strictă.
    /// (Mai exact: este *legal* să implementați acest trait deasupra unei biblioteci de alocare native subiacente care se întrerupe la epuizarea memoriei.)
    ///
    /// Clienții care doresc să întrerupă calculul ca răspuns la o eroare de realocare sunt încurajați să apeleze funcția [`handle_alloc_error`], mai degrabă decât să invoce direct `panic!` sau similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SIGURANȚĂ: apelantul trebuie să se asigure că `new_size` nu se revarsă.
        // `layout.align()` provine de la un `Layout` și, prin urmare, este garantat că este valid.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SIGURANȚĂ: apelantul trebuie să se asigure că `new_layout` este mai mare decât zero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SIGURANȚĂ: blocul alocat anterior nu poate suprapune blocul nou alocat.
            // Contractul de siguranță pentru `dealloc` trebuie confirmat de către apelant.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}