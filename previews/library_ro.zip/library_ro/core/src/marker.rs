//! traits primitive și tipuri reprezentând proprietăți de bază ale tipurilor.
//!
//! Tipurile Rust pot fi clasificate în diferite moduri utile în funcție de proprietățile lor intrinseci.
//! Aceste clasificări sunt reprezentate ca traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipuri care pot fi transferate peste limitele firului.
///
/// Acest trait este implementat automat atunci când compilatorul determină că este adecvat.
///
/// Un exemplu de tip care nu este " Trimite` este indicatorul de numărare a referințelor [`rc::Rc`][`Rc`].
/// Dacă două fire încearcă să cloneze [`Rc`] care indică aceeași valoare de referință, ar putea încerca să actualizeze numărul de referințe în același timp, care este [undefined behavior][ub] deoarece [`Rc`] nu folosește operații atomice.
///
/// Vărul său [`sync::Arc`][arc] folosește operațiuni atomice (suportând unele cheltuieli generale) și astfel este `Send`.
///
/// Consultați [the Nomicon](../../nomicon/send-and-sync.html) pentru mai multe detalii.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipuri cu o dimensiune constantă cunoscută în timpul compilării.
///
/// Toți parametrii de tip au o legătură implicită de `Sized`.Sintaxa specială `?Sized` poate fi utilizată pentru a elimina această legătură dacă nu este adecvată.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//eroare: Sized nu este implementat pentru [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Singura excepție este tipul `Self` implicit al unui trait.
/// Un trait nu are un `Sized` implicit legat deoarece acest lucru este incompatibil cu [obiectul trait] unde, prin definiție, trait trebuie să funcționeze cu toți implementatorii posibili și, prin urmare, ar putea avea orice dimensiune.
///
///
/// Deși Rust vă va permite să legați `Sized` la un trait, nu îl veți putea folosi pentru a forma un obiect trait mai târziu:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // să y: &dyn Bar= &Impl;//eroare: trait `Bar` nu poate fi transformat într-un obiect
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // pentru Default, de exemplu, care necesită ca `[T]: !Default` să poată fi evaluat
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipuri care pot fi "unsized" la un tip dinamic.
///
/// De exemplu, matricea de tip `[i8; 2]` implementează `Unsize<[i8]>` și `Unsize<dyn fmt::Debug>`.
///
/// Toate implementările `Unsize` sunt furnizate automat de compilator.
///
/// `Unsize` este implementat pentru:
///
/// - `[T; N]` este `Unsize<[T]>`
/// - `T` este `Unsize<dyn Trait>` când `T: Trait`
/// - `Foo<..., T, ...>` este `Unsize<Foo<..., U, ...>>` dacă:
///   - `T: Unsize<U>`
///   - Foo este o structură
///   - Doar ultimul câmp al `Foo` are un tip care implică `T`
///   - `T` nu face parte din tipul niciunui alt câmp
///   - `Bar<T>: Unsize<Bar<U>>`, dacă ultimul câmp al `Foo` are tipul `Bar<T>`
///
/// `Unsize` este utilizat împreună cu [`ops::CoerceUnsized`] pentru a permite containerelor "user-defined", cum ar fi [`Rc`], să conțină tipuri de dimensiuni dinamice.
/// Consultați [DST coercion RFC][RFC982] și [the nomicon entry on coercion][nomicon-coerce] pentru mai multe detalii.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait obligatoriu pentru constantele utilizate în potrivirile de tipare.
///
/// Orice tip care derivă `PartialEq` implementează automat acest trait,*indiferent* dacă parametrii săi tip implementează `Eq`.
///
/// Dacă un articol `const` conține un tip care nu implementează acest trait, atunci acel tip fie (1.) nu implementează `PartialEq` (ceea ce înseamnă că constanta nu va furniza acea metodă de comparație, care generare de cod presupune că este disponibilă), sau (2.) implementează *propria sa* versiunea `PartialEq` (despre care presupunem că nu este conformă cu o comparație structurală-egalitate).
///
///
/// În oricare dintre cele două scenarii de mai sus, respingem utilizarea unei astfel de constante într-o potrivire de tipar.
///
/// Vedeți și [structural match RFC][RFC1445] și [issue 63438] care au motivat migrarea de la proiectarea bazată pe atribute la acest trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait obligatoriu pentru constantele utilizate în potrivirile de tipare.
///
/// Orice tip care derivă `Eq` implementează automat acest trait,*indiferent* dacă parametrii săi de tip implementează `Eq`.
///
/// Acesta este un hack pentru a rezolva o limitare în sistemul nostru de tip.
///
/// # Background
///
/// Vrem să cerem ca tipurile de consts utilizate în potrivirile de tipare să aibă atributul `#[derive(PartialEq, Eq)]`.
///
/// Într-o lume mai ideală, am putea verifica acea cerință doar verificând dacă tipul dat implementează atât `StructuralPartialEq` trait *, cât și*`Eq` trait.
/// Cu toate acestea, puteți avea ADT-uri care *fac*`derive(PartialEq, Eq)` și puteți fi un caz pe care dorim ca compilatorul să-l accepte, și totuși tipul constantei nu reușește să implementeze `Eq`.
///
/// Și anume, un caz ca acesta:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problema din codul de mai sus este că `Wrap<fn(&())>` nu implementează `PartialEq` și nici `Eq`, deoarece `pentru <'a> fn(&'a _)` does not implement those traits.)
///
/// Prin urmare, nu ne putem baza pe verificarea naivă pentru `StructuralPartialEq` și simpla `Eq`.
///
/// Ca un hack pentru a rezolva acest lucru, folosim două traits separate injectate de fiecare dintre cele două derivă (`#[derive(PartialEq)]` și `#[derive(Eq)]`) și verificăm că ambele sunt prezente ca parte a verificării potrivirii structurale.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipuri ale căror valori pot fi duplicate pur și simplu prin copierea biților.
///
/// În mod implicit, legările variabile au " mută semantică`.Cu alte cuvinte:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` s-a mutat în `y` și, prin urmare, nu poate fi utilizat
///
/// // println! ("{: ?}", x);//eroare: utilizarea valorii mutate
/// ```
///
/// Cu toate acestea, dacă un tip implementează `Copy`, are în schimb " semantică de copiere`:
///
/// ```
/// // Putem obține o implementare `Copy`.
/// // `Clone` este, de asemenea, necesar, deoarece este un super-portret de `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` este o copie a `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Este important să rețineți că în aceste două exemple, singura diferență este dacă aveți permisiunea de a accesa `x` după atribuire.
/// Sub capotă, atât o copiere, cât și o mutare pot duce la copierea de biți în memorie, deși aceasta este uneori optimizată.
///
/// ## Cum pot implementa `Copy`?
///
/// Există două moduri de a implementa `Copy` pe tipul dvs.Cel mai simplu este să folosiți `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// De asemenea, puteți implementa manual `Copy` și `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Există o mică diferență între cele două: strategia `derive` va plasa, de asemenea, un `Copy` legat de parametrii de tip, ceea ce nu este întotdeauna dorit.
///
/// ## Care este diferența dintre `Copy` și `Clone`?
///
/// Copiile au loc implicit, de exemplu ca parte a unei sarcini `y = x`.Comportamentul `Copy` nu este supraîncărcabil;este întotdeauna o copie simplă, înțeleaptă.
///
/// Clonarea este o acțiune explicită, `x.clone()`.Implementarea [`Clone`] poate oferi orice tip de comportament specific necesar duplicării în siguranță a valorilor.
/// De exemplu, implementarea [`Clone`] pentru [`String`] trebuie să copieze buffer-ul șir orientat în heap.
/// O copie simplă pe biți a valorilor [`String`] ar copia doar indicatorul, ducând la o dublă liberă în jos.
/// Din acest motiv, [`String`] este [`Clone`], dar nu `Copy`.
///
/// [`Clone`] este o supertraită a lui `Copy`, deci tot ceea ce este `Copy` trebuie să implementeze și [`Clone`].
/// Dacă un tip este `Copy`, atunci implementarea sa [`Clone`] trebuie doar să returneze `*self` (a se vedea exemplul de mai sus).
///
/// ## Când poate fi tipul meu `Copy`?
///
/// Un tip poate implementa `Copy` dacă toate componentele sale implementează `Copy`.De exemplu, această structură poate fi `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// O structură poate fi `Copy`, iar [`i32`] este `Copy`, prin urmare `Point` este eligibil pentru a fi `Copy`.
/// În schimb, ia în considerare
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struct `PointList` nu poate implementa `Copy`, deoarece [`Vec<T>`] nu este `Copy`.Dacă încercăm să obținem o implementare `Copy`, vom primi o eroare:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Referințele partajate (`&T`) sunt, de asemenea, `Copy`, deci un tip poate fi `Copy`, chiar și atunci când deține referințe partajate de tipuri `T` care nu sunt *X*`Copy`.
/// Luați în considerare următoarea structură, care poate implementa `Copy`, deoarece conține doar o *referință partajată* la tipul nostru XC01X non-copiat de mai sus:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Când *nu poate* tipul meu să fie `Copy`?
///
/// Unele tipuri nu pot fi copiate în siguranță.De exemplu, copierea `&mut T` ar crea o referință mutabilă aliasată.
/// Copierea [`String`] ar duplica responsabilitatea pentru gestionarea bufferului [" String`], ducând la o dublă gratuită.
///
/// Generalizând ultimul caz, orice tip care implementează [`Drop`] nu poate fi `Copy`, deoarece gestionează unele resurse în afară de propriii octeți [`size_of::<T>`].
///
/// Dacă încercați să implementați `Copy` pe o structură sau enum care conține date care nu sunt " Copiere`, veți primi eroarea [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Când *ar trebui* ca tipul meu să fie `Copy`?
///
/// În general, dacă tipul dvs. _can_ implementează `Copy`, ar trebui.
/// Rețineți, însă, că implementarea `Copy` face parte din API-ul public de tipul dvs.
/// Dacă tipul ar putea deveni non-Copiere în future, ar putea fi prudent să omiteți implementarea `Copy` acum, pentru a evita o modificare a API-ului.
///
/// ## Implementatori suplimentari
///
/// În plus față de [implementors listed below][impls], următoarele tipuri implementează și `Copy`:
///
/// * Tipuri de elemente de funcție (de exemplu, tipurile distincte definite pentru fiecare funcție)
/// * Tipuri de pointer funcțional (de ex., `fn() -> i32`)
/// * Tipuri de matrice, pentru toate dimensiunile, dacă tipul articolului implementează și `Copy` (de exemplu, `[i32; 123456]`)
/// * Tipuri de tupluri, dacă fiecare componentă implementează și `Copy` (de exemplu, `()`, `(i32, bool)`)
/// * Tipuri de închidere, dacă nu captează nicio valoare din mediul înconjurător sau dacă toate aceste valori capturate implementează singuri `Copy`.
///   Rețineți că variabilele capturate prin referință partajată implementează întotdeauna `Copy` (chiar dacă referentul nu), în timp ce variabilele capturate prin referință mutabilă nu implementează niciodată `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Acest lucru permite copierea unui tip care nu implementează `Copy` din cauza unor limite de viață nesatisfăcute (copierea `A<'_>` când doar `A<'static>: Copy` și `A<'_>: Clone`).
// Avem acest atribut aici deocamdată doar pentru că există destul de multe specializări existente pe `Copy` care există deja în biblioteca standard și nu există nicio modalitate de a avea acest comportament în siguranță chiar acum.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Derivați macro care generează un impl al trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipuri pentru care este sigur să partajați referințe între fire.
///
/// Acest trait este implementat automat atunci când compilatorul determină că este adecvat.
///
/// Definiția precisă este: un tip `T` este [`Sync`] dacă și numai dacă `&T` este [`Send`].
/// Cu alte cuvinte, dacă nu există nicio posibilitate de [undefined behavior][ub] (inclusiv cursele de date) la trecerea referințelor `&T` între fire.
///
/// Așa cum ne-am aștepta, tipurile primitive precum [`u8`] și [`f64`] sunt toate [`Sync`], la fel și tipurile simple de agregate care le conțin, cum ar fi tupluri, structuri și enumere.
/// Mai multe exemple de tipuri [`Sync`] de bază includ tipurile "immutable" precum `&T` și cele cu mutabilitate moștenită simplă, cum ar fi [`Box<T>`][box], [`Vec<T>`][vec] și majoritatea celorlalte tipuri de colecție.
///
/// (Parametrii generici trebuie să fie [`Sync`] pentru ca containerul lor să fie [" Sincronizare`].)
///
/// O consecință oarecum surprinzătoare a definiției este că `&mut T` este `Sync` (dacă `T` este `Sync`), chiar dacă se pare că ar putea oferi mutație nesincronizată.
/// Trucul este că o referință mutabilă din spatele unei referințe partajate (adică `& &mut T`) devine numai în citire, ca și cum ar fi un `& &T`.
/// Prin urmare, nu există riscul unei curse de date.
///
/// Tipurile care nu sunt `Sync` sunt cele care au "interior mutability" într-o formă non-thread-safe, cum ar fi [`Cell`][cell] și [`RefCell`][refcell].
/// Aceste tipuri permit mutarea conținutului lor chiar și printr-o referință imuabilă, partajată.
/// De exemplu, metoda `set` pe [`Cell<T>`][cell] ia `&self`, deci necesită doar o referință partajată [`&Cell<T>`][cell].
/// Metoda nu efectuează sincronizare, astfel [`Cell`][cell] nu poate fi `Sync`.
///
/// Un alt exemplu de tip non-Sync este indicatorul [`Rc`][rc] de numărare a referințelor.
/// Având în vedere orice referință [`&Rc<T>`][rc], puteți clona un nou [`Rc<T>`][rc], modificând numărul de referințe într-un mod non-atomic.
///
/// Pentru cazurile în care cineva are nevoie de mutabilitate interioară sigură la fir, Rust oferă [atomic data types], precum și blocare explicită prin [`sync::Mutex`][mutex] și [`sync::RwLock`][rwlock].
/// Aceste tipuri asigură că orice mutație nu poate provoca curse de date, prin urmare tipurile sunt `Sync`.
/// În mod similar, [`sync::Arc`][arc] oferă un analog analogic [`Rc`][rc].
///
/// Orice tip cu mutabilitate interioară trebuie să utilizeze, de asemenea, învelitoarea [`cell::UnsafeCell`][unsafecell] din jurul value(s), care poate fi mutată printr-o referință partajată.
/// Eșecul de a face acest lucru este [undefined behavior][ub].
/// De exemplu, [`transmute`][transmute]-ing de la `&T` la `&mut T` este nevalid.
///
/// Consultați [the Nomicon][nomicon-send-and-sync] pentru mai multe detalii despre `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): odată ce suportul pentru adăugarea de note în `rustc_on_unimplemented` aterizează în versiune beta și a fost extins pentru a verifica dacă o închidere se află oriunde în lanțul de cerințe, extindeți-o ca atare (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipul de dimensiuni zero folosit pentru a marca lucrurile pe care "act like" le dețin un `T`.
///
/// Adăugarea unui câmp `PhantomData<T>` la tipul dvs. îi spune compilatorului că tipul dvs. acționează ca și cum ar stoca o valoare de tipul `T`, chiar dacă nu chiar.
/// Aceste informații sunt utilizate atunci când se calculează anumite proprietăți de siguranță.
///
/// Pentru o explicație mai detaliată a modului de utilizare a `PhantomData<T>`, vă rugăm să consultați [the Nomicon](../../nomicon/phantom-data.html).
///
/// # O notă groaznică 👻👻👻
///
/// Deși ambele au nume înfricoșătoare, `PhantomData` și " tipurile fantomă` sunt înrudite, dar nu identice.Un parametru de tip fantomă este pur și simplu un parametru de tip care nu este folosit niciodată.
/// În Rust, acest lucru determină adesea compilatorul să se plângă, iar soluția este să adăugați o utilizare "dummy" prin `PhantomData`.
///
/// # Examples
///
/// ## Parametri de viață neutilizați
///
/// Poate cel mai frecvent caz de utilizare pentru `PhantomData` este o structură care are un parametru de viață neutilizat, de obicei ca parte a unui cod nesigur.
/// De exemplu, aici este o struct `Slice` care are două pointeri de tipul `*const T`, care indică probabil într-o matrice undeva:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Intenția este ca datele subiacente să fie valabile numai pentru durata de viață `'a`, deci `Slice` nu ar trebui să supraviețuiască `'a`.
/// Cu toate acestea, această intenție nu este exprimată în cod, deoarece nu există utilizări ale duratei de viață `'a` și, prin urmare, nu este clar la ce date se aplică.
/// Putem corecta acest lucru spunând compilatorului să acționeze *ca și cum* structura `Slice` ar conține o referință `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// La rândul său, acest lucru necesită adnotarea `T: 'a`, indicând faptul că orice referințe din `T` sunt valabile pe toată durata de viață `'a`.
///
/// Când inițializați un `Slice`, furnizați pur și simplu valoarea `PhantomData` pentru câmpul `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parametri de tip neutilizați
///
/// Uneori se întâmplă să aveți parametri de tip neutilizați care indică ce tip de date este o structură "tied", chiar dacă aceste date nu sunt de fapt găsite în structura în sine.
/// Iată un exemplu în care acest lucru apare cu [FFI].
/// Interfața străină folosește mânere de tip `*mut ()` pentru a se referi la valorile Rust de diferite tipuri.
/// Urmărim tipul Rust folosind un parametru de tip fantomă pe struct `ExternalResource` care înfășoară un mâner.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Proprietate și verificare de renunțare
///
/// Adăugarea unui câmp de tip `PhantomData<T>` indică faptul că tipul dvs. deține date de tip `T`.La rândul său, acest lucru implică faptul că atunci când tipul dvs. este abandonat, acesta poate renunța la una sau mai multe instanțe de tipul `T`.
/// Acest lucru are legătură cu analiza [drop check] a compilatorului Rust.
///
/// Dacă structura dvs. nu deține *de fapt* datele de tipul `T`, este mai bine să utilizați un tip de referință, cum ar fi `PhantomData<&'a T>` (ideally) sau `PhantomData<*const T>` (dacă nu se aplică durata de viață), pentru a nu indica proprietatea.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// trait intern al compilatorului folosit pentru a indica tipul discriminanților enum.
///
/// Acest trait este implementat automat pentru fiecare tip și nu adaugă nicio garanție pentru [`mem::Discriminant`].
/// Este **comportament nedefinit** transmutarea între `DiscriminantKind::Discriminant` și `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Tipul discriminantului, care trebuie să satisfacă trait bounds cerut de `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait intern al compilatorului folosit pentru a determina dacă un tip conține intern `UnsafeCell`, dar nu printr-o indirectare.
///
/// Acest lucru afectează, de exemplu, dacă un `static` de acest tip este plasat în memorie statică numai în citire sau în memorie statică înscriibilă.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipuri care pot fi mutate în siguranță după ce au fost fixate.
///
/// Rust în sine nu are noțiune de tipuri imobile și consideră că mișcările (de exemplu, prin atribuire sau [`mem::replace`]) sunt întotdeauna sigure.
///
/// Tipul [`Pin`][Pin] este folosit în schimb pentru a preveni mișcările prin sistemul de tip.Pointerele `P<T>` înfășurate în ambalajul [`Pin<P<T>>`][Pin] nu pot fi mutate din.
/// Consultați documentația [`pin` module] pentru mai multe informații despre fixare.
///
/// Implementarea `Unpin` trait pentru `T` ridică restricțiile de fixare a tipului, care apoi permite mutarea `T` din [`Pin<P<T>>`][Pin] cu funcții precum [`mem::replace`].
///
///
/// `Unpin` nu are deloc consecințe pentru datele care nu sunt fixate.
/// În special, [`mem::replace`] mută fericit datele `!Unpin` (funcționează pentru orice `&mut T`, nu doar când `T: Unpin`).
/// Cu toate acestea, nu puteți utiliza [`mem::replace`] pe datele împachetate într-un [`Pin<P<T>>`][Pin], deoarece nu puteți obține `&mut T` de care aveți nevoie pentru asta, și *asta* este ceea ce face ca acest sistem să funcționeze.
///
/// Deci, acest lucru, de exemplu, se poate face numai pe tipurile care implementează `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Avem nevoie de o referință mutabilă pentru a apela `mem::replace`.
/// // Putem obține o astfel de referință prin (implicitly) invocând `Pin::deref_mut`, dar acest lucru este posibil doar deoarece `String` implementează `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Acest trait este implementat automat pentru aproape fiecare tip.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Un tip de marker care nu implementează `Unpin`.
///
/// Dacă un tip conține un `PhantomPinned`, acesta nu va implementa `Unpin` în mod implicit.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementări ale `Copy` pentru tipurile primitive.
///
/// Implementările care nu pot fi descrise în Rust sunt implementate în `traits::SelectionContext::copy_clone_conditions()` în `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Referințele partajate pot fi copiate, dar referințele mutabile *nu pot*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}