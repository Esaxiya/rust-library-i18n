//! Libcore prelude
//!
//! Acest modul este destinat utilizatorilor libcore care nu se leagă la libstd.
//! Acest modul este importat implicit atunci când `#![no_std]` este utilizat în același mod ca prelude al bibliotecii standard.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Versiunea 2015 a nucleului prelude.
///
/// Vedeți [module-level documentation](self) pentru mai multe.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versiunea 2018 a nucleului prelude.
///
/// Vedeți [module-level documentation](self) pentru mai multe.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versiunea 2021 a nucleului prelude.
///
/// Vedeți [module-level documentation](self) pentru mai multe.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Adăugați mai multe lucruri.
}