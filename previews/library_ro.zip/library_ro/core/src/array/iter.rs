//! Definește iteratorul `IntoIter` pentru matrice.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Un iterator [array] secundar.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Acesta este tabloul pe care îl iterăm.
    ///
    /// Elemente cu index `i` unde `alive.start <= i < alive.end` nu au fost încă cedate și sunt intrări valide în matrice.
    /// Elementele cu indicii `i < alive.start` sau `i >= alive.end` au fost deja cedate și nu mai trebuie accesate!Aceste elemente moarte ar putea fi chiar într-o stare complet neinițială!
    ///
    ///
    /// Deci invarianții sunt:
    /// - `data[alive]` este viu (adică conține elemente valide)
    /// - `data[..alive.start]` și `data[alive.end..]` sunt moarte (adică elementele au fost deja citite și nu mai trebuie atinse!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elementele din `data` care nu au fost încă cedate.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Creează un nou iterator peste `array` dat.
    ///
    /// *Notă*: această metodă ar putea fi depreciată în future, după [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Tipul `value` este un `i32` aici, în loc de `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SIGURANȚĂ: Transmutația de aici este de fapt sigură.Documentele `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` este garantat să aibă aceeași dimensiune și aliniere
        // > ca `T`.
        //
        // Documentele arată chiar o transmutare de la o matrice de `MaybeUninit<T>` la o matrice de `T`.
        //
        //
        // Cu aceasta, această inițializare satisface invarianții.

        // FIXME(LukasKalbertodt): folosiți de fapt `mem::transmute` aici, odată ce funcționează cu generice const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Până atunci, putem folosi `mem::transmute_copy` pentru a crea o copie bit în formă de tip diferit, apoi uităm de `array` astfel încât să nu fie scăpat.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Returnează o felie imuabilă a tuturor elementelor care nu au fost încă cedate.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SIGURANȚĂ: Știm că toate elementele din `alive` sunt inițializate corect.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Returnează o porțiune mutabilă a tuturor elementelor care nu au fost încă cedate.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SIGURANȚĂ: Știm că toate elementele din `alive` sunt inițializate corect.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Obțineți următorul index din față.
        //
        // Creșterea `alive.start` cu 1 menține invariantul în ceea ce privește `alive`.
        // Cu toate acestea, datorită acestei modificări, pentru o perioadă scurtă de timp, zona vie nu mai este `data[alive]`, ci `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Citiți elementul din matrice.
            // SIGURANȚĂ: `idx` este un index în fosta regiune "alive" a
            // matrice.Citirea acestui element înseamnă că `data[idx]` este considerat mort acum (adică nu atingeți).
            // Deoarece `idx` a fost începutul zonei vii, zona vie este acum din nou `data[alive]`, restabilind toți invarianții.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Obțineți următorul index din spate.
        //
        // Scăderea `alive.end` cu 1 menține invariantul în ceea ce privește `alive`.
        // Cu toate acestea, datorită acestei modificări, pentru o perioadă scurtă de timp, zona vie nu mai este `data[alive]`, ci `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Citiți elementul din matrice.
            // SIGURANȚĂ: `idx` este un index în fosta regiune "alive" a
            // matrice.Citirea acestui element înseamnă că `data[idx]` este considerat mort acum (adică nu atingeți).
            // Deoarece `idx` a fost sfârșitul zonei vii, zona vie este acum din nou `data[alive]`, restabilind toți invarianții.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SIGURANȚĂ: Acest lucru este sigur: `as_mut_slice` returnează exact sub-felia
        // de elemente care nu au fost încă mutate și care rămân de abandonat.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nu se va revărsa niciodată din cauza invariantului `viu.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteratorul raportează într-adevăr lungimea corectă.
// Numărul de elemente "alive" (care va fi încă cedat) este lungimea intervalului `alive`.
// Această gamă este diminuată în lungime fie în `next`, fie în `next_back`.
// Este întotdeauna decrementat cu 1 în aceste metode, dar numai dacă `Some(_)` este returnat.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Rețineți, nu trebuie să potrivim cu exact același interval viu, deci putem doar să clonăm în offset 0 indiferent de locul în care se află `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clonează toate elementele vii.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Scrieți o clonă în noua matrice, apoi actualizați-o.
            // Dacă clonăm panics, vom renunța corect la elementele anterioare.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Imprimați doar elementele care nu au fost cedate încă: nu mai putem accesa elementele cedate.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}