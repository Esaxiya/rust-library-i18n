#![stable(feature = "core_hint", since = "1.27.0")]

//! Sugestii pentru compilator care afectează modul în care codul trebuie emis sau optimizat.
//! Indiciile pot fi timpul de compilare sau timpul de execuție.

use crate::intrinsics;

/// Informează compilatorul că acest punct din cod nu este accesibil, permițând optimizări suplimentare.
///
/// # Safety
///
/// Atingerea acestei funcții este complet *comportament nedefinit*(UB).În special, compilatorul presupune că toate UB nu trebuie să se întâmple niciodată și, prin urmare, vor elimina toate ramurile care ajung la un apel către `unreachable_unchecked()`.
///
/// La fel ca toate cazurile de UB, dacă această ipoteză se dovedește a fi greșită, adică apelul `unreachable_unchecked()` este de fapt accesibil între toate fluxurile de control posibile, compilatorul va aplica o strategie de optimizare greșită și, uneori, poate chiar corupe codul aparent fără legătură, cauzând probleme de depanare.
///
///
/// Utilizați această funcție numai atunci când puteți demonstra că codul nu o va numi niciodată.
/// În caz contrar, luați în considerare utilizarea macro-ului [`unreachable!`], care nu permite optimizări, dar va panic atunci când este executat.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` este întotdeauna pozitiv (nu zero), prin urmare `checked_div` nu va returna niciodată `None`.
/////
///     // Prin urmare, celălalt branch este inaccesibil.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SIGURANȚĂ: contractul de siguranță pentru `intrinsics::unreachable` trebuie
    // să fie confirmat de apelant.
    unsafe { intrinsics::unreachable() }
}

/// Emite o instrucțiune a mașinii pentru a semnala procesorului că rulează într-o buclă de rotire ocupată-așteptată (" blocare rotire`).
///
/// La primirea semnalului spin-loop, procesorul își poate optimiza comportamentul, de exemplu, economisind energie sau comutând firele hyper.
///
/// Această funcție este diferită de [`thread::yield_now`] care cedează direct planificatorului sistemului, în timp ce `spin_loop` nu interacționează cu sistemul de operare.
///
/// Un caz de utilizare obișnuit pentru `spin_loop` este implementarea filării optimiste mărginite într-o buclă CAS în primitive de sincronizare.
/// Pentru a evita probleme, cum ar fi inversarea prioritară, se recomandă insistent ca bucla de centrifugare să fie terminată după o cantitate finită de iterații și să se facă o blocare adecvată.
///
///
/// **Notă**: Pe platformele care nu acceptă primirea de indicii de tip spin-loop această funcție nu face deloc nimic.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // O valoare atomică partajată pe care firele o vor folosi pentru coordonare
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Într-un fir de fundal vom seta în cele din urmă valoarea
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Faceți ceva de lucru, apoi faceți ca valoarea să fie trăită
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Revenind la firul nostru actual, așteptăm să fie setată valoarea
/// while !live.load(Ordering::Acquire) {
///     // Bucla de rotire este un indiciu pentru CPU pe care îl așteptăm, dar probabil nu pentru foarte mult timp
/////
///     hint::spin_loop();
/// }
///
/// // Valoarea este acum setată
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SIGURANȚĂ: `cfg` attr ne asigură că executăm acest lucru numai pe țintele x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SIGURANȚĂ: `cfg` attr ne asigură că executăm acest lucru numai pe țintele x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SIGURANȚĂ: `cfg` attr ne asigură că executăm acest lucru numai pe țintele aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SIGURANȚĂ: `cfg` attr ne asigură că executăm acest lucru numai pe ținte de braț
            // cu suport pentru caracteristica v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// O funcție de identitate care *__ sugerează __* compilatorului pentru a fi maxim pesimistă cu privire la ceea ce `black_box` ar putea face.
///
/// Spre deosebire de [`std::convert::identity`], un compilator Rust este încurajat să presupună că `black_box` poate utiliza `dummy` în orice mod valid posibil în care codul Rust este permis fără a introduce comportament nedefinit în codul de apelare.
///
/// Această proprietate face `black_box` util pentru scrierea codului în care nu sunt dorite anumite optimizări, cum ar fi benchmark-urile.
///
/// Rețineți însă că `black_box` este furnizat numai (și poate fi furnizat numai) pe baza "best-effort".Măsura în care poate bloca optimizările poate varia în funcție de platformă și de backend-ul cod-gen utilizat.
/// Programele nu se pot baza pe `black_box` pentru *corectitudine* în niciun fel.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Trebuie să "use" argumentul într-un fel LLVM nu poate introspecta, iar asupra țintelor care îl susțin putem folosi de obicei asamblarea în linie pentru a face acest lucru.
    // Interpretarea LLVM a ansamblului în linie este că este, bine, o cutie neagră.
    // Aceasta nu este cea mai mare implementare, deoarece probabil că dezoptimizează mai mult decât ne dorim, dar până acum este suficient de bună.
    //
    //

    #[cfg(not(miri))] // Acesta este doar un indiciu, deci este bine să omiteți Miri.
    // SIGURANȚĂ: ansamblul în linie este fără opțiuni.
    unsafe {
        // FIXME: Nu se poate utiliza `asm!` deoarece nu acceptă MIPS și alte arhitecturi.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}