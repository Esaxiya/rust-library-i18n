// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rotește intervalul `[mid-left, mid+right)` astfel încât elementul de la `mid` să devină primul element.În mod echivalent, rotește gama `left` elemente la stânga sau `right` elemente la dreapta.
///
/// # Safety
///
/// Intervalul specificat trebuie să fie valid pentru citire și scriere.
///
/// # Algorithm
///
/// Algoritmul 1 este utilizat pentru valori mici de `left + right` sau pentru `T` mari.
/// Elementele sunt mutate în pozițiile lor finale unul câte unul începând cu `mid - left` și avansând cu pașii `right` modulo `left + right`, astfel încât este nevoie de un singur temporar.
/// În cele din urmă, ajungem înapoi la `mid - left`.
/// Cu toate acestea, dacă `gcd(left + right, right)` nu este 1, pașii de mai sus au trecut peste elemente.
/// De exemplu:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Din fericire, numărul de elemente omise între elementele finalizate este întotdeauna egal, deci putem doar să ne compensăm poziția de plecare și să facem mai multe runde (numărul total de runde este `gcd(left + right, right)` value).
///
/// Rezultatul final este că toate elementele sunt finalizate o singură dată.
///
/// Algoritmul 2 este utilizat dacă `left + right` este mare, dar `min(left, right)` este suficient de mic pentru a se potrivi pe un buffer de stivă.
/// Elementele `min(left, right)` sunt copiate pe tampon, `memmove` se aplică celorlalte, iar cele de pe tampon sunt mutate înapoi în orificiul de pe partea opusă de unde au provenit.
///
/// Algoritmii care pot fi vectorizați depășesc cele de mai sus odată ce `left + right` devine suficient de mare.
/// Algoritmul 1 poate fi vectorizat prin fragmentare și efectuarea mai multor runde simultan, dar există prea puține runde în medie până când `left + right` este enorm, iar cel mai rău caz al unei singure runde este întotdeauna acolo.
/// În schimb, algoritmul 3 utilizează schimbarea repetată a elementelor `min(left, right)` până când este lăsată o problemă de rotire mai mică.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// când `left < right` schimbul are loc în schimb din stânga.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algoritmii de mai jos pot eșua dacă aceste cazuri nu sunt verificate
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritmul 1 Microbenchmark-urile indică faptul că performanța medie pentru schimbările aleatorii este mai bună până la aproximativ `left + right == 32`, dar cel mai rău caz este de aproximativ 16.
            // 24 a fost ales ca punct de mijloc.
            // Dacă dimensiunea `T` este mai mare de 4 `usize`s, acest algoritm depășește și alți algoritmi.
            //
            //
            let x = unsafe { mid.sub(left) };
            // începutul primei runde
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` poate fi găsit înainte de mână, calculând `gcd(left + right, right)`, dar este mai rapid să faci o buclă care calculează gcd ca efect secundar, apoi să faci restul bucății
            //
            //
            let mut gcd = right;
            // reperele arată că este mai rapid să schimbați temporare până la capăt, în loc să citiți o singură dată temporar, să copiați înapoi și apoi să scrieți acel temporar chiar la sfârșit.
            // Acest lucru se datorează, probabil, faptului că schimbarea sau înlocuirea temporară utilizează o singură adresă de memorie în buclă în loc să fie nevoie să gestioneze două.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // în loc să incrementăm `i` și apoi să verificăm dacă este în afara limitelor, verificăm dacă `i` va ieși în afara limitelor la următorul increment.
                // Acest lucru previne orice înfășurare a pointerelor sau `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // sfârșitul primei runde
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // acest condițional trebuie să fie aici dacă `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // termina bucata cu mai multe runde
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nu este de tip zero, deci este bine să împărțiți la dimensiunea sa.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmul 2 `[T; 0]` aici este pentru a vă asigura că acesta este aliniat corespunzător pentru T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmul 3 Există o modalitate alternativă de swaping care implică găsirea locului în care ar fi ultimul swap al acestui algoritm și schimbarea folosind ultimul bloc în loc să schimbe bucăți adiacente, așa cum face acest algoritm, dar acest mod este încă mai rapid.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmul 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}