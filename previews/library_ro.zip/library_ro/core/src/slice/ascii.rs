//! Operații pe ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Verifică dacă toți octeții din această porțiune se încadrează în intervalul ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Verifică dacă două felii sunt o potrivire ASCII care nu face sensibilitate la majuscule.
    ///
    /// La fel ca `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, dar fără alocarea și copierea temporară.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Convertește această secțiune în echivalentul ASCII cu majuscule la locul său.
    ///
    /// Literele ASCII 'a' la 'z' sunt mapate la 'A' la 'Z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a returna o nouă valoare cu majusculă fără a o modifica pe cea existentă, utilizați [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Convertește această secțiune în echivalentul său ASCII minuscul în loc.
    ///
    /// Literele ASCII 'A' la 'Z' sunt mapate la 'a' la 'z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a returna o nouă valoare cu litere mici, fără a o modifica pe cea existentă, utilizați [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Returnează `true` dacă orice octet din cuvântul `v` este nonascii (>=128).
/// Snarfed de la `../str/mod.rs`, care face ceva similar pentru validarea utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Test ASCII optimizat, care va utiliza operațiuni de utilizare la rând în loc de operații de octeți la un moment dat (atunci când este posibil).
///
/// Algoritmul pe care îl folosim aici este destul de simplu.Dacă `s` este prea scurt, verificăm fiecare octet și terminăm cu acesta.In caz contrar:
///
/// - Citiți primul cuvânt cu o încărcare nealiniată.
/// - Aliniați indicatorul, citiți cuvintele ulterioare până la capăt cu sarcini aliniate.
/// - Citiți ultimul `usize` de la `s` cu o încărcare nealiniată.
///
/// Dacă oricare dintre aceste încărcări produce ceva pentru care `contains_nonascii` (above) revine adevărat, atunci știm că răspunsul este fals.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Dacă nu am câștiga nimic din implementarea cuvânt la un moment dat, reveniți la o buclă scalară.
    //
    // Facem acest lucru și pentru arhitecturi în care `size_of::<usize>()` nu este suficient alinierea pentru `usize`, deoarece este un caz ciudat edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Citim întotdeauna primul cuvânt nealiniat, ceea ce înseamnă că `align_offset` este
    // 0, am citi din nou aceeași valoare pentru citirea aliniată.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SIGURANȚĂ: Verificăm `len < USIZE_SIZE` de mai sus.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Am verificat acest lucru mai sus, oarecum implicit.
    // Rețineți că `offset_to_aligned` este fie `align_offset`, fie `USIZE_SIZE`, ambele fiind verificate explicit mai sus.
    //
    debug_assert!(offset_to_aligned <= len);

    // SIGURANȚĂ: word_ptr este ptr-ul de utilizare (corect aliniat) pe care îl folosim pentru a citi
    // bucata mijlocie a feliei.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` este indexul de octeți al `word_ptr`, utilizat pentru verificările de capăt de buclă.
    let mut byte_pos = offset_to_aligned;

    // Verificați paranoia despre aliniere, deoarece suntem pe punctul de a face o grămadă de încărcături nealiniate.
    // În practică, acest lucru ar trebui să fie imposibil, cu excepția unui bug în `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Citiți cuvintele ulterioare până la ultimul cuvânt aliniat, excluzând singur cuvântul aliniat care va fi efectuat ulterior în verificarea cozii, pentru a vă asigura că coada este întotdeauna cel mult `usize` până la branch `byte_pos == len` suplimentar.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanatate verificați dacă citirea este în limite
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Și că ipotezele noastre despre `byte_pos` sunt valabile.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SIGURANȚĂ: Știm că `word_ptr` este aliniat corect (din cauza
        // `align_offset`) și știm că avem suficienți octeți între `word_ptr` și final
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SIGURANȚĂ: Știm `byte_pos <= len - USIZE_SIZE`, ceea ce înseamnă asta
        // după acest `add`, `word_ptr` va fi cel mult la un sfârșit.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Verificați sănătatea pentru a vă asigura că rămâne cu adevărat doar un `usize`.
    // Acest lucru ar trebui să fie garantat de starea noastră de buclă.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SIGURANȚĂ: Aceasta se bazează pe `len >= USIZE_SIZE`, pe care îl verificăm la început.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}