//! Funcții gratuite pentru a crea `&[T]` și `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Formează o felie dintr-un pointer și o lungime.
///
/// Argumentul `len` este numărul de **elemente**, nu numărul de octeți.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `data` trebuie să fie [valid] pentru citiri pentru `len * mem::size_of::<T>()` mulți octeți și trebuie să fie aliniat corespunzător.Aceasta înseamnă în special:
///
///     * Întreaga gamă de memorie a acestei felii trebuie să fie conținută într-un singur obiect alocat!
///       Feliile nu se pot întinde niciodată pe mai multe obiecte alocate.A se vedea [below](#incorrect-usage) pentru un exemplu incorect, care nu ia în considerare acest lucru.
///     * `data` trebuie să fie nenule și aliniate chiar și pentru felii de lungime zero.
///     Un motiv pentru aceasta este că optimizările de enumere ale aspectului se pot baza pe referințe (inclusiv felii de orice lungime) aliniate și care nu sunt nule pentru a le distinge de alte date.
///     Puteți obține un indicator care poate fi utilizat ca `data` pentru felii de lungime zero folosind [`NonNull::dangling()`].
///
/// * `data` trebuie să indice spre `len` consecutiv valorile inițializate corespunzător de tipul `T`.
///
/// * Memoria la care face referire felia returnată nu trebuie mutată pe durata de viață `'a`, cu excepția unui `UnsafeCell`.
///
/// * Dimensiunea totală `len * mem::size_of::<T>()` a feliei nu trebuie să fie mai mare decât `isize::MAX`.
///   Consultați documentația de siguranță a [`pointer::offset`].
///
/// # Caveat
///
/// Durata de viață pentru felia returnată este dedusă din utilizarea sa.
/// Pentru a preveni utilizarea abuzivă accidentală, se sugerează legarea duratei de viață cu oricare durată de viață sursă este sigură în context, cum ar fi furnizarea unei funcții de asistență care durează durata de viață a unei valori gazdă pentru felie sau prin adnotare explicită.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestă o felie pentru un singur element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Utilizare incorectă
///
/// Următoarea funcție `join_slices` este **neîntemeiată** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Afirmația de mai sus asigură că `fst` și `snd` sunt adiacente, dar ar putea fi încă conținute în _different allocated objects_, caz în care crearea acestei porțiuni este un comportament nedefinit.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` și `b` sunt diferite obiecte alocate ...
///     let a = 42;
///     let b = 27;
///     // ... care poate fi totuși prezentat contiguu în memorie: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Efectuează aceeași funcționalitate ca și [`from_raw_parts`], cu excepția faptului că se restituie o porțiune mutabilă.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `data` trebuie să fie [valid] atât pentru citiri cât și pentru scrieri pentru `len * mem::size_of::<T>()` mulți octeți și trebuie aliniat corect.Aceasta înseamnă în special:
///
///     * Întreaga gamă de memorie a acestei felii trebuie să fie conținută într-un singur obiect alocat!
///       Feliile nu se pot întinde niciodată pe mai multe obiecte alocate.
///     * `data` trebuie să fie nenule și aliniate chiar și pentru felii de lungime zero.
///     Un motiv pentru aceasta este că optimizările de enumere ale aspectului se pot baza pe referințe (inclusiv felii de orice lungime) aliniate și care nu sunt nule pentru a le distinge de alte date.
///
///     Puteți obține un indicator care poate fi utilizat ca `data` pentru felii de lungime zero folosind [`NonNull::dangling()`].
///
/// * `data` trebuie să indice spre `len` consecutiv valorile inițializate corespunzător de tipul `T`.
///
/// * Memoria la care face referire felia returnată nu trebuie accesată prin niciun alt indicator (care nu derivă din valoarea returnată) pe durata de viață `'a`.
///   Atât accesele de citire, cât și cele de scriere sunt interzise.
///
/// * Dimensiunea totală `len * mem::size_of::<T>()` a feliei nu trebuie să fie mai mare decât `isize::MAX`.
///   Consultați documentația de siguranță a [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Convertește o referință la T într-o felie de lungime 1 (fără copiere).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Convertește o referință la T într-o felie de lungime 1 (fără copiere).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}