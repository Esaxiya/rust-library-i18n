// Implementare originală preluată de la rust-memchr.
// Copyright 2015 Andrew Gallant, bluss și Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Utilizați trunchierea.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Returnează `true` dacă `x` conține orice octet zero.
///
/// De la *Matters Computational*, J. Arndt:
///
/// " Ideea este să scădem câte unul din fiecare octet și apoi să căutăm octeți în care împrumutul s-a propagat până la cel mai semnificativ
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Returnează primul index care corespunde octetului `x` în `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Calea rapidă pentru felii mici
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Căutați o valoare de un singur octet citind două cuvinte `usize` odată.
    //
    // Împarte `text` în trei părți
    // - partea inițială nealiniată, înainte de prima adresă aliniată în text
    // - corp, scanează câte 2 cuvinte odată
    // - ultima parte rămasă, dimensiunea <2 cuvinte

    // căutați până la o limită aliniată
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // căutați corpul textului
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SIGURANȚĂ: predicatul timpului garantează o distanță de cel puțin 2 * usize_bytes
        // între offset și sfârșitul feliei.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // rupeți dacă există un octet care se potrivește
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Găsiți octetul după punctul în care bucla corpului sa oprit.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Returnează ultimul index care corespunde octetului `x` în `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Căutați o valoare de un singur octet citind două cuvinte `usize` odată.
    //
    // Împărțiți `text` în trei părți:
    // - coadă nealiniată, după ultima adresă aliniată în text,
    // - corp, scanat câte 2 cuvinte pe rând,
    // - primii octeți rămași, dimensiunea <2 cuvinte.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Numim asta doar pentru a obține lungimea prefixului și a sufixului.
        // La mijloc procesăm întotdeauna două bucăți simultan.
        // SIGURANȚĂ: transmutarea `[u8]` la `[usize]` este sigură, cu excepția diferențelor de dimensiune care sunt gestionate de `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Căutați în corpul textului, asigurați-vă că nu traversăm min_aligned_offset.
    // decalajul este întotdeauna aliniat, deci doar testarea `>` este suficientă și evită posibilul revărsare.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SIGURANȚĂ: offsetul începe de la len, suffix.len(), atâta timp cât este mai mare decât
        // min_aligned_offset (prefix.len()) distanța rămasă este de cel puțin 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Se sparge dacă există un octet de potrivire.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Găsiți octetul înainte de punctul în care bucla corpului s-a oprit.
    text[..offset].iter().rposition(|elt| *elt == x)
}