// ignore-tidy-filelength

//! Gestionarea și manipularea feliilor.
//!
//! Pentru mai multe detalii, consultați [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Implementare pură rust memchr, preluată din rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Această funcție este publică numai pentru că nu există o altă modalitate de a testa unitatea de sarcină.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Returnează numărul de elemente din felie.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SIGURANȚĂ: sunet constant, deoarece transmutăm câmpul de lungime ca o utilizare (care trebuie să fie)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIGURANȚĂ: este sigur deoarece `&[T]` și `FatPtr<T>` au același aspect.
            // Doar `std` poate face această garanție.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Înlocuiți cu `crate::ptr::metadata(self)` atunci când este constant.
            // Începând cu această scriere, acest lucru provoacă o eroare "Const-stable functions can only call other const-stable functions".
            //

            // SIGURANȚĂ: Accesarea valorii din uniunea `PtrRepr` este sigură din moment ce * const T
            // și PtrComponents<T>au aceleași aspecte de memorie.
            // Doar std poate face această garanție.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Returnează `true` dacă felia are o lungime de 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Returnează primul element al feliei sau `None` dacă este gol.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnează un indicator mutabil la primul element al feliei sau `None` dacă este gol.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnează primul și toate celelalte elemente ale feliei sau `None` dacă este gol.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnează primul și toate celelalte elemente ale feliei sau `None` dacă este gol.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnează ultimul și toate celelalte elemente ale feliei sau `None` dacă este goală.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnează ultimul și toate celelalte elemente ale feliei sau `None` dacă este goală.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnează ultimul element al feliei sau `None` dacă este gol.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnează un pointer modificabil la ultimul element din felie.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnează o referință la un element sau subsecțiune în funcție de tipul de index.
    ///
    /// - Dacă i se dă o poziție, returnează o referință la elementul din acea poziție sau `None` dacă este în afara limitelor.
    ///
    /// - Dacă i se dă un interval, returnează subslice-ul corespunzător intervalului respectiv sau `None` dacă este în afara limitelor.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Returnează o referință mutabilă la un element sau subsecțiune în funcție de tipul de index (vezi [`get`]) sau `None` dacă indexul este în afara limitelor.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Returnează o referință la un element sau subsecțiune, fără a face verificarea limitelor.
    ///
    /// Pentru o alternativă sigură, consultați [`get`].
    ///
    /// # Safety
    ///
    /// Apelarea acestei metode cu un index în afara limitelor este *[comportament nedefinit]* chiar dacă referința rezultată nu este utilizată.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte cele mai multe dintre cerințele de siguranță pentru `get_unchecked`;
        // felia este dereferențabilă deoarece `self` este o referință sigură.
        // Pointerul returnat este sigur, deoarece instrumentele `SliceIndex` trebuie să garanteze că este.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Returnează o referință mutabilă la un element sau subsecțiune, fără a face verificarea limitelor.
    ///
    /// Pentru o alternativă sigură, consultați [`get_mut`].
    ///
    /// # Safety
    ///
    /// Apelarea acestei metode cu un index în afara limitelor este *[comportament nedefinit]* chiar dacă referința rezultată nu este utilizată.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte cerințele de siguranță pentru `get_unchecked_mut`;
        // felia este dereferențabilă deoarece `self` este o referință sigură.
        // Pointerul returnat este sigur, deoarece instrumentele `SliceIndex` trebuie să garanteze că este.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Returnează un indicator brut în bufferul feliei.
    ///
    /// Apelantul trebuie să se asigure că felia depășește indicatorul pe care îl returnează această funcție, altfel va ajunge să arate gunoiul.
    ///
    /// Apelantul trebuie, de asemenea, să se asigure că memoria către care indică indicatorul (non-transitively) nu este scrisă niciodată (cu excepția unui `UnsafeCell`) folosind acest indicator sau orice alt indicator derivat din acesta.
    /// Dacă trebuie să mutați conținutul feliei, utilizați [`as_mut_ptr`].
    ///
    /// Modificarea containerului la care se face referire prin această felie poate determina realocarea bufferului său, ceea ce ar face, de asemenea, orice indicații către acesta nevalide.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Returnează un pointer mutabil nesigur în bufferul feliei.
    ///
    /// Apelantul trebuie să se asigure că felia depășește indicatorul pe care îl returnează această funcție, altfel va ajunge să arate gunoiul.
    ///
    /// Modificarea containerului la care se face referire prin această felie poate determina realocarea bufferului său, ceea ce ar face, de asemenea, orice indicații către acesta nevalide.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Returnează cele două indicatoare brute care se întind pe felie.
    ///
    /// Intervalul returnat este pe jumătate deschis, ceea ce înseamnă că indicatorul final indică *un trecut* ultimul element al feliei.
    /// În acest fel, o felie goală este reprezentată de doi indicatori egali, iar diferența dintre cele două indicatoare reprezintă dimensiunea feliei.
    ///
    /// Consultați [`as_ptr`] pentru avertismente privind utilizarea acestor indicatoare.Indicatorul final necesită precauție suplimentară, deoarece nu indică un element valid în felie.
    ///
    /// Această funcție este utilă pentru interacțiunea cu interfețe străine care utilizează două indicatoare pentru a se referi la o serie de elemente din memorie, așa cum este obișnuit în C++ .
    ///
    ///
    /// De asemenea, poate fi util să verificați dacă un pointer către un element se referă la un element al acestei felii:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SIGURANȚĂ: `add` aici este sigur, deoarece:
        //
        //   - Ambele indicatoare fac parte din același obiect, deoarece contează și indicarea directă a obiectului.
        //
        //   - Dimensiunea feliei nu este niciodată mai mare decât isize::MAX octeți, după cum sa menționat aici:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Nu există nicio înfășurare implicată, deoarece feliile nu trec peste capătul spațiului de adrese.
        //
        // Consultați documentația pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Returnează cele două indicatoare mutabile nesigure care se întind pe felie.
    ///
    /// Intervalul returnat este pe jumătate deschis, ceea ce înseamnă că indicatorul final indică *un trecut* ultimul element al feliei.
    /// În acest fel, o felie goală este reprezentată de doi indicatori egali, iar diferența dintre cele două indicatoare reprezintă dimensiunea feliei.
    ///
    /// Consultați [`as_mut_ptr`] pentru avertismente privind utilizarea acestor indicatoare.
    /// Indicatorul final necesită precauție suplimentară, deoarece nu indică un element valid în felie.
    ///
    /// Această funcție este utilă pentru interacțiunea cu interfețe străine care utilizează două indicatoare pentru a se referi la o serie de elemente din memorie, așa cum este obișnuit în C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SIGURANȚĂ: Consultați as_ptr_range() de mai sus pentru a afla de ce `add` este sigur.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Schimbă două elemente în felie.
    ///
    /// # Arguments
    ///
    /// * a, Indicele primului element
    /// * b, indicele celui de-al doilea element
    ///
    /// # Panics
    ///
    /// Panics dacă `a` sau `b` sunt în afara limitelor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Nu pot lua două împrumuturi mutabile dintr-un singur vector, deci folosiți în schimb indicii brute.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SIGURANȚĂ: `pa` și `pb` au fost create din referințe și referințe mutabile sigure
        // la elementele din felie și, prin urmare, sunt garantate pentru a fi valide și aliniate.
        // Rețineți că accesarea elementelor din spatele `a` și `b` este bifată și va panic atunci când este în afara limitelor.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Inversează ordinea elementelor din felie, la locul său.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Pentru tipurile foarte mici, toate citirile individuale pe calea normală au performanțe slabe.
        // Ne putem descurca mai bine, având în vedere load/store eficient nealiniat, încărcând o bucată mai mare și inversând un registru.
        //

        // În mod ideal, LLVM ar face acest lucru pentru noi, deoarece știe mai bine decât noi dacă citirile nealiniate sunt eficiente (deoarece schimbările între diferite versiuni ARM, de exemplu) și care ar fi cea mai bună dimensiune a bucății.
        // Din păcate, începând cu LLVM 4.0 (2017-05), acesta derulează doar bucla, așa că trebuie să facem acest lucru noi înșine.
        // (Ipoteza: inversarea este supărătoare deoarece laturile pot fi aliniate diferit-va fi, atunci când lungimea este impară-deci nu există nicio modalitate de a emite pre și postludii pentru a utiliza SIMD complet aliniat în mijloc.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Utilizați llvm.bswap intrinsec pentru a inversa u8-urile într-o utilizare
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SIGURANȚĂ: Există mai multe lucruri de verificat aici:
                //
                // - Rețineți că `chunk` este fie 4, fie 8 datorită verificării cfg de mai sus.Deci `chunk - 1` este pozitiv.
                // - Indexarea cu indexul `i` este bună, așa cum garantează verificarea buclei
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indexarea cu indexul `ln - i - chunk = ln - (i + chunk)` este bună:
                //   - `i + chunk > 0` este trivial adevărat.
                //   - Verificarea buclei garantează:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, prin urmare scăderea nu este infundată.
                // - Apelurile `read_unaligned` și `write_unaligned` sunt în regulă:
                //   - `pa` indică indicele `i` unde `i < ln / 2 - (chunk - 1)` (a se vedea mai sus) și `pb` indică indicele `ln - i - chunk`, deci ambele sunt cel puțin `chunk` la mulți octeți distanță de sfârșitul lui `self`.
                //
                //   - Orice memorie inițializată este validă `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Utilizați rotirea cu 16 pentru a inversa u16-urile într-un u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SIGURANȚĂ: Un u32 nealiniat poate fi citit din `i` dacă `i + 1 < ln`
                // (și evident `i < ln`), deoarece fiecare element are 2 octeți și citim 4.
                //
                // `i + chunk - 1 < ln / 2` # în timp ce starea
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Deoarece este mai mică decât lungimea împărțită la 2, atunci trebuie să fie în limite.
                //
                // Aceasta înseamnă, de asemenea, că condiția `0 < i + chunk <= ln` este întotdeauna respectată, asigurându-se că pointerul `pb` poate fi utilizat în siguranță.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SIGURANȚĂ: `i` este inferior la jumătate din lungimea feliei, așa că
            // accesarea `i` și `ln - i - 1` este sigură (`i` începe de la 0 și nu va merge mai departe de `ln / 2 - 1`).
            // Indicatoarele rezultate `pa` și `pb` sunt, prin urmare, valide și aliniate și pot fi citite și scrise în.
            //
            //
            unsafe {
                // Schimb nesigur pentru a evita limitele verificați în swap sigur.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Returnează un iterator peste felie.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Returnează un iterator care permite modificarea fiecărei valori.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Returnează un iterator peste toate windows adiacente cu lungimea `size`.
    /// windows se suprapune.
    /// Dacă felia este mai scurtă decât `size`, iteratorul nu returnează valori.
    ///
    /// # Panics
    ///
    /// Panics dacă `size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Dacă felia este mai scurtă decât `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la începutul feliei.
    ///
    /// Bucățile sunt felii și nu se suprapun.Dacă `chunk_size` nu împarte lungimea feliei, atunci ultima bucată nu va avea lungimea `chunk_size`.
    ///
    /// A se vedea [`chunks_exact`] pentru o variantă a acestui iterator care returnează bucăți de elemente întotdeauna exact `chunk_size` și [`rchunks`] pentru același iterator, dar începând de la sfârșitul feliei.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la începutul feliei.
    ///
    /// Bucățile sunt felii modificabile și nu se suprapun.Dacă `chunk_size` nu împarte lungimea feliei, atunci ultima bucată nu va avea lungimea `chunk_size`.
    ///
    /// A se vedea [`chunks_exact_mut`] pentru o variantă a acestui iterator care returnează bucăți de elemente întotdeauna exact `chunk_size` și [`rchunks_mut`] pentru același iterator, dar începând de la sfârșitul feliei.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la începutul feliei.
    ///
    /// Bucățile sunt felii și nu se suprapun.
    /// Dacă `chunk_size` nu împarte lungimea feliei, atunci ultimele până la `chunk_size-1` elemente vor fi omise și pot fi recuperate din funcția `remainder` a iteratorului.
    ///
    ///
    /// Datorită faptului că fiecare bucată are exact elemente `chunk_size`, compilatorul poate optimiza deseori codul rezultat mai bine decât în cazul [`chunks`].
    ///
    /// Consultați [`chunks`] pentru o variantă a acestui iterator care returnează și restul ca o bucată mai mică și [`rchunks_exact`] pentru același iterator, dar începând de la sfârșitul feliei.
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la începutul feliei.
    ///
    /// Bucățile sunt felii modificabile și nu se suprapun.
    /// Dacă `chunk_size` nu împarte lungimea feliei, atunci ultimele până la `chunk_size-1` elemente vor fi omise și pot fi recuperate din funcția `into_remainder` a iteratorului.
    ///
    ///
    /// Datorită faptului că fiecare bucată are exact elemente `chunk_size`, compilatorul poate optimiza deseori codul rezultat mai bine decât în cazul [`chunks_mut`].
    ///
    /// Consultați [`chunks_mut`] pentru o variantă a acestui iterator care returnează și restul ca o bucată mai mică și [`rchunks_exact_mut`] pentru același iterator, dar începând de la sfârșitul feliei.
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Împarte felia într-o felie de matrice de elemente " N`, presupunând că nu există rest.
    ///
    ///
    /// # Safety
    ///
    /// Acest lucru poate fi apelat numai atunci când
    /// - Felia se împarte exact în bucăți de element " N` (alias `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SIGURANȚĂ: bucăți de 1 element nu au niciodată rest
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SIGURANȚĂ: lungimea feliei (6) este un multiplu de 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Acestea ar fi nejustificate:
    /// // lăsați bucăți: &[[_;5]]= slice.as_chunks_unchecked()//Lungimea feliei nu este un multiplu de 5 bucăți:&[[_;0]]= slice.as_chunks_unchecked()//Nu sunt permise niciodată bucăți de lungime zero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIGURANȚĂ: Precondiția noastră este exact ceea ce este necesar pentru a numi asta
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIGURANȚĂ: Am aruncat o felie de elemente `new_len * N` în
        // o felie de `new_len` multe elemente `N` bucăți.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Împarte felia într-o felie de matrice de elemente " N`, începând de la începutul feliei, și o felie restantă cu lungimea strict mai mică de `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `N` este 0. Această verificare se va schimba cel mai probabil într-o eroare de timp de compilare înainte ca această metodă să se stabilizeze.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SIGURANȚĂ: Am intrat deja în panică pentru zero și asigurați de construcții
        // că lungimea subslice este multiplu de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Împarte felia într-o felie de matrice de elemente " N`, începând de la sfârșitul feliei, și o felie rămasă cu lungimea strict mai mică de `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `N` este 0. Această verificare se va schimba cel mai probabil într-o eroare de timp de compilare înainte ca această metodă să se stabilizeze.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SIGURANȚĂ: Am intrat deja în panică pentru zero și asigurați de construcții
        // că lungimea subslice este multiplu de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Returnează un iterator peste `N` elemente ale feliei la un moment dat, începând de la începutul feliei.
    ///
    /// Bucățile sunt referințe matrice și nu se suprapun.
    /// Dacă `N` nu împarte lungimea feliei, atunci ultimele până la `N-1` elemente vor fi omise și pot fi recuperate din funcția `remainder` a iteratorului.
    ///
    ///
    /// Această metodă este echivalentul generic const al lui [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics dacă `N` este 0. Această verificare se va schimba cel mai probabil într-o eroare de timp de compilare înainte ca această metodă să se stabilizeze.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Împarte felia într-o felie de matrice de elemente " N`, presupunând că nu există rest.
    ///
    ///
    /// # Safety
    ///
    /// Acest lucru poate fi apelat numai atunci când
    /// - Felia se împarte exact în bucăți de element " N` (alias `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SIGURANȚĂ: bucăți de 1 element nu au niciodată rest
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SIGURANȚĂ: lungimea feliei (6) este un multiplu de 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Acestea ar fi nejustificate:
    /// // lăsați bucăți: &[[_;5]]= slice.as_chunks_unchecked_mut()//Lungimea feliei nu este un multiplu de 5 bucăți:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nu sunt permise niciodată bucăți de lungime zero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIGURANȚĂ: Precondiția noastră este exact ceea ce este necesar pentru a numi asta
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIGURANȚĂ: Am aruncat o felie de elemente `new_len * N` în
        // o felie de `new_len` multe elemente `N` bucăți.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Împarte felia într-o felie de matrice de elemente " N`, începând de la începutul feliei, și o felie restantă cu lungimea strict mai mică de `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `N` este 0. Această verificare se va schimba cel mai probabil într-o eroare de timp de compilare înainte ca această metodă să se stabilizeze.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SIGURANȚĂ: Am intrat deja în panică pentru zero și asigurați de construcții
        // că lungimea subslice este multiplu de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Împarte felia într-o felie de matrice de elemente " N`, începând de la sfârșitul feliei, și o felie rămasă cu lungimea strict mai mică de `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `N` este 0. Această verificare se va schimba cel mai probabil într-o eroare de timp de compilare înainte ca această metodă să se stabilizeze.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SIGURANȚĂ: Am intrat deja în panică pentru zero și asigurați de construcții
        // că lungimea subslice este multiplu de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Returnează un iterator peste `N` elemente ale feliei la un moment dat, începând de la începutul feliei.
    ///
    /// Bucățile sunt referințe matrice mutabile și nu se suprapun.
    /// Dacă `N` nu împarte lungimea feliei, atunci ultimele până la `N-1` elemente vor fi omise și pot fi recuperate din funcția `into_remainder` a iteratorului.
    ///
    ///
    /// Această metodă este echivalentul generic const al lui [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics dacă `N` este 0. Această verificare se va schimba cel mai probabil într-o eroare de timp de compilare înainte ca această metodă să se stabilizeze.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Returnează un iterator care se suprapune peste windows din elementele `N` ale unei felii, începând de la începutul feliei.
    ///
    ///
    /// Acesta este echivalentul generic constant al [`windows`].
    ///
    /// Dacă `N` este mai mare decât dimensiunea feliei, nu va returna niciun windows.
    ///
    /// # Panics
    ///
    /// Panics dacă `N` este 0.
    /// Această verificare se va schimba cel mai probabil într-o eroare de timp de compilare înainte ca această metodă să se stabilizeze.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la sfârșitul feliei.
    ///
    /// Bucățile sunt felii și nu se suprapun.Dacă `chunk_size` nu împarte lungimea feliei, atunci ultima bucată nu va avea lungimea `chunk_size`.
    ///
    /// A se vedea [`rchunks_exact`] pentru o variantă a acestui iterator care returnează bucăți de elemente întotdeauna exact `chunk_size` și [`chunks`] pentru același iterator, dar începând de la începutul feliei.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la sfârșitul feliei.
    ///
    /// Bucățile sunt felii modificabile și nu se suprapun.Dacă `chunk_size` nu împarte lungimea feliei, atunci ultima bucată nu va avea lungimea `chunk_size`.
    ///
    /// A se vedea [`rchunks_exact_mut`] pentru o variantă a acestui iterator care returnează bucăți de elemente întotdeauna exact `chunk_size` și [`chunks_mut`] pentru același iterator, dar începând de la începutul feliei.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la sfârșitul feliei.
    ///
    /// Bucățile sunt felii și nu se suprapun.
    /// Dacă `chunk_size` nu împarte lungimea feliei, atunci ultimele până la `chunk_size-1` elemente vor fi omise și pot fi recuperate din funcția `remainder` a iteratorului.
    ///
    /// Datorită faptului că fiecare bucată are exact elemente `chunk_size`, compilatorul poate optimiza deseori codul rezultat mai bine decât în cazul [`chunks`].
    ///
    /// Consultați [`rchunks`] pentru o variantă a acestui iterator care returnează și restul ca o bucată mai mică și [`chunks_exact`] pentru același iterator, dar începând de la începutul feliei.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Returnează un iterator peste `chunk_size` elemente ale feliei la un moment dat, începând de la sfârșitul feliei.
    ///
    /// Bucățile sunt felii modificabile și nu se suprapun.
    /// Dacă `chunk_size` nu împarte lungimea feliei, atunci ultimele până la `chunk_size-1` elemente vor fi omise și pot fi recuperate din funcția `into_remainder` a iteratorului.
    ///
    /// Datorită faptului că fiecare bucată are exact elemente `chunk_size`, compilatorul poate optimiza deseori codul rezultat mai bine decât în cazul [`chunks_mut`].
    ///
    /// Consultați [`rchunks_mut`] pentru o variantă a acestui iterator care returnează și restul ca o bucată mai mică și [`chunks_exact_mut`] pentru același iterator, dar începând de la începutul feliei.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `chunk_size` este 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Returnează un iterator peste felie producând curse de elemente care nu se suprapun folosind predicatul pentru a le separa.
    ///
    /// Predicatul este apelat pe două elemente care se urmează, înseamnă că predicatul este apelat pe `slice[0]` și `slice[1]` apoi pe `slice[1]` și `slice[2]` și așa mai departe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Această metodă poate fi utilizată pentru a extrage subclasele sortate:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Returnează un iterator peste felie producând rute mutabile de elemente care nu se suprapun folosind predicatul pentru a le separa.
    ///
    /// Predicatul este apelat pe două elemente care se urmează, înseamnă că predicatul este apelat pe `slice[0]` și `slice[1]` apoi pe `slice[1]` și `slice[2]` și așa mai departe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Această metodă poate fi utilizată pentru a extrage subclasele sortate:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Împarte o felie în două la un index.
    ///
    /// Primul va conține toți indicii din `[0, mid)` (cu excepția indexului `mid` în sine) și al doilea va conține toți indicii din `[mid, len)` (cu excepția indexului `len` însuși).
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SIGURANȚĂ: `[ptr; mid]` și `[mid; len]` se află în interiorul `self`, care
        // îndeplinește cerințele `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Împarte o felie mutabilă în două la un index.
    ///
    /// Primul va conține toți indicii din `[0, mid)` (cu excepția indexului `mid` în sine) și al doilea va conține toți indicii din `[mid, len)` (cu excepția indexului `len` însuși).
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SIGURANȚĂ: `[ptr; mid]` și `[mid; len]` se află în interiorul `self`, care
        // îndeplinește cerințele `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Împarte o felie în două la un index, fără a face verificarea limitelor.
    ///
    /// Primul va conține toți indicii din `[0, mid)` (cu excepția indexului `mid` în sine) și al doilea va conține toți indicii din `[mid, len)` (cu excepția indexului `len` însuși).
    ///
    ///
    /// Pentru o alternativă sigură, consultați [`split_at`].
    ///
    /// # Safety
    ///
    /// Apelarea acestei metode cu un index în afara limitelor este *[comportament nedefinit]* chiar dacă referința rezultată nu este utilizată.Apelantul trebuie să se asigure că `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SIGURANȚĂ: Apelantul trebuie să verifice dacă `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Împarte o felie mutabilă în două la un index, fără a face verificarea limitelor.
    ///
    /// Primul va conține toți indicii din `[0, mid)` (cu excepția indexului `mid` în sine) și al doilea va conține toți indicii din `[mid, len)` (cu excepția indexului `len` însuși).
    ///
    ///
    /// Pentru o alternativă sigură, consultați [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Apelarea acestei metode cu un index în afara limitelor este *[comportament nedefinit]* chiar dacă referința rezultată nu este utilizată.Apelantul trebuie să se asigure că `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SIGURANȚĂ: Apelantul trebuie să verifice dacă `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` și `[mid; len]` nu se suprapun, deci returnarea unei referințe mutabile este în regulă.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Returnează un iterator peste subsecțiuni separate prin elemente care se potrivesc cu `pred`.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Dacă primul element este asociat, o felie goală va fi primul articol returnat de iterator.
    /// În mod similar, dacă ultimul element din felie este asortat, o felie goală va fi ultimul element returnat de iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Dacă două elemente potrivite sunt direct adiacente, o felie goală va fi prezentă între ele:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Returnează un iterator peste subsecțiuni mutabile separate prin elemente care se potrivesc cu `pred`.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Returnează un iterator peste subsecțiuni separate prin elemente care se potrivesc cu `pred`.
    /// Elementul potrivit este conținut la sfârșitul subsecțiunii anterioare ca terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Dacă ultimul element al feliei este asociat, acel element va fi considerat terminatorul feliei precedente.
    ///
    /// Acea felie va fi ultimul articol returnat de iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Returnează un iterator peste subsecțiuni mutabile separate prin elemente care se potrivesc cu `pred`.
    /// Elementul potrivit este conținut în subsecțiunea anterioară ca terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Returnează un iterator peste subsecțiuni separate prin elemente care se potrivesc cu `pred`, începând de la sfârșitul feliei și lucrând înapoi.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ca și în cazul `split()`, dacă primul sau ultimul element este asociat, o felie goală va fi primul (sau ultimul) element returnat de iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Returnează un iterator peste subsecțiuni mutabile separate prin elemente care se potrivesc cu `pred`, începând de la sfârșitul feliei și lucrând înapoi.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Returnează un iterator peste subsecțiuni separate prin elemente care se potrivesc cu `pred`, limitat la returnarea cel mult a articolelor `n`.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// Ultimul element returnat, dacă există, va conține restul feliei.
    ///
    /// # Examples
    ///
    /// Imprimați felia împărțită o dată cu numere divizibile cu 3 (adică `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Returnează un iterator peste subsecțiuni separate prin elemente care se potrivesc cu `pred`, limitat la returnarea cel mult a articolelor `n`.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// Ultimul element returnat, dacă există, va conține restul feliei.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Returnează un iterator peste subsecțiuni separate prin elemente care se potrivesc cu `pred` limitat la returnarea a cel mult `n` articole.
    /// Aceasta începe la sfârșitul feliei și funcționează înapoi.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// Ultimul element returnat, dacă există, va conține restul feliei.
    ///
    /// # Examples
    ///
    /// Imprimați felia împărțită o singură dată, începând de la sfârșit, cu numere divizibile cu 3 (adică `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Returnează un iterator peste subsecțiuni separate prin elemente care se potrivesc cu `pred` limitat la returnarea a cel mult `n` articole.
    /// Aceasta începe la sfârșitul feliei și funcționează înapoi.
    /// Elementul potrivit nu este conținut în subsecțiuni.
    ///
    /// Ultimul element returnat, dacă există, va conține restul feliei.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Returnează `true` dacă felia conține un element cu valoarea dată.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Dacă nu aveți un `&T`, ci doar un `&U` astfel încât `T: Borrow<U>` (de ex
    /// " Șir: Împrumută<str>`), puteți utiliza `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // felie de `String`
    /// assert!(v.iter().any(|e| e == "hello")); // căutați cu `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Returnează `true` dacă `needle` este un prefix al feliei.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Returnează întotdeauna `true` dacă `needle` este o felie goală:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Returnează `true` dacă `needle` este un sufix al feliei.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Returnează întotdeauna `true` dacă `needle` este o felie goală:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Returnează un subsecțiune cu prefixul eliminat.
    ///
    /// Dacă felia începe cu `prefix`, returnează subslice-ul după prefix, înfășurat în `Some`.
    /// Dacă `prefix` este gol, returnează pur și simplu felia originală.
    ///
    /// Dacă felia nu începe cu `prefix`, returnează `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Această funcție va trebui rescrisă dacă și când SlicePattern devine mai sofisticat.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Returnează un subsecțiune cu sufixul eliminat.
    ///
    /// Dacă felia se termină cu `suffix`, returnează subsecțiunea înainte de sufix, înfășurată în `Some`.
    /// Dacă `suffix` este gol, returnează pur și simplu felia originală.
    ///
    /// Dacă felia nu se termină cu `suffix`, returnează `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Această funcție va trebui rescrisă dacă și când SlicePattern devine mai sofisticat.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binarul caută această felie sortată pentru un anumit element.
    ///
    /// Dacă valoarea este găsită, atunci se returnează [`Result::Ok`], conținând indexul elementului de potrivire.
    /// Dacă există mai multe meciuri, atunci oricare dintre meciuri poate fi returnată.
    /// Dacă valoarea nu este găsită, atunci se returnează [`Result::Err`], conținând indexul în care ar putea fi inserat un element de potrivire în timp ce se menține ordinea sortată.
    ///
    ///
    /// A se vedea, de asemenea, [`binary_search_by`], [`binary_search_by_key`] și [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Căutați o serie de patru elemente.
    /// Primul se găsește, cu o poziție determinată în mod unic;al doilea și al treilea nu se găsesc;al patrulea ar putea egala orice poziție în `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Dacă doriți să inserați un element într-un vector sortat, menținând în același timp ordinea de sortare:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binarul caută această felie sortată cu o funcție de comparare.
    ///
    /// Funcția de comparare ar trebui să implementeze o ordine conformă cu ordinea de sortare a feliei subiacente, returnând un cod de comandă care indică dacă argumentul său este `Less`, `Equal` sau `Greater` ținta dorită.
    ///
    ///
    /// Dacă valoarea este găsită, atunci se returnează [`Result::Ok`], conținând indexul elementului de potrivire.Dacă există mai multe meciuri, atunci oricare dintre meciuri poate fi returnată.
    /// Dacă valoarea nu este găsită, atunci se returnează [`Result::Err`], conținând indexul în care ar putea fi inserat un element de potrivire în timp ce se menține ordinea sortată.
    ///
    /// A se vedea, de asemenea, [`binary_search`], [`binary_search_by_key`] și [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Căutați o serie de patru elemente.Primul se găsește, cu o poziție determinată în mod unic;al doilea și al treilea nu se găsesc;al patrulea s-ar putea potrivi cu orice poziție din `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SIGURANȚĂ: apelul este făcut în siguranță de către următorii invarianți:
            // - `mid >= 0`
            // - `mid < size`: `mid` este limitat de `[left; right)` legat.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Motivul pentru care folosim fluxul de control if/else mai degrabă decât potrivirea se datorează faptului că potrivirea reordonează operațiunile de comparare, care este perfect sensibilă.
            //
            // Acesta este x86 asm pentru u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binarul caută această felie sortată cu o funcție de extragere a cheii.
    ///
    /// Presupune că felia este sortată după cheie, de exemplu cu [`sort_by_key`] utilizând aceeași funcție de extragere a cheii.
    ///
    /// Dacă valoarea este găsită, atunci se returnează [`Result::Ok`], conținând indexul elementului de potrivire.
    /// Dacă există mai multe meciuri, atunci oricare dintre meciuri poate fi returnată.
    /// Dacă valoarea nu este găsită, atunci se returnează [`Result::Err`], conținând indexul în care ar putea fi inserat un element de potrivire în timp ce se menține ordinea sortată.
    ///
    ///
    /// A se vedea, de asemenea, [`binary_search`], [`binary_search_by`] și [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Căutați o serie de patru elemente într-o felie de perechi sortate după al doilea element.
    /// Primul se găsește, cu o poziție determinată în mod unic;al doilea și al treilea nu se găsesc;al patrulea ar putea egala orice poziție în `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links este permis deoarece `slice::sort_by_key` este în crate `alloc` și, ca atare, nu există încă la construirea `core`.
    //
    // linkuri către crate în aval: #74481.Deoarece primitivele sunt documentate numai în libstd (#73423), acest lucru nu duce niciodată la legături rupte în practică.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sortează felia, dar este posibil să nu păstreze ordinea elementelor egale.
    ///
    /// Acest tip este instabil (adică, poate reordona elemente egale), în loc (adică nu alocă) și *O*(*n*\*log(* n*)) în cel mai rău caz.
    ///
    /// # Implementare curentă
    ///
    /// Algoritmul actual se bazează pe [pattern-defeating quicksort][pdqsort] de Orson Peters, care combină cazul mediu rapid al rapidului randomizat cu cel mai rău caz de heapsort, obținând în același timp timp liniar pe felii cu anumite tipare.
    /// Folosește oarecare randomizare pentru a evita cazurile degenerate, dar cu un seed fix pentru a oferi întotdeauna un comportament determinist.
    ///
    /// Este de obicei mai rapid decât sortarea stabilă, cu excepția câtorva cazuri speciale, de exemplu, când felia constă din mai multe secvențe sortate concatenate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sortează felia cu o funcție de comparare, dar este posibil să nu păstreze ordinea elementelor egale.
    ///
    /// Acest tip este instabil (adică, poate reordona elemente egale), în loc (adică nu alocă) și *O*(*n*\*log(* n*)) în cel mai rău caz.
    ///
    /// Funcția de comparare trebuie să definească o ordonare totală pentru elementele din felie.Dacă ordonarea nu este totală, ordinea elementelor este nespecificată.O comandă este o comandă totală dacă este (pentru toate `a`, `b` și `c`):
    ///
    /// * total și antisimetric: exact unul dintre `a < b`, `a == b` sau `a > b` este adevărat și
    /// * tranzitiv, `a < b` și `b < c` implică `a < c`.Același lucru trebuie valabil atât pentru `==`, cât și pentru `>`.
    ///
    /// De exemplu, în timp ce [`f64`] nu implementează [`Ord`] deoarece `NaN != NaN`, putem folosi `partial_cmp` ca funcție de sortare când știm că felia nu conține un `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Implementare curentă
    ///
    /// Algoritmul actual se bazează pe [pattern-defeating quicksort][pdqsort] de Orson Peters, care combină cazul mediu rapid al rapidului randomizat cu cel mai rău caz de heapsort, obținând în același timp timp liniar pe felii cu anumite tipare.
    /// Folosește oarecare randomizare pentru a evita cazurile degenerate, dar cu un seed fix pentru a oferi întotdeauna un comportament determinist.
    ///
    /// Este de obicei mai rapid decât sortarea stabilă, cu excepția câtorva cazuri speciale, de exemplu, când felia constă din mai multe secvențe sortate concatenate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // sortare inversă
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sortează felia cu o funcție de extragere a cheii, dar este posibil să nu păstreze ordinea elementelor egale.
    ///
    /// Acest sort este instabil (adică, poate reordona elemente egale), în loc (adică nu alocă) și *O*(m\* * n *\* log(*n*)) în cel mai rău caz, unde funcția cheie este *O*(*m*).
    ///
    /// # Implementare curentă
    ///
    /// Algoritmul actual se bazează pe [pattern-defeating quicksort][pdqsort] de Orson Peters, care combină cazul mediu rapid al rapidului randomizat cu cel mai rău caz de heapsort, obținând în același timp timp liniar pe felii cu anumite tipare.
    /// Folosește oarecare randomizare pentru a evita cazurile degenerate, dar cu un seed fix pentru a oferi întotdeauna un comportament determinist.
    ///
    /// Datorită strategiei sale de apelare cheie, [`sort_unstable_by_key`](#method.sort_unstable_by_key) este probabil să fie mai lent decât [`sort_by_cached_key`](#method.sort_by_cached_key) în cazurile în care funcția cheie este costisitoare.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reordonați felia astfel încât elementul de la `index` să fie în poziția sa finală sortată.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Reordonați felia cu o funcție de comparare astfel încât elementul de la `index` să fie în poziția sa finală sortată.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reordonați felia cu o funcție de extracție a cheii astfel încât elementul de la `index` să fie în poziția sa finală sortată.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reordonați felia astfel încât elementul de la `index` să fie în poziția sa finală sortată.
    ///
    /// Această reordonare are proprietatea suplimentară că orice valoare la poziția `i < index` va fi mai mică sau egală cu orice valoare la o poziție `j > index`.
    /// În plus, această reordonare este instabilă (adică
    /// orice număr de elemente egale poate ajunge la poziția `index`), în loc (adică
    /// nu alocă) și *O*(*n*) cel mai rău caz.
    /// Această funcție este, de asemenea, cunoscută sub numele de "kth element" în alte biblioteci.
    /// Returnează un triplet al următoarelor valori: toate elementele mai mici decât cel de la indexul dat, valoarea la indexul dat și toate elementele mai mari decât cel de la indexul dat.
    ///
    ///
    /// # Implementare curentă
    ///
    /// Algoritmul actual se bazează pe porțiunea de selectare rapidă a aceluiași algoritm rapid de scurtă durată utilizat pentru [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics când `index >= len()`, adică întotdeauna panics pe felii goale.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Găsiți mediana
    /// v.select_nth_unstable(2);
    ///
    /// // Ne este garantat doar că felia va fi una dintre următoarele, pe baza modului în care sortăm în funcție de indexul specificat.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordonați felia cu o funcție de comparare astfel încât elementul de la `index` să fie în poziția sa finală sortată.
    ///
    /// Această reordonare are proprietatea suplimentară că orice valoare la poziția `i < index` va fi mai mică sau egală cu orice valoare la o poziție `j > index` utilizând funcția de comparare.
    /// În plus, această reordonare este instabilă (adică orice număr de elemente egale poate ajunge la poziția `index`), în loc (adică nu alocă) și *O*(*n*) în cel mai rău caz.
    /// Această funcție este cunoscută și sub numele de "kth element" în alte biblioteci.
    /// Returnează un triplet al următoarelor valori: toate elementele mai mici decât cel de la indexul dat, valoarea la indexul dat și toate elementele mai mari decât cel de la indexul dat, utilizând funcția de comparare furnizată.
    ///
    ///
    /// # Implementare curentă
    ///
    /// Algoritmul actual se bazează pe porțiunea de selectare rapidă a aceluiași algoritm rapid de scurtă durată utilizat pentru [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics când `index >= len()`, adică întotdeauna panics pe felii goale.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Găsiți mediana ca și cum felia ar fi sortată în ordine descrescătoare.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Ne este garantat doar că felia va fi una dintre următoarele, pe baza modului în care sortăm în funcție de indexul specificat.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordonați felia cu o funcție de extracție a cheii astfel încât elementul de la `index` să fie în poziția sa finală sortată.
    ///
    /// Această reordonare are proprietatea suplimentară că orice valoare la poziția `i < index` va fi mai mică sau egală cu orice valoare la o poziție `j > index` utilizând funcția de extracție a cheii.
    /// În plus, această reordonare este instabilă (adică orice număr de elemente egale poate ajunge la poziția `index`), în loc (adică nu alocă) și *O*(*n*) în cel mai rău caz.
    /// Această funcție este cunoscută și sub numele de "kth element" în alte biblioteci.
    /// Returnează un triplet al următoarelor valori: toate elementele mai mici decât cel de la indexul dat, valoarea la indexul dat și toate elementele mai mari decât cel de la indexul dat, utilizând funcția de extracție a cheii furnizate.
    ///
    ///
    /// # Implementare curentă
    ///
    /// Algoritmul actual se bazează pe porțiunea de selectare rapidă a aceluiași algoritm rapid de scurtă durată utilizat pentru [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics când `index >= len()`, adică întotdeauna panics pe felii goale.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Întoarceți mediana ca și cum matricea ar fi sortată în funcție de valoarea absolută.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Ne este garantat doar că felia va fi una dintre următoarele, pe baza modului în care sortăm în funcție de indexul specificat.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Mută toate elementele repetate consecutive până la capătul feliei în conformitate cu implementarea [`PartialEq`] trait.
    ///
    ///
    /// Returnează două felii.Primul nu conține elemente repetate consecutive.
    /// Al doilea conține toate duplicatele într-o ordine specificată.
    ///
    /// Dacă felia este sortată, prima felie returnată nu conține duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Mută toate elementele consecutive, cu excepția primului, la sfârșitul feliei, satisfăcând o anumită relație de egalitate.
    ///
    /// Returnează două felii.Primul nu conține elemente repetate consecutive.
    /// Al doilea conține toate duplicatele într-o ordine specificată.
    ///
    /// Funcția `same_bucket` este trimisă referințe la două elemente din felie și trebuie să stabilească dacă elementele se compară egal.
    /// Elementele sunt trecute în ordine opusă față de ordinea lor în felie, deci dacă `same_bucket(a, b)` returnează `true`, `a` este mutat la sfârșitul feliei.
    ///
    ///
    /// Dacă felia este sortată, prima felie returnată nu conține duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Deși avem o referință mutabilă la `self`, nu putem face modificări *arbitrare*.Apelurile `same_bucket` ar putea panic, deci trebuie să ne asigurăm că felia este în permanență într-o stare validă.
        //
        // Modul în care gestionăm acest lucru este prin utilizarea swap-urilor;iterăm peste toate elementele, schimbând în timp ce mergem, astfel încât la final elementele pe care dorim să le păstrăm sunt în față, iar cele pe care dorim să le respingem sunt în spate.
        // Putem apoi împărți felia.
        // Această operațiune este încă `O(n)`.
        //
        // Exemplu: Începem în această stare, unde `r` reprezintă " următorul
        // citiți " și `w` reprezintă" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Comparând self[r] cu auto [w-1], acesta nu este un duplicat, așa că schimbăm self[r] și self[w] (fără efect ca r==w) și apoi incrementăm atât r cât și w, lăsându-ne cu:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparând self[r] cu auto [w-1], această valoare este un duplicat, așa că incrementăm `r`, dar lăsăm neschimbat orice altceva:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparând self[r] cu auto [w-1], acesta nu este un duplicat, deci schimbați self[r] și self[w] și avansați r și w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Nu este un duplicat, repetați:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicat, advance r. End de felie.Împărțiți la w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SIGURANȚĂ: condiția `while` garantează `next_read` și `next_write`
        // sunt mai mici decât `len`, deci sunt în `self`.
        // `prev_ptr_write` indică un element înainte de `ptr_write`, dar `next_write` începe de la 1, deci `prev_ptr_write` nu este niciodată mai mic de 0 și se află în interiorul feliei.
        // Acest lucru îndeplinește cerințele pentru dereferențierea `ptr_read`, `prev_ptr_write` și `ptr_write` și pentru utilizarea `ptr.add(next_read)`, `ptr.add(next_write - 1)` și `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` este, de asemenea, incrementat cel mult o dată pe buclă cel mult, ceea ce înseamnă că niciun element nu este omis atunci când poate fi necesar să fie schimbat.
        //
        // `ptr_read` și `prev_ptr_write` nu indică niciodată același element.Acest lucru este necesar pentru ca `&mut *ptr_read`, `&mut* prev_ptr_write` să fie în siguranță.
        // Explicația este pur și simplu că `next_read >= next_write` este întotdeauna adevărat, deci `next_read > next_write - 1` este și el.
        //
        //
        //
        //
        //
        unsafe {
            // Evitați verificările limitelor utilizând pointeri raw.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Mută toate elementele consecutive, cu excepția primului, la sfârșitul feliei care se rezolvă la aceeași cheie.
    ///
    ///
    /// Returnează două felii.Primul nu conține elemente repetate consecutive.
    /// Al doilea conține toate duplicatele într-o ordine specificată.
    ///
    /// Dacă felia este sortată, prima felie returnată nu conține duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Rotiți felia în loc, astfel încât primele elemente `mid` ale feliei să se deplaseze până la capăt, în timp ce ultimele elemente `self.len() - mid` se deplasează în față.
    /// După apelarea `rotate_left`, elementul anterior la indexul `mid` va deveni primul element din felie.
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă `mid` este mai mare decât lungimea feliei.Rețineți că `mid == self.len()` face _not_ panic și este o rotație fără oprire.
    ///
    /// # Complexity
    ///
    /// Ia liniar (în timp `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotirea unui subsecțiune:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SIGURANȚĂ: Gama `[p.add(mid) - mid, p.add(mid) + k)` este banală
        // valabil pentru citire și scriere, conform cerințelor `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rotiți felia în loc, astfel încât primele elemente `self.len() - k` ale feliei să se deplaseze până la capăt, în timp ce ultimele elemente `k` se deplasează în față.
    /// După apelarea `rotate_right`, elementul anterior la indexul `self.len() - k` va deveni primul element din felie.
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă `k` este mai mare decât lungimea feliei.Rețineți că `k == self.len()` face _not_ panic și este o rotație fără oprire.
    ///
    /// # Complexity
    ///
    /// Ia liniar (în timp `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rotiți un subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SIGURANȚĂ: Gama `[p.add(mid) - mid, p.add(mid) + k)` este banală
        // valabil pentru citire și scriere, conform cerințelor `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Umple `self` cu elemente prin clonarea `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Umple `self` cu elementele returnate apelând o închidere în mod repetat.
    ///
    /// Această metodă folosește o închidere pentru a crea noi valori.Dacă preferați [`Clone`] o valoare dată, utilizați [`fill`].
    /// Dacă doriți să utilizați [`Default`] trait pentru a genera valori, puteți trece [`Default::default`] ca argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Copiază elementele din `src` în `self`.
    ///
    /// Lungimea lui `src` trebuie să fie aceeași cu `self`.
    ///
    /// Dacă `T` implementează `Copy`, poate fi mai performant să folosiți [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă cele două felii au lungimi diferite.
    ///
    /// # Examples
    ///
    /// Clonarea a două elemente dintr-o felie în alta:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Deoarece feliile trebuie să aibă aceeași lungime, feliem felia sursă de la patru elemente la două.
    /// // Va fi panic dacă nu facem acest lucru.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impune că nu poate exista decât o referință mutabilă fără referințe imuabile la o anumită bucată de date într-un anumit domeniu de aplicare.
    /// Din acest motiv, încercarea de a utiliza `clone_from_slice` pe o singură felie va duce la un eșec de compilare:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Pentru a rezolva acest lucru, putem folosi [`split_at_mut`] pentru a crea două sub-felii distincte dintr-o felie:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Copiază toate elementele din `src` în `self`, utilizând un memcpy.
    ///
    /// Lungimea lui `src` trebuie să fie aceeași cu `self`.
    ///
    /// Dacă `T` nu implementează `Copy`, utilizați [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă cele două felii au lungimi diferite.
    ///
    /// # Examples
    ///
    /// Copierea a două elemente dintr-o felie în alta:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Deoarece feliile trebuie să aibă aceeași lungime, feliem felia sursă de la patru elemente la două.
    /// // Va fi panic dacă nu facem acest lucru.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impune că nu poate exista decât o referință mutabilă fără referințe imuabile la o anumită bucată de date într-un anumit domeniu de aplicare.
    /// Din acest motiv, încercarea de a utiliza `copy_from_slice` pe o singură felie va duce la un eșec de compilare:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Pentru a rezolva acest lucru, putem folosi [`split_at_mut`] pentru a crea două sub-felii distincte dintr-o felie:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Calea codului panic a fost pusă într-o funcție rece pentru a nu umfla site-ul apelului.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SIGURANȚĂ: `self` este valid pentru elementele `self.len()` prin definiție, iar `src` a fost
        // verificat pentru a avea aceeași lungime.
        // Feliile nu se pot suprapune, deoarece referințele mutabile sunt exclusive.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Copiază elemente dintr-o parte a feliei într-o altă parte din ea însăși, folosind un memmove.
    ///
    /// `src` este intervalul din `self` din care să copiați.
    /// `dest` este indexul de pornire al intervalului din `self` în care trebuie copiat, care va avea aceeași lungime ca `src`.
    /// Cele două game se pot suprapune.
    /// Capetele celor două intervale trebuie să fie mai mici sau egale cu `self.len()`.
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă oricare interval depășește sfârșitul feliei sau dacă sfârșitul `src` este înainte de început.
    ///
    ///
    /// # Examples
    ///
    /// Copierea a patru octeți într-o felie:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SIGURANȚĂ: condițiile pentru `ptr::copy` au fost verificate mai sus,
        // ca și cele pentru `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Schimbă toate elementele din `self` cu cele din `other`.
    ///
    /// Lungimea lui `other` trebuie să fie aceeași cu `self`.
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă cele două felii au lungimi diferite.
    ///
    /// # Example
    ///
    /// Schimbarea a două elemente pe felii:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust aplică faptul că nu poate exista decât o referință mutabilă la o anumită bucată de date într-un anumit domeniu de aplicare.
    ///
    /// Din acest motiv, încercarea de a utiliza `swap_with_slice` pe o singură felie va duce la un eșec de compilare:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Pentru a rezolva acest lucru, putem folosi [`split_at_mut`] pentru a crea două sub-felii diferite mutabile dintr-o felie:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SIGURANȚĂ: `self` este valid pentru elementele `self.len()` prin definiție, iar `src` a fost
        // verificat pentru a avea aceeași lungime.
        // Feliile nu se pot suprapune, deoarece referințele mutabile sunt exclusive.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funcție pentru calcularea lungimilor mijlocului și a feliei finale pentru `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ceea ce vom face în legătură cu `rest` este să ne dăm seama ce multiplu al lui " U`putem pune într-un număr mai mic de " T`.
        //
        // Și de câte `T` avem nevoie pentru fiecare astfel de "multiple".
        //
        // Să luăm de exemplu T=u8 U=u16.Apoi putem pune 1 U în 2 Ts.Simplu.
        // Acum, ia în considerare, de exemplu, un caz în care size_of: :<T>=16, mărimea_de::<U>=24.</u>
        // Putem pune 2 Us în locul fiecărui 3 Ts din felia `rest`.
        // Un pic mai complicat.
        //
        // Formula pentru a calcula aceasta este:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Extins și simplificat:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Din fericire, deoarece toate acestea sunt evaluate constant ... performanța aici nu contează!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algoritmul stein iterativ Ar trebui să facem acest `const fn` (și să revenim la algoritmul recursiv dacă o facem) pentru că mizând pe llvm pentru a constevalua toate acestea este ... ei bine, mă face să mă simt inconfortabil.
            //
            //

            // SIGURANȚĂ: `a` și `b` sunt verificate ca fiind valori diferite de zero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // eliminați toți factorii de 2 din b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SIGURANȚĂ: `b` este bifat pentru a fi diferit de zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Înarmați cu aceste cunoștințe, putem găsi câte U-uri ne pot potrivi!
        let us_len = self.len() / ts * us;
        // Și câte `T` vor fi în felia finală!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmutați felia într-o felie de alt tip, asigurându-vă că se menține alinierea tipurilor.
    ///
    /// Această metodă împarte felia în trei felii distincte: prefix, felie mijlocie corect aliniată de un tip nou și felie sufix.
    /// Metoda poate face felia de mijloc cea mai mare lungime posibilă pentru un anumit tip și felie de intrare, dar numai performanța algoritmului dvs. ar trebui să depindă de aceasta, nu de corectitudinea sa.
    ///
    /// Este permis ca toate datele de intrare să fie returnate ca prefix sau felie de sufix.
    ///
    /// Această metodă nu are niciun scop când elementul de intrare `T` sau elementul de ieșire `U` au dimensiunea zero și vor returna felia originală fără a împărți nimic.
    ///
    /// # Safety
    ///
    /// Această metodă este în esență un `transmute` în ceea ce privește elementele din felia de mijloc returnată, deci toate prevederile obișnuite referitoare la `transmute::<T, U>` se aplică și aici.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Rețineți că cea mai mare parte a acestei funcții va fi constant evaluată,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // gestionați ZST-urile în mod special, ceea ce înseamnă-nu le manipulați deloc.
            return (self, &[], &[]);
        }

        // Mai întâi, aflați în ce moment ne împărțim între prima și a doua felie.
        // Ușor cu ptr.align_offset.
        let ptr = self.as_ptr();
        // SIGURANȚĂ: Consultați metoda `align_to_mut` pentru comentariul detaliat privind siguranța.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SIGURANȚĂ: acum `rest` este cu siguranță aliniat, deci `from_raw_parts` de mai jos este în regulă,
            // deoarece apelantul garantează că putem transmuta `T` în `U` în siguranță.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmutați felia într-o felie de alt tip, asigurându-vă că se menține alinierea tipurilor.
    ///
    /// Această metodă împarte felia în trei felii distincte: prefix, felie mijlocie corect aliniată de un tip nou și felie sufix.
    /// Metoda poate face felia de mijloc cea mai mare lungime posibilă pentru un anumit tip și felie de intrare, dar numai performanța algoritmului dvs. ar trebui să depindă de aceasta, nu de corectitudinea sa.
    ///
    /// Este permis ca toate datele de intrare să fie returnate ca prefix sau felie de sufix.
    ///
    /// Această metodă nu are niciun scop când elementul de intrare `T` sau elementul de ieșire `U` au dimensiunea zero și vor returna felia originală fără a împărți nimic.
    ///
    /// # Safety
    ///
    /// Această metodă este în esență un `transmute` în ceea ce privește elementele din felia de mijloc returnată, deci toate prevederile obișnuite referitoare la `transmute::<T, U>` se aplică și aici.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Rețineți că cea mai mare parte a acestei funcții va fi constant evaluată,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // gestionați ZST-urile în mod special, ceea ce înseamnă-nu le manipulați deloc.
            return (self, &mut [], &mut []);
        }

        // Mai întâi, aflați în ce moment ne împărțim între prima și a doua felie.
        // Ușor cu ptr.align_offset.
        let ptr = self.as_ptr();
        // SIGURANȚĂ: Aici ne asigurăm că vom folosi indicatori aliniați pentru U pentru
        // restul metodei.Acest lucru se face prin trecerea unui pointer către&[T] cu o aliniere vizată pentru U.
        // `crate::ptr::align_offset` este apelat cu un indicator corect și corect valid `ptr` (provine dintr-o referință la `self`) și cu o dimensiune care este o putere de două (deoarece provine din alinierea pentru U), satisfăcând constrângerile sale de siguranță.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Nu mai putem folosi `rest` din nou după aceasta, ceea ce i-ar invalida aliasul `mut_ptr`!SIGURANȚĂ: vezi comentariile pentru `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Verifică dacă elementele acestei felii sunt sortate.
    ///
    /// Adică, pentru fiecare element `a` și următorul său element `b`, `a <= b` trebuie să păstreze.Dacă felia produce exact zero sau un element, se returnează `true`.
    ///
    /// Rețineți că dacă `Self::Item` este doar `PartialOrd`, dar nu `Ord`, definiția de mai sus implică faptul că această funcție returnează `false` dacă oricare două elemente consecutive nu sunt comparabile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Verifică dacă elementele acestei felii sunt sortate folosind funcția de comparare dată.
    ///
    /// În loc să utilizeze `PartialOrd::partial_cmp`, această funcție folosește funcția dată `compare` pentru a determina ordinea a două elemente.
    /// În afară de asta, este echivalent cu [`is_sorted`];consultați documentația pentru mai multe informații.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Verifică dacă elementele acestei felii sunt sortate folosind funcția dată de extragere a cheilor.
    ///
    /// În loc să compare elementele feliei direct, această funcție compară cheile elementelor, așa cum este determinat de `f`.
    /// În afară de asta, este echivalent cu [`is_sorted`];consultați documentația pentru mai multe informații.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Returnează indexul punctului de partiție conform predicatului dat (indicele primului element al celei de-a doua partiții).
    ///
    /// Se presupune că felia este partiționată conform predicatului dat.
    /// Aceasta înseamnă că toate elementele pentru care predicatul returnează adevărat sunt la începutul feliei și toate elementele pentru care predicatul returnează fals sunt la sfârșit.
    ///
    /// De exemplu, [7, 15, 3, 5, 4, 12, 6] este partiționat sub predicat x% 2!=0 (toate numerele impare sunt la început, toate par la sfârșit).
    ///
    /// Dacă această porțiune nu este partiționată, rezultatul returnat este nespecificat și fără sens, deoarece această metodă efectuează un fel de căutare binară.
    ///
    /// A se vedea, de asemenea, [`binary_search`], [`binary_search_by`] și [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SIGURANȚĂ: Când `left < right`, `left <= mid < right`.
            // Prin urmare, `left` crește întotdeauna și `right` scade întotdeauna și oricare dintre ele este selectată.În ambele cazuri `left <= right` este satisfăcut.Prin urmare, dacă `left < right` într-un pas, `left <= right` este satisfăcut în pasul următor.
            //
            // Prin urmare, atâta timp cât `left != right`, `0 <= left < right <= len` este satisfăcut, iar în acest caz și `0 <= mid < len` este satisfăcut.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Trebuie să le tăiem în mod explicit la aceeași lungime
        // pentru a facilita optimizarea verificării limitelor.
        // Dar, deoarece nu se poate baza pe noi, avem și o specializare explicită pentru T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Creează o felie goală.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Creează o felie goală mutabilă.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Modele în felii, utilizate în prezent doar de `strip_prefix` și `strip_suffix`.
/// La un moment future, sperăm să generalizăm `core::str::Pattern` (care la momentul scrierii este limitat la `str`) la felii, iar apoi acest trait va fi înlocuit sau abolit.
///
pub trait SlicePattern {
    /// Tipul de element al feliei pe care se potrivește.
    type Item;

    /// În prezent, consumatorii `SlicePattern` au nevoie de o felie.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}