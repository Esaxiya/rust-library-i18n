//! Macrocomenzile utilizate de iteratorii de felii.

// Înlinierea is_empty și len face o diferență uriașă de performanță
macro_rules! is_empty {
    // Modul în care codificăm lungimea unui iterator ZST, acesta funcționează atât pentru ZST, cât și pentru non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Pentru a scăpa de unele verificări de limite (a se vedea `position`), calculăm lungimea într-un mod oarecum neașteptat.
// (Testat de `codegen/slice-position-limits-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // suntem uneori folosiți într-un bloc nesigur

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Acest _cannot_ folosește `unchecked_sub` deoarece depindem de împachetare pentru a reprezenta lungimea iteratorilor de felii ZST lungi.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Știm că `start <= end`, deci se poate descurca mai bine decât `offset_from`, care trebuie să se ocupe semnat.
            // Prin setarea indicatoarelor corespunzătoare aici, putem spune LLVM acest lucru, ceea ce îl ajută să elimine verificările limitelor.
            // SIGURANȚĂ: după tipul invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // De asemenea, spunându-i lui LLVM că pointerele sunt separate de un multiplu exact al dimensiunii tipului, poate optimiza `len() == 0` până la `start == end` în loc de `(end - start) < size`.
            //
            // SIGURANȚĂ: După tipul invariant, indicatorii sunt aliniați astfel
            //         distanța dintre ele trebuie să fie un multiplu de dimensiunea pointei
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Definiția partajată a iteratorilor `Iter` și `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Returnează primul element și mută începutul iteratorului înainte cu 1.
        // Îmbunătățește foarte mult performanța în comparație cu o funcție înclinată.
        // Iteratorul nu trebuie să fie gol.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Returnează ultimul element și mută sfârșitul iteratorului înapoi cu 1.
        // Îmbunătățește foarte mult performanța în comparație cu o funcție înclinată.
        // Iteratorul nu trebuie să fie gol.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Micsorează iteratorul atunci când T este un ZST, mutând capătul iteratorului înapoi cu `n`.
        // `n` nu trebuie să depășească `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Funcția de ajutor pentru crearea unei felii din iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SIGURANȚĂ: iteratorul a fost creat dintr-o felie cu pointer
                // `self.ptr` și lungimea `len!(self)`.
                // Acest lucru garantează îndeplinirea tuturor condițiilor prealabile pentru `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Funcția de asistență pentru deplasarea înainte a iteratorului cu elemente `offset`, returnând vechiul start.
            //
            // Nesigur deoarece offsetul nu trebuie să depășească `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SIGURANȚĂ: apelantul garantează că `offset` nu depășește `self.len()`,
                    // deci acest nou indicator este în interiorul `self` și, prin urmare, este garantat ca fiind nul.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Funcția de ajutor pentru deplasarea capătului iteratorului înapoi cu elemente `offset`, returnând noul capăt.
            //
            // Nesigur deoarece offsetul nu trebuie să depășească `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SIGURANȚĂ: apelantul garantează că `offset` nu depășește `self.len()`,
                    // care este garantat să nu depășească un `isize`.
                    // De asemenea, indicatorul rezultat se află în limitele `slice`, care îndeplinește celelalte cerințe pentru `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // ar putea fi implementat cu felii, dar acest lucru evită verificarea limitelor

                // SIGURANȚĂ: apelurile `assume` sunt sigure, deoarece indicatorul de pornire al unei felii
                // trebuie să fie non-nul, iar feliile peste non-ZST trebuie să aibă, de asemenea, un pointer final non-nul.
                // Apelul către `next_unchecked!` este sigur deoarece verificăm dacă iteratorul este gol mai întâi.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Acest iterator este acum gol.
                    if mem::size_of::<T>() == 0 {
                        // Trebuie să o facem în acest fel, deoarece `ptr` nu poate fi niciodată 0, dar `end` ar putea fi (datorită împachetării).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SIGURANȚĂ: end nu poate fi 0 dacă T nu este ZST deoarece ptr nu este 0 și end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SIGURANȚĂ: Suntem în limite.`post_inc_start` face ceea ce trebuie chiar și pentru ZST-uri.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Înlocuim implementarea implicită, care utilizează `try_fold`, deoarece această implementare simplă generează mai puține IR LLVM și este mai rapid de compilat.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Înlocuim implementarea implicită, care utilizează `try_fold`, deoarece această implementare simplă generează mai puține IR LLVM și este mai rapid de compilat.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Înlocuim implementarea implicită, care utilizează `try_fold`, deoarece această implementare simplă generează mai puține IR LLVM și este mai rapid de compilat.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Înlocuim implementarea implicită, care utilizează `try_fold`, deoarece această implementare simplă generează mai puține IR LLVM și este mai rapid de compilat.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Înlocuim implementarea implicită, care utilizează `try_fold`, deoarece această implementare simplă generează mai puține IR LLVM și este mai rapid de compilat.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Înlocuim implementarea implicită, care utilizează `try_fold`, deoarece această implementare simplă generează mai puține IR LLVM și este mai rapid de compilat.
            // De asemenea, `assume` evită verificarea limitelor.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SIGURANȚĂ: ne garantăm că suntem în limitele invariantei buclei:
                        // când `i >= n`, `self.next()` returnează `None` și bucla se întrerupe.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Înlocuim implementarea implicită, care utilizează `try_fold`, deoarece această implementare simplă generează mai puține IR LLVM și este mai rapid de compilat.
            // De asemenea, `assume` evită verificarea limitelor.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SIGURANȚĂ: `i` trebuie să fie mai mic decât `n`, deoarece începe de la `n`
                        // și este doar în scădere.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SIGURANȚĂ: apelantul trebuie să garanteze că `i` se află în limitele
                // felia de bază, deci `i` nu poate revărsa un `isize`, iar referințele returnate sunt garantate pentru a se referi la un element al feliei și, prin urmare, garantate pentru a fi valabile.
                //
                // De asemenea, rețineți că apelantul garantează, de asemenea, că nu vom mai fi sunat niciodată cu același index și că nu se apelează alte metode care vor accesa acest subslice, deci este valabil ca referința returnată să fie modificabilă în cazul
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // ar putea fi implementat cu felii, dar acest lucru evită verificarea limitelor

                // SIGURANȚĂ: apelurile `assume` sunt sigure, deoarece indicatorul de pornire al unei felii trebuie să fie nul,
                // iar feliile peste non-ZST trebuie să aibă, de asemenea, un pointer final non-nul.
                // Apelul către `next_back_unchecked!` este sigur deoarece verificăm dacă iteratorul este gol mai întâi.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Acest iterator este acum gol.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SIGURANȚĂ: Suntem în limite.`pre_dec_end` face ceea ce trebuie chiar și pentru ZST-uri.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}