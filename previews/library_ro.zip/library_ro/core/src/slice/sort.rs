//! Sortarea feliilor
//!
//! Acest modul conține un algoritm de sortare bazat pe quicksortul Orson Peters care învinge modelul, publicat la: <https://github.com/orlp/pdqsort>
//!
//!
//! Sortarea instabilă este compatibilă cu libcore deoarece nu alocă memorie, spre deosebire de implementarea noastră de sortare stabilă.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Când este abandonat, copii de pe `src` în `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SIGURANȚĂ: Aceasta este o clasă de ajutor.
        //          Vă rugăm să consultați utilizarea acestuia pentru corectitudine.
        //          Anume, trebuie să fim siguri că `src` și `dst` nu se suprapun conform cerințelor `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Deplasează primul element spre dreapta până când întâlnește un element mai mare sau egal.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURANȚĂ: Operațiunile nesigure de mai jos implică indexarea fără o verificare legată (`get_unchecked` și `get_unchecked_mut`)
    // și copierea memoriei (`ptr::copy_nonoverlapping`).
    //
    // A.Indexare:
    //  1. Am verificat dimensiunea matricei la>=2.
    //  2. Toată indexarea pe care o vom face este întotdeauna între cel mult {0 <= index < len}.
    //
    // b.Copierea memoriei
    //  1. Obținem indicii pentru referințe care sunt garantate pentru a fi valabile.
    //  2. Acestea nu se pot suprapune, deoarece obținem indicatori pentru a indica indici de diferență ai feliei.
    //     Și anume, `i` și `i-1`.
    //  3. Dacă felia este aliniată corect, elementele sunt aliniate corect.
    //     Este responsabilitatea apelantului să se asigure că felia este aliniată corect.
    //
    // Vezi comentariile de mai jos pentru detalii suplimentare.
    unsafe {
        // Dacă primele două elemente sunt ieșite din uz ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Citiți primul element într-o variabilă alocată stivei.
            // Dacă următoarea operație de comparație panics, `hole` va fi abandonată și va scrie automat elementul înapoi în felie.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Deplasați elementul `i`-un loc la stânga, deplasând astfel gaura spre dreapta.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` este scăpat și astfel copiază `tmp` în orificiul rămas în `v`.
        }
    }
}

/// Deplasează ultimul element spre stânga până când întâlnește un element mai mic sau egal.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURANȚĂ: Operațiunile nesigure de mai jos implică indexarea fără o verificare legată (`get_unchecked` și `get_unchecked_mut`)
    // și copierea memoriei (`ptr::copy_nonoverlapping`).
    //
    // A.Indexare:
    //  1. Am verificat dimensiunea matricei la>=2.
    //  2. Toată indexarea pe care o vom face este întotdeauna între cel mult `0 <= index < len-1`.
    //
    // b.Copierea memoriei
    //  1. Obținem indicii pentru referințe care sunt garantate pentru a fi valabile.
    //  2. Acestea nu se pot suprapune, deoarece obținem indicatori pentru a indica indici de diferență ai feliei.
    //     Și anume, `i` și `i+1`.
    //  3. Dacă felia este aliniată corect, elementele sunt aliniate corect.
    //     Este responsabilitatea apelantului să se asigure că felia este aliniată corect.
    //
    // Vezi comentariile de mai jos pentru detalii suplimentare.
    unsafe {
        // Dacă ultimele două elemente sunt defecte ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Citiți ultimul element într-o variabilă alocată stivei.
            // Dacă următoarea operație de comparație panics, `hole` va fi abandonată și va scrie automat elementul înapoi în felie.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Mutați elementul `i`-un loc la dreapta, deplasând astfel gaura spre stânga.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` este scăpat și astfel copiază `tmp` în orificiul rămas în `v`.
        }
    }
}

/// Sortează parțial o felie prin deplasarea mai multor elemente ieșite din ordine.
///
/// Returnează `true` dacă felia este sortată la sfârșit.Această funcție este *O*(*n*) cel mai rău caz.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Numărul maxim de perechi ieșite din ordine adiacente care vor fi mutate.
    const MAX_STEPS: usize = 5;
    // Dacă felia este mai scurtă decât aceasta, nu schimbați niciun element.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SIGURANȚĂ: Am făcut deja în mod explicit verificarea legată cu `i < len`.
        // Toate indexările noastre ulterioare sunt doar în intervalul `0 <= index < len`
        unsafe {
            // Găsiți următoarea pereche de elemente ieșite din ordine adiacente.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Am terminat?
        if i == len {
            return true;
        }

        // Nu schimbați elementele pe tablouri scurte, care au un cost de performanță.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Schimbați perechea de elemente găsite.Acest lucru le pune în ordine corectă.
        v.swap(i - 1, i);

        // Deplasați elementul mai mic spre stânga.
        shift_tail(&mut v[..i], is_less);
        // Deplasați elementul cel mai mare spre dreapta.
        shift_head(&mut v[i..], is_less);
    }

    // Nu am reușit să sortez felia în numărul limitat de pași.
    false
}

/// Sortează o felie utilizând sortarea prin inserare, care este cel mai rău caz *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sortează `v` folosind heapsort, care garantează *O*(*n*\*log(* n*)) în cel mai rău caz.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Această grămadă binară respectă invariantul `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Copiii lui `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Alege copilul cel mai mare.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Opriți-vă dacă invariantul se menține la `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Schimbați `node` cu copilul mai mare, mutați un pas în jos și continuați cernerea.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Construiți grămada în timp liniar.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elemente maxime din heap.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Se partiționează `v` în elemente mai mici decât `pivot`, urmate de elemente mai mari sau egale cu `pivot`.
///
///
/// Returnează numărul de elemente mai mic decât `pivot`.
///
/// Partiționarea se realizează bloc cu bloc pentru a minimiza costul operațiunilor de ramificare.
/// Această idee este prezentată în lucrarea [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Numărul de elemente dintr-un bloc tipic.
    const BLOCK: usize = 128;

    // Algoritmul de partiționare repetă pașii următori până la finalizare:
    //
    // 1. Urmăriți un bloc din partea stângă pentru a identifica elemente mai mari sau egale cu pivotul.
    // 2. Urmăriți un bloc din partea dreaptă pentru a identifica elemente mai mici decât pivotul.
    // 3. Schimbați elementele identificate între partea stângă și cea dreaptă.
    //
    // Păstrăm următoarele variabile pentru un bloc de elemente:
    //
    // 1. `block` - Numărul de elemente din bloc.
    // 2. `start` - Porniți indicatorul în matricea `offsets`.
    // 3. `end` - Pointerul final în matricea `offsets`.
    // 4. `offsets, indicii elementelor care nu funcționează în cadrul blocului.

    // Blocul curent din partea stângă (de la `l` la `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Blocul curent din partea dreaptă (de la `r.sub(block_r)` to `r`).
    // SIGURANȚĂ: Documentația pentru .add() menționează în mod specific că `vec.as_ptr().add(vec.len())` este întotdeauna sigur `
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Când obținem VLA-uri, încercați să creați mai degrabă o matrice de lungime `min(v.len(), 2 * BLOCK) `
    // decât două tablouri de dimensiuni fixe cu lungimea `BLOCK`.VLA-urile ar putea fi mai eficiente în cache.

    // Returnează numărul de elemente dintre pointerele `l` (inclusive) și `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Am terminat cu partiționarea bloc cu bloc când `l` și `r` se apropie foarte mult.
        // Apoi facem unele lucrări de corecție pentru a partiția elementele rămase între ele.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Numărul de elemente rămase (încă nu se compară cu pivotul).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Reglați dimensiunile blocurilor astfel încât blocurile din stânga și din dreapta să nu se suprapună, ci să fie aliniate perfect pentru a acoperi întregul spațiu rămas.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Urmăriți elementele `block_l` din partea stângă.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SIGURANȚĂ: Operațiunile de nesiguranță de mai jos implică utilizarea `offset`.
                //         Conform condițiilor cerute de funcție, le satisfacem pentru că:
                //         1. `offsets_l` este alocat în stivă și, prin urmare, este considerat obiect alocat separat.
                //         2. Funcția `is_less` returnează un `bool`.
                //            Lansarea unui `bool` nu va depăși niciodată `isize`.
                //         3. Am garantat că `block_l` va fi `<= BLOCK`.
                //            În plus, `end_l` a fost setat inițial la indicatorul de începere al `offsets_`, care a fost declarat în stivă.
                //            Astfel, știm că chiar și în cel mai rău caz (toate invocațiile lui `is_less` returnează fals) vom trece doar la cel mult 1 octet la sfârșit.
                //        O altă operațiune nesigură aici este dereferențierea `elem`.
                //        Cu toate acestea, `elem` a fost inițial indicatorul de începere la felie, care este întotdeauna valid.
                unsafe {
                    // Comparație fără ramuri.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Urmăriți elementele `block_r` din partea dreaptă.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SIGURANȚĂ: Operațiunile de nesiguranță de mai jos implică utilizarea `offset`.
                //         Conform condițiilor cerute de funcție, le satisfacem pentru că:
                //         1. `offsets_r` este alocat în stivă și, prin urmare, este considerat obiect alocat separat.
                //         2. Funcția `is_less` returnează un `bool`.
                //            Lansarea unui `bool` nu va depăși niciodată `isize`.
                //         3. Am garantat că `block_r` va fi `<= BLOCK`.
                //            În plus, `end_r` a fost setat inițial la indicatorul de începere al `offsets_`, care a fost declarat în stivă.
                //            Astfel, știm că chiar și în cel mai rău caz (toate invocațiile lui `is_less` se întoarcă adevărat) vom fi treceți cu cel mult 1 octet la sfârșit.
                //        O altă operațiune nesigură aici este dereferențierea `elem`.
                //        Cu toate acestea, `elem` a fost inițial `1 *sizeof(T)` trecut de final și îl decrementăm cu `1* sizeof(T)` înainte de a-l accesa.
                //        În plus, `block_r` a fost afirmat a fi mai mic decât `BLOCK` și, prin urmare, `elem` va indica cel mult începutul feliei.
                unsafe {
                    // Comparație fără ramuri.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Numărul de elemente nefuncționale care trebuie schimbate între partea stângă și cea dreaptă.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // În loc să schimbați o pereche în acel moment, este mai eficient să efectuați o permutare ciclică.
            // Acest lucru nu este strict echivalent cu schimbarea, dar produce un rezultat similar folosind mai puține operații de memorie.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Toate elementele nefuncționale din blocul din stânga au fost mutate.Treceți la următorul bloc.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Toate elementele nefuncționale din blocul din dreapta au fost mutate.Treceți la blocul anterior.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tot ce rămâne acum este cel mult un bloc (fie stânga, fie dreapta) cu elemente ieșite din ordine care trebuie mutate.
    // Astfel de elemente rămase pot fi pur și simplu mutate până la capăt în cadrul blocului lor.
    //

    if start_l < end_l {
        // Blocul din stânga rămâne.
        // Mutați elementele rămase în afara ordinii în extrema dreaptă.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blocul din dreapta rămâne.
        // Mutați elementele rămase în afara ordinii către extrema stângă.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nimic altceva de făcut, am terminat.
        width(v.as_mut_ptr(), l)
    }
}

/// Se partiționează `v` în elemente mai mici decât `v[pivot]`, urmate de elemente mai mari sau egale cu `v[pivot]`.
///
///
/// Returnează un tuplu de:
///
/// 1. Număr de elemente mai mic decât `v[pivot]`.
/// 2. Adevărat dacă `v` a fost deja partiționat.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Așezați pivotul la începutul feliei.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Citiți pivotul într-o variabilă alocată stivei pentru eficiență.
        // Dacă o operațiune de comparație următoare panics, pivotul va fi scris automat înapoi în felie.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Găsiți prima pereche de elemente nefuncționale.
        let mut l = 0;
        let mut r = v.len();

        // SIGURANȚĂ: Nesiguranța de mai jos implică indexarea unui tablou.
        // Pentru primul: verificăm deja limitele aici cu `l < r`.
        // Pentru a doua: inițial avem `l == 0` și `r == v.len()` și am verificat că `l < r` la fiecare operație de indexare.
        //                     De aici știm că `r` trebuie să fie cel puțin `r == l`, ceea ce s-a dovedit a fi valid din prima.
        unsafe {
            // Găsiți primul element mai mare sau egal cu pivotul.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Găsiți ultimul element mai mic decât pivotul.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` iese din scop și scrie pivotul (care este o variabilă alocată stivei) înapoi în felia în care se afla inițial.
        // Acest pas este esențial pentru asigurarea siguranței!
        //
    };

    // Așezați pivotul între cele două partiții.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Se partiționează `v` în elemente egale cu `v[pivot]` urmate de elemente mai mari decât `v[pivot]`.
///
/// Returnează numărul de elemente egal cu pivotul.
/// Se presupune că `v` nu conține elemente mai mici decât pivotul.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Așezați pivotul la începutul feliei.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Citiți pivotul într-o variabilă alocată stivei pentru eficiență.
    // Dacă o operațiune de comparație următoare panics, pivotul va fi scris automat înapoi în felie.
    // SIGURANȚĂ: Pointerul de aici este valid deoarece este obținut dintr-o referință la o felie.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Acum partiționăm felia.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SIGURANȚĂ: Nesiguranța de mai jos implică indexarea unui tablou.
        // Pentru primul: verificăm deja limitele aici cu `l < r`.
        // Pentru a doua: inițial avem `l == 0` și `r == v.len()` și am verificat că `l < r` la fiecare operație de indexare.
        //                     De aici știm că `r` trebuie să fie cel puțin `r == l`, ceea ce s-a dovedit a fi valid din prima.
        unsafe {
            // Găsiți primul element mai mare decât pivotul.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Găsiți ultimul element egal cu pivotul.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Am terminat?
            if l >= r {
                break;
            }

            // Schimbați perechea găsită de elemente nefuncționale.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Am găsit elemente `l` egale cu pivotul.Adăugați 1 pentru a contura pivotul în sine.
    l + 1

    // `_pivot_guard` iese din scop și scrie pivotul (care este o variabilă alocată stivei) înapoi în felia în care se afla inițial.
    // Acest pas este esențial pentru asigurarea siguranței!
}

/// Împrăștie unele elemente în jurul valorii de în încercarea de a sparge modele care ar putea provoca partiții dezechilibrate în rapid.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generator de numere pseudorandom din hârtia "Xorshift RNGs" de George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Luați numere aleatorii modulo acest număr.
        // Numărul se potrivește cu `usize`, deoarece `len` nu este mai mare decât `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Unii candidați pivot vor fi în apropierea acestui index.Să le randomizăm.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generați un număr aleatoriu modulo `len`.
            // Cu toate acestea, pentru a evita operațiuni costisitoare, luăm mai întâi modulul de putere de două, apoi scăzem cu `len` până când se încadrează în gama `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` este garantat să fie mai mic de `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Alege un pivot în `v` și returnează indexul și `true` dacă felia este probabil deja sortată.
///
/// Elementele din `v` pot fi reordonate în acest proces.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lungimea minimă pentru a alege metoda mediană a medianelor.
    // Feliile mai scurte folosesc metoda simplă mediană de trei.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Numărul maxim de swap-uri care pot fi efectuate în această funcție.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trei indici lângă care vom alege un pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Numără numărul total de swap-uri pe care urmează să le realizăm în timp ce sortăm indicii.
    let mut swaps = 0;

    if len >= 8 {
        // Indici swap astfel încât `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Indici swap astfel încât `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Găsește mediana lui `v[a - 1], v[a], v[a + 1]` și stochează indexul în `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Găsiți mediane în cartierele `a`, `b` și `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Găsiți mediana dintre `a`, `b` și `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // A fost efectuat numărul maxim de swap-uri.
        // Sunt șanse ca felia să fie descendentă sau în mare parte descendentă, deci inversarea va ajuta probabil la sortarea mai rapidă.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sortează `v` recursiv.
///
/// Dacă felia a avut un predecesor în matricea originală, aceasta este specificată ca `pred`.
///
/// `limit` este numărul de partiții dezechilibrate permise înainte de a trece la `heapsort`.
/// Dacă este zero, această funcție va trece imediat la Hacksort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Feliile de până la această lungime sunt sortate folosind sortarea prin inserare.
    const MAX_INSERTION: usize = 20;

    // Adevărat dacă ultima partiționare a fost echilibrată în mod rezonabil.
    let mut was_balanced = true;
    // Este adevărat dacă ultima partiționare nu a amestecat elemente (felia a fost deja partiționată).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Feliile foarte scurte sunt sortate folosind sortarea prin inserare.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Dacă s-au făcut prea multe alegeri de pivot proaste, pur și simplu reveniți la Hacksort pentru a garanta cel mai rău caz `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Dacă ultima partiționare a fost dezechilibrată, încercați să spargeți tiparele în felie amestecând câteva elemente în jur.
        // Sperăm că vom alege un pivot mai bun de data aceasta.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Alegeți un pivot și încercați să ghiciți dacă felia este deja sortată.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Dacă ultima partiționare a fost echilibrată decent și nu a amestecat elemente și dacă selecția pivot prezice că felia este probabil deja sortată ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Încercați să identificați mai multe elemente scoase din ordine și să le mutați în poziții corecte.
            // Dacă felia ajunge să fie complet sortată, am terminat.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Dacă pivotul ales este egal cu predecesorul, atunci este cel mai mic element din felie.
        // Împărțiți felia în elemente egale și elemente mai mari decât pivotul.
        // Acest caz este de obicei lovit atunci când felia conține multe elemente duplicate.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continuați să sortați elemente mai mari decât pivotul.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Împărțiți felia.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Împarte felia în `left`, `pivot` și `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse în partea mai scurtă numai pentru a minimiza numărul total de apeluri recursive și pentru a consuma mai puțin spațiu în stivă.
        // Apoi continuați cu partea mai lungă (aceasta este asemănătoare cu recursivitatea cozii).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sortează `v` utilizând rapidul care învinge modelul, care este *O*(*n*\*log(* n*)) în cel mai rău caz.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortarea nu are un comportament semnificativ la tipurile cu dimensiuni zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limitați numărul de partiții dezechilibrate la `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Pentru felii de până la această lungime este probabil mai rapid să le sortați pur și simplu.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Alegeți un pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Dacă pivotul ales este egal cu predecesorul, atunci este cel mai mic element din felie.
        // Împărțiți felia în elemente egale și elemente mai mari decât pivotul.
        // Acest caz este de obicei lovit atunci când felia conține multe elemente duplicate.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Dacă ne-am trecut indexul, atunci suntem buni.
                if mid > index {
                    return;
                }

                // În caz contrar, continuați să sortați elemente mai mari decât pivotul.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Împarte felia în `left`, `pivot` și `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Dacă mid==index, atunci am terminat, deoarece partition() a garantat că toate elementele după mid sunt mai mari sau egale cu mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortarea nu are un comportament semnificativ la tipurile cu dimensiuni zero.Nu face nimic.
    } else if index == v.len() - 1 {
        // Găsiți elementul max și plasați-l în ultima poziție a matricei.
        // Suntem liberi să folosim `unwrap()` aici, deoarece știm că v nu trebuie să fie gol.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Găsiți elementul min și plasați-l în prima poziție a matricei.
        // Suntem liberi să folosim `unwrap()` aici, deoarece știm că v nu trebuie să fie gol.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}