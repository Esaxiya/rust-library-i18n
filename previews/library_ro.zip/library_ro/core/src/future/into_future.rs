use crate::future::Future;

/// Conversia într-un `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Ieșirea pe care future o va produce la finalizare.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// În ce fel de future transformăm acest lucru?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Creează un future dintr-o valoare.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}