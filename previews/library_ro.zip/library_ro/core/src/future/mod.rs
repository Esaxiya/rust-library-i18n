#![stable(feature = "futures_api", since = "1.36.0")]

//! Valori asincrone.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Acest tip este necesar deoarece:
///
/// a) Generatoarele nu pot implementa `for<'a, 'b> Generator<&'a mut Context<'b>>`, deci trebuie să trecem un pointer brut (vezi <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Pointerele Raw și `NonNull` nu sunt `Send` sau `Sync`, deci ar face ca fiecare future să fie și non-Send/Sync și nu vrem asta.
///
/// De asemenea, simplifică scăderea HIR a `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Înfășurați un generator într-un future.
///
/// Această funcție returnează un `GenFuture` dedesubt, dar îl ascunde în `impl Trait` pentru a oferi mesaje de eroare mai bune (`impl Future` mai degrabă decât `GenFuture<[closure.....]>`).
///
// Acesta este `const` pentru a evita erorile suplimentare după ce ne recuperăm de la `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Ne bazăm pe faptul că async/await futures sunt imobile pentru a crea împrumuturi auto-referențiale în generatorul de bază.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SIGURANȚĂ: Sigur deoarece suntem !Unpin + !Drop, iar aceasta este doar o proiecție de câmp.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Reluați generatorul, transformând `&mut Context` într-un indicator brut `NonNull`.
            // Coborârea `.await` o va arunca în siguranță pe un `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SIGURANȚĂ: apelantul trebuie să garanteze că `cx.0` este un indicator valid
    // care îndeplinește toate cerințele pentru o referință mutabilă.
    unsafe { &mut *cx.0.as_ptr().cast() }
}