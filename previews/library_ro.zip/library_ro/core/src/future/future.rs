#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un future reprezintă un calcul asincron.
///
/// Un future este o valoare care este posibil să nu fi terminat încă calculul.
/// Acest tip de "asynchronous value" face posibil ca un fir să continue să lucreze în timp ce așteaptă ca valoarea să devină disponibilă.
///
///
/// # Metoda `poll`
///
/// Metoda de bază a future, `poll`,*încearcă* să rezolve future într-o valoare finală.
/// Această metodă nu se blochează dacă valoarea nu este gata.
/// În schimb, sarcina curentă este programată să fie trezită atunci când este posibil să se realizeze progrese ulterioare prin " sondarea" din nou.
/// `context` trecut la metoda `poll` poate oferi un [`Waker`], care este un mâner pentru trezirea sarcinii curente.
///
/// Când utilizați un future, în general nu veți apela direct `poll`, ci în schimb `.await` valoarea.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Tipul valorii produse la finalizare.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Încercați să rezolvați future la o valoare finală, înregistrând sarcina curentă pentru trezire dacă valoarea nu este încă disponibilă.
    ///
    /// # Valoare returnată
    ///
    /// Această funcție returnează:
    ///
    /// - [`Poll::Pending`] dacă future nu este încă gata
    /// - [`Poll::Ready(val)`] cu rezultatul `val` al acestui future dacă a terminat cu succes.
    ///
    /// Odată ce un future s-a terminat, clienții nu ar trebui să îl `poll` din nou.
    ///
    /// Când un future nu este încă gata, `poll` returnează `Poll::Pending` și stochează o clonă a [`Waker`] copiată din [`Context`] curent.
    /// Acest [`Waker`] este apoi trezit odată ce future poate face progrese.
    /// De exemplu, un future care așteaptă ca o priză să devină lizibilă va apela `.clone()` pe [`Waker`] și îl va stoca.
    /// Când un semnal ajunge în altă parte care indică faptul că soclul este lizibil, se apelează [`Waker::wake`] și sarcina soclului future este trezită.
    /// Odată ce o sarcină a fost trezită, ar trebui să încerce să `poll` din nou future, care poate produce sau nu o valoare finală.
    ///
    /// Rețineți că la mai multe apeluri către `poll`, numai [`Waker`] de la [`Context`] trecut la cel mai recent apel ar trebui să fie programat pentru a primi o trezire.
    ///
    /// # Caracteristici de rulare
    ///
    /// Futures singur este *inert*;ele trebuie să fie " active *" sondate " pentru a face progrese, ceea ce înseamnă că de fiecare dată când sarcina curentă este trezită, aceasta ar trebui să" reînscrie `activ în așteptarea futures în care are încă un interes.
    ///
    /// Funcția `poll` nu este apelată în mod repetat într-o buclă strânsă-în schimb, ar trebui apelată numai atunci când future indică faptul că este gata să progreseze (apelând `wake()`).
    /// Dacă sunteți familiarizați cu sistemele `poll(2)` sau `select(2)` de pe Unix, merită remarcat faptul că futures de obicei *nu* suferă aceleași probleme ca "all wakeups must poll all events";seamănă mai mult cu `epoll(4)`.
    ///
    /// O implementare a `poll` ar trebui să se străduiască să revină rapid și nu ar trebui să se blocheze.Revenirea rapidă previne înfundarea inutilă a firelor sau a buclelor de evenimente.
    /// Dacă se știe din timp că un apel către `poll` poate ajunge să dureze o perioadă, lucrarea ar trebui descărcată într-un pool de fire (sau ceva similar) pentru a se asigura că `poll` se poate întoarce rapid.
    ///
    /// # Panics
    ///
    /// Odată ce un future s-a finalizat (a returnat `Ready` de la `poll`), apelarea din nou a metodei `poll` poate panic, să se blocheze definitiv sau să provoace alte tipuri de probleme;`Future` trait nu impune cerințe asupra efectelor unui astfel de apel.
    /// Cu toate acestea, întrucât metoda `poll` nu este marcată `unsafe`, se aplică regulile obișnuite ale Rust: apelurile nu trebuie să provoace niciodată un comportament nedefinit (corupția memoriei, utilizarea incorectă a funcțiilor `unsafe` sau altele asemenea), indiferent de starea future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}