use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Un wrapper pentru a împiedica compilatorul să apeleze automat distructorul lui " T`.
/// Acest ambalaj are un cost de 0.
///
/// `ManuallyDrop<T>` este supus acelorași optimizări de aspect ca și `T`.
/// În consecință, nu are *niciun efect* asupra ipotezelor pe care compilatorul le face despre conținutul său.
/// De exemplu, inițializarea unui `ManuallyDrop<&mut T>` cu [`mem::zeroed`] este un comportament nedefinit.
/// Dacă trebuie să gestionați date neinițializate, utilizați în schimb [`MaybeUninit<T>`].
///
/// Rețineți că accesarea valorii în interiorul unui `ManuallyDrop<T>` este sigură.
/// Aceasta înseamnă că un `ManuallyDrop<T>` al cărui conținut a fost abandonat nu trebuie expus printr-un API sigur public.
/// În mod corespunzător, `ManuallyDrop::drop` este nesigur.
///
/// # `ManuallyDrop` și comanda de drop.
///
/// Rust are un [drop order] de valori bine definit.
/// Pentru a vă asigura că câmpurile sau localnicii sunt aruncați într-o anumită ordine, reordonați declarațiile astfel încât ordinea de aruncare implicită să fie cea corectă.
///
/// Este posibil să utilizați `ManuallyDrop` pentru a controla ordinea de scădere, dar acest lucru necesită cod nesigur și este greu de realizat corect în prezența derulării.
///
///
/// De exemplu, dacă doriți să vă asigurați că un anumit câmp este abandonat după celelalte, faceți din acesta ultimul câmp al unei structuri:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` va fi abandonat după `children`.
///     // Rust garantează că câmpurile sunt abandonate în ordinea declarației.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Înfășurați o valoare pentru a fi abandonată manual.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Puteți totuși să folosiți valoarea în siguranță
    /// assert_eq!(*x, "Hello");
    /// // Dar `Drop` nu va fi rulat aici
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrage valoarea din containerul `ManuallyDrop`.
    ///
    /// Aceasta permite ca valoarea să fie scăzută din nou.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Aceasta scade `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Scoate valoarea din containerul `ManuallyDrop<T>`.
    ///
    /// Această metodă este destinată în primul rând mutării valorilor în scădere.
    /// În loc să utilizați [`ManuallyDrop::drop`] pentru a renunța manual la valoare, puteți utiliza această metodă pentru a lua valoarea și a o folosi oricum doriți.
    ///
    /// Ori de câte ori este posibil, este de preferat să utilizați în schimb [`into_inner`][`ManuallyDrop::into_inner`], ceea ce împiedică duplicarea conținutului `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Această funcție mută semantic valoarea conținută fără a împiedica utilizarea ulterioară, lăsând starea acestui container neschimbată.
    /// Este responsabilitatea dumneavoastră să vă asigurați că acest `ManuallyDrop` nu este utilizat din nou.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SIGURANȚĂ: citim dintr-o referință, care este garantată
        // să fie valabil pentru citiri.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Scade manual valoarea conținută.Acest lucru este exact echivalent cu apelarea [`ptr::drop_in_place`] cu un pointer la valoarea conținută.
    /// Ca atare, cu excepția cazului în care valoarea conținută este o structură împachetată, destructorul va fi chemat în loc fără a muta valoarea și, astfel, poate fi utilizat pentru a renunța în siguranță la datele [pinned].
    ///
    /// Dacă dețineți proprietatea asupra valorii, puteți folosi în schimb [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Această funcție execută distructorul valorii conținute.
    /// În afară de modificările făcute de distructor în sine, memoria rămâne neschimbată și, în ceea ce privește compilatorul, deține încă un model de biți valabil pentru tipul `T`.
    ///
    ///
    /// Cu toate acestea, această valoare "zombie" nu trebuie expusă codului sigur, iar această funcție nu trebuie apelată de mai multe ori.
    /// Pentru a utiliza o valoare după ce a fost abandonată sau pentru a renunța la o valoare de mai multe ori, se poate produce un Comportament nedefinit (în funcție de ceea ce face `drop`).
    /// Acest lucru este în mod normal împiedicat de sistemul de tip, dar utilizatorii `ManuallyDrop` trebuie să susțină acele garanții fără asistența din partea compilatorului.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SIGURANȚĂ: renunțăm la valoarea indicată de o referință mutabilă
        // care este garantat a fi valabil pentru scrieri.
        // Depinde de apelant să se asigure că `slot` nu este abandonat din nou.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}