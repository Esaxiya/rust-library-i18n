use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Un tip de împachetare pentru a construi instanțe neinițializate de `T`.
///
/// # Invariant de inițializare
///
/// Compilatorul, în general, presupune că o variabilă este inițializată corespunzător în funcție de cerințele tipului variabilei.De exemplu, o variabilă de tip referință trebuie să fie aliniată și să nu fie NULL.
/// Acesta este un invariant care trebuie * întotdeauna confirmat, chiar și în coduri nesigure.
/// În consecință, inițializarea zero a unei variabile de tip de referință provoacă [undefined behavior][ub] instantaneu, indiferent dacă această referință se folosește vreodată pentru a accesa memoria:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // comportament nedefinit!⚠️
/// // Codul echivalent cu `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // comportament nedefinit!⚠️
/// ```
///
/// Acest lucru este exploatat de compilator pentru diverse optimizări, cum ar fi evitarea verificărilor în timpul rulării și optimizarea aspectului `enum`.
///
/// În mod similar, memoria complet neinițializată poate avea orice conținut, în timp ce un `bool` trebuie să fie întotdeauna `true` sau `false`.Prin urmare, crearea unui `bool` neinițializat este un comportament nedefinit:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // comportament nedefinit!⚠️
/// // Codul echivalent cu `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // comportament nedefinit!⚠️
/// ```
///
/// Mai mult, memoria neinițializată este specială prin faptul că nu are o valoare fixă ("fixed" însemnând "it won't change without being written to").Citirea aceluiași octet neinițializat de mai multe ori poate da rezultate diferite.
/// Acest lucru face ca comportamentul nedefinit să aibă date neinițializate într-o variabilă, chiar dacă acea variabilă are un tip întreg, care altfel poate conține orice tipar de biți *fix*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // comportament nedefinit!⚠️
/// // Codul echivalent cu `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // comportament nedefinit!⚠️
/// ```
/// (Observați că regulile în jurul numerelor întregi neinițializate nu sunt încă finalizate, dar până la finalizarea acestora, este recomandabil să le evitați.)
///
/// Mai mult decât atât, amintiți-vă că majoritatea tipurilor au invarianți suplimentari dincolo de simpla considerare inițializată la nivel de tip.
/// De exemplu, un [`Vec<T>`] inițializat cu " 1` este considerat inițializat (în cadrul implementării actuale; aceasta nu constituie o garanție stabilă), deoarece singura cerință pe care compilatorul o știe este că indicatorul de date trebuie să fie nul.
/// Crearea unui astfel de `Vec<T>` nu provoacă un comportament *imediat* nedefinit, dar va provoca un comportament nedefinit cu cele mai multe operațiuni sigure (inclusiv renunțarea la acesta).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` servește pentru a permite codului nesigur să se ocupe de date neinițializate.
/// Este un semnal către compilator care indică faptul că datele de aici pot *nu* fi inițializate:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Creați o referință explicit neinițializată.
/// // Compilatorul știe că datele dintr-un `MaybeUninit<T>` pot fi nevalide și, prin urmare, acest lucru nu este UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Setați-l la o valoare validă.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extrageți datele inițializate-acest lucru este permis numai *după* inițializarea corectă a `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Compilatorul știe apoi să nu facă presupuneri sau optimizări incorecte asupra acestui cod.
///
/// Vă puteți gândi la `MaybeUninit<T>` ca la un pic ca `Option<T>`, dar fără urmărirea în timp de execuție și fără niciunul dintre controalele de siguranță.
///
/// ## out-pointers
///
/// Puteți utiliza `MaybeUninit<T>` pentru a implementa "out-pointers": în loc să returnați datele dintr-o funcție, treceți-l cu un pointer în memoria (uninitialized) pentru a pune rezultatul.
/// Acest lucru poate fi util atunci când este important pentru apelant să controleze modul în care este alocată memoria în care este stocat rezultatul și doriți să evitați mișcările inutile.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nu renunță la conținutul vechi, ceea ce este important.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Acum știm că `v` este inițializat!Acest lucru asigură, de asemenea, că vector este scăpat în mod corespunzător.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inițializarea unui tablou element cu element
///
/// `MaybeUninit<T>` poate fi folosit pentru a inițializa o matrice mare element cu element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Creați o matrice neinițializată de `MaybeUninit`.
///     // `assume_init` este sigur, deoarece tipul pe care pretindem că l-am inițializat aici este o grămadă de " MaybeUninit`, care nu necesită inițializare.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Scăderea unui `MaybeUninit` nu face nimic.
///     // Astfel, utilizarea alocării indicatorului brut în loc de `ptr::write` nu determină scăderea vechii valori neinițializate.
/////
///     // De asemenea, dacă există un panic în timpul acestei bucle, avem o scurgere de memorie, dar nu există nicio problemă de siguranță a memoriei.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Totul este inițializat.
///     // Transmutați matricea la tipul inițializat.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// De asemenea, puteți lucra cu tablouri parțial inițializate, care ar putea fi găsite în structurile de date de nivel scăzut.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Creați o matrice neinițializată de `MaybeUninit`.
/// // `assume_init` este sigur, deoarece tipul pe care pretindem că l-am inițializat aici este o grămadă de " MaybeUninit`, care nu necesită inițializare.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Numărați numărul de elemente pe care le-am atribuit.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Pentru fiecare element din matrice, renunțați dacă l-am alocat.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inițializarea unei structuri câmp cu câmp
///
/// Puteți utiliza `MaybeUninit<T>` și macrocomanda [`std::ptr::addr_of_mut`] pentru a inițializa structurile câmp cu câmp:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inițializarea câmpului `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inițializarea câmpului `list` Dacă există un panic aici, atunci `String` în câmpul `name` se scurge.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Toate câmpurile sunt inițializate, așa că apelăm `assume_init` pentru a obține un Foo inițializat.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` este garantat să aibă aceeași dimensiune, aliniament și ABI ca și `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Nu uitați însă că un tip *care conține* un `MaybeUninit<T>` nu este neapărat același aspect;Rust nu garantează în general că câmpurile unui `Foo<T>` au aceeași ordine ca un `Foo<U>`, chiar dacă `T` și `U` au aceeași dimensiune și aliniere.
///
/// În plus, deoarece orice valoare de bit este validă pentru un `MaybeUninit<T>`, compilatorul nu poate aplica optimizări non-zero/niche-filling, ceea ce poate duce la o dimensiune mai mare:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Dacă `T` este sigur pentru FFI, atunci este și `MaybeUninit<T>`.
///
/// În timp ce `MaybeUninit` este `#[repr(transparent)]` (indicând faptul că garantează aceeași dimensiune, aliniament și ABI ca și `T`), acest lucru nu modifică niciuna dintre prevederile anterioare.
/// `Option<T>` și `Option<MaybeUninit<T>>` pot avea în continuare dimensiuni diferite, iar tipurile care conțin un câmp de tip `T` pot fi așezate (și dimensionate) diferit decât dacă acel câmp ar fi `MaybeUninit<T>`.
/// `MaybeUninit` este de tip uniune, iar `#[repr(transparent)]` pe uniuni este instabil (vezi [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// În timp, garanțiile exacte ale `#[repr(transparent)]` pe uniuni pot evolua, iar `MaybeUninit` poate rămâne sau nu `#[repr(transparent)]`.
/// Acestea fiind spuse, `MaybeUninit<T>` va garanta *întotdeauna* că are aceeași dimensiune, aliniament și ABI ca și `T`;doar că modul în care implementează `MaybeUninit` această garanție poate evolua.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Elementul Lang, astfel încât să putem înfășura alte tipuri în el.Acest lucru este util pentru generatoare.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Dacă nu sunăm la `T::clone()`, nu putem ști dacă suntem suficient de inițializați pentru asta.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Creează un nou `MaybeUninit<T>` inițializat cu valoarea dată.
    /// Este sigur să apelați [`assume_init`] la valoarea returnată a acestei funcții.
    ///
    /// Rețineți că scăderea unui `MaybeUninit<T>` nu va apela niciodată codul de " T`.
    /// Este responsabilitatea dumneavoastră să vă asigurați că `T` este abandonat dacă a fost inițializat.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Creează un nou `MaybeUninit<T>` într-o stare neinițializată.
    ///
    /// Rețineți că scăderea unui `MaybeUninit<T>` nu va apela niciodată codul de " T`.
    /// Este responsabilitatea dumneavoastră să vă asigurați că `T` este abandonat dacă a fost inițializat.
    ///
    /// Consultați [type-level documentation][MaybeUninit] pentru câteva exemple.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Creați o nouă matrice de articole `MaybeUninit<T>`, într-o stare neinițială.
    ///
    /// Note: într-o versiune future Rust această metodă poate deveni inutilă atunci când sintaxa literală a matricei permite [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Exemplul de mai jos ar putea folosi `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Returnează o porțiune (posibil mai mică) de date care a fost de fapt citită
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SIGURANȚĂ: Un `[MaybeUninit<_>; LEN]` neinițializat este valid.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Creează un nou `MaybeUninit<T>` într-o stare neinițializată, memoria fiind umplută cu octeți `0`.Depinde de `T` dacă acest lucru face deja inițializarea corectă.
    ///
    /// De exemplu, `MaybeUninit<usize>::zeroed()` este inițializat, dar `MaybeUninit<&'static i32>::zeroed()` nu deoarece referințele nu trebuie să fie nule.
    ///
    /// Rețineți că scăderea unui `MaybeUninit<T>` nu va apela niciodată codul de " T`.
    /// Este responsabilitatea dumneavoastră să vă asigurați că `T` este abandonat dacă a fost inițializat.
    ///
    /// # Example
    ///
    /// Utilizarea corectă a acestei funcții: inițializarea unei structuri cu zero, unde toate câmpurile structurii pot deține modelul de biți 0 ca valoare validă.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// * Utilizare incorectă a acestei funcții: apelarea `x.zeroed().assume_init()` când `0` nu este un model de biți valid pentru tipul:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // În interiorul unei perechi, creăm un `NotZero` care nu are un discriminant valid.
    /// // Acesta este un comportament nedefinit.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SIGURANȚĂ: `u.as_mut_ptr()` indică memoria alocată.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Setează valoarea `MaybeUninit<T>`.
    /// Aceasta suprascrie orice valoare anterioară fără a o scăpa, așa că aveți grijă să nu o utilizați de două ori, cu excepția cazului în care doriți să omiteți rularea distructorului.
    ///
    /// Pentru confortul dvs., acest lucru returnează, de asemenea, o referință mutabilă la conținutul (acum inițializat în siguranță) al `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SIGURANȚĂ: Tocmai am inițializat această valoare.
        unsafe { self.assume_init_mut() }
    }

    /// Obține un indicator către valoarea conținută.
    /// Citirea din acest indicator sau transformarea acestuia într-o referință este un comportament nedefinit, cu excepția cazului în care `MaybeUninit<T>` este inițializat.
    /// Scrierea în memorie la care indică acest pointer (non-transitively) este un comportament nedefinit (cu excepția unui `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Utilizarea corectă a acestei metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Creați o referință în `MaybeUninit<T>`.Acest lucru este în regulă pentru că l-am inițializat.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Utilizarea incorectă a acestei metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Am creat o referință la un vector neinițializat!Acesta este un comportament nedefinit.⚠️
    /// ```
    ///
    /// (Observați că regulile referitoare la referințele la date neinițializate nu sunt încă finalizate, dar până la finalizarea acestora, este recomandabil să le evitați.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` și `ManuallyDrop` sunt ambele `repr(transparent)`, astfel încât să putem arunca indicatorul.
        self as *const _ as *const T
    }

    /// Obține un indicator mutabil la valoarea conținută.
    /// Citirea din acest indicator sau transformarea acestuia într-o referință este un comportament nedefinit, cu excepția cazului în care `MaybeUninit<T>` este inițializat.
    ///
    /// # Examples
    ///
    /// Utilizarea corectă a acestei metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Creați o referință în `MaybeUninit<Vec<u32>>`.
    /// // Acest lucru este în regulă pentru că l-am inițializat.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Utilizarea incorectă a acestei metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Am creat o referință la un vector neinițializat!Acesta este un comportament nedefinit.⚠️
    /// ```
    ///
    /// (Observați că regulile referitoare la referințele la date neinițializate nu sunt încă finalizate, dar până la finalizarea acestora, este recomandabil să le evitați.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` și `ManuallyDrop` sunt ambele `repr(transparent)`, astfel încât să putem arunca indicatorul.
        self as *mut _ as *mut T
    }

    /// Extrage valoarea din containerul `MaybeUninit<T>`.Aceasta este o modalitate excelentă de a vă asigura că datele vor fi abandonate, deoarece `T` rezultat este supus manipulării obișnuite a căderii.
    ///
    /// # Safety
    ///
    /// Depinde de apelant să garanteze că `MaybeUninit<T>` este într-adevăr într-o stare inițializată.Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament imediat nedefinit.
    /// [type-level documentation][inv] conține mai multe informații despre acest invariant de inițializare.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Mai mult decât atât, amintiți-vă că majoritatea tipurilor au invarianți suplimentari dincolo de simpla considerare inițializată la nivel de tip.
    /// De exemplu, un [`Vec<T>`] inițializat cu " 1` este considerat inițializat (în cadrul implementării actuale; aceasta nu constituie o garanție stabilă), deoarece singura cerință pe care compilatorul o știe este că indicatorul de date trebuie să fie nul.
    ///
    /// Crearea unui astfel de `Vec<T>` nu provoacă un comportament *imediat* nedefinit, dar va provoca un comportament nedefinit cu cele mai multe operațiuni sigure (inclusiv renunțarea la acesta).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Utilizarea corectă a acestei metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Utilizarea incorectă a acestei metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` nu fusese încă inițializat, deci această ultimă linie a provocat un comportament nedefinit.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` este inițializat.
        // Aceasta înseamnă, de asemenea, că `self` trebuie să fie o variantă `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Citește valoarea din containerul `MaybeUninit<T>`.`T` rezultat este supus manipulării obișnuite a căderii.
    ///
    /// Ori de câte ori este posibil, este de preferat să utilizați în schimb [`assume_init`], ceea ce împiedică duplicarea conținutului `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Depinde de apelant să garanteze că `MaybeUninit<T>` este într-adevăr într-o stare inițializată.Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament nedefinit.
    /// [type-level documentation][inv] conține mai multe informații despre acest invariant de inițializare.
    ///
    /// Mai mult, acest lucru lasă o copie a acelorași date în `MaybeUninit<T>`.
    /// Când utilizați mai multe copii ale datelor (apelând `assume_init_read` de mai multe ori sau apelând mai întâi `assume_init_read` și apoi [`assume_init`]), vă revine responsabilitatea de a vă asigura că aceste date pot fi într-adevăr duplicate.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Utilizarea corectă a acestei metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` este `Copy`, deci este posibil să citim de mai multe ori.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicarea unei valori `None` este în regulă, deci este posibil să citim de mai multe ori.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Utilizarea incorectă a acestei metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Acum am creat două copii ale aceluiași vector, ducând la o dublă gratuită ⚠️ atunci când ambii sunt renunțați!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` este inițializat.
        // Citirea din `self.as_ptr()` este sigură, deoarece `self` ar trebui inițializat.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Renunță la valoarea conținută la locul său.
    ///
    /// Dacă dețineți proprietatea asupra `MaybeUninit`, puteți utiliza în schimb [`assume_init`].
    ///
    /// # Safety
    ///
    /// Depinde de apelant să garanteze că `MaybeUninit<T>` este într-adevăr într-o stare inițializată.Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament nedefinit.
    ///
    /// În plus, trebuie să fie satisfăcuți toți invarianții suplimentari de tipul `T`, deoarece implementarea `Drop` a `T` (sau membrii săi) se poate baza pe aceasta.
    /// De exemplu, un [`Vec<T>`] inițializat cu " 1` este considerat inițializat (în cadrul implementării actuale; aceasta nu constituie o garanție stabilă), deoarece singura cerință pe care compilatorul o știe este că indicatorul de date trebuie să fie nul.
    ///
    /// Renunțarea la un astfel de `Vec<T>` va provoca totuși un comportament nedefinit.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` este inițializat și
        // satisface toți invarianții `T`.
        // Reducerea valorii la locul lor este sigură dacă acesta este cazul.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Obține o referință partajată la valoarea conținută.
    ///
    /// Acest lucru poate fi util atunci când dorim să accesăm un `MaybeUninit` care a fost inițializat, dar care nu deține proprietatea asupra `MaybeUninit` (împiedicând utilizarea `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Apelarea atunci când conținutul nu este încă complet inițializat provoacă un comportament nedefinit: depinde de apelant să garanteze că `MaybeUninit<T>` este într-adevăr într-o stare inițializată.
    ///
    ///
    /// # Examples
    ///
    /// ### Utilizarea corectă a acestei metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inițializați `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Acum, după ce se știe că `MaybeUninit<_>`-ul nostru este inițializat, este bine să creați o referință comună la acesta:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SIGURANȚĂ: `x` a fost inițializat.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Utilizări *incorecte* ale acestei metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Am creat o referință la un vector neinițializat!Acesta este un comportament nedefinit.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inițializați `MaybeUninit` folosind `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referință la un `Cell<bool>` neinițializat: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` este inițializat.
        // Aceasta înseamnă, de asemenea, că `self` trebuie să fie o variantă `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Obține o referință mutabilă (unique) la valoarea conținută.
    ///
    /// Acest lucru poate fi util atunci când dorim să accesăm un `MaybeUninit` care a fost inițializat, dar care nu deține proprietatea asupra `MaybeUninit` (împiedicând utilizarea `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Apelarea atunci când conținutul nu este încă complet inițializat provoacă un comportament nedefinit: depinde de apelant să garanteze că `MaybeUninit<T>` este într-adevăr într-o stare inițializată.
    /// De exemplu, `.assume_init_mut()` nu poate fi utilizat pentru a inițializa un `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Utilizarea corectă a acestei metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inițializează *toate* octeții bufferului de intrare.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inițializați `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Acum știm că `buf` a fost inițializat, așa că am putea să-l `.assume_init()`.
    /// // Cu toate acestea, utilizarea `.assume_init()` poate declanșa un `memcpy` din 2048 octeți.
    /// // Pentru a afirma că tamponul nostru a fost inițializat fără a-l copia, actualizăm `&mut MaybeUninit<[u8; 2048]>` la un `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SIGURANȚĂ: `buf` a fost inițializat.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Acum putem folosi `buf` ca o felie normală:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Utilizări *incorecte* ale acestei metode:
    ///
    /// Nu puteți utiliza `.assume_init_mut()` pentru a inițializa o valoare:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Am creat o referință (mutable) la un `bool` neinițializat!
    ///     // Acesta este un comportament nedefinit.⚠️
    /// }
    /// ```
    ///
    /// De exemplu, nu puteți [`Read`] într-un tampon neinițializat:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referire la memoria neinițializată!
    ///                             // Acesta este un comportament nedefinit.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Nici nu puteți utiliza accesul direct pe câmp pentru a inițializa treptat câmp cu câmp:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referire la memoria neinițializată!
    ///                  // Acesta este un comportament nedefinit.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referire la memoria neinițializată!
    ///                  // Acesta este un comportament nedefinit.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): În prezent, ne bazăm pe faptul că cele de mai sus sunt incorecte, adică avem referințe la date neinițializate (de exemplu, în `libcore/fmt/float.rs`).
    // Ar trebui să luăm o decizie finală cu privire la reguli înainte de stabilizare.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` este inițializat.
        // Aceasta înseamnă, de asemenea, că `self` trebuie să fie o variantă `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrage valorile dintr-o matrice de containere `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Depinde de apelant să garanteze că toate elementele matricei sunt într-o stare inițializată.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SIGURANȚĂ: Acum sigur, deoarece am inițializat toate elementele
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Apelantul garantează că toate elementele matricei sunt inițializate
        // * `MaybeUninit<T>` și T sunt garantate pentru a avea același aspect
        // * Poate că Unint nu scade, deci nu există libere duble și astfel conversia este sigură
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Presupunând că toate elementele sunt inițializate, obțineți o felie pentru ele.
    ///
    /// # Safety
    ///
    /// Depinde de apelant să garanteze că elementele `MaybeUninit<T>` sunt într-adevăr într-o stare inițializată.
    ///
    /// Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament nedefinit.
    ///
    /// Consultați [`assume_init_ref`] pentru mai multe detalii și exemple.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SIGURANȚĂ: aruncarea feliei pe un `*const [T]` este sigură, deoarece apelantul garantează acest lucru
        // `slice` este inițializat, iar " PoateUninit` este garantat să aibă același aspect ca `T`.
        // Pointerul obținut este valid, deoarece se referă la memoria deținută de `slice`, care este o referință și, prin urmare, garantată pentru a fi validă pentru citiri.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Presupunând că toate elementele sunt inițializate, obțineți o felie mutabilă pentru ele.
    ///
    /// # Safety
    ///
    /// Depinde de apelant să garanteze că elementele `MaybeUninit<T>` sunt într-adevăr într-o stare inițializată.
    ///
    /// Apelarea la acest lucru atunci când conținutul nu este încă inițializat complet provoacă un comportament nedefinit.
    ///
    /// Consultați [`assume_init_mut`] pentru mai multe detalii și exemple.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SIGURANȚĂ: similar cu notele de siguranță pentru `slice_get_ref`, dar avem un
        // referință mutabilă, care este, de asemenea, garantată pentru a fi valabilă pentru scrieri.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Obține un pointer către primul element al matricei.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Obține un pointer mutabil către primul element al matricei.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copiază elementele de la `src` la `this`, returnând o referință mutabilă la conținutul acum initalizat al `this`.
    ///
    /// Dacă `T` nu implementează `Copy`, utilizați [`write_slice_cloned`]
    ///
    /// Acest lucru este similar cu [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă cele două felii au lungimi diferite.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURANȚĂ: tocmai am copiat toate elementele de len în capacitatea de rezervă
    /// // primele elemente src.len() ale vec sunt valabile acum.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SIGURANȚĂ: &[T] și&[MaybeUninit<T>] au același aspect
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SIGURANȚĂ: Elementele valide tocmai au fost copiate în `this`, astfel încât să fie inițializate
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clonează elementele de la `src` la `this`, returnând o referință mutabilă la conținutul acum initalizat al `this`.
    /// Orice element deja inițializat nu va fi abandonat.
    ///
    /// Dacă `T` implementează `Copy`, utilizați [`write_slice`]
    ///
    /// Acest lucru este similar cu [`slice::clone_from_slice`], dar nu renunță la elementele existente.
    ///
    /// # Panics
    ///
    /// Această funcție va panic dacă cele două felii au lungimi diferite sau dacă implementarea `Clone` panics.
    ///
    /// Dacă există un panic, elementele deja clonate vor fi abandonate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURANȚĂ: tocmai am clonat toate elementele de len în capacitatea de rezervă
    /// // primele elemente src.len() ale vec sunt valabile acum.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // spre deosebire de copy_from_slice, aceasta nu apelează clone_from_slice pe felie, deoarece `MaybeUninit<T: Clone>` nu implementează Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SIGURANȚĂ: această felie brută va conține doar obiecte inițializate
                // de aceea, este permis să îl aruncați.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Trebuie să le tăiem în mod explicit la aceeași lungime
        // pentru eliminarea verificării limitelor, iar optimizatorul va genera memcpy pentru cazuri simple (de exemplu T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Este nevoie de pază b/c panic s-ar putea întâmpla în timpul unei clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SIGURANȚĂ: Elementele valide tocmai au fost scrise în `this`, deci sunt inițializate
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}