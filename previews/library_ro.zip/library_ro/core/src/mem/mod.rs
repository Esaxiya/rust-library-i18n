//! Funcții de bază pentru gestionarea memoriei.
//!
//! Acest modul conține funcții pentru interogarea dimensiunii și alinierii tipurilor, inițializarea și manipularea memoriei.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Preia proprietatea și "forgets" despre valoarea **fără a rula distructorul**.
///
/// Orice resursă gestionată de valoare, cum ar fi memoria heap sau un controler de fișier, va rămâne pentru totdeauna într-o stare inaccesibilă.Cu toate acestea, nu garantează că indicatoarele către această memorie vor rămâne valabile.
///
/// * Dacă doriți să scăpați de memorie, consultați [`Box::leak`].
/// * Dacă doriți să obțineți un indicator brut în memorie, consultați [`Box::into_raw`].
/// * Dacă doriți să eliminați corect o valoare, executând distructorul acesteia, consultați [`mem::drop`].
///
/// # Safety
///
/// `forget` nu este marcat ca `unsafe`, deoarece garanțiile de siguranță ale Rust nu includ o garanție că destructorii vor funcționa întotdeauna.
/// De exemplu, un program poate crea un ciclu de referință folosind [`Rc`][rc] sau poate apela [`process::exit`][exit] pentru a ieși fără a rula distructori.
/// Astfel, permiterea `mem::forget` din cod sigur nu modifică fundamental garanțiile de siguranță ale Rust.
///
/// Acestea fiind spuse, scurgerea resurselor precum memoria sau obiectele I/O este de obicei nedorită.
/// Necesitatea apare în unele cazuri de utilizare specializate pentru codul FFI sau nesigur, dar chiar și atunci, [`ManuallyDrop`] este de obicei preferat.
///
/// Deoarece uitarea unei valori este permisă, orice cod `unsafe` pe care îl scrieți trebuie să permită această posibilitate.Nu puteți returna o valoare și vă așteptați ca apelantul să execute în mod necesar distructorul valorii.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Utilizarea sigură canonică a `mem::forget` este de a ocoli distructorul unei valori implementat de `Drop` trait.De exemplu, acesta va scurge un `File`, adică
/// recuperați spațiul ocupat de variabilă, dar nu închideți niciodată resursa de bază a sistemului:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Acest lucru este util atunci când proprietatea asupra resursei de bază a fost transferată anterior către cod în afara Rust, de exemplu prin transmiterea descriptorului de fișiere brute către codul C.
///
/// # Relația cu `ManuallyDrop`
///
/// În timp ce `mem::forget` poate fi utilizat și pentru a transfera proprietatea *memoriei*, acest lucru este predispus la erori.
/// [`ManuallyDrop`] ar trebui folosit în schimb.Luați în considerare, de exemplu, acest cod:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Construiți un `String` folosind conținutul `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // scurge `v` deoarece memoria sa este acum gestionată de `s`
/// mem::forget(v);  // EROARE, v este nevalid și nu trebuie transmis unei funcții
/// assert_eq!(s, "Az");
/// // `s` este implicit abandonat și memoria sa este alocată.
/// ```
///
/// Există două probleme cu exemplul de mai sus:
///
/// * Dacă s-ar adăuga mai mult cod între construcția lui `String` și invocarea lui `mem::forget()`, un panic din acesta ar provoca o dublă liberă, deoarece aceeași memorie este gestionată atât de `v`, cât și de `s`.
/// * După ce ați apelat `v.as_mut_ptr()` și ați transmis proprietatea datelor către `s`, valoarea `v` este nevalidă.
/// Chiar și atunci când o valoare este mutată în `mem::forget` (care nu o va inspecta), unele tipuri au cerințe stricte privind valorile lor, care le fac nevalide atunci când sunt suspendate sau nu mai sunt deținute.
/// Utilizarea valorilor nevalide în orice mod, inclusiv transmiterea acestora sau returnarea acestora din funcții, constituie un comportament nedefinit și poate rupe ipotezele făcute de compilator.
///
/// Trecerea la `ManuallyDrop` evită ambele probleme:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Înainte de a dezasambla `v` în piesele sale brute, asigurați-vă că nu scade!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Acum dezasamblați `v`.Aceste operațiuni nu pot panic, deci nu poate exista o scurgere.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // În cele din urmă, construiți un `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` este implicit abandonat și memoria sa este alocată.
/// ```
///
/// `ManuallyDrop` previne în mod robust dublu-liber, deoarece dezactivăm distructorul `v` înainte de a face orice altceva.
/// `mem::forget()` nu permite acest lucru, deoarece își consumă argumentul, forțându-ne să-l apelăm numai după ce extragem tot ce avem nevoie din `v`.
/// Chiar dacă s-ar introduce un panic între construcția `ManuallyDrop` și construirea șirului (ceea ce nu se poate întâmpla în cod așa cum se arată), ar rezulta o scurgere și nu o dublă liberă.
/// Cu alte cuvinte, `ManuallyDrop` greșește pe partea de scurgere în loc să greșească pe partea de (dublă) cădere.
///
/// De asemenea, `ManuallyDrop` ne împiedică să trecem la "touch" `v` după transferul proprietății către `s`-pasul final al interacțiunii cu `v` pentru a-l elimina fără a-l rula distructorul este complet evitat.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// La fel ca [`forget`], dar acceptă și valori nedimensionate.
///
/// Această funcție este doar o carcasă destinată eliminării atunci când caracteristica `unsized_locals` se stabilizează.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Returnează dimensiunea unui tip în octeți.
///
/// Mai precis, acesta este compensarea în octeți între elementele succesive dintr-o matrice cu acel tip de element, inclusiv umplerea alinierii.
///
/// Astfel, pentru orice tip `T` și lungime `n`, `[T; n]` are o dimensiune de `n * size_of::<T>()`.
///
/// În general, dimensiunea unui tip nu este stabilă în cadrul compilațiilor, dar sunt tipuri specifice, cum ar fi primitivele.
///
/// Următorul tabel oferă dimensiunea primitivelor.
///
/// Tastați |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 caractere |4
///
/// Mai mult, `usize` și `isize` au aceeași dimensiune.
///
/// Tipurile `*const T`, `&T`, `Box<T>`, `Option<&T>` și `Option<Box<T>>` au toate aceeași dimensiune.
/// Dacă `T` este Sized, toate aceste tipuri au aceeași dimensiune ca `usize`.
///
/// Mutabilitatea unui indicator nu modifică dimensiunea acestuia.Ca atare, `&T` și `&mut T` au aceeași dimensiune.
/// La fel și pentru `*const T` și `* mut T`.
///
/// # Dimensiunea articolelor `#[repr(C)]`
///
/// Reprezentarea `C` pentru articole are un aspect definit.
/// Cu acest aspect, dimensiunea articolelor este, de asemenea, stabilă, atâta timp cât toate câmpurile au o dimensiune stabilă.
///
/// ## Dimensiunea structurilor
///
/// Pentru `structs`, dimensiunea este determinată de următorul algoritm.
///
/// Pentru fiecare câmp din structură ordonat prin ordin de declarație:
///
/// 1. Adăugați dimensiunea câmpului.
/// 2. Rotunjește dimensiunea curentă la cel mai apropiat multiplu al [alignment] al câmpului următor.
///
/// În cele din urmă, rotunjiți dimensiunea structurii la cel mai apropiat multiplu al lui [alignment].
/// Alinierea structului este de obicei cea mai mare aliniere dintre toate câmpurile sale;acest lucru poate fi schimbat cu utilizarea `repr(align(N))`.
///
/// Spre deosebire de `C`, structurile de dimensiuni zero nu sunt rotunjite până la un octet.
///
/// ## Dimensiunea sumelor
///
/// Enumeri care nu conțin alte date decât discriminantul au aceeași dimensiune ca enumeri C pe platforma pentru care sunt compilate.
///
/// ## Dimensiunea sindicatelor
///
/// Dimensiunea unei uniuni este dimensiunea celui mai mare câmp al acesteia.
///
/// Spre deosebire de `C`, uniunile de dimensiuni zero nu sunt rotunjite până la un octet.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Unii primitivi
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Unele matrice
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Egalitatea dimensiunii indicatorului
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Folosind `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Dimensiunea primului câmp este 1, deci adăugați 1 la dimensiune.Dimensiunea este 1.
/// // Alinierea celui de-al doilea câmp este 2, deci adăugați 1 la dimensiunea pentru umplere.Dimensiunea este de 2.
/// // Dimensiunea celui de-al doilea câmp este 2, deci adăugați 2 la dimensiune.Dimensiunea este de 4.
/// // Alinierea celui de-al treilea câmp este 1, deci adăugați 0 la dimensiunea pentru umplere.Dimensiunea este de 4.
/// // Dimensiunea celui de-al treilea câmp este 1, așa că adăugați 1 la dimensiune.Dimensiunea este de 5.
/// // În cele din urmă, alinierea structurii este 2 (deoarece cea mai mare aliniere dintre câmpurile sale este 2), așa că adăugați 1 la dimensiunea pentru umplere.
/// // Dimensiunea este de 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Structurile tuplurilor respectă aceleași reguli.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Rețineți că reordonarea câmpurilor poate reduce dimensiunea.
/// // Putem elimina ambii octeți de umplere punând `third` înainte de `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Dimensiunea uniunii este dimensiunea celui mai mare câmp.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Returnează dimensiunea valorii indicate în octeți.
///
/// Acest lucru este, de obicei, la fel ca `size_of::<T>()`.
/// Cu toate acestea, când `T`*nu are* o dimensiune cunoscută static, de exemplu, o felie [`[T]`][slice] sau un [trait object], atunci `size_of_val` poate fi utilizat pentru a obține dimensiunea cunoscută dinamic.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURANȚĂ: `val` este o referință, deci este un indicator brut valabil
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnează dimensiunea valorii indicate în octeți.
///
/// Acest lucru este, de obicei, la fel ca `size_of::<T>()`.Cu toate acestea, când `T`*nu are* o dimensiune cunoscută static, de exemplu, o felie [`[T]`][slice] sau un [trait object], atunci `size_of_val_raw` poate fi utilizat pentru a obține dimensiunea cunoscută dinamic.
///
/// # Safety
///
/// Această funcție poate fi apelată în siguranță numai dacă sunt îndeplinite următoarele condiții:
///
/// - Dacă `T` este `Sized`, această funcție este întotdeauna sigură de apelat.
/// - Dacă coada nedimensionată a lui `T` este:
///     - un [slice], atunci lungimea cozii feliei trebuie să fie un număr întreg inițializat, iar dimensiunea *întregii valori*(lungimea cozii dinamice + prefixul de dimensiune statică) trebuie să se potrivească în `isize`.
///     - un [trait object], atunci partea vtable a indicatorului trebuie să indice o tabelă vtable validă dobândită printr-o constrângere de dimensiune, iar dimensiunea *întregii valori*(lungimea cozii dinamice + prefixul dimensiunii statice) trebuie să se potrivească în `isize`.
///
///     - un (unstable) [extern type], atunci această funcție este întotdeauna sigură de apelat, dar poate panic sau altfel să returneze valoarea greșită, deoarece aspectul tipului extern nu este cunoscut.
///     Acesta este același comportament ca și [`size_of_val`] la o referință la un tip cu o coadă de tip extern.
///     - în caz contrar, nu este permis conservator să se apeleze această funcție.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURANȚĂ: apelantul trebuie să furnizeze un indicator brut valabil
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnează alinierea minimă necesară [ABI] a unui tip.
///
/// Fiecare referință la o valoare de tipul `T` trebuie să fie un multiplu al acestui număr.
///
/// Aceasta este alinierea utilizată pentru câmpurile struct.Poate fi mai mic decât alinierea preferată.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnează alinierea minimă necesară [ABI] a tipului valorii către care indică `val`.
///
/// Fiecare referință la o valoare de tipul `T` trebuie să fie un multiplu al acestui număr.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURANȚĂ: val este o referință, deci este un indicator brut valabil
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnează alinierea minimă necesară [ABI] a unui tip.
///
/// Fiecare referință la o valoare de tipul `T` trebuie să fie un multiplu al acestui număr.
///
/// Aceasta este alinierea utilizată pentru câmpurile struct.Poate fi mai mic decât alinierea preferată.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnează alinierea minimă necesară [ABI] a tipului valorii către care indică `val`.
///
/// Fiecare referință la o valoare de tipul `T` trebuie să fie un multiplu al acestui număr.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURANȚĂ: val este o referință, deci este un indicator brut valabil
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnează alinierea minimă necesară [ABI] a tipului valorii către care indică `val`.
///
/// Fiecare referință la o valoare de tipul `T` trebuie să fie un multiplu al acestui număr.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Această funcție poate fi apelată în siguranță numai dacă sunt îndeplinite următoarele condiții:
///
/// - Dacă `T` este `Sized`, această funcție este întotdeauna sigură de apelat.
/// - Dacă coada nedimensionată a lui `T` este:
///     - un [slice], atunci lungimea cozii feliei trebuie să fie un număr întreg inițializat, iar dimensiunea *întregii valori*(lungimea cozii dinamice + prefixul de dimensiune statică) trebuie să se potrivească în `isize`.
///     - un [trait object], atunci partea vtable a indicatorului trebuie să indice o tabelă vtable validă dobândită printr-o constrângere de dimensiune, iar dimensiunea *întregii valori*(lungimea cozii dinamice + prefixul dimensiunii statice) trebuie să se potrivească în `isize`.
///
///     - un (unstable) [extern type], atunci această funcție este întotdeauna sigură de apelat, dar poate panic sau altfel să returneze valoarea greșită, deoarece aspectul tipului extern nu este cunoscut.
///     Acesta este același comportament ca și [`align_of_val`] la o referință la un tip cu o coadă de tip extern.
///     - în caz contrar, nu este permis conservator să se apeleze această funcție.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURANȚĂ: apelantul trebuie să furnizeze un indicator brut valabil
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnează `true` dacă valorile de scădere de tip `T` contează.
///
/// Acesta este doar un indiciu de optimizare și poate fi implementat în mod conservator:
/// se poate returna `true` pentru tipurile care nu trebuie efectiv abandonate.
/// Ca atare, întotdeauna returnarea `true` ar fi o implementare validă a acestei funcții.Cu toate acestea, dacă această funcție returnează `false`, atunci puteți fi sigur că renunțarea la `T` nu are niciun efect secundar.
///
/// Implementările la nivel scăzut de lucruri precum colecțiile, care trebuie să renunțe manual la datele lor, ar trebui să utilizeze această funcție pentru a evita încercarea inutilă de a renunța la tot conținutul lor atunci când sunt distruse.
///
/// Acest lucru s-ar putea să nu facă diferența în versiunile de lansare (unde o buclă care nu are efecte secundare este ușor de detectat și eliminat), dar este adesea un mare câștig pentru versiunile de depanare.
///
/// Rețineți că [`drop_in_place`] efectuează deja această verificare, deci dacă volumul de lucru poate fi redus la un număr mic de apeluri [`drop_in_place`], utilizarea acestuia nu este necesară.
/// În special, rețineți că puteți [`drop_in_place`] o felie și că va face o singură verificare needs_drop pentru toate valorile.
///
/// Tipuri precum Vec, prin urmare, doar `drop_in_place(&mut self[..])` fără a utiliza în mod explicit `needs_drop`.
/// Tipuri precum [`HashMap`], pe de altă parte, trebuie să renunțe la valori pe rând și ar trebui să utilizeze acest API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Iată un exemplu despre modul în care o colecție ar putea folosi `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // renunțați la date
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Returnează valoarea tipului `T` reprezentată de modelul de octeți complet zero.
///
/// Aceasta înseamnă că, de exemplu, octetul de umplere în `(u8, u16)` nu este neapărat redus la zero.
///
/// Nu există nicio garanție că un model de octeți complet zero reprezintă o valoare validă de un tip `T`.
/// De exemplu, modelul de octeți complet zero nu este o valoare validă pentru tipurile de referință (`&T`, `&mut T`) și indicatorii de funcții.
/// Utilizarea `zeroed` pe astfel de tipuri provoacă [undefined behavior][ub] imediat deoarece [the Rust compiler assumes][inv] că întotdeauna există o valoare validă într-o variabilă pe care o consideră inițializată.
///
///
/// Acest lucru are același efect ca și [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Uneori este util pentru FFI, dar trebuie evitat în general.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Utilizarea corectă a acestei funcții: inițializarea unui număr întreg cu zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Utilizarea incorectă a acestei funcții: inițializarea unei referințe cu zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Comportament nedefinit!
/// let _y: fn() = unsafe { mem::zeroed() }; // Și din nou!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SIGURANȚĂ: apelantul trebuie să garanteze că o valoare complet zero este validă pentru `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ocolește verificările normale de inițializare a memoriei Rust, pretinzând că produce o valoare de tip `T`, fără a face nimic.
///
/// **Această funcție este învechită.** Folosiți în schimb [`MaybeUninit<T>`].
///
/// Motivul deprecierii este că funcția nu poate fi utilizată corect: are același efect ca [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// După cum explică [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] că valorile sunt inițializate corect.
/// În consecință, apelarea de ex
/// `mem::uninitialized::<bool>()` provoacă un comportament imediat nedefinit pentru returnarea unui `bool` care nu este cu siguranță nici `true`, nici `false`.
/// Memoria mai rea, cu adevărat neinițializată, cum ar fi ceea ce este returnat aici, este specială, deoarece compilatorul știe că nu are o valoare fixă.
/// Acest lucru face ca comportamentul nedefinit să aibă date neinițializate într-o variabilă, chiar dacă acea variabilă are un tip întreg.
/// (Observați că regulile în jurul numerelor întregi neinițializate nu sunt încă finalizate, dar până la finalizarea acestora, este recomandabil să le evitați.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SIGURANȚĂ: apelantul trebuie să garanteze că o valoare unitară este validă pentru `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Schimbă valorile în două locații care pot fi modificate, fără a dezinicializa niciuna.
///
/// * Dacă doriți să faceți swap cu o valoare implicită sau falsă, consultați [`take`].
/// * Dacă doriți să faceți swap cu o valoare trecută, returnând vechea valoare, consultați [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SIGURANȚĂ: indicatoarele brute au fost create din referințe mutabile sigure, satisfăcând toate
    // constrângeri pe `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Înlocuiește `dest` cu valoarea implicită `T`, returnând valoarea `dest` anterioară.
///
/// * Dacă doriți să înlocuiți valorile a două variabile, consultați [`swap`].
/// * Dacă doriți să înlocuiți cu o valoare trecută în loc de valoarea implicită, consultați [`replace`].
///
/// # Examples
///
/// Un exemplu simplu:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permite deținerea unui câmp struct prin înlocuirea acestuia cu o valoare "empty".
/// Fără `take` puteți întâmpina probleme precum acestea:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Rețineți că `T` nu implementează neapărat [`Clone`], deci nici măcar nu poate clona și reseta `self.buf`.
/// Dar `take` poate fi folosit pentru a disocia valoarea inițială a `self.buf` de la `self`, permițând returnarea acestuia:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Mută `src` în `dest` de referință, returnând valoarea `dest` anterioară.
///
/// Nici o valoare nu este scăzută.
///
/// * Dacă doriți să înlocuiți valorile a două variabile, consultați [`swap`].
/// * Dacă doriți să înlocuiți cu o valoare implicită, consultați [`take`].
///
/// # Examples
///
/// Un exemplu simplu:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permite consumul unui câmp struct prin înlocuirea acestuia cu o altă valoare.
/// Fără `replace` puteți întâmpina probleme precum acestea:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Rețineți că `T` nu implementează neapărat [`Clone`], deci nici măcar nu putem clona `self.buf[i]` pentru a evita mutarea.
/// Dar `replace` poate fi folosit pentru a disocia valoarea originală la acel indice de la `self`, permițându-i să fie returnată:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SIGURANȚĂ: Citim din `dest`, dar scriem direct `src` în el ulterior,
    // astfel încât vechea valoare să nu fie duplicată.
    // Nimic nu este abandonat și nimic nu poate panic aici.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispune de o valoare.
///
/// Aceasta face acest lucru apelând la implementarea argumentului [`Drop`][drop].
///
/// Acest lucru nu face efectiv nimic pentru tipurile care implementează `Copy`, de ex
/// integers.
/// Astfel de valori sunt copiate și _then_ mutat în funcție, deci valoarea persistă după acest apel de funcție.
///
///
/// Această funcție nu este magică;este literalmente definit ca
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Deoarece `_x` este mutat în funcție, acesta este abandonat automat înainte ca funcția să revină.
///
/// [drop]: Drop
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // aruncați în mod explicit vector
/// ```
///
/// Deoarece [`RefCell`] aplică regulile de împrumut în timpul rulării, `drop` poate elibera un împrumut [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // renunță la împrumutul mutabil pe acest slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Numerele întregi și alte tipuri care implementează [`Copy`] nu sunt afectate de `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // o copie a `x` este mutată și abandonată
/// drop(y); // o copie a `y` este mutată și abandonată
///
/// println!("x: {}, y: {}", x, y.0); // încă disponibil
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretează `src` ca având tipul `&U` și apoi citește `src` fără a muta valoarea conținută.
///
/// Această funcție va presupune în siguranță că indicatorul `src` este valid pentru octeții [`size_of::<U>`][size_of] prin transmutarea `&T` în `&U` și apoi citirea `&U` (cu excepția faptului că acest lucru se face într-un mod corect, chiar și atunci când `&U` face cerințe de aliniere mai stricte decât `&T`).
/// De asemenea, va crea în siguranță o copie a valorii conținute în loc să se mute din `src`.
///
/// Nu este o eroare în timpul compilării dacă `T` și `U` au dimensiuni diferite, dar este foarte încurajat să invocăm această funcție doar în cazul în care `T` și `U` au aceeași dimensiune.Această funcție declanșează [undefined behavior][ub] dacă `U` este mai mare decât `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copiați datele din 'foo_array' și tratați-le ca pe un 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modificați datele copiate
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Conținutul 'foo_array' nu ar fi trebuit să se schimbe
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Dacă U are o cerință de aliniere mai mare, este posibil ca src să nu fie aliniat corespunzător.
    if align_of::<U>() > align_of::<T>() {
        // SIGURANȚĂ: `src` este o referință care este garantată pentru a fi validă pentru citiri.
        // Apelantul trebuie să garanteze că transmutația efectivă este sigură.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SIGURANȚĂ: `src` este o referință care este garantată pentru a fi validă pentru citiri.
        // Tocmai am verificat dacă `src as *const U` a fost aliniat corect.
        // Apelantul trebuie să garanteze că transmutația efectivă este sigură.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tipul opac care reprezintă discriminantul unei enumeri.
///
/// Consultați funcția [`discriminant`] din acest modul pentru mai multe informații.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Aceste implementări trait nu pot fi derivate pentru că nu vrem limite pentru T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Returnează o valoare care identifică în mod unic varianta enum în `v`.
///
/// Dacă `T` nu este un enum, apelarea acestei funcții nu va avea ca rezultat un comportament nedefinit, dar valoarea returnată este nespecificată.
///
///
/// # Stability
///
/// Discriminantul unei variante enum se poate modifica dacă se modifică definiția enum.
/// Un discriminant al unor variante nu se va schimba între compilații cu același compilator.
///
/// # Examples
///
/// Aceasta poate fi utilizată pentru a compara enumerările care transportă date, ignorând în același timp datele reale:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Returnează numărul de variante din enum tip `T`.
///
/// Dacă `T` nu este un enum, apelarea acestei funcții nu va avea ca rezultat un comportament nedefinit, dar valoarea returnată este nespecificată.
/// În mod similar, dacă `T` este o enumere cu mai multe variante decât `usize::MAX`, valoarea de returnare nu este specificată.
/// Variantele nelocuite vor fi numărate.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}