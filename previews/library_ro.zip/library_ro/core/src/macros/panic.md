Panics firul curent.

Acest lucru permite unui program să se încheie imediat și să ofere feedback apelantului programului.
`panic!` ar trebui să fie utilizat atunci când un program atinge o stare nerecuperabilă.

Această macrocomandă este modalitatea perfectă de afirmare a condițiilor în exemplul de cod și în teste.
`panic!` este strâns legat de metoda `unwrap` a ambelor enumerări [`Option`][ounwrap] și [`Result`][runwrap].
Ambele implementări apelează `panic!` când sunt setate la variantele [`None`] sau [`Err`].

Când utilizați `panic!()` puteți specifica o sarcină utilă șir, care este construită utilizând sintaxa [`format!`].
Această sarcină utilă este utilizată la injectarea panic în firul Rust apelant, determinând firul complet panic.

Comportamentul implicit al `std` hook, adică
codul care rulează direct după ce panic este invocat, este să imprimeți sarcina utilă a mesajului către `stderr` împreună cu informațiile file/line/column ale apelului `panic!()`.

Puteți suprascrie panic hook folosind [`std::panic::set_hook()`].
În interiorul hook, un panic poate fi accesat ca un `&dyn Any + Send`, care conține fie un `&str`, fie `String` pentru invocații obișnuite `panic!()`.
Pentru panic cu o valoare de alt tip, poate fi utilizat [`panic_any`].

[`Result`] enum este adesea o soluție mai bună pentru recuperarea după erori decât utilizarea macro-ului `panic!`.
Această macrocomandă trebuie utilizată pentru a evita continuarea utilizării unor valori incorecte, cum ar fi din surse externe.
Informații detaliate despre gestionarea erorilor se găsesc în [book].

A se vedea, de asemenea, macro [`compile_error!`], pentru ridicarea erorilor în timpul compilării.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementare curentă

Dacă firul principal panics va încheia toate firele și va încheia programul cu codul `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





