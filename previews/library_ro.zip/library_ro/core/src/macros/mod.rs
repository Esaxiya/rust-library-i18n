#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Se extinde la `$crate::panic::panic_2015` sau `$crate::panic::panic_2021` în funcție de ediția apelantului.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Afirmă că două expresii sunt egale una cu cealaltă (folosind [`PartialEq`]).
///
/// Pe panic, această macrocomandă va imprima valorile expresiilor cu reprezentările lor de depanare.
///
///
/// La fel ca [`assert!`], această macrocomandă are o a doua formă, unde poate fi furnizat un mesaj panic personalizat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Resursele de mai jos sunt intenționate.
                    // Fără ele, slotul stivei pentru împrumut este inițializat chiar înainte de compararea valorilor, ceea ce duce la o încetinire vizibilă.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Resursele de mai jos sunt intenționate.
                    // Fără ele, slotul stivei pentru împrumut este inițializat chiar înainte de compararea valorilor, ceea ce duce la o încetinire vizibilă.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirmă că două expresii nu sunt egale între ele (folosind [`PartialEq`]).
///
/// Pe panic, această macrocomandă va imprima valorile expresiilor cu reprezentările lor de depanare.
///
///
/// La fel ca [`assert!`], această macrocomandă are o a doua formă, unde poate fi furnizat un mesaj panic personalizat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Resursele de mai jos sunt intenționate.
                    // Fără ele, slotul stivei pentru împrumut este inițializat chiar înainte de compararea valorilor, ceea ce duce la o încetinire vizibilă.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Resursele de mai jos sunt intenționate.
                    // Fără ele, slotul stivei pentru împrumut este inițializat chiar înainte de compararea valorilor, ceea ce duce la o încetinire vizibilă.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirmă că o expresie booleană este `true` în timpul rulării.
///
/// Aceasta va invoca macrocomanda [`panic!`] dacă expresia furnizată nu poate fi evaluată la `true` în timpul rulării.
///
/// La fel ca [`assert!`], această macro are, de asemenea, o a doua versiune, unde poate fi furnizat un mesaj panic personalizat.
///
/// # Uses
///
/// Spre deosebire de [`assert!`], instrucțiunile `debug_assert!` sunt activate în mod implicit numai în versiunile neoptimizate.
/// O versiune optimizată nu va executa instrucțiuni `debug_assert!` decât dacă `-C debug-assertions` este trecut la compilator.
/// Acest lucru face ca `debug_assert!` să fie util pentru verificările care sunt prea scumpe pentru a fi prezente într-o versiune de versiune, dar pot fi utile în timpul dezvoltării.
/// Rezultatul extinderii `debug_assert!` este întotdeauna verificat de tip.
///
/// O afirmație necontrolată permite unui program aflat într-o stare inconsistentă să ruleze în continuare, ceea ce ar putea avea consecințe neașteptate, dar nu introduce nesiguranță atâta timp cât acest lucru se întâmplă numai în codul sigur.
///
/// Cu toate acestea, costul de performanță al afirmațiilor nu este măsurabil în general.
/// Înlocuirea [`assert!`] cu `debug_assert!` este astfel încurajată numai după o profilare aprofundată și, mai important, numai în cod sigur!
///
/// # Examples
///
/// ```
/// // mesajul panic pentru aceste afirmații este valoarea strânsă a expresiei date.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // o funcție foarte simplă
/// debug_assert!(some_expensive_computation());
///
/// // afirmați cu un mesaj personalizat
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afirmă că două expresii sunt egale una cu cealaltă.
///
/// Pe panic, această macrocomandă va imprima valorile expresiilor cu reprezentările lor de depanare.
///
/// Spre deosebire de [`assert_eq!`], instrucțiunile `debug_assert_eq!` sunt activate în mod implicit numai în versiunile neoptimizate.
/// O versiune optimizată nu va executa instrucțiuni `debug_assert_eq!` decât dacă `-C debug-assertions` este trecut la compilator.
/// Acest lucru face ca `debug_assert_eq!` să fie util pentru verificările care sunt prea scumpe pentru a fi prezente într-o versiune de versiune, dar pot fi utile în timpul dezvoltării.
///
/// Rezultatul extinderii `debug_assert_eq!` este întotdeauna verificat de tip.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afirmă că două expresii nu sunt egale una cu cealaltă.
///
/// Pe panic, această macrocomandă va imprima valorile expresiilor cu reprezentările lor de depanare.
///
/// Spre deosebire de [`assert_ne!`], instrucțiunile `debug_assert_ne!` sunt activate în mod implicit numai în versiunile neoptimizate.
/// O versiune optimizată nu va executa instrucțiuni `debug_assert_ne!` decât dacă `-C debug-assertions` este trecut la compilator.
/// Acest lucru face ca `debug_assert_ne!` să fie util pentru verificările care sunt prea scumpe pentru a fi prezente într-o versiune de versiune, dar pot fi utile în timpul dezvoltării.
///
/// Rezultatul extinderii `debug_assert_ne!` este întotdeauna verificat de tip.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Returnează dacă expresia dată se potrivește cu oricare dintre tiparele date.
///
/// La fel ca într-o expresie `match`, modelul poate fi urmat opțional de `if` și o expresie de gardă care are acces la nume legate de model.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Desface un rezultat sau propagă eroarea acestuia.
///
/// Operatorul `?` a fost adăugat pentru a înlocui `try!` și ar trebui folosit în schimb.
/// În plus, `try` este un cuvânt rezervat în Rust 2018, deci dacă trebuie să-l utilizați, va trebui să utilizați [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` se potrivește cu [`Result`] dat.În cazul variantei `Ok`, expresia are valoarea valorii împachetate.
///
/// În cazul variantei `Err`, recuperează eroarea interioară.`try!` efectuează apoi conversia utilizând `From`.
/// Aceasta oferă conversia automată între erori specializate și erori mai generale.
/// Eroarea rezultată este apoi returnată imediat.
///
/// Datorită returnării timpurii, `try!` poate fi utilizat numai în funcții care returnează [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Metoda preferată de returnare rapidă a erorilor
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Metoda anterioară de returnare rapidă a erorilor
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Acest lucru este echivalent cu:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Scrie date formatate într-un buffer.
///
/// Această macrocomandă acceptă un 'writer', un șir de format și o listă de argumente.
/// Argumentele vor fi formatate conform șirului de format specificat și rezultatul va fi transmis scriitorului.
/// Scriitorul poate avea orice valoare cu o metodă `write_fmt`;în general, aceasta provine dintr-o implementare a [`fmt::Write`] sau a [`io::Write`] trait.
/// Macro returnează orice returnează metoda `write_fmt`;de obicei un [`fmt::Result`] sau un [`io::Result`].
///
/// Consultați [`std::fmt`] pentru mai multe informații despre sintaxa șirului de format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Un modul poate importa atât `std::fmt::Write`, cât și `std::io::Write` și poate apela `write!` pe obiecte care implementează, deoarece obiectele nu implementează de obicei ambele.
///
/// Cu toate acestea, modulul trebuie să importe calificarea traits, astfel încât numele lor să nu intre în conflict:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // folosește fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // folosește io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Această macrocomandă poate fi utilizată și în configurațiile `no_std`.
/// Într-o configurație `no_std` sunteți responsabil pentru detaliile de implementare ale componentelor.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Scrieți datele formatate într-un buffer, cu o nouă linie adăugată.
///
/// Pe toate platformele, noua linie este caracterul LINE FEED (`\n`/`U+000A`) singur (fără CARRIAGE RETURN (`\r`/`U+000D`) suplimentar.
///
/// Pentru mai multe informații, consultați [`write!`].Pentru informații despre sintaxa șirului de format, consultați [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Un modul poate importa atât `std::fmt::Write`, cât și `std::io::Write` și poate apela `write!` pe obiecte care implementează, deoarece obiectele nu implementează de obicei ambele.
/// Cu toate acestea, modulul trebuie să importe calificarea traits, astfel încât numele lor să nu intre în conflict:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // folosește fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // folosește io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indică cod inaccesibil.
///
/// Acest lucru este util oricând compilatorul nu poate determina că un anumit cod nu poate fi accesat.De exemplu:
///
/// * Potriviți brațele cu condițiile de protecție.
/// * Bucle care se termină dinamic.
/// * Iteratori care se termină dinamic.
///
/// Dacă determinarea faptului că codul este inaccesibil se dovedește incorectă, programul se termină imediat cu un [`panic!`].
///
/// Omologul nesigur al acestei macrocomenzi este funcția [`unreachable_unchecked`], care va provoca un comportament nedefinit dacă se ajunge la cod.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Aceasta va fi întotdeauna [`panic!`].
///
/// # Examples
///
/// Combinați brațele:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // eroare de compilare dacă este comentată
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // una dintre cele mai slabe implementări ale x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indică codul neimplementat prin panică cu un mesaj "not implemented".
///
/// Acest lucru permite codului dvs. să verifice tip, ceea ce este util dacă prototipați sau implementați un trait care necesită mai multe metode pe care nu intenționați să le utilizați toate.
///
/// Diferența dintre `unimplemented!` și [`todo!`] este că, în timp ce `todo!` transmite intenția de a implementa funcționalitatea ulterior și mesajul este "not yet implemented", `unimplemented!` nu face astfel de afirmații.
/// Mesajul său este "not implemented".
/// De asemenea, unele IDE vor marca " todo!` S.
///
/// # Panics
///
/// Aceasta va fi întotdeauna [`panic!`] deoarece `unimplemented!` este doar o prescurtare pentru `panic!` cu un mesaj fix, specific.
///
/// La fel ca `panic!`, această macrocomandă are un al doilea formular pentru afișarea valorilor personalizate.
///
/// # Examples
///
/// Să presupunem că avem un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Vrem să implementăm `Foo` pentru 'MyStruct', dar din anumite motive nu are sens să implementăm funcția `bar()`.
/// `baz()` și `qux()` va trebui în continuare să fie definit în implementarea noastră a `Foo`, dar putem folosi `unimplemented!` în definițiile lor pentru a permite compilarea codului nostru.
///
/// Încă vrem ca programul nostru să nu mai ruleze dacă sunt atinse metodele neimplementate.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Nu are sens pentru `baz` un `MyStruct`, deci nu avem deloc logică aici.
/////
///         // Aceasta va afișa "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Avem o logică aici, putem adăuga un mesaj la neimplementat!pentru a ne arăta omisiunea.
///         // Aceasta va afișa: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indică cod neterminat.
///
/// Acest lucru poate fi util dacă prototipați și căutați doar să verificați tipul de cod.
///
/// Diferența dintre [`unimplemented!`] și `todo!` este că, în timp ce `todo!` transmite intenția de a implementa funcționalitatea ulterior și mesajul este "not yet implemented", `unimplemented!` nu face astfel de afirmații.
/// Mesajul său este "not implemented".
/// De asemenea, unele IDE vor marca " todo!` S.
///
/// # Panics
///
/// Aceasta va fi întotdeauna [`panic!`].
///
/// # Examples
///
/// Iată un exemplu de cod în curs.Avem un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Vrem să implementăm `Foo` pe unul dintre tipurile noastre, dar vrem să lucrăm mai întâi doar pe `bar()`.Pentru ca codul nostru să fie compilat, trebuie să implementăm `baz()`, astfel încât să putem folosi `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementarea merge aici
///     }
///
///     fn baz(&self) {
///         // să nu ne facem griji cu privire la implementarea baz() pentru moment
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nici măcar nu folosim baz(), deci este bine.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definiții de macrocomenzi încorporate.
///
/// Majoritatea proprietăților macro (stabilitate, vizibilitate etc.) sunt preluate din codul sursă aici, cu excepția funcțiilor de expansiune care transformă intrările macro în ieșiri, acele funcții fiind furnizate de compilator.
///
///
pub(crate) mod builtin {

    /// Face ca compilarea să eșueze cu mesajul de eroare dat atunci când este întâlnit.
    ///
    /// Această macrocomandă trebuie utilizată atunci când un crate folosește o strategie de compilare condiționată pentru a furniza mesaje de eroare mai bune pentru condiții eronate.
    ///
    /// Este forma la nivel de compilator a [`panic!`], dar emite o eroare în timpul *compilării* mai degrabă decât în timpul *runtime*.
    ///
    /// # Examples
    ///
    /// Două astfel de exemple sunt macro-urile și mediile `#[cfg]`.
    ///
    /// Emiteți o eroare mai bună a compilatorului dacă unei macro i se transmit valori nevalide.
    /// Fără branch final, compilatorul ar emite în continuare o eroare, dar mesajul erorii nu ar menționa cele două valori valide.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emiteți o eroare a compilatorului dacă una dintre o serie de funcții nu este disponibilă.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Construiește parametri pentru celelalte macro-uri de formatare a șirurilor.
    ///
    /// Această macro funcționează luând un șir de formatare literal care conține `{}` pentru fiecare argument suplimentar trecut.
    /// `format_args!` pregătește parametrii suplimentari pentru a se asigura că ieșirea poate fi interpretată ca un șir și canonizează argumentele într-un singur tip.
    /// Orice valoare care implementează [`Display`] trait poate fi transmisă către `format_args!`, la fel ca orice implementare [`Debug`] poate fi transmisă către un `{:?}` în cadrul șirului de formatare.
    ///
    ///
    /// Această macrocomandă produce o valoare de tip [`fmt::Arguments`].Această valoare poate fi transmisă macrocomenzilor din [`std::fmt`] pentru efectuarea redirecționării utile.
    /// Toate celelalte macrocomenzi de formatare ([`format!`], [`write!`], [`println!`] etc.) sunt transmise prin proxy prin aceasta.
    /// `format_args!`, spre deosebire de macro-urile derivate, evită alocările de heap.
    ///
    /// Puteți utiliza valoarea [`fmt::Arguments`] pe care o returnează `format_args!` în contextele `Debug` și `Display` așa cum se vede mai jos.
    /// Exemplul arată, de asemenea, că formatul `Debug` și `Display` are același lucru: șirul formatului interpolat în `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Pentru mai multe informații, consultați documentația din [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// La fel ca `format_args`, dar adaugă o linie nouă în cele din urmă.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspectează o variabilă de mediu la momentul compilării.
    ///
    /// Această macrocomandă se va extinde la valoarea variabilei de mediu numite la momentul compilării, obținând o expresie de tip `&'static str`.
    ///
    ///
    /// Dacă variabila de mediu nu este definită, atunci va fi emisă o eroare de compilare.
    /// Pentru a nu emite o eroare de compilare, utilizați macrocomanda [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Puteți personaliza mesajul de eroare trecând un șir ca al doilea parametru:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Dacă variabila de mediu `documentation` nu este definită, veți primi următoarea eroare:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opțional, inspectează o variabilă de mediu la momentul compilării.
    ///
    /// Dacă variabila de mediu numită este prezentă la momentul compilării, aceasta se va extinde într-o expresie de tip `Option<&'static str>` a cărei valoare este `Some` din valoarea variabilei de mediu.
    /// Dacă variabila de mediu nu este prezentă, aceasta se va extinde la `None`.
    /// Consultați [`Option<T>`][Option] pentru mai multe informații despre acest tip.
    ///
    /// O eroare de timp de compilare nu este emisă niciodată atunci când se utilizează această macro, indiferent dacă variabila de mediu este prezentă sau nu.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenează identificatorii într-un singur identificator.
    ///
    /// Această macrocomandă ia orice număr de identificatori separați prin virgule și îi concatenează pe toți într-unul singur, producând o expresie care este un nou identificator.
    /// Rețineți că igiena face ca această macrocomandă să nu capteze variabile locale.
    /// De asemenea, ca regulă generală, macro-urile sunt permise numai în poziția articolului, a instrucțiunii sau a expresiei.
    /// Asta înseamnă că, deși puteți utiliza această macrocomandă pentru a face referire la variabilele, funcțiile sau modulele existente etc., nu puteți defini una nouă cu ea.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//nu poate fi folosit în acest fel!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenează literele într-o felie de șir static.
    ///
    /// Această macrocomandă ia orice număr de litere separate prin virgulă, producând o expresie de tip `&'static str` care reprezintă toate literele concatenate de la stânga la dreapta.
    ///
    ///
    /// Literele întregi și în virgulă mobilă sunt strânse pentru a fi concatenate.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Se extinde la numărul de linie pe care a fost invocat.
    ///
    /// Cu [`column!`] și [`file!`], aceste macro-uri oferă informații de depanare pentru dezvoltatori despre locația din sursă.
    ///
    /// Expresia extinsă are tipul `u32` și este bazată pe 1, astfel încât prima linie din fiecare fișier se evaluează la 1, a doua la 2 etc.
    /// Acest lucru este în concordanță cu mesajele de eroare ale compilatoarelor obișnuite sau ale editorilor populari.
    /// Linia returnată este *nu neapărat* linia invocării `line!` în sine, ci mai degrabă prima invocare macro care conduce la invocarea macro-ului `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Se extinde la numărul coloanei la care a fost invocat.
    ///
    /// Cu [`line!`] și [`file!`], aceste macro-uri oferă informații de depanare pentru dezvoltatori despre locația din sursă.
    ///
    /// Expresia extinsă are tipul `u32` și este bazată pe 1, astfel încât prima coloană din fiecare linie se evaluează la 1, a doua la 2 etc.
    /// Acest lucru este în concordanță cu mesajele de eroare ale compilatoarelor obișnuite sau ale editorilor populari.
    /// Coloana returnată este *nu neapărat* linia invocării `column!` în sine, ci mai degrabă prima invocare macro care conduce la invocarea macro-ului `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Se extinde la numele fișierului în care a fost invocat.
    ///
    /// Cu [`line!`] și [`column!`], aceste macro-uri oferă informații de depanare pentru dezvoltatori despre locația din sursă.
    ///
    /// Expresia extinsă are tipul `&'static str`, iar fișierul returnat nu este invocarea macro-ului `file!` în sine, ci mai degrabă prima invocare macro care conduce la invocarea macro-ului `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifică argumentele sale.
    ///
    /// Această macrocomandă va produce o expresie de tipul `&'static str`, care este stringificarea tuturor tokens transmisă macrocomandei.
    /// Nu sunt plasate restricții asupra sintaxei invocației macro în sine.
    ///
    /// Rețineți că rezultatele extinse ale intrării tokens se pot modifica în future.Ar trebui să aveți grijă dacă vă bazați pe rezultat.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Include un fișier codat UTF-8 ca șir.
    ///
    /// Fișierul este situat în raport cu fișierul curent (în mod similar cu modul în care sunt găsite modulele).
    /// Calea furnizată este interpretată într-un mod specific platformei în timpul compilării.
    /// Deci, de exemplu, o invocație cu o cale Windows care conține bare oblice `\` nu se va compila corect pe Unix.
    ///
    ///
    /// Această macrocomandă va produce o expresie de tip `&'static str`, care este conținutul fișierului.
    ///
    /// # Examples
    ///
    /// Să presupunem că există două fișiere în același director cu următorul conținut:
    ///
    /// Fișier 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fișier 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compilarea 'main.rs' și rularea binarului rezultat va imprima "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Include un fișier ca referință la o matrice de octeți.
    ///
    /// Fișierul este situat în raport cu fișierul curent (în mod similar cu modul în care sunt găsite modulele).
    /// Calea furnizată este interpretată într-un mod specific platformei în timpul compilării.
    /// Deci, de exemplu, o invocație cu o cale Windows care conține bare oblice `\` nu se va compila corect pe Unix.
    ///
    ///
    /// Această macrocomandă va produce o expresie de tip `&'static [u8; N]`, care este conținutul fișierului.
    ///
    /// # Examples
    ///
    /// Să presupunem că există două fișiere în același director cu următorul conținut:
    ///
    /// Fișier 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fișier 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compilarea 'main.rs' și rularea binarului rezultat va imprima "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Se extinde la un șir care reprezintă calea modulului curent.
    ///
    /// Calea actuală a modulului poate fi considerată ierarhia modulelor care duc înapoi la crate root.
    /// Prima componentă a căii returnate este numele crate în curs de compilare.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evaluează combinațiile booleene de semnalizatoare de configurare în timpul compilării.
    ///
    /// În plus față de atributul `#[cfg]`, această macrocomandă este furnizată pentru a permite evaluarea expresiei booleene a steagurilor de configurare.
    /// Acest lucru duce frecvent la un cod mai puțin duplicat.
    ///
    /// Sintaxa dată acestei macrocomenzi este aceeași sintaxă cu atributul [`cfg`].
    ///
    /// `cfg!`, spre deosebire de `#[cfg]`, nu elimină niciun cod și se evaluează doar la adevărat sau fals.
    /// De exemplu, toate blocurile dintr-o expresie if/else trebuie să fie valide atunci când `cfg!` este utilizat pentru condiție, indiferent de ceea ce evaluează `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analizează un fișier ca o expresie sau un element în funcție de context.
    ///
    /// Fișierul este situat în raport cu fișierul curent (în mod similar cu modul în care sunt găsite modulele).Calea furnizată este interpretată într-un mod specific platformei în timpul compilării.
    /// Deci, de exemplu, o invocație cu o cale Windows care conține bare oblice `\` nu se va compila corect pe Unix.
    ///
    /// Utilizarea acestei macrocomenzi este adesea o idee proastă, deoarece dacă fișierul este analizat ca o expresie, va fi plasat în codul din jur neigienic.
    /// Acest lucru ar putea duce la variabile sau funcții diferite de ceea ce se aștepta fișierul dacă există variabile sau funcții care au același nume în fișierul curent.
    ///
    ///
    /// # Examples
    ///
    /// Să presupunem că există două fișiere în același director cu următorul conținut:
    ///
    /// Fișier 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fișier 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compilarea 'main.rs' și rularea binarului rezultat va imprima "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Afirmă că o expresie booleană este `true` în timpul rulării.
    ///
    /// Aceasta va invoca macrocomanda [`panic!`] dacă expresia furnizată nu poate fi evaluată la `true` în timpul rulării.
    ///
    /// # Uses
    ///
    /// Afirmațiile sunt întotdeauna verificate atât în versiunile de depanare, cât și în versiunile și nu pot fi dezactivate.
    /// Consultați [`debug_assert!`] pentru afirmații care nu sunt activate în versiunile implicite de versiuni.
    ///
    /// Codul nesigur se poate baza pe `assert!` pentru a impune invarianții în timp de execuție care, dacă ar fi încălcați, ar putea duce la nesiguranță.
    ///
    /// Alte cazuri de utilizare a `assert!` includ testarea și aplicarea invarianților în timpul rulării în cod sigur (a căror încălcare nu poate duce la nesiguranță).
    ///
    ///
    /// # Mesaje personalizate
    ///
    /// Această macrocomandă are o a doua formă, în care un mesaj panic personalizat poate fi furnizat cu sau fără argumente pentru formatare.
    /// Consultați [`std::fmt`] pentru sintaxă pentru acest formular.
    /// Expresiile utilizate ca argumente de format vor fi evaluate numai dacă afirmația eșuează.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // mesajul panic pentru aceste afirmații este valoarea strânsă a expresiei date.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // o funcție foarte simplă
    ///
    /// assert!(some_computation());
    ///
    /// // afirmați cu un mesaj personalizat
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Asamblare în linie.
    ///
    /// Citiți [unstable book] pentru utilizare.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Asamblare în linie în stil LLVM.
    ///
    /// Citiți [unstable book] pentru utilizare.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Asamblare în linie la nivel de modul.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Imprimările au trecut tokens în ieșirea standard.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Activează sau dezactivează funcționalitatea de urmărire utilizată pentru depanarea altor macrocomenzi.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macrocomandă de atribut utilizată pentru aplicarea macrocomenzilor derivate.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Atribut macro aplicat unei funcții pentru ao transforma într-un test de unitate.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Atribut macro aplicat unei funcții pentru ao transforma într-un test de referință.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Un detaliu de implementare a macro-urilor `#[test]` și `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atribut macro aplicat unui static pentru al înregistra ca alocator global.
    ///
    /// Vezi și [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Păstrează elementul căruia i se aplică dacă calea transmisă este accesibilă și îl elimină altfel.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Extinde toate atributele `#[cfg]` și `#[cfg_attr]` din fragmentul de cod căruia i se aplică.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Detalii despre implementarea instabilă a compilatorului `rustc`, nu utilizați.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Detalii despre implementarea instabilă a compilatorului `rustc`, nu utilizați.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}