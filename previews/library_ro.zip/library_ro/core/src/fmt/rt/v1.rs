//! Acesta este un modul intern utilizat de ifmt!timpul de rulare.Aceste structuri sunt emise în matrici statice pentru a precompila șiruri de format înainte de timp.
//!
//! Aceste definiții sunt similare cu echivalentele lor `ct`, dar diferă prin faptul că acestea pot fi alocate static și sunt ușor optimizate pentru runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Posibile alinieri care pot fi solicitate ca parte a unei directive de formatare.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicație că conținutul trebuie aliniat la stânga.
    Left,
    /// Indicație că conținutul trebuie aliniat la dreapta.
    Right,
    /// Indicația că conținutul ar trebui să fie aliniat în centru.
    Center,
    /// Nu a fost solicitată nicio aliniere.
    Unknown,
}

/// Folosit de specificatorii [width](https://doc.rust-lang.org/std/fmt/#width) și [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Specificat cu un număr literal, stochează valoarea
    Is(usize),
    /// Specificat utilizând sintaxele `$` și `*`, stochează indexul în `args`
    Param(usize),
    /// Nu este specificat
    Implied,
}