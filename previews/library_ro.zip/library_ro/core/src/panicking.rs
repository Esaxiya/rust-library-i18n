//! Suport Panic pentru libcore
//!
//! Biblioteca de bază nu poate defini panica, dar *declară* panica.
//! Aceasta înseamnă că funcțiile din interiorul libcore sunt permise pentru panic, dar pentru a fi util, un crate din amonte trebuie să definească panica pentru ca libcore să o poată utiliza.
//! Interfața actuală pentru panică este:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Această definiție permite panicarea cu orice mesaj general, dar nu permite eșecul cu o valoare `Box<Any>`.
//! (`PanicInfo` conține doar un `&(dyn Any + Send)`, pentru care completăm o valoare fictivă în `PanicInfo: : internal_constructor`.) Motivul pentru aceasta este că libcore nu are voie să aloce.
//!
//!
//! Acest modul conține câteva alte funcții de panicare, dar acestea sunt doar elementele de limbaj necesare pentru compilator.Toate panics sunt canalizate prin această funcție.
//! Simbolul real este declarat prin atributul `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Implementarea de bază a macrocomenzii `panic!` a libcore atunci când nu este utilizată nicio formatare.
#[cold]
// niciodată în linie, cu excepția cazului în care panic_immediate_abort pentru a evita umflarea codului pe site-urile de apel cât mai mult posibil
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // nevoie de codegen pentru panic la overflow și alți terminatori `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Utilizați Arguments::new_v1 în loc de format_args! (" {}`, Expr) pentru a reduce potențialul de dimensiuni.
    // Format_args!macro folosește Display trait de la str pentru a scrie expr, care apelează Formatter::pad, care trebuie să găzduiască trunchierea șirului și căptușeala (chiar dacă aici nu se folosește niciuna).
    //
    // Utilizarea Arguments::new_v1 poate permite compilatorului să omită Formatter::pad din binarul de ieșire, economisind până la câțiva kiloocteți.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // necesar pentru panics evaluat constant
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nevoie de codegen pentru panic pe acces OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Implementarea de bază a macrocomenzii `panic!` a libcore atunci când este utilizată formatarea.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTĂ Această funcție nu traversează niciodată limita FFI;este un apel Rust-to-Rust care se rezolvă la funcția `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SIGURANȚĂ: `panic_impl` este definit în codul Rust sigur și, prin urmare, este sigur să apelați.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Funcție internă pentru macro-urile `assert_eq!` și `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}