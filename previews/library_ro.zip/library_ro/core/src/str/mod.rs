//! Manipularea șirurilor.
//!
//! Pentru mai multe detalii, consultați modulul [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. în afara limitelor
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. începe <=sfârșit
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. limita caracterului
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // găsește personajul
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` trebuie să fie mai mică decât len și o limită char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Returnează lungimea `self`.
    ///
    /// Această lungime este în octeți, nu [`char`] sau grafeme.
    /// Cu alte cuvinte, este posibil să nu fie ceea ce un om consideră lungimea șirului.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fantezie f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Returnează `true` dacă `self` are o lungime de zero octeți.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Verifică dacă `index`-th octet este primul octet într-o secvență de puncte de cod UTF-8 sau sfârșitul șirului.
    ///
    ///
    /// Începutul și sfârșitul șirului (când `index== self.len()`) sunt considerate limite.
    ///
    /// Returnează `false` dacă `index` este mai mare decât `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // începutul `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // al doilea octet al `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // al treilea octet al `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 și len sunt întotdeauna ok.
        // Testați în mod explicit pentru 0, astfel încât să poată optimiza cu ușurință verificarea și sări peste citirea șirurilor de date pentru acest caz.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Aceasta este magie de biți echivalentă cu: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Convertește o felie de șir într-o felie de octeți.
    /// Pentru a converti felia de octeți înapoi într-o felie de șir, utilizați funcția [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SIGURANȚĂ: sunet constant deoarece transmutăm două tipuri cu același aspect
        unsafe { mem::transmute(self) }
    }

    /// Convertește o felie de șir mutabil într-o felie de octeți mutabilă.
    ///
    /// # Safety
    ///
    /// Apelantul trebuie să se asigure că conținutul feliei este valabil UTF-8 înainte ca împrumutul să se termine și să fie utilizat `str` subiacent.
    ///
    ///
    /// Utilizarea unui `str` al cărui conținut nu este valid UTF-8 este un comportament nedefinit.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SIGURANȚĂ: distribuția de la `&str` la `&[u8]` este sigură de la `str`
        // are același aspect ca și `&[u8]` (numai libstd poate face această garanție).
        // Dereferențierea indicatorului este sigură, deoarece provine dintr-o referință mutabilă care este garantată pentru a fi validă pentru scrieri.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Convertește o felie de șir într-un pointer brut.
    ///
    /// Deoarece feliile de șir sunt o felie de octeți, indicatorul brut indică un [`u8`].
    /// Acest indicator va indica către primul octet al feliei de șir.
    ///
    /// Apelantul trebuie să se asigure că indicatorul returnat nu este scris niciodată.
    /// Dacă trebuie să mutați conținutul feliei de șiruri, utilizați [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Convertește o felie de șir modificabilă într-un pointer brut.
    ///
    /// Deoarece feliile de șir sunt o felie de octeți, indicatorul brut indică un [`u8`].
    /// Acest indicator va indica către primul octet al feliei de șir.
    ///
    /// Este responsabilitatea dvs. să vă asigurați că felia de șir se modifică doar într-un mod în care să rămână valabil UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Returnează un subslice de `str`.
    ///
    /// Aceasta este alternativa fără panică la indexarea `str`.
    /// Returnează [`None`] ori de câte ori operațiunea de indexare echivalentă ar fi panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indicii nu pe limitele secvenței UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // în afara limitelor
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Returnează un subslice mutabil de `str`.
    ///
    /// Aceasta este alternativa fără panică la indexarea `str`.
    /// Returnează [`None`] ori de câte ori operațiunea de indexare echivalentă ar fi panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // lungimea corectă
    /// assert!(v.get_mut(0..5).is_some());
    /// // în afara limitelor
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Returnează un subslice necontrolat de `str`.
    ///
    /// Aceasta este alternativa necontrolată la indexarea `str`.
    ///
    /// # Safety
    ///
    /// Apelanții acestei funcții sunt responsabili pentru îndeplinirea acestor condiții prealabile:
    ///
    /// * Indicele inițial nu trebuie să depășească indicele final;
    /// * Indexurile trebuie să se afle în limitele feliei originale;
    /// * Indicii trebuie să se afle pe limitele secvenței UTF-8.
    ///
    /// În caz contrar, felia de șir returnată poate face referire la memoria nevalidă sau poate încălca invarianții comunicați de tipul `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked`;
        // felia este dereferențabilă deoarece `self` este o referință sigură.
        // Pointerul returnat este sigur, deoarece instrumentele `SliceIndex` trebuie să garanteze că este.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Returnează un subslice mutabil, necontrolat de `str`.
    ///
    /// Aceasta este alternativa necontrolată la indexarea `str`.
    ///
    /// # Safety
    ///
    /// Apelanții acestei funcții sunt responsabili pentru îndeplinirea acestor condiții prealabile:
    ///
    /// * Indicele inițial nu trebuie să depășească indicele final;
    /// * Indexurile trebuie să se afle în limitele feliei originale;
    /// * Indicii trebuie să se afle pe limitele secvenței UTF-8.
    ///
    /// În caz contrar, felia de șir returnată poate face referire la memoria nevalidă sau poate încălca invarianții comunicați de tipul `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked_mut`;
        // felia este dereferențabilă deoarece `self` este o referință sigură.
        // Pointerul returnat este sigur, deoarece instrumentele `SliceIndex` trebuie să garanteze că este.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Creează o felie de șir dintr-o altă felie de șir, ocolind verificările de siguranță.
    ///
    /// Acest lucru nu este în general recomandat, utilizați cu precauție!Pentru o alternativă sigură, consultați [`str`] și [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Această nouă porțiune merge de la `begin` la `end`, inclusiv `begin`, dar cu excepția `end`.
    ///
    /// Pentru a obține în schimb o felie de șir modificabilă, consultați metoda [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Apelanții acestei funcții sunt responsabili pentru îndeplinirea a trei condiții prealabile:
    ///
    /// * `begin` nu trebuie să depășească `end`.
    /// * `begin` și `end` trebuie să fie poziții de octeți în felia de șir.
    /// * `begin` și `end` trebuie să se afle pe limitele secvenței UTF-8.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked`;
        // felia este dereferențabilă deoarece `self` este o referință sigură.
        // Pointerul returnat este sigur, deoarece instrumentele `SliceIndex` trebuie să garanteze că este.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Creează o felie de șir dintr-o altă felie de șir, ocolind verificările de siguranță.
    /// Acest lucru nu este în general recomandat, utilizați cu precauție!Pentru o alternativă sigură, consultați [`str`] și [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Această nouă porțiune merge de la `begin` la `end`, inclusiv `begin`, dar cu excepția `end`.
    ///
    /// Pentru a obține o felie de șir imuabil în schimb, consultați metoda [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Apelanții acestei funcții sunt responsabili pentru îndeplinirea a trei condiții prealabile:
    ///
    /// * `begin` nu trebuie să depășească `end`.
    /// * `begin` și `end` trebuie să fie poziții de octeți în felia de șir.
    /// * `begin` și `end` trebuie să se afle pe limitele secvenței UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked_mut`;
        // felia este dereferențabilă deoarece `self` este o referință sigură.
        // Pointerul returnat este sigur, deoarece instrumentele `SliceIndex` trebuie să garanteze că este.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Împărțiți o felie de șir în două la un index.
    ///
    /// Argumentul, `mid`, ar trebui să fie un decalaj de octeți de la începutul șirului.
    /// De asemenea, trebuie să se afle la limita unui punct de cod UTF-8.
    ///
    /// Cele două felii returnate merg de la începutul feliei de șir la `mid` și de la `mid` până la sfârșitul feliei de șir.
    ///
    /// Pentru a obține în schimb felii de șir modificabile, consultați metoda [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics dacă `mid` nu se află la limita unui punct de cod UTF-8 sau dacă depășește sfârșitul ultimului punct de cod al feliei de șir.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary verifică dacă indexul este în [0, .len()]
        if self.is_char_boundary(mid) {
            // SIGURANȚĂ: tocmai am verificat dacă `mid` se află la o limită de caracter.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Împărțiți o felie de șir mutabil în două la un index.
    ///
    /// Argumentul, `mid`, ar trebui să fie un decalaj de octeți de la începutul șirului.
    /// De asemenea, trebuie să se afle la limita unui punct de cod UTF-8.
    ///
    /// Cele două felii returnate merg de la începutul feliei de șir la `mid` și de la `mid` până la sfârșitul feliei de șir.
    ///
    /// Pentru a obține în schimb felii de șir imuabile, consultați metoda [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics dacă `mid` nu se află la limita unui punct de cod UTF-8 sau dacă depășește sfârșitul ultimului punct de cod al feliei de șir.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary verifică dacă indexul este în [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SIGURANȚĂ: tocmai am verificat dacă `mid` se află la o limită de caracter.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Returnează un iterator peste [`char`] s a unei felii de șir.
    ///
    /// Deoarece o felie de șir constă din UTF-8 valid, putem itera printr-o felie de șir cu [`char`].
    /// Această metodă returnează un astfel de iterator.
    ///
    /// Este important să ne amintim că [`char`] reprezintă o valoare Scalar Unicode și este posibil să nu se potrivească cu ideea dvs. despre ce este un 'character'.
    ///
    /// Iterația asupra clusterelor de grafeme poate fi ceea ce doriți de fapt.
    /// Această funcționalitate nu este furnizată de biblioteca standard a Rust, verificați în schimb crates.io.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Amintiți-vă, este posibil ca [`char`] să nu se potrivească cu intuiția dvs. despre personaje:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // nu 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Returnează un iterator peste [`char`] s ale unei felii de șir și pozițiile lor.
    ///
    /// Deoarece o felie de șir constă din UTF-8 valid, putem itera printr-o felie de șir cu [`char`].
    /// Această metodă returnează un iterator atât al acestor [`char`], cât și al pozițiilor lor de octeți.
    ///
    /// Iteratorul produce tupluri.Poziția este prima, [`char`] este a doua.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Amintiți-vă, este posibil ca [`char`] să nu se potrivească cu intuiția dvs. despre personaje:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // nu (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // notează 3 aici, ultimul personaj a ocupat doi octeți
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Un iterator peste octeții unei felii de șir.
    ///
    /// Deoarece o felie de șir constă dintr-o secvență de octeți, putem itera printr-o felie de șir cu octeți.
    /// Această metodă returnează un astfel de iterator.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Împarte o felie de șir de spații albe.
    ///
    /// Iteratorul returnat va returna felii de șir care sunt sub-felii ale feliei de șir originale, separate de orice cantitate de spațiu alb.
    ///
    ///
    /// 'Whitespace' este definit în conformitate cu termenii proprietății de bază derivate Unicode `White_Space`.
    /// Dacă doriți doar să vă împărțiți pe spațiul alb ASCII, utilizați [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Sunt considerate toate tipurile de spații albe:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Împarte o felie de șir de spațiu alb ASCII.
    ///
    /// Iteratorul returnat va returna felii de șir care sunt sub-felii ale feliei de șir originale, separate de orice cantitate de spațiu alb ASCII.
    ///
    ///
    /// Pentru a împărți în schimb cu Unicode `Whitespace`, utilizați [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Sunt considerate toate tipurile de spații albe ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Un iterator peste liniile unui șir, ca felii de șir.
    ///
    /// Liniile se încheie fie cu o linie nouă (`\n`), fie cu o întoarcere de trăsură cu o linie de alimentare (`\r\n`).
    ///
    /// Finalul liniei finale este opțional.
    /// Un șir care se termină cu un sfârșit de linie finală va reveni la aceleași linii ca un șir altfel identic, fără un final de linie final.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Finalul final al liniei nu este obligatoriu:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Un iterator peste liniile unui șir.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Returnează un iterator `u16` peste șirul codat ca UTF-16.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Returnează `true` dacă modelul dat se potrivește cu o sub-felie a acestei felii de șir.
    ///
    /// Returnează `false` dacă nu.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Returnează `true` dacă modelul dat se potrivește cu un prefix al acestui fel de șir.
    ///
    /// Returnează `false` dacă nu.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Returnează `true` dacă modelul dat se potrivește cu un sufix al acestui fel de șir.
    ///
    /// Returnează `false` dacă nu.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Returnează indexul de octeți al primului caracter al acestei felii de șir care se potrivește cu modelul.
    ///
    /// Returnează [`None`] dacă modelul nu se potrivește.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Modele mai complexe care utilizează stil și puncte de închidere fără puncte:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Nu găsesc modelul:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Returnează indexul de octeți pentru primul caracter al potrivirii din dreapta a modelului din această porțiune de șir.
    ///
    /// Returnează [`None`] dacă modelul nu se potrivește.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Modele mai complexe cu închideri:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Nu găsesc modelul:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Un iterator peste șiruri de caractere ale acestui fel de șir, separat de caractere potrivite cu un model.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat va fi un [`DoubleEndedIterator`] dacă modelul permite o căutare inversă și căutarea forward/reverse produce aceleași elemente.
    /// Acest lucru este valabil pentru, de exemplu, [`char`], dar nu și pentru `&str`.
    ///
    /// Dacă modelul permite o căutare inversă, dar rezultatele sale pot diferi de o căutare directă, poate fi utilizată metoda [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Dacă modelul este o felie de caractere, împărțiți la fiecare apariție a oricăruia dintre caractere:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Un model mai complex, folosind o închidere:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Dacă un șir conține mai multe separatoare adiacente, veți termina cu șiruri goale în ieșire:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Separatorii adiacenți sunt separați de șirul gol.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separatoarele de la începutul sau sfârșitul unui șir sunt învecinate de șiruri goale.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Când șirul gol este utilizat ca separator, acesta separă fiecare caracter din șir, împreună cu începutul și sfârșitul șirului.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Separatorii adiacenți pot duce la un comportament posibil surprinzător atunci când spațiul alb este utilizat ca separator.Acest cod este corect:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ vă oferă:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Folosiți [`split_whitespace`] pentru acest comportament.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Un iterator peste șiruri de caractere ale acestui fel de șir, separat de caractere potrivite cu un model.
    /// Diferă de iteratorul produs de `split` prin faptul că `split_inclusive` lasă partea potrivită ca terminator al șirului de caractere.
    ///
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Dacă ultimul element al șirului se potrivește, acel element va fi considerat terminatorul șirului precedent.
    /// Acel șir va fi ultimul element returnat de iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Un iterator peste șiruri de caractere ale șirului dat, separat de caractere asortate de un model și redate în ordine inversă.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat necesită ca modelul să accepte o căutare inversă și va fi un [`DoubleEndedIterator`] dacă o căutare forward/reverse produce aceleași elemente.
    ///
    ///
    /// Pentru iterația din față, poate fi utilizată metoda [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Un model mai complex, folosind o închidere:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Un iterator peste șiruri de caractere ale secțiunii de șir date, separate prin caractere potrivite de un model.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Echivalent cu [`split`], cu excepția faptului că șirul final este omis dacă este gol.
    ///
    /// [`split`]: str::split
    ///
    /// Această metodă poate fi utilizată pentru date șir care este _terminated_, mai degrabă decât _separated_ printr-un model.
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat va fi un [`DoubleEndedIterator`] dacă modelul permite o căutare inversă și căutarea forward/reverse produce aceleași elemente.
    /// Acest lucru este valabil pentru, de exemplu, [`char`], dar nu și pentru `&str`.
    ///
    /// Dacă modelul permite o căutare inversă, dar rezultatele sale pot diferi de o căutare directă, poate fi utilizată metoda [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Un iterator peste șiruri de caractere `self`, separat de caractere asortate de un model și cedat în ordine inversă.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Echivalent cu [`split`], cu excepția faptului că șirul final este omis dacă este gol.
    ///
    /// [`split`]: str::split
    ///
    /// Această metodă poate fi utilizată pentru date șir care este _terminated_, mai degrabă decât _separated_ printr-un model.
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat necesită ca modelul să accepte o căutare inversă și va avea un sfârșit dublu dacă o căutare forward/reverse produce aceleași elemente.
    ///
    ///
    /// Pentru iterația din față, poate fi utilizată metoda [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Un iterator peste șiruri de caractere ale șirului de caractere, separat printr-un model, limitat la returnarea a cel mult `n` articole.
    ///
    /// Dacă se restituie șirurile `n`, ultimul șir (șirul `n`th) va conține restul șirului.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat nu va avea un sfârșit dublu, deoarece nu este eficient de suportat.
    ///
    /// Dacă modelul permite o căutare inversă, poate fi utilizată metoda [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Un model mai complex, folosind o închidere:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Un iterator peste șiruri de caractere ale acestui fel de șir, separat de un model, începând de la sfârșitul șirului, limitat la returnarea a cel mult `n` articole.
    ///
    ///
    /// Dacă se restituie șirurile `n`, ultimul șir (șirul `n`th) va conține restul șirului.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat nu va avea un sfârșit dublu, deoarece nu este eficient de suportat.
    ///
    /// Pentru despărțirea din față, poate fi utilizată metoda [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Un model mai complex, folosind o închidere:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Împarte șirul la prima apariție a delimitatorului specificat și returnează prefixul înainte de delimitator și sufixul după delimitator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Împarte șirul la ultima apariție a delimitatorului specificat și returnează prefixul înainte de delimitator și sufixul după delimitator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Un iterator peste potrivirile disjuncte ale unui model în cadrul feliei de șir date.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat va fi un [`DoubleEndedIterator`] dacă modelul permite o căutare inversă și căutarea forward/reverse produce aceleași elemente.
    /// Acest lucru este valabil pentru, de exemplu, [`char`], dar nu și pentru `&str`.
    ///
    /// Dacă modelul permite o căutare inversă, dar rezultatele sale pot diferi de o căutare directă, poate fi utilizată metoda [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Un iterator peste potrivirile disjuncte ale unui model din această felie de șir, a cedat în ordine inversă.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat necesită ca modelul să accepte o căutare inversă și va fi un [`DoubleEndedIterator`] dacă o căutare forward/reverse produce aceleași elemente.
    ///
    ///
    /// Pentru iterația din față, poate fi utilizată metoda [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Un iterator peste potrivirile disjuncte ale unui model din această porțiune de șir, precum și indicele la care începe meciul.
    ///
    /// Pentru meciurile `pat` din cadrul `self` care se suprapun, se returnează numai indicii corespunzători primei potriviri.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat va fi un [`DoubleEndedIterator`] dacă modelul permite o căutare inversă și căutarea forward/reverse produce aceleași elemente.
    /// Acest lucru este valabil pentru, de exemplu, [`char`], dar nu și pentru `&str`.
    ///
    /// Dacă modelul permite o căutare inversă, dar rezultatele sale pot diferi de o căutare directă, poate fi utilizată metoda [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // doar primul `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Un iterator asupra potrivirilor disjuncte ale unui model din cadrul `self`, a cedat în ordine inversă împreună cu indicele meciului.
    ///
    /// Pentru meciurile `pat` din cadrul `self` care se suprapun, se returnează numai indicii corespunzători ultimului meci.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamentul iterator
    ///
    /// Iteratorul returnat necesită ca modelul să accepte o căutare inversă și va fi un [`DoubleEndedIterator`] dacă o căutare forward/reverse produce aceleași elemente.
    ///
    ///
    /// Pentru iterația din față, poate fi utilizată metoda [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // doar ultimul `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Returnează o felie de șir cu spațiul alb principal și final eliminat.
    ///
    /// 'Whitespace' este definit în conformitate cu termenii proprietății de bază derivate Unicode `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Returnează o secțiune de șir cu spațiul alb principal eliminat.
    ///
    /// 'Whitespace' este definit în conformitate cu termenii proprietății de bază derivate Unicode `White_Space`.
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// `start` în acest context înseamnă prima poziție a acelui șir de octeți;pentru o limbă de la stânga la dreapta, cum ar fi engleza sau rusa, aceasta va fi partea stângă, iar pentru limbile de la dreapta la stânga, cum ar fi araba sau ebraica, aceasta va fi partea dreaptă.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Returnează un fel de șir cu spațiul alb eliminat.
    ///
    /// 'Whitespace' este definit în conformitate cu termenii proprietății de bază derivate Unicode `White_Space`.
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// `end` în acest context înseamnă ultima poziție a acelui șir de octeți;pentru o limbă de la stânga la dreapta, cum ar fi engleza sau rusa, aceasta va fi partea dreaptă, iar pentru limbile de la dreapta la stânga, cum ar fi araba sau ebraica, aceasta va fi partea stângă.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Returnează o secțiune de șir cu spațiul alb principal eliminat.
    ///
    /// 'Whitespace' este definit în conformitate cu termenii proprietății de bază derivate Unicode `White_Space`.
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// 'Left' în acest context înseamnă prima poziție a acelui șir de octeți;pentru o limbă precum araba sau ebraica care sunt " de la dreapta la stânga`mai degrabă decât " de la stânga la dreapta`, aceasta va fi partea _right_, nu stânga.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Returnează un fel de șir cu spațiul alb eliminat.
    ///
    /// 'Whitespace' este definit în conformitate cu termenii proprietății de bază derivate Unicode `White_Space`.
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// 'Right' în acest context înseamnă ultima poziție a acelui șir de octeți;pentru o limbă precum araba sau ebraica care sunt " de la dreapta la stânga`mai degrabă decât " de la stânga la dreapta`, aceasta va fi partea _left_, nu dreapta.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Returnează o felie de șir cu toate prefixele și sufixele care se potrivesc cu un model eliminat în mod repetat.
    ///
    /// [pattern] poate fi un [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Un model mai complex, folosind o închidere:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Amintiți-vă prima potrivire cunoscută, corectați-o mai jos dacă
            // ultimul meci este diferit
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIGURANȚĂ: se știe că `Searcher` returnează indici valabili.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Returnează o felie de șir cu toate prefixele care se potrivesc cu un model eliminat în mod repetat.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// `start` în acest context înseamnă prima poziție a acelui șir de octeți;pentru o limbă de la stânga la dreapta, cum ar fi engleza sau rusa, aceasta va fi partea stângă, iar pentru limbile de la dreapta la stânga, cum ar fi araba sau ebraica, aceasta va fi partea dreaptă.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SIGURANȚĂ: se știe că `Searcher` returnează indici valabili.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Returnează o felie de șir cu prefixul eliminat.
    ///
    /// Dacă șirul începe cu modelul `prefix`, returnează subșirul după prefix, înfășurat în `Some`.
    /// Spre deosebire de `trim_start_matches`, această metodă elimină prefixul exact o dată.
    ///
    /// Dacă șirul nu pornește cu `prefix`, returnează `None`.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Returnează o felie de șir cu sufixul eliminat.
    ///
    /// Dacă șirul se termină cu modelul `suffix`, returnează șirul înainte de sufix, înfășurat în `Some`.
    /// Spre deosebire de `trim_end_matches`, această metodă elimină sufixul exact o dată.
    ///
    /// Dacă șirul nu se termină cu `suffix`, returnează `None`.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Returnează o felie de șir cu toate sufixele care se potrivesc cu un model eliminat în mod repetat.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// `end` în acest context înseamnă ultima poziție a acelui șir de octeți;pentru o limbă de la stânga la dreapta, cum ar fi engleza sau rusa, aceasta va fi partea dreaptă, iar pentru limbile de la dreapta la stânga, cum ar fi araba sau ebraica, aceasta va fi partea stângă.
    ///
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Un model mai complex, folosind o închidere:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIGURANȚĂ: se știe că `Searcher` returnează indici valabili.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Returnează o felie de șir cu toate prefixele care se potrivesc cu un model eliminat în mod repetat.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// 'Left' în acest context înseamnă prima poziție a acelui șir de octeți;pentru o limbă precum araba sau ebraica care sunt " de la dreapta la stânga`mai degrabă decât " de la stânga la dreapta`, aceasta va fi partea _right_, nu stânga.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Returnează o felie de șir cu toate sufixele care se potrivesc cu un model eliminat în mod repetat.
    ///
    /// [pattern] poate fi un `&str`, [`char`], o felie de [`char`] s sau o funcție sau închidere care determină dacă un caracter se potrivește.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direcționalitatea textului
    ///
    /// Un șir este o secvență de octeți.
    /// 'Right' în acest context înseamnă ultima poziție a acelui șir de octeți;pentru o limbă precum araba sau ebraica care sunt " de la dreapta la stânga`mai degrabă decât " de la stânga la dreapta`, aceasta va fi partea _left_, nu dreapta.
    ///
    ///
    /// # Examples
    ///
    /// Modele simple:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Un model mai complex, folosind o închidere:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analizează această felie de șir într-un alt tip.
    ///
    /// Deoarece `parse` este atât de general, poate cauza probleme cu inferența de tip.
    /// Ca atare, `parse` este una dintre puținele ocazii în care veți vedea sintaxa cunoscută cu afecțiune sub numele de 'turbofish': `::<>`.
    ///
    /// Acest lucru ajută algoritmul de inferență să înțeleagă în mod specific în ce tip încercați să analizați.
    ///
    /// `parse` poate analiza orice tip care implementează [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Va returna [`Err`] dacă nu este posibilă analizarea acestei felii de șir în tipul dorit.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Utilizare de bază
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Utilizarea 'turbofish' în loc de adnotarea `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Nu se analizează:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Verifică dacă toate caracterele din acest șir se află în intervalul ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Putem trata fiecare octet ca caracter aici: toate caracterele multibyte încep cu un octet care nu se află în intervalul ascii, deci ne vom opri deja acolo.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Verifică dacă două șiruri sunt o potrivire ASCII care nu face sensibilitate la majuscule.
    ///
    /// La fel ca `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, dar fără alocarea și copierea temporară.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Convertește acest șir la echivalentul ASCII cu majuscule la locul său.
    ///
    /// Literele ASCII 'a' la 'z' sunt mapate la 'A' la 'Z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a returna o nouă valoare cu majusculă fără a o modifica pe cea existentă, utilizați [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SIGURANȚĂ: sigur deoarece transmutăm două tipuri cu același aspect.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Convertește acest șir în echivalentul său ASCII minuscul în loc.
    ///
    /// Literele ASCII 'A' la 'Z' sunt mapate la 'a' la 'z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a returna o nouă valoare cu litere mici, fără a o modifica pe cea existentă, utilizați [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SIGURANȚĂ: sigur deoarece transmutăm două tipuri cu același aspect.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Întoarceți un iterator care scapă de fiecare caracter din `self` cu [`char::escape_debug`].
    ///
    ///
    /// Note: vor fi evadate numai punctele de cod grafem extinse care încep șirul.
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Întoarceți un iterator care scapă de fiecare caracter din `self` cu [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Întoarceți un iterator care scapă de fiecare caracter din `self` cu [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Creează un str. Gol
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Creează un str mutabil gol
    #[inline]
    fn default() -> Self {
        // SIGURANȚĂ: Șirul gol este UTF-8 valid.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Un tip fn denumit, clonabil
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SIGURANȚĂ: nu este sigur
        unsafe { from_utf8_unchecked(bytes) }
    };
}