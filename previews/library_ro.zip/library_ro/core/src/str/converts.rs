//! Modalități de a crea un `str` din secțiunea de octeți.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Convertește o felie de octeți într-o felie de șir.
///
/// Un fel de șir ([`&str`]) este format din octeți ([`u8`]), iar un fel de octeți ([`&[u8]`][byteslice]) este format din octeți, astfel încât această funcție convertește între cele două.
/// Nu toate feliile de octeți sunt felii de șir valide, cu toate acestea: [`&str`] necesită ca acesta să fie UTF-8 valid.
/// `from_utf8()` verifică pentru a se asigura că octeții sunt valizi UTF-8 și apoi efectuează conversia.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Dacă sunteți sigur că felia de octeți este UTF-8 validă și nu doriți să suportați cheltuielile generale ale verificării de validitate, există o versiune nesigură a acestei funcții, [`from_utf8_unchecked`], care are același comportament, dar omite verificarea.
///
///
/// Dacă aveți nevoie de un `String` în loc de un `&str`, luați în considerare [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Deoarece puteți aloca în stivă un `[u8; N]` și puteți lua un [`&[u8]`][byteslice] din acesta, această funcție este o modalitate de a avea un șir alocat în stivă.Există un exemplu în secțiunea de exemple de mai jos.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Returnează `Err` dacă felia nu este UTF-8 cu o descriere a motivului pentru care felia furnizată nu este UTF-8.
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::str;
///
/// // unii octeți, într-un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Știm că acești octeți sunt valabili, deci folosiți doar `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Octet incorect:
///
/// ```
/// use std::str;
///
/// // niște octeți invalizi, într-un vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Consultați documentele pentru [`Utf8Error`] pentru mai multe detalii despre tipurile de erori care pot fi returnate.
///
/// Un "stack allocated string":
///
/// ```
/// use std::str;
///
/// // unii octeți, într-o matrice alocată stivei
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Știm că acești octeți sunt valabili, deci folosiți doar `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURANȚĂ: tocmai am rulat validarea.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Convertește o felie mutabilă de octeți într-o felie șir mutabilă.
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" ca un vector mutabil
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // După cum știm, acești octeți sunt valabili, putem folosi `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Octet incorect:
///
/// ```
/// use std::str;
///
/// // Unii octeți invalizi într-un vector modificabil
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Consultați documentele pentru [`Utf8Error`] pentru mai multe detalii despre tipurile de erori care pot fi returnate.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURANȚĂ: tocmai am rulat validarea.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Convertește o felie de octeți într-o felie de șir fără a verifica dacă șirul conține UTF-8 valid.
///
/// Consultați versiunea sigură, [`from_utf8`], pentru mai multe informații.
///
/// # Safety
///
/// Această funcție nu este sigură, deoarece nu verifică dacă octeții care i-au fost trecuți sunt valabili UTF-8.
/// Dacă această constrângere este încălcată, rezultă un comportament nedefinit, deoarece restul Rust presupune că [`&str`] s sunt UTF-8 valide.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::str;
///
/// // unii octeți, într-un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SIGURANȚĂ: apelantul trebuie să garanteze că octeții `v` sunt UTF-8 valabili.
    // De asemenea, se bazează pe `&str` și `&[u8]` având același aspect.
    unsafe { mem::transmute(v) }
}

/// Convertește o felie de octeți într-o felie de șir fără a verifica dacă șirul conține UTF-8 valid;versiune mutabilă.
///
///
/// Vedeți versiunea imuabilă, [`from_utf8_unchecked()`] pentru mai multe informații.
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SIGURANȚĂ: apelantul trebuie să garanteze că octeții `v`
    // sunt valabile UTF-8, deci distribuirea la `*mut str` este sigură.
    // De asemenea, dereferențarea indicatorului este sigură, deoarece acel indicator provine dintr-o referință care este garantată pentru a fi validă pentru scrieri.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}