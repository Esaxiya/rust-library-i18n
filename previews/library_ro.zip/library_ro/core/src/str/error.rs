//! Definește tipul de eroare utf8.

use crate::fmt;

/// Erori care pot apărea atunci când se încearcă interpretarea unei secvențe de [`u8`] ca un șir.
///
/// Ca atare, familia de funcții și metode `from_utf8` atât pentru [`String`], cât și pentru [`&str`] utilizează această eroare, de exemplu.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Metodele acestui tip de eroare pot fi utilizate pentru a crea funcționalități similare cu `String::from_utf8_lossy` fără a aloca memorie heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Returnează indexul din șirul dat până la care a fost verificat UTF-8 valid.
    ///
    /// Este indicele maxim astfel încât `from_utf8(&input[..index])` să returneze `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::str;
    ///
    /// // niște octeți invalizi, într-un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 returnează un Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // al doilea octet este invalid aici
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Oferă mai multe informații despre eșec:
    ///
    /// * `None`: sfârșitul intrării a fost atins în mod neașteptat.
    ///   `self.valid_up_to()` este de la 1 la 3 octeți de la sfârșitul intrării.
    ///   Dacă un flux de octeți (cum ar fi un fișier sau o priză de rețea) este decodificat incremental, acesta ar putea fi un `char` valid a cărui secvență de octeți UTF-8 se întinde pe mai multe bucăți.
    ///
    ///
    /// * `Some(len)`: a fost întâlnit un octet neașteptat.
    ///   Lungimea furnizată este cea a secvenței de octeți nevalizi care începe la indexul dat de `valid_up_to()`.
    ///   Decodarea trebuie reluată după acea secvență (după introducerea unui [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) în caz de decodare cu pierderi.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// O eroare returnată la analizarea unui `bool` folosind [`from_str`] eșuează
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}