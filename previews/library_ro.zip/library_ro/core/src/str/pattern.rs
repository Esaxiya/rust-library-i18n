//! Șirul API Pattern.
//!
//! API-ul Model oferă un mecanism generic pentru utilizarea diferitelor tipuri de modele atunci când căutăm printr-un șir.
//!
//! Pentru mai multe detalii, consultați traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] și [`DoubleEndedSearcher`].
//!
//! Deși acest API este instabil, este expus prin intermediul API-urilor stabile de tipul [`str`].
//!
//! # Examples
//!
//! [`Pattern`] este [implemented][pattern-impls] în API-ul stabil pentru [`&str`][`str`], [`char`], felii de [`char`] și funcții și închideri care implementează `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // tipar char
//! assert_eq!(s.find('n'), Some(2));
//! // felie de tipar de caractere
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // model de închidere
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Un model de șir.
///
/// Un `Pattern<'a>` exprimă faptul că tipul de implementare poate fi utilizat ca șablon șir pentru căutarea într-un [`&'a str`][str].
///
/// De exemplu, atât `'a'`, cât și `"aa"` sunt modele care s-ar potrivi la indexul `1` din șirul `"baaaab"`.
///
/// trait în sine acționează ca un constructor pentru un tip [`Searcher`] asociat, care face munca efectivă de a găsi aparițiile modelului într-un șir.
///
///
/// În funcție de tipul modelului, comportamentul metodelor precum [`str::find`] și [`str::contains`] se poate modifica.
/// Tabelul de mai jos descrie unele dintre aceste comportamente.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Căutător asociat pentru acest model
    type Searcher: Searcher<'a>;

    /// Construiește căutătorul asociat din `self` și `haystack` pentru a căuta.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Verifică dacă modelul se potrivește oriunde în fân
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Verifică dacă modelul se potrivește în partea din față a fânului
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Verifică dacă modelul se potrivește în partea din spate a fânului
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Elimină modelul din partea din față a fânului, dacă se potrivește.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SIGURANȚĂ: se știe că `Searcher` returnează indici valabili.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Îndepărtează modelul din spatele fânului, dacă se potrivește.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SIGURANȚĂ: se știe că `Searcher` returnează indici valabili.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Rezultatul apelului [`Searcher::next()`] sau [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Exprimă că o potrivire a modelului a fost găsită la `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Exprimă faptul că `haystack[a..b]` a fost respins ca o posibilă potrivire a modelului.
    ///
    /// Rețineți că ar putea exista mai mult de un `Reject` între două " meciuri`, nu există nicio cerință pentru ca acestea să fie combinate într-unul singur.
    ///
    ///
    Reject(usize, usize),
    /// Exprimă faptul că fiecare octet al fânului a fost vizitat, încheind iterația.
    ///
    Done,
}

/// Un căutător pentru un model de șir.
///
/// Acest trait oferă metode pentru căutarea potrivirilor care nu se suprapun dintr-un model începând de la (left) frontală a unui șir.
///
/// Acesta va fi implementat de tipurile `Searcher` asociate ale [`Pattern`] trait.
///
/// trait este marcat nesigur, deoarece indicii returnați de metodele [`next()`][Searcher::next] sunt obligați să se afle pe limite valide utf8 în fân.
/// Acest lucru permite consumatorilor acestui trait să taie fânul fără verificări suplimentare de rulare.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter pentru șirul de bază care trebuie căutat
    ///
    /// Va reveni întotdeauna același [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Efectuează următorul pas de căutare începând din față.
    ///
    /// - Returnează [`Match(a, b)`][SearchStep::Match] dacă `haystack[a..b]` se potrivește cu modelul.
    /// - Returnează [`Reject(a, b)`][SearchStep::Reject] dacă `haystack[a..b]` nu se potrivește cu modelul, nici măcar parțial.
    /// - Returnează [`Done`][SearchStep::Done] dacă a fost vizitat fiecare octet al fânului.
    ///
    /// Fluxul de valori [`Match`][SearchStep::Match] și [`Reject`][SearchStep::Reject] până la un [`Done`][SearchStep::Done] va conține intervale de indici care sunt adiacente, care nu se suprapun, acoperă întregul fân și se așază pe limitele utf8.
    ///
    ///
    /// Un rezultat [`Match`][SearchStep::Match] trebuie să conțină întregul model asociat, totuși rezultatele [`Reject`][SearchStep::Reject] pot fi împărțite în multe fragmente adiacente arbitrare.Ambele intervale pot avea o lungime zero.
    ///
    /// De exemplu, modelul `"aaa"` și fânul `"cbaaaaab"` ar putea produce fluxul
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Găsește următorul rezultat [`Match`][SearchStep::Match].Vezi [`next()`][Searcher::next].
    ///
    /// Spre deosebire de [`next()`][Searcher::next], nu există nicio garanție că intervalele returnate ale acestuia și [`next_reject`][Searcher::next_reject] se vor suprapune.
    /// Aceasta va returna `(start_match, end_match)`, unde start_match este indicele de unde începe meciul, iar end_match este indexul după sfârșitul meciului.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Găsește următorul rezultat [`Reject`][SearchStep::Reject].A se vedea [`next()`][Searcher::next] și [`next_match()`][Searcher::next_match].
    ///
    /// Spre deosebire de [`next()`][Searcher::next], nu există nicio garanție că intervalele returnate ale acestuia și [`next_match`][Searcher::next_match] se vor suprapune.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un căutător invers pentru un șir de caractere.
///
/// Acest trait oferă metode pentru căutarea potrivirilor care nu se suprapun dintr-un model începând de la (right) din spate a unui șir.
///
/// Acesta va fi implementat de tipurile [`Searcher`] asociate ale [`Pattern`] trait dacă modelul acceptă căutarea acestuia din spate.
///
///
/// Intervalele de indici returnate de acest trait nu sunt necesare pentru a se potrivi exact cu cele ale căutării directe în sens invers.
///
/// Din motivul pentru care acest trait este marcat ca fiind nesigur, consultați-l părinte trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Efectuează următorul pas de căutare începând din spate.
    ///
    /// - Returnează [`Match(a, b)`][SearchStep::Match] dacă `haystack[a..b]` se potrivește cu modelul.
    /// - Returnează [`Reject(a, b)`][SearchStep::Reject] dacă `haystack[a..b]` nu se potrivește cu modelul, nici măcar parțial.
    /// - Returnează [`Done`][SearchStep::Done] dacă a fost vizitat fiecare octet al fânului
    ///
    /// Fluxul de valori [`Match`][SearchStep::Match] și [`Reject`][SearchStep::Reject] până la un [`Done`][SearchStep::Done] va conține intervale de indici care sunt adiacente, care nu se suprapun, acoperă întregul fân și se așază pe limitele utf8.
    ///
    ///
    /// Un rezultat [`Match`][SearchStep::Match] trebuie să conțină întregul model asociat, totuși rezultatele [`Reject`][SearchStep::Reject] pot fi împărțite în multe fragmente adiacente arbitrare.Ambele intervale pot avea o lungime zero.
    ///
    /// De exemplu, modelul `"aaa"` și fânul `"cbaaaaab"` ar putea produce fluxul `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Găsește următorul rezultat [`Match`][SearchStep::Match].
    /// Vezi [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Găsește următorul rezultat [`Reject`][SearchStep::Reject].
    /// Vezi [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un marker trait pentru a exprima faptul că un [`ReverseSearcher`] poate fi utilizat pentru o implementare [`DoubleEndedIterator`].
///
/// Pentru aceasta, aplicația [`Searcher`] și [`ReverseSearcher`] trebuie să respecte aceste condiții:
///
/// - Toate rezultatele `next()` trebuie să fie identice cu rezultatele `next_back()` în ordine inversă.
/// - `next()` și `next_back()` trebuie să se comporte ca cele două capete ale unei game de valori, adică nu pot "walk past each other".
///
/// # Examples
///
/// `char::Searcher` este un `DoubleEndedSearcher` deoarece căutarea unui [`char`] necesită doar o privire pe rând, care se comportă la fel de la ambele capete.
///
/// `(&str)::Searcher` nu este un `DoubleEndedSearcher` deoarece modelul `"aa"` din fânul `"aaa"` se potrivește fie cu `"[aa]a"`, fie cu `"a[aa]"`, în funcție de ce parte este căutat.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl pentru caracter
/////////////////////////////////////////////////////////////////////////////

/// Tip asociat pentru `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant de siguranță: `finger`/`finger_back` trebuie să fie un index de octet utf8 valid al lui `haystack` Acest invariant poate fi rupt *în* next_match și next_match_back, totuși trebuie să iasă cu degetele pe limitele punctelor de cod valide.
    //
    //
    /// `finger` este indicele de octet actual al căutării directe.
    /// Imaginați-vă că există înainte de octetul la indexul său, adică
    /// `haystack[finger]` este primul octet al feliei pe care trebuie să o inspectăm în timpul căutării înainte
    ///
    finger: usize,
    /// `finger_back` este indicele de octet actual al căutării inverse.
    /// Imaginați-vă că există după octetul la indexul său, adică
    /// haystack [finger_back, 1] este ultimul octet al feliei pe care trebuie să îl inspectăm în timpul căutării înainte (și astfel primul octet care trebuie inspectat atunci când apelăm next_back()).
    ///
    finger_back: usize,
    /// Personajul căutat
    needle: char,

    // invariant de siguranță: `utf8_size` trebuie să fie mai mic de 5
    /// Numărul de octeți `needle` ocupă atunci când este codat în utf8.
    utf8_size: usize,
    /// O copie codificată utf8 a `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SIGURANȚĂ: 1-4 garantează siguranța `get_unchecked`
        // 1. `self.finger` și `self.finger_back` sunt păstrate la limitele unicode (aceasta este invariantă)
        // 2. `self.finger >= 0` deoarece începe de la 0 și crește doar
        // 3. `self.finger < self.finger_back` pentru că altfel caracterul `iter` ar întoarce `SearchStep::Done`
        // 4.
        // `self.finger` vine înainte de sfârșitul fânului, deoarece `self.finger_back` începe la sfârșit și scade doar
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // adăugați decalajul de octeți al caracterului curent fără a recodifica ca utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // obțineți fânul după ultimul personaj găsit
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ultimul octet al acului codat utf8 SIGURANȚĂ: avem un invariant care `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Noul deget este indicele octetului pe care l-am găsit, plus unul, deoarece am înregistrat ultimul octet al personajului.
                //
                // Rețineți că acest lucru nu ne dă întotdeauna un deget pe o limită UTF8.
                // Dacă *nu* am găsit caracterul nostru, este posibil să fi indexat la ultimul octet al unui caracter de 3 octeți sau 4 octeți.
                // Nu putem trece doar la următorul octet de pornire valid, deoarece un caracter ca ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ne va face să găsim întotdeauna al doilea octet atunci când îl căutăm pe al treilea.
                //
                //
                // Cu toate acestea, acest lucru este complet în regulă.
                // În timp ce avem invariantul că self.finger se află la o limită UTF8, acest invariant nu se bazează pe această metodă (se bazează pe CharSearcher::next()).
                //
                // Ieșim din această metodă doar când ajungem la sfârșitul șirului sau dacă găsim ceva.Când găsim ceva, `finger` va fi setat la o limită UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // nu am găsit nimic, ieși
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // permiteți next_reject să utilizeze implementarea implicită din Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SIGURANȚĂ: vezi comentariul pentru next() de mai sus
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // scădeți decalajul de octet al caracterului curent fără a recodifica ca utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // obțineți fânul până când nu includeți ultimul personaj căutat
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ultimul octet al acului codat utf8 SIGURANȚĂ: avem un invariant care `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // am căutat o felie care a fost compensată de self.finger, adăugăm self.finger pentru a recupera indexul original
                //
                let index = self.finger + index;
                // memrchr va returna indexul octetului pe care dorim să îl găsim.
                // În cazul unui caracter ASCII, aceasta este într-adevăr dacă ne dorim ca noul nostru deget să fie ("after" caracterul găsit în paradigma iterației inverse).
                //
                // Pentru caracterele multibyte, trebuie să sărim peste numărul de octeți pe care îl au decât ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // mutați degetul înaintea caracterului găsit (adică la indexul de început)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Aici nu putem folosi finger_back=index, mărime + 1.
                // Dacă am găsit ultimul caracter al unui caracter de dimensiuni diferite (sau octetul mijlociu al unui caracter diferit), trebuie să reducem finger_back la `index`.
                // Acest lucru face ca `finger_back` să aibă potențialul de a nu mai fi la o graniță, dar acest lucru este OK, deoarece ieșim doar din această funcție la o graniță sau când fânul a fost căutat complet.
                //
                //
                // Spre deosebire de next_match, acest lucru nu are problema de octeți repetați în utf-8, deoarece căutăm ultimul octet și putem găsi ultimul octet doar atunci când căutăm în sens invers.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // nu am găsit nimic, ieși
                return None;
            }
        }
    }

    // lasă next_reject_back să utilizeze implementarea implicită din Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Caută caractere care sunt egale cu un [`char`] dat.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Implicați un înveliș MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Comparați lungimile iteratorului de octeți interne pentru a găsi lungimea caracterului curent
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Comparați lungimile iteratorului de octeți interne pentru a găsi lungimea caracterului curent
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl pentru&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Schimbați/eliminați din cauza ambiguității în sens.

/// Tip asociat pentru `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Căutați caractere care sunt egale cu oricare dintre [`char`] din felie.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Implicație pentru F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Tip asociat pentru `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Se caută [`char`] care se potrivesc cu predicatul dat.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pentru&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegați la `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pentru &str
/////////////////////////////////////////////////////////////////////////////

/// Căutare sub-șir fără alocare.
///
/// Se va ocupa de modelul `""` ca returnând potriviri goale la fiecare limită de caractere.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Verifică dacă modelul se potrivește în partea din față a fânului.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Elimină modelul din partea din față a fânului, dacă se potrivește.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SIGURANȚĂ: prefixul tocmai a fost verificat pentru a exista.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Verifică dacă modelul se potrivește în partea din spate a fânului.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Îndepărtează modelul din spatele fânului, dacă se potrivește.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SIGURANȚĂ: sufixul a fost verificat pentru a exista.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Căutător cu două șiruri de șiruri
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Tip asociat pentru `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // acul gol respinge fiecare caracter și se potrivește cu fiecare șir gol între ele
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produce indicii *Match* valabili care se împart la limitele caracterelor, atâta timp cât potrivesc corect și că fânul și acul sunt valabile UTF-8 *Respinge* din algoritm poate cădea pe orice indici, dar le vom deplasa manual la următoarea limită de caractere, astfel încât să fie în siguranță utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // treceți la următoarea limită de caractere
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // scrieți carcasele `true` și `false` pentru a încuraja compilatorul să specializeze separat cele două carcase.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // treceți la următoarea limită de caractere
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // scrieți `true` și `false`, cum ar fi `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Starea internă a algoritmului de căutare bidirecțională a șirurilor.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// indicele de factorizare critică
    crit_pos: usize,
    /// indicele critic de factorizare pentru ac inversat
    crit_pos_back: usize,
    period: usize,
    /// `byteset` este o extensie (nu face parte din algoritmul bidirecțional);
    /// este un "fingerprint" pe 64 de biți în care fiecare bit set `j` corespunde unui (octet și 63)==j prezent în ac.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index în ac înaintea căruia ne-am asortat deja
    memory: usize,
    /// index în ac după care ne-am asortat deja
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // O explicație deosebit de lizibilă a ceea ce se întâmplă aici poate fi găsită în cartea "Text Algorithms" a lui Crochemore și Rytter, cap. 13.
        // Consultați în mod specific codul pentru "Algorithm CP" la p.
        // 323.
        //
        // Ceea ce se întâmplă este că avem o anumită factorizare critică (u, v) a acului și vrem să determinăm dacă u este un sufix al lui&v [.. perioadă].
        // Dacă este, folosim "Algorithm CP1".
        // În caz contrar, folosim "Algorithm CP2", care este optimizat pentru perioada în care acul este mare.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // caz de perioadă scurtă-perioada este exactă calculați o factorizare critică separată pentru acul inversat x=u 'v' unde | v '|<period(x).
            //
            // Acest lucru este accelerat de perioada cunoscută deja.
            // Rețineți că un caz ca x= "acba" poate fi luat în considerare exact înainte (crit_pos=1, period=3) în timp ce este luat în considerare cu perioada aproximativă inversă (crit_pos=2, period=2).
            // Folosim factorizarea inversă dată, dar păstrăm perioada exactă.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // caz de perioadă lungă-avem o aproximare la perioada reală și nu folosim memorarea.
            //
            //
            // Aproximează perioada cu limita inferioară max(|u|, |v|) + 1.
            // Factorizarea critică este eficientă de utilizat atât pentru căutarea directă, cât și pentru cea inversă.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valoare falsă pentru a semnifica faptul că perioada este lungă
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Una dintre ideile principale ale Two-Way este aceea că factorizăm acul în două jumătăți (u, v) și începem să încercăm să găsim v în fân prin scanarea de la stânga la dreapta.
    // Dacă v se potrivește, încercăm să îl potrivim scanând de la dreapta la stânga.
    // Cât de departe putem sări când întâlnim o nepotrivire se bazează pe faptul că (u, v) este o factorizare critică pentru ac.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` folosește `self.position` ca cursor
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Verificați dacă avem spațiu pentru a căuta în poziție + acul_ultima nu poate revărsa dacă presupunem că feliile sunt delimitate de intervalul isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Treceți rapid de porțiuni mari care nu au legătură cu șirul nostru
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Vedeți dacă partea dreaptă a acului se potrivește
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Vedeți dacă partea stângă a acului se potrivește
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Am găsit o potrivire!
            let match_pos = self.position;

            // Note: adăugați self.period în loc de needle.len() pentru a avea potriviri suprapuse
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // setat la needle.len(), self.period pentru meciuri suprapuse
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Urmărește ideile din `next()`.
    //
    // Definițiile sunt simetrice, cu period(x) = period(reverse(x)) și local_period(u, v) = local_period(reverse(v), reverse(u)), deci dacă (u, v) este o factorizare critică, la fel este (reverse(v), reverse(u)).
    //
    //
    // Pentru cazul invers, am calculat o factorizare critică x=u 'v' (câmpul `crit_pos_back`).Avem nevoie de | u |<period(x) pentru cazul direct și astfel | v '|<period(x) pentru revers.
    //
    // Pentru a căuta invers prin fân, căutăm înainte printr-un fân invers cu un ac inversat, potrivind mai întâi u 'și apoi v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` folosește `self.end` ca cursor-astfel încât `next()` și `next_back()` să fie independente.
        //
        let old_end = self.end;
        'search: loop {
            // Verificați dacă avem spațiu pentru a căuta în cele din urmă, needle.len() se va înfășura atunci când nu mai există loc, dar, din cauza limitelor de lungime a feliei, nu se poate înfășura niciodată până înapoi în lungimea fânului.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Treceți rapid de porțiuni mari care nu au legătură cu șirul nostru
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Vedeți dacă partea stângă a acului se potrivește
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Vedeți dacă partea dreaptă a acului se potrivește
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Am găsit o potrivire!
            let match_pos = self.end - needle.len();
            // Note: sub self.period în loc de needle.len() pentru a avea potriviri suprapuse
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Calculați sufixul maxim al `arr`.
    //
    // Sufixul maxim este o posibilă factorizare critică (u, v) a `arr`.
    //
    // Returnează (`i`, `p`) unde `i` este indicele inițial al lui v și `p` este perioada lui v.
    //
    // `order_greater` determină dacă ordinea lexicală este `<` sau `>`.
    // Ambele comenzi trebuie calculate-comanda cu cel mai mare `i` oferă o factorizare critică.
    //
    //
    // Pentru cazurile de perioadă lungă, perioada rezultată nu este exactă (este prea scurtă).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Corespunde cu i din ziar
        let mut right = 1; // Corespunde cu j din ziar
        let mut offset = 0; // Corespunde cu k din ziar, dar începând cu 0
        // pentru a se potrivi indexării bazate pe 0.
        let mut period = 1; // Corespunde cu p din ziar

        while let Some(&a) = arr.get(right + offset) {
            // `left` vor fi primite când `right` este.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sufixul este mai mic, perioada este întregul prefix până acum.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Înaintează prin repetarea perioadei curente.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Sufixul este mai mare, începeți din nou de la locația curentă.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Calculați sufixul maxim al reversului `arr`.
    //
    // Sufixul maxim este o posibilă factorizare critică (u ', v') a `arr`.
    //
    // Returnează `i` unde `i` este indicele inițial al lui v ', din spate;
    // revine imediat când se atinge o perioadă de `known_period`.
    //
    // `order_greater` determină dacă ordinea lexicală este `<` sau `>`.
    // Ambele comenzi trebuie calculate-comanda cu cel mai mare `i` oferă o factorizare critică.
    //
    //
    // Pentru cazurile de perioadă lungă, perioada rezultată nu este exactă (este prea scurtă).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Corespunde cu i din ziar
        let mut right = 1; // Corespunde cu j din ziar
        let mut offset = 0; // Corespunde cu k din ziar, dar începând cu 0
        // pentru a se potrivi indexării bazate pe 0.
        let mut period = 1; // Corespunde cu p din ziar
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sufixul este mai mic, perioada este întregul prefix până acum.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Înaintează prin repetarea perioadei curente.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Sufixul este mai mare, începeți din nou de la locația curentă.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy permite algoritmului să sară peste meciuri cât mai repede posibil sau să funcționeze într-un mod în care emite Respinge relativ repede.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Treceți la intervalele de potrivire cât mai repede posibil
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emitere respinge în mod regulat
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}