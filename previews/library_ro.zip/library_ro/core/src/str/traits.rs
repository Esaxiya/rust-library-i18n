//! Implementări Trait pentru `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementează ordonarea șirurilor.
///
/// Șirurile sunt ordonate [lexicographically](Ord#lexicographical-comparison) după valorile lor de octeți.
/// Aceasta comandă punctele de cod Unicode pe baza pozițiilor lor în diagramele de coduri.
/// Acest lucru nu este neapărat același cu ordinea "alphabetical", care variază în funcție de limbă și localizare.
/// Sortarea șirurilor în conformitate cu standardele acceptate din punct de vedere cultural necesită date specifice locației care sunt în afara domeniului de aplicare al tipului `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementează operații de comparație pe șiruri.
///
/// Șirurile sunt comparate [lexicographically](Ord#lexicographical-comparison) după valorile lor de octeți.
/// Aceasta compară punctele de cod Unicode pe baza pozițiilor lor în diagramele de coduri.
/// Acest lucru nu este neapărat același cu ordinea "alphabetical", care variază în funcție de limbă și localizare.
/// Compararea șirurilor în conformitate cu standardele acceptate din punct de vedere cultural necesită date specifice locației care sunt în afara domeniului de aplicare al tipului `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementează tranșarea subșirului cu sintaxa `&self[..]` sau `&mut self[..]`.
///
/// Returnează o felie din întregul șir, adică returnează `&self` sau `&mut self`.Echivalent cu `&self [0 ..
/// len] `sau`&mut self [0 ..
/// len]`.
/// Spre deosebire de alte operațiuni de indexare, acest lucru nu poate niciodată panic.
///
/// Această operațiune este *O*(1).
///
/// Înainte de 1.20.0, aceste operațiuni de indexare erau încă susținute de implementarea directă a `Index` și `IndexMut`.
///
/// Echivalent cu `&self[0 .. len]` sau `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementează tranșarea subșirului cu sintaxa `&self[begin .. end]` sau `&mut self[begin .. end]`.
///
/// Returnează o felie din șirul dat din intervalul de octeți [`begin`, `end`).
///
/// Această operațiune este *O*(1).
///
/// Înainte de 1.20.0, aceste operațiuni de indexare erau încă susținute de implementarea directă a `Index` și `IndexMut`.
///
/// # Panics
///
/// Panics dacă `begin` sau `end` nu indică decalajul octetului de pornire al unui caracter (așa cum este definit de `is_char_boundary`), dacă `begin > end` sau dacă `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // acestea vor panic:
/// // octetul 2 se află în `ö`:
/// // &s [2 ..3];
///
/// // octetul 8 se află în `老`&s [1 ..
/// // 8];
///
/// // octetul 100 este în afara șirului&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURANȚĂ: tocmai am verificat dacă `start` și `end` se află la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            // De asemenea, am verificat limitele caracterelor, deci este valabil UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURANȚĂ: tocmai ați verificat dacă `start` și `end` sunt la o limită de caracter.
            // Știm că indicatorul este unic deoarece l-am primit de la `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURANȚĂ: apelantul garantează că `self` se află în limitele `slice`
        // care îndeplinește toate condițiile pentru `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURANȚĂ: vezi comentariile pentru `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary verifică dacă indexul este în [0, .len()] nu poate reutiliza `get` ca mai sus, din cauza problemelor NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURANȚĂ: tocmai am verificat dacă `start` și `end` se află la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementează tranșarea subșirului cu sintaxa `&self[.. end]` sau `&mut self[.. end]`.
///
/// Returnează o felie din șirul dat din intervalul de octeți [`0`, `end`).
/// Echivalent cu `&self[0 .. end]` sau `&mut self[0 .. end]`.
///
/// Această operațiune este *O*(1).
///
/// Înainte de 1.20.0, aceste operațiuni de indexare erau încă susținute de implementarea directă a `Index` și `IndexMut`.
///
/// # Panics
///
/// Panics dacă `end` nu indică decalajul octetului inițial al unui caracter (așa cum este definit de `is_char_boundary`) sau dacă `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURANȚĂ: tocmai am verificat dacă `end` este la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURANȚĂ: tocmai am verificat dacă `end` este la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SIGURANȚĂ: tocmai am verificat dacă `end` este la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementează tranșarea subșirului cu sintaxa `&self[begin ..]` sau `&mut self[begin ..]`.
///
/// Returnează o felie din șirul dat din intervalul de octeți [`begin`, `len`).Echivalent cu `&self [începe ..
/// len] `sau`&mut self [începe ..
/// len]`.
///
/// Această operațiune este *O*(1).
///
/// Înainte de 1.20.0, aceste operațiuni de indexare erau încă susținute de implementarea directă a `Index` și `IndexMut`.
///
/// # Panics
///
/// Panics dacă `begin` nu indică decalajul octetului inițial al unui caracter (așa cum este definit de `is_char_boundary`) sau dacă `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURANȚĂ: tocmai am verificat dacă `start` este la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURANȚĂ: tocmai am verificat dacă `start` este la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURANȚĂ: apelantul garantează că `self` se află în limitele `slice`
        // care îndeplinește toate condițiile pentru `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURANȚĂ: identic cu `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SIGURANȚĂ: tocmai am verificat dacă `start` este la o limită de caracter,
            // și trecem într-o referință sigură, deci și valoarea de returnare va fi una.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementează tranșarea subșirului cu sintaxa `&self[begin ..= end]` sau `&mut self[begin ..= end]`.
///
/// Returnează o felie din șirul dat din intervalul de octeți [`begin`, `end`].Echivalent cu `&self [begin .. end + 1]` sau `&mut self[begin .. end + 1]`, cu excepția cazului în care `end` are valoarea maximă pentru `usize`.
///
/// Această operațiune este *O*(1).
///
/// # Panics
///
/// Panics dacă `begin` nu indică decalajul octetului inițial al unui caracter (așa cum este definit de `is_char_boundary`), dacă `end` nu indică decalajul octetului final al unui caracter (`end + 1` este fie un decalaj octet inițial, fie egal cu `len`), dacă `begin > end`, sau dacă `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementează tranșarea subșirului cu sintaxa `&self[..= end]` sau `&mut self[..= end]`.
///
/// Returnează o felie din șirul dat din intervalul de octeți [0, `end`].
/// Echivalent cu `&self [0 .. end + 1]`, cu excepția cazului în care `end` are valoarea maximă pentru `usize`.
///
/// Această operațiune este *O*(1).
///
/// # Panics
///
/// Panics dacă `end` nu indică decalajul de octet final al unui caracter (`end + 1` este fie un decalaj de octeți de pornire, așa cum este definit de `is_char_boundary`, sau egal cu `len`), sau dacă `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizați o valoare dintr-un șir
///
/// Metoda [`from_str`] din " FromStr`este adesea utilizată implicit, prin metoda [`parse`] a lui [`str`].
/// Consultați documentația [" analiza`] pentru exemple.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nu are un parametru durata de viață și, prin urmare, puteți analiza doar tipurile care nu conțin un parametru durata de viață.
///
/// Cu alte cuvinte, puteți analiza un `i32` cu `FromStr`, dar nu un `&i32`.
/// Puteți analiza o structură care conține un `i32`, dar nu una care conține un `&i32`.
///
/// # Examples
///
/// Implementarea de bază a `FromStr` pe un exemplu de tip `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Eroarea asociată care poate fi returnată de la analiză.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizează un șir `s` pentru a returna o valoare de acest tip.
    ///
    /// Dacă analiza reușește, returnați valoarea în interiorul [`Ok`], în caz contrar, când șirul nu este formatat, returnați o eroare specifică [`Err`] din interior.
    /// Tipul de eroare este specific implementării trait.
    ///
    /// # Examples
    ///
    /// Utilizare de bază cu [`i32`], un tip care implementează `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analizați un `bool` dintr-un șir.
    ///
    /// Produce un `Result<bool, ParseBoolError>`, deoarece `s` poate fi sau nu de fapt analizat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Rețineți, în multe cazuri, metoda `.parse()` pe `str` este mai adecvată.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}