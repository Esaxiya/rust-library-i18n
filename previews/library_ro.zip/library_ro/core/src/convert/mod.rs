//! Traits pentru conversii între tipuri.
//!
//! traits din acest modul oferă o modalitate de a converti de la un tip la altul.
//! Fiecare trait are un scop diferit:
//!
//! - Implementați [`AsRef`] trait pentru conversii ieftine referință-la-referință
//! - Implementați [`AsMut`] trait pentru conversii ieftine care pot fi modificate
//! - Implementați [`From`] trait pentru consumul de conversii valoare-valoare
//! - Implementați [`Into`] trait pentru consumul de conversii valoare-valoare la tipuri din afara crate curent
//! - [`TryFrom`] și [`TryInto`] traits se comportă ca [`From`] și [`Into`], dar ar trebui implementate atunci când conversia poate eșua.
//!
//! traits din acest modul sunt adesea folosite ca trait bounds pentru funcții generice astfel încât să fie acceptate argumente de mai multe tipuri.Consultați documentația fiecărui trait pentru exemple.
//!
//! Ca autor al bibliotecii, ar trebui să preferați întotdeauna să implementați [`From<T>`][`From`] sau [`TryFrom<T>`][`TryFrom`] în loc de [`Into<U>`][`Into`] sau [`TryInto<U>`][`TryInto`], deoarece [`From`] și [`TryFrom`] oferă o flexibilitate mai mare și oferă implementări echivalente [`Into`] sau [`TryInto`] gratuit, datorită unei implementări pătură în biblioteca standard.
//! Atunci când vizați o versiune anterioară Rust 1.41, poate fi necesar să implementați [`Into`] sau [`TryInto`] direct atunci când convertiți la un tip în afara crate curent.
//!
//! # Implementări generice
//!
//! - [`AsRef`] și [`AsMut`] autoreferențierea dacă tipul interior este o referință
//! - [`De la`]`<U>pentru T` implică [`Înto`]`</u><T><U>pentru U`</u>
//! - [`TryFrom`]`<U>pentru T` implică [`TryInto`]`</u><T><U>pentru U`</u>
//! - [`From`] și [`Into`] sunt reflexive, ceea ce înseamnă că toate tipurile pot `into` în sine și `from` în sine
//!
//! Consultați fiecare trait pentru exemple de utilizare.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Funcția de identitate.
///
/// Două lucruri sunt importante de remarcat despre această funcție:
///
/// - Nu este întotdeauna echivalent cu o închidere ca `|x| x`, deoarece închiderea poate constrânge `x` într-un alt tip.
///
/// - Mută intrarea `x` transmisă funcției.
///
/// Deși ar putea părea ciudat să aveți o funcție care doar returnează intrarea, există câteva utilizări interesante.
///
///
/// # Examples
///
/// Folosirea `identity` pentru a nu face nimic într-o succesiune de alte funcții interesante:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Să ne prefacem că adăugarea uneia este o funcție interesantă.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Utilizarea `identity` ca carcasă de bază "do nothing" în condițional:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Faceți lucruri mai interesante ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Folosind `identity` pentru a păstra variantele `Some` ale unui iterator de `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Folosit pentru a face o conversie ieftină referință-la-referință.
///
/// Acest trait este similar cu [`AsMut`], care este utilizat pentru conversia între referințe mutabile.
/// Dacă trebuie să faceți o conversie costisitoare, este mai bine să implementați [`From`] cu tipul `&T` sau să scrieți o funcție personalizată.
///
/// `AsRef` are aceeași semnătură ca [`Borrow`], dar [`Borrow`] este diferit în câteva aspecte:
///
/// - Spre deosebire de `AsRef`, [`Borrow`] are un instrument de acoperire pentru orice `T` și poate fi utilizat pentru a accepta fie o referință, fie o valoare.
/// - [`Borrow`] necesită, de asemenea, ca [`Hash`], [`Eq`] și [`Ord`] pentru valoarea împrumutată să fie echivalente cu cele ale valorii deținute.
/// Din acest motiv, dacă doriți să împrumutați doar un singur câmp dintr-o structură, puteți implementa `AsRef`, dar nu [`Borrow`].
///
/// **Note: Acest trait nu trebuie să dea greș **.Dacă conversia poate eșua, utilizați o metodă dedicată care returnează un [`Option<T>`] sau un [`Result<T, E>`].
///
/// # Implementări generice
///
/// - `AsRef` autoreferențieri dacă tipul interior este o referință sau o referință modificabilă (de exemplu: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Prin utilizarea trait bounds putem accepta argumente de diferite tipuri atâta timp cât pot fi convertite la tipul specificat `T`.
///
/// De exemplu: Prin crearea unei funcții generice care ia un `AsRef<str>`, exprimăm că dorim să acceptăm toate referințele care pot fi convertite în [`&str`] ca argument.
/// Deoarece atât [`String`], cât și [`&str`] implementează `AsRef<str>`, le putem accepta pe ambele ca argument de intrare.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Efectuează conversia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Folosit pentru a face o conversie ieftină de referință mutabilă-mutabilă.
///
/// Acest trait este similar cu [`AsRef`], dar utilizat pentru conversia între referințe mutabile.
/// Dacă trebuie să faceți o conversie costisitoare, este mai bine să implementați [`From`] cu tipul `&mut T` sau să scrieți o funcție personalizată.
///
/// **Note: Acest trait nu trebuie să dea greș **.Dacă conversia poate eșua, utilizați o metodă dedicată care returnează un [`Option<T>`] sau un [`Result<T, E>`].
///
/// # Implementări generice
///
/// - `AsMut` autoreferențieri dacă tipul interior este o referință mutabilă (de exemplu: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Folosind `AsMut` ca trait bound pentru o funcție generică putem accepta toate referințele mutabile care pot fi convertite în tipul `&mut T`.
/// Deoarece [`Box<T>`] implementează `AsMut<T>` putem scrie o funcție `add_one` care ia toate argumentele care pot fi convertite în `&mut u64`.
/// Deoarece [`Box<T>`] implementează `AsMut<T>`, `add_one` acceptă și argumente de tipul `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Efectuează conversia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// O conversie valoare-valoare care consumă valoarea de intrare.Opusul lui [`From`].
///
/// Ar trebui să evitați implementarea [`Into`] și să implementați [`From`] în schimb.
/// Implementarea [`From`] oferă automat una cu o implementare a [`Into`] datorită implementării păturii în biblioteca standard.
///
/// Preferați să utilizați [`Into`] peste [`From`] atunci când specificați trait bounds pe o funcție generică pentru a vă asigura că tipurile care implementează doar [`Into`] pot fi utilizate și ele.
///
/// **Note: Acest trait nu trebuie să dea greș **.Dacă conversia poate eșua, utilizați [`TryInto`].
///
/// # Implementări generice
///
/// - [`De la]]`<T>pentru U` implică `Into<U> for T`
/// - [`Into`] este reflexiv, ceea ce înseamnă că `Into<T> for T` este implementat
///
/// # Implementarea [`Into`] pentru conversii la tipuri externe în versiunile vechi ale Rust
///
/// Înainte de Rust 1.41, dacă tipul de destinație nu făcea parte din crate curent, atunci nu puteai implementa [`From`] direct.
/// De exemplu, luați acest cod:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Acest lucru nu va reuși să se compileze în versiunile mai vechi ale limbajului, deoarece regulile orfane ale lui Rust erau ceva mai stricte.
/// Pentru a ocoli acest lucru, puteți implementa [`Into`] direct:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Este important să înțelegem că [`Into`] nu oferă o implementare [`From`] (așa cum face [`From`] cu [`Into`]).
/// Prin urmare, ar trebui să încercați întotdeauna să implementați [`From`] și apoi să reveniți la [`Into`] dacă [`From`] nu poate fi implementat.
///
/// # Examples
///
/// [`String`] implementează [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Pentru a exprima că dorim ca o funcție generică să ia toate argumentele care pot fi convertite într-un tip specificat `T`, putem folosi un trait bound din [`Into`]`<T>`.
///
/// De exemplu: Funcția `is_hello` ia toate argumentele care pot fi convertite într-un [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Efectuează conversia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Folosit pentru a face conversii valoare-valoare în timp ce consumați valoarea de intrare.Este reciprocitatea [`Into`].
///
/// Ar trebui să preferați întotdeauna să implementați `From` peste [`Into`], deoarece implementarea `From` oferă automat o implementare a [`Into`] datorită implementării pături în biblioteca standard.
///
///
/// Implementați [`Into`] numai când vizați o versiune anterioară Rust 1.41 și convertiți la un tip în afara crate curent.
/// `From` nu a reușit să facă aceste tipuri de conversii în versiunile anterioare din cauza regulilor orfane ale lui Rust.
/// Consultați [`Into`] pentru mai multe detalii.
///
/// Preferați să utilizați [`Into`] decât să folosiți `From` atunci când specificați trait bounds pe o funcție generică.
/// În acest fel, tipurile care implementează direct [`Into`] pot fi folosite și ca argumente.
///
/// `From` este, de asemenea, foarte util atunci când efectuați tratarea erorilor.Atunci când se construiește o funcție care poate eșua, tipul de returnare va fi în general de forma `Result<T, E>`.
/// `From` trait simplifică gestionarea erorilor, permițând unei funcții să returneze un singur tip de eroare care încapsulează mai multe tipuri de erori.Consultați secțiunea "Examples" și [the book][book] pentru mai multe detalii.
///
/// **Note: Acest trait nu trebuie să dea greș **.Dacă conversia poate eșua, utilizați [`TryFrom`].
///
/// # Implementări generice
///
/// - `From<T> for U` implică [`Into`]`<U>pentru T`</u>
/// - `From` este reflexiv, ceea ce înseamnă că `From<T> for T` este implementat
///
/// # Examples
///
/// [`String`] implementează `From<&str>`:
///
/// O conversie explicită de la un `&str` la un șir se face după cum urmează:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// În timp ce efectuați tratarea erorilor, este adesea util să implementați `From` pentru propriul dvs. tip de eroare.
/// Prin conversia tipurilor de erori subiacente la propriul nostru tip de eroare personalizată care încapsulează tipul de eroare subiacent, putem returna un singur tip de eroare fără a pierde informații despre cauza subiacentă.
/// Operatorul '?' convertește automat tipul de eroare subiacent în tipul nostru de eroare personalizat apelând `Into<CliError>::into` care este furnizat automat la implementarea `From`.
/// Compilatorul deduce apoi ce implementare a `Into` ar trebui utilizată.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Efectuează conversia.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// O încercare de conversie care consumă `self`, care poate fi sau nu costisitoare.
///
/// Autorii bibliotecii nu ar trebui, de obicei, să implementeze direct acest trait, dar ar trebui să prefere implementarea [`TryFrom`] trait, care oferă o flexibilitate mai mare și oferă o implementare echivalentă `TryInto` gratuit, datorită unei implementări pătură în biblioteca standard.
/// Pentru mai multe informații despre acest lucru, consultați documentația pentru [`Into`].
///
/// # Implementarea `TryInto`
///
/// Aceasta suferă aceleași restricții și raționamente ca și implementarea [`Into`], consultați aici pentru detalii.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Tipul returnat în cazul unei erori de conversie.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Efectuează conversia.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Conversii de tip simplu și sigur, care pot eșua într-un mod controlat în anumite circumstanțe.Este reciprocitatea [`TryInto`].
///
/// Acest lucru este util atunci când efectuați o conversie de tip care poate avea succes în mod trivial, dar care poate necesita și o manipulare specială.
/// De exemplu, nu există nicio modalitate de a converti un [`i64`] într-un [`i32`] folosind [`From`] trait, deoarece un [`i64`] poate conține o valoare pe care un [`i32`] nu o poate reprezenta și astfel conversia ar pierde date.
///
/// Acest lucru ar putea fi rezolvat prin trunchierea [`i64`] la un [`i32`] (în esență, oferind valoarea [`i64`] modulului [`i32::MAX`]) sau prin simpla returnare a [`i32::MAX`], sau printr-o altă metodă.
/// [`From`] trait este destinat conversiilor perfecte, astfel încât `TryFrom` trait informează programatorul când o conversie de tip ar putea merge prost și le permite să decidă cum să o gestioneze.
///
/// # Implementări generice
///
/// - `TryFrom<T> for U` implică [`TryInto`]`<U>pentru T`</u>
/// - [`try_from`] este reflexiv, ceea ce înseamnă că `TryFrom<T> for T` este implementat și nu poate eșua-tipul `Error` asociat pentru apelarea `T::try_from()` pe o valoare de tip `T` este [`Infallible`].
/// Când tipul [`!`] este stabilizat, [`Infallible`] și [`!`] vor fi echivalente.
///
/// `TryFrom<T>` poate fi implementat după cum urmează:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Așa cum este descris, [`i32`] implementează `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunchiază în mod silențios `big_number`, necesită detectarea și tratarea trunchierii după fapt.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Returnează o eroare deoarece `big_number` este prea mare pentru a se potrivi într-un `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Returnează `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Tipul returnat în cazul unei erori de conversie.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Efectuează conversia.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GENERICE
////////////////////////////////////////////////////////////////////////////////

// Pe măsură ce ridică
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Pe măsură ce ridică peste &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): înlocuiți instrumentele de mai sus pentru&/&mut cu următoarele mai generale:
// // Ca ascensoare peste Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>pentru D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut ridică peste &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): înlocuiți instrumentul de mai sus pentru &mut cu următorul mai general:
// // AsMut ridică peste DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>pentru D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// De la implică în
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// De la (și astfel la Into) este reflexiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Notă de stabilitate:** Acest instrument nu există încă, dar suntem "reserving space" să îl adăugăm în future.
/// Consultați [rust-lang/rust#64715][#64715] pentru detalii.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): faceți o soluție de principiu.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implică TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Conversiile infailibile sunt semantic echivalente cu conversiile falibile cu un tip de eroare nelocuită.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS DE BETON
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TIPUL DE EROARE FĂRĂ ERORĂ
////////////////////////////////////////////////////////////////////////////////

/// Tipul de eroare pentru erori care nu se pot întâmpla niciodată.
///
/// Deoarece această enumere nu are nicio variantă, o valoare de acest tip nu poate exista niciodată.
/// Acest lucru poate fi util pentru API-urile generice care utilizează [`Result`] și parametrizează tipul de eroare, pentru a indica faptul că rezultatul este întotdeauna [`Ok`].
///
/// De exemplu, [`TryFrom`] trait (conversia care returnează un [`Result`]) are o implementare generală pentru toate tipurile în care există o implementare inversă [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilitate Future
///
/// Această enumere are același rol ca [the `!`“never”type][never], care este instabil în această versiune a Rust.
/// Când `!` este stabilizat, intenționăm să facem din `Infallible` un alias de tip:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Și, în cele din urmă, va deprecia `Infallible`.
///
/// Cu toate acestea, există un caz în care sintaxa `!` poate fi utilizată înainte ca `!` să fie stabilizată ca un tip complet: în poziția tipului de revenire al unei funcții.
/// Mai exact, sunt posibile implementări pentru două tipuri diferite de pointeri de funcții:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Având în vedere că `Infallible` este o enumerare, acest cod este valid.
/// Cu toate acestea, atunci când `Infallible` devine un alias pentru never type, cele două `impl`s vor începe să se suprapună și, prin urmare, vor fi interzise de regulile de coerență ale limbajului trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}