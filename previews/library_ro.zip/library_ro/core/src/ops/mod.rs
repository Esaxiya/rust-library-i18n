//! Operatori supraîncărcabili.
//!
//! Implementarea acestor traits vă permite să supraîncărcați anumiți operatori.
//!
//! Unele dintre aceste traits sunt importate de prelude, deci sunt disponibile în fiecare program Rust.Numai operatorii susținuți de traits pot fi supraîncărcați.
//! De exemplu, operatorul de adăugare (`+`) poate fi supraîncărcat prin [`Add`] trait, dar din moment ce operatorul de atribuire (`=`) nu are niciun suport trait, nu există nicio modalitate de a supraîncărca semantica sa.
//! În plus, acest modul nu oferă niciun mecanism pentru a crea noi operatori.
//! Dacă sunt necesare supraîncărcări fără caracteristici sau operatori personalizați, ar trebui să priviți spre macrocomenzi sau pluginuri de compilare pentru a extinde sintaxa Rust.
//!
//! Implementările operatorului traits nu ar trebui să fie surprinzătoare în contextele lor respective, ținând cont de semnificațiile lor obișnuite și de [operator precedence].
//! De exemplu, atunci când implementați [`Mul`], operația ar trebui să aibă o anumită asemănare cu multiplicarea (și să împartă proprietățile așteptate, cum ar fi asociativitatea).
//!
//! Rețineți că operatorii `&&` și `||` scurtcircuitează, adică își evaluează cel de-al doilea operand numai dacă contribuie la rezultat.Deoarece acest comportament nu este aplicabil de către traits, `&&` și `||` nu sunt acceptate ca operatori supraîncărcabili.
//!
//! Mulți dintre operatori își iau operanzii după valoare.În contexte non-generice care implică tipuri încorporate, aceasta nu este de obicei o problemă.
//! Cu toate acestea, utilizarea acestor operatori în cod generic necesită o anumită atenție dacă valorile trebuie reutilizate, spre deosebire de a le permite operatorilor să le consume.O opțiune este utilizarea ocazională a [`clone`].
//! O altă opțiune este să vă bazați pe tipurile implicate, oferind implementări suplimentare de operator pentru referințe.
//! De exemplu, pentru un tip definit de utilizator `T` care ar trebui să accepte adăugarea, este probabil o idee bună ca atât `T`, cât și `&T` să implementeze traits [`Add<T>`][`Add`] și [`Add<&T>`][`Add`], astfel încât codul generic să poată fi scris fără clonare inutilă.
//!
//!
//! # Examples
//!
//! Acest exemplu creează o structură `Point` care implementează [`Add`] și [`Sub`] și apoi demonstrează adăugarea și scăderea a două `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Consultați documentația pentru fiecare trait pentru un exemplu de implementare.
//!
//! [`Fn`], [`FnMut`] și [`FnOnce`] traits sunt implementate după tipuri care pot fi invocate ca funcții.Rețineți că [`Fn`] ia `&self`, [`FnMut`] ia `&mut self` și [`FnOnce`] ia `self`.
//! Acestea corespund celor trei tipuri de metode care pot fi invocate într-o instanță: apel-prin-referință, apel-cu-mutabil-referință și apel-după-valoare.
//! Cea mai obișnuită utilizare a acestor traits este de a acționa ca limite la funcțiile de nivel superior care iau funcții sau închideri ca argumente.
//!
//! Luând un [`Fn`] ca parametru:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Luând un [`FnMut`] ca parametru:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Luând un [`FnOnce`] ca parametru:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` își consumă variabilele capturate, deci nu poate fi rulat de mai multe ori
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Încercarea de a invoca din nou `func()` va genera o eroare `use of moved value` pentru `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` nu mai poate fi invocat în acest moment
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;