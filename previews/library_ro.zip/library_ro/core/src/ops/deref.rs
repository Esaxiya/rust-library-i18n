/// Folosit pentru operații de dereferențiere imuabile, cum ar fi `*v`.
///
/// Pe lângă faptul că este utilizat pentru operațiuni explicite de dereferențiere cu operatorul (unary) `*` în contexte imuabile, `Deref` este, de asemenea, utilizat implicit de compilator în multe circumstanțe.
/// Acest mecanism se numește ['`Deref` coercion'][more].
/// În contexte mutabile, se utilizează [`DerefMut`].
///
/// Implementarea `Deref` pentru indicatoarele inteligente face convenabilă accesarea datelor din spatele lor, motiv pentru care implementează `Deref`.
/// Pe de altă parte, regulile referitoare la `Deref` și [`DerefMut`] au fost concepute special pentru a găzdui indicii inteligenți.
/// Din acest motiv,**" Deref` ar trebui implementat numai pentru indicatorii inteligenți** pentru a evita confuzia.
///
/// Din motive similare,**acest trait nu ar trebui să dea greș niciodată**.Eșecul în timpul dereferențierii poate fi extrem de confuz atunci când `Deref` este invocat implicit.
///
/// # Mai multe despre coerciția `Deref`
///
/// Dacă `T` implementează `Deref<Target = U>` și `x` este o valoare de tip `T`, atunci:
///
/// * În contexte imuabile, `*x` (unde `T` nu este nici o referință, nici un indicator brut) este echivalent cu `* Deref::deref(&x)`.
/// * Valorile de tip `&T` sunt constrânse la valorile de tip `&U`
/// * `T` implementează implicit toate metodele (immutable) de tipul `U`.
///
/// Pentru mai multe detalii, vizitați [the chapter in *The Rust Programming Language*][book], precum și secțiunile de referință pentru [the dereference operator][ref-deref-op], [method resolution] și [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// O structură cu un singur câmp accesibil prin dereferențierea structurii.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Tipul rezultat după dereferențiere.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferează valoarea.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Folosit pentru operațiuni de dereferențiere mutabile, ca în `*v = 1;`.
///
/// Pe lângă faptul că este utilizat pentru operațiuni explicite de dereferențiere cu operatorul (unary) `*` în contexte mutabile, `DerefMut` este, de asemenea, utilizat implicit de compilator în multe circumstanțe.
/// Acest mecanism se numește ['`Deref` coercion'][more].
/// În contexte imuabile, se utilizează [`Deref`].
///
/// Implementarea `DerefMut` pentru indicatoarele inteligente face ca mutarea datelor din spatele lor să fie convenabilă, motiv pentru care implementează `DerefMut`.
/// Pe de altă parte, regulile referitoare la [`Deref`] și `DerefMut` au fost concepute special pentru a găzdui indicii inteligenți.
/// Din acest motiv,**" DerefMut` ar trebui implementat numai pentru indicatorii inteligenți** pentru a evita confuzia.
///
/// Din motive similare,**acest trait nu ar trebui să dea greș niciodată**.Eșecul în timpul dereferențierii poate fi extrem de confuz atunci când `DerefMut` este invocat implicit.
///
/// # Mai multe despre coerciția `Deref`
///
/// Dacă `T` implementează `DerefMut<Target = U>` și `x` este o valoare de tip `T`, atunci:
///
/// * În contexte mutabile, `*x` (unde `T` nu este nici o referință, nici un indicator brut) este echivalent cu `* DerefMut::deref_mut(&mut x)`.
/// * Valorile de tip `&mut T` sunt constrânse la valorile de tip `&mut U`
/// * `T` implementează implicit toate metodele (mutable) de tipul `U`.
///
/// Pentru mai multe detalii, vizitați [the chapter in *The Rust Programming Language*][book], precum și secțiunile de referință pentru [the dereference operator][ref-deref-op], [method resolution] și [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// O structură cu un singur câmp care se poate modifica prin dereferențierea structurii.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Deferențiază reciproc valoarea.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indică faptul că o structură poate fi utilizată ca receptor de metodă, fără caracteristica `arbitrary_self_types`.
///
/// Acest lucru este implementat de tipurile de pointer stdlib cum ar fi `Box<T>`, `Rc<T>`, `&T` și `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}