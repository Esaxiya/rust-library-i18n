use crate::marker::Unpin;
use crate::pin::Pin;

/// Rezultatul reluării generatorului.
///
/// Această enumere este returnată din metoda `Generator::resume` și indică valorile posibile de returnare ale unui generator.
/// În prezent, acesta corespunde fie unui punct de suspendare (`Yielded`), fie unui punct de terminare (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generatorul suspendat cu o valoare.
    ///
    /// Această stare indică faptul că un generator a fost suspendat și, de obicei, corespunde unei instrucțiuni `yield`.
    /// Valoarea oferită în această variantă corespunde expresiei transmise către `yield` și permite generatoarelor să furnizeze o valoare de fiecare dată când cedează.
    ///
    ///
    Yielded(Y),

    /// Generatorul completat cu o valoare de returnare.
    ///
    /// Această stare indică faptul că un generator a finalizat execuția cu valoarea furnizată.
    /// Odată ce un generator a returnat `Complete`, este considerat o eroare de programare să apeleze din nou `resume`.
    ///
    Complete(R),
}

/// trait implementat de tipurile de generator încorporat.
///
/// Generatoarele, denumite și coroutine, sunt în prezent o caracteristică de limbaj experimental în Rust.
/// Adăugate în generatoarele [RFC 2033] sunt în prezent destinate să ofere în principal un element de bază pentru sintaxa async/await, dar se vor extinde probabil și la furnizarea unei definiții ergonomice pentru iteratori și alte primitive.
///
///
/// Sintaxa și semantica pentru generatoare sunt instabile și vor necesita o RFC suplimentară pentru stabilizare.În acest moment, însă, sintaxa este de tip închidere:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Mai multe documente despre generatoare pot fi găsite în cartea instabilă.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Tipul de valoare pe care îl produce acest generator.
    ///
    /// Acest tip asociat corespunde expresiei `yield` și valorilor cărora li se permite să fie returnate de fiecare dată când cedează un generator.
    ///
    /// De exemplu, un iterator-ca-un-generator ar avea probabil acest tip ca `T`, tipul fiind iterat peste.
    ///
    type Yield;

    /// Tipul de valoare pe care îl returnează acest generator.
    ///
    /// Aceasta corespunde tipului returnat de la un generator fie cu o instrucțiune `return`, fie implicit ca ultimă expresie a unui literal al generatorului.
    /// De exemplu, futures ar folosi acest lucru ca `Result<T, E>` deoarece reprezintă un future finalizat.
    ///
    ///
    type Return;

    /// Reia executarea acestui generator.
    ///
    /// Această funcție va relua execuția generatorului sau va începe executarea dacă nu a făcut-o deja.
    /// Acest apel va reveni în ultimul punct de suspendare al generatorului, reluând execuția de la cel mai recent `yield`.
    /// Generatorul va continua să se execute până când cedează sau se întoarce, moment în care această funcție va reveni.
    ///
    /// # Valoare returnată
    ///
    /// Enumerația `GeneratorState` returnată de această funcție indică în ce stare se află generatorul la revenire.
    /// Dacă se returnează varianta `Yielded`, atunci generatorul a atins un punct de suspensie și s-a obținut o valoare.
    /// Generatoarele din această stare sunt disponibile pentru reluare într-un moment ulterior.
    ///
    /// Dacă `Complete` este returnat, atunci generatorul a terminat complet cu valoarea furnizată.Nu este valid pentru reluarea generatorului.
    ///
    /// # Panics
    ///
    /// Această funcție poate panic dacă este apelată după ce varianta `Complete` a fost returnată anterior.
    /// În timp ce literele generatoare în limbă sunt garantate pentru panic la reluarea după `Complete`, acest lucru nu este garantat pentru toate implementările `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}