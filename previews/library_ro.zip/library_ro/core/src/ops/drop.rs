/// Cod personalizat în cadrul distructorului.
///
/// Când o valoare nu mai este necesară, Rust va rula un "destructor" pe acea valoare.
/// Cel mai obișnuit mod în care o valoare nu mai este necesară este atunci când iese din domeniul de aplicare.Destructorii pot rula în continuare în alte circumstanțe, dar ne vom concentra asupra domeniului de aplicare al exemplelor de aici.
/// Pentru a afla mai multe despre aceste alte cazuri, vă rugăm să consultați secțiunea [the reference] despre destructori.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Acest distructor este format din două componente:
/// - Un apel către `Drop::drop` pentru valoarea respectivă, dacă acest `Drop` special trait este implementat pentru tipul său.
/// - "drop glue" generat automat, care apelează recursiv distructorii tuturor câmpurilor de această valoare.
///
/// Deoarece Rust apelează automat distructorii tuturor câmpurilor conținute, nu trebuie să implementați `Drop` în majoritatea cazurilor.
/// Dar există unele cazuri în care este util, de exemplu pentru tipurile care gestionează direct o resursă.
/// Resursa respectivă poate fi memorie, poate fi un descriptor de fișiere, poate fi o priză de rețea.
/// Odată ce o valoare de acest tip nu va mai fi utilizată, ar trebui să "clean up" resursa sa prin eliberarea memoriei sau închiderea fișierului sau soclului.
/// Aceasta este treaba unui destructor și, prin urmare, treaba `Drop::drop`.
///
/// ## Examples
///
/// Pentru a vedea distructorii în acțiune, să aruncăm o privire la următorul program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust va apela mai întâi `Drop::drop` pentru `_x` și apoi atât pentru `_x.one`, cât și pentru `_x.two`, ceea ce înseamnă că rularea acestuia va imprima
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Chiar dacă eliminăm implementarea `Drop` pentru `HasTwoDrop`, distructorii câmpurilor sale sunt încă numiți.
/// Acest lucru ar avea ca rezultat
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Nu puteți apela singur `Drop::drop`
///
/// Deoarece `Drop::drop` este utilizat pentru a curăța o valoare, poate fi periculos să utilizați această valoare după ce metoda a fost apelată.
/// Deoarece `Drop::drop` nu își asumă proprietatea asupra intrării sale, Rust previne utilizarea abuzivă, nepermițându-vă să apelați direct `Drop::drop`.
///
/// Cu alte cuvinte, dacă ați încerca să apelați în mod explicit `Drop::drop` în exemplul de mai sus, veți primi o eroare de compilator.
///
/// Dacă doriți să apelați în mod explicit distructorul unei valori, [`mem::drop`] poate fi folosit în schimb.
///
/// [`mem::drop`]: drop
///
/// ## Comandă de renunțare
///
/// Care dintre cele două `HasDrop` noastre scade mai întâi, totuși?Pentru structuri, este aceeași ordine în care sunt declarate: mai întâi `one`, apoi `two`.
/// Dacă doriți să încercați acest lucru singur, puteți modifica `HasDrop` de mai sus pentru a conține unele date, cum ar fi un număr întreg, și apoi utilizați-l în `println!` din `Drop`.
/// Acest comportament este garantat de limbaj.
///
/// Spre deosebire de structuri, variabilele locale sunt abandonate în ordine inversă:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Aceasta se va imprima
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Vă rugăm să consultați [the reference] pentru regulile complete.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` și `Drop` sunt exclusive
///
/// Nu puteți implementa atât [`Copy`], cât și `Drop` pe același tip.Tipurile care sunt `Copy` sunt duplicate implicit de compilator, ceea ce face foarte dificil să se prevadă când și cât de des vor fi executați distructorii.
///
/// Ca atare, aceste tipuri nu pot avea destructori.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Execută distructorul pentru acest tip.
    ///
    /// Această metodă se numește implicit atunci când valoarea iese din domeniul de aplicare și nu poate fi apelată în mod explicit (aceasta este eroarea de compilare [E0040]).
    /// Cu toate acestea, funcția [`mem::drop`] din prelude poate fi utilizată pentru a apela implementarea `Drop` a argumentului.
    ///
    /// Când a fost apelată această metodă, `self` nu a fost încă repartizat.
    /// Asta se întâmplă numai după ce metoda este terminată.
    /// Dacă nu ar fi cazul, `self` ar fi o referință atârnătoare.
    ///
    /// # Panics
    ///
    /// Având în vedere că un [`panic!`] va apela `drop` pe măsură ce se desfășoară, orice [`panic!`] dintr-o implementare `drop` se va întrerupe probabil.
    ///
    /// Rețineți că, chiar dacă acest panics, valoarea este considerată a fi scăzută;
    /// nu trebuie să faceți apelul `drop` din nou.
    /// Acest lucru este în mod normal gestionat automat de compilator, dar când se utilizează cod nesigur, uneori poate apărea neintenționat, în special atunci când se utilizează [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}