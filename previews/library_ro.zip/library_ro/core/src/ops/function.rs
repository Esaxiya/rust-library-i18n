/// Versiunea operatorului de apel care ia un receptor imuabil.
///
/// Instanțele `Fn` pot fi apelate în mod repetat fără starea de mutare.
///
/// *Acest trait (`Fn`) nu trebuie confundat cu [function pointers] (`fn`).*
///
/// `Fn` este implementat automat prin închideri care iau doar referințe imuabile la variabilele capturate sau nu captează nimic deloc, precum și (safe) [function pointers] (cu unele avertismente, consultați documentația lor pentru mai multe detalii).
///
/// În plus, pentru orice tip `F` care implementează `Fn`, `&F` implementează și `Fn`.
///
/// Deoarece atât [`FnMut`], cât și [`FnOnce`] sunt supertraituri ale `Fn`, orice instanță a `Fn` poate fi utilizată ca parametru în care se așteaptă un [`FnMut`] sau [`FnOnce`].
///
/// Utilizați `Fn` ca legat atunci când doriți să acceptați un parametru de tip funcțional și trebuie să-l apelați în mod repetat și fără starea de mutare (de exemplu, când îl apelați simultan).
/// Dacă nu aveți nevoie de astfel de cerințe stricte, utilizați ca limite [`FnMut`] sau [`FnOnce`].
///
/// Consultați [chapter on closures in *The Rust Programming Language*][book] pentru mai multe informații despre acest subiect.
///
/// De asemenea, este de remarcat sintaxa specială pentru `Fn` traits (de ex
/// `Fn(usize, bool) -> folosiți`).Cei interesați de detaliile tehnice ale acestui lucru se pot referi la [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Apelarea unei închideri
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Folosind un parametru `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // astfel încât regex să se poată baza pe acel `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Efectuează operația de apelare.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versiunea operatorului de apel care ia un receptor mutabil.
///
/// Instanțele `FnMut` pot fi apelate în mod repetat și pot muta starea.
///
/// `FnMut` este implementat automat prin închideri care iau referințe mutabile la variabilele capturate, precum și toate tipurile care implementează [`Fn`], de exemplu, (safe) [function pointers] (deoarece `FnMut` este un superretret al lui [`Fn`]).
/// În plus, pentru orice tip `F` care implementează `FnMut`, `&mut F` implementează și `FnMut`.
///
/// Deoarece [`FnOnce`] este o supertraită a lui `FnMut`, orice instanță a lui `FnMut` poate fi utilizată acolo unde se așteaptă un [`FnOnce`] și, din moment ce [`Fn`] este un subretret al lui `FnMut`, orice instanță a lui [`Fn`] poate fi utilizată acolo unde se așteaptă `FnMut`.
///
/// Utilizați `FnMut` ca legat atunci când doriți să acceptați un parametru de tip funcțional și trebuie să-l apelați în mod repetat, permițându-i în același timp să mute starea.
/// Dacă nu doriți ca parametrul să mute starea, utilizați [`Fn`] ca legat;dacă nu trebuie să-l apelați în mod repetat, utilizați [`FnOnce`].
///
/// Consultați [chapter on closures in *The Rust Programming Language*][book] pentru mai multe informații despre acest subiect.
///
/// De asemenea, este de remarcat sintaxa specială pentru `Fn` traits (de ex
/// `Fn(usize, bool) -> folosiți`).Cei interesați de detaliile tehnice ale acestui lucru se pot referi la [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Apelarea unei închideri care capturează mutabil
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Folosind un parametru `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // astfel încât regex să se poată baza pe acel `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Efectuează operația de apelare.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versiunea operatorului de apel care ia un receptor cu valoare secundară.
///
/// Instanțele `FnOnce` pot fi apelate, dar s-ar putea să nu fie apelabile de mai multe ori.Din această cauză, dacă singurul lucru cunoscut despre un tip este că implementează `FnOnce`, acesta poate fi apelat o singură dată.
///
/// `FnOnce` este implementat automat prin închideri care ar putea consuma variabile capturate, precum și toate tipurile care implementează [`FnMut`], de exemplu, (safe) [function pointers] (deoarece `FnOnce` este un superretret al lui [`FnMut`]).
///
///
/// Deoarece atât [`Fn`], cât și [`FnMut`] sunt subtraits ale `FnOnce`, orice instanță de [`Fn`] sau [`FnMut`] poate fi utilizată acolo unde se așteaptă un `FnOnce`.
///
/// Utilizați `FnOnce` ca legat atunci când doriți să acceptați un parametru de tip funcțional și trebuie să-l apelați o singură dată.
/// Dacă trebuie să apelați parametrul în mod repetat, utilizați [`FnMut`] ca legat;dacă aveți nevoie și de acesta pentru a nu muta starea, utilizați [`Fn`].
///
/// Consultați [chapter on closures in *The Rust Programming Language*][book] pentru mai multe informații despre acest subiect.
///
/// De asemenea, este de remarcat sintaxa specială pentru `Fn` traits (de ex
/// `Fn(usize, bool) -> folosiți`).Cei interesați de detaliile tehnice ale acestui lucru se pot referi la [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Folosind un parametru `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` își consumă variabilele capturate, deci nu poate fi rulat de mai multe ori.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Încercarea de a invoca din nou `func()` va genera o eroare `use of moved value` pentru `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` nu mai poate fi invocat în acest moment
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // astfel încât regex să se poată baza pe acel `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Tipul returnat după ce se folosește operatorul de apel.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Efectuează operația de apelare.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}