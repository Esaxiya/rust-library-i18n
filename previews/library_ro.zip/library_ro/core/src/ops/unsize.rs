use crate::marker::Unsize;

/// Trait care indică faptul că acesta este un pointer sau un wrapper pentru unul, unde se poate efectua redimensionarea pe pointee.
///
/// Consultați [DST coercion RFC][dst-coerce] și [the nomicon entry on coercion][nomicon-coerce] pentru mai multe detalii.
///
/// Pentru tipurile de pointer încorporat, pointerele către `T` vor constrânge la pointerele către `U` dacă `T: Unsize<U>` prin conversia dintr-un pointer subțire într-un pointer gras.
///
/// Pentru tipurile personalizate, coerciția de aici funcționează prin constrângerea `Foo<T>` la `Foo<U>`, cu condiția să existe un impl al `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Un astfel de instrument poate fi scris numai dacă `Foo<T>` are doar un singur câmp non-fantomă care implică `T`.
/// Dacă tipul câmpului respectiv este `Bar<T>`, trebuie să existe o implementare a `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Coerciția va funcționa constrângând câmpul `Bar<T>` în `Bar<U>` și completând restul câmpurilor din `Foo<T>` pentru a crea un `Foo<U>`.
/// Acest lucru va conduce efectiv la un câmp de pointer și îl va constrânge.
///
/// În general, pentru indicatoarele inteligente veți implementa `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, cu un `?Sized` opțional legat de `T` în sine.
/// Pentru tipurile de împachetări care încorporează direct `T`, cum ar fi `Cell<T>` și `RefCell<T>`, puteți implementa direct `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Acest lucru va permite coercițiile de tipuri precum `Cell<Box<T>>` să funcționeze.
///
/// [`Unsize`][unsize] este folosit pentru a marca tipuri care pot fi constrânse la DST dacă se află în spatele pointerilor.Este implementat automat de compilator.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Acesta este utilizat pentru siguranța obiectelor, pentru a verifica dacă tipul de receptor al unei metode poate fi expediat.
///
/// Un exemplu de implementare a trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}