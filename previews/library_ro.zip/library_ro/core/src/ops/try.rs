/// Un trait pentru personalizarea comportamentului operatorului `?`.
///
/// Un tip care implementează `Try` este unul care are un mod canonic de a-l vizualiza în termeni de dihotomie success/failure.
/// Acest trait permite atât extragerea acelor valori de succes sau eșec dintr-o instanță existentă, cât și crearea unei noi instanțe dintr-o valoare de succes sau eșec.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Tipul acestei valori atunci când este văzut ca fiind de succes.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Tipul acestei valori atunci când este văzut ca eșuat.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplică operatorul "?".O revenire a lui `Ok(t)` înseamnă că execuția ar trebui să continue în mod normal, iar rezultatul lui `?` este valoarea `t`.
    /// O întoarcere a lui `Err(e)` înseamnă că execuția ar trebui să fie branch la cel mai interior `catch` care o încadrează sau să revină din funcție.
    ///
    /// Dacă se returnează un rezultat `Err(e)`, valoarea `e` va fi "wrapped" în tipul de returnare al domeniului înconjurător (care trebuie să implementeze el însuși `Try`).
    ///
    /// Mai exact, se returnează valoarea `X::from_error(From::from(e))`, unde `X` este tipul returnat al funcției de închidere.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Înfășurați o valoare de eroare pentru a construi rezultatul compozit.
    /// De exemplu, `Result::Err(x)` și `Result::from_error(x)` sunt echivalente.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Înfășurați o valoare OK pentru a construi rezultatul compozit.
    /// De exemplu, `Result::Ok(x)` și `Result::from_ok(x)` sunt echivalente.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}