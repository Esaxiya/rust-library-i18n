#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Conține definiții struct pentru aspectul tipurilor încorporate ale compilatorului.
//!
//! Ele pot fi utilizate ca ținte ale transmutărilor în cod nesigur pentru manipularea directă a reprezentărilor brute.
//!
//!
//! Definiția lor trebuie să se potrivească întotdeauna cu ABI definită în `rustc_middle::ty::layout`.
//!

/// Reprezentarea unui obiect trait ca `&dyn SomeTrait`.
///
/// Această structură are același aspect ca tipurile precum `&dyn SomeTrait` și `Box<dyn AnotherTrait>`.
///
/// `TraitObject` este garantat să se potrivească cu aspectele, dar nu este tipul obiectelor trait (de exemplu, câmpurile nu sunt accesibile direct pe un `&dyn SomeTrait`) și nici nu controlează acel aspect (modificarea definiției nu va schimba aspectul unui `&dyn SomeTrait`).
///
/// Este conceput doar pentru a fi utilizat de coduri nesigure care trebuie să manipuleze detaliile de nivel scăzut.
///
/// Nu există nicio modalitate de a face referire la toate obiectele trait în mod generic, deci singura modalitate de a crea valori de acest tip este cu funcții precum [`std::mem::transmute`][transmute].
/// În mod similar, singura modalitate de a crea un obiect trait adevărat dintr-o valoare `TraitObject` este cu `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetizarea unui obiect trait cu tipuri nepotrivite-unul în care tabelul vtable nu corespunde cu tipul valorii către care indică indicatorul de date-este foarte probabil să ducă la un comportament nedefinit.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // un exemplu trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lăsați compilatorul să facă un obiect trait
/// let object: &dyn Foo = &value;
///
/// // uită-te la reprezentarea brută
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // indicatorul de date este adresa `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // construiește un obiect nou, indicând un alt `i32`, având grijă să folosești tabelul `i32` de la `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ar trebui să funcționeze la fel ca și când am fi construit un obiect trait din `other_value` direct
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}