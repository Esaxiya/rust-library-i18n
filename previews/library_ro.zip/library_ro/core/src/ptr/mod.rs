//! Gestionați manual memoria prin pointeri brut.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Multe funcții din acest modul iau indicii brute ca argumente și le citesc sau le scriu.Pentru ca acest lucru să fie sigur, aceste indicatoare trebuie să fie *valide*.
//! Dacă un indicator este valid depinde de operația pentru care este utilizat (citire sau scriere) și de amploarea memoriei la care se accesează (adică, câte octeți sunt read/written).
//! Majoritatea funcțiilor folosesc `*mut T` și `* const T` pentru a accesa doar o singură valoare, caz în care documentația omite dimensiunea și implicit o presupune a fi `size_of::<T>()` octeți.
//!
//! Regulile precise de validitate nu sunt încă stabilite.Garanțiile oferite în acest moment sunt foarte minime:
//!
//! * Un indicator [null] nu este *niciodată* valid, nici măcar pentru accesările [size zero][zst].
//! * Pentru ca un indicator să fie valid, este necesar, dar nu întotdeauna suficient, ca indicatorul să fie *dereferențial*: intervalul de memorie al dimensiunii date începând de la indicator trebuie să fie toate în limitele unui singur obiect alocat.
//!
//! Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
//! * Chiar și pentru operațiunile [size zero][zst], indicatorul nu trebuie să indice spre memoria alocată, adică, alocarea face ca indicatorii să fie nevalizi chiar și pentru operațiuni de dimensiuni zero.
//! Cu toate acestea, aruncarea unui număr întreg *literal* diferit de zero într-un pointer este valabilă pentru accesele de dimensiuni zero, chiar dacă există o anumită memorie la acea adresă și devine alocată.
//! Acest lucru corespunde scrierii propriului dvs. alocator: alocarea obiectelor de dimensiuni zero nu este foarte grea.
//! Modul canonic de a obține un pointer valid pentru accesări de dimensiuni zero este [`NonNull::dangling`].
//! * Toate accesările efectuate de funcțiile din acest modul sunt *non-atomice* în sensul [atomic operations] utilizat pentru sincronizarea între fire.
//! Aceasta înseamnă că este un comportament nedefinit să efectuați două accesuri simultane la aceeași locație din fire diferite, cu excepția cazului în care ambele accesări citesc doar din memorie.
//! Observați că acest lucru include în mod explicit [`read_volatile`] și [`write_volatile`]: accesele volatile nu pot fi utilizate pentru sincronizarea inter-thread.
//! * Rezultatul trasării unei referințe la un pointer este valabil atât timp cât obiectul subiacent este activ și nu se folosește nicio referință (doar pointeri bruti) pentru a accesa aceeași memorie.
//!
//! Aceste axiome, împreună cu utilizarea atentă a [`offset`] pentru aritmetica indicatorului, sunt suficiente pentru a implementa corect multe lucruri utile în codul nesigur.
//! În cele din urmă, vor fi oferite garanții mai puternice, deoarece sunt stabilite regulile [aliasing].
//! Pentru mai multe informații, consultați [book], precum și secțiunea din referința dedicată [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Pointerii raw valizi definiți mai sus nu sunt neapărat aliniați corect (unde alinierea "proper" este definită de tipul pointee, adică `*const T` trebuie aliniat la `mem::align_of::<T>()`).
//! Cu toate acestea, majoritatea funcțiilor necesită alinierea corectă a argumentelor lor și vor menționa în mod explicit această cerință în documentația lor.
//! Excepții notabile de la aceasta sunt [`read_unaligned`] și [`write_unaligned`].
//!
//! Atunci când o funcție necesită o aliniere adecvată, o face chiar dacă accesul are dimensiunea 0, adică chiar dacă memoria nu este de fapt atinsă.Luați în considerare utilizarea [`NonNull::dangling`] în astfel de cazuri.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Execută distructorul (dacă există) al valorii indicate.
///
/// Acest lucru este semantic echivalent cu apelarea [`ptr::read`] și eliminarea rezultatului, dar are următoarele avantaje:
///
/// * Este *necesar* să utilizați `drop_in_place` pentru a renunța la tipuri nedimensionate, cum ar fi obiecte trait, deoarece acestea nu pot fi citite în stivă și aruncate în mod normal.
///
/// * Este mai prietenos cu optimizatorul să facă acest lucru peste [`ptr::read`] atunci când renunțați la memoria alocată manual (de exemplu, în implementările `Box`/`Rc`/`Vec`), deoarece compilatorul nu trebuie să demonstreze că este bine să eliminați copia.
///
///
/// * Poate fi folosit pentru a renunța la datele [pinned] atunci când `T` nu este `repr(packed)` (datele fixate nu trebuie mutate înainte de a fi abandonate).
///
/// Valorile nealiniate nu pot fi lăsate la loc, ele trebuie copiate mai întâi într-o locație aliniată folosind [`ptr::read_unaligned`].Pentru structurile împachetate, această mutare se face automat de către compilator.
/// Aceasta înseamnă că câmpurile structurilor împachetate nu sunt lăsate în loc.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `to_drop` trebuie să fie [valid] atât pentru citiri, cât și pentru scrieri.
///
/// * `to_drop` trebuie aliniate corect.
///
/// * Valoarea `to_drop` puncte la trebuie să fie valabilă pentru eliminare, ceea ce poate însemna că trebuie să susțină invarianți suplimentari, aceasta depinde de tip.
///
/// În plus, dacă `T` nu este [`Copy`], utilizarea valorii îndreptate către apel după `drop_in_place` poate provoca un comportament nedefinit.Rețineți că `*to_drop = foo` contează ca o utilizare, deoarece va face ca valoarea să fie scăzută din nou.
/// [`write()`] poate fi folosit pentru a suprascrie datele fără a face ca acestea să fie abandonate.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL și aliniat corect.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Eliminați manual ultimul element dintr-un vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Obțineți un indicator brut la ultimul element din `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Scurtați `v` pentru a preveni scăderea ultimului articol.
///     // Facem asta mai întâi, pentru a preveni problemele dacă `drop_in_place` sub panics.
///     v.set_len(1);
///     // Fără un apel `drop_in_place`, ultimul articol nu ar fi renunțat niciodată, iar memoria pe care o gestionează ar fi scursă.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Asigurați-vă că ultimul element a fost eliminat.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Observați că compilatorul efectuează automat această copie atunci când renunțați la structurile împachetate, adică nu trebuie să vă faceți griji cu privire la astfel de probleme decât dacă apelați manual `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Codul de aici nu contează, acesta este înlocuit de lipiciul real de către compilator.
    //

    // SIGURANȚĂ: vezi comentariul de mai sus
    unsafe { drop_in_place(to_drop) }
}

/// Creează un pointer raw raw.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Creează un indicator brut mutabil nul.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Este necesar un instrument manual pentru a evita legarea `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Este necesar un instrument manual pentru a evita legarea `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Formează o felie brută dintr-un pointer și o lungime.
///
/// Argumentul `len` este numărul de **elemente**, nu numărul de octeți.
///
/// Această funcție este sigură, dar utilizarea valorii returnate este nesigură.
/// Consultați documentația [`slice::from_raw_parts`] pentru cerințele de siguranță a feliilor.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // creați un indicator de felie atunci când începeți cu un indicator la primul element
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SIGURANȚĂ: Accesarea valorii din uniunea `Repr` este sigură din moment ce * const [T]
        //
        // și FatPtr au aceleași aspecte de memorie.Doar std poate face această garanție.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Efectuează aceeași funcționalitate ca și [`slice_from_raw_parts`], cu excepția faptului că o felie brută mutabilă este returnată, spre deosebire de o felie brută imuabilă.
///
///
/// Consultați documentația [`slice_from_raw_parts`] pentru mai multe detalii.
///
/// Această funcție este sigură, dar utilizarea valorii returnate este nesigură.
/// Consultați documentația [`slice::from_raw_parts_mut`] pentru cerințele de siguranță a feliilor.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // atribuiți o valoare la un index din felie
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SIGURANȚĂ: Accesarea valorii din uniunea `Repr` este sigură din moment ce * mut [T]
        // și FatPtr au aceleași aspecte de memorie
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Schimbați valorile în două locații mutabile de același tip, fără a deinitializa niciuna.
///
/// Dar pentru următoarele două excepții, această funcție este semantic echivalentă cu [`mem::swap`]:
///
///
/// * Funcționează pe pointeri bruti în loc de referințe.
/// Când sunt disponibile referințe, [`mem::swap`] trebuie preferat.
///
/// * Cele două valori arătate se pot suprapune.
/// Dacă valorile se suprapun, atunci va fi utilizată regiunea de memorie suprapusă de la `x`.
/// Acest lucru este demonstrat în al doilea exemplu de mai jos.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * Atât `x`, cât și `y` trebuie să fie [valid] atât pentru citiri, cât și pentru scrieri.
///
/// * Atât `x`, cât și `y` trebuie aliniate corect.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatoarele trebuie să fie nule și aliniate corect.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Schimbarea a două regiuni care nu se suprapun:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // acesta este `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // acesta este `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Schimbarea a două regiuni suprapuse:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // acesta este `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // acesta este `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indicii `1..3` ai feliei se suprapun între `x` și `y`.
///     // Rezultatele rezonabile ar fi pentru ei să fie `[2, 3]`, astfel încât indicii `0..3` să fie `[1, 2, 3]` (care să corespundă `y` înainte de `swap`);sau pentru ca acestea să fie `[0, 1]`, astfel încât indicii `1..4` să fie `[0, 1, 2]` (potrivind cu `x` înainte de `swap`).
/////
///     // Această implementare este definită pentru a face ultima alegere.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Oferiți-ne un spațiu de zgârieturi pentru a lucra.
    // Nu trebuie să ne facem griji cu privire la picături: `MaybeUninit` nu face nimic atunci când este scăpat.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Efectuați schimbul SIGURANȚĂ: apelantul trebuie să garanteze că `x` și `y` sunt valide pentru scrieri și aliniate corect.
    // `tmp` nu se poate suprapune `x` sau `y` deoarece `tmp` tocmai a fost alocat pe stivă ca obiect separat alocat.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` iar `y` se pot suprapune
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Schimbă octeți `count * size_of::<T>()` între cele două regiuni ale memoriei începând de la `x` și `y`.
/// Cele două regiuni nu trebuie să se suprapună.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * Atât `x`, cât și `y` trebuie să fie [valid] atât pentru citiri, cât și pentru scrieri despre `count *
///   size_of: :<T>() `octeți.
///
/// * Atât `x`, cât și `y` trebuie aliniate corect.
///
/// * Regiunea memoriei care începe de la `x` cu o dimensiune de `count *
///   size_of: :<T>() `octeții *nu* trebuie * să se suprapună cu regiunea memoriei începând de la `y` cu aceeași dimensiune.
///
/// Rețineți că, chiar dacă dimensiunea copiată efectiv (`count * size_of: :<T>()`) este `0`, indicatoarele trebuie să fie nule și aliniate corespunzător.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SIGURANȚĂ: apelantul trebuie să garanteze că `x` și `y` sunt
    // valabil pentru scrieri și aliniat corespunzător.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Pentru tipurile mai mici decât optimizarea blocurilor de mai jos, schimbați direct pentru a evita pesimizarea codegenului.
    //
    if mem::size_of::<T>() < 32 {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `x` și `y` sunt valide
        // pentru scrieri, aliniate corect și fără suprapunere.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Abordarea aici este de a utiliza simd pentru a schimba eficient x&y.
    // Testarea arată că schimbarea fie a 32 de octeți, fie a 64 de octeți la un moment dat este cea mai eficientă pentru procesoarele Intel Haswell E.
    // LLVM este mai capabil să optimizeze dacă acordăm unei structuri un #[repr(simd)], chiar dacă de fapt nu folosim direct această structură.
    //
    //
    // FIXME repr(simd) rupt pe emscripten și redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Buclați prin x&y, copiați-le `Block` odată Optimizatorul ar trebui să deruleze complet bucla pentru majoritatea tipurilor NB
    // Nu putem utiliza o buclă for pentru că `range` impl apelează `mem::swap` recursiv
    //
    let mut i = 0;
    while i + block_size <= len {
        // Creați memorie neinițializată ca spațiu de zgâriere. Declararea `t` aici evită alinierea stivei atunci când această buclă este neutilizată
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SIGURANȚĂ: Ca `i < len` și ca apelant trebuie să garanteze că `x` și `y` sunt valide
        // pentru octeții `len`, `x + i` și `y + i` trebuie să fie adrese valide, ceea ce îndeplinește contractul de siguranță pentru `add`.
        //
        // De asemenea, apelantul trebuie să garanteze că `x` și `y` sunt valide pentru scrieri, aliniate corect și fără suprapunere, ceea ce îndeplinește contractul de siguranță pentru `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Schimbați un bloc de octeți de x&y, folosind t ca tampon temporar Acest lucru ar trebui optimizat în operațiuni SIMD eficiente, acolo unde este disponibil
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Schimbați orice octeți rămași
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SIGURANȚĂ: vezi comentariul de siguranță anterior.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Mută `src` în `dst` ascuțit, returnând valoarea `dst` anterioară.
///
/// Nici o valoare nu este scăzută.
///
/// Această funcție este echivalentă din punct de vedere semantic cu [`mem::replace`], cu excepția faptului că operează pe pointeri raw în loc de referințe.
/// Când sunt disponibile referințe, [`mem::replace`] ar trebui preferat.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `dst` trebuie să fie [valid] atât pentru citiri, cât și pentru scrieri.
///
/// * `dst` trebuie aliniate corect.
///
/// * `dst` trebuie să indice o valoare inițializată corespunzător de tipul `T`.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL și aliniat corect.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ar avea același efect fără a necesita blocul nesigur.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SIGURANȚĂ: apelantul trebuie să garanteze că `dst` este valid
    // aruncat la o referință mutabilă (valabil pentru scrieri, aliniat, inițializat) și nu poate suprapune `src`, deoarece `dst` trebuie să indice un obiect distinct alocat.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nu se poate suprapune
    }
    src
}

/// Citește valoarea din `src` fără a o muta.Aceasta lasă memoria în `src` neschimbată.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `src` trebuie să fie [valid] pentru citiri.
///
/// * `src` trebuie aliniate corect.Utilizați [`read_unaligned`] dacă acest lucru nu este cazul.
///
/// * `src` trebuie să indice o valoare inițializată corespunzător de tipul `T`.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL și aliniat corect.
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementați manual [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Creați o copie pe biți a valorii la `a` în `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ieșirea în acest moment (fie prin întoarcerea explicită, fie prin apelarea unei funcții pe care panics) ar face ca valoarea din `tmp` să fie scăzută în timp ce aceeași valoare este încă menționată de `a`.
///         // Acest lucru ar putea declanșa un comportament nedefinit dacă `T` nu este `Copy`.
/////
/////
///
///         // Creați o copie pe biți a valorii la `b` în `a`.
///         // Acest lucru este sigur, deoarece referințele mutabile nu pot face alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ca mai sus, ieșirea de aici ar putea declanșa un comportament nedefinit, deoarece aceeași valoare este menționată de `a` și `b`.
/////
///
///         // Mutați `tmp` în `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` a fost mutat (`write` își asumă al doilea argument), deci nimic nu este renunțat implicit aici.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Proprietatea asupra valorii returnate
///
/// `read` creează o copie pe biți a `T`, indiferent dacă `T` este [`Copy`].
/// Dacă `T` nu este [`Copy`], utilizarea atât a valorii returnate, cât și a valorii la `*src` poate încălca siguranța memoriei.
/// Rețineți că atribuirea la `*src` este considerată o utilizare, deoarece va încerca să scadă valoarea la `* src`.
///
/// [`write()`] poate fi folosit pentru a suprascrie datele fără a face ca acestea să fie abandonate.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` indică acum aceeași memorie subiacentă ca și `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Atribuirea la `s2` determină scăderea valorii sale inițiale.
///     // Dincolo de acest punct, `s` nu mai trebuie utilizat, deoarece memoria de bază a fost eliberată.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Atribuirea la `s` ar determina renunțarea la vechea valoare, rezultând un comportament nedefinit.
/////
///     // s= String::from("bar");//EROARE
///
///     // `ptr::write` poate fi folosit pentru a suprascrie o valoare fără a o scăpa.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURANȚĂ: apelantul trebuie să garanteze că `src` este valid pentru citiri.
    // `src` nu se poate suprapune `tmp` deoarece `tmp` tocmai a fost alocat pe stivă ca obiect separat alocat.
    //
    //
    // De asemenea, din moment ce tocmai am scris o valoare validă în `tmp`, este garantat că este inițializat corect.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Citește valoarea din `src` fără a o muta.Aceasta lasă memoria în `src` neschimbată.
///
/// Spre deosebire de [`read`], `read_unaligned` funcționează cu pointeri nealiniți.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `src` trebuie să fie [valid] pentru citiri.
///
/// * `src` trebuie să indice o valoare inițializată corespunzător de tipul `T`.
///
/// La fel ca [`read`], `read_unaligned` creează o copie pe biți a `T`, indiferent dacă `T` este [`Copy`].
/// Dacă `T` nu este [`Copy`], folosind atât valoarea returnată, cât și valoarea de la `*src` pot [violate memory safety][read-ownership].
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Pe structurile `packed`
///
/// În prezent, este imposibil să se creeze indicii brute către câmpuri nealiniate ale unei structuri împachetate.
///
/// Încercarea de a crea un indicator brut într-un câmp struct `unaligned` cu o expresie precum `&packed.unaligned as *const FieldType` creează o referință intermediară nealiniată înainte de a o converti într-un indicator brut.
///
/// Faptul că această referință este temporară și aruncată imediat nu este consecventă deoarece compilatorul se așteaptă întotdeauna ca referințele să fie aliniate corect.
/// Ca urmare, utilizarea `&packed.unaligned as *const FieldType` cauzează un comportament imediat* nedefinit * în programul dvs.
///
/// Un exemplu despre ceea ce nu trebuie făcut și despre legătura dintre acesta și `read_unaligned` este:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Aici încercăm să luăm adresa unui număr întreg de 32 de biți care nu este aliniat.
///     let unaligned =
///         // Aici se creează o referință temporară nealiniată care are ca rezultat un comportament nedefinit, indiferent dacă referința este utilizată sau nu.
/////
///         &packed.unaligned
///         // Transmiterea către un indicator brut nu ajută;greșeala s-a întâmplat deja.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Accesarea câmpurilor nealiniate direct cu, de exemplu, `packed.unaligned` este sigură.
///
///
///
///
///
///
// FIXME: Actualizați documentele pe baza rezultatului RFC #2582 și al prietenilor.
/// # Examples
///
/// Citiți o valoare de utilizare dintr-un buffer de octeți:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURANȚĂ: apelantul trebuie să garanteze că `src` este valid pentru citiri.
    // `src` nu se poate suprapune `tmp` deoarece `tmp` tocmai a fost alocat pe stivă ca obiect separat alocat.
    //
    //
    // De asemenea, din moment ce tocmai am scris o valoare validă în `tmp`, este garantat că este inițializat corect.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Suprascrie o locație de memorie cu valoarea dată, fără a citi sau a renunța la vechea valoare.
///
/// `write` nu renunță la conținutul `dst`.
/// Acest lucru este sigur, dar ar putea scurge alocări sau resurse, așa că trebuie să aveți grijă să nu suprascrieți un obiect care ar trebui scăpat.
///
///
/// În plus, nu scade `src`.Semantic, `src` este mutat în locația indicată de `dst`.
///
/// Acest lucru este adecvat pentru inițializarea memoriei neinițializate sau pentru suprascrierea memoriei care a fost anterior [`read`] din.
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `dst` trebuie să fie [valid] pentru scrieri.
///
/// * `dst` trebuie aliniate corect.Utilizați [`write_unaligned`] dacă acest lucru nu este cazul.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL și aliniat corect.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementați manual [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Creați o copie pe biți a valorii la `a` în `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ieșirea în acest moment (fie prin întoarcerea explicită, fie prin apelarea unei funcții pe care panics) ar face ca valoarea din `tmp` să fie scăzută în timp ce aceeași valoare este încă menționată de `a`.
///         // Acest lucru ar putea declanșa un comportament nedefinit dacă `T` nu este `Copy`.
/////
/////
///
///         // Creați o copie pe biți a valorii la `b` în `a`.
///         // Acest lucru este sigur, deoarece referințele mutabile nu pot face alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ca mai sus, ieșirea de aici ar putea declanșa un comportament nedefinit, deoarece aceeași valoare este menționată de `a` și `b`.
/////
///
///         // Mutați `tmp` în `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` a fost mutat (`write` își asumă al doilea argument), deci nimic nu este renunțat implicit aici.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Apelăm direct la intrinseci pentru a evita apelurile de funcții din codul generat, deoarece `intrinsics::copy_nonoverlapping` este o funcție de împachetare.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SIGURANȚĂ: apelantul trebuie să garanteze că `dst` este valid pentru scrieri.
    // `dst` nu poate suprapune `src` deoarece apelantul are acces mutabil la `dst` în timp ce `src` este deținut de această funcție.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Suprascrie o locație de memorie cu valoarea dată, fără a citi sau a renunța la vechea valoare.
///
/// Spre deosebire de [`write()`], indicatorul poate fi nealiniat.
///
/// `write_unaligned` nu renunță la conținutul `dst`.Acest lucru este sigur, dar ar putea scurge alocări sau resurse, așa că trebuie să aveți grijă să nu suprascrieți un obiect care ar trebui scăpat.
///
/// În plus, nu scade `src`.Semantic, `src` este mutat în locația indicată de `dst`.
///
/// Acest lucru este adecvat pentru inițializarea memoriei neinițializate sau pentru suprascrierea memoriei care a fost citită anterior cu [`read_unaligned`].
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `dst` trebuie să fie [valid] pentru scrieri.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL.
///
/// [valid]: self#safety
///
/// ## Pe structurile `packed`
///
/// În prezent, este imposibil să se creeze indicii brute către câmpuri nealiniate ale unei structuri împachetate.
///
/// Încercarea de a crea un indicator brut într-un câmp struct `unaligned` cu o expresie precum `&packed.unaligned as *const FieldType` creează o referință intermediară nealiniată înainte de a o converti într-un indicator brut.
///
/// Faptul că această referință este temporară și aruncată imediat nu este consecventă deoarece compilatorul se așteaptă întotdeauna ca referințele să fie aliniate corect.
/// Ca urmare, utilizarea `&packed.unaligned as *const FieldType` cauzează un comportament imediat* nedefinit * în programul dvs.
///
/// Un exemplu despre ceea ce nu trebuie făcut și despre legătura dintre acesta și `write_unaligned` este:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Aici încercăm să luăm adresa unui număr întreg de 32 de biți care nu este aliniat.
///     let unaligned =
///         // Aici se creează o referință temporară nealiniată care are ca rezultat un comportament nedefinit, indiferent dacă referința este utilizată sau nu.
/////
///         &mut packed.unaligned
///         // Transmiterea către un indicator brut nu ajută;greșeala s-a întâmplat deja.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Accesarea câmpurilor nealiniate direct cu, de exemplu, `packed.unaligned` este sigură.
///
///
///
///
///
///
///
///
///
// FIXME: Actualizați documentele pe baza rezultatului RFC #2582 și al prietenilor.
/// # Examples
///
/// Scrieți o valoare de utilizare într-un tampon de octeți:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SIGURANȚĂ: apelantul trebuie să garanteze că `dst` este valid pentru scrieri.
    // `dst` nu poate suprapune `src` deoarece apelantul are acces mutabil la `dst` în timp ce `src` este deținut de această funcție.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Apelăm direct intrinsecul pentru a evita apelurile funcționale în codul generat.
        intrinsics::forget(src);
    }
}

/// Efectuează o citire volatilă a valorii de la `src` fără a o muta.Aceasta lasă memoria în `src` neschimbată.
///
/// Operațiile volatile sunt destinate să acționeze asupra memoriei I/O și sunt garantate că nu vor fi evitate sau reordonate de către compilator în alte operații volatile.
///
/// # Notes
///
/// Rust nu are în prezent un model de memorie riguros și formal definit, astfel încât semantica precisă a ceea ce înseamnă "volatile" aici poate fi modificată în timp.
/// Acestea fiind spuse, semantica va ajunge aproape întotdeauna destul de asemănătoare cu [C11's definition of volatile][c11].
///
/// Compilatorul nu ar trebui să schimbe ordinea relativă sau numărul de operații de memorie volatile.
/// Cu toate acestea, operațiile de memorie volatile pe tipuri de dimensiuni zero (de exemplu, dacă un tip de dimensiune zero este trecut la `read_volatile`) sunt nopți și pot fi ignorate.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `src` trebuie să fie [valid] pentru citiri.
///
/// * `src` trebuie aliniate corect.
///
/// * `src` trebuie să indice o valoare inițializată corespunzător de tipul `T`.
///
/// La fel ca [`read`], `read_volatile` creează o copie pe biți a `T`, indiferent dacă `T` este [`Copy`].
/// Dacă `T` nu este [`Copy`], folosind atât valoarea returnată, cât și valoarea de la `*src` pot [violate memory safety][read-ownership].
/// Cu toate acestea, stocarea tipurilor non-[" Copiere`] în memoria volatilă este aproape sigur incorectă.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL și aliniat corect.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// La fel ca în C, dacă o operațiune este volatilă nu are nicio influență asupra întrebărilor care implică acces simultan din mai multe fire.Accesele volatile se comportă exact ca accesele non-atomice în această privință.
///
/// În special, o cursă între un `read_volatile` și orice operație de scriere în aceeași locație este un comportament nedefinit.
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Nu intră în panică pentru a menține impactul codegenului mai mic.
        abort();
    }
    // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Efectuează o scriere volatilă a unei locații de memorie cu valoarea dată fără a citi sau a renunța la vechea valoare.
///
/// Operațiile volatile sunt destinate să acționeze asupra memoriei I/O și sunt garantate că nu vor fi evitate sau reordonate de către compilator în alte operații volatile.
///
/// `write_volatile` nu renunță la conținutul `dst`.Acest lucru este sigur, dar ar putea scurge alocări sau resurse, așa că trebuie să aveți grijă să nu suprascrieți un obiect care ar trebui scăpat.
///
/// În plus, nu scade `src`.Semantic, `src` este mutat în locația indicată de `dst`.
///
/// # Notes
///
/// Rust nu are în prezent un model de memorie riguros și formal definit, astfel încât semantica precisă a ceea ce înseamnă "volatile" aici poate fi modificată în timp.
/// Acestea fiind spuse, semantica va ajunge aproape întotdeauna destul de asemănătoare cu [C11's definition of volatile][c11].
///
/// Compilatorul nu ar trebui să schimbe ordinea relativă sau numărul de operații de memorie volatile.
/// Cu toate acestea, operațiile de memorie volatile pe tipuri de dimensiuni zero (de exemplu, dacă un tip de dimensiune zero este trecut la `write_volatile`) sunt nopți și pot fi ignorate.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `dst` trebuie să fie [valid] pentru scrieri.
///
/// * `dst` trebuie aliniate corect.
///
/// Rețineți că, chiar dacă `T` are dimensiunea `0`, indicatorul trebuie să fie non-NULL și aliniat corect.
///
/// [valid]: self#safety
///
/// La fel ca în C, dacă o operațiune este volatilă nu are nicio influență asupra întrebărilor care implică acces simultan din mai multe fire.Accesele volatile se comportă exact ca accesele non-atomice în această privință.
///
/// În special, o cursă între un `write_volatile` și orice altă operațiune (citire sau scriere) în aceeași locație este un comportament nedefinit.
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Nu intră în panică pentru a menține impactul codegenului mai mic.
        abort();
    }
    // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Aliniați indicatorul `p`.
///
/// Calculați decalajul (în termeni de elemente ale pasului `stride`) care trebuie aplicat indicatorului `p`, astfel încât indicatorul `p` să se alinieze la `a`.
///
/// Note: Această implementare a fost atent adaptată pentru a nu fi panic.Este UB pentru asta la panic.
/// Singura schimbare reală care poate fi făcută aici este schimbarea `INV_TABLE_MOD_16` și a constantelor asociate.
///
/// Dacă vom decide vreodată să facem posibilă apelarea intrinsecului cu `a` care nu este o putere de doi, va fi probabil mai prudent să trecem doar la o implementare naivă decât să încercăm să adaptăm acest lucru pentru a se potrivi acelei schimbări.
///
///
/// Orice întrebare merge la@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Utilizarea directă a acestor intrinseci îmbunătățește semnificativ codegenul la nivelul opt <=
    // 1, unde versiunile metodice ale acestor operații nu sunt subliniate.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calculați inversul modular multiplicativ al `x` modul `m`.
    ///
    /// Această implementare este adaptată pentru `align_offset` și are următoarele condiții prealabile:
    ///
    /// * `m` este o putere de doi;
    /// * `x < m`; (dacă `x ≥ m`, introduceți în schimb `x % m`)
    ///
    /// Implementarea acestei funcții nu trebuie să fie panic.Vreodată.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tabel invers invers modular multiplicativ 2ulo=16.
        ///
        /// Rețineți că acest tabel nu conține valori unde inversul nu există (adică pentru `0⁻¹ mod 16`, `2⁻¹ mod 16` etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo pentru care este destinat `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SIGURANȚĂ: `m` trebuie să fie o putere de doi, deci diferită de zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Iterăm "up" folosind următoarea formulă:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // până la 2²ⁿ ≥ m.Apoi putem reduce la `m` dorit luând rezultatul `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Rețineți că folosim aici operații de împachetare intenționat-formula originală folosește, de exemplu, scăderea `mod n`.
                // Este în întregime bine să le faci `mod usize::MAX`, pentru că oricum luăm rezultatul `mod n`.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SIGURANȚĂ: `a` este o putere de doi, deci diferită de zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` cazul poate fi calculat mai simplu prin `-p (mod a)`, dar acest lucru inhibă capacitatea LLVM de a selecta instrucțiuni precum `lea`.În schimb, calculăm
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // care distribuie operațiuni în jurul portantului, dar pesimizând suficient `and` pentru ca LLVM să poată utiliza diferitele optimizări despre care știe.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Deja aliniat.Ura!
        return 0;
    } else if stride == 0 {
        // Dacă indicatorul nu este aliniat și elementul are dimensiunea zero, atunci nicio cantitate de elemente nu va alinia indicatorul vreodată.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SIGURANȚĂ: a este puterea a două, deci non-zero.stride==0 carcasă este tratată mai sus.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SIGURANȚĂ: gcdpow are o limită superioară care este cel mult numărul de biți dintr-o utilizare.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SIGURANȚĂ: gcd este întotdeauna mai mare sau egal cu 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Această branch rezolvă următoarea ecuație de congruență liniară:
        //
        // ` p + so = 0 mod a `
        //
        // `p` aici este valoarea indicatorului, `s`, pasul `T`, `o` offset în `T`s și `a`, alinierea solicitată.
        //
        // Cu `g = gcd(a, s)` și condiția de mai sus care afirmă că `p` este, de asemenea, divizibil cu `g`, putem indica `a' = a/g`, `s' = s/g`, `p' = p/g`, atunci aceasta devine echivalentă cu:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Primul termen este "the relative alignment of `p` to `a`" (împărțit la `g`), al doilea termen este "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (din nou împărțit la `g`).
        //
        // Împărțirea cu `g` este necesară pentru a face inversul bine format dacă `a` și `s` nu sunt coprimi.
        //
        // În plus, rezultatul produs de această soluție nu este "minimal", deci este necesar să luați rezultatul `o mod lcm(s, a)`.Putem înlocui `lcm(s, a)` cu doar un `a'`.
        //
        //
        //
        //
        //

        // SIGURANȚĂ: `gcdpow` are o limită superioară nu mai mare decât numărul de biți 0 din `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SIGURANȚĂ: `a2` este diferit de zero.Schimbarea `a` cu `gcdpow` nu poate schimba niciunul dintre biții setați
        // în `a` (dintre care are exact unul).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SIGURANȚĂ: `gcdpow` are o limită superioară nu mai mare decât numărul de biți 0 din `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SIGURANȚĂ: `gcdpow` are o limită superioară nu mai mare decât numărul de 0-biți în urmă
        // `a`.
        // În plus, scăderea nu poate depăși, deoarece `a2 = a >> gcdpow` va fi întotdeauna strict mai mare decât `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SIGURANȚĂ: `a2` este o putere de doi, așa cum s-a dovedit mai sus.`s2` este strict mai mic decât `a2`
        // deoarece `(s % a) >> gcdpow` este strict mai mic decât `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Nu poate fi deloc aliniat.
    usize::MAX
}

/// Compară indicii brute pentru egalitate.
///
/// Acesta este același lucru cu utilizarea operatorului `==`, dar mai puțin generic:
/// argumentele trebuie să fie `*const T` pointeri brut, nu orice ar implementa `PartialEq`.
///
/// Aceasta poate fi utilizată pentru a compara referințele `&T` (care constrâng implicit la `*const T`) după adresa lor, mai degrabă decât compararea valorilor la care indică (ceea ce face implementarea `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Feliile sunt, de asemenea, comparate prin lungimea lor (indicatori de grăsime):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits sunt, de asemenea, comparate prin implementarea lor:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Indicatorii au adrese egale.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Obiectele au adrese egale, dar `Trait` are implementări diferite.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Conversia referinței la un `*const u8` se compară în funcție de adresă.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash un indicator brut.
///
/// Acest lucru poate fi folosit pentru a hash o referință `&T` (care constrânge la `*const T` implicit) prin adresa sa, mai degrabă decât prin valoarea la care indică (ceea ce face implementarea `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Instrucțiuni pentru indicatorii de funcții
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Distribuirea intermediară ca utilizare este necesară pentru AVR
                // astfel încât spațiul de adresă al indicatorului funcției sursă să fie păstrat în indicatorul funcției finale.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Distribuirea intermediară ca utilizare este necesară pentru AVR
                // astfel încât spațiul de adresă al indicatorului funcției sursă să fie păstrat în indicatorul funcției finale.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Nu există funcții variadice cu 0 parametri
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Creați un pointer brut `const` într-un loc, fără a crea o referință intermediară.
///
/// Crearea unei referințe cu `&`/`&mut` este permisă numai dacă indicatorul este corect aliniat și indică datele inițializate.
/// Pentru cazurile în care aceste cerințe nu sunt valabile, ar trebui să se folosească în schimb indicii brute.
/// Cu toate acestea, `&expr as *const _` creează o referință înainte de a o arunca într-un pointer brut și această referință este supusă acelorași reguli ca toate celelalte referințe.
///
/// Această macrocomandă poate crea un pointer brut *fără a* crea mai întâi o referință.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` ar crea o referință nealiniată și astfel ar fi un Comportament nedefinit!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Creați un pointer brut `mut` într-un loc, fără a crea o referință intermediară.
///
/// Crearea unei referințe cu `&`/`&mut` este permisă numai dacă indicatorul este corect aliniat și indică datele inițializate.
/// Pentru cazurile în care aceste cerințe nu sunt valabile, ar trebui să se folosească în schimb indicii brute.
/// Cu toate acestea, `&mut expr as *mut _` creează o referință înainte de a o arunca într-un pointer brut și această referință este supusă acelorași reguli ca toate celelalte referințe.
///
/// Această macrocomandă poate crea un pointer brut *fără a* crea mai întâi o referință.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` ar crea o referință nealiniată și astfel ar fi un Comportament nedefinit!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` forțează să copieze câmpul în loc să creeze o referință.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}