use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Returnează `true` dacă indicatorul este nul.
    ///
    /// Rețineți că tipurile nedimensionate au numeroși indicatori nuli posibili, deoarece se ia în considerare doar indicatorul de date brute, nu lungimea lor, tabelul etc.
    /// Prin urmare, două indicatoare care sunt nule s-ar putea să nu fie încă egale între ele.
    ///
    /// ## Comportament în timpul evaluării const
    ///
    /// Când această funcție este utilizată în timpul evaluării const, aceasta poate returna `false` pentru pointerii care se dovedesc a fi nuli în timpul rulării.
    /// Mai exact, atunci când un indicator către o anumită memorie este decalat dincolo de limitele sale, astfel încât indicatorul rezultat să fie nul, funcția va întoarce în continuare `false`.
    ///
    /// Nu există nicio modalitate prin care CTFE să cunoască poziția absolută a memoriei respective, așa că nu putem spune dacă indicatorul este nul sau nu.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Comparați printr-o distribuție cu un indicator subțire, astfel încât indicatorii grași iau în considerare partea lor "data" doar pentru nulitate.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Distribuie la un pointer de alt tip.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Descompuneți un pointer (posibil larg) în componentele de adresă și metadate.
    ///
    /// Pointerul poate fi ulterior reconstruit cu [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Returnează `None` dacă indicatorul este nul sau altfel returnează o referință partajată la valoarea înfășurată în `Some`.Dacă valoarea poate fi neinițializată, trebuie utilizat în schimb [`as_uninit_ref`].
    ///
    /// Pentru omologul mutabil, a se vedea [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că *fie* pointerul este NULL *, fie că* toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Pointerul trebuie să indice o instanță inițializată de `T`.
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///   În special, pe durata acestei vieți, memoria spre care indică indicatorul nu trebuie mutată (cu excepția `UnsafeCell`).
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    /// (Partea despre inițializare nu este încă pe deplin hotărâtă, dar până la finalizarea acesteia, singura abordare sigură este asigurarea faptului că acestea sunt într-adevăr inițializate.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versiune nulă nebifată
    ///
    /// Dacă sunteți sigur că indicatorul nu poate fi niciodată nul și căutați un fel de `as_ref_unchecked` care returnează `&T` în loc de `Option<&T>`, știți că puteți dereca direct pointerul.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` este valid pentru un
        // referință dacă nu este nulă.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Returnează `None` dacă indicatorul este nul sau altfel returnează o referință partajată la valoarea înfășurată în `Some`.
    /// Spre deosebire de [`as_ref`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul mutabil, a se vedea [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că *fie* pointerul este NULL *, fie că* toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///
    ///   În special, pe durata acestei vieți, memoria spre care indică indicatorul nu trebuie mutată (cu excepția `UnsafeCell`).
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calculează decalajul de la un pointer.
    ///
    /// `count` este în unități de T;de exemplu, un `count` de 3 reprezintă un offset de pointer de octeți `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Dacă se încalcă oricare dintre următoarele condiții, rezultatul este Comportament nedefinit:
    ///
    /// * Atât indicatorul inițial, cât și cel rezultat trebuie să fie fie în limite, fie cu un octet peste sfârșitul aceluiași obiect alocat.
    /// Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
    ///
    /// * Compensarea calculată,**în octeți**, nu poate depăși un `isize`.
    ///
    /// * Decalajul fiind în limite nu se poate baza pe "wrapping around" spațiul de adrese.Adică suma cu precizie infinită,**în octeți**, trebuie să se încadreze într-o utilizare.
    ///
    /// Compilatorul și biblioteca standard încearcă, în general, să se asigure că alocările nu ating niciodată o dimensiune în care un offset este o problemă.
    /// De exemplu, `Vec` și `Box` se asigură că nu alocă niciodată mai mult de `isize::MAX` octeți, astfel încât `vec.as_ptr().add(vec.len())` este întotdeauna sigur.
    ///
    /// Majoritatea platformelor nu pot construi o astfel de alocare.
    /// De exemplu, nicio platformă cunoscută pe 64 de biți nu poate furniza vreodată o cerere pentru 2 <sup>63 de</sup> octeți din cauza limitărilor tabelului de pagini sau împărțirii spațiului de adrese.
    /// Cu toate acestea, unele platforme pe 32 de biți și pe 16 biți pot furniza cu succes o solicitare pentru mai mult de `isize::MAX` octeți cu lucruri precum Extensia de adresă fizică
    ///
    /// Ca atare, memoria dobândită direct de la alocatoare sau fișierele mapate de memorie *poate* să fie prea mare pentru a fi tratată cu această funcție.
    ///
    /// Luați în considerare utilizarea [`wrapping_offset`] în loc dacă aceste constrângeri sunt greu de satisfăcut.
    /// Singurul avantaj al acestei metode este că permite optimizări mai agresive ale compilatorului.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `offset`.
        // Pointerul obținut este valid pentru scrieri, deoarece apelantul trebuie să garanteze că indică același obiect alocat ca `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Calculează decalajul de la un pointer folosind aritmetica de împachetare.
    /// `count` este în unități de T;de exemplu, un `count` de 3 reprezintă un offset de pointer de octeți `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Această operație în sine este întotdeauna sigură, dar utilizarea indicatorului rezultat nu este.
    ///
    /// Pointerul rezultat rămâne atașat la același obiect alocat către care indică `self`.
    /// Poate *nu* fi folosit pentru a accesa un alt obiect alocat.Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
    ///
    /// Cu alte cuvinte, `let z = x.wrapping_offset((y as isize) - (x as isize))`*nu* face ca `z` să fie la fel ca `y`, chiar dacă presupunem că `T` are dimensiunea `1` și nu există o revărsare: `z` este încă atașat la obiectul `x` este atașat și dereferențierea este Comportament nedefinit, cu excepția cazului în care `x` și `y` punct în același obiect alocat.
    ///
    /// Comparativ cu [`offset`], această metodă întârzie în esență cerința de a rămâne în același obiect alocat: [`offset`] este un Comportament Nedefinit imediat la trecerea limitelor obiectului;`wrapping_offset` produce un pointer, dar duce în continuare la Comportament nedefinit dacă un pointer este dereferențiat atunci când este în afara limitelor obiectului la care este atașat.
    /// [`offset`] poate fi optimizat mai bine și este astfel preferabil în codul sensibil la performanță.
    ///
    /// Verificarea întârziată are în vedere numai valoarea indicatorului care a fost dereferențiat, nu valorile intermediare utilizate în timpul calculului rezultatului final.
    /// De exemplu, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` este întotdeauna același cu `x`.Cu alte cuvinte, este permisă părăsirea obiectului alocat și reintroducerea acestuia ulterior.
    ///
    /// Dacă trebuie să treceți limitele obiectelor, aruncați indicatorul într-un număr întreg și efectuați aritmetica acolo.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // Iterează folosind un indicator brut în trepte de două elemente
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SIGURANȚĂ: intrinsecul `arith_offset` nu are condiții prealabile pentru a fi apelat.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Returnează `None` dacă indicatorul este nul sau altfel returnează o referință unică la valoarea înfășurată în `Some`.Dacă valoarea poate fi neinițializată, trebuie utilizat în schimb [`as_uninit_mut`].
    ///
    /// Pentru omologul partajat vezi [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că *fie* pointerul este NULL *, fie că* toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Pointerul trebuie să indice o instanță inițializată de `T`.
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///   În special, pe durata acestei vieți, memoria către care indică indicatorul nu trebuie accesată (citită sau scrisă) prin niciun alt indicator.
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    /// (Partea despre inițializare nu este încă pe deplin hotărâtă, dar până la finalizarea acesteia, singura abordare sigură este asigurarea faptului că acestea sunt într-adevăr inițializate.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Se va imprima: "[4, 2, 3]".
    /// ```
    ///
    /// # Versiune nulă nebifată
    ///
    /// Dacă sunteți sigur că indicatorul nu poate fi niciodată nul și căutați un fel de `as_mut_unchecked` care returnează `&mut T` în loc de `Option<&mut T>`, știți că puteți dereca direct pointerul.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Se va imprima: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` este valabil pentru
        // o referință mutabilă dacă nu este nulă.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Returnează `None` dacă indicatorul este nul sau altfel returnează o referință unică la valoarea înfășurată în `Some`.
    /// Spre deosebire de [`as_mut`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul partajat vezi [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că *fie* pointerul este NULL *, fie că* toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///
    ///   În special, pe durata acestei vieți, memoria către care indică indicatorul nu trebuie accesată (citită sau scrisă) prin niciun alt indicator.
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Returnează dacă este garantat că doi indicatori sunt egali.
    ///
    /// În timpul rulării, această funcție se comportă ca `self == other`.
    /// Cu toate acestea, în unele contexte (de exemplu, evaluarea timpului de compilare), nu este întotdeauna posibil să se determine egalitatea a doi pointeri, astfel încât această funcție poate întoarce fals `false` pentru pointerii care ulterior se dovedesc a fi egali.
    ///
    /// Dar când returnează `true`, indicatoarele sunt garantate să fie egale.
    ///
    /// Această funcție este oglinda [`guaranteed_ne`], dar nu inversă.Există comparații de pointer pentru care ambele funcții returnează `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Valoarea returnată se poate modifica în funcție de versiunea compilatorului, iar codul nesigur poate să nu se bazeze pe rezultatul acestei funcții pentru soliditate.
    /// Este sugerat să utilizați această funcție numai pentru optimizări de performanță în cazul în care valorile de returnare false `false` de această funcție nu afectează rezultatul, ci doar performanța.
    /// Consecințele utilizării acestei metode pentru a face ca timpul de execuție și codul de compilare să se comporte diferit nu au fost explorate.
    /// Această metodă nu ar trebui utilizată pentru a introduce astfel de diferențe și, de asemenea, nu ar trebui stabilizată înainte de a înțelege mai bine această problemă.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Returnează dacă se garantează că două indicii sunt inegale.
    ///
    /// În timpul rulării, această funcție se comportă ca `self != other`.
    /// Cu toate acestea, în unele contexte (de exemplu, evaluarea timpului de compilare), nu este întotdeauna posibil să se determine inegalitatea a doi indicatori, astfel încât această funcție poate returna `false` în mod fals pentru indicatorii care ulterior se dovedesc a fi inegali.
    ///
    /// Dar când returnează `true`, indicatoarele sunt garantate să fie inegale.
    ///
    /// Această funcție este oglinda [`guaranteed_eq`], dar nu inversă.Există comparații de pointer pentru care ambele funcții returnează `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Valoarea returnată se poate modifica în funcție de versiunea compilatorului, iar codul nesigur poate să nu se bazeze pe rezultatul acestei funcții pentru soliditate.
    /// Este sugerat să utilizați această funcție numai pentru optimizări de performanță în cazul în care valorile de returnare false `false` de această funcție nu afectează rezultatul, ci doar performanța.
    /// Consecințele utilizării acestei metode pentru a face ca timpul de execuție și codul de compilare să se comporte diferit nu au fost explorate.
    /// Această metodă nu ar trebui utilizată pentru a introduce astfel de diferențe și, de asemenea, nu ar trebui stabilizată înainte de a înțelege mai bine această problemă.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Calculează distanța dintre doi indicatori.Valoarea returnată este în unități de T: distanța în octeți este împărțită la `mem::size_of::<T>()`.
    ///
    /// Această funcție este inversa [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Dacă se încalcă oricare dintre următoarele condiții, rezultatul este Comportament nedefinit:
    ///
    /// * Atât indicatorul inițial, cât și celălalt trebuie să fie fie în limite, fie cu un octet peste sfârșitul aceluiași obiect alocat.
    /// Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
    ///
    /// * Ambele indicatoare trebuie să fie *derivate din* un pointer către același obiect.
    ///   (A se vedea mai jos un exemplu.)
    ///
    /// * Distanța dintre pointeri, în octeți, trebuie să fie un multiplu exact al dimensiunii `T`.
    ///
    /// * Distanța dintre indicatoare,**în octeți**, nu poate depăși un `isize`.
    ///
    /// * Distanța fiind în limite nu se poate baza pe "wrapping around" spațiul de adrese.
    ///
    /// Tipurile Rust nu sunt niciodată mai mari decât alocările `isize::MAX` și Rust nu se înfășoară niciodată în jurul spațiului de adresă, astfel încât doi indicatori cu o anumită valoare a oricărui tip Rust de tip `T` vor îndeplini întotdeauna ultimele două condiții.
    ///
    /// Biblioteca standard asigură, de asemenea, că alocările nu ating niciodată o dimensiune în care un offset este o problemă.
    /// De exemplu, `Vec` și `Box` se asigură că nu alocă niciodată mai mult de `isize::MAX` octeți, astfel încât `ptr_into_vec.offset_from(vec.as_ptr())` îndeplinește întotdeauna ultimele două condiții.
    ///
    /// Majoritatea platformelor nu pot construi o alocare atât de mare.
    /// De exemplu, nicio platformă cunoscută pe 64 de biți nu poate furniza vreodată o cerere pentru 2 <sup>63 de</sup> octeți din cauza limitărilor tabelului de pagini sau împărțirii spațiului de adrese.
    /// Cu toate acestea, unele platforme pe 32 de biți și pe 16 biți pot furniza cu succes o solicitare pentru mai mult de `isize::MAX` octeți cu lucruri precum Extensia de adresă fizică
    /// Ca atare, memoria dobândită direct de la alocatoare sau fișierele mapate de memorie *poate* să fie prea mare pentru a fi tratată cu această funcție.
    /// (Rețineți că [`offset`] și [`add`] au, de asemenea, o limitare similară și, prin urmare, nu pot fi utilizate nici la alocări atât de mari.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Această funcție panics dacă `T` este un tip ("ZST") de dimensiuni zero.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Utilizare incorectă*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Faceți ptr2_other un "alias" din ptr2, dar derivat din ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Deoarece ptr2_other și ptr2 sunt derivate din pointeri către obiecte diferite, calculul decalării lor este un comportament nedefinit, chiar dacă indică aceeași adresă!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportament nedefinit
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Calculează decalajul de la un indicator (comoditate pentru `.offset(count as isize)`).
    ///
    /// `count` este în unități de T;de exemplu, un `count` de 3 reprezintă un offset de pointer de octeți `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Dacă se încalcă oricare dintre următoarele condiții, rezultatul este Comportament nedefinit:
    ///
    /// * Atât indicatorul inițial, cât și cel rezultat trebuie să fie fie în limite, fie cu un octet peste sfârșitul aceluiași obiect alocat.
    /// Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
    ///
    /// * Compensarea calculată,**în octeți**, nu poate depăși un `isize`.
    ///
    /// * Decalajul fiind în limite nu se poate baza pe "wrapping around" spațiul de adrese.Adică, suma cu precizie infinită trebuie să se potrivească într-un `usize`.
    ///
    /// Compilatorul și biblioteca standard încearcă, în general, să se asigure că alocările nu ating niciodată o dimensiune în care un offset este o problemă.
    /// De exemplu, `Vec` și `Box` se asigură că nu alocă niciodată mai mult de `isize::MAX` octeți, astfel încât `vec.as_ptr().add(vec.len())` este întotdeauna sigur.
    ///
    /// Majoritatea platformelor nu pot construi o astfel de alocare.
    /// De exemplu, nicio platformă cunoscută pe 64 de biți nu poate furniza vreodată o cerere pentru 2 <sup>63 de</sup> octeți din cauza limitărilor tabelului de pagini sau împărțirii spațiului de adrese.
    /// Cu toate acestea, unele platforme pe 32 de biți și pe 16 biți pot furniza cu succes o solicitare pentru mai mult de `isize::MAX` octeți cu lucruri precum Extensia de adresă fizică
    ///
    /// Ca atare, memoria dobândită direct de la alocatoare sau fișierele mapate de memorie *poate* să fie prea mare pentru a fi tratată cu această funcție.
    ///
    /// Luați în considerare utilizarea [`wrapping_add`] în loc dacă aceste constrângeri sunt greu de satisfăcut.
    /// Singurul avantaj al acestei metode este că permite optimizări mai agresive ale compilatorului.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calculează decalajul de la un pointer (comoditate pentru `.offset ((se numără isize).wrapping_neg())`).
    ///
    /// `count` este în unități de T;de exemplu, un `count` de 3 reprezintă un offset de pointer de octeți `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Dacă se încalcă oricare dintre următoarele condiții, rezultatul este Comportament nedefinit:
    ///
    /// * Atât indicatorul inițial, cât și cel rezultat trebuie să fie fie în limite, fie cu un octet peste sfârșitul aceluiași obiect alocat.
    /// Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
    ///
    /// * Decalajul calculat nu poate depăși `isize::MAX`**octeți**.
    ///
    /// * Decalajul fiind în limite nu se poate baza pe "wrapping around" spațiul de adrese.Adică suma de precizie infinită trebuie să se încadreze într-o utilizare.
    ///
    /// Compilatorul și biblioteca standard încearcă, în general, să se asigure că alocările nu ating niciodată o dimensiune în care un offset este o problemă.
    /// De exemplu, `Vec` și `Box` se asigură că nu alocă niciodată mai mult de `isize::MAX` octeți, astfel încât `vec.as_ptr().add(vec.len()).sub(vec.len())` este întotdeauna sigur.
    ///
    /// Majoritatea platformelor nu pot construi o astfel de alocare.
    /// De exemplu, nicio platformă cunoscută pe 64 de biți nu poate furniza vreodată o cerere pentru 2 <sup>63 de</sup> octeți din cauza limitărilor tabelului de pagini sau împărțirii spațiului de adrese.
    /// Cu toate acestea, unele platforme pe 32 de biți și pe 16 biți pot furniza cu succes o solicitare pentru mai mult de `isize::MAX` octeți cu lucruri precum Extensia de adresă fizică
    ///
    /// Ca atare, memoria dobândită direct de la alocatoare sau fișierele mapate de memorie *poate* să fie prea mare pentru a fi tratată cu această funcție.
    ///
    /// Luați în considerare utilizarea [`wrapping_sub`] în loc dacă aceste constrângeri sunt greu de satisfăcut.
    /// Singurul avantaj al acestei metode este că permite optimizări mai agresive ale compilatorului.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calculează decalajul de la un pointer folosind aritmetica de împachetare.
    /// (comoditate pentru `.wrapping_offset(count as isize)`)
    ///
    /// `count` este în unități de T;de exemplu, un `count` de 3 reprezintă un offset de pointer de octeți `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Această operație în sine este întotdeauna sigură, dar utilizarea indicatorului rezultat nu este.
    ///
    /// Pointerul rezultat rămâne atașat la același obiect alocat către care indică `self`.
    /// Poate *nu* fi folosit pentru a accesa un alt obiect alocat.Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
    ///
    /// Cu alte cuvinte, `let z = x.wrapping_add((y as usize) - (x as usize))`*nu* face ca `z` să fie la fel ca `y`, chiar dacă presupunem că `T` are dimensiunea `1` și nu există o revărsare: `z` este încă atașat la obiectul `x` este atașat și dereferențierea este Comportament nedefinit, cu excepția cazului în care `x` și `y` punct în același obiect alocat.
    ///
    /// Comparativ cu [`add`], această metodă întârzie în esență cerința de a rămâne în același obiect alocat: [`add`] este un Comportament Nedefinit imediat la trecerea limitelor obiectului;`wrapping_add` produce un pointer, dar duce în continuare la Comportament nedefinit dacă un pointer este dereferențiat atunci când este în afara limitelor obiectului la care este atașat.
    /// [`add`] poate fi optimizat mai bine și este astfel preferabil în codul sensibil la performanță.
    ///
    /// Verificarea întârziată are în vedere numai valoarea indicatorului care a fost dereferențiat, nu valorile intermediare utilizate în timpul calculului rezultatului final.
    /// De exemplu, `x.wrapping_add(o).wrapping_sub(o)` este întotdeauna același cu `x`.Cu alte cuvinte, este permisă părăsirea obiectului alocat și reintroducerea acestuia ulterior.
    ///
    /// Dacă trebuie să treceți limitele obiectelor, aruncați indicatorul într-un număr întreg și efectuați aritmetica acolo.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // Iterează folosind un indicator brut în trepte de două elemente
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Această buclă imprimă "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calculează decalajul de la un pointer folosind aritmetica de împachetare.
    /// (comoditate pentru `.wrapping_offset ((se numără isize).wrapping_neg())`)
    ///
    /// `count` este în unități de T;de exemplu, un `count` de 3 reprezintă un offset de pointer de octeți `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Această operație în sine este întotdeauna sigură, dar utilizarea indicatorului rezultat nu este.
    ///
    /// Pointerul rezultat rămâne atașat la același obiect alocat către care indică `self`.
    /// Poate *nu* fi folosit pentru a accesa un alt obiect alocat.Rețineți că în Rust, fiecare variabilă (stack-allocated) este considerată un obiect alocat separat.
    ///
    /// Cu alte cuvinte, `let z = x.wrapping_sub((x as usize) - (y as usize))`*nu* face ca `z` să fie la fel ca `y`, chiar dacă presupunem că `T` are dimensiunea `1` și nu există o revărsare: `z` este încă atașat la obiectul `x` este atașat și dereferențierea este Comportament nedefinit, cu excepția cazului în care `x` și `y` punct în același obiect alocat.
    ///
    /// Comparativ cu [`sub`], această metodă întârzie în esență cerința de a rămâne în același obiect alocat: [`sub`] este un Comportament Nedefinit imediat la trecerea limitelor obiectului;`wrapping_sub` produce un pointer, dar duce în continuare la Comportament nedefinit dacă un pointer este dereferențiat atunci când este în afara limitelor obiectului la care este atașat.
    /// [`sub`] poate fi optimizat mai bine și este astfel preferabil în codul sensibil la performanță.
    ///
    /// Verificarea întârziată are în vedere numai valoarea indicatorului care a fost dereferențiat, nu valorile intermediare utilizate în timpul calculului rezultatului final.
    /// De exemplu, `x.wrapping_add(o).wrapping_sub(o)` este întotdeauna același cu `x`.Cu alte cuvinte, este permisă părăsirea obiectului alocat și reintroducerea acestuia ulterior.
    ///
    /// Dacă trebuie să treceți limitele obiectelor, aruncați indicatorul într-un număr întreg și efectuați aritmetica acolo.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // Iterează folosind un indicator brut în trepte de două elemente (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Această buclă imprimă "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Setează valoarea indicatorului la `ptr`.
    ///
    /// În cazul în care `self` este un pointer (fat) către un tip nedimensionat, această operațiune va afecta doar partea pointer, în timp ce pentru pointerii (thin) la tipuri de dimensiuni, acesta are același efect ca o simplă atribuire.
    ///
    /// Pointerul rezultat va avea proveniența `val`, adică pentru un pointer fat, această operație este semantic aceeași cu crearea unui nou pointer fat cu valoarea indicatorului de date `val`, dar metadatele `self`.
    ///
    ///
    /// # Examples
    ///
    /// Această funcție este utilă în primul rând pentru a permite aritmetica indicatorului de octet pe indicii cu potențial de grăsime:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // va imprima "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SIGURANȚĂ: În cazul unui indicator subțire, această operațiune este identică
        // la o sarcină simplă.
        // În cazul unui indicator de grăsime, cu implementarea actuală a aspectului indicatorului de grăsime, primul câmp al unui astfel de indicator este întotdeauna indicatorul de date, care este, de asemenea, atribuit.
        //
        unsafe { *thin = val };
        self
    }

    /// Citește valoarea din `self` fără a o muta.
    /// Acest lucru lasă memoria în `self` neschimbată.
    ///
    /// Consultați [`ptr::read`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru ``.
        unsafe { read(self) }
    }

    /// Efectuează o citire volatilă a valorii de la `self` fără a o muta.Aceasta lasă memoria în `self` neschimbată.
    ///
    /// Operațiile volatile sunt destinate să acționeze asupra memoriei I/O și sunt garantate că nu vor fi evitate sau reordonate de către compilator în alte operații volatile.
    ///
    ///
    /// Consultați [`ptr::read_volatile`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Citește valoarea din `self` fără a o muta.
    /// Acest lucru lasă memoria în `self` neschimbată.
    ///
    /// Spre deosebire de `read`, indicatorul poate fi nealiniat.
    ///
    /// Consultați [`ptr::read_unaligned`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copiază octeți `count * size_of<T>` de la `self` la `dest`.
    /// Sursa și destinația se pot suprapune.
    ///
    /// NOTE: acesta are același ordin de argument * ca și [`ptr::copy`].
    ///
    /// Consultați [`ptr::copy`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copiază octeți `count * size_of<T>` de la `self` la `dest`.
    /// Sursa și destinația se pot *nu* suprapune.
    ///
    /// NOTE: acesta are același ordin de argument * ca și [`ptr::copy_nonoverlapping`].
    ///
    /// Consultați [`ptr::copy_nonoverlapping`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Copiază octeți `count * size_of<T>` de la `src` la `self`.
    /// Sursa și destinația se pot suprapune.
    ///
    /// NOTE: aceasta are ordinea argumentelor *opuse* de [`ptr::copy`].
    ///
    /// Consultați [`ptr::copy`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Copiază octeți `count * size_of<T>` de la `src` la `self`.
    /// Sursa și destinația se pot *nu* suprapune.
    ///
    /// NOTE: aceasta are ordinea argumentelor *opuse* de [`ptr::copy_nonoverlapping`].
    ///
    /// Consultați [`ptr::copy_nonoverlapping`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Execută distructorul (dacă există) al valorii indicate.
    ///
    /// Consultați [`ptr::drop_in_place`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Suprascrie o locație de memorie cu valoarea dată, fără a citi sau a renunța la vechea valoare.
    ///
    ///
    /// Consultați [`ptr::write`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `write`.
        unsafe { write(self, val) }
    }

    /// Invocă memset pe indicatorul specificat, setând `count * size_of::<T>()` octeți de memorie începând de la `self` la `val`.
    ///
    ///
    /// Consultați [`ptr::write_bytes`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Efectuează o scriere volatilă a unei locații de memorie cu valoarea dată fără a citi sau a renunța la vechea valoare.
    ///
    /// Operațiile volatile sunt destinate să acționeze asupra memoriei I/O și sunt garantate că nu vor fi evitate sau reordonate de către compilator în alte operații volatile.
    ///
    ///
    /// Consultați [`ptr::write_volatile`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Suprascrie o locație de memorie cu valoarea dată, fără a citi sau a renunța la vechea valoare.
    ///
    ///
    /// Spre deosebire de `write`, indicatorul poate fi nealiniat.
    ///
    /// Consultați [`ptr::write_unaligned`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Înlocuiește valoarea la `self` cu `src`, returnând valoarea veche, fără a scăpa niciuna.
    ///
    ///
    /// Consultați [`ptr::replace`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `replace`.
        unsafe { replace(self, src) }
    }

    /// Schimbați valorile în două locații mutabile de același tip, fără a deinitializa niciuna.
    /// Se pot suprapune, spre deosebire de `mem::swap`, care altfel este echivalent.
    ///
    /// Consultați [`ptr::swap`] pentru probleme și exemple de siguranță.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `swap`.
        unsafe { swap(self, with) }
    }

    /// Calculează decalajul care trebuie aplicat indicatorului pentru al alinia la `align`.
    ///
    /// Dacă nu este posibil să aliniați indicatorul, implementarea returnează `usize::MAX`.
    /// Este permis ca implementarea să returneze *întotdeauna*`usize::MAX`.
    /// Doar performanța algoritmului dvs. poate depinde de obținerea unui offset utilizabil aici, nu de corectitudinea acestuia.
    ///
    /// Decalajul este exprimat în număr de elemente `T` și nu în octeți.Valoarea returnată poate fi utilizată cu metoda `wrapping_add`.
    ///
    /// Nu există nicio garanție că compensarea indicatorului nu va depăși sau va depăși alocarea în care indică indicatorul.
    ///
    /// Depinde de apelant să se asigure că decalajul returnat este corect în toți termenii, cu excepția alinierii.
    ///
    /// # Panics
    ///
    /// Funcția panics dacă `align` nu este o putere de doi.
    ///
    /// # Examples
    ///
    /// Accesarea `u8` adiacentă ca `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // în timp ce indicatorul poate fi aliniat prin `offset`, acesta ar indica în afara alocării
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SIGURANȚĂ: `align` a fost verificat pentru a avea o putere de 2 de mai sus
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Returnează lungimea unei felii brute.
    ///
    /// Valoarea returnată este numărul de **elemente**, nu numărul de octeți.
    ///
    /// Această funcție este sigură, chiar și atunci când felia brută nu poate fi aruncată într-o referință felie, deoarece indicatorul este nul sau nealiniat.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIGURANȚĂ: acest lucru este sigur deoarece `*const [T]` și `FatPtr<T>` au același aspect.
            // Doar `std` poate face această garanție.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Returnează un indicator brut în bufferul feliei.
    ///
    /// Acest lucru este echivalent cu turnarea `self` la `*mut T`, dar mai sigur de tip.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Returnează un pointer brut la un element sau subsecțiune, fără a face verificarea limitelor.
    ///
    /// Apelarea acestei metode cu un index în afara limitelor sau când `self` nu este dereferențial este *[comportament nedefinit]*, chiar dacă indicatorul rezultat nu este utilizat.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SIGURANȚĂ: apelantul se asigură că `self` este dereferențial și `index` este limitat.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Returnează `None` dacă indicatorul este nul sau altfel returnează o felie partajată la valoarea înfășurată în `Some`.
    /// Spre deosebire de [`as_ref`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul mutabil, a se vedea [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că *fie* pointerul este NULL *, fie că* toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie să fie [valid] pentru citiri pentru `ptr.len() * mem::size_of::<T>()` mulți octeți și trebuie să fie aliniat corect.Aceasta înseamnă în special:
    ///
    ///     * Întreaga gamă de memorie a acestei felii trebuie să fie conținută într-un singur obiect alocat!
    ///       Feliile nu se pot întinde niciodată pe mai multe obiecte alocate.
    ///
    ///     * Pointerul trebuie să fie aliniat chiar și pentru felii de lungime zero.
    ///     Un motiv pentru aceasta este că optimizările de enumere ale aspectului se pot baza pe referințe (inclusiv felii de orice lungime) aliniate și care nu sunt nule pentru a le distinge de alte date.
    ///
    ///     Puteți obține un indicator care poate fi utilizat ca `data` pentru felii de lungime zero folosind [`NonNull::dangling()`].
    ///
    /// * Dimensiunea totală `ptr.len() * mem::size_of::<T>()` a feliei nu trebuie să fie mai mare decât `isize::MAX`.
    ///   Consultați documentația de siguranță a [`pointer::offset`].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///   În special, pe durata acestei vieți, memoria spre care indică indicatorul nu trebuie mutată (cu excepția `UnsafeCell`).
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// Vezi și [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Returnează `None` dacă indicatorul este nul sau altfel returnează o felie unică la valoarea înfășurată în `Some`.
    /// Spre deosebire de [`as_mut`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul partajat vezi [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că *fie* pointerul este NULL *, fie că* toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie să fie [valid] pentru citiri și scrieri pentru `ptr.len() * mem::size_of::<T>()` mulți octeți și trebuie aliniat corect.Aceasta înseamnă în special:
    ///
    ///     * Întreaga gamă de memorie a acestei felii trebuie să fie conținută într-un singur obiect alocat!
    ///       Feliile nu se pot întinde niciodată pe mai multe obiecte alocate.
    ///
    ///     * Pointerul trebuie să fie aliniat chiar și pentru felii de lungime zero.
    ///     Un motiv pentru aceasta este că optimizările de enumere ale aspectului se pot baza pe referințe (inclusiv felii de orice lungime) aliniate și care nu sunt nule pentru a le distinge de alte date.
    ///
    ///     Puteți obține un indicator care poate fi utilizat ca `data` pentru felii de lungime zero folosind [`NonNull::dangling()`].
    ///
    /// * Dimensiunea totală `ptr.len() * mem::size_of::<T>()` a feliei nu trebuie să fie mai mare decât `isize::MAX`.
    ///   Consultați documentația de siguranță a [`pointer::offset`].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///   În special, pe durata acestei vieți, memoria către care indică indicatorul nu trebuie accesată (citită sau scrisă) prin niciun alt indicator.
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// Vezi și [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Egalitate pentru indicatori
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}