#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Oferă tipul de metadate ale indicatorului oricărui tip îndreptat.
///
/// # Metadatele indicatorului
///
/// Tipurile de pointer brut și tipurile de referință din Rust pot fi considerate ca fiind formate din două părți:
/// un indicator de date care conține adresa de memorie a valorii și câteva metadate.
///
/// Pentru tipurile cu dimensiuni statice (care implementează `Sized` traits), precum și pentru tipurile `extern`, se spune că indicii sunt " subțiri`: metadatele sunt de dimensiuni zero și tipul său este `()`.
///
///
/// Se spune că indicatoarele către [dynamically-sized types][dst] sunt " late`sau " grase`, au metadate de dimensiuni diferite de zero:
///
/// * Pentru structuri al căror ultim câmp este DST, metadatele sunt metadatele ultimului câmp
/// * Pentru tipul `str`, metadatele reprezintă lungimea în octeți ca `usize`
/// * Pentru tipurile de felii cum ar fi `[T]`, metadatele reprezintă lungimea în articole ca `usize`
/// * Pentru obiectele trait precum `dyn SomeTrait`, metadatele sunt [`DynMetadata<Self>`][DynMetadata] (de ex. `DynMetadata<dyn SomeTrait>`)
///
/// În future, limbajul Rust poate câștiga noi tipuri de tipuri care au metadate diferite ale indicatorului.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Punctul acestui trait este tipul său asociat `Metadata`, care este `()` sau `usize` sau `DynMetadata<_>` așa cum este descris mai sus.
/// Este implementat automat pentru fiecare tip.
/// Se poate presupune că este implementat într-un context generic, chiar și fără o legătură corespunzătoare.
///
/// # Usage
///
/// Pointerii raw pot fi descompuși în adresa de date și componente de metadate cu metoda lor [`to_raw_parts`].
///
/// Alternativ, metadatele singure pot fi extrase cu funcția [`metadata`].
/// O referință poate fi transmisă la [`metadata`] și implicit constrânsă.
///
/// Un indicator (possibly-wide) poate fi pus din nou împreună de la adresa și metadatele sale cu [`from_raw_parts`] sau [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Tipul pentru metadate în pointeri și referințe la `Self`.
    #[lang = "metadata_type"]
    // NOTE: Păstrați trait bounds în `static_assert_expected_bounds_for_metadata`
    //
    // în `library/core/src/ptr/metadata.rs` sincronizat cu cei de aici:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Indicatorii către tipurile care implementează acest alias trait sunt " subțiri`.
///
/// Aceasta include tipurile statice " Dimensionate` și tipurile `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nu stabilizați acest lucru înainte ca aliasurile trait să fie stabile în limbă?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrageți componenta de metadate a unui pointer.
///
/// Valorile de tipul `*mut T`, `&T` sau `&mut T` pot fi transmise direct acestei funcții, deoarece acestea constrâng implicit către `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SIGURANȚĂ: Accesarea valorii din uniunea `PtrRepr` este sigură din moment ce * const T
    // și PtrComponents<T>au aceleași aspecte de memorie.
    // Doar std poate face această garanție.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Formează un pointer brut (possibly-wide) dintr-o adresă de date și metadate.
///
/// Această funcție este sigură, dar indicatorul returnat nu este neapărat sigur de la dereferință.
/// Pentru felii, consultați documentația [`slice::from_raw_parts`] pentru cerințele de siguranță.
/// Pentru obiectele trait, metadatele trebuie să provină de la un pointer la același tip subiacent șters.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SIGURANȚĂ: Accesarea valorii din uniunea `PtrRepr` este sigură din moment ce * const T
    // și PtrComponents<T>au aceleași aspecte de memorie.
    // Doar std poate face această garanție.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Efectuează aceeași funcționalitate ca și [`from_raw_parts`], cu excepția faptului că se returnează un pointer `*mut` brut, spre deosebire de un pointer `* const` brut.
///
///
/// Consultați documentația [`from_raw_parts`] pentru mai multe detalii.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SIGURANȚĂ: Accesarea valorii din uniunea `PtrRepr` este sigură din moment ce * const T
    // și PtrComponents<T>au aceleași aspecte de memorie.
    // Doar std poate face această garanție.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Este necesar un instrument manual pentru a evita legarea `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Este necesar un instrument manual pentru a evita legarea `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadatele pentru un tip de obiect `Dyn = dyn SomeTrait` trait.
///
/// Este un indicator către o tabelă virtuală (tabel de apel virtual) care reprezintă toate informațiile necesare pentru a manipula tipul de beton stocat în interiorul unui obiect trait.
/// Vtable conține în special:
///
/// * tipul dimensiunii
/// * aliniere tip
/// * un indicator către tipul `drop_in_place` de tip (poate fi un no-op pentru date simple-vechi)
/// * indică toate metodele pentru implementarea tipului trait
///
/// Rețineți că primele trei sunt speciale deoarece sunt necesare pentru alocarea, scăderea și alocarea oricărui obiect trait.
///
/// Este posibil să denumiți această structură cu un parametru de tip care nu este un obiect `dyn` trait (de exemplu `DynMetadata<u64>`), dar nu pentru a obține o valoare semnificativă a structurii respective.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Prefixul comun al tuturor tabelelor.Este urmat de indicatori de funcție pentru metodele trait.
///
/// Detalii despre implementarea privată a `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Returnează dimensiunea tipului asociat cu acest tabel.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Returnează alinierea tipului asociat cu acest tabel.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Returnează dimensiunea și alinierea împreună ca un `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SIGURANȚĂ: compilatorul a emis acest tabel pentru un tip beton Rust care
        // se știe că are un aspect valid.Același motiv ca în `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Instrumente manuale necesare pentru a evita limitele `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}