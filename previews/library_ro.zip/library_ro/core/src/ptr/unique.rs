use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Un wrapper în jurul unui `*mut T` brut non-nul care indică faptul că posesorul acestui wrapper deține referentul.
/// Util pentru construirea de abstracții precum `Box<T>`, `Vec<T>`, `String` și `HashMap<K, V>`.
///
/// Spre deosebire de `*mut T`, `Unique<T>` se comportă "as if", ar fi o instanță a `T`.
/// Implementează `Send`/`Sync` dacă `T` este `Send`/`Sync`.
/// Aceasta implică, de asemenea, un fel de aliasing puternic care se poate aștepta la o instanță de `T`:
/// referentul indicatorului nu ar trebui modificat fără o cale unică către proprietarul său unic.
///
/// Dacă nu sunteți sigur dacă este corect să utilizați `Unique` în scopurile dvs., luați în considerare utilizarea `NonNull`, care are o semantică mai slabă.
///
///
/// Spre deosebire de `*mut T`, indicatorul trebuie să fie întotdeauna non-nul, chiar dacă indicatorul nu este niciodată dereferențiat.
/// Aceasta pentru ca enumurile să poată folosi această valoare interzisă ca discriminant-`Option<Unique<T>>` are aceeași dimensiune ca `Unique<T>`.
/// Cu toate acestea, pointerul poate să atârne în continuare dacă nu este dereferențiat.
///
/// Spre deosebire de `*mut T`, `Unique<T>` este covariant peste `T`.
/// Acest lucru ar trebui să fie întotdeauna corect pentru orice tip care respectă cerințele de aliasing Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: acest marker nu are consecințe asupra varianței, dar este necesar
    // ca Dropck să înțeleagă că deținem în mod logic un `T`.
    //
    // Pentru detalii, a se vedea:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` indicatorii sunt `Send` dacă `T` este `Send`, deoarece datele la care fac referire sunt nelimitate.
/// Rețineți că acest invariant aliasing nu este impus de sistemul de tip;abstractizarea care utilizează `Unique` trebuie să o aplice.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` indicatorii sunt `Sync` dacă `T` este `Sync`, deoarece datele la care fac referire sunt nelimitate.
/// Rețineți că acest invariant aliasing nu este impus de sistemul de tip;abstractizarea care utilizează `Unique` trebuie să o aplice.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Creează un nou `Unique` care atârnă, dar bine aliniat.
    ///
    /// Acest lucru este util pentru inițializarea tipurilor care alocă leneș, așa cum face `Vec::new`.
    ///
    /// Rețineți că valoarea indicatorului poate reprezenta potențial un indicator valid la un `T`, ceea ce înseamnă că acest lucru nu trebuie utilizat ca valoare de sentinelă "not yet initialized".
    /// Tipurile care alocă leneș trebuie să urmărească inițializarea prin alte mijloace.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURANȚĂ: mem::align_of() returnează un indicator valid, non-nul.
        // condițiile pentru a apela new_unchecked() sunt astfel respectate.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Creează un nou `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` trebuie să fie nul.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `ptr` este nul.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Creează un `Unique` nou dacă `ptr` este nul.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURANȚĂ: indicatorul a fost deja verificat și nu este nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Achiziționează indicatorul `*mut` subiacent.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferență conținutul.
    ///
    /// Durata de viață rezultată este legată de sine, așa că acesta se comportă "as if", de fapt a fost o instanță de T care se împrumută.
    /// Dacă este necesară o durată mai mare de viață (unbound), utilizați `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință.
        unsafe { &*self.as_ptr() }
    }

    /// Dezreferențează reciproc conținutul.
    ///
    /// Durata de viață rezultată este legată de sine, așa că acesta se comportă "as if", de fapt a fost o instanță de T care se împrumută.
    /// Dacă este necesară o durată mai mare de viață (unbound), utilizați `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință mutabilă.
        unsafe { &mut *self.as_ptr() }
    }

    /// Distribuie la un pointer de alt tip.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SIGURANȚĂ: Unique::new_unchecked() creează un nou unic și are nevoie
        // indicatorul dat să nu fie nul.
        // Deoarece trecem de sine ca indicator, acesta nu poate fi nul.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURANȚĂ: o referință mutabilă nu poate fi nulă
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}