use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` dar non-zero și covariant.
///
/// Acesta este adesea lucrul corect de utilizat atunci când construiți structuri de date folosind pointeri bruti, dar este în cele din urmă mai periculos de utilizat datorită proprietăților sale suplimentare.Dacă nu sunteți sigur dacă ar trebui să utilizați `NonNull<T>`, utilizați doar `*mut T`!
///
/// Spre deosebire de `*mut T`, indicatorul trebuie să fie întotdeauna non-nul, chiar dacă indicatorul nu este niciodată dereferențiat.Asta pentru ca enumurile să poată folosi această valoare interzisă ca discriminant-`Option<NonNull<T>>` are aceeași dimensiune ca `* mut T`.
/// Cu toate acestea, pointerul poate să atârne în continuare dacă nu este dereferențiat.
///
/// Spre deosebire de `*mut T`, `NonNull<T>` a fost ales să fie covariant peste `T`.Acest lucru face posibilă utilizarea `NonNull<T>` atunci când construiți tipuri de covarianți, dar introduce riscul de insolvență dacă este utilizat într-un tip care nu ar trebui să fie de fapt covariant.
/// (Alegerea opusă a fost făcută pentru `*mut T`, chiar dacă din punct de vedere tehnic lipsa de sens poate fi cauzată doar de apelarea funcțiilor nesigure.)
///
/// Covarianța este corectă pentru cele mai sigure abstracții, cum ar fi `Box`, `Rc`, `Arc`, `Vec` și `LinkedList`.Acesta este cazul deoarece oferă un API public care respectă regulile XOR comune partajate mutabile ale Rust.
///
/// Dacă tipul dvs. nu poate fi covariant în siguranță, trebuie să vă asigurați că acesta conține câmp suplimentar pentru a oferi invarianță.Adesea acest câmp va fi de tip [`PhantomData`], cum ar fi `PhantomData<Cell<T>>` sau `PhantomData<&'a mut T>`.
///
/// Observați că `NonNull<T>` are o instanță `From` pentru `&T`.Cu toate acestea, acest lucru nu schimbă faptul că mutarea printr-un (pointer derivat dintr-o) referință partajată este un comportament nedefinit, cu excepția cazului în care mutația se întâmplă în interiorul unui [`UnsafeCell<T>`].Același lucru este valabil și pentru crearea unei referințe mutabile dintr-o referință partajată.
///
/// Când utilizați această instanță `From` fără `UnsafeCell<T>`, este responsabilitatea dvs. să vă asigurați că `as_mut` nu este apelat niciodată și că `as_ptr` nu este folosit niciodată pentru mutație.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` indicatorii nu sunt `Send` deoarece datele la care fac referire pot fi aliasate.
// NB, acest instrument nu este necesar, dar ar trebui să ofere mesaje de eroare mai bune.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` indicatorii nu sunt `Sync` deoarece datele la care fac referire pot fi aliasate.
// NB, acest instrument nu este necesar, dar ar trebui să ofere mesaje de eroare mai bune.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Creează un nou `NonNull` care atârnă, dar bine aliniat.
    ///
    /// Acest lucru este util pentru inițializarea tipurilor care alocă leneș, așa cum face `Vec::new`.
    ///
    /// Rețineți că valoarea indicatorului poate reprezenta potențial un indicator valid la un `T`, ceea ce înseamnă că acest lucru nu trebuie utilizat ca valoare de sentinelă "not yet initialized".
    /// Tipurile care alocă leneș trebuie să urmărească inițializarea prin alte mijloace.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURANȚĂ: mem::align_of() returnează o utilizare diferită de zero, care este apoi aruncată
        // la un * mut T.
        // Prin urmare, `ptr` nu este nul și sunt respectate condițiile pentru apelarea new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Returnează o referință partajată la valoare.Spre deosebire de [`as_ref`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul mutabil, a se vedea [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///
    ///   În special, pe durata acestei vieți, memoria spre care indică indicatorul nu trebuie mutată (cu excepția `UnsafeCell`).
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Returnează o referință unică la valoare.Spre deosebire de [`as_mut`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul partajat vezi [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///
    ///   În special, pe durata acestei vieți, memoria către care indică indicatorul nu trebuie accesată (citită sau scrisă) prin niciun alt indicator.
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Creează un nou `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` trebuie să fie nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `ptr` este nul.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Creează un `NonNull` nou dacă `ptr` este nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURANȚĂ: indicatorul este deja bifat și nu este nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Efectuează aceeași funcționalitate ca și [`std::ptr::from_raw_parts`], cu excepția faptului că se returnează un pointer `NonNull`, spre deosebire de un pointer `*const` brut.
    ///
    ///
    /// Consultați documentația [`std::ptr::from_raw_parts`] pentru mai multe detalii.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SIGURANȚĂ: Rezultatul `ptr::from::raw_parts_mut` este nul, deoarece `data_address` este.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Descompuneți un pointer (posibil larg) în componentele de adresă și metadate.
    ///
    /// Pointerul poate fi ulterior reconstruit cu [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Achiziționează indicatorul `*mut` subiacent.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Returnează o referință partajată la valoare.Dacă valoarea poate fi neinițializată, trebuie utilizat în schimb [`as_uninit_ref`].
    ///
    /// Pentru omologul mutabil, a se vedea [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Pointerul trebuie să indice o instanță inițializată de `T`.
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///
    ///   În special, pe durata acestei vieți, memoria spre care indică indicatorul nu trebuie mutată (cu excepția `UnsafeCell`).
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    /// (Partea despre inițializare nu este încă pe deplin hotărâtă, dar până la finalizarea acesteia, singura abordare sigură este asigurarea faptului că acestea sunt într-adevăr inițializate.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință.
        unsafe { &*self.as_ptr() }
    }

    /// Returnează o referință unică la valoare.Dacă valoarea poate fi neinițializată, trebuie folosit în schimb [`as_uninit_mut`].
    ///
    /// Pentru omologul partajat vezi [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie aliniat corect.
    ///
    /// * Trebuie să fie "dereferencable" în sensul definit în [the module documentation].
    ///
    /// * Pointerul trebuie să indice o instanță inițializată de `T`.
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///
    ///   În special, pe durata acestei vieți, memoria către care indică indicatorul nu trebuie accesată (citită sau scrisă) prin niciun alt indicator.
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    /// (Partea despre inițializare nu este încă pe deplin hotărâtă, dar până la finalizarea acesteia, singura abordare sigură este asigurarea faptului că acestea sunt într-adevăr inițializate.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURANȚĂ: apelantul trebuie să garanteze că `self` îndeplinește toate
        // cerințele pentru o referință mutabilă.
        unsafe { &mut *self.as_ptr() }
    }

    /// Distribuie la un pointer de alt tip.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SIGURANȚĂ: `self` este un indicator `NonNull` care este neapărat non-nul
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Creează o felie brută non-nulă dintr-un indicator subțire și o lungime.
    ///
    /// Argumentul `len` este numărul de **elemente**, nu numărul de octeți.
    ///
    /// Această funcție este sigură, dar dereferențierea valorii returnate este nesigură.
    /// Consultați documentația [`slice::from_raw_parts`] pentru cerințele de siguranță a feliilor.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // creați un indicator de felie atunci când începeți cu un indicator la primul element
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Rețineți că acest exemplu demonstrează în mod artificial utilizarea acestei metode, dar `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SIGURANȚĂ: `data` este un indicator `NonNull` care este neapărat non-nul
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Returnează lungimea unei felii brute care nu sunt nule.
    ///
    /// Valoarea returnată este numărul de **elemente**, nu numărul de octeți.
    ///
    /// Această funcție este sigură, chiar și atunci când felia brută non-nulă nu poate fi dereferențiată la o felie, deoarece indicatorul nu are o adresă validă.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Returnează un pointer care nu este nul în bufferul feliei.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SIGURANȚĂ: Știm că `self` este nul.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Returnează un indicator brut în bufferul feliei.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Returnează o referință partajată la o porțiune de valori posibil neinitializate.Spre deosebire de [`as_ref`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul mutabil, a se vedea [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie să fie [valid] pentru citiri pentru `ptr.len() * mem::size_of::<T>()` mulți octeți și trebuie să fie aliniat corect.Aceasta înseamnă în special:
    ///
    ///     * Întreaga gamă de memorie a acestei felii trebuie să fie conținută într-un singur obiect alocat!
    ///       Feliile nu se pot întinde niciodată pe mai multe obiecte alocate.
    ///
    ///     * Pointerul trebuie să fie aliniat chiar și pentru felii de lungime zero.
    ///     Un motiv pentru aceasta este că optimizările de enumere ale aspectului se pot baza pe referințe (inclusiv felii de orice lungime) aliniate și care nu sunt nule pentru a le distinge de alte date.
    ///
    ///     Puteți obține un indicator care poate fi utilizat ca `data` pentru felii de lungime zero folosind [`NonNull::dangling()`].
    ///
    /// * Dimensiunea totală `ptr.len() * mem::size_of::<T>()` a feliei nu trebuie să fie mai mare decât `isize::MAX`.
    ///   Consultați documentația de siguranță a [`pointer::offset`].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///   În special, pe durata acestei vieți, memoria spre care indică indicatorul nu trebuie mutată (cu excepția `UnsafeCell`).
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// Vezi și [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Returnează o referință unică la o porțiune de valori posibil neinitializate.Spre deosebire de [`as_mut`], acest lucru nu necesită inițializarea valorii.
    ///
    /// Pentru omologul partajat vezi [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Când apelați această metodă, trebuie să vă asigurați că toate următoarele sunt adevărate:
    ///
    /// * Pointerul trebuie să fie [valid] pentru citiri și scrieri pentru `ptr.len() * mem::size_of::<T>()` mulți octeți și trebuie aliniat corect.Aceasta înseamnă în special:
    ///
    ///     * Întreaga gamă de memorie a acestei felii trebuie să fie conținută într-un singur obiect alocat!
    ///       Feliile nu se pot întinde niciodată pe mai multe obiecte alocate.
    ///
    ///     * Pointerul trebuie să fie aliniat chiar și pentru felii de lungime zero.
    ///     Un motiv pentru aceasta este că optimizările de enumere ale aspectului se pot baza pe referințe (inclusiv felii de orice lungime) aliniate și care nu sunt nule pentru a le distinge de alte date.
    ///
    ///     Puteți obține un indicator care poate fi utilizat ca `data` pentru felii de lungime zero folosind [`NonNull::dangling()`].
    ///
    /// * Dimensiunea totală `ptr.len() * mem::size_of::<T>()` a feliei nu trebuie să fie mai mare decât `isize::MAX`.
    ///   Consultați documentația de siguranță a [`pointer::offset`].
    ///
    /// * Trebuie să aplicați regulile de aliasare ale Rust, deoarece durata de viață returnată `'a` este aleasă în mod arbitrar și nu reflectă neapărat durata de viață reală a datelor.
    ///   În special, pe durata acestei vieți, memoria către care indică indicatorul nu trebuie accesată (citită sau scrisă) prin niciun alt indicator.
    ///
    /// Acest lucru se aplică chiar dacă rezultatul acestei metode este neutilizat!
    ///
    /// Vezi și [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Acest lucru este sigur, deoarece `memory` este valid pentru citiri și scrieri pentru `memory.len()` mulți octeți.
    /// // Rețineți că apelarea `memory.as_mut()` nu este permisă aici, deoarece conținutul poate fi neinițializat.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SIGURANȚĂ: apelantul trebuie să respecte contractul de siguranță pentru `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Returnează un pointer brut la un element sau subsecțiune, fără a face verificarea limitelor.
    ///
    /// Apelarea acestei metode cu un index în afara limitelor sau când `self` nu este dereferențial este *[comportament nedefinit]*, chiar dacă indicatorul rezultat nu este utilizat.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SIGURANȚĂ: apelantul se asigură că `self` este dereferențial și `index` este limitat.
        // În consecință, indicatorul rezultat nu poate fi NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SIGURANȚĂ: Un indicator unic nu poate fi nul, deci condițiile pentru
        // new_unchecked() sunt respectate.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURANȚĂ: o referință mutabilă nu poate fi nulă.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SIGURANȚĂ: O referință nu poate fi nulă, deci condițiile pentru
        // new_unchecked() sunt respectate.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}