//! Un modul pentru lucrul cu date împrumutate.

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait pentru date de împrumut.
///
/// În Rust, este obișnuit să se furnizeze diferite reprezentări ale unui tip pentru diferite cazuri de utilizare.
/// De exemplu, locația de stocare și gestionarea unei valori pot fi alese în mod specific, adecvate pentru o anumită utilizare, prin tipuri de pointer, cum ar fi [`Box<T>`] sau [`Rc<T>`].
/// Dincolo de aceste ambalaje generice care pot fi utilizate cu orice tip, unele tipuri oferă fațete opționale care oferă funcționalități potențial costisitoare.
/// Un exemplu pentru un astfel de tip este [`String`], care adaugă posibilitatea de a extinde un șir la [`str`] de bază.
/// Acest lucru necesită păstrarea informațiilor suplimentare inutile pentru un șir simplu, imuabil.
///
/// Aceste tipuri oferă acces la datele subiacente prin referințe la tipul acelor date.Se spune că sunt " împrumutați` ca acel tip.
/// De exemplu, un [`Box<T>`] poate fi împrumutat ca `T` în timp ce un [`String`] poate fi împrumutat ca `str`.
///
/// Tipurile exprimă faptul că pot fi împrumutate ca un anumit tip `T` prin implementarea `Borrow<T>`, oferind o referință la un `T` în metoda [`borrow`] a trait.Un tip este liber să împrumute ca mai multe tipuri diferite.
/// Dacă dorește să împrumute reciproc ca tip-permițând modificarea datelor de bază, poate implementa suplimentar [`BorrowMut<T>`].
///
/// Mai mult, atunci când se oferă implementări pentru traits suplimentare, trebuie să se ia în considerare dacă acestea ar trebui să se comporte identic cu cele de tipul subiacent ca o consecință a acționării ca reprezentare a acelui tip de bază.
/// Codul generic folosește de obicei `Borrow<T>` atunci când se bazează pe comportamentul identic al acestor implementări suplimentare trait.
/// Aceste traits vor apărea probabil ca trait bounds suplimentare.
///
/// În special `Eq`, `Ord` și `Hash` trebuie să fie echivalente pentru valorile împrumutate și deținute: `x.borrow() == y.borrow()` ar trebui să dea același rezultat ca `x == y`.
///
/// Dacă codul generic trebuie doar să funcționeze pentru toate tipurile care pot furniza o referință la tipul asociat `T`, este adesea mai bine să folosiți [`AsRef<T>`], deoarece mai multe tipuri îl pot implementa în siguranță.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Ca colecție de date, [`HashMap<K, V>`] deține atât chei, cât și valori.Dacă datele reale ale cheii sunt înfășurate într-un tip de gestionare de un fel, ar trebui totuși să fie posibil să căutați o valoare folosind o referință la datele cheii.
/// De exemplu, dacă cheia este un șir, atunci este probabil stocată cu harta hash ca [`String`], în timp ce ar trebui să fie posibil să căutați folosind un [`&str`][`str`].
/// Astfel, `insert` trebuie să funcționeze pe un `String`, în timp ce `get` trebuie să poată utiliza un `&str`.
///
/// Ușor simplificate, părțile relevante ale `HashMap<K, V>` arată astfel:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // câmpuri omise
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Întreaga hartă hash este generică pe un tip de cheie `K`.Deoarece aceste chei sunt stocate cu harta hash, acest tip trebuie să dețină datele cheii.
/// Când introduceți o pereche cheie-valoare, hărții primește un astfel de `K` și trebuie să găsească cupa hash corectă și să verifice dacă cheia este deja prezentă pe baza acelui `K`.Prin urmare, necesită `K: Hash + Eq`.
///
/// Cu toate acestea, atunci când căutați o valoare pe hartă, trebuie să furnizați o referință la un `K`, deoarece cheia de căutat ar necesita să creați întotdeauna o astfel de valoare deținută.
/// Pentru tastele șir, acest lucru ar însemna că trebuie creată o valoare `String` doar pentru căutarea cazurilor în care este disponibil doar un `str`.
///
/// În schimb, metoda `get` este generică față de tipul datelor cheie subiacente, numită `Q` în semnătura metodei de mai sus.Se afirmă că `K` împrumută ca `Q` cerând `K: Borrow<Q>`.
/// Prin necesitatea suplimentară de `Q: Hash + Eq`, semnalează cerința ca `K` și `Q` să aibă implementări ale `Hash` și `Eq` traits care să producă rezultate identice.
///
/// Implementarea `get` se bazează în special pe implementări identice ale `Hash` prin determinarea cupei hash a cheii apelând `Hash::hash` pe valoarea `Q`, chiar dacă a introdus cheia pe baza valorii hash calculate din valoarea `K`.
///
///
/// În consecință, harta hash se rupe dacă un `K` care împachetează o valoare `Q` produce un hash diferit de `Q`.De exemplu, imaginați-vă că aveți un tip care înfășoară un șir, dar compară literele ASCII ignorând majusculele lor:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Deoarece două valori egale trebuie să producă aceeași valoare hash, implementarea `Hash` trebuie să ignore și cazul ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Poate `CaseInsensitiveString` să implementeze `Borrow<str>`?Cu siguranță poate oferi o referință la o felie de șir prin șirul său deținut.
/// Dar, deoarece implementarea sa `Hash` diferă, se comportă diferit de `str` și, prin urmare, nu trebuie, de fapt, să implementeze `Borrow<str>`.
/// Dacă dorește să permită altor persoane accesul la `str` subiacent, poate face acest lucru prin `AsRef<str>`, care nu are cerințe suplimentare.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Împrumută imuabil dintr-o valoare deținută.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Un trait pentru împrumut reciproc de date.
///
/// Ca însoțitor al [`Borrow<T>`], acest trait permite unui tip să împrumute ca tip de bază oferind o referință mutabilă.
/// Consultați [`Borrow<T>`] pentru mai multe informații despre împrumuturi ca alt tip.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Împrumută reciproc de la o valoare deținută.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}