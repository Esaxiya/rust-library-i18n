//! Decodează o valoare în virgulă mobilă în părți individuale și intervale de erori.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valoare finită nesemnată decodificată, astfel încât:
///
/// - Valoarea inițială este egală cu `mant * 2^exp`.
///
/// - Orice număr de la `(mant - minus)*2^exp` la `(mant + plus)* 2^exp` se va rotunji la valoarea inițială.
/// Gama este inclusă numai atunci când `inclusive` este `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantisa scalată.
    pub mant: u64,
    /// Intervalul de eroare inferior.
    pub minus: u64,
    /// Intervalul de eroare superior.
    pub plus: u64,
    /// Exponentul partajat în baza 2.
    pub exp: i16,
    /// Adevărat atunci când intervalul de erori este inclus.
    ///
    /// În IEEE 754, acest lucru este adevărat atunci când mantisa originală era uniformă.
    pub inclusive: bool,
}

/// Valoare nesemnată decodificată.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinități, fie pozitive, fie negative.
    Infinite,
    /// Zero, fie pozitiv, fie negativ.
    Zero,
    /// Numere finite cu câmpuri decodificate în continuare.
    Finite(Decoded),
}

/// Un tip cu virgulă mobilă care poate fi " decodat` d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Valoarea minimă normalizată pozitivă.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Returnează un semn (adevărat atunci când este negativ) și valoarea `FullDecoded` de la numărul dat în virgulă mobilă.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // vecini: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode păstrează întotdeauna exponentul, astfel încât mantisa este scalată pentru subnormali.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // vecini: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // unde maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // vecini: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}