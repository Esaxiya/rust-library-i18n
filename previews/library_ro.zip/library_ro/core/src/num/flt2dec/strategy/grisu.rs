//! Adaptarea Rust a algoritmului Grisu3 descris în " Tipărirea rapidă și precisă a numerelor în virgulă mobilă cu numere întregi` [^ 1].
//! Folosește aproximativ 1 KB de tabel precomputat și, la rândul său, este foarte rapid pentru majoritatea intrărilor.
//!
//! [^1]: Florian Loitsch.2010. Tipărirea rapidă a numerelor în virgulă mobilă și
//!   cu precizie cu numere întregi.SIGPLAN Nu.45, 6 (iunie 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// vezi comentariile din `format_shortest_opt` pentru justificare.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Dat fiind `x > 0`, returnează `(k, 10^k)` astfel încât `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Cea mai scurtă implementare a modului pentru Grisu.
///
/// Întoarce `None` când altfel ar returna o reprezentare inexactă.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // avem nevoie de cel puțin trei biți de precizie suplimentară

    // începeți cu valorile normalizate cu exponentul partajat
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // găsiți orice `cached = 10^minusk` astfel încât `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // deoarece `plus` este normalizat, aceasta înseamnă `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // având în vedere alegerile noastre de `ALPHA` și `GAMMA`, acest lucru pune `plus * cached` în `[4, 2^32)`.
    //
    // în mod evident, este de dorit să maximizăm `GAMMA - ALPHA`, astfel încât să nu avem nevoie de multe puteri cache de 10, dar există câteva considerații:
    //
    //
    // 1. vrem să păstrăm `floor(plus * cached)` în `u32`, deoarece are nevoie de o diviziune costisitoare.
    //    (acest lucru nu este cu adevărat evitabil, restul este necesar pentru estimarea preciziei.)
    // 2.
    // restul `floor(plus * cached)` se înmulțește în mod repetat cu 10 și nu ar trebui să depășească.
    //
    // primul oferă `64 + GAMMA <= 32`, în timp ce al doilea dă `10 * 2^-ALPHA <= 2^64`;
    // -60 iar -32 este intervalul maxim cu această constrângere și V8 le folosește, de asemenea.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // scară fps.acest lucru dă eroarea maximă de 1 ulp (demonstrată din teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-intervalul real de minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // peste `minus`, `v` și `plus` sunt aproximări *cuantificate*(eroare <1 ulp).
    // deoarece nu știm că eroarea este pozitivă sau negativă, folosim două aproximări distanțate în mod egal și avem eroarea maximă de 2 ulpi.
    //
    // "unsafe region" este un interval liberal pe care îl generăm inițial.
    // "safe region" este un interval conservator pe care îl acceptăm doar.
    // începem cu reprogramarea corectă în regiunea nesigură și încercăm să găsim cea mai apropiată reprimare la `v`, care este și în regiunea sigură.
    // dacă nu putem, renunțăm.
    //
    let plus1 = plus.f + 1;
    // să plus0 = plus.f, 1;//doar pentru explicație, lăsați minus0 = minus.f + 1;//doar pentru explicații
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // exponent comun

    // împarte `plus1` în părți integrale și fracționate.
    // părțile integrale sunt garantate pentru a se potrivi în u32, deoarece puterea cache garantează `plus < 2^32` și `plus.f` normal este întotdeauna mai mică decât `2^64 - 2^4` datorită cerinței de precizie.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // calculați cel mai mare `10^max_kappa` nu mai mult de `plus1` (deci `plus1 < 10^(max_kappa+1)`).
    // aceasta este o limită superioară a `kappa` de mai jos.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: dacă `k` este cel mai mare întreg st
    // `0 <= y mod 10^k <= y - x`,              atunci `V = floor(y / 10^k) * 10^k` este în `[x, y]` și una dintre cele mai scurte reprezentări (cu numărul minim de cifre semnificative) din intervalul respectiv.
    //
    //
    // găsiți lungimea cifrei `kappa` între `(minus1, plus1)` conform teoremei 6.2.
    // Teorema 6.2 poate fi adoptată pentru a exclude `x` solicitând în schimb `y mod 10^k < y - x`.
    // (de exemplu, `x` =32000, `y` =32777; `kappa` =2 deoarece `y mod 10 ^ 3=777 <y, x=777`.) algoritmul se bazează pe faza de verificare ulterioară pentru a exclude `y`.
    //
    let delta1 = plus1 - minus1;
    // să delta1int=(delta1>> e) ca utilizează;//doar pentru explicații
    let delta1frac = delta1 & ((1 << e) - 1);

    // redați piese integrale, verificând în același timp acuratețea la fiecare pas.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // cifre încă de redat
    loop {
        // avem întotdeauna cel puțin o cifră de redat, ca invarianți `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (rezultă că `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // împarte `remainder` la `10^kappa`.ambele sunt scalate de `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; am găsit `kappa` corect.
            let ten_kappa = (ten_kappa as u64) << e; // scala 10 ^ kappa înapoi la exponentul partajat
            return round_and_weed(
                // SIGURANȚĂ: am inițializat acea memorie mai sus.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // rupem bucla când am redat toate cifrele integrale.
        // numărul exact de cifre este `max_kappa + 1` ca `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restabiliți invarianții
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // redați părți fracționate, în timp ce verificați acuratețea la fiecare pas.
    // de această dată ne bazăm pe multiplicări repetate, deoarece împărțirea va pierde precizia.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // următoarea cifră ar trebui să fie semnificativă deoarece am testat asta înainte de a sparge invarianți, unde `m = max_kappa + 1` (numărul de cifre din partea integrală):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // nu se va revărsa, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // împarte `remainder` la `10^kappa`.
        // ambele sunt scalate de `2^e / 10^kappa`, deci acesta din urmă este implicit aici.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // divizor implicit
            return round_and_weed(
                // SIGURANȚĂ: am inițializat acea memorie mai sus.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // restabiliți invarianții
        kappa -= 1;
        remainder = r;
    }

    // am generat toate cifrele semnificative ale `plus1`, dar nu suntem siguri dacă este cea optimă.
    // de exemplu, dacă `minus1` este 3,14153 ... și `plus1` este 3,14158 ..., există 5 reprezentări scurte diferite de la 3.14154 la 3.14158, dar noi avem doar cea mai mare.
    // trebuie să micșorăm succesiv ultima cifră și să verificăm dacă aceasta este reprimarea optimă.
    // există cel mult 9 candidați (..1 la ..9), deci acest lucru este destul de rapid.(Faza "rounding")
    //
    // funcția verifică dacă această reproducere "optimal" este de fapt în limitele ulp și, de asemenea, este posibil ca reproducerea "second-to-optimal" să fie de fapt optimă din cauza erorii de rotunjire.
    // în ambele cazuri, acest lucru returnează `None`.
    // (Faza "weeding")
    //
    // toate argumentele de aici sunt scalate de valoarea comună (dar implicită) `k`, astfel încât:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (și, de asemenea, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (și, de asemenea, `threshold > plus1v` de la invarianți anteriori)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // produce două aproximări la `v` (de fapt `plus1 - v`) în cadrul ulpilor 1.5.
        // reprezentarea rezultată ar trebui să fie cea mai apropiată de ambele.
        //
        // aici se folosește `plus1 - v` deoarece calculele se fac cu privire la `plus1` pentru a evita overflow/underflow (de aici și numele aparent schimbate).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // micșorați ultima cifră și opriți-vă la cea mai apropiată reprezentare de `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // lucrăm cu cifrele aproximative `w(n)`, care este inițial egală cu `plus1 - plus1 % 10^kappa`.după rularea corpului buclei de `n` ori, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // setăm `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (deci `rest= plus1w(0)`) pentru a simplifica verificările.
            // rețineți că `plus1w(n)` este în continuă creștere.
            //
            // avem trei condiții de încheiat.oricare dintre ele va face ca bucla să nu poată continua, dar avem apoi cel puțin o reprezentare validă cunoscută a fi cea mai apropiată de `v + 1 ulp` oricum.
            // le vom denumi TC1 până la TC3 pentru scurtă durată.
            //
            // TC1: `w(n) <= v + 1 ulp`, adică acesta este ultimul repr, care poate fi cel mai apropiat.
            // acest lucru este echivalent cu `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // combinat cu TC2 (care verifică dacă `w(n+1)` is valid), acest lucru împiedică depășirea posibilă la calculul `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, adică următoarea reproșare cu siguranță nu se va rotunji la `v`.
            // acest lucru este echivalent cu `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // partea stângă se poate revărsa, dar știm `threshold > plus1v`, deci dacă TC1 este fals, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` și putem testa în siguranță dacă `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, adică, următorul repr este
            // nu mai aproape de `v + 1 ulp` decât actualul repr.
            // dat `z(n) = plus1v_up - plus1w(n)`, acesta devine `abs(z(n)) <= abs(z(n+1))`.presupunând din nou că TC1 este fals, avem `z(n) > 0`.avem două cazuri de luat în considerare:
            //
            // - când `z(n+1) >= 0`: TC3 devine `z(n) <= z(n+1)`.
            // deoarece `plus1w(n)` crește, `z(n)` ar trebui să fie în scădere și acest lucru este în mod clar fals.
            // - când `z(n+1) < 0`:
            //   - TC3a: precondiția este `plus1v_up < plus1w(n) + 10^kappa`.presupunând că TC2 este fals, `threshold >= plus1w(n) + 10^kappa` deci nu poate revărsa.
            //   - TC3b: TC3 devine `z(n) <= -z(n+1)`, adică `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 negat dă `plus1v_up > plus1w(n)`, deci nu poate revărsa sau deborda atunci când este combinat cu TC3a.
            //
            // în consecință, ar trebui să ne oprim când `TC1 || TC2 || (TC3a && TC3b)`.următorul este egal cu inversul său, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // cel mai scurt repr nu se poate termina cu `0`
                plus1w += ten_kappa;
            }
        }

        // verificați dacă această reprezentare este, de asemenea, cea mai apropiată reprezentare de `v - 1 ulp`.
        //
        // acest lucru este pur și simplu același cu condițiile de terminare pentru `v + 1 ulp`, cu toate `plus1v_up` înlocuite cu `plus1v_down`.
        // analiza preaplinului se menține în mod egal.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // acum avem cea mai apropiată reprezentare la `v` între `plus1` și `minus1`.
        // totuși, acest lucru este prea liberal, așa că respingem orice `w(n)` nu între `plus0` și `minus0`, adică `plus1 - plus1w(n) <= minus0` sau `plus1 - plus1w(n) >= plus0`.
        // folosim faptele pe care `threshold = plus1 - minus1` și `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Cea mai scurtă implementare a modului pentru Grisu cu Dragon fallback.
///
/// Acest lucru ar trebui utilizat în majoritatea cazurilor.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SIGURANȚĂ: Verificatorul de împrumut nu este suficient de inteligent pentru a ne permite să folosim `buf`
    // în a doua branch, așa că spălăm viața aici.
    // Dar reutilizăm `buf` numai dacă `format_shortest_opt` a returnat `None`, deci este în regulă.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Implementarea modului exact și fix pentru Grisu.
///
/// Întoarce `None` când altfel ar returna o reprezentare inexactă.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // avem nevoie de cel puțin trei biți de precizie suplimentară
    assert!(!buf.is_empty());

    // normalizați și scalați `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // împarte `v` în părți integrale și fracționate.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // atât vechiul `v`, cât și noul `v` (scalat cu `10^-k`) are o eroare de <1 ulp (teorema 5.1).
    // deoarece nu știm că eroarea este pozitivă sau negativă, folosim două aproximări distanțate în mod egal și avem eroarea maximă de 2 ulpi (același cu cel mai scurt caz).
    //
    //
    // scopul este să găsim seria de cifre exact rotunjite, care sunt comune atât pentru `v - 1 ulp`, cât și pentru `v + 1 ulp`, astfel încât să avem maximă încredere.
    // dacă acest lucru nu este posibil, nu știm care este ieșirea corectă pentru `v`, deci renunțăm și ne întoarcem.
    //
    // `err` este definit ca `1 ulp * 2^e` aici (același cu cel al ulp din `vfrac`) și îl vom scala ori de câte ori `v` va fi scalat.
    //
    //
    //
    let mut err = 1;

    // calculați cel mai mare `10^max_kappa` nu mai mult de `v` (deci `v < 10^(max_kappa+1)`).
    // aceasta este o limită superioară a `kappa` de mai jos.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // dacă lucrăm cu limitarea ultimelor cifre, trebuie să scurtăm tamponul înainte de redarea efectivă, pentru a evita rotunjirea dublă.
    //
    // rețineți că trebuie să mărim din nou bufferul atunci când se întâmplă rotunjirea în sus!
    let len = if exp <= limit {
        // Oops, nici măcar nu putem produce * o singură cifră.
        // acest lucru este posibil atunci când, să zicem, avem ceva de genul 9.5 și este rotunjit la 10.
        //
        // în principiu, putem apela imediat `possibly_round` cu un tampon gol, dar scalarea `max_ten_kappa << e` cu 10 poate duce la depășire.
        //
        // astfel suntem neglijent aici și extindem gama de erori cu un factor de 10.
        // aceasta va crește rata falsului negativ, dar doar foarte,*foarte* ușor;
        // poate conta doar în mod vizibil atunci când mantisa este mai mare de 60 de biți.
        //
        // SIGURANȚĂ: `len=0`, deci obligația de a inițializa această memorie este banală.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // redau piese integrale.
    // eroarea este complet fracțională, deci nu este nevoie să o verificăm în această parte.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // cifre încă de redat
    loop {
        // avem întotdeauna cel puțin o cifră pentru a face invarianți:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (rezultă că `remainder = vint % 10^(kappa+1)`)
        //
        //

        // împarte `remainder` la `10^kappa`.ambele sunt scalate de `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // este tamponul plin?rulați permisul de rotunjire cu restul.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SIGURANȚĂ: am inițializat `len` mulți octeți.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // rupem bucla când am redat toate cifrele integrale.
        // numărul exact de cifre este `max_kappa + 1` ca `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restabiliți invarianții
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // redau părți fracționate.
    //
    // în principiu, putem continua până la ultima cifră disponibilă și putem verifica acuratețea.
    // din păcate, lucrăm cu numere întregi de dimensiuni finite, deci avem nevoie de un criteriu pentru a detecta depășirea.
    // V8 folosește `remainder > err`, care devine fals atunci când primele cifre semnificative `i` ale `v - 1 ulp` și `v` diferă.
    // cu toate acestea, acest lucru respinge prea multe date de altfel valabile.
    //
    // deoarece faza ulterioară are o detectare corectă a revărsării, folosim în schimb criteriul mai strict:
    // continuăm până când `err` depășește `10^kappa / 2`, astfel încât intervalul dintre `v - 1 ulp` și `v + 1 ulp` conține cu siguranță două sau mai multe reprezentări rotunjite.
    //
    // acest lucru este același cu primele două comparații de la `possibly_round`, pentru referință.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianți, unde `m = max_kappa + 1` (numărul de cifre din partea integrală):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // nu se va revărsa, `2^e * 10 < 2^64`
        err *= 10; // nu se va revărsa, `err * 10 < 2^e * 5 < 2^64`

        // împarte `remainder` la `10^kappa`.
        // ambele sunt scalate de `2^e / 10^kappa`, deci acesta din urmă este implicit aici.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // este tamponul plin?rulați permisul de rotunjire cu restul.
        if i == len {
            // SIGURANȚĂ: am inițializat `len` mulți octeți.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // restabiliți invarianții
        remainder = r;
    }

    // alte calcule sunt inutile (`possibly_round` eșuează cu siguranță), așa că renunțăm.
    return None;

    // am generat toate cifrele solicitate de `v`, care ar trebui să fie la fel cu cifrele corespunzătoare ale `v - 1 ulp`.
    // acum verificăm dacă există o reprezentare unică partajată atât de `v - 1 ulp`, cât și de `v + 1 ulp`;acest lucru poate fi identic cu cifrele generate, sau cu versiunea rotunjită a acestor cifre.
    //
    // dacă intervalul conține mai multe reprezentări de aceeași lungime, nu putem fi siguri și ar trebui să returnăm `None` în schimb.
    //
    // toate argumentele de aici sunt scalate de valoarea comună (dar implicită) `k`, astfel încât:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SIGURANȚĂ: trebuie inițializați primii octeți `len` ai `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (pentru referință, linia punctată indică valoarea exactă pentru reprezentările posibile într-un număr dat de cifre.)
        //
        //
        // eroarea este prea mare încât există cel puțin trei reprezentări posibile între `v - 1 ulp` și `v + 1 ulp`.
        // nu putem determina care dintre ele este corectă.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // de fapt, 1/2 ulp este suficient pentru a introduce două reprezentări posibile.
        // (amintiți-vă că avem nevoie de o reprezentare unică atât pentru `v - 1 ulp`, cât și pentru " v + 1 ulp`.) aceasta nu se va revărsa, deoarece `ulp < ten_kappa` de la prima verificare.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // dacă `v + 1 ulp` este mai aproape de reprezentarea rotunjită (care este deja în `buf`), atunci putem reveni în siguranță.
        // rețineți că `v - 1 ulp`*poate* fi mai mic decât reprezentarea curentă, dar ca `1 ulp < 10^kappa / 2`, această condiție este suficientă:
        // distanța dintre `v - 1 ulp` și reprezentarea curentă nu poate depăși `10^kappa / 2`.
        //
        // condiția este egală cu `remainder + ulp < 10^kappa / 2`.
        // deoarece acest lucru se poate revărsa cu ușurință, verificați mai întâi dacă `remainder < 10^kappa / 2`.
        // am verificat deja că `ulp < 10^kappa / 2`, deci atâta timp cât `10^kappa` nu s-a revărsat până la urmă, a doua verificare este în regulă.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SIGURANȚĂ: apelantul nostru a inițializat acea memorie.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------rest------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // pe de altă parte, dacă `v - 1 ulp` este mai aproape de reprezentarea rotunjită, ar trebui să ne rotunjim și să ne întoarcem.
        // din același motiv nu este nevoie să verificăm `v + 1 ulp`.
        //
        // condiția este egală cu `remainder - ulp >= 10^kappa / 2`.
        // din nou verificăm mai întâi dacă `remainder > ulp` (rețineți că acesta nu este `remainder >= ulp`, deoarece `10^kappa` nu este niciodată zero).
        //
        // de asemenea, rețineți că `remainder - ulp <= 10^kappa`, deci a doua verificare nu se revarsă.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SIGURANȚĂ: apelantul nostru trebuie să fi inițializat acea memorie.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // adăugați o cifră suplimentară numai atunci când ni se solicită precizia fixă.
                // trebuie, de asemenea, să verificăm dacă, dacă bufferul original a fost gol, cifra suplimentară poate fi adăugată numai atunci când `exp == limit` (carcasa edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SIGURANȚĂ: noi și apelantul nostru am inițializat acea memorie.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // altfel suntem condamnați (adică, unele valori între `v - 1 ulp` și `v + 1 ulp` se rotunjesc în jos și altele se rotunjesc în sus) și renunțăm.
        //
        None
    }
}

/// Implementarea modului exact și fix pentru Grisu cu Dragon de rezervă.
///
/// Acest lucru ar trebui utilizat în majoritatea cazurilor.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SIGURANȚĂ: Verificatorul de împrumut nu este suficient de inteligent pentru a ne permite să folosim `buf`
    // în a doua branch, așa că spălăm viața aici.
    // Dar reutilizăm `buf` numai dacă `format_exact_opt` a returnat `None`, deci este în regulă.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}