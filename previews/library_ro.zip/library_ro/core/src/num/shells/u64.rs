//! Constante pentru tipul de număr întreg nesemnat pe 64 de biți.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Noul cod ar trebui să utilizeze constantele asociate direct pe tipul primitiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }