//! Constantele pentru tipul întreg nesemnat de dimensiune pointer.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Noul cod ar trebui să utilizeze constantele asociate direct pe tipul primitiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }