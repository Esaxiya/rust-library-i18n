//! Constante pentru tipul întreg semnat pe 128 de biți.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Noul cod ar trebui să utilizeze constantele asociate direct pe tipul primitiv.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }