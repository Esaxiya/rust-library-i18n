//! Constante pentru tipul întreg nesemnat pe 16 biți.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Noul cod ar trebui să utilizeze constantele asociate direct pe tipul primitiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }