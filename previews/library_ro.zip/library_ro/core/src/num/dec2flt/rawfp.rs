//! Bit lăudă pe flotante IEEE 754 pozitive.Numerele negative nu sunt și nu trebuie tratate.
//! Numerele normale în virgulă mobilă au o reprezentare canonică ca (frac, exp) astfel încât valoarea este 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) unde N este numărul de biți.
//!
//! Subnormalii sunt ușor diferiți și ciudați, dar se aplică același principiu.
//!
//! Totuși, aici îi reprezentăm ca (sig, k) cu f pozitiv, astfel încât valoarea este f *
//! 2 <sup>e</sup> .În afară de a face "hidden bit" explicit, acest lucru schimbă exponentul prin așa-numita mantissa shift.
//!
//! Altfel spus, în mod normal floats sunt scrise ca (1), dar aici sunt scrise ca (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Numim (1)**reprezentarea fracțională** și (2)**reprezentarea integrală**.
//!
//! Multe funcții din acest modul gestionează numai numerele normale.Rutinele dec2flt iau conservator calea lentă corectă universal (algoritmul M) pentru numere foarte mici și foarte mari.
//! Acest algoritm are nevoie doar de next_float() care se ocupă de subnormale și zerouri.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Un ajutor trait pentru a evita duplicarea practic a întregului cod de conversie pentru `f32` și `f64`.
///
/// Consultați comentariul doc al modulului părinte pentru a afla de ce este necesar acest lucru.
///
/// **Nu ar trebui niciodată** să fie implementat niciodată pentru alte tipuri sau să fie utilizat în afara modulului dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipul folosit de `to_bits` și `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Efectuează o transmutație brută la un întreg.
    fn to_bits(self) -> Self::Bits;

    /// Efectuează o transmutație brută dintr-un număr întreg.
    fn from_bits(v: Self::Bits) -> Self;

    /// Returnează categoria în care se încadrează acest număr.
    fn classify(self) -> FpCategory;

    /// Returnează mantisa, exponentul și semnul ca numere întregi.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodează plutitorul.
    fn unpack(self) -> Unpacked;

    /// Distribuie dintr-un număr întreg mic care poate fi reprezentat exact.
    /// Panic dacă numărul întreg nu poate fi reprezentat, celălalt cod din acest modul se asigură că nu lăsați acest lucru să se întâmple niciodată.
    fn from_int(x: u64) -> Self;

    /// Obține valoarea 10 <sup>e</sup> dintr-un tabel precalculat.
    /// Panics pentru `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ce spune numele.
    /// Este mai ușor să faci codul greu decât să jonglezi cu intrinsecele și să speri că LLVM constanta îl va plia.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // O legătură conservatoare pe cifrele zecimale ale intrărilor care nu pot produce depășire sau zero sau
    /// subnormali.Probabil exponentul zecimal al valorii normale maxime, de unde și numele.
    const MAX_NORMAL_DIGITS: usize;

    /// Când cea mai semnificativă cifră zecimală are o valoare de poziție mai mare decât aceasta, numărul este cu siguranță rotunjit la infinit.
    ///
    const INF_CUTOFF: i64;

    /// Când cea mai semnificativă cifră zecimală are o valoare de poziție mai mică decât aceasta, numărul este cu siguranță rotunjit la zero.
    ///
    const ZERO_CUTOFF: i64;

    /// Numărul de biți din exponent.
    const EXP_BITS: u8;

    /// Numărul de biți din semnificație,*inclusiv* bitul ascuns.
    const SIG_BITS: u8;

    /// Numărul de biți din semnificație,*excluzând* bitul ascuns.
    const EXPLICIT_SIG_BITS: u8;

    /// Exponentul legal maxim în reprezentarea fracționată.
    const MAX_EXP: i16;

    /// Exponentul legal minim în reprezentarea fracționată, cu excepția subnormalilor.
    const MIN_EXP: i16;

    /// `MAX_EXP` pentru reprezentare integrală, adică cu schimbarea aplicată.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` codificat (adică, cu prejudecată compensată)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` pentru reprezentare integrală, adică cu schimbarea aplicată.
    const MIN_EXP_INT: i16;

    /// Semnificația maximă normalizată în reprezentarea integrală.
    const MAX_SIG: u64;

    /// Semnificația minimă normalizată în reprezentarea integrală.
    const MIN_SIG: u64;
}

// În principal, o soluție pentru #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Returnează mantisa, exponentul și semnul ca numere întregi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Biasă componentă + schimbare mantisă
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe nu este sigur dacă `as` se rotunde corect pe toate platformele.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Returnează mantisa, exponentul și semnul ca numere întregi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Biasă componentă + schimbare mantisă
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe nu este sigur dacă `as` se rotunde corect pe toate platformele.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Convertește un `Fp` în cel mai apropiat tip de plutitor al mașinii.
/// Nu gestionează rezultatele subnormale.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f are 64 de biți, deci xe are o schimbare de mantisă de 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Rotunjește semnificația pe 64 de biți la biții T::SIG_BITS cu jumătate până la egal.
/// Nu gestionează depășirea exponenților.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajustați schimbarea mantissei
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inversul `RawFloat::unpack()` pentru numerele normalizate.
/// Panics dacă semnificația sau exponentul nu sunt valabile pentru numerele normalizate.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Eliminați bitul ascuns
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Reglați exponentul pentru tendința exponentului și pentru schimbarea mantissei
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lăsați bitul de semn la 0 ("+"), numerele noastre sunt toate pozitive
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Construiți un subnormal.O mantisă de 0 este permisă și construiește zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Exponentul codat este 0, bitul de semn este 0, deci trebuie doar să reinterpretăm biții.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Aproximează un bignum cu Fp.Rundă în 0.5 ULP cu jumătate până la egal.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Întrerupem toți biții înainte de indexul `start`, adică schimbăm efectiv dreapta cu o cantitate de `start`, deci acesta este și exponentul de care avem nevoie.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rotund (half-to-even) în funcție de biții trunchiați.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Găsește cel mai mare număr în virgulă mobilă strict mai mic decât argumentul.
/// Nu gestionează subnormali, zero sau exponenți.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Găsiți cel mai mic număr în virgulă mobilă strict mai mare decât argumentul.
// Această operație este saturată, adică next_float(inf) ==inf.
// Spre deosebire de majoritatea codului din acest modul, această funcție gestionează zero, subnormali și infinit.
// Cu toate acestea, la fel ca toate celelalte coduri de aici, nu tratează NaN și numerele negative.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Acest lucru pare prea bun pentru a fi adevărat, dar funcționează.
        // 0.0 este codificat ca cuvântul zero.Subnormalii sunt 0x000m ... m unde m este mantisa.
        // În special, cel mai mic subnormal este 0x0 ... 01 și cel mai mare este 0x000F ... F.
        // Cel mai mic număr normal este 0x0010 ... 0, deci și această carcasă de colț funcționează.
        // Dacă creșterea deversează mantisa, bitul de transport mărește exponentul așa cum dorim, iar biții de mantissa devin zero.
        // Datorită convenției de biți ascunși, și asta este exact ceea ce ne dorim!
        // În cele din urmă, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}