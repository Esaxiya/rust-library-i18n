//! Diferitii algoritmi din hârtie.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Numărul de biți de semnificație în Fp
const P: u32 = 64;

// Stocăm pur și simplu cea mai bună aproximare pentru *toți* exponenții, astfel încât variabila "h" și condițiile asociate pot fi omise.
// Acest lucru schimbă performanța pentru câteva kilobyți de spațiu.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// În majoritatea arhitecturilor, operațiile în virgulă mobilă au o dimensiune de biți explicită, prin urmare precizia calculului este determinată pe bază de operație.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Pe x86, x87 FPU este utilizat pentru operații plutitoare dacă extensiile SSE/SSE2 nu sunt disponibile.
// x87 FPU funcționează cu 80 de biți de precizie în mod implicit, ceea ce înseamnă că operațiile se rotunjesc la 80 de biți, determinând rotunjirea dublă atunci când valorile sunt reprezentate în cele din urmă ca
//
// 32/64 valori float de biți.Pentru a depăși acest lucru, cuvântul de control FPU poate fi setat astfel încât calculele să fie efectuate în precizia dorită.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// O structură utilizată pentru a păstra valoarea inițială a cuvântului de control FPU, astfel încât să poată fi restaurată când structura este abandonată.
    ///
    ///
    /// x87 FPU este un registru pe 16 biți ale cărui câmpuri sunt după cum urmează:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Documentația pentru toate câmpurile este disponibilă în IA-32 Architectures Software Developer's Manual (Volumul 1).
    ///
    /// Singurul câmp relevant pentru următorul cod este PC, Precision Control.
    /// Acest câmp determină precizia operațiunilor efectuate de FPU.
    /// Poate fi setat la:
    ///  - 0b00, o singură precizie, adică 32 de biți
    ///  - 0b10, precizie dublă, adică 64 de biți
    ///  - 0b11, precizie dublă extinsă, adică 80 de biți (stare implicită) Valoarea 0b01 este rezervată și nu ar trebui utilizată.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SIGURANȚĂ: instrucțiunea `fldcw` a fost auditată pentru a putea funcționa corect cu
        // orice `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Folosim sintaxa ATT pentru a susține LLVM 8 și LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Setează câmpul de precizie al FPU la `T` și returnează un `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calculați valoarea pentru câmpul Precision Control care este adecvat pentru `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 de biți
            8 => 0x0200, // 64 de biți
            _ => 0x0300, // implicit, 80 de biți
        };

        // Obțineți valoarea originală a cuvântului de control pentru ao restabili mai târziu, când structura `FPUControlWord` este abandonată SIGURANȚĂ: instrucțiunea `fnstcw` a fost auditată pentru a putea funcționa corect cu orice `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Folosim sintaxa ATT pentru a susține LLVM 8 și LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Setați cuvântul de control la precizia dorită.
        // Acest lucru se realizează mascând vechea precizie (biții 8 și 9, 0x300) și înlocuind-o cu steagul de precizie calculat mai sus.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Calea rapidă a lui Bellerophon folosind numere întregi și plutitoare de dimensiuni mașină.
///
/// Aceasta este extrasă într-o funcție separată, astfel încât să poată fi încercată înainte de a construi un bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Comparăm valoarea exactă cu MAX_SIG aproape de sfârșit, aceasta este doar o respingere rapidă și ieftină (și, de asemenea, eliberează restul codului de a vă face griji cu privire la scufundare).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Calea rapidă depinde în mod crucial de faptul că aritmetica este rotunjită la numărul corect de biți fără nici o rotunjire intermediară.
    // Pe x86 (fără SSE sau SSE2) acest lucru necesită modificarea preciziei stivei x87 FPU, astfel încât să se rotunjească direct la bitul 64/32.
    // Funcția `set_precision` se ocupă de setarea preciziei pe arhitecturi care necesită setarea acesteia prin schimbarea stării globale (cum ar fi cuvântul de control al x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Cazul e <0 nu poate fi pliat în celălalt branch.
    // Puterile negative au ca rezultat o parte fracțională repetată în binar, care sunt rotunjite, ceea ce provoacă erori reale (și uneori destul de semnificative!) În rezultatul final.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritmul Bellerophon este un cod trivial justificat prin analize numerice non-triviale.
///
/// Se rotunjește "f" la un float cu semnificație pe 64 de biți și îl înmulțește cu cea mai bună aproximare a `10^e` (în același format în virgulă mobilă).Acest lucru este adesea suficient pentru a obține rezultatul corect.
/// Cu toate acestea, atunci când rezultatul este aproape la jumătatea distanței dintre două plutitoare (ordinary) adiacente, eroarea de rotunjire compusă din multiplicarea a două aproximări înseamnă că rezultatul poate fi oprit cu câțiva biți.
/// Când se întâmplă acest lucru, algoritmul iterativ R remediază lucrurile.
///
/// "close to halfway" ondulat manual este precis prin analiza numerică din lucrare.
/// În cuvintele lui Clinger:
///
/// > Slop, exprimat în unități de cel mai puțin semnificativ bit, este o limitare inclusivă pentru eroare
/// > acumulat în timpul calculului în virgulă mobilă a aproximării la f * 10 ^ e.(Slop este
/// > nu este o legătură pentru adevărata eroare, ci limitează diferența dintre aproximarea z și
/// > cea mai bună aproximare posibilă care folosește p biți de semnificație.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Cazurile abs(e) <log5(2^N) sunt în fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Panta este suficient de mare pentru a face diferența atunci când se rotunjește la n biți?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Un algoritm iterativ care îmbunătățește o aproximare în virgulă mobilă a `f * 10^e`.
///
/// Fiecare iterație se apropie de o unitate în ultimul loc, ceea ce, bineînțeles, durează foarte mult pentru a converge dacă `z0` este chiar ușor oprit.
/// Din fericire, când este utilizată ca alternativă pentru Bellerophon, aproximarea inițială este dezactivată de cel mult un ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Găsiți numere întregi pozitive `x`, `y` astfel încât `x / y` să fie exact `(f *10^e) / (m* 2^k)`.
        // Acest lucru nu numai că evită să se ocupe de semnele `e` și `k`, ci eliminăm și puterea a două comune `10^e` și `2^k` pentru a micșora numerele.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Acest lucru este scris puțin ciudat, deoarece bignumurile noastre nu acceptă cifre negative, așa că folosim informațiile despre valoarea absolută + semn.
        // Înmulțirea cu m_digits nu poate revărsa.
        // Dacă `x` sau `y` sunt suficient de mari încât trebuie să ne facem griji cu privire la revărsare, atunci sunt și ele suficient de mari încât `make_ratio` să reducă fracția cu un factor de 2 ^ 64 sau mai mult.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Nu mai aveți nevoie de x, salvați un clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Mai ai nevoie de tine, fă o copie.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Având în vedere `x = f` și `y = m`, unde `f` reprezintă cifre zecimale de intrare ca de obicei și `m` este semnificația unei aproximări în virgulă mobilă, faceți raportul `x / y` egal cu `(f *10^e) / (m* 2^k)`, posibil redus cu o putere de două amândouă au în comun.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, cu excepția faptului că reducem fracția cu o anumită putere a două.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Acest lucru nu se poate revărsa deoarece necesită `e` pozitiv și `k` negativ, ceea ce se poate întâmpla numai pentru valori extrem de apropiate de 1, ceea ce înseamnă că `e` și `k` vor fi relativ mici.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Nici acest lucru nu poate deborda, vezi mai sus.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), reducând din nou cu o putere comună de două.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceptual, algoritmul M este cel mai simplu mod de a converti o zecimală în float.
///
/// Formăm un raport care este egal cu `f * 10^e`, apoi aruncăm puteri de două până când dă un semn valabil valabil.
/// Exponentul binar `k` este de câte ori am înmulțit numărătorul sau numitorul cu doi, adică în orice moment `f *10^e` este egal cu `(u / v)* 2^k`.
/// Când am aflat semnificația, trebuie doar să rotunjim examinând restul diviziunii, care se face în funcțiile de ajutor mai jos.
///
///
/// Acest algoritm este foarte lent, chiar și cu optimizarea descrisă în `quick_start()`.
/// Cu toate acestea, este cel mai simplu dintre algoritmi să se adapteze pentru rezultate de revărsare, scurgere și subnormale.
/// Această implementare preia atunci când Bellerophon și Algorithm R sunt copleșiți.
/// Detectarea debitului și a revărsării este ușoară: raportul nu este încă un semn al domeniului, dar exponentul minimum/maximum a fost atins.
/// În cazul revărsării, returnăm pur și simplu infinitul.
///
/// Manipularea debitului și a subnormalelor este mai dificilă.
/// O mare problemă este că, cu exponentul minim, raportul ar putea fi în continuare prea mare pentru o semnificație.
/// Consultați underflow() pentru detalii.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME posibilă optimizare: generalizați big_to_fp astfel încât să putem face echivalentul fp_to_float(big_to_fp(u)) aici, numai fără rotunjirea dublă.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Trebuie să ne oprim la exponentul minim, dacă așteptăm până la `k < T::MIN_EXP_INT`, atunci ne-am opri cu un factor de doi.
            // Din păcate, acest lucru înseamnă că trebuie să facem cazuri speciale cu numere normale cu exponentul minim.
            // FIXME găsește o formulare mai elegantă, dar rulați testul `tiny-pow10` pentru a vă asigura că este de fapt corect!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Trece peste majoritatea M iterațiilor algoritmului verificând lungimea biților.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Lungimea biților este o estimare a logaritmului de bază doi și log(u / v) = log(u), log(v).
    // Estimarea este dezactivată de cel mult 1, dar întotdeauna o subestimare, astfel încât erorile de pe log(u) și log(v) au același semn și se anulează (dacă ambele sunt mari).
    // Prin urmare, eroarea pentru log(u / v) este cel mult una.
    // Raportul țintă este unul în care u/v este într-un domeniu semnificativ.Astfel, starea noastră de terminare este log2(u / v) fiind biții semnificanți, plus/minus unul.
    // FIXME Privind la cel de-al doilea bit, s-ar putea îmbunătăți estimarea și s-ar putea evita alte diviziuni.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow sau subnormal.Lăsați-l pe funcția principală.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Revărsare.Lăsați-l pe funcția principală.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Raportul nu este o semnificație și un exponent minim, așa că trebuie să rotunjim excesul de biți și să ajustăm exponentul în consecință.
    // Valoarea reală arată acum:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(reprezentat prin rem)
    //
    // Prin urmare, când biții rotunjiți sunt!= 0.5 ULP, ei decid rotunjirea singuri.
    // Când sunt egale și restul este diferit de zero, valoarea trebuie totuși rotunjită în sus.
    // Doar atunci când biții rotunjiți sunt 1/2 și restul este zero, avem o situație de jumătate până la egal.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Rundă obișnuită, uniformă, obscurizată prin nevoia de rotunjire pe baza restului unei diviziuni.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}