//! Funcții de utilitate pentru bignumuri care nu au prea mult sens să se transforme în metode.

// FIXME Numele acestui modul este puțin regretabil, deoarece alte module importă și `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Testați dacă trunchierea tuturor biților mai puțin semnificativi decât `ones_place` introduce o eroare relativă mai mică, egală sau mai mare decât 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Dacă toți biții rămași sunt zero, este= 0.5 ULP, în caz contrar> 0.5 Dacă nu mai sunt biți (half_bit==0), de mai jos se întoarce corect Egal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Convertește un șir ASCII care conține doar cifre zecimale într-un `u64`.
///
/// Nu efectuează verificări pentru depășirea sau caracterele nevalide, deci dacă apelantul nu este atent, rezultatul este fals și poate panic (deși nu va fi `unsafe`).
/// În plus, șirurile goale sunt tratate ca zero.
/// Această funcție există pentru că
///
/// 1. utilizarea `FromStr` pe `&[u8]` necesită `from_utf8_unchecked`, care este rău, și
/// 2. Asocierea rezultatelor `integral.parse()` și `fractional.parse()` este mai complicată decât această întreagă funcție.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Convertește un șir de cifre ASCII într-un bignum.
///
/// La fel ca `from_str_unchecked`, această funcție se bazează pe analizor pentru a elimina non-cifre.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Desface un bignum într-un număr întreg de 64 de biți.Panics dacă numărul este prea mare.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrage o gamă de biți.

/// Indexul 0 este cel mai puțin semnificativ bit, iar intervalul este pe jumătate deschis ca de obicei.
/// Panics dacă i se cere să extragă mai mulți biți decât se încadrează în tipul de returnare.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}