//! Tipuri de erori pentru conversia în tipuri integrale.

use crate::convert::Infallible;
use crate::fmt;

/// Tipul de eroare returnat atunci când o conversie de tip integral verificată eșuează.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Potriviți mai degrabă decât constrângeți pentru a vă asigura că codul precum `From<Infallible> for TryFromIntError` de mai sus va continua să funcționeze atunci când `Infallible` devine un alias la `!`.
        //
        //
        match never {}
    }
}

/// O eroare care poate fi returnată la analizarea unui număr întreg.
///
/// Această eroare este utilizată ca tip de eroare pentru funcțiile `from_str_radix()` pe tipurile întregi primitive, cum ar fi [`i8::from_str_radix`].
///
/// # Cauze potențiale
///
/// Printre alte cauze, `ParseIntError` poate fi aruncat din cauza spațiului alb principal sau final în șir, de exemplu, atunci când este obținut din intrarea standard.
///
/// Utilizarea metodei [`str::trim()`] vă asigură că nu rămâne spațiu alb înainte de analiză.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum pentru a stoca diferitele tipuri de erori care pot provoca eșecul analizei unui întreg.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Valoarea analizată este goală.
    ///
    /// Printre alte cauze, această variantă va fi construită atunci când se analizează un șir gol.
    Empty,
    /// Conține o cifră nevalidă în contextul său.
    ///
    /// Printre alte cauze, această variantă va fi construită atunci când se analizează un șir care conține un caracter non-ASCII.
    ///
    /// Această variantă este, de asemenea, construită atunci când un `+` sau `-` este plasat greșit într-un șir fie singur, fie în mijlocul unui număr.
    ///
    ///
    InvalidDigit,
    /// Numărul întreg este prea mare pentru a fi stocat în tipul întreg țintă.
    PosOverflow,
    /// Numărul întreg este prea mic pentru a fi stocat în tipul întreg țintă.
    NegOverflow,
    /// Valoarea a fost zero
    ///
    /// Această variantă va fi emisă atunci când șirul de analiză are o valoare zero, ceea ce ar fi ilegal pentru tipurile diferite de zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Afișează cauza detaliată a analizei unui număr întreg care eșuează.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}