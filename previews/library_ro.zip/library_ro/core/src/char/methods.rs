//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Cel mai înalt punct de cod valid pe care îl poate avea un `char`.
    ///
    /// Un `char` este un [Unicode Scalar Value], ceea ce înseamnă că este un [Code Point], dar numai unul dintr-un anumit interval.
    /// `MAX` este cel mai înalt punct de cod valid care este un [Unicode Scalar Value] valid.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () este utilizat în Unicode pentru a reprezenta o eroare de decodare.
    ///
    /// Poate apărea, de exemplu, atunci când se acordă octeți UTF-8 neformați la [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Versiunea [Unicode](http://www.unicode.org/) pe care se bazează părțile Unicode ale metodelor `char` și `str`.
    ///
    /// Noile versiuni ale Unicode sunt lansate în mod regulat și ulterior toate metodele din biblioteca standard, în funcție de Unicode, sunt actualizate.
    /// Prin urmare, comportamentul unor metode `char` și `str` și valoarea acestei constante se modifică în timp.
    /// Acest lucru nu este * considerat a fi o schimbare de rupere.
    ///
    /// Schema de numerotare a versiunilor este explicată în [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Creează un iterator peste punctele codate codate UTF-16 în `iter`, returnând surogatele nepereche ca `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Un decodor cu pierderi poate fi obținut prin înlocuirea rezultatelor `Err` cu caracterul de înlocuire:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Convertește un `u32` într-un `char`.
    ///
    /// Rețineți că toate `char`s sunt valide [`u32`] s și pot fi aruncate la unul cu
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Cu toate acestea, inversul nu este adevărat: nu toate [`u32`] valide sunt`char`s valide.
    /// `from_u32()` va returna `None` dacă intrarea nu este o valoare validă pentru un `char`.
    ///
    /// Pentru o versiune nesigură a acestei funcții care ignoră aceste verificări, consultați [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Se returnează `None` când intrarea nu este un `char` valid:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Convertește un `u32` într-un `char`, ignorând validitatea.
    ///
    /// Rețineți că toate `char`s sunt valide [`u32`] s și pot fi aruncate la unul cu
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Cu toate acestea, inversul nu este adevărat: nu toate [`u32`] valide sunt`char`s valide.
    /// `from_u32_unchecked()` va ignora acest lucru și va arunca orbește la `char`, creând posibil unul nevalid.
    ///
    ///
    /// # Safety
    ///
    /// Această funcție nu este sigură, deoarece poate crea valori `char` nevalide.
    ///
    /// Pentru o versiune sigură a acestei funcții, consultați funcția [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SIGURANȚĂ: contractul de siguranță trebuie confirmat de către apelant.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Convertește o cifră din radioul dat într-un `char`.
    ///
    /// Un 'radix' aici este uneori numit și 'base'.
    /// O rază de două indică un număr binar, o rază de zece, zecimală și o rază de șaisprezece, hexazecimală, pentru a da câteva valori comune.
    ///
    /// Radisurile arbitrare sunt acceptate.
    ///
    /// `from_digit()` va returna `None` dacă intrarea nu este o cifră în raza dată.
    ///
    /// # Panics
    ///
    /// Panics dacă i se dă o rază mai mare de 36.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Zecimalul 11 este o singură cifră în baza 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Returnarea `None` când intrarea nu este o cifră:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Trecerea unui radix mare, provocând un panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Verifică dacă un `char` este o cifră în raza dată.
    ///
    /// Un 'radix' aici este uneori numit și 'base'.
    /// O rază de două indică un număr binar, o rază de zece, zecimală și o rază de șaisprezece, hexazecimală, pentru a da câteva valori comune.
    ///
    /// Radisurile arbitrare sunt acceptate.
    ///
    /// Comparativ cu [`is_numeric()`], această funcție recunoaște doar caracterele `0-9`, `a-z` și `A-Z`.
    ///
    /// 'Digit' este definit ca fiind doar următoarele caractere:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Pentru o înțelegere mai cuprinzătoare a 'digit', consultați [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics dacă i se dă o rază mai mare de 36.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Trecerea unui radix mare, provocând un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Convertește un `char` într-o cifră în raza dată.
    ///
    /// Un 'radix' aici este uneori numit și 'base'.
    /// O rază de două indică un număr binar, o rază de zece, zecimală și o rază de șaisprezece, hexazecimală, pentru a da câteva valori comune.
    ///
    /// Radisurile arbitrare sunt acceptate.
    ///
    /// 'Digit' este definit ca fiind doar următoarele caractere:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Returnează `None` dacă `char` nu se referă la o cifră din raza dată.
    ///
    /// # Panics
    ///
    /// Panics dacă i se dă o rază mai mare de 36.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Trecerea unei cifre fără cifre duce la eșec:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Trecerea unui radix mare, provocând un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // codul este împărțit aici pentru a îmbunătăți viteza de execuție pentru cazurile în care `radix` este constant și 10 sau mai mic
        //
        let val = if likely(radix <= 10) {
            // Dacă nu o cifră, va fi creat un număr mai mare decât radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Returnează un iterator care produce scăderea hexadecimală Unicode a unui personaj ca `char`s.
    ///
    /// Aceasta va scăpa de caractere cu sintaxa Rust de forma `\u{NNNNNN}` unde `NNNNNN` este o reprezentare hexazecimală.
    ///
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // sau-ing 1 se asigură că pentru c==0 codul calculează că o cifră ar trebui tipărită și (care este același) evită (31, 32) fluxul inferior
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indicele celei mai semnificative cifre hex
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// O versiune extinsă a `escape_debug` care, opțional, permite evadarea punctelor de cod Extended Grapheme.
    /// Acest lucru ne permite să formatăm mai bine caractere precum semnele fără spațiu atunci când sunt la începutul unui șir.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Returnează un iterator care dă codul literal de evadare al unui caracter ca " char`s.
    ///
    /// Aceasta va scăpa de caracterele similare cu implementările `Debug` ale `str` sau `char`.
    ///
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Returnează un iterator care dă codul literal de evadare al unui caracter ca " char`s.
    ///
    /// Valoarea implicită este aleasă cu o tendință spre producerea literelor care sunt legale într-o varietate de limbi, inclusiv C++ 11 și limbaje similare ale familiei C.
    /// Regulile exacte sunt:
    ///
    /// * Fila este scăpată ca `\t`.
    /// * Returul transportului este scăpat ca `\r`.
    /// * Alimentarea de linie este scăpată ca `\n`.
    /// * Devizul unic este scăpat ca `\'`.
    /// * Cota dublă este evitată ca `\"`.
    /// * Backslash este scăpat ca `\\`.
    /// * Orice caracter din intervalul " ASCII imprimabil` `0x20` .. `0x7e` inclusiv nu este scăpat.
    /// * Toate celelalte caractere au scăpări Unicode hexazecimale;vezi [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Returnează numărul de octeți de care acest `char` ar avea nevoie dacă este codat în UTF-8.
    ///
    /// Acest număr de octeți este întotdeauna între 1 și 4, inclusiv.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Tipul `&str` garantează că conținutul său este UTF-8 și, astfel, putem compara lungimea pe care ar lua-o dacă fiecare punct de cod ar fi reprezentat ca un `char` față de `&str` în sine:
    ///
    ///
    /// ```
    /// // ca caractere
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ambele pot fi reprezentate ca trei octeți
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ca un &str, aceste două sunt codificate în UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // putem vedea că au nevoie de șase octeți în total ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... la fel ca &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Returnează numărul de unități de cod pe 16 biți de care `char` ar avea nevoie dacă este codat în UTF-16.
    ///
    ///
    /// Consultați documentația pentru [`len_utf8()`] pentru mai multe explicații despre acest concept.
    /// Această funcție este o oglindă, dar pentru UTF-16 în loc de UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Codifică acest caracter ca UTF-8 în bufferul de octeți furnizat și apoi returnează subslice-ul bufferului care conține caracterul codat.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă tamponul nu este suficient de mare.
    /// Un tampon cu lungimea patru este suficient de mare pentru a codifica orice `char`.
    ///
    /// # Examples
    ///
    /// În ambele exemple, 'ß' necesită doi octeți pentru a codifica.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un tampon prea mic:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SIGURANȚĂ: `char` nu este un surogat, deci este valabil UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Codifică acest caracter ca UTF-16 în bufferul `u16` furnizat și apoi returnează subslice-ul bufferului care conține caracterul codat.
    ///
    ///
    /// # Panics
    ///
    /// Panics dacă tamponul nu este suficient de mare.
    /// Un tampon de lungime 2 este suficient de mare pentru a codifica orice `char`.
    ///
    /// # Examples
    ///
    /// În ambele exemple, '𝕊' necesită două coduri `u16`.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un tampon prea mic:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Returnează `true` dacă acest `char` are proprietatea `Alphabetic`.
    ///
    /// `Alphabetic` este descris în Capitolul 4 (Proprietăți caracter) al [Unicode Standard] și specificat în [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // dragostea este multe lucruri, dar nu este alfabetică
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Returnează `true` dacă acest `char` are proprietatea `Lowercase`.
    ///
    /// `Lowercase` este descris în Capitolul 4 (Proprietăți caracter) al [Unicode Standard] și specificat în [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Diferitele scripturi și punctuații chinezești nu au majuscule și așa:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Returnează `true` dacă acest `char` are proprietatea `Uppercase`.
    ///
    /// `Uppercase` este descris în Capitolul 4 (Proprietăți caracter) al [Unicode Standard] și specificat în [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Diferitele scripturi și punctuații chinezești nu au majuscule și așa:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Returnează `true` dacă acest `char` are proprietatea `White_Space`.
    ///
    /// `White_Space` este specificat în [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // un spațiu care nu se sparge
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Returnează `true` dacă acest `char` satisface fie [`is_alphabetic()`], fie [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Returnează `true` dacă acest `char` are categoria generală pentru codurile de control.
    ///
    /// Codurile de control (punctele de cod cu categoria generală `Cc`) sunt descrise în Capitolul 4 (Proprietăți caracter) ale [Unicode Standard] și sunt specificate în [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // U + 009C, TERMINATOR STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Returnează `true` dacă acest `char` are proprietatea `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` este descris în [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] și specificat în [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Returnează `true` dacă acest `char` are una dintre categoriile generale pentru numere.
    ///
    /// Categoriile generale pentru numere (`Nd` pentru cifre zecimale, `Nl` pentru caractere numerice asemănătoare literelor și `No` pentru alte caractere numerice) sunt specificate în [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Returnează un iterator care produce maparea cu litere mici a acestui `char` ca una sau mai multe
    /// `char`s.
    ///
    /// Dacă acest `char` nu are o mapare cu litere mici, iteratorul produce același `char`.
    ///
    /// Dacă acest `char` are o mapare minusculă unu-la-unu dată de [Unicode Character Database][ucd] [`UnicodeData.txt`], iteratorul produce acel `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Dacă acest `char` necesită considerații speciale (de exemplu, mai multe `char`s) iteratorul produce" char` (uri) date de [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Această operațiune efectuează o mapare necondiționată fără croială.Adică, conversia este independentă de context și limbaj.
    ///
    /// În [Unicode Standard], Capitolul 4 (Proprietăți caracter) discută maparea cazurilor în general și Capitolul 3 (Conformance) discută algoritmul implicit pentru conversia cazurilor.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Uneori rezultatul este mai mult de un personaj:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Caracterele care nu au atât majuscule, cât și minuscule se convertesc în ele însele.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Returnează un iterator care produce maparea cu majuscule a acestui `char` ca una sau mai multe
    /// `char`s.
    ///
    /// Dacă acest `char` nu are o mapare cu majuscule, iteratorul produce același `char`.
    ///
    /// Dacă acest `char` are o mapare majusculă unu-la-unu dată de [Unicode Character Database][ucd] [`UnicodeData.txt`], iteratorul dă acel `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Dacă acest `char` necesită considerații speciale (de exemplu, mai multe `char`s) iteratorul produce" char` (uri) date de [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Această operațiune efectuează o mapare necondiționată fără croială.Adică, conversia este independentă de context și limbaj.
    ///
    /// În [Unicode Standard], Capitolul 4 (Proprietăți caracter) discută maparea cazurilor în general și Capitolul 3 (Conformance) discută algoritmul implicit pentru conversia cazurilor.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ca iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizarea directă a `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ambele sunt echivalente cu:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Folosind `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Uneori rezultatul este mai mult de un personaj:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Caracterele care nu au atât majuscule, cât și minuscule se convertesc în ele însele.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Notă despre localizare
    ///
    /// În turcă, echivalentul lui 'i' în latină are cinci forme în loc de două:
    ///
    /// * 'Dotless': I/ı, uneori scris ï
    /// * 'Dotted': İ/i
    ///
    /// Rețineți că 'i' punctat cu litere mici este același cu latinul.Prin urmare:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Valoarea lui `upper_i` se bazează aici pe limba textului: dacă suntem în `en-US`, ar trebui să fie `"I"`, dar dacă suntem în `tr_TR`, ar trebui să fie `"İ"`.
    /// `to_uppercase()` nu ia în considerare acest lucru și astfel:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// deține mai multe limbi.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Verifică dacă valoarea se află în intervalul ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Face o copie a valorii în echivalentul ASCII cu majuscule.
    ///
    /// Literele ASCII 'a' la 'z' sunt mapate la 'A' la 'Z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a majuscula valoarea pe loc, utilizați [`make_ascii_uppercase()`].
    ///
    /// Pentru a majuscula caractere ASCII pe lângă caractere non-ASCII, utilizați [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Face o copie a valorii în echivalentul ASCII minuscul.
    ///
    /// Literele ASCII 'A' la 'Z' sunt mapate la 'a' la 'z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a utiliza valoarea minusculă pe loc, utilizați [`make_ascii_lowercase()`].
    ///
    /// Pentru a scrie minuscule caractere ASCII pe lângă caractere non-ASCII, utilizați [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Verifică dacă două valori sunt o potrivire ASCII care nu face sensibilitate la majuscule.
    ///
    /// Echivalent cu `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Convertește acest tip în echivalentul ASCII cu majuscule la locul său.
    ///
    /// Literele ASCII 'a' la 'z' sunt mapate la 'A' la 'Z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a returna o nouă valoare cu majusculă fără a o modifica pe cea existentă, utilizați [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Convertește acest tip în echivalentul său ASCII minuscul în loc.
    ///
    /// Literele ASCII 'A' la 'Z' sunt mapate la 'a' la 'z', dar literele non-ASCII sunt neschimbate.
    ///
    /// Pentru a returna o nouă valoare cu litere mici, fără a o modifica pe cea existentă, utilizați [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Verifică dacă valoarea este un caracter alfabetic ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' sau
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Verifică dacă valoarea este un caracter ASCII cu majuscule:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Verifică dacă valoarea este un caracter minuscul ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Verifică dacă valoarea este un caracter alfanumeric ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' sau
    /// - U + 0061 'a' ..=U + 007A 'z' sau
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Verifică dacă valoarea este o cifră zecimală ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Verifică dacă valoarea este o cifră hexazecimală ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' sau
    /// - U + 0041 'A' ..=U + 0046 'F' sau
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Verifică dacă valoarea este un caracter de punctuație ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` sau
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` sau
    /// - U + 005B ..=U + 0060 "[\] ^ _` `` sau
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Verifică dacă valoarea este un caracter grafic ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Verifică dacă valoarea este un caracter de spațiu ASCII:
    /// U + 0020 SPAȚIU, U + 0009 TAB ORIZONTAL, U + 000A ALIMENTARE LINIE, U + 000C ALIMENTARE FORMĂ sau U + 000D RETURNARE TRASPORT.
    ///
    /// Rust utilizează [definition of ASCII whitespace][infra-aw] al WhatWG Infra Standard.Există mai multe alte definiții în utilizare largă.
    /// De exemplu, [the POSIX locale][pct] include U + 000B TAB VERTICAL, precum și toate caracterele de mai sus, dar-din aceeași specificație-[regula implicită pentru "field splitting" în Bourne shell][bfs] consideră *numai* SPACE, TAB HORIZONTAL și LINE FEED ca spațiu alb.
    ///
    ///
    /// Dacă scrieți un program care va procesa un format de fișier existent, verificați care este definiția acelui format al spațiului alb înainte de a utiliza această funcție.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Verifică dacă valoarea este un caracter de control ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARATOR DE UNITĂȚI sau U + 007F DELETE.
    /// Rețineți că majoritatea caracterelor de spațiu alb ASCII sunt caractere de control, dar SPACE nu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Codifică o valoare u32 brută ca UTF-8 în bufferul de octeți furnizat și apoi returnează subslice-ul bufferului care conține caracterul codificat.
///
///
/// Spre deosebire de `char::encode_utf8`, această metodă gestionează și punctele de cod din gama surogat.
/// (Crearea unui `char` în intervalul surogat este UB.) Rezultatul este [generalized UTF-8] valid, dar nu UTF-8 valid.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics dacă tamponul nu este suficient de mare.
/// Un tampon cu lungimea patru este suficient de mare pentru a codifica orice `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Codifică o valoare brută u32 ca UTF-16 în bufferul `u16` furnizat și apoi returnează subslice-ul bufferului care conține caracterul codificat.
///
///
/// Spre deosebire de `char::encode_utf16`, această metodă gestionează și punctele de cod din gama surogat.
/// (Crearea unui `char` în gama surogat este UB.)
///
/// # Panics
///
/// Panics dacă tamponul nu este suficient de mare.
/// Un tampon de lungime 2 este suficient de mare pentru a codifica orice `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SIGURANȚĂ: fiecare braț verifică dacă există destui biți în care să scrieți
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP cade
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Avioanele suplimentare se sparg în surogate.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}