//! Tipuri care fixează datele la locația sa în memorie.
//!
//! Uneori este util să aveți obiecte care nu au mișcare garantată, în sensul că plasarea lor în memorie nu se schimbă și, astfel, poate fi bazată pe.
//! Un prim exemplu al unui astfel de scenariu ar fi construirea de structuri auto-referențiale, deoarece mutarea unui obiect cu indicatori către el însuși le va invalida, ceea ce ar putea provoca un comportament nedefinit.
//!
//! La un nivel ridicat, un [`Pin<P>`] se asigură că pointee-ul oricărui tip de pointer `P` are o locație stabilă în memorie, ceea ce înseamnă că nu poate fi mutat în altă parte, iar memoria sa nu poate fi repartizată până când nu scade.Spunem că pointee este "pinned".Lucrurile devin mai subtile atunci când se discută despre tipurile care combină date fixate cu date care nu sunt fixate;[see below](#projections-and-structural-pinning) pentru mai multe detalii.
//!
//! În mod implicit, toate tipurile din Rust sunt mobile.
//! Rust permite transmiterea tuturor tipurilor de valori, iar tipurile obișnuite de indicatoare inteligente, cum ar fi [`Box<T>`] și `&mut T`, permit înlocuirea și mutarea valorilor pe care le conțin: puteți ieși dintr-un [`Box<T>`] sau puteți utiliza [`mem::swap`].
//! [`Pin<P>`] împachetează un pointer de tip `P`, deci [`Pin`]`<`[`Box`] `<T>>`funcționează la fel ca un obișnuit
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`este eliminat, la fel și conținutul său, iar memoria devine
//!
//! dezlocuit.În mod similar, [`Pin`]`<&mut T>`seamănă mult cu `&mut T`.Cu toate acestea, [`Pin<P>`] nu permite clienților să obțină de fapt un [`Box<T>`] sau `&mut T` la date fixate, ceea ce implică faptul că nu puteți utiliza operațiuni precum [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` are nevoie de `&mut T`, dar nu îl putem obține.
//!     // Suntem blocați, nu putem schimba conținutul acestor referințe.
//!     // Am putea folosi `Pin::get_unchecked_mut`, dar acest lucru nu este sigur dintr-un motiv:
//!     // nu avem voie să-l folosim pentru mutarea lucrurilor din `Pin`.
//! }
//! ```
//!
//! Merită să reiterăm faptul că [`Pin<P>`]*nu* schimbă faptul că un compilator Rust consideră toate tipurile mobile.[`mem::swap`] rămâne apelabil pentru orice `T`.În schimb, [`Pin<P>`] împiedică mutarea anumitor *valori*(indicate de indicii înfășurați în [`Pin<P>`]), făcând imposibilă apelarea metodelor care necesită `&mut T` (cum ar fi [`mem::swap`]).
//!
//! [`Pin<P>`] poate fi folosit pentru a înfășura orice tip de pointer `P` și, ca atare, interacționează cu [`Deref`] și [`DerefMut`].Un [`Pin<P>`] în care `P: Deref` ar trebui considerat ca un "`P`-style pointer" la un `P::Target` fixat-deci, un [`Pin`]`<`[`Box`] `<T>>`este un pointer deținut la un `T` fixat și un [`Pin`] `<` [`Rc`]`<T>>`este un indicator cu referință la un `T` fixat.
//! Pentru corectitudine, [`Pin<P>`] se bazează pe implementările [`Deref`] și [`DerefMut`] să nu se deplaseze din parametrul lor `self` și să returneze un pointer numai la datele fixate atunci când sunt apelate pe un pointer fixat.
//!
//! # `Unpin`
//!
//! Multe tipuri sunt întotdeauna libere, chiar și atunci când sunt fixate, deoarece nu se bazează pe o adresă stabilă.Aceasta include toate tipurile de bază (cum ar fi [`bool`], [`i32`] și referințe), precum și tipurile care constau exclusiv din aceste tipuri.Tipurile cărora nu le pasă de fixare implementează [`Unpin`] auto-trait, care anulează efectul [`Pin<P>`].
//! Pentru `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`și [`Box<T>`] funcționează identic, la fel ca [`Pin`] `<&mut T>` și `&mut T`.
//!
//! Rețineți că fixarea și [`Unpin`] afectează doar tipul `P::Target`, nu pointerul de tip `P` în sine care a fost înfășurat în [`Pin<P>`].De exemplu, dacă [`Box<T>`] este sau nu [`Unpin`] nu are niciun efect asupra comportamentului lui [`Pin`]`<`[`Box`] `<T>>`(aici, `T` este tipul indicat).
//!
//! # Exemplu: struct auto-referențial
//!
//! Înainte de a intra în mai multe detalii pentru a explica garanțiile și alegerile asociate cu `Pin<T>`, discutăm câteva exemple despre modul în care ar putea fi utilizat.
//! Simțiți-vă liber pentru [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Aceasta este o structură auto-referențială, deoarece câmpul felie indică câmpul de date.
//! // Nu putem informa compilatorul despre aceasta cu o referință normală, deoarece acest model nu poate fi descris cu regulile obișnuite de împrumut.
//! //
//! // În schimb, folosim un pointer brut, deși unul despre care se știe că nu este nul, așa cum știm că îndreaptă spre șir.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Pentru a ne asigura că datele nu se mișcă la revenirea funcției, le așezăm în heap unde vor rămâne pe durata de viață a obiectului și singura modalitate de accesare ar fi printr-un pointer către acesta.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // creăm indicatorul doar odată ce datele sunt la locul lor, altfel se va muta deja înainte de a începe
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // știm că acest lucru este sigur deoarece modificarea unui câmp nu mută întreaga structură
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Pointerul ar trebui să indice locația corectă, atâta timp cât structul nu s-a mișcat.
//! //
//! // Între timp, suntem liberi să mutăm indicatorul.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Deoarece tipul nostru nu implementează Unpin, acest lucru nu va reuși să compileze:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Exemplu: listă intruzivă cu dublă legătură
//!
//! Într-o listă intruzivă cu dublă legătură, colecția nu alocă de fapt memoria pentru elementele în sine.
//! Alocarea este controlată de clienți, iar elementele pot locui pe un cadru de stivă care trăiește mai scurt decât colecția.
//!
//! Pentru ca acest lucru să funcționeze, fiecare element are indicii către predecesorul și succesorul său din listă.Elementele pot fi adăugate numai atunci când sunt fixate, deoarece deplasarea elementelor în jur ar invalida pointerele.Mai mult decât atât, implementarea [`Drop`] a unui element de listă legată va corela indicațiile predecesorului și succesorului său pentru a se elimina din listă.
//!
//! În mod crucial, trebuie să ne putem baza pe apelarea [`drop`].Dacă un element ar putea fi repartizat sau invalidat în alt mod fără a apela [`drop`], indicatoarele din acesta din elementele învecinate ar deveni nevalide, ceea ce ar rupe structura datelor.
//!
//! Prin urmare, fixarea vine, de asemenea, cu o garanție legată de [" drop`].
//!
//! # `Drop` guarantee
//!
//! Scopul fixării este de a vă putea baza pe plasarea unor date în memorie.
//! Pentru ca acest lucru să funcționeze, nu doar mutarea datelor este restricționată;alocarea, reutilizarea sau invalidarea memoriei utilizate pentru stocarea datelor este restricționată, de asemenea.
//! Concret, pentru datele fixate trebuie să păstrați invariantul că *memoria sa nu va fi invalidată sau redistribuită din momentul în care este fixată până când se numește [`drop`]*.Numai după ce [`drop`] revine sau panics, memoria poate fi refolosită.
//!
//! Memoria poate fi "invalidated" prin repartizare, dar și prin înlocuirea unui [`Some(v)`] cu [`None`] sau apelând [`Vec::set_len`] la "kill" unele elemente dintr-un vector.Poate fi refăcut utilizând [`ptr::write`] pentru a-l suprascrie fără a apela mai întâi distructorul.Nimic din toate acestea nu este permis pentru datele fixate fără a apela [`drop`].
//!
//! Acesta este exact tipul de garanție că lista intruzivă legată din secțiunea anterioară trebuie să funcționeze corect.
//!
//! Observați că această garanție *nu* înseamnă că memoria nu se scurge!Este încă complet în regulă să nu apelați niciodată [`drop`] pe un element fixat (de exemplu, puteți apela în continuare [`mem::forget`] pe un [`Pin`]`<`[`Box`] `<T>>`).În exemplul listei cu două legături, acel element ar rămâne doar în listă.Cu toate acestea, nu puteți elibera sau refolosi spațiul de stocare *fără a apela [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Dacă tipul dvs. folosește fixarea (cum ar fi cele două exemple de mai sus), trebuie să fiți atenți atunci când implementați [`Drop`].Funcția [`drop`] ia `&mut self`, dar aceasta se numește *chiar dacă tipul dvs. a fost fixat anterior*!Este ca și cum compilatorul va numi automat [`Pin::get_unchecked_mut`].
//!
//! Acest lucru nu poate provoca niciodată o problemă în codul sigur deoarece implementarea unui tip care se bazează pe fixare necesită cod nesigur, dar rețineți că decideți să utilizați fixarea în tipul dvs. (de exemplu prin implementarea unor operații pe [`Pin`]`<&Self>`sau [`Pin`] `<&mut Self>`) are consecințe și pentru implementarea dvs. [`Drop`]: dacă un element de tipul dvs. ar fi putut fi fixat, trebuie să tratați [`Drop`] ca implicit luând [`Pin`]`<&mut Sinele>`.
//!
//!
//! De exemplu, puteți implementa `Drop` după cum urmează:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` este în regulă, deoarece știm că această valoare nu mai este folosită niciodată după ce a fost abandonată.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Codul drop real merge aici.
//!         }
//!     }
//! }
//! ```
//!
//! Funcția `inner_drop` are tipul pe care ar trebui să-l aibă [`drop`] *, deci acest lucru vă asigură că nu utilizați accidental `self`/`this` într-un mod care este în conflict cu fixarea.
//!
//! Mai mult, dacă tipul dvs. este `#[repr(packed)]`, compilatorul va muta automat câmpurile pentru a le putea renunța.S-ar putea chiar să facă acest lucru pentru câmpurile care se întâmplă să fie suficient aliniate.În consecință, nu puteți utiliza fixarea cu un tip `#[repr(packed)]`.
//!
//! # Proiecții și fixare structurală
//!
//! Când lucrați cu structuri fixate, apare întrebarea cum se poate accesa câmpurile structurii respective într-o metodă care ia doar [`Pin`]`<&mut Struct>`.
//! Abordarea obișnuită este de a scrie metode de ajutor (așa-numitele *proiecții*) care transformă [`Pin`]`<&mut Struct>`într-o referință la câmp, dar ce tip ar trebui să aibă această referință?Este [`Pin`]`<&mut Field>`sau `&mut Field`?
//! Aceeași întrebare apare cu câmpurile unui `enum` și, de asemenea, atunci când se iau în considerare tipurile container/wrapper, cum ar fi [`Vec<T>`], [`Box<T>`] sau [`RefCell<T>`].
//! (Această întrebare se aplică atât referințelor mutabile, cât și referințelor partajate, folosim doar cazul mai frecvent al referințelor mutabile aici pentru ilustrare.)
//!
//! Se pare că este de fapt autorul structurii de date să decidă dacă proiecția fixată pentru un anumit câmp transformă [`Pin`]`<&mut Struct>`în [`Pin`] `<&mut Field>` sau `&mut Field`.Există însă unele constrângeri și cea mai importantă constrângere este *consistența*:
//! fiecare câmp poate fi *fie* proiectat la o referință fixată,*fie* poate fi eliminat fixarea ca parte a proiecției.
//! Dacă ambele sunt realizate pentru același câmp, probabil că va fi nefondat!
//!
//! Ca autor al unei structuri de date, trebuie să decideți pentru fiecare câmp dacă fixați "propagates" la acest câmp sau nu.
//! Fixarea care se propagă este numită și "structural", deoarece urmează structura tipului.
//! În subsecțiunile următoare, descriem considerațiile care trebuie luate pentru fiecare alegere.
//!
//! ## Fixarea *nu este* structurală pentru `field`
//!
//! Poate părea contra-intuitiv că câmpul unei structuri fixate s-ar putea să nu fie fixat, dar aceasta este de fapt cea mai ușoară alegere: dacă nu se creează niciodată un [`Pin`]`<&mut Field>`, nimic nu poate merge prost!Deci, dacă decideți că un câmp nu are fixare structurală, tot ce trebuie să vă asigurați este că nu creați niciodată o referință fixată la acel câmp.
//!
//! Câmpurile fără fixare structurală pot avea o metodă de proiecție care transformă [`Pin`]`<&mut Struct>`în `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Acest lucru este în regulă, deoarece `field` nu este considerat niciodată fixat.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Puteți, de asemenea, `impl Unpin for Struct`*chiar dacă* tipul de `field` nu este [`Unpin`].Ceea ce crede acest tip despre fixare nu este relevant atunci când nu se creează niciodată [[Pin`]`<&mut Field>`.
//!
//! ## Fixarea *este* structurală pentru `field`
//!
//! Cealaltă opțiune este să decideți că fixarea este "structural" pentru `field`, ceea ce înseamnă că, dacă structura este fixată, la fel este și câmpul.
//!
//! Acest lucru permite scrierea unei proiecții care creează un [`Pin`]`<&mut Field>`, fiind astfel martor că câmpul este fixat:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Acest lucru este în regulă, deoarece `field` este fixat când `self` este.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Cu toate acestea, fixarea structurală vine cu câteva cerințe suplimentare:
//!
//! 1. Structura trebuie să fie [`Unpin`] numai dacă toate câmpurile structurale sunt [`Unpin`].Aceasta este valoarea implicită, dar [`Unpin`] este un trait sigur, deci, în calitate de autor al structului, este responsabilitatea dumneavoastră *nu* să adăugați ceva de genul `impl<T> Unpin for Struct<T>`.
//! (Observați că adăugarea unei operații de proiecție necesită cod nesigur, deci faptul că [`Unpin`] este un trait sigur nu încalcă principiul că trebuie să vă faceți griji în legătură cu oricare dintre acestea dacă utilizați " nesigur`.)
//! 2. Distructorul structurii nu trebuie să scoată câmpurile structurale din argumentul său.Acesta este punctul exact care a fost ridicat în [previous section][drop-impl]: `drop` ia `&mut self`, dar struct (și, prin urmare, câmpurile sale) ar fi putut fi fixat înainte.
//!     Trebuie să garantați că nu mutați un câmp în cadrul implementării [`Drop`].
//!     În special, așa cum am explicat anterior, acest lucru înseamnă că structura dvs. nu trebuie să fie * `#[repr(packed)]`.
//!     Consultați acea secțiune pentru a scrie cum să scrieți [`drop`] într-un mod în care compilatorul vă poate ajuta să nu rupeți accidental fixarea.
//! 3. Trebuie să vă asigurați că respectați [`Drop` guarantee][drop-guarantee]:
//!     odată ce structura dvs. este fixată, memoria care conține conținutul nu este suprascrisă sau alocată fără a apela distructorii conținutului.
//!     Acest lucru poate fi dificil, după cum a văzut [`VecDeque<T>`]: distructorul [`VecDeque<T>`] poate să nu apeleze [`drop`] pe toate elementele dacă unul dintre destructorii panics.Acest lucru încalcă garanția [`Drop`], deoarece poate duce la alocarea elementelor fără ca destructorul lor să fie chemat.([`VecDeque<T>`] nu are proiecții de fixare, deci acest lucru nu provoacă lipsă de sens.)
//! 4. Nu trebuie să oferiți alte operații care ar putea duce la mutarea datelor din câmpurile structurale atunci când tipul dvs. este fixat.De exemplu, dacă structul conține un [`Option<T>`] și există o operațiune de tip " take` cu tipul `fn(Pin<&mut Struct<T>>) -> Option<T>`, acea operație poate fi utilizată pentru a muta un `T` dintr-un `Struct<T>` fixat-ceea ce înseamnă că fixarea nu poate fi structurală pentru câmpul care deține acest date.
//!
//!     Pentru un exemplu mai complex de mutare a datelor dintr-un tip fixat, imaginați-vă dacă [`RefCell<T>`] avea o metodă `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Apoi am putea face următoarele:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Acest lucru este catastrofal, înseamnă că mai întâi putem fixa conținutul [`RefCell<T>`] (folosind `RefCell::get_pin_mut`) și apoi mutăm acel conținut folosind referința mutabilă pe care am obținut-o mai târziu.
//!
//! ## Examples
//!
//! Pentru un tip precum [`Vec<T>`], ambele posibilități (fixarea structurală sau nu) au sens.
//! Un [`Vec<T>`] cu fixare structurală ar putea avea metode `get_pin`/`get_pin_mut` pentru a obține referințe fixate la elemente.Cu toate acestea,*nu* ar putea permite apelarea [`pop`][Vec::pop] pe un [`Vec<T>`] fixat, deoarece aceasta ar muta conținutul (fixat structural)!Nici nu ar putea permite [`push`][Vec::push], care ar putea realoca și, prin urmare, va muta conținutul.
//!
//! Un [`Vec<T>`] fără fixare structurală ar putea `impl<T> Unpin for Vec<T>`, deoarece conținutul nu este niciodată fixat și [`Vec<T>`] în sine este în regulă și cu mutarea.
//! În acel moment fixarea nu are niciun efect asupra vector.
//!
//! În biblioteca standard, tipurile de pointer în general nu au fixare structurală și, prin urmare, nu oferă proiecții de fixare.Acesta este motivul pentru care `Box<T>: Unpin` este valabil pentru toate `T`.
//! Este logic să faceți acest lucru pentru tipurile de pointer, deoarece mutarea `Box<T>` nu mută de fapt `T`: [`Box<T>`] poate fi deplasat liber (alias `Unpin`) chiar dacă `T` nu este.De fapt, chiar și [`Pin`]`<`[`Box`] `<T>>`și [`Pin`] `<&mut T>` sunt întotdeauna [`Unpin`] în sine, din același motiv: conținutul lor (`T`) este fixat, dar pointerele în sine pot fi mutate fără a muta datele fixate.
//! Atât pentru [`Box<T>`], cât și pentru [`Pin`]`<`[`Box`] `<T>>`, dacă conținutul este fixat este complet independent de faptul dacă indicatorul este fixat, adică fixarea nu este * structurală.
//!
//! Când implementați un combinator [`Future`], de obicei veți avea nevoie de fixare structurală pentru futures imbricat, deoarece trebuie să obțineți referințe fixate la acestea pentru a apela [`poll`].
//! Dar dacă combinatorul dvs. conține orice alte date care nu trebuie fixate, puteți face ca acele câmpuri să nu fie structurale și, prin urmare, să le accesați liber cu o referință mutabilă chiar și atunci când aveți doar [`Pin`]`<&mut Self>`(astfel ca în propria dvs. implementare [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Un indicator fixat.
///
/// Acesta este un înveliș în jurul unui fel de pointer care face ca pointerul "pin" să-și stabilească valoarea, împiedicând mutarea valorii la care se referă acel pointer, cu excepția cazului în care implementează [`Unpin`].
///
///
/// *Consultați documentația [`pin` module] pentru o explicație a fixării.*
///
/// [`pin` module]: self
///
// Note: derivarea `Clone` de mai jos provoacă lipsă de sens, deoarece este posibil să o implementați
// `Clone` pentru referințe mutabile.
// Consultați <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> pentru mai multe detalii.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Următoarele implementări nu sunt derivate pentru a evita problemele de soliditate.
// `&self.pointer` nu ar trebui să fie accesibil implementărilor trait care nu au încredere.
//
// Consultați <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> pentru mai multe detalii.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Construiți un nou `Pin<P>` în jurul unui pointer pentru unele date de un tip care implementează [`Unpin`].
    ///
    /// Spre deosebire de `Pin::new_unchecked`, această metodă este sigură, deoarece indicatorul `P` se referă la un tip [`Unpin`], care anulează garanțiile de fixare.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SIGURANȚĂ: valoarea indicată este `Unpin` și, prin urmare, nu are cerințe
        // în jurul fixării.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Desfășoară acest `Pin<P>` returnând indicatorul de bază.
    ///
    /// Acest lucru necesită ca datele din acest `Pin` să fie [`Unpin`], astfel încât să putem ignora invarianții de fixare atunci când îl desfacem.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Construiți un nou `Pin<P>` în jurul unei referințe la unele date de un tip care poate sau nu să implementeze `Unpin`.
    ///
    /// Dacă `pointer` se referă la un tip `Unpin`, ar trebui folosit în schimb `Pin::new`.
    ///
    /// # Safety
    ///
    /// Acest constructor este nesigur, deoarece nu putem garanta că datele arătate de `pointer` sunt fixate, ceea ce înseamnă că datele nu vor fi mutate sau stocarea lor invalidată până când nu vor fi abandonate.
    /// Dacă `Pin<P>` construit nu garantează că datele pe care le indică `P` sunt fixate, aceasta reprezintă o încălcare a contractului API și poate duce la un comportament nedefinit în operațiunile (safe) ulterioare.
    ///
    /// Utilizând această metodă, creați un promise despre implementările `P::Deref` și `P::DerefMut`, dacă acestea există.
    /// Cel mai important, nu trebuie să se deplaseze din argumentele lor `self`: `Pin::as_mut` și `Pin::as_ref` vor apela `DerefMut::deref_mut` și `Deref::deref`*pe indicatorul fixat* și se așteaptă ca aceste metode să susțină invarianții de fixare.
    /// Mai mult, apelând această metodă, promise că referințele referințelor `P` la care nu vor fi mutate din nou;în special, nu trebuie să fie posibil să obțineți un `&mut P::Target` și apoi să ieșiți din acea referință (folosind, de exemplu, [`mem::swap`]).
    ///
    ///
    /// De exemplu, apelarea `Pin::new_unchecked` pe un `&'a mut T` este nesigură, deoarece, deși sunteți capabil să o fixați pe durata de viață dată `'a`, nu aveți control asupra faptului dacă este păstrat fixat odată ce `'a` se termină:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Acest lucru ar trebui să însemne că pointee `a` nu se mai poate mișca niciodată.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adresa `a` s-a schimbat în slotul stivei " b`, așa că `a` a fost mutat chiar dacă l-am fixat anterior!Am încălcat contractul API de fixare.
    /////
    /// }
    /// ```
    ///
    /// O valoare, odată fixată, trebuie să rămână fixată pentru totdeauna (cu excepția cazului în care tipul său implementează `Unpin`).
    ///
    /// În mod similar, apelarea `Pin::new_unchecked` pe un `Rc<T>` este nesigură, deoarece ar putea exista aliasuri pentru aceleași date care nu fac obiectul restricțiilor de fixare:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Acest lucru ar trebui să însemne că pointee nu se mai poate mișca niciodată.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Acum, dacă `x` a fost singura referință, avem o referință mutabilă la datele pe care le-am fixat mai sus, pe care le-am putea folosi pentru a le muta așa cum am văzut în exemplul anterior.
    ///     // Am încălcat contractul API de fixare.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Obține o referință partajată fixată din acest indicator fixat.
    ///
    /// Aceasta este o metodă generică pentru a trece de la `&Pin<Pointer<T>>` la `Pin<&T>`.
    /// Este sigur, deoarece, ca parte a contractului `Pin::new_unchecked`, pointee nu se poate deplasa după ce `Pin<Pointer<T>>` a fost creat.
    ///
    /// "Malicious" implementările `Pointer::Deref` sunt, de asemenea, excluse prin contractul `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SIGURANȚĂ: consultați documentația despre această funcție
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Desfășoară acest `Pin<P>` returnând indicatorul de bază.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură.Trebuie să garantați că veți continua să tratați indicatorul `P` ca fixat după ce ați apelat această funcție, astfel încât invarianții de tipul `Pin` să poată fi confirmați.
    /// Dacă codul care utilizează `P` rezultat nu continuă să mențină invarianții de fixare, aceasta reprezintă o încălcare a contractului API și poate duce la un comportament nedefinit în operațiunile (safe) ulterioare.
    ///
    ///
    /// Dacă datele de bază sunt [`Unpin`], ar trebui să se utilizeze în schimb [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Obține o referință mutabilă fixată din acest indicator fixat.
    ///
    /// Aceasta este o metodă generică pentru a trece de la `&mut Pin<Pointer<T>>` la `Pin<&mut T>`.
    /// Este sigur, deoarece, ca parte a contractului `Pin::new_unchecked`, pointee nu se poate deplasa după ce `Pin<Pointer<T>>` a fost creat.
    ///
    /// "Malicious" implementările `Pointer::DerefMut` sunt, de asemenea, excluse prin contractul `Pin::new_unchecked`.
    ///
    /// Această metodă este utilă atunci când efectuați mai multe apeluri către funcții care consumă tipul fixat.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // Fă ceva
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consumă `self`, așa că rambursește `Pin<&mut Self>` prin `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SIGURANȚĂ: consultați documentația despre această funcție
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Atribuie o nouă valoare memoriei din spatele referinței fixate.
    ///
    /// Acest lucru suprascrie datele fixate, dar este în regulă: distructorul său este executat înainte de a fi suprascris, deci nu se încalcă nicio garanție de fixare.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Construiește un nou pin prin maparea valorii interioare.
    ///
    /// De exemplu, dacă doriți să obțineți un `Pin` dintr-un câmp de ceva, puteți utiliza acest lucru pentru a obține accesul la câmpul respectiv într-o singură linie de cod.
    /// Cu toate acestea, există mai multe gotcha-uri cu aceste "pinning projections";
    /// consultați documentația [`pin` module] pentru detalii suplimentare despre acest subiect.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură.
    /// Trebuie să garantați că datele pe care le returnați nu se vor mișca atât timp cât valoarea argumentului nu se mișcă (de exemplu, deoarece este unul dintre câmpurile acelei valori) și, de asemenea, că nu vă deplasați din argumentul pe care îl primiți funcția interioară.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SIGURANȚĂ: contractul de siguranță pentru `new_unchecked` trebuie să fie
        // confirmat de apelant.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Obține o referință partajată dintr-un pin.
    ///
    /// Acest lucru este sigur, deoarece nu este posibil să ieșiți dintr-o referință partajată.
    /// Se poate părea că există o problemă aici cu mutabilitatea interioară: de fapt,*este* posibilă mutarea unui `T` dintr-un `&RefCell<T>`.
    /// Cu toate acestea, aceasta nu este o problemă atâta timp cât nu există și un `Pin<&T>` care să indice aceleași date, iar `RefCell<T>` nu vă permite să creați o referință fixată la conținutul său.
    ///
    /// Consultați discuția despre ["pinning projections"] pentru detalii suplimentare.
    ///
    /// Note: `Pin` implementează, de asemenea, `Deref` în țintă, care poate fi folosit pentru a accesa valoarea interioară.
    /// Cu toate acestea, `Deref` oferă doar o referință care durează atât timp cât împrumutul `Pin`, nu durata de viață a `Pin` în sine.
    /// Această metodă permite transformarea `Pin` într-o referință cu aceeași durată de viață ca `Pin` original.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Convertește acest `Pin<&mut T>` într-un `Pin<&T>` cu aceeași durată de viață.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Obține o referință mutabilă la datele din acest `Pin`.
    ///
    /// Acest lucru necesită ca datele din acest `Pin` să fie `Unpin`.
    ///
    /// Note: `Pin` implementează, de asemenea, `DerefMut` pentru date, care poate fi utilizat pentru a accesa valoarea interioară.
    /// Cu toate acestea, `DerefMut` oferă doar o referință care durează atât timp cât împrumutul `Pin`, nu durata de viață a `Pin` în sine.
    ///
    /// Această metodă permite transformarea `Pin` într-o referință cu aceeași durată de viață ca `Pin` original.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Obține o referință mutabilă la datele din acest `Pin`.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură.
    /// Trebuie să garantați că nu veți muta niciodată datele din referința mutabilă pe care o primiți atunci când apelați această funcție, astfel încât invarianții de tipul `Pin` să poată fi păstrați.
    ///
    ///
    /// Dacă datele de bază sunt `Unpin`, ar trebui să se utilizeze în schimb `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Construiți un nou pin prin cartografierea valorii interioare.
    ///
    /// De exemplu, dacă doriți să obțineți un `Pin` dintr-un câmp de ceva, puteți utiliza acest lucru pentru a obține accesul la câmpul respectiv într-o singură linie de cod.
    /// Cu toate acestea, există mai multe gotcha-uri cu aceste "pinning projections";
    /// consultați documentația [`pin` module] pentru detalii suplimentare despre acest subiect.
    ///
    /// # Safety
    ///
    /// Această funcție este nesigură.
    /// Trebuie să garantați că datele pe care le returnați nu se vor mișca atât timp cât valoarea argumentului nu se mișcă (de exemplu, deoarece este unul dintre câmpurile acelei valori) și, de asemenea, că nu vă deplasați din argumentul pe care îl primiți funcția interioară.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SIGURANȚĂ: apelantul este responsabil pentru faptul că nu mișcă
        // valoare din această referință.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SIGURANȚĂ: deoarece valoarea `this` este garantată să nu aibă
        // a fost mutat, acest apel către `new_unchecked` este sigur.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Obțineți o referință fixată dintr-o referință statică.
    ///
    /// Acest lucru este sigur, deoarece `T` este împrumutat pentru durata de viață `'static`, care nu se termină niciodată.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SIGURANȚĂ: " Împrumutul static garantează că datele nu vor fi
        // moved/invalidated până când scade (ceea ce nu este niciodată).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Obțineți o referință mutabilă fixată dintr-o referință statică mutabilă.
    ///
    /// Acest lucru este sigur, deoarece `T` este împrumutat pentru durata de viață `'static`, care nu se termină niciodată.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SIGURANȚĂ: " Împrumutul static garantează că datele nu vor fi
        // moved/invalidated până când scade (ceea ce nu este niciodată).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: aceasta înseamnă că orice instrument de `CoerceUnsized` care permite constrângerea de la
// un tip care implică `Deref<Target=impl !Unpin>` la un tip care implică `Deref<Target=Unpin>` nu este sigur.
// Orice astfel de implementare ar fi probabil nefondată din alte motive, deci trebuie doar să avem grijă să nu permitem ca aceste implice să aterizeze în std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}