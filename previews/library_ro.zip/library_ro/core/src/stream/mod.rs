//! Iterație asincronă compozabilă.
//!
//! Dacă futures sunt valori asincrone, atunci fluxurile sunt iteratoare asincrone.
//! Dacă v-ați găsit cu o colecție asincronă de un fel și ați avut nevoie să efectuați o operație asupra elementelor respectivei colecții, veți rula rapid în 'streams'.
//! Fluxurile sunt foarte utilizate în codul Rust idiomatic asincron, deci merită să vă familiarizați cu ele.
//!
//! Înainte de a explica mai multe, să vorbim despre modul în care este structurat acest modul:
//!
//! # Organization
//!
//! Acest modul este organizat în mare parte pe tipuri:
//!
//! * [Traits] sunt porțiunea principală: aceste traits definesc ce fel de fluxuri există și ce puteți face cu ele.Metodele acestor traits merită să punem ceva timp de studiu în plus.
//! * Funcțiile oferă câteva modalități utile de a crea câteva fluxuri de bază.
//! * Structurile sunt adesea tipurile de returnare ale diferitelor metode de pe acest modul traits.De obicei, veți dori să vă uitați la metoda care creează `struct`, mai degrabă decât `struct` în sine.
//! Pentru mai multe detalii despre motiv, consultați " [Implementing Stream](#Implementing-Stream)`.
//!
//! [Traits]: #traits
//!
//! Asta este!Să săpăm în cursuri.
//!
//! # Stream
//!
//! Inima și sufletul acestui modul este [`Stream`] trait.Miezul [`Stream`] arată astfel:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Spre deosebire de `Iterator`, `Stream` face o distincție între metoda [`poll_next`] care este utilizată atunci când implementați un `Stream` și o metodă (to-be-implemented) `next` care este utilizată atunci când consumați un flux.
//!
//! Consumatorii de `Stream` trebuie să ia în considerare doar `next`, care atunci când este apelat, returnează un future care produce `Option<Stream::Item>`.
//!
//! future returnat de `next` va produce `Some(Item)` atâta timp cât există elemente și, odată ce au fost epuizate, va produce `None` pentru a indica faptul că iterația este terminată.
//! Dacă așteptăm ceva asincron de rezolvat, future va aștepta până când fluxul este gata să cedeze din nou.
//!
//! Fluxurile individuale pot alege să reia iterația și, prin urmare, apelarea din nou a `next` poate sau nu poate produce în cele din urmă `Some(Item)` la un moment dat.
//!
//! Definiția completă a [`Stream`] include și o serie de alte metode, dar sunt metode implicite, construite pe [`poll_next`], astfel încât să le obțineți gratuit.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementarea fluxului
//!
//! Crearea unui flux propriu implică doi pași: crearea unui `struct` pentru a păstra starea fluxului și apoi implementarea [`Stream`] pentru acel `struct`.
//!
//! Să facem un flux numit `Counter` care contează de la `1` la `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // În primul rând, structura:
//!
//! /// Un flux care contează de la unu la cinci
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vrem ca numărul nostru să înceapă de la unul, așa că haideți să adăugăm o metodă new() pentru a vă ajuta.
//! // Acest lucru nu este strict necesar, dar este convenabil.
//! // Rețineți că pornim `count` la zero, vom vedea de ce în implementarea `poll_next()`'s mai jos.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Apoi, implementăm `Stream` pentru `Counter`:
//!
//! impl Stream for Counter {
//!     // vom conta cu uzura
//!     type Item = usize;
//!
//!     // poll_next() este singura metodă necesară
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Creșteți numărul nostru.Acesta este motivul pentru care am început de la zero.
//!         self.count += 1;
//!
//!         // Verificați dacă am terminat de numărat sau nu.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Fluxurile sunt *leneșe*.Aceasta înseamnă că doar crearea unui flux nu _do_ prea mult.Nimic nu se întâmplă cu adevărat până nu suni `next`.
//! Aceasta este uneori o sursă de confuzie atunci când creați un flux exclusiv pentru efectele sale secundare.
//! Compilatorul ne va avertiza despre acest tip de comportament:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;