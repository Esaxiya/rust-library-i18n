use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// O interfață pentru tratarea iteratorilor asincroni.
///
/// Acesta este fluxul principal trait.
/// Pentru mai multe informații despre conceptul de fluxuri, în general, consultați [module-level documentation].
/// În special, poate doriți să știți cum să [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Tipul de articole generate de flux.
    type Item;

    /// Încercați să extrageți următoarea valoare a acestui flux, înregistrând sarcina curentă pentru trezire dacă valoarea nu este încă disponibilă și returnând `None` dacă fluxul este epuizat.
    ///
    /// # Valoare returnată
    ///
    /// Există mai multe valori de returnare posibile, fiecare indicând o stare de flux distinctă:
    ///
    /// - `Poll::Pending` înseamnă că următoarea valoare a acestui flux nu este încă gata.Implementările se vor asigura că sarcina curentă va fi notificată când următoarea valoare poate fi gata.
    ///
    /// - `Poll::Ready(Some(val))` înseamnă că fluxul a produs cu succes o valoare, `val` și poate produce valori suplimentare la apelurile `poll_next` ulterioare.
    ///
    /// - `Poll::Ready(None)` înseamnă că fluxul sa încheiat, iar `poll_next` nu ar trebui să fie invocat din nou.
    ///
    /// # Panics
    ///
    /// Odată ce un flux sa terminat (`Ready(None)` from `poll_next`) returnat, apelarea din nou a metodei `poll_next` poate panic, să se blocheze definitiv sau să provoace alte tipuri de probleme; `Stream` trait nu pune cerințe asupra efectelor unui astfel de apel.
    ///
    /// Cu toate acestea, deoarece metoda `poll_next` nu este marcată `unsafe`, se aplică regulile obișnuite ale Rust: apelurile nu trebuie să provoace niciodată un comportament nedefinit (corupția memoriei, utilizarea incorectă a funcțiilor `unsafe` sau altele asemenea), indiferent de starea fluxului.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Returnează limitele pentru lungimea rămasă a fluxului.
    ///
    /// Mai exact, `size_hint()` returnează un tuplu în care primul element este limita inferioară, iar al doilea element este limita superioară.
    ///
    /// A doua jumătate a tuplului returnat este o [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] aici înseamnă că fie nu există limită superioară cunoscută, fie limita superioară este mai mare decât [`usize`].
    ///
    /// # Note de implementare
    ///
    /// Nu se impune ca o implementare a fluxului să producă numărul declarat de elemente.Un flux buggy poate produce mai puțin decât limita inferioară sau mai mult decât limita superioară a elementelor.
    ///
    /// `size_hint()` este destinat în primul rând să fie utilizat pentru optimizări precum rezervarea spațiului pentru elementele fluxului, dar nu trebuie să fie de încredere că, de exemplu, omite verificările limitelor în codul nesigur.
    /// O implementare incorectă a `size_hint()` nu ar trebui să conducă la încălcări ale siguranței memoriei.
    ///
    /// Acestea fiind spuse, implementarea ar trebui să ofere o estimare corectă, deoarece altfel ar fi o încălcare a protocolului trait.
    ///
    /// Implementarea implicită returnează `(0,` [`None`]`)`care este corect pentru orice flux.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}