use crate::fmt;

/// Creează un nou iterator în care fiecare iterație numește închiderea furnizată `F: FnMut() -> Option<T>`.
///
/// Acest lucru permite crearea unui iterator personalizat cu orice comportament fără a utiliza sintaxa mai detaliată de a crea un tip dedicat și de a implementa [`Iterator`] trait pentru acesta.
///
/// Rețineți că iteratorul `FromFn` nu face presupuneri cu privire la comportamentul închiderii și, prin urmare, nu implementează în mod conservator [`FusedIterator`] sau nu înlocuiește [`Iterator::size_hint()`] de la `(0, None)` implicit.
///
///
/// Închiderea poate utiliza capturi și mediul său pentru a urmări starea de pe iterații.În funcție de modul în care este utilizat iteratorul, acest lucru poate necesita specificarea cuvântului cheie [`move`] în închidere.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Să implementăm din nou contorul iterator de la [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Creșteți numărul nostru.Acesta este motivul pentru care am început de la zero.
///     count += 1;
///
///     // Verificați dacă am terminat de numărat sau nu.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Un iterator în care fiecare iterație numește închiderea furnizată `F: FnMut() -> Option<T>`.
///
/// Acest `struct` este creat de funcția [`iter::from_fn()`].
/// Consultați documentația sa pentru mai multe.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}