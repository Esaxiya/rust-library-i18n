use crate::iter::{FusedIterator, TrustedLen};

/// Creează un nou iterator care repetă elemente de tip `A` la nesfârșit prin aplicarea închiderii furnizate, repetorului, `F: FnMut() -> A`.
///
/// Funcția `repeat_with()` apelează repetorul repetat.
///
/// Infinitori iteratori precum `repeat_with()` sunt adesea utilizați cu adaptoare precum [`Iterator::take()`], pentru a le face finite.
///
/// Dacă tipul de element al iteratorului de care aveți nevoie implementează [`Clone`] și este OK să păstrați elementul sursă în memorie, ar trebui să utilizați în schimb funcția [`repeat()`].
///
///
/// Un iterator produs de `repeat_with()` nu este un [`DoubleEndedIterator`].
/// Dacă aveți nevoie de `repeat_with()` pentru a returna un [`DoubleEndedIterator`], vă rugăm să deschideți o problemă GitHub explicând cazul dvs. de utilizare.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::iter;
///
/// // să presupunem că avem o valoare de un tip care nu este `Clone` sau care nu doresc să aibă în memorie încă, deoarece este scump:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // o valoare specială pentru totdeauna:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Folosind mutația și mergând finit:
///
/// ```rust
/// use std::iter;
///
/// // De la zero la a treia putere a două:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... și acum am terminat
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Un iterator care repetă elemente de tipul `A` la nesfârșit prin aplicarea închiderii furnizate `F: FnMut() -> A`.
///
///
/// Acest `struct` este creat de funcția [`repeat_with()`].
/// Consultați documentația sa pentru mai multe.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}