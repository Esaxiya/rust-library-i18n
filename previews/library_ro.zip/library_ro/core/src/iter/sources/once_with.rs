use crate::iter::{FusedIterator, TrustedLen};

/// Creează un iterator care generează leneș o valoare exact o dată prin invocarea închiderii furnizate.
///
/// Acesta este utilizat în mod obișnuit pentru a adapta un singur generator de valori într-un [`chain()`] de alte tipuri de iterații.
/// Poate aveți un iterator care acoperă aproape totul, dar aveți nevoie de un caz suplimentar special.
/// Poate aveți o funcție care funcționează pe iteratori, dar trebuie doar să procesați o valoare.
///
/// Spre deosebire de [`once()`], această funcție va genera leneș valoarea la cerere.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::iter;
///
/// // unul este cel mai singuratic număr
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // doar una, asta e tot ce primim
/// assert_eq!(None, one.next());
/// ```
///
/// Înlănțuind împreună cu un alt iterator.
/// Să presupunem că vrem să repetăm fiecare fișier din directorul `.foo`, dar și un fișier de configurare,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // trebuie să convertim de la un iterator de DirEntry-s la un iterator de PathBufs, așa că folosim harta
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // acum, iteratorul nostru doar pentru fișierul nostru de configurare
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // înlănțuiți cei doi iteratori împreună într-un singur iterator mare
/// let files = dirs.chain(config);
///
/// // aceasta ne va oferi toate fișierele din .foo, precum și .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Un iterator care produce un singur element de tipul `A` prin aplicarea închiderii furnizate `F: FnOnce() -> A`.
///
///
/// Acest `struct` este creat de funcția [`once_with()`].
/// Consultați documentația sa pentru mai multe.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}