use crate::iter::{FusedIterator, TrustedLen};

/// Creează un iterator care produce un element exact o dată.
///
/// Aceasta este folosită în mod obișnuit pentru a adapta o singură valoare într-un [`chain()`] de alte tipuri de iterații.
/// Poate aveți un iterator care acoperă aproape totul, dar aveți nevoie de un caz suplimentar special.
/// Poate aveți o funcție care funcționează pe iteratori, dar trebuie doar să procesați o valoare.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::iter;
///
/// // unul este cel mai singuratic număr
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // doar una, asta e tot ce primim
/// assert_eq!(None, one.next());
/// ```
///
/// Înlănțuind împreună cu un alt iterator.
/// Să presupunem că vrem să repetăm fiecare fișier din directorul `.foo`, dar și un fișier de configurare,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // trebuie să convertim de la un iterator de DirEntry-s la un iterator de PathBufs, așa că folosim harta
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // acum, iteratorul nostru doar pentru fișierul nostru de configurare
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // înlănțuiți cei doi iteratori împreună într-un singur iterator mare
/// let files = dirs.chain(config);
///
/// // aceasta ne va oferi toate fișierele din .foo, precum și .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Un iterator care produce un element exact o dată.
///
/// Acest `struct` este creat de funcția [`once()`].Consultați documentația sa pentru mai multe.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}