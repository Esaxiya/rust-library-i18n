use crate::iter::{FusedIterator, TrustedLen};

/// Creează un nou iterator care repetă la nesfârșit un singur element.
///
/// Funcția `repeat()` repetă o singură valoare mereu.
///
/// Infinitori iteratori precum `repeat()` sunt adesea utilizați cu adaptoare precum [`Iterator::take()`], pentru a le face finite.
///
/// Dacă tipul de element al iteratorului de care aveți nevoie nu implementează `Clone` sau dacă nu doriți să păstrați elementul repetat în memorie, puteți folosi funcția [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::iter;
///
/// // numărul patru 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // da, încă patru
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Mergând finit cu [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ultimul exemplu a fost prea mulți patru.Să avem doar patru paturi.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... și acum am terminat
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Un iterator care repetă un element la nesfârșit.
///
/// Acest `struct` este creat de funcția [`repeat()`].Consultați documentația sa pentru mai multe.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}