use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Obiecte care au o noțiune de operații *succesor* și *predecesor*.
///
/// Operația *succesor* se îndreaptă spre valori care se compară mai mult.
/// Operația *predecesorul* se îndreaptă spre valori care se compară mai puțin.
///
/// # Safety
///
/// Acest trait este `unsafe` deoarece implementarea acestuia trebuie să fie corectă pentru siguranța implementărilor `unsafe trait TrustedLen`, iar rezultatele utilizării acestui trait pot fi altfel de încredere prin codul `unsafe` pentru a fi corecte și pentru a îndeplini obligațiile enumerate.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Returnează numărul de pași *succesori* necesari pentru a trece de la `start` la `end`.
    ///
    /// Returnează `None` dacă numărul de pași ar depăși `usize` (sau este infinit sau dacă `end` nu ar fi atins niciodată).
    ///
    ///
    /// # Invariants
    ///
    /// Pentru orice `a`, `b` și `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` dacă și numai dacă `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` dacă și numai dacă `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` numai dacă `a <= b`
    ///   * Corolar: `steps_between(&a, &b) == Some(0)` dacă și numai dacă `a == b`
    ///   * Rețineți că `a <= b` implică _not_ `steps_between(&a, &b) != None`;
    ///     acesta este cazul când ar necesita mai mult de pași `usize::MAX` pentru a ajunge la `b`
    /// * `steps_between(&a, &b) == None` dacă `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Returnează valoarea care ar fi obținută luând *succesorul*`self` `count` ori.
    ///
    /// Dacă acest lucru va depăși gama de valori acceptate de `Self`, returnează `None`.
    ///
    /// # Invariants
    ///
    /// Pentru orice `a`, `n` și `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Pentru orice `a`, `n` și `m` în care `n + m` nu depășește:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Pentru orice `a` și `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Returnează valoarea care ar fi obținută luând *succesorul*`self` `count` ori.
    ///
    /// Dacă acest lucru ar depăși gama de valori acceptate de `Self`, această funcție este permisă pentru panic, pentru a înfășura sau pentru a satura.
    ///
    /// Comportamentul sugerat este pentru panic când afirmațiile de depanare sunt activate și pentru a înfășura sau satura altfel.
    ///
    /// Codul nesigur nu trebuie să se bazeze pe corectitudinea comportamentului după revărsare.
    ///
    /// # Invariants
    ///
    /// Pentru orice `a`, `n` și `m`, în cazul în care nu are loc o revărsare:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Pentru orice `a` și `n`, unde nu are loc o revărsare:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Returnează valoarea care ar fi obținută luând *succesorul*`self` `count` ori.
    ///
    /// # Safety
    ///
    /// Este un comportament nedefinit pentru această operațiune să depășească gama de valori acceptate de `Self`.
    /// Dacă nu puteți garanta că acest lucru nu se va revărsa, utilizați în schimb `forward` sau `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Pentru orice `a`:
    ///
    /// * dacă există `b` astfel încât `b > a`, este sigur să apelați `Step::forward_unchecked(a, 1)`
    /// * dacă există `b`, `n` astfel încât `steps_between(&a, &b) == Some(n)`, este sigur să apelați `Step::forward_unchecked(a, m)` pentru orice `m <= n`.
    ///
    ///
    /// Pentru orice `a` și `n`, unde nu are loc o revărsare:
    ///
    /// * `Step::forward_unchecked(a, n)` este echivalent cu `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Returnează valoarea care ar fi obținută luând *predecesorul*`self` `count` ori.
    ///
    /// Dacă acest lucru va depăși gama de valori acceptate de `Self`, returnează `None`.
    ///
    /// # Invariants
    ///
    /// Pentru orice `a`, `n` și `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Pentru orice `a` și `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Returnează valoarea care ar fi obținută luând *predecesorul*`self` `count` ori.
    ///
    /// Dacă acest lucru ar depăși gama de valori acceptate de `Self`, această funcție este permisă pentru panic, pentru a înfășura sau pentru a satura.
    ///
    /// Comportamentul sugerat este pentru panic când afirmațiile de depanare sunt activate și pentru a înfășura sau satura altfel.
    ///
    /// Codul nesigur nu trebuie să se bazeze pe corectitudinea comportamentului după revărsare.
    ///
    /// # Invariants
    ///
    /// Pentru orice `a`, `n` și `m`, în cazul în care nu are loc o revărsare:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Pentru orice `a` și `n`, unde nu are loc o revărsare:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Returnează valoarea care ar fi obținută luând *predecesorul*`self` `count` ori.
    ///
    /// # Safety
    ///
    /// Este un comportament nedefinit pentru această operațiune să depășească gama de valori acceptate de `Self`.
    /// Dacă nu puteți garanta că acest lucru nu se va revărsa, utilizați în schimb `backward` sau `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Pentru orice `a`:
    ///
    /// * dacă există `b` astfel încât `b < a`, este sigur să apelați `Step::backward_unchecked(a, 1)`
    /// * dacă există `b`, `n` astfel încât `steps_between(&b, &a) == Some(n)`, este sigur să apelați `Step::backward_unchecked(a, m)` pentru orice `m <= n`.
    ///
    ///
    /// Pentru orice `a` și `n`, unde nu are loc o revărsare:
    ///
    /// * `Step::backward_unchecked(a, n)` este echivalent cu `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Acestea sunt încă generate macro, deoarece literele întregi se rezolvă la diferite tipuri.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SIGURANȚĂ: apelantul trebuie să garanteze că `start + n` nu se revarsă.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SIGURANȚĂ: apelantul trebuie să garanteze că `start - n` nu se revarsă.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // În versiunile de depanare, declanșați un panic la depășire.
            // Acest lucru ar trebui optimizat complet în versiunile de lansare.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Înfășurați matematica pentru a permite, de exemplu `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // În versiunile de depanare, declanșați un panic la depășire.
            // Acest lucru ar trebui optimizat complet în versiunile de lansare.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Înfășurați matematica pentru a permite, de exemplu `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Aceasta se bazează pe $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // dacă n este în afara intervalului, `unsigned_start + n` este și el
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // dacă n este în afara intervalului, `unsigned_start - n` este și el
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Aceasta se bazează pe $i_narrower <=usize
                        //
                        // Turnarea la izize extinde lățimea, dar păstrează semnul.
                        // Utilizați wrapping_sub în spațiul isize și aruncați pentru a utiliza pentru a calcula diferența care poate să nu se potrivească în intervalul isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Înfășurarea gestionează carcase precum `Step::forward(-120_i8, 200) == Some(80_i8)`, chiar dacă 200 este în afara intervalului pentru i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Adăugarea s-a revărsat
                            }
                        }
                        // Dacă n este în afara intervalului de ex
                        // u8, atunci este mai mare decât întreaga gamă pentru i8 este largă, astfel încât `any_i8 + n` depășește în mod necesar i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Înfășurarea gestionează carcase precum `Step::forward(-120_i8, 200) == Some(80_i8)`, chiar dacă 200 este în afara intervalului pentru i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Scăderea a debordat
                            }
                        }
                        // Dacă n este în afara intervalului de ex
                        // u8, atunci este mai mare decât întreaga gamă pentru i8 este largă, astfel încât `any_i8 - n` depășește în mod necesar i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Dacă diferența este prea mare de ex
                            // i128, va fi, de asemenea, prea mare pentru a fi folosit cu mai puțini biți.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SIGURANȚĂ: res este un scalar unicode valid
            // (sub 0x110000 și nu în 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SIGURANȚĂ: res este un scalar unicode valid
        // (sub 0x110000 și nu în 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SIGURANȚĂ: apelantul trebuie să garanteze că acest lucru nu se revarsă
        // intervalul de valori pentru un caracter.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SIGURANȚĂ: apelantul trebuie să garanteze că acest lucru nu se revarsă
            // intervalul de valori pentru un caracter.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SIGURANȚĂ: datorită contractului anterior, acest lucru este garantat
        // de către apelant pentru a fi un caracter valid.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SIGURANȚĂ: apelantul trebuie să garanteze că acest lucru nu se revarsă
        // intervalul de valori pentru un caracter.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SIGURANȚĂ: apelantul trebuie să garanteze că acest lucru nu se revarsă
            // intervalul de valori pentru un caracter.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SIGURANȚĂ: datorită contractului anterior, acest lucru este garantat
        // de către apelant pentru a fi un caracter valid.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SIGURANȚĂ: tocmai am verificat condiția prealabilă
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SIGURANȚĂ: tocmai am verificat condiția prealabilă
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Aceste macrocomenzi generează implemente `ExactSizeIterator` pentru diferite tipuri de game.
//
// * `ExactSizeIterator::len` este obligatoriu pentru a returna întotdeauna un `usize` exact, deci nicio rază nu poate fi mai mare decât `usize::MAX`.
//
// * Pentru tipurile întregi din `Range<_>`, acesta este cazul pentru tipurile mai înguste sau late ca `usize`.
//   Pentru tipurile întregi din `RangeInclusive<_>` acesta este cazul tipurilor *strict mai înguste* decât `usize`, de ex
//   `(0..=u64::MAX).len()` ar fi `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Acestea sunt incorecte conform raționamentului de mai sus, dar eliminarea lor ar fi o schimbare de rupere deoarece acestea au fost stabilizate în Rust 1.0.0.
    // Deci, de ex
    // `(0..66_000_u32).len()` de exemplu, va compila fără erori sau avertismente pe platformele de 16 biți, dar continuă să dea un rezultat greșit.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Acestea sunt incorecte conform raționamentului de mai sus, dar eliminarea lor ar fi o schimbare de rupere deoarece acestea au fost stabilizate în Rust 1.26.0.
    // Deci, de ex
    // `(0..=u16::MAX).len()` de exemplu, va compila fără erori sau avertismente pe platformele de 16 biți, dar continuă să dea un rezultat greșit.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SIGURANȚĂ: tocmai am verificat condiția prealabilă
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SIGURANȚĂ: tocmai am verificat condiția prealabilă
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SIGURANȚĂ: tocmai am verificat condiția prealabilă
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SIGURANȚĂ: tocmai am verificat condiția prealabilă
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SIGURANȚĂ: tocmai am verificat condiția prealabilă
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SIGURANȚĂ: tocmai am verificat condiția prealabilă
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}