// ignore-tidy-filelength Acest fișier constă aproape exclusiv din definiția `Iterator`.
// Nu putem împărți acest lucru în mai multe fișiere.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// O interfață pentru tratarea iteratorilor.
///
/// Acesta este principalul iterator trait.
/// Pentru mai multe despre conceptul de iteratori în general, vă rugăm să consultați [module-level documentation].
/// În special, poate doriți să știți cum să [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Tipul elementelor care se repetă.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avansează iteratorul și returnează următoarea valoare.
    ///
    /// Returnează [`None`] când iterația este terminată.
    /// Implementările individuale ale iteratorului pot alege să reia iterația și, prin urmare, apelarea din nou a `next()` poate începe sau nu să returneze [`Some(Item)`] la un moment dat.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Un apel către next() returnează următoarea valoare ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... și apoi None odată ce s-a terminat.
    /// assert_eq!(None, iter.next());
    ///
    /// // Mai multe apeluri pot sau nu să returneze `None`.Aici vor face întotdeauna.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Returnează limitele pentru lungimea rămasă a iteratorului.
    ///
    /// Mai exact, `size_hint()` returnează un tuplu în care primul element este limita inferioară, iar al doilea element este limita superioară.
    ///
    /// A doua jumătate a tuplului returnat este o [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] aici înseamnă că fie nu există limită superioară cunoscută, fie limita superioară este mai mare decât [`usize`].
    ///
    /// # Note de implementare
    ///
    /// Nu se impune ca o implementare iteratoare să producă numărul declarat de elemente.Un iterator buggy poate produce mai puțin decât limita inferioară sau mai mult decât limita superioară a elementelor.
    ///
    /// `size_hint()` este destinat în primul rând să fie utilizat pentru optimizări precum rezervarea spațiului pentru elementele iteratorului, dar nu trebuie să fie de încredere că, de exemplu, omite verificările limitelor în codul nesigur.
    /// O implementare incorectă a `size_hint()` nu ar trebui să conducă la încălcări ale siguranței memoriei.
    ///
    /// Acestea fiind spuse, implementarea ar trebui să ofere o estimare corectă, deoarece altfel ar fi o încălcare a protocolului trait.
    ///
    /// Implementarea implicită returnează `(0,` [`None`]`)`ceea ce este corect pentru orice iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Un exemplu mai complex:
    ///
    /// ```
    /// // Numerele pare de la zero la zece.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Am putea itera de la zero la zece ori.
    /// // Știind că exact cinci sunt nu ar fi posibil fără a executa filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Să adăugăm încă cinci numere cu chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // acum ambele limite sunt mărite cu cinci
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Returnarea `None` pentru o limită superioară:
    ///
    /// ```
    /// // un iterator infinit nu are limită superioară și limita inferioară maximă posibilă
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Consumă iteratorul, numărând numărul de iterații și returnându-l.
    ///
    /// Această metodă va apela [`next`] în mod repetat până când se întâlnește [`None`], returnând de câte ori a văzut [`Some`].
    /// Rețineți că [`next`] trebuie apelat cel puțin o dată, chiar dacă iteratorul nu are elemente.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Comportament de revărsare
    ///
    /// Metoda nu protejează împotriva revărsărilor, astfel încât numărarea elementelor unui iterator cu mai mult de elemente [`usize::MAX`] fie produce rezultatul greșit, fie panics.
    ///
    /// Dacă sunt activate afirmațiile de depanare, este garantat un panic.
    ///
    /// # Panics
    ///
    /// Această funcție ar putea panic dacă iteratorul are mai mult de [`usize::MAX`] elemente.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Consumă iteratorul, returnând ultimul element.
    ///
    /// Această metodă va evalua iteratorul până când returnează [`None`].
    /// În acest timp, ține evidența elementului curent.
    /// După ce [`None`] este returnat, `last()` va returna ultimul element pe care l-a văzut.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Avansează iteratorul cu elemente `n`.
    ///
    /// Această metodă va sări peste elementele `n` apelând [`next`] de până la `n` ori până când se întâlnește [`None`].
    ///
    /// `advance_by(n)` va returna [`Ok(())`][Ok] dacă iteratorul avansează cu succes cu elementele `n` sau [`Err(k)`][Err] dacă se întâlnește [`None`], unde `k` este numărul de elemente pe care iteratorul este avansat înainte de a rămâne fără elemente (adică
    /// lungimea iteratorului).
    /// Rețineți că `k` este întotdeauna mai mic decât `n`.
    ///
    /// Apelarea la `advance_by(0)` nu consumă niciun element și returnează întotdeauna [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // doar `&4` a fost omis
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Returnează elementul `n`th al iteratorului.
    ///
    /// La fel ca majoritatea operațiilor de indexare, numărul începe de la zero, deci `nth(0)` returnează prima valoare, `nth(1)` a doua și așa mai departe.
    ///
    /// Rețineți că toate elementele precedente, precum și elementul returnat, vor fi consumate din iterator.
    /// Asta înseamnă că elementele precedente vor fi eliminate și, de asemenea, că apelarea `nth(0)` de mai multe ori pe același iterator va returna elemente diferite.
    ///
    ///
    /// `nth()` va returna [`None`] dacă `n` este mai mare sau egală cu lungimea iteratorului.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Apelarea `nth()` de mai multe ori nu derulează înapoi iteratorul:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Se returnează `None` dacă există mai puțin de elemente `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Creează un iterator începând din același punct, dar pas cu cantitatea dată la fiecare iterație.
    ///
    /// Notă 1: Primul element al iteratorului va fi întotdeauna returnat, indiferent de pasul dat.
    ///
    /// Notă 2: Momentul în care sunt trase elementele ignorate nu este fixat.
    /// `StepBy` se comportă ca secvența `next(), nth(step-1), nth(step-1),…`, dar este, de asemenea, liber să se comporte ca secvența
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Modul utilizat este posibil să se schimbe pentru unii iteratori din motive de performanță.
    /// A doua modalitate va avansa iteratorul mai devreme și poate consuma mai multe articole.
    ///
    /// `advance_n_and_return_first` este echivalentul:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoda va panic dacă pasul dat este `0`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Ia doi iteratori și creează un nou iterator peste ambele în ordine.
    ///
    /// `chain()` va returna un nou iterator care va itera mai întâi peste valorile din primul iterator și apoi peste valorile din al doilea iterator.
    ///
    /// Cu alte cuvinte, leagă doi iteratori împreună, într-un lanț.🔗
    ///
    /// [`once`] este utilizat în mod obișnuit pentru a adapta o singură valoare într-un lanț de alte tipuri de iterații.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deoarece argumentul pentru `chain()` utilizează [`IntoIterator`], putem transmite orice poate fi convertit într-un [`Iterator`], nu doar într-un [`Iterator`] în sine.
    /// De exemplu, feliile (`&[T]`) implementează [`IntoIterator`] și astfel pot fi transmise direct la `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dacă lucrați cu Windows API, vă recomandăm să convertiți [`OsStr`] în `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// " Închide` doi iteratori într-un singur iterator de perechi.
    ///
    /// `zip()` returnează un nou iterator care va itera peste alți doi iteratori, returnând un tuplu în care primul element provine de la primul iterator, iar al doilea element provine de la al doilea iterator.
    ///
    ///
    /// Cu alte cuvinte, împarte doi iteratori împreună, într-unul singur.
    ///
    /// Dacă oricare dintre iteratoare returnează [`None`], [`next`] din iteratorul cu fermoar va returna [`None`].
    /// Dacă primul iterator returnează [`None`], `zip` va face scurtcircuit și `next` nu va fi apelat pe al doilea iterator.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deoarece argumentul pentru `zip()` folosește [`IntoIterator`], putem transmite orice poate fi convertit într-un [`Iterator`], nu doar într-un [`Iterator`] în sine.
    /// De exemplu, feliile (`&[T]`) implementează [`IntoIterator`] și astfel pot fi transmise direct la `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` este adesea folosit pentru a fixa un iterator infinit la unul finit.
    /// Acest lucru funcționează deoarece iteratorul finit va returna în cele din urmă [`None`], punând capăt fermoarului.Fixarea cu `(0..)` poate semăna mult cu [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Creează un nou iterator care plasează o copie a `separator` între elementele adiacente ale iteratorului original.
    ///
    /// În cazul în care `separator` nu implementează [`Clone`] sau trebuie calculat de fiecare dată, utilizați [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Primul element de la `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatorul.
    /// assert_eq!(a.next(), Some(&1));   // Următorul element de la `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatorul.
    /// assert_eq!(a.next(), Some(&2));   // Ultimul element de la `a`.
    /// assert_eq!(a.next(), None);       // Iteratorul este terminat.
    /// ```
    ///
    /// `intersperse` poate fi foarte util pentru a alătura elementelor unui iterator folosind un element comun:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Creează un nou iterator care plasează un element generat de `separator` între elementele adiacente ale iteratorului original.
    ///
    /// Închiderea va fi apelată exact odată de fiecare dată când un element este plasat între două articole adiacente de la iteratorul subiacent;
    /// în mod specific, închiderea nu este apelată dacă iteratorul subiacent produce mai puțin de două elemente și după ce ultimul element este randat.
    ///
    ///
    /// Dacă elementul iteratorului implementează [`Clone`], poate fi mai ușor să folosiți [`intersperse`].
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Primul element de la `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatorul.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Următorul element de la `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatorul.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ultimul element de la `v`.
    /// assert_eq!(it.next(), None);               // Iteratorul este terminat.
    /// ```
    ///
    /// `intersperse_with` poate fi utilizat în situații în care separatorul trebuie calculat:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Închiderea își împrumută mutabil contextul pentru a genera un element.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Face o închidere și creează un iterator care numește această închidere pe fiecare element.
    ///
    /// `map()` transformă un iterator în altul, prin intermediul argumentului său:
    /// ceva care implementează [`FnMut`].Produce un nou iterator care numește această închidere pentru fiecare element al iteratorului original.
    ///
    /// Dacă te pricepi la gândire în tipuri, te poți gândi la `map()` astfel:
    /// Dacă aveți un iterator care vă oferă elemente de un anumit tip `A` și doriți un iterator de alt tip `B`, puteți utiliza `map()`, trecând o închidere care ia un `A` și returnează un `B`.
    ///
    ///
    /// `map()` este similar din punct de vedere conceptual cu o buclă [`for`].Cu toate acestea, deoarece `map()` este leneș, este cel mai bine folosit atunci când lucrați deja cu alți iteratori.
    /// Dacă faceți un fel de buclă pentru un efect secundar, este considerat mai idiomatic să utilizați [`for`] decât `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dacă faceți un fel de efect secundar, preferați [`for`] decât `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // nu face asta:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nici măcar nu se va executa, deoarece este leneș.Rust vă va avertiza despre acest lucru.
    ///
    /// // În schimb, utilizați pentru:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Apelează închiderea fiecărui element al unui iterator.
    ///
    /// Acest lucru este echivalent cu utilizarea unei bucle [`for`] pe iterator, deși `break` și `continue` nu sunt posibile dintr-o închidere.
    /// În general, este mai idiomatic să folosiți o buclă `for`, dar `for_each` poate fi mai lizibil atunci când prelucrați articole la sfârșitul lanțurilor de iteratoare mai lungi.
    ///
    /// În unele cazuri, `for_each` poate fi, de asemenea, mai rapid decât o buclă, deoarece va folosi iterația internă pe adaptoare precum `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Pentru un exemplu atât de mic, o buclă `for` poate fi mai curată, dar `for_each` ar putea fi preferabil să păstreze un stil funcțional cu iteratori mai lungi:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Creează un iterator care folosește o închidere pentru a determina dacă un element trebuie cedat.
    ///
    /// Având în vedere un element, închiderea trebuie să returneze `true` sau `false`.Iteratorul returnat va produce numai elementele pentru care închiderea revine adevărată.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deoarece închiderea transmisă către `filter()` ia o referință și mulți iteratori iterați peste referințe, aceasta duce la o situație posibil confuză, în care tipul închiderii este o referință dublă:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // am nevoie de două * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Este obișnuit să folosiți în schimb destructurarea pe argument pentru a elimina unul:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // amandoi si *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// sau amândouă:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // două &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// dintre aceste straturi.
    ///
    /// Rețineți că `iter.filter(f).next()` este echivalent cu `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Creează un iterator care filtrează și mapează.
    ///
    /// Iteratorul returnat produce doar " valoarea` pentru care închiderea furnizată returnează `Some(value)`.
    ///
    /// `filter_map` poate fi folosit pentru a face lanțurile [`filter`] și [`map`] mai concise.
    /// Exemplul de mai jos arată cum un `map().filter().map()` poate fi scurtat la un singur apel către `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Iată același exemplu, dar cu [`filter`] și [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Creează un iterator care oferă numărul de iterații curente, precum și următoarea valoare.
    ///
    /// Iteratorul returnat produce perechi `(i, val)`, unde `i` este indicele curent al iterației și `val` este valoarea returnată de iterator.
    ///
    ///
    /// `enumerate()` își păstrează numărul ca [`usize`].
    /// Dacă doriți să numărați cu un număr întreg diferit, funcția [`zip`] oferă funcționalități similare.
    ///
    /// # Comportament de revărsare
    ///
    /// Metoda nu protejează împotriva revărsărilor, deci enumerarea mai multor elemente [`usize::MAX`] fie produce rezultatul greșit, fie panics.
    /// Dacă sunt activate afirmațiile de depanare, este garantat un panic.
    ///
    /// # Panics
    ///
    /// Iteratorul returnat ar putea panic dacă indexul care urmează să fie returnat ar depăși un [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Creează un iterator care poate folosi [`peek`] pentru a privi următorul element al iteratorului fără a-l consuma.
    ///
    /// Adaugă o metodă [`peek`] la un iterator.Consultați documentația pentru mai multe informații.
    ///
    /// Rețineți că iteratorul subiacent este încă avansat când [`peek`] este apelat pentru prima dată: Pentru a prelua elementul următor, [`next`] este apelat pe iteratorul subiacent, de unde rezultă orice efecte secundare (adică
    ///
    /// orice altceva decât preluarea următoarei valori) a metodei [`next`] va avea loc.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ne permite să vedem în future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // putem peek() de mai multe ori, iteratorul nu va avansa
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // după terminarea iteratorului, la fel și peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Creează un iterator care [" sări`] elementele bazate pe un predicat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ia o închidere ca argument.Acesta va numi această închidere pe fiecare element al iteratorului și va ignora elementele până când returnează `false`.
    ///
    /// După ce `false` este returnat, jobul `skip_while()`'s sa încheiat, iar restul elementelor sunt cedate.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deoarece închiderea transmisă către `skip_while()` ia o referință și mulți iteratori iterați peste referințe, aceasta duce la o situație posibil confuză, în care tipul argumentului de închidere este o referință dublă:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // am nevoie de două * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Oprirea după un `false` inițial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // în timp ce acest lucru ar fi fost fals, deoarece am primit deja un fals, skip_while() nu mai este folosit
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Creează un iterator care produce elemente bazate pe un predicat.
    ///
    /// `take_while()` ia o închidere ca argument.Va numi această închidere pe fiecare element al iteratorului și va da elemente în timp ce returnează `true`.
    ///
    /// După ce `false` este returnat, jobul `take_while()`'s sa încheiat, iar restul elementelor sunt ignorate.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deoarece închiderea transmisă către `take_while()` ia o referință și mulți iteratori iterați peste referințe, aceasta duce la o situație posibil confuză, în care tipul închiderii este o referință dublă:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // am nevoie de două * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Oprirea după un `false` inițial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Avem mai multe elemente mai mici de zero, dar din moment ce avem deja un fals, take_while() nu mai este folosit
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Deoarece `take_while()` trebuie să analizeze valoarea pentru a vedea dacă ar trebui să fie inclusă sau nu, iteratorii consumatori vor vedea că este eliminată:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` nu mai este acolo, deoarece a fost consumat pentru a vedea dacă iterația ar trebui să se oprească, dar nu a fost plasată din nou în iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Creează un iterator care produce ambele elemente pe baza unui predicat și a hărților.
    ///
    /// `map_while()` ia o închidere ca argument.
    /// Va numi această închidere pe fiecare element al iteratorului și va da elemente în timp ce returnează [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Iată același exemplu, dar cu [`take_while`] și [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Oprirea după un [`None`] inițial:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Avem mai multe elemente care s-ar putea potrivi în u32 (4, 5), dar `map_while` a returnat `None` pentru `-3` (pe măsură ce `predicate` a returnat `None`) și `collect` se oprește la primul `None` întâlnit.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Deoarece `map_while()` trebuie să analizeze valoarea pentru a vedea dacă ar trebui să fie inclusă sau nu, iteratorii consumatori vor vedea că este eliminată:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` nu mai este acolo, deoarece a fost consumat pentru a vedea dacă iterația ar trebui să se oprească, dar nu a fost plasată din nou în iterator.
    ///
    /// Rețineți că, spre deosebire de [`take_while`], acest iterator **nu este** fuzionat.
    /// De asemenea, nu este specificat ce returnează acest iterator după returnarea primului [`None`].
    /// Dacă aveți nevoie de iterator fuzionat, utilizați [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Creează un iterator care omite primele elemente `n`.
    ///
    /// După ce au fost consumate, restul elementelor sunt cedate.
    /// În loc să suprascrieți direct această metodă, înlocuiți-o cu metoda `nth`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Creează un iterator care produce primele sale elemente `n`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` este adesea folosit cu un iterator infinit, pentru a-l face finit:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dacă sunt disponibile mai puțin de elemente `n`, `take` se va limita la dimensiunea iteratorului subiacent:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Un adaptor iterator similar cu [`fold`] care deține starea internă și produce un nou iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ia două argumente: o valoare inițială care însămânțează starea internă și o închidere cu două argumente, primul fiind o referință mutabilă la starea internă și al doilea un element iterator.
    ///
    /// Închiderea poate fi atribuită stării interne pentru a partaja starea între iterații.
    ///
    /// La iterație, închiderea va fi aplicată fiecărui element al iteratorului și valoarea returnată din închidere, un [`Option`], este obținută de către iterator.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // fiecare iterație, vom înmulți starea cu elementul
    ///     *state = *state * x;
    ///
    ///     // apoi vom produce negarea statului
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Creează un iterator care funcționează ca harta, dar aplatizează structura imbricată.
    ///
    /// Adaptorul [`map`] este foarte util, dar numai atunci când argumentul de închidere produce valori.
    /// Dacă produce în schimb un iterator, există un strat suplimentar de indirecție.
    /// `flat_map()` va elimina singur acest strat suplimentar.
    ///
    /// Vă puteți gândi la `flat_map(f)` ca la echivalentul semantic al [`map`] ping, și apoi [` aplatizați]] ca la `map(f).flatten()`.
    ///
    /// Un alt mod de gândire la `flat_map()`: închiderea [" map`] returnează un articol pentru fiecare element, iar închiderea `flat_map()`'s returnează un iterator pentru fiecare element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnează un iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Creează un iterator care aplatizează structura imbricată.
    ///
    /// Acest lucru este util atunci când aveți un iterator de iteratori sau un iterator de lucruri care pot fi transformate în iteratori și doriți să eliminați un nivel de indirecție.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Cartografiere și apoi aplatizare:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnează un iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// De asemenea, puteți rescrie acest lucru în termeni de [`flat_map()`], ceea ce este de preferat în acest caz, deoarece transmite intenția mai clar:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnează un iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Aplatizarea elimină doar un nivel de cuibărire la un moment dat:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Aici vedem că `flatten()` nu efectuează o aplatizare "deep".
    /// În schimb, doar un singur nivel de cuibărire este eliminat.Adică, dacă `flatten()` este un tablou tridimensional, rezultatul va fi bidimensional și nu unidimensional.
    /// Pentru a obține o structură unidimensională, trebuie să faceți din nou `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Creează un iterator care se termină după primul [`None`].
    ///
    /// După ce un iterator returnează [`None`], apelurile future pot sau nu să producă din nou [`Some(T)`].
    /// `fuse()` adaptează un iterator, asigurându-se că după ce se dă un [`None`], acesta va returna întotdeauna [`None`] pentru totdeauna.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // un iterator care alternează între Unii și Nici unul
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // dacă este egal, Some(i32), altceva Nici unul
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // putem vedea iteratorul nostru mergând înainte și înapoi
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // totuși, odată ce-l topim ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // va reveni întotdeauna `None` după prima dată.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Face ceva cu fiecare element al unui iterator, trecând valoarea mai departe.
    ///
    /// Atunci când utilizați iteratoare, veți adesea înlănțui mai multe dintre ele.
    /// În timp ce lucrați la un astfel de cod, vă recomandăm să verificați ce se întâmplă în diferite părți din conductă.Pentru aceasta, introduceți un apel către `inspect()`.
    ///
    /// Este mai obișnuit ca `inspect()` să fie utilizat ca instrument de depanare decât să existe în codul final, dar aplicațiile îl pot găsi util în anumite situații în care erorile trebuie înregistrate înainte de a fi aruncate.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // această secvență iteratoare este complexă.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // să adăugăm câteva apeluri inspect() pentru a investiga ce se întâmplă
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Aceasta va tipări:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Erori de înregistrare înainte de a le arunca:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Aceasta va tipări:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Împrumută un iterator, mai degrabă decât să-l consume.
    ///
    /// Acest lucru este util pentru a permite aplicarea adaptoarelor de iterator, păstrând în același timp proprietatea asupra iteratorului original.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // dacă încercăm să-l folosim din nou, nu va funcționa.
    /// // Următorul rând indică " eroare: utilizarea valorii mutate: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // să încercăm din nou asta
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // în schimb, adăugăm un .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // acum este foarte bine:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transformă un iterator într-o colecție.
    ///
    /// `collect()` poate lua orice iterabil și îl poate transforma într-o colecție relevantă.
    /// Aceasta este una dintre cele mai puternice metode din biblioteca standard, utilizată într-o varietate de contexte.
    ///
    /// Cel mai de bază model în care este utilizat `collect()` este de a transforma o colecție în alta.
    /// Luați o colecție, apelați [`iter`] pe ea, faceți o grămadă de transformări și apoi `collect()` la sfârșit.
    ///
    /// `collect()` poate crea, de asemenea, instanțe de tipuri care nu sunt colecții tipice.
    /// De exemplu, un [`String`] poate fi construit din [`char`] s, iar un iterator de articole [`Result<T, E>`][`Result`] poate fi colectat în `Result<Collection<T>, E>`.
    ///
    /// Vedeți exemplele de mai jos pentru mai multe.
    ///
    /// Deoarece `collect()` este atât de general, poate cauza probleme cu inferența de tip.
    /// Ca atare, `collect()` este una dintre puținele ocazii în care veți vedea sintaxa cunoscută cu afecțiune sub numele de 'turbofish': `::<>`.
    /// Acest lucru ajută algoritmul de inferență să înțeleagă în mod specific în ce colecție încercați să colectați.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Rețineți că aveam nevoie de `: Vec<i32>` pe partea stângă.Acest lucru se datorează faptului că am putea colecta, de exemplu, un [`VecDeque<T>`] în schimb:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Utilizarea 'turbofish' în loc de adnotarea `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Deoarece lui `collect()` îi pasă doar de ceea ce colectezi, poți folosi în continuare un indiciu de tip parțial, `_`, cu turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Folosind `collect()` pentru a crea un [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Dacă aveți o listă cu [`Rezultat<T, E>`][`Result`] s, puteți utiliza `collect()` pentru a vedea dacă vreunul dintre ele nu a reușit:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ne dă prima eroare
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ne oferă lista răspunsurilor
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Consumă un iterator, creând două colecții din acesta.
    ///
    /// Predicatul trecut la `partition()` poate returna `true` sau `false`.
    /// `partition()` returnează o pereche, toate elementele pentru care a returnat `true` și toate elementele pentru care a returnat `false`.
    ///
    ///
    /// Vezi și [`is_partitioned()`] și [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reordonează elementele acestui iterator *în loc* în funcție de predicatul dat, astfel încât toți cei care returnează `true` să preceadă pe toți cei care returnează `false`.
    ///
    /// Returnează numărul de elemente `true` găsite.
    ///
    /// Ordinea relativă a elementelor partiționate nu este menținută.
    ///
    /// Vezi și [`is_partitioned()`] și [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Împărțirea în loc între egal și cote
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ar trebui să ne facem griji cu privire la numărul debordant?Singura modalitate de a avea mai mult de
        // `usize::MAX` referințele mutabile sunt cu ZST-uri, care nu sunt utile pentru partiționare ...

        // Aceste funcții de închidere "factory" există pentru a evita genericitatea în `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Găsiți în mod repetat primul `false` și schimbați-l cu ultimul `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Verifică dacă elementele acestui iterator sunt partiționate în funcție de predicatul dat, astfel încât toți cei care returnează `true` să preceadă toți cei care returnează `false`.
    ///
    ///
    /// Vezi și [`partition()`] și [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Fie toate articolele testează `true`, fie prima clauză se oprește la `false` și verificăm dacă nu mai există articole `true` după aceea.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// O metodă iterator care aplică o funcție atâta timp cât revine cu succes, producând o singură valoare finală.
    ///
    /// `try_fold()` ia două argumente: o valoare inițială și o închidere cu două argumente: un 'accumulator' și un element.
    /// Închiderea fie revine cu succes, cu valoarea pe care acumulatorul ar trebui să o aibă pentru următoarea iterație, fie returnează eșecul, cu o valoare de eroare care este propagată înapoi către apelant imediat (short-circuiting).
    ///
    ///
    /// Valoarea inițială este valoarea pe care acumulatorul o va avea la primul apel.Dacă aplicarea închiderii a reușit împotriva fiecărui element al iteratorului, `try_fold()` returnează acumulatorul final ca succes.
    ///
    /// Plierea este utilă ori de câte ori aveți o colecție de ceva și doriți să produceți o singură valoare din aceasta.
    ///
    /// # Notă pentru implementatori
    ///
    /// Multe dintre celelalte metode (forward) au implementări implicite în ceea ce privește aceasta, așa că încercați să implementați acest lucru în mod explicit dacă poate face ceva mai bun decât implementarea implicită a buclei `for`.
    ///
    /// În special, încercați să aveți acest apel `try_fold()` pe părțile interne din care este compus acest iterator.
    /// Dacă sunt necesare mai multe apeluri, operatorul `?` poate fi convenabil pentru înlănțuirea valorii acumulatorului, dar aveți grijă la orice invarianți care trebuie confirmate înainte de întoarcerea timpurie.
    /// Aceasta este o metodă `&mut self`, deci iterația trebuie reluată după ce ați lovit o eroare aici.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // suma verificată a tuturor elementelor matricei
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Această sumă se revarsă la adăugarea elementului 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Deoarece s-a scurtcircuitat, elementele rămase sunt încă disponibile prin iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// O metodă iterator care aplică o funcție falibilă fiecărui element din iterator, oprindu-se la prima eroare și returnând acea eroare.
    ///
    ///
    /// Acest lucru poate fi, de asemenea, considerat ca forma falibilă a [`for_each()`] sau ca versiunea apatridă a [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // S-a scurtcircuitat, deci elementele rămase sunt încă în iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Pliază fiecare element într-un acumulator prin aplicarea unei operații, returnând rezultatul final.
    ///
    /// `fold()` ia două argumente: o valoare inițială și o închidere cu două argumente: un 'accumulator' și un element.
    /// Închiderea returnează valoarea pe care acumulatorul ar trebui să o aibă pentru următoarea iterație.
    ///
    /// Valoarea inițială este valoarea pe care acumulatorul o va avea la primul apel.
    ///
    /// După aplicarea acestei închideri la fiecare element al iteratorului, `fold()` returnează acumulatorul.
    ///
    /// Această operație se numește uneori 'reduce' sau 'inject'.
    ///
    /// Plierea este utilă ori de câte ori aveți o colecție de ceva și doriți să produceți o singură valoare din aceasta.
    ///
    /// Note: `fold()` și alte metode similare care traversează întregul iterator, nu se pot termina pentru iteratoare infinite, chiar și pe traits pentru care un rezultat este determinabil în timp finit.
    ///
    /// Note: [`reduce()`] poate fi utilizat pentru a utiliza primul element ca valoare inițială, dacă tipul acumulatorului și tipul articolului sunt aceleași.
    ///
    /// # Notă pentru implementatori
    ///
    /// Multe dintre celelalte metode (forward) au implementări implicite în ceea ce privește aceasta, așa că încercați să implementați acest lucru în mod explicit dacă poate face ceva mai bun decât implementarea implicită a buclei `for`.
    ///
    ///
    /// În special, încercați să aveți acest apel `fold()` pe părțile interne din care este compus acest iterator.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // suma tuturor elementelor matricei
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Să parcurgem fiecare pas al iterației aici:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Și așa, rezultatul nostru final, `6`.
    ///
    /// Este obișnuit ca persoanele care nu au folosit mult iteratorii să folosească o buclă `for` cu o listă de lucruri pentru a construi un rezultat.Acestea pot fi transformate în `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // pentru bucla:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // sunt la fel
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduce elementele la unul singur, aplicând în mod repetat o operație de reducere.
    ///
    /// Dacă iteratorul este gol, returnează [`None`];în caz contrar, returnează rezultatul reducerii.
    ///
    /// Pentru iteratorii cu cel puțin un element, acesta este la fel ca [`fold()`] cu primul element al iteratorului ca valoare inițială, pliant fiecare element ulterior în el.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Găsiți valoarea maximă:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testează dacă fiecare element al iteratorului se potrivește cu un predicat.
    ///
    /// `all()` preia o închidere care returnează `true` sau `false`.Aplică această închidere fiecărui element al iteratorului și, dacă toate returnează `true`, la fel și `all()`.
    /// Dacă oricare dintre ele returnează `false`, acesta returnează `false`.
    ///
    /// `all()` este în scurtcircuit;cu alte cuvinte, se va opri din procesare imediat ce va găsi un `false`, dat fiind că, indiferent ce s-ar mai întâmpla, rezultatul va fi și `false`.
    ///
    ///
    /// Un iterator gol returnează `true`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Oprire la primul `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // putem folosi în continuare `iter`, deoarece există mai multe elemente.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testează dacă vreun element al iteratorului se potrivește cu un predicat.
    ///
    /// `any()` preia o închidere care returnează `true` sau `false`.Aplică această închidere fiecărui element al iteratorului și, dacă vreunul dintre ele returnează `true`, la fel și `any()`.
    /// Dacă toți returnează `false`, acesta returnează `false`.
    ///
    /// `any()` este în scurtcircuit;cu alte cuvinte, se va opri din procesare imediat ce va găsi un `true`, dat fiind că, indiferent ce s-ar mai întâmpla, rezultatul va fi și `true`.
    ///
    ///
    /// Un iterator gol returnează `false`.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Oprire la primul `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // putem folosi în continuare `iter`, deoarece există mai multe elemente.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Căutați un element al unui iterator care satisface un predicat.
    ///
    /// `find()` preia o închidere care returnează `true` sau `false`.
    /// Aplică această închidere fiecărui element al iteratorului și, dacă oricare dintre ele returnează `true`, atunci `find()` returnează [`Some(element)`].
    /// Dacă toți returnează `false`, acesta returnează [`None`].
    ///
    /// `find()` este în scurtcircuit;cu alte cuvinte, va înceta procesarea de îndată ce închiderea returnează `true`.
    ///
    /// Deoarece `find()` ia o referință, iar mulți iteratori iterați peste referințe, aceasta duce la o situație posibil confuză în care argumentul este o referință dublă.
    ///
    /// Puteți vedea acest efect în exemplele de mai jos, cu `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Oprire la primul `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // putem folosi în continuare `iter`, deoarece există mai multe elemente.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Rețineți că `iter.find(f)` este echivalent cu `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Aplică funcția elementelor iteratorului și returnează primul rezultat non-none.
    ///
    ///
    /// `iter.find_map(f)` este echivalent cu `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Aplică funcția elementelor iteratorului și returnează primul rezultat adevărat sau prima eroare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Căutați un element într-un iterator, returnând indexul acestuia.
    ///
    /// `position()` preia o închidere care returnează `true` sau `false`.
    /// Aplică această închidere fiecărui element al iteratorului și dacă unul dintre ele returnează `true`, atunci `position()` returnează [`Some(index)`].
    /// Dacă toți returnează `false`, acesta returnează [`None`].
    ///
    /// `position()` este în scurtcircuit;cu alte cuvinte, va înceta procesarea imediat ce va găsi un `true`.
    ///
    /// # Comportament de revărsare
    ///
    /// Metoda nu protejează împotriva revărsărilor, deci dacă există mai mult de [`usize::MAX`] elemente care nu se potrivesc, fie produce rezultatul greșit, fie panics.
    ///
    /// Dacă sunt activate afirmațiile de depanare, este garantat un panic.
    ///
    /// # Panics
    ///
    /// Această funcție ar putea panic dacă iteratorul are mai mult de `usize::MAX` elemente care nu se potrivesc.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Oprire la primul `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // putem folosi în continuare `iter`, deoarece există mai multe elemente.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Indicele returnat depinde de starea iteratorului
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Căutați un element dintr-un iterator din dreapta, returnând indexul acestuia.
    ///
    /// `rposition()` preia o închidere care returnează `true` sau `false`.
    /// Aplică această închidere fiecărui element al iteratorului, începând de la sfârșit, iar dacă unul dintre ele returnează `true`, atunci `rposition()` returnează [`Some(index)`].
    ///
    /// Dacă toți returnează `false`, acesta returnează [`None`].
    ///
    /// `rposition()` este în scurtcircuit;cu alte cuvinte, va înceta procesarea imediat ce va găsi un `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Oprire la primul `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // putem folosi în continuare `iter`, deoarece există mai multe elemente.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Nu este nevoie de o verificare a depășirii aici, deoarece `ExactSizeIterator` implică faptul că numărul de elemente se potrivește într-un `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Returnează elementul maxim al unui iterator.
    ///
    /// Dacă mai multe elemente sunt la fel de maxime, ultimul element este returnat.
    /// Dacă iteratorul este gol, [`None`] este returnat.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Returnează elementul minim al unui iterator.
    ///
    /// Dacă mai multe elemente sunt la fel de minime, primul element este returnat.
    /// Dacă iteratorul este gol, [`None`] este returnat.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Returnează elementul care dă valoarea maximă din funcția specificată.
    ///
    ///
    /// Dacă mai multe elemente sunt la fel de maxime, ultimul element este returnat.
    /// Dacă iteratorul este gol, [`None`] este returnat.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Returnează elementul care oferă valoarea maximă în raport cu funcția de comparație specificată.
    ///
    ///
    /// Dacă mai multe elemente sunt la fel de maxime, ultimul element este returnat.
    /// Dacă iteratorul este gol, [`None`] este returnat.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Returnează elementul care dă valoarea minimă din funcția specificată.
    ///
    ///
    /// Dacă mai multe elemente sunt la fel de minime, primul element este returnat.
    /// Dacă iteratorul este gol, [`None`] este returnat.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Returnează elementul care oferă valoarea minimă în raport cu funcția de comparație specificată.
    ///
    ///
    /// Dacă mai multe elemente sunt la fel de minime, primul element este returnat.
    /// Dacă iteratorul este gol, [`None`] este returnat.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inversează direcția unui iterator.
    ///
    /// De obicei, iteratorii itera de la stânga la dreapta.
    /// După utilizarea `rev()`, un iterator va itera în schimb de la dreapta la stânga.
    ///
    /// Acest lucru este posibil numai dacă iteratorul are un capăt, deci `rev()` funcționează numai pe [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Convertește un iterator de perechi într-o pereche de containere.
    ///
    /// `unzip()` consumă un întreg iterator de perechi, producând două colecții: una din elementele din stânga perechilor și una din elementele din dreapta.
    ///
    ///
    /// Această funcție este, într-un anumit sens, opusă [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Creează un iterator care copiază toate elementele sale.
    ///
    /// Acest lucru este util atunci când aveți un iterator peste `&T`, dar aveți nevoie de un iterator peste `T`.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copiat este același cu .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Creează un iterator care [" clonează`] toate elementele sale.
    ///
    /// Acest lucru este util atunci când aveți un iterator peste `&T`, dar aveți nevoie de un iterator peste `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // clonat este același cu .map(|&x| x), pentru numere întregi
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Repetă un iterator la nesfârșit.
    ///
    /// În loc să se oprească la [`None`], iteratorul va începe din nou, de la început.După repetarea iterării, va începe din nou la început.Și din nou.
    /// Și din nou.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Rezumă elementele unui iterator.
    ///
    /// Ia fiecare element, le adaugă împreună și returnează rezultatul.
    ///
    /// Un iterator gol returnează valoarea zero a tipului.
    ///
    /// # Panics
    ///
    /// Când se apelează `sum()` și se returnează un tip întreg primitiv, această metodă va panic dacă deversările de calcul și afirmațiile de depanare sunt activate.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterează pe întregul iterator, multiplicând toate elementele
    ///
    /// Un iterator gol returnează singura valoare a tipului.
    ///
    /// # Panics
    ///
    /// Când se apelează `product()` și se returnează un tip întreg primitiv, metoda va panic în cazul în care deversările de calcul și afirmațiile de depanare sunt activate.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compară elementele acestui [`Iterator`] cu cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compară elementele acestui [`Iterator`] cu cele ale altuia în ceea ce privește funcția de comparație specificată.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compară elementele acestui [`Iterator`] cu cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compară elementele acestui [`Iterator`] cu cele ale altuia în ceea ce privește funcția de comparație specificată.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determină dacă elementele acestui [`Iterator`] sunt egale cu cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determină dacă elementele acestui [`Iterator`] sunt egale cu cele ale altuia în ceea ce privește funcția de egalitate specificată.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determină dacă elementele acestui [`Iterator`] sunt inegale cu cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determină dacă elementele acestui [`Iterator`] sunt [lexicographically](Ord#lexicographical-comparison) mai mici decât cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determină dacă elementele acestui [`Iterator`] sunt [lexicographically](Ord#lexicographical-comparison) mai mici sau egale cu cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determină dacă elementele acestui [`Iterator`] sunt [lexicographically](Ord#lexicographical-comparison) mai mari decât cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determină dacă elementele acestui [`Iterator`] sunt [lexicographically](Ord#lexicographical-comparison) mai mari sau egale cu cele ale altuia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Verifică dacă elementele acestui iterator sunt sortate.
    ///
    /// Adică, pentru fiecare element `a` și următorul său element `b`, `a <= b` trebuie să păstreze.Dacă iteratorul produce exact zero sau un element, `true` este returnat.
    ///
    /// Rețineți că dacă `Self::Item` este doar `PartialOrd`, dar nu `Ord`, definiția de mai sus implică faptul că această funcție returnează `false` dacă oricare două elemente consecutive nu sunt comparabile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Verifică dacă elementele acestui iterator sunt sortate folosind funcția de comparare dată.
    ///
    /// În loc să utilizeze `PartialOrd::partial_cmp`, această funcție folosește funcția dată `compare` pentru a determina ordinea a două elemente.
    /// În afară de asta, este echivalent cu [`is_sorted`];consultați documentația pentru mai multe informații.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Verifică dacă elementele acestui iterator sunt sortate utilizând funcția dată de extragere a cheilor.
    ///
    /// În loc să compare elementele iteratorului direct, această funcție compară cheile elementelor, așa cum este determinat de `f`.
    /// În afară de asta, este echivalent cu [`is_sorted`];consultați documentația pentru mai multe informații.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Vezi [TrustedRandomAccess]
    // Numele neobișnuit este de a evita coliziunile de nume în rezoluția metodei, vezi #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}