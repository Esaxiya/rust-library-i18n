/// Conversie de pe un [`Iterator`].
///
/// Prin implementarea `FromIterator` pentru un tip, definiți cum va fi creat dintr-un iterator.
/// Acest lucru este comun pentru tipurile care descriu o colecție de un fel.
///
/// [`FromIterator::from_iter()`] este rar apelat în mod explicit și este folosit în schimb prin metoda [`Iterator::collect()`].
///
/// Consultați documentația [`Iterator::collect()`]'s pentru mai multe exemple.
///
/// Vezi si: [`IntoIterator`].
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Folosind [`Iterator::collect()`] pentru a utiliza implicit `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementarea `FromIterator` pentru tipul dvs.:
///
/// ```
/// use std::iter::FromIterator;
///
/// // O colecție de eșantioane, care este doar o învelitoare peste Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Să îi oferim câteva metode, astfel încât să putem crea una și să îi adăugăm lucruri.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // și vom implementa FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Acum putem face un nou iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... și faceți o colecție My din ea
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // culege și tu lucrări!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Creează o valoare dintr-un iterator.
    ///
    /// Vedeți [module-level documentation] pentru mai multe.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversia într-un [`Iterator`].
///
/// Prin implementarea `IntoIterator` pentru un tip, definiți cum va fi convertit într-un iterator.
/// Acest lucru este comun pentru tipurile care descriu o colecție de un fel.
///
/// Un avantaj al implementării `IntoIterator` este că tipul dvs. va [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Vezi si: [`FromIterator`].
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementarea `IntoIterator` pentru tipul dvs.:
///
/// ```
/// // O colecție de eșantioane, care este doar o învelitoare peste Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Să îi oferim câteva metode, astfel încât să putem crea una și să îi adăugăm lucruri.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // și vom implementa IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Acum putem face o nouă colecție ...
/// let mut c = MyCollection::new();
///
/// // ... adaugă câteva lucruri la el ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... și apoi transformați-l într-un Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Este obișnuit să folosiți `IntoIterator` ca trait bound.Aceasta permite schimbarea tipului de colectare a intrărilor, atâta timp cât este încă un iterator.
/// Limitele suplimentare pot fi specificate prin restricționarea pe
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Tipul elementelor care se repetă.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// În ce fel de iterator transformăm acest lucru?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Creează un iterator dintr-o valoare.
    ///
    /// Vedeți [module-level documentation] pentru mai multe.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Extindeți o colecție cu conținutul unui iterator.
///
/// Iteratorii produc o serie de valori, iar colecțiile pot fi, de asemenea, considerate ca o serie de valori.
/// `Extend` trait elimină acest decalaj, permițându-vă să extindeți o colecție prin includerea conținutului acelui iterator.
/// Atunci când extindeți o colecție cu o cheie deja existentă, acea intrare este actualizată sau, în cazul colecțiilor care permit mai multe intrări cu chei egale, se introduce această intrare.
///
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// // Puteți extinde un șir cu câteva caractere:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementarea `Extend`:
///
/// ```
/// // O colecție de eșantioane, care este doar o învelitoare peste Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Să îi oferim câteva metode, astfel încât să putem crea una și să îi adăugăm lucruri.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // deoarece MyCollection are o listă de i32-uri, implementăm Extend pentru i32
/// impl Extend<i32> for MyCollection {
///
///     // Acest lucru este un pic mai simplu cu semnătura de tip concret: putem apela extinde pe orice poate fi transformat într-un Iterator care ne oferă i32-uri.
///     // Pentru că avem nevoie de i32-uri pentru a le introduce în MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Implementarea este foarte simplă: parcurgeți iteratorul și add() fiecare element pentru noi înșine.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // să extindem colecția noastră cu încă trei numere
/// c.extend(vec![1, 2, 3]);
///
/// // am adăugat aceste elemente la final
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Extinde o colecție cu conținutul unui iterator.
    ///
    /// Deoarece aceasta este singura metodă necesară pentru acest trait, documentele [trait-level] conțin mai multe detalii.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // Puteți extinde un șir cu câteva caractere:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Extinde o colecție cu exact un element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezervă capacitatea într-o colecție pentru numărul dat de elemente suplimentare.
    ///
    /// Implementarea implicită nu face nimic.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}