/// Un iterator care își cunoaște lungimea exactă.
///
/// Mulți [" Iterator`] nu știu de câte ori vor itera, dar unii o fac.
/// Dacă un iterator știe de câte ori poate itera, furnizarea accesului la informațiile respective poate fi utilă.
/// De exemplu, dacă doriți să iterați înapoi, un început bun este să știți unde este sfârșitul.
///
/// Când implementați un `ExactSizeIterator`, trebuie să implementați și [`Iterator`].
/// Când faceți acest lucru, implementarea [`Iterator::size_hint`]*trebuie* să returneze dimensiunea exactă a iteratorului.
///
/// Metoda [`len`] are o implementare implicită, deci nu trebuie să o implementați de obicei.
/// Cu toate acestea, este posibil să puteți furniza o implementare mai performantă decât cea implicită, așa că suprascrierea în acest caz are sens.
///
///
/// Rețineți că acest trait este un trait sigur și ca atare *nu* și *nu poate* garanta că lungimea returnată este corectă.
/// Aceasta înseamnă că codul `unsafe`**nu trebuie** să se bazeze pe corectitudinea [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait instabil și nesigur oferă această garanție suplimentară.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// // o gamă finită știe exact de câte ori va itera
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// În [module-level docs], am implementat un [`Iterator`], `Counter`.
/// Să implementăm și `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Putem calcula cu ușurință numărul rămas de iterații.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Și acum îl putem folosi!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Returnează lungimea exactă a iteratorului.
    ///
    /// Implementarea asigură faptul că iteratorul va returna exact `len()` de mai multe ori decât valoarea [`Some(T)`], înainte de a returna [`None`].
    ///
    /// Această metodă are o implementare implicită, deci nu trebuie să o implementați direct.
    /// Cu toate acestea, dacă puteți oferi o implementare mai eficientă, puteți face acest lucru.
    /// Consultați documentele [trait-level] pentru un exemplu.
    ///
    /// Această funcție are aceleași garanții de siguranță ca și funcția [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// // o gamă finită știe exact de câte ori va itera
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Această afirmație este excesiv de defensivă, dar verifică invariantul
        // garantat de trait.
        // Dacă acest trait ar fi rust-intern, am putea folosi debug_assert !;afirmă_eq!va verifica și toate implementările utilizatorului Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Returnează `true` dacă iteratorul este gol.
    ///
    /// Această metodă are o implementare implicită folosind [`ExactSizeIterator::len()`], deci nu este nevoie să o implementați singur.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}