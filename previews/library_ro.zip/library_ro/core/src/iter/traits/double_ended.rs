use crate::ops::{ControlFlow, Try};

/// Un iterator capabil să producă elemente de la ambele capete.
///
/// Ceva care implementează `DoubleEndedIterator` are o capacitate suplimentară față de ceva care implementează [`Iterator`]: abilitatea de a lua și " Item`s din spate, precum și din față.
///
///
/// Este important să rețineți că atât înainte cât și înapoi funcționează pe același interval și nu se încrucișează: iterația se termină atunci când se întâlnesc în mijloc.
///
/// În mod similar cu protocolul [`Iterator`], odată ce un `DoubleEndedIterator` returnează [`None`] de pe un [`next_back()`], apelarea acestuia din nou poate sau nu să returneze [`Some`] din nou.
/// [`next()`] și [`next_back()`] sunt interschimbabile în acest scop.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Elimină și returnează un element de la sfârșitul iteratorului.
    ///
    /// Returnează `None` când nu mai există elemente.
    ///
    /// Documentele [trait-level] conțin mai multe detalii.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementele obținute prin metodele " DoubleEndedIterator`pot diferi de cele obținute prin metodele [[Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Avansează iteratorul din spate cu elemente `n`.
    ///
    /// `advance_back_by` este versiunea inversă a [`advance_by`].Această metodă va omite cu nerăbdare elementele `n` începând din spate, apelând [`next_back`] de până la `n` ori până când se întâlnește [`None`].
    ///
    /// `advance_back_by(n)` va returna [`Ok(())`] dacă iteratorul avansează cu succes cu elementele `n` sau [`Err(k)`] dacă se întâlnește [`None`], unde `k` este numărul de elemente pe care iteratorul este avansat înainte de a rămâne fără elemente (adică
    /// lungimea iteratorului).
    /// Rețineți că `k` este întotdeauna mai mic decât `n`.
    ///
    /// Apelarea la `advance_back_by(0)` nu consumă niciun element și returnează întotdeauna [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // doar `&3` a fost omis
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Returnează elementul `n`th de la sfârșitul iteratorului.
    ///
    /// Aceasta este în esență versiunea inversată a [`Iterator::nth()`].
    /// Deși la fel ca majoritatea operațiilor de indexare, numărul începe de la zero, deci `nth_back(0)` returnează prima valoare de la sfârșit, `nth_back(1)` a doua și așa mai departe.
    ///
    ///
    /// Rețineți că toate elementele dintre final și elementul returnat vor fi consumate, inclusiv elementul returnat.
    /// Acest lucru înseamnă, de asemenea, că apelarea `nth_back(0)` de mai multe ori pe același iterator va restitui elemente diferite.
    ///
    /// `nth_back()` va returna [`None`] dacă `n` este mai mare sau egală cu lungimea iteratorului.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Apelarea `nth_back()` de mai multe ori nu derulează înapoi iteratorul:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Se returnează `None` dacă există mai puțin de elemente `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Aceasta este versiunea inversă a [`Iterator::try_fold()`]: are nevoie de elemente începând din spatele iteratorului.
    ///
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Deoarece s-a scurtcircuitat, elementele rămase sunt încă disponibile prin iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// O metodă iterator care reduce elementele iteratorului la o singură valoare finală, începând din spate.
    ///
    /// Aceasta este versiunea inversă a [`Iterator::fold()`]: are nevoie de elemente începând din spatele iteratorului.
    ///
    /// `rfold()` ia două argumente: o valoare inițială și o închidere cu două argumente: un 'accumulator' și un element.
    /// Închiderea returnează valoarea pe care acumulatorul ar trebui să o aibă pentru următoarea iterație.
    ///
    /// Valoarea inițială este valoarea pe care acumulatorul o va avea la primul apel.
    ///
    /// După aplicarea acestei închideri la fiecare element al iteratorului, `rfold()` returnează acumulatorul.
    ///
    /// Această operație se numește uneori 'reduce' sau 'inject'.
    ///
    /// Plierea este utilă ori de câte ori aveți o colecție de ceva și doriți să produceți o singură valoare din aceasta.
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // suma tuturor elementelor unui
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Acest exemplu construiește un șir, începând cu o valoare inițială și continuând cu fiecare element din spate până în față:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Caută un element al unui iterator din spate care să satisfacă un predicat.
    ///
    /// `rfind()` preia o închidere care returnează `true` sau `false`.
    /// Aplică această închidere fiecărui element al iteratorului, începând de la sfârșit și, dacă vreunul dintre ele returnează `true`, atunci `rfind()` returnează [`Some(element)`].
    /// Dacă toți returnează `false`, acesta returnează [`None`].
    ///
    /// `rfind()` este în scurtcircuit;cu alte cuvinte, va înceta procesarea de îndată ce închiderea returnează `true`.
    ///
    /// Deoarece `rfind()` ia o referință, iar mulți iteratori iterați peste referințe, aceasta duce la o situație posibil confuză în care argumentul este o referință dublă.
    ///
    /// Puteți vedea acest efect în exemplele de mai jos, cu `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizare de bază:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Oprire la primul `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // putem folosi în continuare `iter`, deoarece există mai multe elemente.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}