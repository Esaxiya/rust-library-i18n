/// Un iterator care continuă să producă întotdeauna `None` când este epuizat.
///
/// Apelarea următoare pe un iterator fuzionat care a returnat `None` o dată este garantată pentru a returna din nou [`None`].
/// Acest trait ar trebui implementat de toți iteratorii care se comportă astfel, deoarece permite optimizarea [`Iterator::fuse()`].
///
///
/// Note: În general, nu ar trebui să utilizați `FusedIterator` în limite generice dacă aveți nevoie de un iterator fuzionat.
/// În schimb, trebuie să apelați [`Iterator::fuse()`] pe iterator.
/// Dacă iteratorul este deja fuzionat, învelitoarea [`Fuse`] suplimentară va fi o opțiune fără penalizare de performanță.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Un iterator care raportează o lungime exactă folosind size_hint.
///
/// Iteratorul raportează un indiciu de dimensiune în care este fie exact (limita inferioară este egală cu limita superioară), fie limita superioară este [`None`].
///
/// Limita superioară trebuie să fie [`None`] numai dacă lungimea reală a iteratorului este mai mare decât [`usize::MAX`].
/// În acest caz, limita inferioară trebuie să fie [`usize::MAX`], rezultând un [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// Iteratorul trebuie să producă exact numărul de elemente raportate sau divergente înainte de a ajunge la final.
///
/// # Safety
///
/// Acest trait trebuie implementat numai atunci când contractul este confirmat.
/// Consumatorii acestui trait trebuie să inspecteze limita superioară [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Un iterator care atunci când cedează un articol va fi luat cel puțin un element din [`SourceIter`]-ul său de bază.
///
/// Apelarea oricărei metode care avansează iteratorul, de ex
/// [`next()`] sau [`try_fold()`], garantează că pentru fiecare pas a fost mutată cel puțin o valoare a sursei subiacente a iteratorului și rezultatul lanțului iteratorului ar putea fi inserat în locul său, presupunând că constrângerile structurale ale sursei permit o astfel de inserție.
///
/// Cu alte cuvinte, acest trait indică faptul că o conductă iterator poate fi colectată în loc.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}