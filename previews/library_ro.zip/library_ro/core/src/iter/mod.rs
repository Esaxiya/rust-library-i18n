//! Iterație externă compozabilă.
//!
//! Dacă v-ați găsit cu o colecție de un fel și ați avut nevoie să efectuați o operație asupra elementelor respectivei colecții, veți rula rapid în 'iterators'.
//! Iteratorii sunt foarte folosiți în codul idiomatic Rust, deci merită să vă familiarizați cu ei.
//!
//! Înainte de a explica mai multe, să vorbim despre modul în care este structurat acest modul:
//!
//! # Organization
//!
//! Acest modul este organizat în mare parte pe tipuri:
//!
//! * [Traits] sunt porțiunea principală: aceste traits definesc ce fel de iteratori există și ce puteți face cu ei.Metodele acestor traits merită să punem ceva timp de studiu în plus.
//! * [Functions] oferiți câteva modalități utile de a crea iteratori de bază.
//! * [Structs] sunt deseori tipurile de returnare ale diferitelor metode de pe traits ale acestui modul.De obicei, veți dori să vă uitați la metoda care creează `struct`, mai degrabă decât `struct` în sine.
//! Pentru mai multe detalii despre de ce, consultați " [Implementing Iterator](#Implementing-iterator)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Asta este!Să săpăm în iteratori.
//!
//! # Iterator
//!
//! Inima și sufletul acestui modul este [`Iterator`] trait.Miezul [`Iterator`] arată astfel:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Un iterator are o metodă, [`next`], care, atunci când este apelat, returnează un [`Option`]`<Item>`.
//! [`next`] va returna [`Some(Item)`] atâta timp cât există elemente și, odată ce au fost epuizate, va returna `None` pentru a indica faptul că iterația este terminată.
//! Iteratorii individuali pot alege să reia iterația și, prin urmare, apelarea din nou a [`next`] poate sau nu poate începe în cele din urmă să returneze [`Some(Item)`] din nou la un moment dat (de exemplu, consultați [`TryIter`]).
//!
//!
//! Definiția completă a [" Iterator`] include și o serie de alte metode, dar sunt metode implicite, construite pe [`next`], astfel încât să le obțineți gratuit.
//!
//! Iteratoarele sunt, de asemenea, compozibile și este obișnuit să le legați împreună pentru a face forme mai complexe de procesare.Consultați secțiunea [Adapters](#adapters) de mai jos pentru mai multe detalii.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Cele trei forme de iterație
//!
//! Există trei metode comune care pot crea iteratori dintr-o colecție:
//!
//! * `iter()`, care repetă peste `&T`.
//! * `iter_mut()`, care repetă peste `&mut T`.
//! * `into_iter()`, care repetă peste `T`.
//!
//! Diverse lucruri din biblioteca standard pot implementa unul sau mai multe dintre cele trei, după caz.
//!
//! # Implementarea Iterator
//!
//! Crearea unui iterator propriu implică doi pași: crearea unui `struct` pentru a păstra starea iteratorului și apoi implementarea [`Iterator`] pentru acel `struct`.
//! Acesta este motivul pentru care există atât de multe structuri în acest modul: există câte unul pentru fiecare iterator și adaptor de iterator.
//!
//! Să facem un iterator numit `Counter` care contează de la `1` la `5`:
//!
//! ```
//! // În primul rând, structura:
//!
//! /// Un iterator care contează de la unu la cinci
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vrem ca numărul nostru să înceapă de la unul, așa că haideți să adăugăm o metodă new() pentru a vă ajuta.
//! // Acest lucru nu este strict necesar, dar este convenabil.
//! // Rețineți că pornim `count` la zero, vom vedea de ce în implementarea `next()`'s mai jos.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Apoi, implementăm `Iterator` pentru `Counter`:
//!
//! impl Iterator for Counter {
//!     // vom conta cu uzura
//!     type Item = usize;
//!
//!     // next() este singura metodă necesară
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Creșteți numărul nostru.Acesta este motivul pentru care am început de la zero.
//!         self.count += 1;
//!
//!         // Verificați dacă am terminat de numărat sau nu.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Și acum îl putem folosi!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Apelarea [`next`] în acest fel devine repetitivă.Rust are o construcție care poate apela [`next`] pe iteratorul dvs., până când ajunge la `None`.Să trecem peste asta în continuare.
//!
//! De asemenea, rețineți că `Iterator` oferă o implementare implicită a metodelor precum `nth` și `fold` care apelează intern `next`.
//! Cu toate acestea, este de asemenea posibil să scrieți o implementare personalizată a metodelor precum `nth` și `fold` dacă un iterator le poate calcula mai eficient fără a apela `next`.
//!
//! # `for` bucle și `IntoIterator`
//!
//! Sintaxa buclei `for` a lui Rust este de fapt zahăr pentru iteratori.Iată un exemplu de bază pentru `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Aceasta va imprima numerele de la unu la cinci, fiecare pe propria linie.Dar veți observa ceva aici: nu am apelat niciodată nimic la vector pentru a produce un iterator.Ce dă?
//!
//! Există un trait în biblioteca standard pentru a converti ceva într-un iterator: [`IntoIterator`].
//! Acest trait are o singură metodă, [`into_iter`], care transformă lucrul care implementează [`IntoIterator`] într-un iterator.
//! Să aruncăm o privire la bucla `for` din nou și în ce îl transformă compilatorul:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust elimină zaharurile în:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Mai întâi, apelăm `into_iter()` pentru valoare.Apoi, ne potrivim pe iteratorul care revine, apelând [`next`] de mai multe ori până când vedem un `None`.
//! În acel moment, `break` ieșim din buclă și am terminat iterarea.
//!
//! Există încă un bit subtil aici: biblioteca standard conține o implementare interesantă a [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Cu alte cuvinte, toate [`Iterator`] implementează [`IntoIterator`], doar revenind singuri.Aceasta înseamnă două lucruri:
//!
//! 1. Dacă scrieți un [`Iterator`], îl puteți folosi cu o buclă `for`.
//! 2. Dacă creați o colecție, implementarea [`IntoIterator`] pentru aceasta va permite colecția dvs. să fie utilizată cu bucla `for`.
//!
//! # Iterând prin referință
//!
//! Deoarece [`into_iter()`] ia `self` în funcție de valoare, utilizarea unei bucle `for` pentru a itera peste o colecție consumă acea colecție.Adesea, poate doriți să repetați o colecție fără a o consuma.
//! Multe colecții oferă metode care oferă iteratori peste referințe, denumite în mod convențional `iter()` și respectiv `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` este încă deținut de această funcție.
//! ```
//!
//! Dacă o colecție de tip `C` oferă `iter()`, de obicei implementează și `IntoIterator` pentru `&C`, cu o implementare care apelează doar `iter()`.
//! La fel, o colecție `C` care oferă `iter_mut()` implementează, în general, `IntoIterator` pentru `&mut C` prin delegarea către `iter_mut()`.Aceasta permite o scurtare convenabilă:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // la fel ca `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // la fel ca `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! În timp ce multe colecții oferă `iter()`, nu toate oferă `iter_mut()`.
//! De exemplu, mutarea cheilor unui [`HashSet<T>`] sau [`HashMap<K, V>`] ar putea pune colecția într-o stare inconsistentă dacă se schimbă hash-ul cheii, astfel încât aceste colecții oferă doar `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funcțiile care iau un [`Iterator`] și returnează un alt [`Iterator`] sunt adesea numite " adaptoare iteratoare`, deoarece sunt o formă a " adaptorului
//! pattern'.
//!
//! Adaptoarele obișnuite de iterare includ [`map`], [`take`] și [`filter`].
//! Pentru mai multe informații, consultați documentația acestora.
//!
//! Dacă un adaptor de iterator panics, iteratorul va fi într-o stare nespecificată (dar sigură pentru memorie).
//! De asemenea, această stare nu este garantată să rămână aceeași în versiunile Rust, deci ar trebui să evitați să vă bazați pe valorile exacte returnate de un iterator care a intrat în panică.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratorii (și iteratorul [adapters](#adapters)) sunt *leneși*. Acest lucru înseamnă că doar crearea unui iterator nu _do_ prea mult. Nimic nu se întâmplă cu adevărat până nu apelați [`next`].
//! Aceasta este uneori o sursă de confuzie atunci când creați un iterator numai pentru efectele sale secundare.
//! De exemplu, metoda [`map`] apelează o închidere pentru fiecare element pe care îl repetă:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Aceasta nu va imprima nicio valoare, deoarece am creat doar un iterator, mai degrabă decât să-l folosim.Compilatorul ne va avertiza despre acest tip de comportament:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Modul idiomatic de a scrie un [`map`] pentru efectele sale secundare este de a utiliza o buclă `for` sau de a apela metoda [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Un alt mod obișnuit de a evalua un iterator este de a utiliza metoda [`collect`] pentru a produce o nouă colecție.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratorii nu trebuie să fie finiți.De exemplu, un interval deschis este un iterator infinit:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Este obișnuit să utilizați adaptorul de iterator [`take`] pentru a transforma un iterator infinit într-unul finit:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Aceasta va imprima numerele de la `0` la `4`, fiecare pe propria linie.
//!
//! Rețineți că metodele pe iteratori infiniti, chiar și cele pentru care un rezultat poate fi determinat matematic în timp finit, pot să nu se termine.
//! Mai exact, metode precum [`min`], care, în general, necesită parcurgerea fiecărui element din iterator, nu vor reveni cu succes pentru niciun iterator infinit.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh nu!O buclă infinită!
//! // `ones.min()` provoacă o buclă infinită, deci nu vom ajunge la acest punct!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;