//! `Clone` trait pentru tipurile care nu pot fi " copiate implicit`.
//!
//! În Rust, unele tipuri simple sunt "implicitly copyable" și atunci când le atribuiți sau le transmiteți ca argumente, receptorul va primi o copie, lăsând valoarea originală la locul său.
//! Aceste tipuri nu necesită alocare pentru copiere și nu au finalizatoare (adică nu conțin cutii deținute sau implementează [`Drop`]), astfel încât compilatorul le consideră ieftine și sigure de copiat.
//!
//! Pentru alte tipuri, copiile trebuie făcute în mod explicit, prin convenție, implementând [`Clone`] trait și apelând metoda [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Exemplu de utilizare de bază:
//!
//! ```
//! let s = String::new(); // Tipul de șir implementează Clona
//! let copy = s.clone(); // astfel încât să o putem clona
//! ```
//!
//! Pentru a implementa cu ușurință Clona trait, puteți utiliza și `#[derive(Clone)]`.Exemplu:
//!
//! ```
//! #[derive(Clone)] // adăugăm Clona trait la structura Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // și acum o putem clona!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait comun pentru capacitatea de a duplica în mod explicit un obiect.
///
/// Diferă de [`Copy`] prin faptul că [`Copy`] este implicit și extrem de ieftin, în timp ce `Clone` este întotdeauna explicit și poate fi sau nu costisitor.
/// Pentru a aplica aceste caracteristici, Rust nu vă permite să reimplementați [`Copy`], dar puteți reimplementa `Clone` și să rulați cod arbitrar.
///
/// Deoarece `Clone` este mai general decât [`Copy`], puteți face automat ca orice [`Copy`] să fie și `Clone`.
///
/// ## Derivable
///
/// Acest trait poate fi utilizat cu `#[derive]` dacă toate câmpurile sunt `Clone`.Implementarea `derive`d a [`Clone`] apelează [`clone`] pe fiecare câmp.
///
/// [`clone`]: Clone::clone
///
/// Pentru o structură generică, `#[derive]` implementează condițional `Clone` adăugând `Clone` legat la parametrii generici.
///
/// ```
/// // `derive` implementează Clona pentru citire<T>când T este Clonă.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Cum pot implementa `Clone`?
///
/// Tipurile care sunt [`Copy`] ar trebui să aibă o implementare banală a `Clone`.Mai formal:
/// dacă `T: Copy`, `x: T` și `y: &T`, atunci `let x = y.clone();` este echivalent cu `let x = *y;`.
/// Implementările manuale ar trebui să fie atente pentru a susține acest invariant;totuși, codul nesigur nu trebuie să se bazeze pe acesta pentru a asigura siguranța memoriei.
///
/// Un exemplu este o structură generică care deține un indicator de funcție.În acest caz, implementarea `Clone` nu poate fi " derivată` d, dar poate fi implementată ca:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementatori suplimentari
///
/// În plus față de [implementors listed below][impls], următoarele tipuri implementează și `Clone`:
///
/// * Tipuri de elemente de funcție (de exemplu, tipurile distincte definite pentru fiecare funcție)
/// * Tipuri de pointer funcțional (de ex., `fn() -> i32`)
/// * Tipuri de matrice, pentru toate dimensiunile, dacă tipul articolului implementează și `Clone` (de exemplu, `[i32; 123456]`)
/// * Tipuri de tupluri, dacă fiecare componentă implementează și `Clone` (de exemplu, `()`, `(i32, bool)`)
/// * Tipuri de închidere, dacă nu captează nicio valoare din mediul înconjurător sau dacă toate aceste valori capturate implementează singuri `Clone`.
///   Rețineți că variabilele capturate prin referință partajată implementează întotdeauna `Clone` (chiar dacă referentul nu), în timp ce variabilele capturate prin referință mutabilă nu implementează niciodată `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Returnează o copie a valorii.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementează Clona
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Efectuează alocarea copiilor din `source`.
    ///
    /// `a.clone_from(&b)` este echivalent cu funcționalitatea `a = b.clone()`, dar poate fi suprascris pentru a reutiliza resursele `a` pentru a evita alocările inutile.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Derivați macro care generează un impl al trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): aceste structuri sunt utilizate exclusiv de#[derive] pentru a afirma că fiecare componentă a unui tip implementează Clonare sau Copiere.
//
//
// Aceste structuri nu ar trebui să apară niciodată în codul de utilizator.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementări ale `Clone` pentru tipurile primitive.
///
/// Implementările care nu pot fi descrise în Rust sunt implementate în `traits::SelectionContext::copy_clone_conditions()` în `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referințele partajate pot fi clonate, dar referințele mutabile *nu pot*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referințele partajate pot fi clonate, dar referințele mutabile *nu pot*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}