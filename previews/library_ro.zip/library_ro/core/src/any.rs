//! Acest modul implementează `Any` trait, care permite tastarea dinamică a oricărui tip `'static` prin reflecție în timp de execuție.
//!
//! `Any` în sine poate fi folosit pentru a obține un `TypeId` și are mai multe caracteristici atunci când este utilizat ca obiect trait.
//! Ca `&dyn Any` (un obiect trait împrumutat), are metodele `is` și `downcast_ref`, pentru a testa dacă valoarea conținută este de un anumit tip și pentru a obține o referință la valoarea interioară ca tip.
//! Ca `&mut dyn Any`, există și metoda `downcast_mut`, pentru a obține o referință mutabilă la valoarea interioară.
//! `Box<dyn Any>` adaugă metoda `downcast`, care încearcă să se convertească la un `Box<T>`.
//! Consultați documentația [`Box`] pentru detalii complete.
//!
//! Rețineți că `&dyn Any` se limitează la testarea dacă o valoare este de un tip de beton specificat și nu poate fi utilizat pentru a testa dacă un tip implementează un trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Indicatoare inteligente și `dyn Any`
//!
//! Un comportament pe care trebuie să-l țineți cont atunci când utilizați `Any` ca obiect trait, în special cu tipuri precum `Box<dyn Any>` sau `Arc<dyn Any>`, este că simpla apelare a `.type_id()` la valoare va produce `TypeId` al *containerului*, nu obiectul trait subiacent.
//!
//! Acest lucru poate fi evitat prin convertirea indicatorului inteligent într-un `&dyn Any`, care va returna `TypeId` al obiectului.
//! De exemplu:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Este mai probabil să doriți acest lucru:
//! let actual_id = (&*boxed).type_id();
//! // ... decât asta:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Luați în considerare o situație în care dorim să deconectăm o valoare transmisă unei funcții.
//! Știm valoarea la care lucrăm, implementează Debug, dar nu știm tipul său concret.Vrem să acordăm un tratament special anumitor tipuri: în acest caz tipărind lungimea valorilor șirului înainte de valoarea lor.
//! Nu cunoaștem tipul concret al valorii noastre la momentul compilării, așa că trebuie să folosim în schimb reflecția runtime.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funcția Logger pentru orice tip care implementează Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Încercați să ne convertiți valoarea într-un `String`.
//!     // Dacă reușim, dorim să scoatem lungimea șirului, precum și valoarea acestuia.
//!     // Dacă nu, este un alt tip: pur și simplu imprimați-l fără ornamente.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Această funcție dorește să-și deconecteze parametrii înainte de a lucra cu ea.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... mai fac ceva
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Orice trait
///////////////////////////////////////////////////////////////////////////////

/// Un trait pentru a emula tastarea dinamică.
///
/// Majoritatea tipurilor implementează `Any`.Cu toate acestea, orice tip care conține o referință non-statică nu.
/// Consultați [module-level documentation][mod] pentru mai multe detalii.
///
/// [mod]: crate::any
// Acest trait nu este nesigur, deși ne bazăm pe specificul funcției sale `type_id` a unicului impl în cod nesigur (de exemplu, `downcast`).În mod normal, aceasta ar fi o problemă, dar pentru că singura implementare a `Any` este o implementare generală, niciun alt cod nu poate implementa `Any`.
//
// Am putea face acest trait în mod plauzibil nesigur-nu ar provoca ruperea, deoarece controlăm toate implementările-dar alegem să nu facem acest lucru, deoarece atât nu este cu adevărat necesar, cât și poate confunda utilizatorii cu privire la distincția dintre traits și metodele nesigure (adică, `type_id` ar fi încă în siguranță pentru a apela, dar probabil că am dori să indicăm ca atare în documentație).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Obține `TypeId` din `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metode de extensie pentru orice obiecte trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Asigurați-vă că rezultatul de exemplu, alăturării unui fir poate fi imprimat și, prin urmare, utilizat cu `unwrap`.
// În cele din urmă, nu mai este necesar dacă expedierea funcționează cu ascensiune.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Returnează `true` dacă tipul în cutie este același cu `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Obțineți `TypeId` de tipul cu care funcționează această funcție.
        let t = TypeId::of::<T>();

        // Obțineți `TypeId` de tipul obiectului trait (`self`).
        let concrete = self.type_id();

        // Comparați ambele `TypeId` despre egalitate.
        t == concrete
    }

    /// Returnează o referință la valoarea în cutie dacă este de tipul `T` sau `None` dacă nu este.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SIGURANȚĂ: tocmai am verificat dacă indicăm tipul corect și ne putem baza
            // că verificăm siguranța memoriei, deoarece am implementat Orice pentru toate tipurile;niciun alt instrument nu poate exista, deoarece ar intra în conflict cu instrumentul nostru.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Returnează o referință mutabilă la valoarea în cutie dacă este de tipul `T` sau `None` dacă nu este.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SIGURANȚĂ: tocmai am verificat dacă indicăm tipul corect și ne putem baza
            // că verificăm siguranța memoriei, deoarece am implementat Orice pentru toate tipurile;niciun alt instrument nu poate exista, deoarece ar intra în conflict cu instrumentul nostru.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Înainte către metoda definită pe tipul `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Înainte către metoda definită pe tipul `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Înainte către metoda definită pe tipul `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Înainte către metoda definită pe tipul `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Înainte către metoda definită pe tipul `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Înainte către metoda definită pe tipul `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID și metodele sale
///////////////////////////////////////////////////////////////////////////////

/// Un `TypeId` reprezintă un identificator unic la nivel global pentru un tip.
///
/// Fiecare `TypeId` este un obiect opac care nu permite inspectarea a ceea ce este în interior, dar permite operații de bază, cum ar fi clonarea, compararea, imprimarea și afișarea.
///
///
/// Un `TypeId` este disponibil în prezent numai pentru tipurile care atribuie `'static`, dar această limitare poate fi eliminată în future.
///
/// În timp ce `TypeId` implementează `Hash`, `PartialOrd` și `Ord`, este demn de remarcat faptul că hashurile și ordinea vor varia între versiunile Rust.
/// Ferește-te să te bazezi pe ele în interiorul codului tău!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Returnează `TypeId` de tipul cu care a fost creată această funcție generică.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Returnează numele unui tip ca o felie de șir.
///
/// # Note
///
/// Aceasta este destinată utilizării diagnostice.
/// Conținutul exact și formatul șirului returnat nu sunt specificate, în afară de a fi o descriere de cel mai bun efort al tipului.
/// De exemplu, printre șirurile pe care `type_name::<Option<String>>()` le-ar putea returna sunt `"Option<String>"` și `"std::option::Option<std::string::String>"`.
///
///
/// Șirul returnat nu trebuie considerat a fi un identificator unic al unui tip, deoarece mai multe tipuri pot fi mapate la același nume de tip.
/// În mod similar, nu există nicio garanție că toate părțile unui tip vor apărea în șirul returnat: de exemplu, specificatorii pe durata de viață nu sunt incluși în prezent.
/// În plus, ieșirea se poate modifica între versiunile compilatorului.
///
/// Implementarea actuală utilizează aceeași infrastructură ca diagnosticarea compilatorului și debuginfo, dar acest lucru nu este garantat.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Returnează numele tipului valorii îndreptate spre o felie de șir.
/// Acesta este la fel ca `type_name::<T>()`, dar poate fi utilizat în cazul în care tipul unei variabile nu este ușor disponibil.
///
/// # Note
///
/// Aceasta este destinată utilizării diagnostice.Conținutul exact și formatul șirului nu sunt specificate, în afară de a fi o descriere de tipul cel mai bun efort.
/// De exemplu, `type_name_of_val::<Option<String>>(None)` ar putea returna `"Option<String>"` sau `"std::option::Option<std::string::String>"`, dar nu `"foobar"`.
///
/// În plus, ieșirea se poate modifica între versiunile compilatorului.
///
/// Această funcție nu rezolvă obiectele trait, ceea ce înseamnă că `type_name_of_val(&7u32 as &dyn Debug)` poate returna `"dyn Debug"`, dar nu `"u32"`.
///
/// Numele tipului nu trebuie considerat un identificator unic al unui tip;
/// mai multe tipuri pot avea același nume de tip.
///
/// Implementarea actuală utilizează aceeași infrastructură ca diagnosticarea compilatorului și debuginfo, dar acest lucru nu este garantat.
///
/// # Examples
///
/// Tipărește numerele implicite și tipurile flotante.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}