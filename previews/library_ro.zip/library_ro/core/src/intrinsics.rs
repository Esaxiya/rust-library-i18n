//! Intrinsecele compilatorului.
//!
//! Definițiile corespunzătoare sunt în `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Implementările corespunzătoare const sunt în `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinseci
//!
//! Note: orice schimbări aduse constanței intrinseci ar trebui discutate cu echipa lingvistică.
//! Aceasta include schimbări în stabilitatea constanței.
//!
//! Pentru a face un intrinsec utilizabil la compilare, trebuie să copiați implementarea de la <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> la `compiler/rustc_mir/src/interpret/intrinsics.rs` și să adăugați un `#[rustc_const_unstable(feature = "foo", issue = "01234")]` la intrinsec.
//!
//!
//! Dacă se presupune că un intrinsec trebuie utilizat dintr-un `const fn` cu un atribut `rustc_const_stable`, atributul intrinsecului trebuie să fie și `rustc_const_stable`.
//! O astfel de modificare nu ar trebui făcută fără consultarea T-lang, deoarece coace o caracteristică în limba care nu poate fi reprodusă în codul de utilizator fără suportul compilatorului.
//!
//! # Volatiles
//!
//! Intrinsecele volatile oferă operațiuni destinate să acționeze asupra memoriei I/O, care sunt garantate să nu fie reordonate de către compilator în alte intrinseci volatile.Consultați documentația LLVM de pe [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Intrinsecele atomice asigură operații atomice obișnuite pe cuvinte mașină, cu mai multe posibile ordonări de memorie.Aceștia respectă aceeași semantică ca C++ 11.Consultați documentația LLVM de pe [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! O reîmprospătare rapidă a comenzii de memorie:
//!
//! * Achiziționează, o barieră pentru achiziționarea unei încuietori.Citirile și scrierile ulterioare au loc după barieră.
//! * Eliberare, o barieră pentru eliberarea unei încuietori.Citirile și scrierile anterioare au loc înainte de barieră.
//! * Operațiunile consecvențe secvențiale, consecvențe secvențiale sunt garantate să se întâmple în ordine.Acesta este modul standard pentru lucrul cu tipuri atomice și este echivalent cu `volatile` al lui Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Aceste importuri sunt utilizate pentru simplificarea legăturilor intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SIGURANȚĂ: vezi `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, aceste elemente intrinseci acceptă indicii brute deoarece mută memoria aliasată, care nu este valabilă nici pentru `&`, nici pentru `&mut`.
    //

    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::SeqCst`] ca parametri `success` și `failure`.
    ///
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::Acquire`] ca parametri `success` și `failure`.
    ///
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::Release`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::AcqRel`] ca `success` și [`Ordering::Acquire`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::Relaxed`] ca parametri `success` și `failure`.
    ///
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::SeqCst`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::SeqCst`] ca `success` și [`Ordering::Acquire`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::Acquire`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange`, trecând [`Ordering::AcqRel`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::SeqCst`] ca parametri `success` și `failure`.
    ///
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::Acquire`] ca parametri `success` și `failure`.
    ///
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::Release`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::AcqRel`] ca `success` și [`Ordering::Acquire`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::Relaxed`] ca parametri `success` și `failure`.
    ///
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::SeqCst`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::SeqCst`] ca `success` și [`Ordering::Acquire`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::Acquire`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stochează o valoare dacă valoarea curentă este aceeași cu valoarea `old`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `compare_exchange_weak`, trecând [`Ordering::AcqRel`] ca `success` și [`Ordering::Relaxed`] ca parametri `failure`.
    /// De exemplu, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Încarcă valoarea curentă a indicatorului.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `load` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Încarcă valoarea curentă a indicatorului.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `load` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Încarcă valoarea curentă a indicatorului.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `load` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Stochează valoarea la locația de memorie specificată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `store` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Stochează valoarea la locația de memorie specificată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `store` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Stochează valoarea la locația de memorie specificată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `store` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Stochează valoarea la locația de memorie specificată, returnând vechea valoare.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `swap` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stochează valoarea la locația de memorie specificată, returnând vechea valoare.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `swap` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stochează valoarea la locația de memorie specificată, returnând vechea valoare.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `swap` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stochează valoarea la locația de memorie specificată, returnând vechea valoare.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `swap` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stochează valoarea la locația de memorie specificată, returnând vechea valoare.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `swap` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Se adaugă la valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_add` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se adaugă la valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_add` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se adaugă la valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_add` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se adaugă la valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_add` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Se adaugă la valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_add` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Scade din valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_sub` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Scade din valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_sub` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Scade din valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_sub` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Scade din valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_sub` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Scade din valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_sub` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// În sensul bitului și cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_and` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// În sensul bitului și cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_and` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// În sensul bitului și cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_and` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// În sensul bitului și cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_and` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// În sensul bitului și cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_and` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitand nand cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipul [`AtomicBool`] prin metoda `fetch_nand`, trecând [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipul [`AtomicBool`] prin metoda `fetch_nand`, trecând [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipul [`AtomicBool`] prin metoda `fetch_nand`, trecând [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipul [`AtomicBool`] prin metoda `fetch_nand`, trecând [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipul [`AtomicBool`] prin metoda `fetch_nand`, trecând [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit sau cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_or` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit sau cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_or` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit sau cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_or` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit sau cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_or` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit sau cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_or` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_xor` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_xor` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_xor` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_xor` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor cu valoarea curentă, returnând valoarea anterioară.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile [`atomic`] prin metoda `fetch_xor` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maxim cu valoarea curentă utilizând o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_max` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă utilizând o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_max` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă utilizând o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_max` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă utilizând o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_max` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_max` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minim cu valoarea curentă folosind o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_min` prin trecerea [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_min` prin trecerea [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_min` prin trecerea [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_min` prin trecerea [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație semnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi semnate [`atomic`] prin metoda `fetch_min` prin trecerea [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minim cu valoarea curentă folosind o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_min`, trecând [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_min`, trecând [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_min`, trecând [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_min`, trecând [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minim cu valoarea curentă folosind o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_min`, trecând [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maxim cu valoarea curentă utilizând o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_max`, trecând [`Ordering::SeqCst`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă utilizând o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_max`, trecând [`Ordering::Acquire`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă utilizând o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_max`, trecând [`Ordering::Release`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă utilizând o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_max`, trecând [`Ordering::AcqRel`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maxim cu valoarea curentă utilizând o comparație nesemnată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă pentru tipurile întregi [`atomic`] nesemnate prin metoda `fetch_max`, trecând [`Ordering::Relaxed`] ca `order`.
    /// De exemplu, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Intrinsecul `prefetch` este un indiciu pentru generatorul de cod pentru a insera o instrucțiune de preluare, dacă este acceptată;în caz contrar, este un no-op.
    /// Prefetchurile nu au niciun efect asupra comportamentului programului, dar pot schimba caracteristicile sale de performanță.
    ///
    /// Argumentul `locality` trebuie să fie un număr întreg constant și este un specificator de localitate temporală variind de la (0), fără localitate, până la (3), păstrare extrem de locală în cache.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Intrinsecul `prefetch` este un indiciu pentru generatorul de cod pentru a insera o instrucțiune de preluare, dacă este acceptată;în caz contrar, este un no-op.
    /// Prefetchurile nu au niciun efect asupra comportamentului programului, dar pot schimba caracteristicile sale de performanță.
    ///
    /// Argumentul `locality` trebuie să fie un număr întreg constant și este un specificator de localitate temporală variind de la (0), fără localitate, până la (3), păstrare extrem de locală în cache.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Intrinsecul `prefetch` este un indiciu pentru generatorul de cod pentru a insera o instrucțiune de preluare, dacă este acceptată;în caz contrar, este un no-op.
    /// Prefetchurile nu au niciun efect asupra comportamentului programului, dar pot schimba caracteristicile sale de performanță.
    ///
    /// Argumentul `locality` trebuie să fie un număr întreg constant și este un specificator de localitate temporală variind de la (0), fără localitate, până la (3), păstrare extrem de locală în cache.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Intrinsecul `prefetch` este un indiciu pentru generatorul de cod pentru a insera o instrucțiune de preluare, dacă este acceptată;în caz contrar, este un no-op.
    /// Prefetchurile nu au niciun efect asupra comportamentului programului, dar pot schimba caracteristicile sale de performanță.
    ///
    /// Argumentul `locality` trebuie să fie un număr întreg constant și este un specificator de localitate temporală variind de la (0), fără localitate, până la (3), păstrare extrem de locală în cache.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Un gard atomic.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::fence`] prin trecerea [`Ordering::SeqCst`] ca `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Un gard atomic.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::fence`] prin trecerea [`Ordering::Acquire`] ca `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Un gard atomic.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::fence`] prin trecerea [`Ordering::Release`] ca `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Un gard atomic.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::fence`] prin trecerea [`Ordering::AcqRel`] ca `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// O barieră de memorie numai pentru compilator.
    ///
    /// Accesele de memorie nu vor fi niciodată reordonate peste această barieră de către compilator, dar nu vor fi emise instrucțiuni pentru aceasta.
    /// Acest lucru este adecvat pentru operațiuni pe același fir care pot fi împiedicate, cum ar fi atunci când interacționați cu gestionarele de semnal.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::compiler_fence`] prin trecerea [`Ordering::SeqCst`] ca `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// O barieră de memorie numai pentru compilator.
    ///
    /// Accesele de memorie nu vor fi niciodată reordonate peste această barieră de către compilator, dar nu vor fi emise instrucțiuni pentru aceasta.
    /// Acest lucru este adecvat pentru operațiuni pe același fir care pot fi împiedicate, cum ar fi atunci când interacționați cu gestionarele de semnal.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::compiler_fence`] prin trecerea [`Ordering::Acquire`] ca `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// O barieră de memorie numai pentru compilator.
    ///
    /// Accesele de memorie nu vor fi niciodată reordonate peste această barieră de către compilator, dar nu vor fi emise instrucțiuni pentru aceasta.
    /// Acest lucru este adecvat pentru operațiuni pe același fir care pot fi împiedicate, cum ar fi atunci când interacționați cu gestionarele de semnal.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::compiler_fence`] prin trecerea [`Ordering::Release`] ca `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// O barieră de memorie numai pentru compilator.
    ///
    /// Accesele de memorie nu vor fi niciodată reordonate peste această barieră de către compilator, dar nu vor fi emise instrucțiuni pentru aceasta.
    /// Acest lucru este adecvat pentru operațiuni pe același fir care pot fi împiedicate, cum ar fi atunci când interacționați cu gestionarele de semnal.
    ///
    /// Versiunea stabilizată a acestui intrinsec este disponibilă în [`atomic::compiler_fence`] prin trecerea [`Ordering::AcqRel`] ca `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic intrinsec care își derivă sensul din atributele atașate funcției.
    ///
    /// De exemplu, fluxul de date folosește acest lucru pentru a injecta afirmații statice, astfel încât `rustc_peek(potentially_uninitialized)` să verifice de fapt dacă fluxul de date a calculat într-adevăr că nu este inițializat în acel moment al fluxului de control.
    ///
    ///
    /// Acest intrinsec nu trebuie utilizat în afara compilatorului.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Întrerupe executarea procesului.
    ///
    /// O versiune mai ușor de utilizat și mai stabilă a acestei operațiuni este [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informează optimizatorul că acest punct din cod nu este accesibil, permițând optimizări suplimentare.
    ///
    /// NB, acest lucru este foarte diferit de macrocomanda `unreachable!()`: spre deosebire de macrocomanda, pe care panics când este executată, este *comportament nedefinit* să se ajungă la codul marcat cu această funcție.
    ///
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informează optimizatorul că o condiție este întotdeauna adevărată.
    /// Dacă condiția este falsă, comportamentul este nedefinit.
    ///
    /// Nu este generat niciun cod pentru acest intrinsec, dar optimizatorul va încerca să îl păstreze (și starea acestuia) între treceri, ceea ce poate interfera cu optimizarea codului înconjurător și poate reduce performanța.
    /// Nu ar trebui să fie utilizat dacă invariantul poate fi descoperit de optimizator singur sau dacă nu permite optimizări semnificative.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Sugestii pentru compilator că starea branch este probabil să fie adevărată.
    /// Returnează valoarea transmisă acestuia.
    ///
    /// Orice utilizare, alta decât cu instrucțiunile `if`, probabil că nu va avea efect.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Sugestii pentru compilator că starea branch este probabil să fie falsă.
    /// Returnează valoarea transmisă acestuia.
    ///
    /// Orice utilizare, alta decât cu instrucțiunile `if`, probabil că nu va avea efect.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Execută o capcană de punct de întrerupere, pentru inspecție de către un depanator.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn breakpoint();

    /// Dimensiunea unui tip în octeți.
    ///
    /// Mai precis, acesta este compensarea în octeți între elementele succesive de același tip, inclusiv umplerea alinierii.
    ///
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Alinierea minimă a unui tip.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Alinierea preferată a unui tip.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Mărimea valorii de referință în octeți.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Alinierea necesară a valorii de referință.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Obține o felie de șir static care conține numele unui tip.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Obține un identificator care este unic la nivel global pentru tipul specificat.
    /// Această funcție va returna aceeași valoare pentru un tip, indiferent de crate în care este invocat.
    ///
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// O protecție pentru funcțiile nesigure care nu pot fi executate niciodată dacă `T` este nelocuit:
    /// Acest lucru va fi static fie panic, fie nu va face nimic.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// O protecție pentru funcțiile nesigure care nu pot fi executate niciodată dacă `T` nu permite inițializarea zero: Aceasta va fi fie panic, fie nu va face nimic.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn assert_zero_valid<T>();

    /// O protecție pentru funcțiile nesigure care nu pot fi executate niciodată dacă `T` are modele de biți nevalizi: Acest lucru va fi static fie panic, fie nu va face nimic.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn assert_uninit_valid<T>();

    /// Obține o referință la un `Location` static care indică unde a fost apelat.
    ///
    /// Luați în considerare utilizarea [`core::panic::Location::caller`](crate::panic::Location::caller) în schimb.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Mută o valoare în afara domeniului de aplicare fără a rula lipici.
    ///
    /// Acest lucru există exclusiv pentru [`mem::forget_unsized`];`forget` normal folosește în schimb `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpretează biții unei valori de un tip ca alt tip.
    ///
    /// Ambele tipuri trebuie să aibă aceeași dimensiune.
    /// Nici originalul, nici rezultatul nu pot fi un [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` este echivalent semantic cu o mișcare de tip bit în altul.Copiază biții din valoarea sursă în valoarea destinației, apoi uită originalul.
    /// Este echivalent cu C's `memcpy` sub capotă, la fel ca `transmute_copy`.
    ///
    /// Deoarece `transmute` este o operație secundară, alinierea valorilor *transmutate în sine* nu este o problemă.
    /// Ca și în cazul oricărei alte funcții, compilatorul se asigură deja că ambele `T` și `U` sunt aliniate corect.
    /// Cu toate acestea, atunci când transmutează valori care *indică în altă parte*(cum ar fi indicii, referințe, casete ...), apelantul trebuie să asigure alinierea corectă a valorilor îndreptate către.
    ///
    /// `transmute` este **incredibil** nesigur.Există o mulțime de moduri de a provoca [undefined behavior][ub] cu această funcție.`transmute` ar trebui să fie ultima soluție absolută.
    ///
    /// [nomicon](../../nomicon/transmutes.html) are documentație suplimentară.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Există câteva lucruri pentru care `transmute` este foarte util.
    ///
    /// Transformarea unui pointer într-un pointer funcțional.Acest lucru nu este * portabil pentru mașinile în care indicatoarele funcționale și indicatoarele de date au dimensiuni diferite.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Prelungirea unei vieți sau scurtarea unei vieți invariante.Acest lucru este avansat, foarte nesigur Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Nu disperați: multe utilizări ale `transmute` pot fi realizate prin alte mijloace.
    /// Mai jos sunt aplicații obișnuite ale `transmute` care pot fi înlocuite cu construcții mai sigure.
    ///
    /// Transformarea bytes(`&[u8]`) brut în `u32`, `f64`, etc.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // folosiți în schimb `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // sau utilizați `u32::from_le_bytes` sau `u32::from_be_bytes` pentru a specifica endianitatea
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Transformarea unui pointer într-un `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Folosiți în schimb o distribuție `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Transformarea unui `*mut T` într-un `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Folosiți în schimb un reborrow
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Transformarea unui `&mut T` într-un `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Acum, puneți împreună `as` și reborrowing, rețineți că înlănțuirea `as` `as` nu este tranzitivă
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Transformarea unui `&str` într-un `&[u8]`:
    ///
    /// ```
    /// // aceasta nu este o modalitate bună de a face acest lucru.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ați putea folosi `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Sau, utilizați doar un șir de octeți, dacă aveți controlul asupra șirului literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Transformarea unui `Vec<&T>` într-un `Vec<Option<&T>>`.
    ///
    /// Pentru a transmuta tipul interior al conținutului unui container, trebuie să vă asigurați că nu încălcați niciunul dintre invarianții containerului.
    /// Pentru `Vec`, aceasta înseamnă că atât dimensiunea *, cât și alinierea* tipurilor interioare trebuie să se potrivească.
    /// Alte containere s-ar putea baza pe dimensiunea tipului, aliniamentului sau chiar pe `TypeId`, caz în care transmutarea nu ar fi deloc posibilă fără a încălca invarianții containerului.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clonați vector deoarece le vom refolosi mai târziu
    /// let v_clone = v_orig.clone();
    ///
    /// // Utilizarea transmutării: aceasta se bazează pe aspectul de date nespecificat al `Vec`, care este o idee proastă și ar putea provoca un comportament nedefinit.
    /////
    /// // Cu toate acestea, este fără copie.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Acesta este modul sugerat, sigur.
    /// // Copiază tot vector într-o nouă matrice.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Acesta este modul corect de copiere, nesigur, al "transmuting" a `Vec`, fără a se baza pe aspectul datelor.
    /// // În loc să apelăm literalmente `transmute`, efectuăm un turn de pointer, dar în ceea ce privește conversia tipului interior original (`&i32`) în cel nou (`Option<&i32>`), acesta are toate aceleași avertismente.
    /////
    /// // Pe lângă informațiile furnizate mai sus, consultați și documentația [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Actualizați acest lucru când vec_into_raw_parts este stabilizat.
    ///     // Asigurați-vă că vector original nu este scăpat.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementarea `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Există mai multe modalități de a face acest lucru și există mai multe probleme cu următorul mod (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // mai întâi: transmutarea nu este sigură pentru tip;tot ce verifică este că T și
    ///         // U sunt de aceeași dimensiune.
    ///         // În al doilea rând, chiar aici, aveți două referințe mutabile care indică aceeași memorie.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Acest lucru scapă de problemele de siguranță de tip;`&mut *` vă va oferi* numai *un `&mut T` de la un `&mut T` sau `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // totuși, aveți încă două referințe mutabile care indică aceeași memorie.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Așa o face biblioteca standard.
    /// // Aceasta este cea mai bună metodă, dacă trebuie să faceți așa ceva
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Aceasta are acum trei referințe mutabile îndreptate către aceeași memorie.`slice`, valoarea ret.0 și valoarea ret.1.
    ///         // `slice` nu este folosit niciodată după `let ptr = ...` și, prin urmare, îl puteți trata ca "dead" și, prin urmare, aveți doar două felii reale mutabile.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: În timp ce acest lucru face ca const intrinseca să fie stabilă, avem un cod personalizat în const fn
    // verificări care împiedică utilizarea acestuia în `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Returnează `true` dacă tipul real dat ca `T` necesită lipici;returnează `false` dacă tipul real prevăzut pentru `T` implementează `Copy`.
    ///
    ///
    /// Dacă tipul real nu necesită lipici și nici nu implementează `Copy`, atunci valoarea returnată a acestei funcții nu este specificată.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calculează decalajul de la un pointer.
    ///
    /// Acest lucru este implementat ca un element intrinsec pentru a evita conversia la și de la un întreg, deoarece conversia ar arunca informații de aliasing.
    ///
    /// # Safety
    ///
    /// Atât indicatorul inițial, cât și cel rezultat trebuie să fie fie în limite, fie cu un octet peste sfârșitul unui obiect alocat.
    /// Dacă fie indicatorul este în afara limitelor, fie apare o revărsare aritmetică, orice altă utilizare a valorii returnate va avea ca rezultat un comportament nedefinit.
    ///
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calculează decalajul de la un indicator, potențial de împachetare.
    ///
    /// Acest lucru este implementat ca un element intrinsec pentru a evita conversia către și dintr-un număr întreg, deoarece conversia inhibă anumite optimizări.
    ///
    /// # Safety
    ///
    /// Spre deosebire de intrinsecul `offset`, acest intrinsec nu restricționează indicatorul rezultat să indice sau să treacă un octet peste sfârșitul unui obiect alocat și se înfășoară cu aritmetica complementului doi.
    /// Valoarea rezultată nu este neapărat valabilă pentru a fi utilizată pentru a accesa efectiv memoria.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Echivalent cu intrinsecul `llvm.memcpy.p0i8.0i8.*` corespunzător, cu o dimensiune de `count`*`size_of::<T>()` și o aliniere de
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametrul volatil este setat la `true`, deci nu va fi optimizat decât dacă dimensiunea este egală cu zero.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Echivalent cu intrinsecul `llvm.memmove.p0i8.0i8.*` corespunzător, cu o dimensiune de `count* size_of::<T>()` și o aliniere de
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametrul volatil este setat la `true`, deci nu va fi optimizat decât dacă dimensiunea este egală cu zero.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Echivalent cu intrinsecul `llvm.memset.p0i8.*` adecvat, cu o dimensiune de `count* size_of::<T>()` și o aliniere de `min_align_of::<T>()`.
    ///
    ///
    /// Parametrul volatil este setat la `true`, deci nu va fi optimizat decât dacă dimensiunea este egală cu zero.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Efectuează o încărcare volatilă de la indicatorul `src`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Realizează un depozit volatil la indicatorul `dst`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Efectuează o încărcare volatilă de la indicatorul `src` Nu este necesar ca indicatorul să fie aliniat.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Realizează un depozit volatil la indicatorul `dst`.
    /// Nu este necesar ca indicatorul să fie aliniat.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Returnează rădăcina pătrată a unui `f32`
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Returnează rădăcina pătrată a unui `f64`
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Crește un `f32` la o putere întreagă.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Crește un `f64` la o putere întreagă.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Returnează sinusul unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Returnează sinusul unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Returnează cosinusul unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Returnează cosinusul unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Crește un `f32` la o putere `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Crește un `f64` la o putere `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Returnează exponențialul unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Returnează exponențialul unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returnează 2 ridicat la puterea unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returnează 2 ridicat la puterea unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Returnează logaritmul natural al unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Returnează logaritmul natural al unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Returnează logaritmul de bază 10 al unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Returnează logaritmul de bază 10 al unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Returnează logaritmul de bază 2 al unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Returnează logaritmul de bază 2 al unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Returnează `a * b + c` pentru valorile `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Returnează `a * b + c` pentru valorile `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Returnează valoarea absolută a unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Returnează valoarea absolută a unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Returnează minimum două valori `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Returnează minimum două valori `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Returnează maximum două valori `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Returnează maximum două valori `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copiază semnul de la `y` la `x` pentru valorile `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copiază semnul de la `y` la `x` pentru valorile `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Returnează cel mai mare întreg mai mic sau egal cu un `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Returnează cel mai mare întreg mai mic sau egal cu un `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Returnează cel mai mic întreg mai mare sau egal cu un `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Returnează cel mai mic întreg mai mare sau egal cu un `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Returnează partea întreagă a unui `f32`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Returnează partea întreagă a unui `f64`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Returnează cel mai apropiat număr întreg la un `f32`.
    /// Poate ridica o excepție inexactă în virgulă mobilă dacă argumentul nu este un număr întreg.
    pub fn rintf32(x: f32) -> f32;
    /// Returnează cel mai apropiat număr întreg la un `f64`.
    /// Poate ridica o excepție inexactă în virgulă mobilă dacă argumentul nu este un număr întreg.
    pub fn rintf64(x: f64) -> f64;

    /// Returnează cel mai apropiat număr întreg la un `f32`.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Returnează cel mai apropiat număr întreg la un `f64`.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Returnează cel mai apropiat număr întreg la un `f32`.Rotunjește la jumătate cazurile de la zero.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Returnează cel mai apropiat număr întreg la un `f64`.Rotunjește la jumătate cazurile de la zero.
    ///
    /// Versiunea stabilizată a acestui intrinsec este
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Adăugare plutitoare care permite optimizări bazate pe reguli algebrice.
    /// Poate presupune că intrările sunt finite.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Scăderea plutitoare care permite optimizări bazate pe reguli algebrice.
    /// Poate presupune că intrările sunt finite.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multiplicarea prin flotare care permite optimizări bazate pe reguli algebrice.
    /// Poate presupune că intrările sunt finite.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Diviziune plutitoare care permite optimizări bazate pe reguli algebrice.
    /// Poate presupune că intrările sunt finite.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Restul plutitor care permite optimizări bazate pe reguli algebrice.
    /// Poate presupune că intrările sunt finite.
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Convertiți cu fptoui/fptosi de la LLVM, care poate reveni undef pentru valori în afara intervalului
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizat ca [`f32::to_int_unchecked`] și [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Returnează numărul de biți stabilit într-un tip întreg `T`
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `count_ones`.
    /// De exemplu,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Returnează numărul de biți (zeroes) inițiali principali într-un tip întreg `T`.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `leading_zeros`.
    /// De exemplu,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Un `x` cu valoarea `0` va returna lățimea de biți a `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// La fel ca `ctlz`, dar extra-nesigur, deoarece returnează `undef` când i se dă un `x` cu valoarea `0`.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Returnează numărul de biți definiți (zeroes) în urmă într-un tip întreg `T`.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `trailing_zeros`.
    /// De exemplu,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Un `x` cu valoarea `0` va returna lățimea de biți a `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// La fel ca `cttz`, dar extra-nesigur, deoarece returnează `undef` când i se dă un `x` cu valoarea `0`.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inversează octeții într-un număr întreg de tip `T`.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `swap_bytes`.
    /// De exemplu,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inversează biții într-un număr întreg `T`.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `reverse_bits`.
    /// De exemplu,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Efectuează adăugarea numărului întreg verificat.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `overflowing_add`.
    /// De exemplu,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Efectuează scăderea numărului verificat
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `overflowing_sub`.
    /// De exemplu,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Efectuează multiplicarea numerelor verificate
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `overflowing_mul`.
    /// De exemplu,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Efectuează o împărțire exactă, rezultând un comportament nedefinit în cazul în care `x % y != 0` sau `y == 0` sau `x == T::MIN && y == -1`
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Efectuează o divizare necontrolată, rezultând un comportament nedefinit în cazul în care `y == 0` sau `x == T::MIN && y == -1`
    ///
    ///
    /// Împachetările sigure pentru acest intrinsec sunt disponibile pe primitivele întregi prin metoda `checked_div`.
    /// De exemplu,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Returnează restul unei diviziuni necontrolate, rezultând un comportament nedefinit atunci când `y == 0` sau `x == T::MIN && y == -1`
    ///
    ///
    /// Împachetările sigure pentru acest intrinsec sunt disponibile pe primitivele întregi prin metoda `checked_rem`.
    /// De exemplu,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Efectuează o deplasare la stânga necontrolată, rezultând un comportament nedefinit atunci când `y < 0` sau `y >= N`, unde N este lățimea lui T în biți.
    ///
    ///
    /// Împachetările sigure pentru acest intrinsec sunt disponibile pe primitivele întregi prin metoda `checked_shl`.
    /// De exemplu,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Efectuează o deplasare la dreapta necontrolată, rezultând un comportament nedefinit atunci când `y < 0` sau `y >= N`, unde N este lățimea lui T în biți.
    ///
    ///
    /// Împachetările sigure pentru acest intrinsec sunt disponibile pe primitivele întregi prin metoda `checked_shr`.
    /// De exemplu,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Returnează rezultatul unei adăugări necontrolate, rezultând un comportament nedefinit atunci când `x + y > T::MAX` sau `x + y < T::MIN`.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Returnează rezultatul unei scăderi necontrolate, rezultând un comportament nedefinit atunci când `x - y > T::MAX` sau `x - y < T::MIN`.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Returnează rezultatul unei multiplicări necontrolate, rezultând un comportament nedefinit atunci când `x *y > T::MAX` sau `x* y < T::MIN`.
    ///
    ///
    /// Acest intrinsec nu are un omolog stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Efectuează rotirea la stânga.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `rotate_left`.
    /// De exemplu,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Efectuează rotirea la dreapta.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `rotate_right`.
    /// De exemplu,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returnează (a + b) mod 2 <sup>N</sup>, unde N este lățimea lui T în biți.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `wrapping_add`.
    /// De exemplu,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returnează (a, b) mod 2 <sup>N</sup>, unde N este lățimea lui T în biți.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `wrapping_sub`.
    /// De exemplu,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returnează (a * b) mod 2 <sup>N</sup>, unde N este lățimea lui T în biți.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `wrapping_mul`.
    /// De exemplu,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calculează `a + b`, saturând la limite numerice.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `saturating_add`.
    /// De exemplu,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calculează `a - b`, saturând la limite numerice.
    ///
    /// Versiunile stabilizate ale acestui intrinsec sunt disponibile pe primitivele întregi prin metoda `saturating_sub`.
    /// De exemplu,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Returnează valoarea discriminantului pentru varianta din 'v';
    /// dacă `T` nu are discriminant, returnează `0`.
    ///
    /// Versiunea stabilizată a acestui intrinsec este [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Returnează numărul de variante ale tipului `T` turnat la un `usize`;
    /// dacă `T` nu are variante, returnează `0`.Variantele nelocuite vor fi numărate.
    ///
    /// Versiunea care trebuie stabilizată a acestui intrinsec este [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Construcția "try catch" a lui Rust care invocă pointerul funcțional `try_fn` cu pointerul de date `data`.
    ///
    /// Al treilea argument este o funcție numită dacă apare un panic.
    /// Această funcție duce indicatorul de date și un indicator către obiectul de excepție specific țintă care a fost capturat.
    ///
    /// Pentru mai multe informații, consultați sursa compilatorului, precum și implementarea capturilor std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emite un magazin `!nontemporal` conform LLVM (consultați documentele lor).
    /// Probabil că nu va deveni niciodată stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Consultați documentația `<*const T>::offset_from` pentru detalii.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Consultați documentația `<*const T>::guaranteed_eq` pentru detalii.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Consultați documentația `<*const T>::guaranteed_ne` pentru detalii.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Alocați la compilare.Nu trebuie apelat în timpul rulării.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Unele funcții sunt definite aici, deoarece au devenit accidental disponibile în acest modul în stabil.
// Vezi <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` se încadrează și în această categorie, dar nu poate fi împachetat datorită verificării faptului că `T` și `U` au aceeași dimensiune.)
//

/// Verifică dacă `ptr` este aliniat corespunzător față de `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copiază octeți `count * size_of::<T>()` de la `src` la `dst`.Sursa și destinația nu trebuie să se suprapună.
///
/// Pentru regiunile de memorie care s-ar putea suprapune, utilizați în schimb [`copy`].
///
/// `copy_nonoverlapping` este echivalent semantic cu X's [`memcpy`] al lui C, dar cu ordinea argumentelor schimbată.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `src` trebuie să fie [valid] pentru citirile de octeți `count * size_of::<T>()`.
///
/// * `dst` trebuie să fie [valid] pentru scrieri de octeți `count * size_of::<T>()`.
///
/// * Atât `src`, cât și `dst` trebuie aliniate corect.
///
/// * Regiunea memoriei care începe de la `src` cu o dimensiune de `count *
///   size_of: :<T>() `octeții *nu* trebuie * să se suprapună cu regiunea memoriei începând de la `dst` cu aceeași dimensiune.
///
/// La fel ca [`read`], `copy_nonoverlapping` creează o copie pe biți a `T`, indiferent dacă `T` este [`Copy`].
/// Dacă `T` nu este [`Copy`], folosind *ambele* valorile din regiunea care începe de la `*src` și regiunea care începe de la `* dst` pot [violate memory safety][read-ownership].
///
///
/// Rețineți că, chiar dacă dimensiunea copiată efectiv (`count * size_of: :<T>()`) este `0`, indicatoarele trebuie să fie nule și aliniate corespunzător.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implementați manual [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Mută toate elementele `src` în `dst`, lăsând `src` gol.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Asigurați-vă că `dst` are suficientă capacitate pentru a păstra toate `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Apelul la compensare este întotdeauna sigur deoarece `Vec` nu va aloca niciodată mai mult de `isize::MAX` octeți.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Trunchiați `src` fără a renunța la conținutul său.
///         // Facem acest lucru mai întâi, pentru a evita problemele în cazul în care ceva mai jos panics.
///         src.set_len(0);
///
///         // Cele două regiuni nu se pot suprapune, deoarece referințele mutabile nu fac alias și două vectors diferite nu pot deține aceeași memorie.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notificați `dst` că acum conține conținutul `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Efectuați aceste verificări numai în timpul rulării
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Nu intră în panică pentru a menține impactul codegenului mai mic.
        abort();
    }*/

    // SIGURANȚĂ: contractul de siguranță pentru `copy_nonoverlapping` trebuie să fie
    // confirmat de apelant.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copiază octeți `count * size_of::<T>()` de la `src` la `dst`.Sursa și destinația se pot suprapune.
///
/// Dacă sursa și destinația nu se vor suprapune *niciodată*, [`copy_nonoverlapping`] poate fi utilizat în schimb.
///
/// `copy` este echivalent semantic cu X's [`memmove`] al lui C, dar cu ordinea argumentelor schimbată.
/// Copierea are loc ca și cum octeții ar fi copiați din `src` într-un tablou temporar și apoi copiat din tablou în `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `src` trebuie să fie [valid] pentru citirile de octeți `count * size_of::<T>()`.
///
/// * `dst` trebuie să fie [valid] pentru scrieri de octeți `count * size_of::<T>()`.
///
/// * Atât `src`, cât și `dst` trebuie aliniate corect.
///
/// La fel ca [`read`], `copy` creează o copie pe biți a `T`, indiferent dacă `T` este [`Copy`].
/// Dacă `T` nu este [`Copy`], folosind atât valorile din regiunea care începe de la `*src`, cât și regiunea care începe de la `* dst` se poate [violate memory safety][read-ownership].
///
///
/// Rețineți că, chiar dacă dimensiunea copiată efectiv (`count * size_of: :<T>()`) este `0`, indicatoarele trebuie să fie nule și aliniate corespunzător.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Creați eficient un Rust vector dintr-un buffer nesigur:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` trebuie aliniat corect pentru tipul său și diferit de zero.
/// /// * `ptr` trebuie să fie valabil pentru citirile elementelor adiacente `elts` de tip `T`.
/// /// * Aceste elemente nu trebuie utilizate după apelarea acestei funcții, cu excepția cazului în care `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SIGURANȚĂ: Precondiția noastră asigură că sursa este aliniată și valabilă,
///     // iar `Vec::with_capacity` ne asigură că avem spațiu utilizabil pentru a le scrie.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SIGURANȚĂ: L-am creat cu această capacitate mult mai devreme,
///     // iar `copy` anterior a inițializat aceste elemente.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Efectuați aceste verificări numai în timpul rulării
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Nu intră în panică pentru a menține impactul codegenului mai mic.
        abort();
    }*/

    // SIGURANȚĂ: contractul de siguranță pentru `copy` trebuie confirmat de către apelant.
    unsafe { copy(src, dst, count) }
}

/// Setează `count * size_of::<T>()` octeți de memorie începând de la `dst` la `val`.
///
/// `write_bytes` este similar cu C's [`memset`], dar setează octeții `count * size_of::<T>()` la `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Comportamentul este nedefinit dacă se încalcă oricare dintre următoarele condiții:
///
/// * `dst` trebuie să fie [valid] pentru scrieri de octeți `count * size_of::<T>()`.
///
/// * `dst` trebuie aliniate corect.
///
/// În plus, apelantul trebuie să se asigure că scrierea octeților `count * size_of::<T>()` în regiunea de memorie dată are ca rezultat o valoare validă de `T`.
/// Utilizarea unei regiuni de memorie tastată ca `T` care conține o valoare nevalidă de `T` este un comportament nedefinit.
///
/// Rețineți că, chiar dacă dimensiunea copiată efectiv (`count * size_of: :<T>()`) este `0`, indicatorul trebuie să nu fie NULL și să fie aliniat corespunzător.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Utilizare de bază:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Crearea unei valori nevalide:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Scurge valoarea reținută anterior prin suprascrierea `Box<T>` cu un indicator nul.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // În acest moment, utilizarea sau eliminarea `v` are ca rezultat un comportament nedefinit.
/// // drop(v); // ERROR
///
/// // Chiar și scurgerea lui `v` "uses" și, prin urmare, este un comportament nedefinit.
/// // mem::forget(v); // ERROR
///
/// // De fapt, `v` este nevalid în funcție de invarianții de schemă de tip de bază, așa că * orice operație care îl atinge este un comportament nedefinit.
/////
/// // să v2 =v;//EROARE
///
/// unsafe {
///     // În schimb, să introducem o valoare validă
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Acum cutia este în regulă
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SIGURANȚĂ: contractul de siguranță pentru `write_bytes` trebuie confirmat de către apelant.
    unsafe { write_bytes(dst, val, count) }
}