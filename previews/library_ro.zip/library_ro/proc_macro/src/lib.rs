//! O bibliotecă de asistență pentru autorii de macrocomenzi la definirea noilor macrocomenzi
//!
//! Această bibliotecă, furnizată de distribuția standard, oferă tipurile consumate în interfețele definițiilor macro definite procedural, cum ar fi macro-urile funcționale `#[proc_macro]`, atributele macro `#[proc_macro_attribute]` și atributele derivate personalizate `#[proc_macro_derive]`.
//!
//!
//! Consultați [the book] pentru mai multe.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Determină dacă proc_macro a fost făcut accesibil programului care rulează în prezent.
///
/// Proc_macro crate este destinat numai utilizării în cadrul implementării macrocomenzilor procedurale.Toate funcțiile din acest crate panic dacă sunt invocate din afara unui macro procedural, cum ar fi dintr-un script de construcție sau un test de unitate sau un binar obișnuit Rust.
///
/// Având în vedere bibliotecile Rust care sunt proiectate să accepte atât cazuri de utilizare macro, cât și non-macro, `proc_macro::is_available()` oferă o modalitate fără panică de a detecta dacă infrastructura necesară pentru a utiliza API-ul proc_macro este disponibilă în prezent.
/// Returnează adevărat dacă este invocat din interiorul unei macro procedurale, fals dacă este invocat din orice alt binar.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Principalul tip oferit de acest crate, reprezentând un flux abstract de tokens, sau, mai precis, o secvență de arbori token.
/// Tipul oferă interfețe pentru iterația asupra acelor copaci token și, dimpotrivă, colectarea unui număr de copaci token într-un singur flux.
///
///
/// Aceasta este atât intrarea, cât și ieșirea definițiilor `#[proc_macro]`, `#[proc_macro_attribute]` și `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Eroare returnată de la `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Returnează un `TokenStream` gol care nu conține copaci token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Verifică dacă acest `TokenStream` este gol.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Încearcă să rupă șirul în tokens și să analizeze acele tokens într-un flux token.
/// Poate eșua din mai multe motive, de exemplu, dacă șirul conține delimitatori dezechilibrați sau caractere care nu există în limbă.
///
/// Toate tokens din fluxul analizat primesc întinderi `Span::call_site()`.
///
/// NOTE: unele erori pot cauza panics în loc să returneze `LexError`.Ne rezervăm dreptul de a schimba aceste erori în " LexError` ulterior.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, podul oferă doar `to_string`, implementați `fmt::Display` pe baza acestuia (inversul relației obișnuite dintre cele două).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Tipărește fluxul token ca un șir care se presupune că poate fi convertit fără pierderi înapoi în același flux token (modulo se întinde), cu excepția eventualelor `TokenTree: : Group`s cu delimitatori `Delimiter::None` și literali numerici negativi.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Tipărește token într-o formă convenabilă pentru depanare.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Creează un flux token care conține un singur arbore token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Colectează un număr de copaci token într-un singur flux.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// O operațiune "flattening" pe fluxurile token, colectează copaci token de la mai multe fluxuri token într-un singur flux.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Folosiți o implementare optimizată if/when posibilă.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Detalii de implementare publică pentru tipul `TokenStream`, cum ar fi iteratorii.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Un iterator peste " TokenTree`s al lui" TokenStream`.
    /// Iterația este "shallow", de exemplu, iteratorul nu se repetă în grupuri delimitate și returnează grupuri întregi ca arborii token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` acceptă tokens arbitrar și se extinde într-un `TokenStream` care descrie intrarea.
/// De exemplu, `quote!(a + b)` va produce o expresie care, atunci când este evaluată, construiește `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Necotarea se face cu `$` și funcționează luând identitatea următoare ca termen necitatat.
/// Pentru a cita `$` în sine, utilizați `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// O regiune de cod sursă, împreună cu informații de extindere macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Creează un nou `Diagnostic` cu `message` dat la intervalul `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Un interval care se rezolvă la site-ul de definiție macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Intervalul invocării macro-ului procedural curent.
    /// Identificatorii creați cu acest interval vor fi rezolvați ca și cum ar fi fost scrise direct la locația de apel macro (igiena de la site-ul apelului), iar alte coduri de la site-ul de apeluri macro vor putea să se refere și la acestea.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Un interval care reprezintă igiena `macro_rules` și, uneori, se rezolvă la locul de definire a macrocomenzilor (variabile locale, etichete, `$crate`) și, uneori, la site-ul de apel macro (orice altceva).
    ///
    /// Locația span este preluată de la site-ul de apelare.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Fișierul sursă original în care indică acest interval.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` pentru tokens în expansiunea macro anterioară din care a fost generat `self`, dacă există.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Intervalul pentru codul sursă de origine din care a fost generat `self`.
    /// Dacă acest `Span` nu a fost generat din alte expansiuni macro, atunci valoarea de returnare este aceeași cu `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Obține line/column de pornire în fișierul sursă pentru acest interval.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Obține sfârșitul line/column în fișierul sursă pentru acest interval.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Creează un nou interval cuprinzând `self` și `other`.
    ///
    /// Returnează `None` dacă `self` și `other` provin din fișiere diferite.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Creează un nou interval cu aceleași informații line/column ca și `self`, dar care rezolvă simbolurile ca și cum ar fi la `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Creează un nou interval cu același comportament de rezoluție ca `self`, dar cu informațiile line/column ale `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Se compară cu întinderile pentru a vedea dacă sunt egale.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Returnează textul sursă în spatele unui interval.
    /// Aceasta păstrează codul sursă original, inclusiv spațiile și comentariile.
    /// Returnează un rezultat numai dacă intervalul corespunde codului sursă real.
    ///
    /// Note: Rezultatul observabil al unei macrocomenzi ar trebui să se bazeze doar pe tokens și nu pe acest text sursă.
    ///
    /// Rezultatul acestei funcții este cel mai bun efort de a fi utilizat numai pentru diagnosticare.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Tipărește un interval într-un formular convenabil pentru depanare.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// O pereche linie-coloană care reprezintă începutul sau sfârșitul unui `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Linia cu 1 index în fișierul sursă pe care intervalul începe sau se termină (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Coloana 0-indexată (în caractere UTF-8) din fișierul sursă pe care intervalul începe sau se termină (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Fișierul sursă al unui `Span` dat.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Obține calea către acest fișier sursă.
    ///
    /// ### Note
    /// Dacă intervalul de cod asociat cu acest `SourceFile` a fost generat de o macro externă, această macro, este posibil să nu fie o cale reală în sistemul de fișiere.
    /// Folosiți [`is_real`] pentru a verifica.
    ///
    /// De asemenea, rețineți că, chiar dacă `is_real` returnează `true`, dacă `--remap-path-prefix` a fost trecut pe linia de comandă, calea indicată poate să nu fie de fapt validă.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Returnează `true` dacă acest fișier sursă este un fișier sursă real și nu este generat de extinderea unei macrocomenzi externe.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Acesta este un hack până când sunt implementate intervalele intercrate și putem avea fișiere sursă reale pentru intervalele generate în macrocomenzi externe.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Un singur token sau o secvență delimitată de copaci token (de exemplu, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Un flux token înconjurat de delimitatori de paranteză.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Un identificator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Un singur caracter de punctuație (`+`, `,`, `$` etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Un caracter literal (`'a'`), șirul (`"hello"`), numărul (`2.3`) etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Returnează intervalul acestui arbore, delegând metodei `span` a token conținut sau un flux delimitat.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configurează intervalul pentru *numai acest token*.
    ///
    /// Rețineți că, dacă acest token este un `Group`, atunci această metodă nu va configura intervalul fiecărui tokens intern, aceasta va delega pur și simplu metodei `set_span` a fiecărei variante.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Tipărește arborele token într-o formă convenabilă pentru depanare.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Fiecare dintre acestea are numele în tipul struct din depanarea derivată, deci nu vă deranjați cu un strat suplimentar de indirecție
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, podul oferă doar `to_string`, implementați `fmt::Display` pe baza acestuia (inversul relației obișnuite dintre cele două).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Tipărește arborele token ca un șir care se presupune că poate fi convertit fără pierderi înapoi în același arbore token (întinderi modulo), cu excepția eventualelor " TokenTree: : Group`s cu delimitatori `Delimiter::None` și literali numerici negativi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Un flux token delimitat.
///
/// Un `Group` conține intern un `TokenStream` care este înconjurat de " Delimiter`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Descrie modul în care este delimitată o secvență de arbori token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Un delimitator implicit, care poate, de exemplu, să apară în jurul tokens provenind de la un "macro variable" `$var`.
    /// Este important să păstrăm prioritățile operatorului în cazuri precum `$var * 3` în care `$var` este `1 + 2`.
    /// Este posibil ca delimitatorii implicați să nu supraviețuiască dus-întorsul unui flux token printr-un șir.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Creează un nou `Group` cu delimitatorul dat și fluxul token.
    ///
    /// Acest constructor va seta intervalul pentru acest grup la `Span::call_site()`.
    /// Pentru a schimba intervalul, puteți utiliza metoda `set_span` de mai jos.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Returnează delimitatorul acestui `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Returnează `TokenStream` din tokens care sunt delimitate în acest `Group`.
    ///
    /// Rețineți că fluxul token returnat nu include delimitatorul returnat mai sus.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Returnează intervalul pentru delimitatorii acestui flux token, acoperind întregul `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Returnează intervalul care indică delimitatorul de deschidere al acestui grup.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Returnează intervalul care indică delimitatorul de închidere al acestui grup.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configurează intervalul pentru delimitatorii acestui " grup`, dar nu și tokens intern.
    ///
    /// Această metodă **nu** va seta intervalul tuturor tokens interne cuprinse de acest grup, ci mai degrabă va seta intervalul delimitatorului tokens la nivelul `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, podul oferă doar `to_string`, implementați `fmt::Display` pe baza acestuia (inversul relației obișnuite dintre cele două).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tipărește grupul ca un șir care ar trebui să fie convertibil fără pierderi înapoi în același grup (întinderi modulo), cu excepția eventualelor `TokenTree: : Group`s cu delimitatori `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Un `Punct` este un caracter de punctuație unic, cum ar fi `+`, `-` sau `#`.
///
/// Operatorii cu mai multe caractere, cum ar fi `+=`, sunt reprezentați ca două instanțe ale `Punct` cu forme diferite de `Spacing` returnate.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Dacă un `Punct` este urmat imediat de un alt `Punct` sau urmat de un alt token sau spațiu alb.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// de exemplu, `+` este `Alone` în `+ =`, `+ident` sau `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// de exemplu, `+` este `Joint` în `+=` sau `'#`.
    /// În plus, cotația simplă `'` se poate alătura cu identificatorii pentru a forma `'ident` în timpul vieții.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Creează un nou `Punct` din caracterul și spațiul dat.
    /// Argumentul `ch` trebuie să fie un caracter de punctuație valid permis de limbă, altfel funcția va panic.
    ///
    /// `Punct` returnat va avea intervalul implicit de `Span::call_site()`, care poate fi configurat în continuare cu metoda `set_span` de mai jos.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Returnează valoarea acestui caracter de punctuație ca `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Returnează spațiul acestui caracter de punctuație, indicând dacă este urmat imediat de un alt `Punct` în fluxul token, astfel încât acestea pot fi combinate într-un operator cu mai multe caractere (`Joint`) sau este urmat de un alt token sau spațiu alb (`Alone`), astfel încât operatorul are cu siguranță încheiat.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Returnează intervalul pentru acest caracter de punctuație.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configurați intervalul pentru acest caracter de punctuație.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, podul oferă doar `to_string`, implementați `fmt::Display` pe baza acestuia (inversul relației obișnuite dintre cele două).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tipărește caracterul de punctuație ca un șir care ar trebui să fie convertibil fără pierderi înapoi în același caracter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Un identificator (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Creează un nou `Ident` cu `string` dat, precum și `span` specificat.
    /// Argumentul `string` trebuie să fie un identificator valid permis de limbă (inclusiv cuvinte cheie, de ex. `self` sau `fn`).În caz contrar, funcția va panic.
    ///
    /// Rețineți că `span`, aflat în prezent în rustc, configurează informațiile de igienă pentru acest identificator.
    ///
    /// Începând cu acest moment, `Span::call_site()` optează în mod explicit pentru igiena "call-site", ceea ce înseamnă că identificatorii creați cu acest interval vor fi rezolvați ca și cum ar fi fost scrise direct la locația apelului macro, iar alt cod de pe site-ul de apel macro va putea face referire la ei de asemenea.
    ///
    ///
    /// Perioadele ulterioare, cum ar fi `Span::def_site()`, vă vor permite să vă înscrieți la igiena "definition-site", ceea ce înseamnă că identificatorii creați cu acest interval vor fi rezolvați la locația definiției macro, iar alte coduri de pe site-ul de apeluri macro nu vor putea face referire la acestea.
    ///
    /// Datorită importanței actuale a igienei, acest constructor, spre deosebire de alte tokens, necesită un `Span` pentru a fi specificat la construcție.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// La fel ca `Ident::new`, dar creează un identificator brut (`r#ident`).
    /// Argumentul `string` este un identificator valid permis de limbă (inclusiv cuvinte cheie, de ex. `fn`).
    /// Cuvinte cheie care pot fi utilizate în segmente de cale (de ex
    /// `self`, " super`) nu sunt acceptate și vor provoca un panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Returnează intervalul acestui `Ident`, cuprinzând întregul șir returnat de [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configurează întinderea acestui `Ident`, modificând eventual contextul său de igienă.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, podul oferă doar `to_string`, implementați `fmt::Display` pe baza acestuia (inversul relației obișnuite dintre cele două).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tipărește identificatorul ca un șir care ar trebui să fie convertibil fără pierderi înapoi în același identificator.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Un șir literal (`"hello"`), șir de octeți (`b"hello"`), caracter (`'a'`), caracter de octet (`b'a'`), un număr întreg sau cu virgulă mobilă cu sau fără sufix (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Literalii booleeni precum `true` și `false` nu aparțin aici, sunt " Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Creează un nou literal întreg cu sufix cu valoarea specificată.
        ///
        /// Această funcție va crea un număr întreg ca `1u32` în care valoarea întregului specificată este prima parte a token și integralul este, de asemenea, sufixat la sfârșit.
        /// Literalele create din numere negative pot să nu supraviețuiască dus-întors prin `TokenStream` sau șiruri și pot fi împărțite în două tokens (`-` și literal pozitiv).
        ///
        ///
        /// Literalele create prin această metodă au intervalul `Span::call_site()` în mod implicit, care poate fi configurat cu metoda `set_span` de mai jos.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Creează un nou număr întreg nesafixat cu valoarea specificată.
        ///
        /// Această funcție va crea un număr întreg ca `1` în care valoarea întregului specificată este prima parte a token.
        /// Nu este specificat nici un sufix pe acest token, ceea ce înseamnă că invocații precum `Literal::i8_unsuffixed(1)` sunt echivalente cu `Literal::u32_unsuffixed(1)`.
        /// Literalele create din numere negative pot să nu supraviețuiască rasturnărilor prin `TokenStream` sau șiruri și pot fi împărțite în două tokens (`-` și literal pozitiv).
        ///
        ///
        /// Literalele create prin această metodă au intervalul `Span::call_site()` în mod implicit, care poate fi configurat cu metoda `set_span` de mai jos.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Creează un nou literal fără virgulă în virgulă mobilă.
    ///
    /// Acest constructor este similar cu cele ca `Literal::i8_unsuffixed`, unde valoarea float-ului este emisă direct în token, dar nu este utilizat sufix, deci se poate deduce că este un `f64` mai târziu în compilator.
    ///
    /// Literalele create din numere negative pot să nu supraviețuiască rasturnărilor prin `TokenStream` sau șiruri și pot fi împărțite în două tokens (`-` și literal pozitiv).
    ///
    /// # Panics
    ///
    /// Această funcție necesită ca plutitorul specificat să fie finit, de exemplu, dacă este infinit sau NaN, această funcție va panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Creează un nou literal în virgulă mobilă cu sufix.
    ///
    /// Acest constructor va crea un literal ca `1.0f32` în care valoarea specificată este partea precedentă a token și `f32` este sufixul token.
    /// Acest token va fi întotdeauna dedus a fi un `f32` în compilator.
    /// Literalele create din numere negative pot să nu supraviețuiască rasturnărilor prin `TokenStream` sau șiruri și pot fi împărțite în două tokens (`-` și literal pozitiv).
    ///
    ///
    /// # Panics
    ///
    /// Această funcție necesită ca plutitorul specificat să fie finit, de exemplu, dacă este infinit sau NaN, această funcție va panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Creează un nou literal fără virgulă în virgulă mobilă.
    ///
    /// Acest constructor este similar cu cele ca `Literal::i8_unsuffixed`, unde valoarea float-ului este emisă direct în token, dar nu este utilizat sufix, deci se poate deduce că este un `f64` mai târziu în compilator.
    ///
    /// Literalele create din numere negative pot să nu supraviețuiască rasturnărilor prin `TokenStream` sau șiruri și pot fi împărțite în două tokens (`-` și literal pozitiv).
    ///
    /// # Panics
    ///
    /// Această funcție necesită ca plutitorul specificat să fie finit, de exemplu, dacă este infinit sau NaN, această funcție va panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Creează un nou literal în virgulă mobilă cu sufix.
    ///
    /// Acest constructor va crea un literal ca `1.0f64` în care valoarea specificată este partea precedentă a token și `f64` este sufixul token.
    /// Acest token va fi întotdeauna dedus a fi un `f64` în compilator.
    /// Literalele create din numere negative pot să nu supraviețuiască rasturnărilor prin `TokenStream` sau șiruri și pot fi împărțite în două tokens (`-` și literal pozitiv).
    ///
    ///
    /// # Panics
    ///
    /// Această funcție necesită ca plutitorul specificat să fie finit, de exemplu, dacă este infinit sau NaN, această funcție va panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Șir literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Caracter literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Litere șir de octeți.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Returnează intervalul care cuprinde acest literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configurează intervalul asociat pentru acest literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Returnează un `Span` care este un subset de `self.span()` care conține doar octeții sursă în intervalul `range`.
    /// Returnează `None` dacă intervalul tăiat dorit se află în afara limitelor `self`.
    ///
    // FIXME(SergioBenitez): verificați dacă intervalul de octeți începe și se termină la o limită UTF-8 a sursei.
    // în caz contrar, este probabil ca un panic să apară în altă parte când textul sursă este tipărit.
    // FIXME(SergioBenitez): nu există nicio modalitate prin care utilizatorul să știe la ce se referă de fapt `self.span()`, astfel încât această metodă poate fi numită în prezent doar orbește.
    // De exemplu, `to_string()` pentru caracterul 'c' returnează "'\u{63}'";nu există nicio modalitate prin care utilizatorul să știe dacă textul sursă a fost 'c' sau dacă a fost '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) ceva asemănător cu `Option::cloned`, dar pentru `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, podul oferă doar `to_string`, implementați `fmt::Display` pe baza acestuia (inversul relației obișnuite dintre cele două).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprimă literalul ca un șir care ar trebui să fie convertibil fără pierderi înapoi în același literal (cu excepția posibilelor rotunjiri pentru literele în virgulă mobilă).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Acces urmărit la variabilele de mediu.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Recuperați o variabilă de mediu și adăugați-o pentru a crea informații de dependență.
    /// Sistemul de construire care execută compilatorul va ști că variabila a fost accesată în timpul compilării și va putea rula din nou compilarea atunci când valoarea variabilei se modifică.
    ///
    /// Pe lângă urmărirea dependenței, această funcție ar trebui să fie echivalentă cu `env::var` din biblioteca standard, cu excepția faptului că argumentul trebuie să fie UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}