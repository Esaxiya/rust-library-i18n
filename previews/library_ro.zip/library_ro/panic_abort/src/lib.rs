//! Implementarea Rust panics prin procesul de întrerupere
//!
//! Comparativ cu implementarea prin derulare, acest crate este *mult* mai simplu!Acestea fiind spuse, nu este la fel de versatil, dar iată!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" sarcina utilă și shim la avortul relevant pe platforma în cauză.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // sunați la std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Pe Windows, utilizați mecanismul __fastfail specific procesorului.În Windows 8 și versiunile ulterioare, acest lucru va încheia procesul imediat fără a rula niciun handler de excepție în proces.
            // În versiunile anterioare ale Windows, această secvență de instrucțiuni va fi tratată ca o încălcare a accesului, încheind procesul, dar fără a ocoli neapărat toate gestionarele de excepție.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: aceasta este aceeași implementare ca în `abort_internal` a libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Asta ... este un pic ciudat.Tl; dr;este că acest lucru este necesar pentru a lega corect, explicația mai lungă este mai jos.
//
// Chiar acum binarele libcore/libstd pe care le livrăm sunt toate compilate cu `-C panic=unwind`.Acest lucru se face pentru a se asigura că binarele sunt compatibile la maximum cu cât mai multe situații posibil.
// Cu toate acestea, compilatorul necesită un "personality function" pentru toate funcțiile compilate cu `-C panic=unwind`.Această funcție de personalitate este codificată la simbolul `rust_eh_personality` și este definită de elementul lang `eh_personality`.
//
// So...
// de ce nu definim doar acel element lang aici?Buna intrebare!Modul în care sunt conectate timpii de execuție panic este de fapt puțin subtil prin faptul că sunt "sort of" în magazinul crate al compilatorului, dar de fapt conectat doar dacă altul nu este de fapt legat.
//
// Acest lucru sfârșește prin a însemna că atât acest crate, cât și panic_unwind crate pot apărea în magazinul crate al compilatorului și dacă ambele definesc elementul lang `eh_personality`, atunci va apărea o eroare.
//
// Pentru a gestiona acest lucru, compilatorul necesită doar ca `eh_personality` să fie definit dacă runtime-ul panic care este conectat este runtime-ul de derulare și altfel nu este necesar să fie definit (pe bună dreptate).
// Cu toate acestea, în acest caz, această bibliotecă definește acest simbol, astfel încât există cel puțin o anumită personalitate undeva.
//
// În esență, acest simbol este definit doar pentru a fi conectat la binarele libcore/libstd, dar nu ar trebui să fie apelat niciodată, deoarece nu ne conectăm deloc într-un timp de rulare derulant.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Pe x86_64-pc-windows-gnu folosim propria noastră funcție de personalitate care trebuie să returneze `ExceptionContinueSearch` pe măsură ce transmitem toate cadrele noastre.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Similar cu cel de mai sus, acesta corespunde articolului `eh_catch_typeinfo` lang care este utilizat doar pe Emscripten în prezent.
    //
    // Deoarece panics nu generează excepții, iar excepțiile străine sunt în prezent UB cu -C panic=avort (deși acest lucru poate fi modificat), orice apel catch_unwind nu va folosi niciodată acest tip de informație.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Aceste două sunt numite de obiectele noastre de pornire de pe i686-pc-windows-gnu, dar nu au nevoie să facă nimic, deci corpurile sunt nopți.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}