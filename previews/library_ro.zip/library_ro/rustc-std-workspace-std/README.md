# `rustc-std-workspace-std` crate

Consultați documentația pentru `rustc-std-workspace-core` crate.