// rsbegin.o și rsend.o sunt așa-numitele "compiler runtime startup objects".
// Acestea conțin codul necesar pentru inițializarea corectă a runtime-ului compilatorului.
//
// Când o imagine executabilă sau dylib este legată, toate codurile de utilizator și bibliotecile sunt "sandwiched" între aceste două fișiere obiect, astfel încât codul sau datele de la rsbegin.o devin primele în secțiunile respective ale imaginii, în timp ce codul și datele de la rsend.o devin ultimele.
// Acest efect poate fi folosit pentru a plasa simboluri la începutul sau la sfârșitul unei secțiuni, precum și pentru a insera anteturile sau subsolurile necesare.
//
// Rețineți că punctul real de intrare al modulului se află în obiectul de pornire C runtime (denumit de obicei `crtX.o`), care invocă apoi apeluri de inițializare ale altor componente de runtime (înregistrate prin încă o altă secțiune specială de imagine).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marcează începutul cadrului stivei secțiunea de informații despre derulare
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Spațiu de zgârieturi pentru contabilitatea internă a derulatorului.
    // Aceasta este definită ca `struct object` în $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Desfășurați rutinele de informații registration/deregistration.
    // Consultați documentele libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // înregistrați informațiile despre derularea la pornirea modulului
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // anulați înregistrarea la închidere
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Înregistrare de rutină init/uninit specifică MinGW
    pub mod mingw_init {
        // Obiectele de pornire ale MinGW (crt0.o/dllcrt0.o) vor invoca constructori globali în secțiunile .ctors și .dtors la pornire și ieșire.
        // În cazul DLL-urilor, acest lucru se face atunci când DLL-ul este încărcat și descărcat.
        //
        // Linkerul va sorta secțiunile, ceea ce asigură că apelurile noastre de apel sunt situate la sfârșitul listei.
        // Deoarece constructorii sunt executați în ordine inversă, acest lucru asigură că apelurile noastre de apel sunt primele și ultimele executate.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: apeluri de inițializare C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .medicii. *: apeluri de apel de terminare C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}