/// Yn creu [`Vec`] sy'n cynnwys y dadleuon.
///
/// `vec!` yn caniatáu diffinio `Vec`s gyda'r un gystrawen ag ymadroddion arae.
/// Mae dwy ffurf ar y macro hwn:
///
/// - Creu [`Vec`] sy'n cynnwys rhestr benodol o elfennau:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Creu [`Vec`] o elfen a maint penodol:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Sylwch, yn wahanol i ymadroddion arae, mae'r gystrawen hon yn cefnogi'r holl elfennau sy'n gweithredu [`Clone`] ac nid oes rhaid i nifer yr elfennau fod yn gyson.
///
/// Bydd hyn yn defnyddio `clone` i ddyblygu mynegiad, felly dylai un fod yn ofalus wrth ddefnyddio hwn gyda mathau â gweithrediad `Clone` ansafonol.
/// Er enghraifft, `vec![Rc::new(1);5] `bydd yn creu vector o bum cyfeiriad at yr un gwerth cyfanrif mewn bocs, nid pum cyfeiriad sy'n pwyntio at gyfanrifau mewn blychau annibynnol.
///
///
/// Hefyd, nodwch fod `vec![expr; 0]` yn cael ei ganiatáu, ac mae'n cynhyrchu vector gwag.
/// Bydd hyn yn dal i werthuso `expr`, fodd bynnag, ac yn gollwng y gwerth sy'n deillio ohono ar unwaith, felly byddwch yn ymwybodol o'r sgîl-effeithiau.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): gyda cfg(test) nid yw'r dull `[T]::into_vec` cynhenid, sy'n ofynnol ar gyfer y diffiniad macro hwn, ar gael.
// Yn lle hynny, defnyddiwch y swyddogaeth `slice::into_vec` sydd ond ar gael gyda cfg(test) NB gweler y modiwl slice::hack yn slice.rs i gael mwy o wybodaeth
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Yn creu `String` gan ddefnyddio rhyngosod ymadroddion rhedeg.
///
/// Y ddadl gyntaf y mae `format!` yn ei derbyn yw llinyn fformat.Rhaid i hwn fod yn llythrennol llinynnol.Mae pŵer y llinyn fformatio yn y `{}` s sydd wedi'i gynnwys.
///
/// Mae paramedrau ychwanegol a basiwyd i `format!` yn disodli'r `{}` s o fewn y llinyn fformatio yn y drefn a roddir oni bai bod paramedrau enwol neu leoliadol yn cael eu defnyddio;gweler [`std::fmt`] i gael mwy o wybodaeth.
///
///
/// Defnydd cyffredin ar gyfer `format!` yw concatenation a rhyngosod llinynnau.
/// Defnyddir yr un confensiwn â macros [`print!`] a [`write!`], yn dibynnu ar gyrchfan arfaethedig y llinyn.
///
/// I drosi gwerth sengl i linyn, defnyddiwch y dull [`to_string`].Bydd hyn yn defnyddio'r fformatio [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics os yw gweithrediad fformatio trait yn dychwelyd gwall.
/// Mae hyn yn dynodi gweithrediad anghywir gan nad yw `fmt::Write for String` byth yn dychwelyd gwall ei hun.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Gorfodwch nod AUS i fynegiant i wella diagnosteg mewn safle patrwm.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}