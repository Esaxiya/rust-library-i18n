//! Awgrymiadau cyfrif cyfeirnod un-edau.Mae 'Rc' yn sefyll am 'Cyfeirnod
//! Counted'.
//!
//! Mae'r math [`Rc<T>`][`Rc`] yn darparu perchnogaeth a rennir o werth math `T`, wedi'i ddyrannu yn y domen.
//! Mae galw [`clone`][clone] ar [`Rc`] yn cynhyrchu pwyntydd newydd i'r un dyraniad yn y domen.
//! Pan fydd y pwyntydd [`Rc`] olaf i ddyraniad penodol yn cael ei ddinistrio, mae'r gwerth sy'n cael ei storio yn y dyraniad hwnnw (y cyfeirir ato'n aml fel "inner value") hefyd yn cael ei ollwng.
//!
//! Mae cyfeiriadau a rennir yn Rust yn gwrthod treiglo yn ddiofyn, ac nid yw [`Rc`] yn eithriad: yn gyffredinol ni allwch gael cyfeiriad treiddgar at rywbeth y tu mewn i [`Rc`].
//! Os oes angen treiddioldeb arnoch, rhowch [`Cell`] neu [`RefCell`] y tu mewn i'r [`Rc`];gweld [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] yn defnyddio cyfrif cyfeiriadau nad yw'n atomig.
//! Mae hyn yn golygu bod uwchben yn isel iawn, ond ni ellir anfon [`Rc`] rhwng edafedd, ac o ganlyniad nid yw [`Rc`] yn gweithredu [`Send`][send].
//! O ganlyniad, bydd y crynhoydd Rust yn gwirio *ar amser llunio* nad ydych chi'n anfon [`Rc`] rhwng edafedd.
//! Os oes angen cyfrif cyfeirnod atomig aml-edau arnoch chi, defnyddiwch [`sync::Arc`][arc].
//!
//! Gellir defnyddio'r dull [`downgrade`][downgrade] i greu pwyntydd [`Weak`] nad yw'n berchen arno.
//! Gall pwyntydd [`Weak`] gael ei [`uwchraddio`][uwchraddio] d i [`Rc`], ond bydd hyn yn dychwelyd [`None`] os yw'r gwerth sydd wedi'i storio yn y dyraniad eisoes wedi'i ollwng.
//! Mewn geiriau eraill, nid yw awgrymiadau `Weak` yn cadw'r gwerth y tu mewn i'r dyraniad yn fyw;fodd bynnag, maen nhw *yn* cadw'r * dyraniad (y storfa gefn ar gyfer y gwerth mewnol) yn fyw.
//!
//! Ni fydd cylch rhwng awgrymiadau [`Rc`] byth yn cael ei ddeallocated.
//! Am y rheswm hwn, defnyddir [`Weak`] i dorri beiciau.
//! Er enghraifft, gallai coeden fod ag awgrymiadau [`Rc`] cryf o nodau rhiant i blant, ac awgrymiadau [`Weak`] gan blant yn ôl i'w rhieni.
//!
//! `Rc<T>` dereferences yn awtomatig i `T` (drwy'r [`Deref`] trait), fel y gallwch alw `Dulliau T` ar werth o fath [`Rc<T>`][`Rc`].
//! Er mwyn osgoi gwrthdaro â enw `dulliau T`, mae'r dulliau o [`Rc<T>`][`Rc`] ei hun yn cael eu swyddogaethau cysylltiedig, a elwir gan ddefnyddio [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Gellir galw gweithrediadau`traits fel `Clone` 'hefyd gan ddefnyddio cystrawen gwbl gymwys.
//! Mae'n well gan rai pobl ddefnyddio cystrawen gwbl gymwys, tra bod yn well gan eraill ddefnyddio cystrawen dull-galw.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Cystrawen dull-galw
//! let rc2 = rc.clone();
//! // Cystrawen gwbl gymwys
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] nid yw'n awto-barchu i `T`, oherwydd mae'n bosibl bod y gwerth mewnol eisoes wedi'i ollwng.
//!
//! # Cyfeiriadau clonio
//!
//! Mae creu cyfeiriad newydd at yr un dyraniad â phwyntydd cyfrif cyfeirnod presennol yn cael ei wneud gan ddefnyddio'r `Clone` trait a weithredir ar gyfer [`Rc<T>`][`Rc`] a [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Mae'r ddau gystrawen isod yn gyfwerth.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // mae a a b yn pwyntio i'r un lleoliad cof ag foo.
//! ```
//!
//! Cystrawen `Rc::clone(&from)` yw'r mwyaf idiomatig oherwydd ei fod yn cyfleu ystyr y cod yn fwy penodol.
//! Yn yr enghraifft uchod, mae'r gystrawen hon yn ei gwneud hi'n haws gweld bod y cod hwn yn creu cyfeirnod newydd yn hytrach na chopïo cynnwys cyfan foo.
//!
//! # Examples
//!
//! Ystyriwch senario lle mae set o `Gadget`s yn eiddo i `Owner` penodol.
//! Rydym am gael ein `pwynt Gadget`s i'w `Owner`.Ni allwn wneud hyn gyda pherchnogaeth unigryw, oherwydd gall mwy nag un teclyn berthyn i'r un `Owner`.
//! [`Rc`] yn caniatáu inni rannu `Owner` rhwng ``Gadget`s lluosog, a sicrhau bod yr `Owner` yn parhau i gael ei ddyrannu cyhyd ag unrhyw bwyntiau `Gadget` arno.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... meysydd eraill
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... meysydd eraill
//! }
//!
//! fn main() {
//!     // Creu `Owner` wedi'i gyfrifo â chyfeirnod.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Creu `Gadget`s sy'n perthyn i `gadget_owner`.
//!     // Mae clonio'r `Rc<Owner>` yn rhoi pwyntydd newydd inni i'r un dyraniad `Owner`, gan gynyddu'r cyfrif cyfeirio yn y broses.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Cael gwared ar ein newidyn lleol `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Er gwaethaf gollwng `gadget_owner`, rydym yn dal i allu argraffu enw'r `Owner` o'r `Gadget`s.
//!     // Mae hyn oherwydd ein bod ni wedi gollwng `Rc<Owner>` sengl yn unig, nid yr `Owner` y mae'n tynnu sylw ato.
//!     // Cyn belled â bod `Rc<Owner>` eraill yn pwyntio at yr un dyraniad `Owner`, bydd yn aros yn fyw.
//!     // Mae'r amcanestyniad maes `gadget1.owner.name` yn gweithio oherwydd bod `Rc<Owner>` yn dad-gyfeirio'n awtomatig i `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ar ddiwedd y swyddogaeth, mae `gadget1` a `gadget2` yn cael eu dinistrio, a gyda nhw mae'r cyfeiriadau olaf a gyfrifwyd at ein `Owner`.
//!     // Bellach mae Gadget Man yn cael ei ddinistrio hefyd.
//!     //
//! }
//! ```
//!
//! Os bydd ein gofynion yn newid, a bod angen i ni hefyd allu tramwyo o `Owner` i `Gadget`, byddwn yn mynd i broblemau.
//! Mae pwyntydd [`Rc`] o `Owner` i `Gadget` yn cyflwyno cylch.
//! Mae hyn yn golygu na all eu cyfrif cyfeiriadau fyth gyrraedd 0, ac ni fydd y dyraniad byth yn cael ei ddinistrio:
//! gollyngiad cof.Er mwyn symud o gwmpas hyn, gallwn ddefnyddio awgrymiadau [`Weak`].
//!
//! Mae Rust mewn gwirionedd yn ei gwneud hi'n anodd cynhyrchu'r ddolen hon yn y lle cyntaf.Er mwyn cael dau werth sy'n pwyntio at ei gilydd, mae angen newid un ohonynt.
//! Mae hyn yn anodd oherwydd bod [`Rc`] yn gorfodi diogelwch cof trwy roi cyfeiriadau a rennir yn unig at y gwerth y mae'n ei lapio, ac nid yw'r rhain yn caniatáu treiglo uniongyrchol.
//! Mae angen i ni lapio'r rhan o'r gwerth yr ydym am ei dreiglo mewn [`RefCell`], sy'n darparu *treiddioldeb mewnol*: dull i gyflawni treiddioldeb trwy gyfeirnod a rennir.
//! [`RefCell`] yn gorfodi rheolau benthyca Rust ar amser rhedeg.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... meysydd eraill
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... meysydd eraill
//! }
//!
//! fn main() {
//!     // Creu `Owner` wedi'i gyfrifo â chyfeirnod.
//!     // Sylwch ein bod wedi rhoi vector y `Perchennog` o`Gadget`s y tu mewn i `RefCell` fel y gallwn ei dreiglo trwy gyfeirnod a rennir.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Creu `Gadget`s sy'n perthyn i `gadget_owner`, fel o'r blaen.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Ychwanegwch y `Gadget`s i'w `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` mae benthyg deinamig yn dod i ben yma.
//!     }
//!
//!     // Iterate dros ein `Gadget`s, gan argraffu eu manylion.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` yn `Weak<Gadget>`.
//!         // Gan na all awgrymiadau `Weak` warantu bod y dyraniad yn dal i fodoli, mae angen i ni ffonio `upgrade`, sy'n dychwelyd `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Yn yr achos hwn rydym yn gwybod bod y dyraniad yn dal i fodoli, felly dim ond `unwrap` yr `Option` ydyn ni.
//!         // Mewn rhaglen fwy cymhleth, efallai y bydd angen trin gwallau gosgeiddig arnoch i gael canlyniad `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Ar ddiwedd y swyddogaeth, mae `gadget_owner`, `gadget1`, a `gadget2` yn cael eu dinistrio.
//!     // Erbyn hyn nid oes unrhyw awgrymiadau (`Rc`) cryf i'r teclynnau, felly maen nhw'n cael eu dinistrio.
//!     // Mae hyn yn sero y cyfrif cyfeirnod ar Gadget Man, felly mae'n cael ei ddinistrio hefyd.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Mae hyn yn brawf repr(C) i future yn erbyn ail-archebu maes posibl, a fyddai'n ymyrryd â [into|from]_raw() sydd fel arall yn ddiogel o fathau mewnol trosglwyddadwy.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Pwyntydd cyfrif cyfeirnod un-edau.Mae 'Rc' yn sefyll am 'Cyfeirnod
/// Counted'.
///
/// Gweler yr [module-level documentation](./index.html) am ragor o fanylion.
///
/// Mae dulliau cynhenid `Rc` i gyd yn swyddogaethau cysylltiedig, sy'n golygu bod yn rhaid i chi eu galw fel ee, [`Rc::get_mut(&mut value)`][get_mut] yn lle `value.get_mut()`.
/// Mae hyn yn osgoi gwrthdaro â dulliau o'r math mewnol `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Mae'r anniogelrwydd hwn yn iawn oherwydd er bod y Rc hwn yn fyw rydym yn sicr bod y pwyntydd mewnol yn ddilys.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Yn adeiladu `Rc<T>` newydd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Mae pwyntydd gwan ymhlyg yn eiddo i'r holl awgrymiadau cryf, sy'n sicrhau nad yw'r dinistriwr gwan byth yn rhyddhau'r dyraniad tra bod y dinistriwr cryf yn rhedeg, hyd yn oed os yw'r pwyntydd gwan yn cael ei storio y tu mewn i'r un cryf.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Yn llunio `Rc<T>` newydd gan ddefnyddio cyfeiriad gwan ato'i hun.
    /// Bydd ceisio uwchraddio'r cyfeirnod gwan cyn i'r swyddogaeth hon ddychwelyd yn arwain at werth `None`.
    ///
    /// Fodd bynnag, gellir clonio'r cyfeirnod gwan yn rhydd a'i storio i'w ddefnyddio yn nes ymlaen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... mwy o feysydd
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Lluniwch y mewnol yn nhalaith "uninitialized" gydag un cyfeiriad gwan.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Mae'n bwysig nad ydym yn ildio perchnogaeth o'r pwyntydd gwan, neu fel arall gallai'r cof gael ei ryddhau erbyn i `data_fn` ddychwelyd.
        // Pe byddem wir eisiau pasio perchnogaeth, gallem greu pwyntydd gwan ychwanegol inni ein hunain, ond byddai hyn yn arwain at ddiweddariadau ychwanegol i'r cyfrif cyfeiriadau gwan na fyddai efallai'n angenrheidiol fel arall.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Dylai cyfeiriadau cryf gyda'i gilydd fod yn berchen ar gyfeirnod gwan a rennir, felly peidiwch â rhedeg y dinistriwr ar gyfer ein hen gyfeirnod gwan.
        //
        mem::forget(weak);
        strong
    }

    /// Yn llunio `Rc` newydd gyda chynnwys heb ei ddynodi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yn llunio `Rc` newydd gyda chynnwys heb ei ddynodi, gyda'r cof yn cael ei lenwi â beit `0`.
    ///
    ///
    /// Gweler [`MaybeUninit::zeroed`][zeroed] am enghreifftiau o ddefnydd cywir ac anghywir o'r dull hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yn llunio `Rc<T>` newydd, gan ddychwelyd gwall os yw'r dyraniad yn methu
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Mae pwyntydd gwan ymhlyg yn eiddo i'r holl awgrymiadau cryf, sy'n sicrhau nad yw'r dinistriwr gwan byth yn rhyddhau'r dyraniad tra bod y dinistriwr cryf yn rhedeg, hyd yn oed os yw'r pwyntydd gwan yn cael ei storio y tu mewn i'r un cryf.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Yn llunio `Rc` newydd gyda chynnwys heb ei ddynodi, gan ddychwelyd gwall os yw'r dyraniad yn methu
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Yn llunio `Rc` newydd gyda chynnwys heb ei ddynodi, gyda'r cof yn cael ei lenwi â beit `0`, gan ddychwelyd gwall os yw'r dyraniad yn methu
    ///
    ///
    /// Gweler [`MaybeUninit::zeroed`][zeroed] am enghreifftiau o ddefnydd cywir ac anghywir o'r dull hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Yn adeiladu `Pin<Rc<T>>` newydd.
    /// Os nad yw `T` yn gweithredu `Unpin`, yna bydd `value` yn cael ei binio yn y cof ac ni ellir ei symud.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Yn dychwelyd y gwerth mewnol, os oes gan yr `Rc` un cyfeiriad cryf yn union.
    ///
    /// Fel arall, mae [`Err`] cael ei ddychwelyd gyda'r un `Rc` a basiwyd yn.
    ///
    ///
    /// Bydd hyn yn llwyddo hyd yn oed os oes cyfeiriadau gwan rhagorol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copïwch y gwrthrych a gynhwysir

                // Nodwch i Weaks na ellir eu hyrwyddo trwy ostwng y cyfrif cryf, ac yna tynnwch y pwyntydd "strong weak" ymhlyg tra hefyd yn trin rhesymeg gollwng trwy grefftio Gwan ffug yn unig.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Yn llunio sleisen newydd wedi'i chyfrif â chyfeirnod gyda chynnwys anghyfarwydd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Yn llunio sleisen newydd wedi'i chyfrif â chyfeirnod gyda chynnwys anghyfarwydd, gyda'r cof yn cael ei lenwi â beit `0`.
    ///
    ///
    /// Gweler [`MaybeUninit::zeroed`][zeroed] am enghreifftiau o ddefnydd cywir ac anghywir o'r dull hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Trosi i `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Yn yr un modd â [`MaybeUninit::assume_init`], mater i'r galwr yw gwarantu bod y gwerth mewnol mewn cyflwr cychwynnol.
    ///
    /// Mae galw hyn pan nad yw'r cynnwys wedi'i gychwyn yn llawn eto yn achosi ymddygiad heb ei ddiffinio ar unwaith.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Trosi i `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Yn yr un modd â [`MaybeUninit::assume_init`], mater i'r galwr yw gwarantu bod y gwerth mewnol mewn cyflwr cychwynnol.
    ///
    /// Mae galw hyn pan nad yw'r cynnwys wedi'i gychwyn yn llawn eto yn achosi ymddygiad heb ei ddiffinio ar unwaith.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Yn defnyddio'r `Rc`, gan ddychwelyd y pwyntydd wedi'i lapio.
    ///
    /// Er mwyn osgoi gollyngiad cof rhaid trosi'r pwyntydd yn ôl i `Rc` gan ddefnyddio [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Mae'n darparu pwyntydd amrwd i'r data.
    ///
    /// Nid yw'r cyfrifiadau yn cael eu heffeithio mewn unrhyw ffordd ac nid yw'r `Rc` cael ei fwyta.
    /// Pwyntydd yn ddilys cyhyd mae cyfrifiadau cryf yn y `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // DIOGELWCH: Ni all hyn fynd trwy Deref::deref neu Rc::inner oherwydd
        // mae hyn yn ofynnol i gadw tarddiad raw/mut fel bod ee
        // `get_mut` yn gallu ysgrifennu trwy'r pwyntydd ar ôl i'r Rc gael ei adfer trwy `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Yn adeiladu `Rc<T>` o bwyntydd amrwd.
    ///
    /// Rhaid bod y pwyntydd amrwd wedi'i ddychwelyd o'r blaen trwy alwad i [`Rc<U>::into_raw`][into_raw] lle mae'n rhaid i `U` fod â'r un maint ac aliniad â `T`.
    /// Mae hyn yn ddibwys yn wir os yw `U` yn `T`.
    /// Sylwch, os nad yw `U` yn `T` ond bod ganddo'r un maint ac aliniad, mae hyn yn y bôn fel cyfeiriadau trawsrywiol o wahanol fathau.
    /// Gweler [`mem::transmute`][transmute] i gael mwy o wybodaeth am ba gyfyngiadau sy'n berthnasol yn yr achos hwn.
    ///
    /// Rhaid i ddefnyddiwr `from_raw` sicrhau bod gwerth penodol o `T` yn cael ei ollwng unwaith yn unig.
    ///
    /// Mae'r swyddogaeth hon yn anniogel oherwydd gall defnydd amhriodol arwain at anniogelrwydd cof, hyd yn oed os na gyrchir at yr `Rc<T>` a ddychwelwyd byth.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Trosi yn ôl i `Rc` i atal gollyngiadau.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Byddai galwadau pellach i `Rc::from_raw(x_ptr)` yn anniogel o ran cof.
    /// }
    ///
    /// // Rhyddhawyd y cof pan aeth `x` allan o'i gwmpas uchod, felly mae `x_ptr` bellach yn hongian!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Gwrthdroi'r gwrthbwyso i ddod o hyd i'r RcBox gwreiddiol.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Yn creu pwyntydd [`Weak`] newydd i'r dyraniad hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Sicrhewch nad ydym yn creu Gwan hongian
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Cael nifer yr awgrymiadau [`Weak`] i'r dyraniad hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Cael nifer yr awgrymiadau (`Rc`) cryf i'r dyraniad hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Yn dychwelyd `true` os nad oes unrhyw awgrymiadau `Rc` neu [`Weak`] eraill i'r dyraniad hwn.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Dychwelyd cyfeiriad mutable i mewn i'r `Rc` a roddir, os nad oes unrhyw `Rc` neu [`Weak`] arwyddion eraill i'r un dyraniad.
    ///
    ///
    /// Yn dychwelyd [`None`] fel arall, oherwydd nid yw'n ddiogel treiglo gwerth a rennir.
    ///
    /// Gweler hefyd [`make_mut`][make_mut], a fydd yn [`clone`][clone] y gwerth mewnol pan fydd awgrymiadau eraill.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Yn dychwelyd cyfeiriad symudol i'r `Rc` a roddir, heb unrhyw wiriad.
    ///
    /// Gweler hefyd [`get_mut`], sy'n ddiogel ac yn gwneud gwiriadau priodol.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ni ddylai unrhyw awgrymiadau eraill `Rc` neu [`Weak`] i'r un dyraniad yn cael ei dereferenced drwy gydol y benthyg a ddychwelwyd.
    ///
    /// Mae hyn yn wir yn wir os nad oes unrhyw awgrymiadau o'r fath yn bodoli, er enghraifft yn syth ar ôl `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Rydym yn ofalus i *beidio* creu cyfeirnod sy'n cwmpasu'r meysydd "count", gan y byddai hyn yn gwrthdaro â mynediad i'r cyfrif cyfeirnod (ee.
        // gan `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Yn dychwelyd `true` os yw'r ddau `Rc 'yn pwyntio at yr un dyraniad (mewn gwythïen debyg i [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Yn gwneud cyfeiriad symudol i'r `Rc` a roddir.
    ///
    /// Os oes awgrymiadau `Rc` eraill i'r un dyraniad, yna bydd `make_mut` yn [`clone`] y gwerth mewnol i ddyraniad newydd i sicrhau perchnogaeth unigryw.
    /// Cyfeirir at hyn hefyd fel clôn-ar-ysgrifennu.
    ///
    /// Os nad oes unrhyw awgrymiadau `Rc` eraill i'r dyraniad hwn, yna bydd awgrymiadau [`Weak`] i'r dyraniad hwn yn cael eu datgysylltu.
    ///
    /// Gweler hefyd [`get_mut`], a fydd yn methu yn hytrach na chlonio.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ddim yn clonio unrhyw beth
    /// let mut other_data = Rc::clone(&data);    // Ddim yn clonio data mewnol
    /// *Rc::make_mut(&mut data) += 1;        // Clonau data mewnol
    /// *Rc::make_mut(&mut data) += 1;        // Ddim yn clonio unrhyw beth
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ddim yn clonio unrhyw beth
    ///
    /// // Nawr mae `data` a `other_data` yn pwyntio at wahanol ddyraniadau.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] bydd awgrymiadau yn cael eu datgysylltu:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta clonio y data, mae yna eraill RCS.
            // Rhag-ddyrannu'r cof i ganiatáu ysgrifennu'r gwerth wedi'i glonio yn uniongyrchol.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Yn gallu dwyn y data yn unig, y cyfan sydd ar ôl yw Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Tynnwch y cyfeirnod cryf-wan ymhlyg (nid oes angen crefft Gwan ffug yma-rydyn ni'n gwybod y gall Gwendidau eraill lanhau i ni)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Mae'r anniogelrwydd hwn yn iawn oherwydd rydym yn sicr mai'r pwyntydd a ddychwelir yw'r *unig* pwyntydd a fydd byth yn cael ei ddychwelyd i T.
        // Gwarantir y bydd ein cyfrif cyfeirnod yn 1 ar y pwynt hwn, ac roeddem yn mynnu bod yr `Rc<T>` ei hun yn `mut`, felly rydym yn dychwelyd yr unig gyfeiriad posibl at y dyraniad.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ceisiwch israddio'r `Rc<dyn Any>` i fath concrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Yn dyrannu `RcBox<T>` gyda digon o le ar gyfer gwerth mewnol nad yw'n sicr o fod lle mae'r cynllun wedi'i ddarparu.
    ///
    /// Yr enw ar y swyddogaeth `mem_to_rcbox` yn gyda'r pwyntydd data a rhaid iddo ddychwelyd yn ôl-pointer (a allai fod yn braster) ar gyfer y `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Cyfrifwch gosodiad gan ddefnyddio'r cynllun gwerth a roddir.
        // Yn flaenorol, cyfrifwyd y cynllun ar yr ymadrodd `&*(ptr as* const RcBox<T>)`, ond roedd hyn yn creu cyfeiriad wedi'i gamlinio (gweler #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Yn dyrannu `RcBox<T>` gyda digon o le ar gyfer gwerth mewnol a allai fod yn anenwog lle mae'r cynllun wedi'i ddarparu, gan ddychwelyd gwall os yw'r dyraniad yn methu.
    ///
    ///
    /// Yr enw ar y swyddogaeth `mem_to_rcbox` yn gyda'r pwyntydd data a rhaid iddo ddychwelyd yn ôl-pointer (a allai fod yn braster) ar gyfer y `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Cyfrifwch gosodiad gan ddefnyddio'r cynllun gwerth a roddir.
        // Yn flaenorol, cyfrifwyd y cynllun ar yr ymadrodd `&*(ptr as* const RcBox<T>)`, ond roedd hyn yn creu cyfeiriad wedi'i gamlinio (gweler #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Dyrannu ar gyfer y cynllun.
        let ptr = allocate(layout)?;

        // Cychwyn y RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Yn dyrannu `RcBox<T>` gyda digon o le ar gyfer gwerth mewnol heb ei feintio
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Dyrannu ar gyfer yr `RcBox<T>` gan ddefnyddio'r gwerth a roddir.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copïwch werth fel beit
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Rhyddhewch y dyraniad heb ollwng ei gynnwys
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Yn dyrannu `RcBox<[T]>` gyda'r hyd penodol.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copïwch elfennau o'r sleisen i Rc <\[T\]> sydd newydd ei dyrannu
    ///
    /// Yn anniogel oherwydd bod yn rhaid i'r galwr naill ai gymryd perchnogaeth neu rwymo `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Yn llunio `Rc<[T]>` o ailadroddwr y gwyddys ei fod o faint penodol.
    ///
    /// Nid yw ymddygiad wedi'i ddiffinio pe bai'r maint yn anghywir.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Gwarchod Panic wrth glonio elfennau T.
        // Os bydd panic, bydd elfennau sydd wedi'u hysgrifennu i'r RcBox newydd yn cael eu gollwng, yna bydd y cof yn cael ei ryddhau.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pwyntydd i'r elfen gyntaf
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // I gyd yn glir.Anghofiwch y gard fel nad yw'n rhyddhau'r RcBox newydd.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Arbenigedd trait a ddefnyddir ar gyfer `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Yn gollwng yr `Rc`.
    ///
    /// Bydd hyn yn lleihau'r cyfrif cyfeirio cryf.
    /// Os yw'r cyfrif cyfeirnod cryf yn cyrraedd sero yna'r unig gyfeiriadau eraill (os oes rhai) yw [`Weak`], felly rydyn ni'n `drop` y gwerth mewnol.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Nid yw'n argraffu unrhyw beth
    /// drop(foo2);   // Printiau "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // dinistrio'r gwrthrych a gynhwysir
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // cael gwared ar y pwyntydd "strong weak" ymhlyg yn awr ein bod wedi dinistrio y cynnwys.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Yn gwneud clôn o'r pwyntydd `Rc`.
    ///
    /// Mae hyn yn creu pwyntydd arall i'r un dyraniad, gan gynyddu'r cyfrif cyfeirio cryf.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Yn creu `Rc<T>` newydd, gyda'r gwerth `Default` ar gyfer `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Darnia i ganiatáu arbenigo ar `Eq` er bod gan `Eq` ddull.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Rydym yn gwneud yr arbenigedd hwn yma, ac nid fel optimeiddiad mwy cyffredinol ar `&T`, oherwydd byddai fel arall yn ychwanegu cost at bob gwiriad cydraddoldeb ar gyfeiriadau.
/// Rydym yn cymryd yn ganiataol bod `Rc`s yn cael eu defnyddio i storio gwerthoedd mawr, sy'n araf i'w clonio, ond hefyd yn drwm i wirio am gydraddoldeb, gan beri i'r gost hon dalu ar ei ganfed yn haws.
///
/// Mae hefyd yn fwy tebygol o gael dau glon `Rc`, sy'n pwyntio i'r un gwerth, na dau `&T`s.
///
/// Gallwn ond wneud hyn pan allai `T: Eq` fel `PartialEq` yn fwriadol irreflexive.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Cydraddoldeb i ddau `Rc '.
    ///
    /// Mae dau `Rc` yn hafal os yw eu gwerthoedd mewnol yn gyfartal, hyd yn oed os cânt eu storio mewn dyraniad gwahanol.
    ///
    /// Os yw `T` hefyd yn gweithredu `Eq` (awgrymu atblygedd cydraddoldeb), mae dau `Rc 'sy'n pwyntio at yr un dyraniad bob amser yn gyfartal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Anghydraddoldeb i ddau `Rc`.
    ///
    /// Mae dau `Rc 'yn anghyfartal os yw eu gwerthoedd mewnol yn anghyfartal.
    ///
    /// Os yw `T` hefyd yn gweithredu `Eq` (awgrymu atblygedd cydraddoldeb), nid yw dau `Rc 'sy'n pwyntio at yr un dyraniad byth yn anghyfartal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Cymhariaeth rannol ar gyfer dau `Rc`.
    ///
    /// Cymharir y ddau trwy ffonio `partial_cmp()` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Cymhariaeth llai na dau `Rc`.
    ///
    /// Cymharir y ddau trwy ffonio `<` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Cymhariaeth 'Llai na neu'n hafal i' dau Rc.
    ///
    /// Mae'r ddau yn cael eu cymharu drwy ffonio `<=` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Cymhariaeth fwy na dau `Rc`.
    ///
    /// Cymharir y ddau trwy ffonio `>` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Cymhariaeth 'Mwy na neu'n hafal i' ar gyfer dau `Rc '.
    ///
    /// Cymharir y ddau trwy ffonio `>=` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Cymhariaeth ar gyfer dau `Rc`.
    ///
    /// Cymharir y ddau trwy ffonio `cmp()` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Dyrannwch dafell wedi'i chyfrif wedi'i chyfeirio a'i llenwi trwy glonio eitemau `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Dyrannu tafell llinyn wedi'i chyfrif cyfeirnod a chopïo `v` ynddo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Dyrannu tafell llinyn wedi'i chyfrif cyfeirnod a chopïo `v` ynddo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Symud gwrthrych mewn bocs i ddyraniad newydd, wedi'i gyfrifo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Dyrannwch dafell wedi'i chyfrif cyfeirnod a symud eitemau `v` i mewn iddi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Caniatáu i'r Vec ryddhau ei gof, ond heb ddinistrio ei gynnwys
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Yn cymryd pob elfen yn yr `Iterator` a'i gasglu i mewn i `Rc<[T]>`.
    ///
    /// # Nodweddion perfformiad
    ///
    /// ## Yr achos cyffredinol
    ///
    /// Yn gyffredinol, mae casglu i mewn i `Rc<[T]>` yn cael ei wneud trwy gasglu i mewn i `Vec<T>` yn gyntaf.Hynny yw, wrth ysgrifennu'r canlynol:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// mae hyn yn ymddwyn fel pe baem yn ysgrifennu:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Mae'r set gyntaf o ddyraniadau yn digwydd yma.
    ///     .into(); // Mae ail ddyraniad ar gyfer `Rc<[T]>` yn digwydd yma.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bydd hyn yn dyrannu cymaint o weithiau ag sydd ei angen ar gyfer llunio'r `Vec<T>` ac yna bydd yn dyrannu unwaith ar gyfer troi'r `Vec<T>` yn `Rc<[T]>`.
    ///
    ///
    /// ## Iterators o hyd hysbys
    ///
    /// Pan fydd eich `Iterator` yn gweithredu `TrustedLen` ac mae o union faint, bydd un dyraniad yn cael ei wneud ar gyfer yr `Rc<[T]>`.Er enghraifft:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Dim ond un dyraniad sy'n digwydd yma.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Arbenigedd trait a ddefnyddir ar gyfer casglu i mewn i `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Mae hyn yn wir am ailadroddwr `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // DIOGELWCH: Mae angen i ni sicrhau bod gan yr ailadroddwr yr union hyd ac sydd gennym ni.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Disgyn yn ôl i weithredu arferol.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` yn fersiwn o [`Rc`] sy'n dal cyfeiriad nad yw'n berchen ar y dyraniad a reolir.Gellir cyrchu'r dyraniad trwy ffonio [`upgrade`] ar y pwyntydd `Weak`, sy'n dychwelyd [`Opsiwn`]`<`[`Rc`] `<T>>`.
///
/// Gan nid yw cyfeiriad `Weak` yn cyfrif tuag at berchnogaeth, ni fydd yn atal y gwerth ei storio yn y dyraniad rhag cael ei ollwng, a `Weak` ei hun yn gwneud unrhyw warant ynglŷn â gwerth yn dal i fod yn bresennol.
/// Felly gall ddychwelyd [`None`] pan fydd [`uwchraddio`] d.
/// Sylwch, fodd bynnag, fod cyfeirnod `Weak`*yn* atal y dyraniad ei hun (y storfa gefn) rhag cael ei ddeallocated.
///
/// Mae pwyntydd `Weak` yn ddefnyddiol ar gyfer cadw cyfeiriad dros dro at y dyraniad a reolir gan [`Rc`] heb atal ei werth mewnol rhag cael ei ollwng.
/// Fe'i defnyddir hefyd i atal cyfeiriadau cylchol rhwng awgrymiadau [`Rc`], gan na fyddai cyfeiriadau cydberchnogaeth byth yn caniatáu gollwng naill ai [`Rc`].
/// Er enghraifft, gallai coeden gael awgrymiadau [`Rc`] cryf gan rieni nodau i blant, a `Weak` awgrymiadau gan blant yn ôl i'w rhieni.
///
/// Y ffordd nodweddiadol o gael pwyntydd `Weak` yw ffonio [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Mae hwn yn `NonNull` i ganiatáu optimeiddio maint y math hwn mewn enymau, ond nid yw o reidrwydd yn bwyntydd dilys.
    //
    // `Weak::new` yn gosod hwn i `usize::MAX` fel nad oes angen iddo ddyrannu lle ar y domen.
    // Nid yw hynny'n werth y bydd pwyntydd go iawn byth yn ei gael oherwydd bod gan RcBox aliniad o leiaf 2.
    // Mae hyn yn bosibl dim ond pan fydd `T: Sized`;bythol `T` byth yn hongian.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Yn adeiladu `Weak<T>` newydd, heb ddyrannu unrhyw gof.
    /// Mae galw [`upgrade`] ar y gwerth dychwelyd bob amser yn rhoi [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Math o gynorthwyydd i ganiatáu cyrchu'r cyfrif cyfeiriadau heb wneud unrhyw honiadau am y maes data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Yn dychwelyd pwyntydd amrwd i'r gwrthrych `T` y mae'r `Weak<T>` hwn yn cyfeirio ato.
    ///
    /// Mae'r pwyntydd yn ddilys dim ond os oes rhai cyfeiriadau cryf.
    /// Gall y pwyntydd fod yn hongian, heb ei lofnodi neu hyd yn oed [`null`] fel arall.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Mae'r ddau bwynt i'r un gwrthrych
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Mae'r cryf yma yn ei gadw'n fyw, felly gallwn ddal i gyrchu'r gwrthrych.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ond dim mwy.
    /// // Gallwn wneud weak.as_ptr(), ond byddai cyrchu'r pwyntydd yn arwain at ymddygiad heb ei ddiffinio.
    /// // assert_eq ("helo", anniogel {&*weak.as_ptr() })!;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Os yw'r pwyntydd yn hongian, byddwn yn dychwelyd y sentinel yn uniongyrchol.
            // Ni all hwn fod yn gyfeiriad llwyth tâl dilys, gan fod y llwyth tâl o leiaf mor gyson â RcBox (usize).
            ptr as *const T
        } else {
            // DIOGELWCH: os yw is_dangling yn dychwelyd yn ffug, yna mae'r pwyntydd yn ddadreferencable.
            // Efallai y bydd y llwyth tâl yn cael ei ollwng ar y pwynt hwn, ac mae'n rhaid i ni gynnal tarddiad, felly defnyddiwch drin pwyntydd amrwd.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Yn bwyta'r `Weak<T>` a'i droi'n bwyntydd amrwd.
    ///
    /// Mae hyn yn trosi'r pwyntydd gwan yn bwyntydd amrwd, gan ddal i gadw perchnogaeth un cyfeirnod gwan (nid yw'r cyfrifiad gwan yn addasu'r cyfrif gwan).
    /// Gellir ei droi yn ôl i'r `Weak<T>` gyda [`from_raw`].
    ///
    /// Mae'r un cyfyngiadau o ran cyrchu targed y pwyntydd â [`as_ptr`] yn berthnasol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Yn trosi pwyntydd amrwd a grëwyd yn flaenorol gan [`into_raw`] yn ôl i `Weak<T>`.
    ///
    /// Gellir defnyddio hwn i gael cyfeirnod cryf yn ddiogel (trwy ffonio [`upgrade`] yn ddiweddarach) neu i ddeallocateiddio'r cyfrif gwan trwy ollwng yr `Weak<T>`.
    ///
    /// Mae'n cymryd perchnogaeth o un cyfeiriad gwan (ac eithrio'r awgrymiadau a grëwyd gan [`new`], gan nad yw'r rhain yn berchen ar unrhyw beth; mae'r dull yn dal i weithio arnynt).
    ///
    /// # Safety
    ///
    /// Rhaid bod y pwyntydd wedi tarddu o'r [`into_raw`] a rhaid iddo fod yn berchen ar ei gyfeirnod gwan posibl o hyd.
    ///
    /// Caniateir i'r cyfrif cryf fod yn 0 ar adeg galw hwn.
    /// Serch hynny, mae hyn yn cymryd perchnogaeth o un cyfeirnod gwan a gynrychiolir ar hyn o bryd fel pwyntydd amrwd (nid yw'r cyfrifiad gwan yn addasu'r cyfrif gwan) ac felly mae'n rhaid ei baru â galwad flaenorol i [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Gostwng y cyfrif gwan olaf.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Gweler Weak::as_ptr i gael cyd-destun ar sut mae'r pwyntydd mewnbwn yn deillio.

        let ptr = if is_dangling(ptr as *mut T) {
            // Mae hwn yn Wan hongian.
            ptr as *mut RcBox<T>
        } else {
            // Fel arall, rydym yn sicr y daeth y pwyntydd o Weak nondangling.
            // DIOGELWCH: mae data_offset yn ddiogel i'w alw, gan fod ptr yn cyfeirio at T. go iawn (a allai gael ei ollwng).
            let offset = unsafe { data_offset(ptr) };
            // Felly, rydym yn gwrthdroi'r gwrthbwyso i gael y RcBox cyfan.
            // DIOGELWCH: tarddodd y pwyntydd o Wan, felly mae'r gwrthbwyso hwn yn ddiogel.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // DIOGELWCH: rydym bellach wedi adfer y pwyntydd Gwan gwreiddiol, felly gallwn greu'r Gwan.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Ymdrechion i uwchraddio'r pwyntydd `Weak` i [`Rc`], gan ohirio gollwng y gwerth mewnol os yw'n llwyddiannus.
    ///
    ///
    /// Yn dychwelyd [`None`] os yw'r gwerth mewnol wedi'i ollwng ers hynny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Dinistrio pob awgrym cryf.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Cael nifer yr awgrymiadau (`Rc`) cryf sy'n pwyntio at y dyraniad hwn.
    ///
    /// Os crëwyd `self` gan ddefnyddio [`Weak::new`], bydd hyn yn dychwelyd 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Cael nifer yr awgrymiadau `Weak` sy'n pwyntio at y dyraniad hwn.
    ///
    /// Os nad oes unrhyw awgrymiadau cryf ar ôl, bydd hyn yn dychwelyd yn sero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // tynnwch y ptr gwan ymhlyg
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Yn dychwelyd `None` pan fydd y pwyntydd yn hongian ac nad oes `RcBox` wedi'i ddyrannu, (hy, pan gafodd yr `Weak` hwn ei greu gan `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Rydym yn ofalus i *beidio* creu cyfeirnod sy'n cwmpasu'r maes "data", oherwydd gall y maes gael ei dreiglo ar yr un pryd (er enghraifft, os caiff yr `Rc` olaf ei ollwng, bydd y maes data yn cael ei ollwng yn ei le).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Yn dychwelyd `true` os yw'r ddau `Gwan 'yn pwyntio at yr un dyraniad (tebyg i [`ptr::eq`]), neu os nad yw'r ddau yn pwyntio at unrhyw ddyraniad (oherwydd iddynt gael eu creu gyda `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Gan fod hyn yn cymharu awgrymiadau, mae'n golygu y bydd `Weak::new()` yn hafal i'w gilydd, er nad ydyn nhw'n pwyntio at unrhyw ddyraniad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Cymharu `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Yn gollwng y pwyntydd `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nid yw'n argraffu unrhyw beth
    /// drop(foo);        // Printiau "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // mae'r cyfrif gwan yn dechrau ar 1, a dim ond os yw'r holl awgrymiadau cryf wedi diflannu y bydd yn mynd i ddim.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gwneud clôn o'r pwyntydd `Weak` bod pwyntiau i'r un dyraniad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Yn adeiladu `Weak<T>` newydd, dyrannu cof ar gyfer `T` heb ymgychwyn hynny.
    /// Mae galw [`upgrade`] ar y gwerth dychwelyd bob amser yn rhoi [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Rydym checked_add yma i ddelio â mem::forget yn ddiogel.Yn benodol
// os ydych chi'n mem::forget Rcs (neu Weaks), gall y ail-gyfrif orlifo, ac yna gallwch chi ryddhau'r dyraniad tra bod Rcs (neu Weaks) sy'n weddill yn bodoli.
//
// Rydym yn erthylu oherwydd bod hon yn senario mor ddirywiol fel nad ydym yn poeni am yr hyn sy'n digwydd-ni ddylai unrhyw raglen go iawn brofi hyn byth.
//
// Dylai hyn fod â gorbenion dibwys gan nad oes angen i chi glonio'r rhain lawer yn Rust diolch i berchnogaeth a semanteg symud.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Rydym am erthylu ar orlif yn lle gollwng y gwerth.
        // Ni fydd y cyfrif cyfeirnod byth yn sero pan elwir hyn;
        // serch hynny, rydym yn mewnosod erthyliad yma i awgrymu LLVM mewn optimeiddiad a gollwyd fel arall.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Rydym am erthylu ar orlif yn lle gollwng y gwerth.
        // Ni fydd y cyfrif cyfeirnod byth yn sero pan elwir hyn;
        // serch hynny, rydym yn mewnosod erthyliad yma i awgrymu LLVM mewn optimeiddiad a gollwyd fel arall.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Sicrhewch y gwrthbwyso o fewn `RcBox` ar gyfer y llwyth tâl y tu ôl i bwyntydd.
///
/// # Safety
///
/// Rhaid i'r pwyntydd bwyntio at (a bod â metadata dilys ar gyfer) enghraifft T a oedd yn ddilys o'r blaen, ond caniateir i'r T gael ei ollwng.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alinio'r gwerth heb ei fesur i ddiwedd y RcBox.
    // Gan fod RcBox yw repr(C), bydd bob amser yn y maes olaf yn y cof.
    // DIOGELWCH: gan mai'r unig fathau heb eu maint sy'n bosibl yw tafelli, gwrthrychau trait,
    // a mathau extern, y gofyniad diogelwch mewnbwn yn ddigon ar hyn o bryd i fodloni gofynion align_of_val_raw;mae hyn yn manylu ar waith yr iaith nad ydynt efallai yn dibynnu ar y tu allan i std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}