//! Cyfleustodau ar gyfer fformatio ac argraffu `String`s.
//!
//! Mae'r modiwl hwn yn cynnwys y gefnogaeth rhedeg amser ar gyfer yr estyniad cystrawen [`format!`].
//! Mae'r macro yn cael ei weithredu yn y compiler i allyrru galwadau i'r modiwl hwn er mwyn dadleuon fformat pan mae'n gweithredu mewn llinynnau.
//!
//! # Usage
//!
//! Bwriedir i'r macro [`format!`] fod yn gyfarwydd i'r rhai sy'n dod o swyddogaethau `printf`/`fprintf` C neu swyddogaeth `str.format` Python.
//!
//! Dyma rai enghreifftiau o'r estyniad [`format!`]:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" gyda seroau blaenllaw
//! ```
//!
//! O'r rhain, gallwch weld bod y ddadl gyntaf yn llinyn fformat.Mae'n ofynnol i'r casglwr fod hwn yn llythrennol llinynnol;ni all fod yn newidyn a basiwyd i mewn (er mwyn gwirio dilysrwydd).
//! Yna bydd y casglwr yn dosrannu'r llinyn fformat ac yn penderfynu a yw'r rhestr o ddadleuon a ddarperir yn addas i'w throsglwyddo i'r llinyn fformat hwn.
//!
//! I drosi gwerth sengl i linyn, defnyddiwch y dull [`to_string`].Bydd hyn yn defnyddio'r fformatio [`Display`] trait.
//!
//! ## Paramedrau lleoliadol
//!
//! Caniateir i bob dadl fformatio nodi pa ddadl werth y mae'n cyfeirio ati, ac os caiff ei hepgor cymerir ei bod yn "the next argument".
//! Er enghraifft, byddai'r llinyn fformat `{} {} {}` yn cymryd tri pharamedr, a byddent yn cael eu fformatio yn yr un drefn ag a roddir iddynt.
//! Byddai'r llinyn fformat `{2} {1} {0}`, fodd bynnag, yn fformatio dadleuon yn ôl trefn.
//!
//! Gall pethau fynd ychydig yn anodd unwaith y byddwch chi'n dechrau cymysgu'r ddau fath o fanylebau lleoliadol.Gellir meddwl am y manylebwr "next argument" fel ailadroddwr dros y ddadl.
//! Bob tro y rhagnodwr "next argument" yn cael ei weld, mae'r datblygiadau iterator.Mae hyn yn arwain at ymddygiad fel hyn:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Nid yw'r ailadroddwr mewnol dros y ddadl wedi'i ddatblygu erbyn i'r `{}` cyntaf gael ei weld, felly mae'n argraffu'r ddadl gyntaf.Yna ar ôl cyrraedd yr ail `{}`, mae'r ailadroddwr wedi symud ymlaen at yr ail ddadl.
//! Yn y bôn, nid yw paramedrau sy'n enwi eu dadl yn benodol yn effeithio ar baramedrau nad ydynt yn enwi dadl o ran manylebau lleoliadol.
//!
//! Mae angen llinyn fformat i ddefnyddio ei holl ddadleuon, fel arall mae'n wall amser llunio.Gallwch gyfeirio at yr un ddadl fwy nag unwaith yn y llinyn fformat.
//!
//! ## Paramedrau a enwir
//!
//! Nid oes gan Rust ei hun gyfwerth â pharamedrau a enwir i swyddogaeth Python, ond mae'r macro [`format!`] yn estyniad cystrawen sy'n caniatáu iddo drosoli paramedrau a enwir.
//! Rhestrir paramedrau a enwir ar ddiwedd y rhestr dadleuon ac mae ganddynt y gystrawen:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Er enghraifft, mae'r ymadroddion [`format!`] canlynol i gyd yn defnyddio dadl a enwir:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nid yw'n ddilys rhoi paramedrau lleoliadol (y rhai heb enwau) ar ôl dadleuon sydd ag enwau.Yn yr un modd â pharamedrau lleoliadol, nid yw'n ddilys darparu paramedrau a enwir nad ydynt yn cael eu defnyddio gan y llinyn fformat.
//!
//! # fformatio Paramedrau
//!
//! Gellir trawsnewid pob dadl sy'n cael ei fformatio gan nifer o baramedrau fformatio (sy'n cyfateb i `format_spec` yn [the syntax](#syntax)). Mae'r paramedrau hyn yn effeithio ar gynrychiolaeth llinyn yr hyn sy'n cael ei fformatio.
//!
//! ## Width
//!
//! ```
//! // Mae pob un o'r rhain yn argraffu "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Mae hwn yn baramedr ar gyfer yr "minimum width" y dylai'r fformat ei ddefnyddio.
//! Os nad yw llinyn y gwerth yn llenwi cymaint o nodau, yna bydd y padin a bennir gan fill/alignment yn cael ei ddefnyddio i gymryd y lle gofynnol (gweler isod).
//!
//! Gellir darparu'r gwerth ar gyfer y lled hefyd fel [`usize`] yn y rhestr o baramedrau trwy ychwanegu ôl-ddodiad `$`, sy'n nodi bod yr ail ddadl yn [`usize`] sy'n nodi'r lled.
//!
//! Nid yw cyfeirio at ddadl gyda'r gystrawen doler yn effeithio ar y cownter "next argument", felly fel arfer mae'n syniad da cyfeirio at ddadleuon yn ôl safle, neu ddefnyddio dadleuon a enwir.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Darperir y cymeriad llenwi ac aliniad dewisol fel arfer ar y cyd â'r paramedr [`width`](#width).Rhaid ei ddiffinio cyn `width`, reit ar ôl yr `:`.
//! Mae hyn yn dangos, os yw'r gwerth sy'n cael ei fformatio yn llai na `width`, bydd rhai nodau ychwanegol yn cael eu hargraffu o'i gwmpas.
//! Mae llenwad yn yr amrywiadau canlynol ar gyfer gwahanol aliniadau:
//!
//! * `[fill]<` - mae'r ddadl wedi'i halinio ar y chwith yng ngholofnau `width`
//! * `[fill]^` - mae'r ddadl wedi'i halinio yng nghanol colofnau `width`
//! * `[fill]>` - mae'r ddadl wedi'i alinio'n iawn yng ngholofnau `width`
//!
//! Mae'r [fill/alignment](#fillalignment) diofyn ar gyfer rhifau nad ydynt yn rhifau yn ofod ac wedi'i alinio i'r chwith.Mae'r rhagosodiad ar gyfer fformatwyr rhifol hefyd yn gymeriad gofod ond gydag aliniad cywir.
//! Os yw'r faner `0` (gweler isod) wedi'i nodi ar gyfer rhifau, yna'r cymeriad llenwi ymhlyg yw `0`.
//!
//! Sylwch efallai na fydd aliniad yn cael ei weithredu gan rai mathau.Yn benodol, ni chaiff ei weithredu'n gyffredinol ar gyfer yr `Debug` trait.
//! Ffordd dda o sicrhau bod padin yn cael ei gymhwyso yw fformatio'ch mewnbwn, yna padiwch y llinyn canlyniadol hwn i gael eich allbwn:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Helo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Mae'r rhain i gyd yn fflagiau sy'n newid ymddygiad y fformatiwr.
//!
//! * `+` - Mae hyn wedi'i fwriadu ar gyfer mathau rhifol ac mae'n nodi y dylid argraffu'r arwydd bob amser.Nid yw arwyddion cadarnhaol byth yn cael eu hargraffu yn ddiofyn, a dim ond yn ddiofyn y caiff yr arwydd negyddol ei argraffu ar gyfer yr `Signed` trait.
//! Mae'r faner hon yn nodi y dylid argraffu'r arwydd cywir (`+` neu `-`) bob amser.
//! * `-` - Heb ei ddefnyddio ar hyn o bryd
//! * `#` - Mae'r faner hon yn nodi y dylid defnyddio'r ffurf argraffu "alternate".Y ffurfiau amgen yw:
//!     * `#?` - 'n bert-argraffu fformatio [`Debug`]
//!     * `#x` - yn rhagflaenu'r ddadl gyda `0x`
//!     * `#X` - yn rhagflaenu'r ddadl gyda `0x`
//!     * `#b` - yn rhagflaenu'r ddadl gyda `0b`
//!     * `#o` - rhagflaenu'r ddadl gyda `0o`
//! * `0` - Defnyddir hwn i nodi ar gyfer fformatau cyfanrif y dylai'r padin i `width` gael ei wneud gyda chymeriad `0` yn ogystal â bod yn ymwybodol o arwyddion.
//! Byddai fformat fel `{:08}` yn cynhyrchu `00000001` ar gyfer y cyfanrif `1`, tra byddai'r un fformat yn esgor ar `-0000001` ar gyfer y cyfanrif `-1`.
//! Sylwch fod gan y fersiwn negyddol un yn llai o sero na'r fersiwn gadarnhaol.
//!         Sylwch fod sero padin bob amser yn cael ei osod ar ôl yr arwydd (os oes un) a chyn y digidau.Pan gaiff ei ddefnyddio ynghyd â'r faner `#`, mae rheol debyg yn berthnasol: mewnosodir sero padin ar ôl y rhagddodiad ond cyn y digidau.
//!         Mae'r rhagddodiad wedi'i gynnwys yng nghyfanswm y lled.
//!
//! ## Precision
//!
//! Ar gyfer mathau nad ydynt yn rhifol, gellir ystyried hyn yn "maximum width".
//! Os yw'r llinyn sy'n deillio o hyn yn hirach na'r lled hwn, yna caiff ei chwtogi i lawr i'r nifer fawr o gymeriadau a bod y gwerth cwtog yn cael ei ollwng gyda `fill`, `alignment` a `width` priodol os yw'r paramedrau hynny wedi'u gosod.
//!
//! Ar gyfer mathau annatod, anwybyddir hyn.
//!
//! Ar gyfer mathau o bwyntiau arnofio, mae hyn yn nodi faint o ddigidau ar ôl y pwynt degol y dylid eu hargraffu.
//!
//! Mae tair ffordd bosibl i nodi'r `precision` a ddymunir:
//!
//! 1. Cyfanrif `.N`:
//!
//!    y cyfanrif `N` ei hun yw'r manwl gywirdeb.
//!
//! 2. Cyfanrif neu enw wedi'i ddilyn gan arwydd doler `.N$`:
//!
//!    defnyddio fformat *dadl*`N` (y mae'n rhaid iddo fod yn `usize`) fel y manwl gywirdeb.
//!
//! 3. Seren `.*`:
//!
//!    `.*` yn golygu bod yr `{...}` hwn yn gysylltiedig â mewnbynnau fformat *dau* yn hytrach nag un: mae'r mewnbwn cyntaf yn dal y manwl gywirdeb `usize`, ac mae'r ail yn dal y gwerth i'w argraffu.
//!    Sylwch, yn yr achos hwn, os yw un yn defnyddio'r llinyn fformat `{<arg>:<spec>.*}`, yna mae'r rhan `<arg>` yn cyfeirio at y* gwerth * i'w argraffu, a rhaid i'r `precision` ddod yn y mewnbwn cyn `<arg>`.
//!
//! Er enghraifft, mae'r galwadau canlynol i gyd yn argraffu'r un peth `Hello x is 0.01000`:
//!
//! ```
//! // Helo {arg 0 ("x")} yw {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Helo {arg 1 ("x")} yw {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Helo {arg 0 ("x")} yw {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Helo {next arg ("x")} yw {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Helo {next arg ("x")} yw {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Helo {next arg ("x")} yw {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Tra bod y rhain:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! argraffu tri pheth gwahanol iawn:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Mewn rhai ieithoedd rhaglennu, mae ymddygiad swyddogaethau fformatio llinyn yn dibynnu ar osodiad locale y system weithredu.
//! Nid oes gan y swyddogaethau fformat a ddarperir gan lyfrgell safonol Rust unrhyw gysyniad o locale a byddant yn cynhyrchu'r un canlyniadau ar bob system waeth beth yw ffurfweddiad y defnyddiwr.
//!
//! Er enghraifft, bydd y cod canlynol bob amser yn argraffu `1.5` hyd yn oed os yw locale y system yn defnyddio gwahanydd degol heblaw dot.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Gellir cynnwys y cymeriadau llythrennol `{` a `}` mewn llinyn trwy eu rhagflaenu â'r un cymeriad.Er enghraifft, cymeriad `{` yn dianc gyda `{{` a chymeriad `}` yn dianc gyda `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! I grynhoi, yma gallwch ddod o hyd i ramadeg llawn llinynnau fformat.
//! Daw'r gystrawen ar gyfer yr iaith fformatio a ddefnyddir o ieithoedd eraill, felly ni ddylai fod yn rhy estron.Mae dadleuon wedi'u fformatio â chystrawen tebyg i Python, sy'n golygu bod dadleuon wedi'u hamgylchynu gan `{}` yn lle'r `%` tebyg i C.
//! Y gramadeg go iawn ar gyfer y gystrawen fformatio yw:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Yn y gramadeg uchod, ni chaiff `text` gynnwys unrhyw nodau `'{'` na `'}'`.
//!
//! # Fformatio traits
//!
//! Wrth ofyn am i ddadl gael ei fformatio â math penodol, rydych chi mewn gwirionedd yn gofyn i ddadl briodoli i trait penodol.
//! Mae hyn yn caniatáu fformatio sawl math gwirioneddol trwy `{:x}` (fel [`i8`] yn ogystal â [`isize`]).Y mapio cyfredol o fathau i traits yw:
//!
//! * *dim byd* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] gyda chyfanrifau hecsadegol llythrennau bach
//! * `X?` ⇒ [`Debug`] gyda chyfanrifau hecsadegol achos uchaf
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Beth mae hyn yn ei olygu yw y gellir fformatio unrhyw fath o ddadl sy'n gweithredu'r [`fmt::Binary`][`Binary`] trait gydag `{:b}`.Darperir gweithrediadau ar gyfer y traits hyn ar gyfer nifer o fathau cyntefig gan y llyfrgell safonol hefyd.
//!
//! Os na nodir unrhyw fformat (fel yn `{}` neu `{:6}`), yna'r fformat trait a ddefnyddir yw'r [`Display`] trait.
//!
//! Wrth weithredu fformat trait ar gyfer eich math eich hun, bydd yn rhaid i chi weithredu dull o'r llofnod:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ein math arferiad
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Bydd eich math yn cael ei basio fel is-gyfeirnod `self`, ac yna dylai'r swyddogaeth allyrru allbwn i'r llif `f.buf`.Mae i fyny i bob fformat gweithredu trait i lynu'n gywir wrth y paramedrau fformatio y gofynnwyd amdanynt.
//! Rhestrir gwerthoedd y paramedrau hyn ym meysydd y strwythur [`Formatter`].Er mwyn helpu gyda hyn, mae'r strwythur [`Formatter`] hefyd yn darparu rhai dulliau cynorthwyydd.
//!
//! Yn ogystal, gwerth dychwelyd y swyddogaeth hon yw [`fmt::Result`] sy'n alias math o [`Canlyniad`]`<(),`[`std: : fmt::Gwall`] `>`.
//! Dylai fformatio gweithrediadau sicrhau eu bod yn lluosogi gwallau o'r [`Formatter`] (ee, wrth ffonio [`write!`]).
//! Fodd bynnag, ni ddylent fyth ddychwelyd gwallau yn ysbeidiol.
//! Hynny yw, mae'n rhaid i weithrediad fformatio ddychwelyd gwall dim ond os yw'r [`Formatter`] a basiwyd i mewn yn dychwelyd gwall.
//! Mae hyn oherwydd, yn groes i'r hyn y gallai llofnod y swyddogaeth ei awgrymu, mae fformatio llinyn yn weithrediad anffaeledig.
//! Mae'r swyddogaeth hon yn dychwelyd canlyniad yn unig oherwydd gallai ysgrifennu i'r nant waelodol fethu a rhaid iddi ddarparu ffordd i luosogi'r ffaith bod gwall wedi digwydd yn ôl i fyny'r pentwr.
//!
//! Enghraifft o weithredu'r traits fformatio yn edrych fel:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Mae'r gwerth `f` yn gweithredu'r `Write` trait, a dyna beth yw'r ysgrifennu!mae macro yn disgwyl.
//!         // Sylwch fod y fformatio hwn yn anwybyddu'r baneri amrywiol a ddarperir i fformatio llinynnau.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Mae gwahanol traits yn caniatáu gwahanol fathau o allbwn o fath.
//! // Ystyr y fformat hwn yw argraffu maint vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Parchwch y fflagiau fformatio trwy ddefnyddio'r dull cynorthwyydd `pad_integral` ar y gwrthrych Formatter.
//!         // Gweler y ddogfennaeth dull am fanylion, a gellir defnyddio'r swyddogaeth `pad` i badio llinynnau.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Mae gan y ddau fformatio traits ddibenion gwahanol:
//!
//! - [`fmt::Display`][`Display`] mae gweithrediadau yn honni y gellir cynrychioli'r math yn ffyddlon fel llinyn UTF-8 bob amser.Ni ddisgwylir ** bod pob math yn gweithredu'r [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] dylid gweithredu ar gyfer **pob** math cyhoeddus.
//!   Bydd allbwn fel rheol yn cynrychioli'r wladwriaeth fewnol mor ffyddlon â phosibl.
//!   Diben y [`Debug`] trait yw hwyluso debugging cod Rust.Yn y rhan fwyaf o achosion, mae defnyddio `#[derive(Debug)]` yn ddigonol ac yn cael ei argymell.
//!
//! Rhai enghreifftiau o'r allbwn o'r ddau traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros cysylltiedig
//!
//! Mae yna nifer o macros cysylltiedig yn y teulu [`format!`].Y rhai sy'n cael eu gweithredu ar hyn o bryd yw:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dau macros yw hwn a [`writeln!`] a ddefnyddir i allyrru'r llinyn fformat i nant benodol.Mae hyn yn cael ei ddefnyddio i atal dyraniadau canolradd o dannau fformat ac yn hytrach ysgrifennwch yr allbwn yn uniongyrchol.
//! O dan y cwfl, mae'r swyddogaeth hon mewn gwirionedd yn galw'r swyddogaeth [`write_fmt`] a ddiffinnir ar yr [`std::io::Write`] trait.
//! Defnydd enghreifftiol yw:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Mae hyn a [`println!`] yn allyrru eu hallbwn i stdout.Yn yr un modd â'r macro [`write!`], nod y macros hyn yw osgoi dyraniadau canolradd wrth argraffu allbwn.Defnydd enghreifftiol yw:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Mae'r macros [`eprint!`] a [`eprintln!`] yn union yr un fath â [`print!`] a [`println!`], yn y drefn honno, ac eithrio eu bod yn allyrru eu hallbwn i stderr.
//!
//! ### `format_args!`
//!
//! Mae hwn yn macro chwilfrydig a ddefnyddir i basio gwrthrych afloyw yn ddiogel sy'n disgrifio'r llinyn fformat.Nid yw'r gwrthrych hwn yn gofyn am unrhyw ddyraniadau domen i'w greu, ac mae'n cyfeirio at wybodaeth ar y pentwr yn unig.
//! O dan y cwfl, gweithredir yr holl macros cysylltiedig o ran hyn.
//! Yn gyntaf, peth enghraifft yw:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Canlyniad y macro [`format_args!`] yw gwerth math [`fmt::Arguments`].
//! Yna gellir trosglwyddo'r strwythur hwn i'r swyddogaethau [`write`] a [`format`] y tu mewn i'r modiwl hwn er mwyn prosesu'r llinyn fformat.
//! Nod y macro hwn yw atal dyraniadau canolraddol ymhellach wrth ddelio â llinynnau fformatio.
//!
//! Er enghraifft, gallai llyfrgell logio ddefnyddio'r gystrawen fformatio safonol, ond byddai'n trosglwyddo'r strwythur hwn yn fewnol nes ei fod wedi'i bennu i ble y dylai'r allbwn fynd.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Mae'r swyddogaeth `format` yn cymryd strwythur [`Arguments`] ac yn dychwelyd y llinyn wedi'i fformatio sy'n deillio o hynny.
///
///
/// Gellir creu'r enghraifft [`Arguments`] gyda'r macro [`format_args!`].
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Sylwch y gallai fod yn well defnyddio [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}