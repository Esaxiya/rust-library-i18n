use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Arbenigedd trait a ddefnyddir ar gyfer Vec::from_iter
///
/// ## Y graff dirprwyo:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Mae achos cyffredin yn pasio vector i swyddogaeth sy'n ail-gasglu ar unwaith i mewn i vector.
        // Gallwn gylchdroi hyn os nad yw'r IntoIter wedi'i ddatblygu o gwbl.
        // Pan mae wedi bod yn uwch Gallwn hefyd ailddefnyddio y cof ac yn symud y data yn y blaen.
        // Ond rydym yn unig yn gwneud hynny pan na fyddai'r VEC deillio alluedd yn fwy heb eu defnyddio na chreu drwy'r weithredu FromIterator generig a fyddai'n.
        //
        // Nid yw cyfyngiad yn angenrheidiol llym ag ymddygiad dyraniad VEC yn amhenodol yn fwriadol.
        // Ond mae'n ddewis ceidwadol.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // rhaid dirprwyo i spec_extend() gan fod extend() ei hun yn dirprwyo i spec_from ar gyfer Vecs gwag
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Mae hyn yn defnyddio `iterator.as_slice().to_vec()` gan fod yn rhaid i spec_extend gymryd mwy o gamau i resymu ynghylch y capasiti + hyd terfynol a thrwy hynny wneud mwy o waith.
// `to_vec()` yn dyrannu'r swm cywir yn uniongyrchol ac yn ei lenwi'n union.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): gyda cfg(test) nid yw'r dull `[T]::to_vec` cynhenid, sy'n ofynnol ar gyfer y diffiniad dull hwn, ar gael.
    // Yn lle defnyddio'r swyddogaeth `slice::to_vec` sydd ond ar gael gyda cfg(test) NB gweler y modwl slice::hack yn slice.rs am fwy o wybodaeth
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}