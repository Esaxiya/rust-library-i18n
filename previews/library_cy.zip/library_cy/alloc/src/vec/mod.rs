//! Math arae tyfadwy cyffiniol gyda chynnwys wedi'i ddyrannu i domen, wedi'i ysgrifennu `Vec<T>`.
//!
//! Mae gan Vectors fynegeio `O(1)`, gwthio `O(1)` wedi'i amorteiddio (i'r diwedd) a `O(1)` pop (o'r diwedd).
//!
//!
//! Mae Vectors yn sicrhau nad ydyn nhw byth yn dyrannu mwy na beit `isize::MAX`.
//!
//! # Examples
//!
//! Gallwch greu [`Vec`] yn benodol gyda [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... neu trwy ddefnyddio'r macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // deg sero
//! ```
//!
//! Gallwch chi werthoedd [`push`] ar ddiwedd vector (a fydd yn tyfu'r vector yn ôl yr angen):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Mae gwerthoedd popio yn gweithio yn yr un ffordd fwy neu lai:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Mae Vectors hefyd yn cefnogi mynegeio (trwy'r [`Index`] a [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Math arae tyfadwy cyffiniol, wedi'i ysgrifennu fel `Vec<T>` a'i ynganu 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Darperir y macro [`vec!`] i wneud ymgychwyn yn fwy cyfleus:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Gall hefyd gychwyn pob elfen o `Vec<T>` gyda gwerth penodol.
/// Gall hyn fod yn fwy effeithlon na pherfformio dyraniad a chychwyniad mewn camau ar wahân, yn enwedig wrth gychwyn vector o sero:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Mae'r canlynol yn cyfateb, ond a allai fod yn arafach:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Am ragor o wybodaeth, gweler [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Defnyddiwch `Vec<T>` fel pentwr effeithlon:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Printiau 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Mae'r math `Vec` yn caniatáu cyrchu gwerthoedd yn ôl mynegai, oherwydd ei fod yn gweithredu'r [`Index`] trait.Bydd enghraifft yn fwy eglur:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // bydd yn arddangos '2'
/// ```
///
/// Fodd bynnag, byddwch yn ofalus: os ceisiwch gyrchu mynegai nad yw yn yr `Vec`, bydd eich meddalwedd yn panic!Ni allwch wneud hyn:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Defnyddiwch [`get`] a [`get_mut`] os ydych am wirio a yw'r mynegai yn y `Vec`.
///
/// # Slicing
///
/// Gall `Vec` fod yn gyfnewidiol.Ar y llaw arall, mae tafelli yn wrthrychau darllen yn unig.
/// I gael [slice][prim@slice], defnyddiwch [`&`].enghraifft:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... a dyna'r cyfan!
/// // gallwch hefyd ei wneud fel hyn:
/// let u: &[usize] = &v;
/// // neu fel hyn:
/// let u: &[_] = &v;
/// ```
///
/// Yn Rust, mae'n fwy cyffredin pasio tafelli fel dadleuon yn hytrach na vectors pan rydych chi am ddarparu mynediad darllen yn unig.Mae'r un peth yn wir am [`String`] a [`&str`].
///
/// # Cynhwysedd ac ailddyrannu
///
/// Cynhwysedd vector yw faint o le a ddyrennir ar gyfer unrhyw elfennau future a fydd yn cael eu hychwanegu at y vector.Ni ddylid cymysgu hyn â *hyd* vector, sy'n nodi nifer yr elfennau gwirioneddol yn y vector.
/// Os yw hyd vector yn fwy na'i allu, bydd ei allu yn cynyddu'n awtomatig, ond bydd yn rhaid ailddyrannu ei elfennau.
///
/// Er enghraifft, byddai vector gyda chynhwysedd 10 a hyd 0 yn vector gwag gyda lle i 10 elfen arall.Ni fydd gwthio 10 neu lai o elfennau ar y vector yn newid ei allu nac yn achosi ailddyrannu.
/// Fodd bynnag, os yw hyd y vector yn cael ei gynyddu i 11, bydd yn rhaid i ailddyrannu, a all fod yn araf.Am y rheswm hwn, argymhellir defnyddio [`Vec::with_capacity`] pryd bynnag y bo modd i nodi pa mor fawr y mae disgwyl i'r vector ei gael.
///
/// # Guarantees
///
/// Oherwydd ei natur anhygoel o sylfaenol, mae `Vec` yn gwneud llawer o warantau ynghylch ei ddyluniad.Mae hyn yn sicrhau ei fod mor isel â phosibl yn yr achos cyffredinol, a gellir ei drin yn gywir mewn ffyrdd cyntefig trwy god anniogel.Noder bod gwarantau hyn yn cyfeirio at `Vec<T>` ddiamod.
/// Os ychwanegir paramedrau math ychwanegol (ee, i gefnogi dyranwyr arfer), gall diystyru eu diffygion newid yr ymddygiad.
///
/// Yn fwyaf sylfaenol, mae `Vec` yn dripled (pwyntydd, gallu, hyd) bob amser.Dim mwy, dim llai.Mae trefn y meysydd hyn yn hollol amhenodol, a dylech ddefnyddio'r dulliau priodol i addasu'r rhain.
/// Ni fydd y pwyntydd byth yn null, felly mae'r math hwn wedi'i optimeiddio null-pwyntydd.
///
/// Fodd bynnag, efallai na fydd y pwyntydd yn pwyntio at gof a ddyrannwyd mewn gwirionedd.
/// Yn benodol, os ydych yn adeiladu `Vec` gyda chynhwysedd 0 trwy [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], neu drwy ffonio [`shrink_to_fit`] ar VEC gwag, ni fydd yn dyrannu cof.Yn yr un modd, os ydych chi'n storio mathau o faint sero y tu mewn i `Vec`, ni fydd yn dyrannu lle ar eu cyfer.
/// *Sylwch, yn yr achos hwn, efallai na fydd yr `Vec` yn adrodd am [`capacity`] o 0*.
/// `Vec` yn dyrannu os a dim ond os [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Yn gyffredinol, `manylion dyrannu Vec` yn gynnil iawn-os ydych yn bwriadu i ddyrannu cof gan ddefnyddio `Vec` ac yn ei ddefnyddio ar gyfer rhywbeth arall (naill ai i drosglwyddo i cod anniogel, neu i adeiladu eich casgliad-cof gefnogir hunain), fod yn sicr i ddeallocate y cof hwn trwy ddefnyddio `from_raw_parts` i adfer yr `Vec` ac yna ei ollwng.
///
/// Os yw `Vec`*wedi* cof wedi'i ddyrannu, yna mae'r cof y mae'n tynnu sylw ato ar y domen (fel y'i diffinnir gan y dyrannwr Rust wedi'i ffurfweddu i'w ddefnyddio yn ddiofyn), ac mae ei bwyntydd yn pwyntio at elfennau cychwynnol, cyffiniol [`len`] mewn trefn (yr hyn y byddech chi'n ei wneud gweld a wnaethoch chi ei orfodi i dafell), ac yna [`capasiti`]`,`[`len`] elfennau rhesymegol, anghysbell, rhesymegol.
///
///
/// Gellir delweddu vector sy'n cynnwys yr elfennau `'a'` a `'b'` gyda chynhwysedd 4 fel isod.Y rhan uchaf yw'r strwythur `Vec`, mae'n cynnwys pwyntydd i ben y dyraniad yn y domen, hyd a chynhwysedd.
/// Y rhan waelod yw'r dyraniad ar y domen, bloc cof cyffiniol.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - mae **dadosod** yn cynrychioli cof nad yw wedi'i ymgychwyn, gweler [`MaybeUninit`].
/// - Note: nid yw'r ABI yn sefydlog ac nid yw `Vec` yn gwarantu cynllun ei gof (gan gynnwys trefn y caeau).
///
/// `Vec` ni fydd byth yn perfformio "small optimization" lle mae elfennau'n cael eu storio ar y pentwr am ddau reswm:
///
/// * Byddai'n ei gwneud hi'n anoddach i god anniogel drin `Vec` yn gywir.Ni fyddai gan gynnwys `Vec` gyfeiriad sefydlog pe bai'n cael ei symud yn unig, a byddai'n anoddach penderfynu a oedd `Vec` wedi dyrannu cof mewn gwirionedd.
///
/// * Byddai'n cosbi'r achos cyffredinol, gan arwain at branch ychwanegol ar bob mynediad.
///
/// `Vec` ni fydd byth yn crebachu ei hun yn awtomatig, hyd yn oed os yw'n hollol wag.Mae hyn yn sicrhau na fydd dyraniadau na deallocations diangen yn digwydd.Ni ddylai gwagio `Vec` ac yna ei lenwi yn ôl i'r un [`len`] arwain at unrhyw alwadau i'r dyrannwr.Os ydych chi'n dymuno rhyddhau cof nas defnyddiwyd, defnyddiwch [`shrink_to_fit`] neu [`shrink_to`].
///
/// [`push`] a bydd [`insert`] byth (ail) dyrannu os y gallu adroddwyd yn ddigonol.Bydd [`push`] a [`insert`]*yn dyrannu*(ail) os [`len`]`==`[`capasiti`].Hynny yw, mae'r gallu yr adroddir arno yn hollol gywir, a gellir dibynnu arno.Gellir ei ddefnyddio hyd yn oed i ryddhau'r cof a ddyrannwyd gan `Vec` â llaw os dymunir.
/// Gall dulliau mewnosod swmp * ailddyrannu, hyd yn oed pan nad oes angen.
///
/// `Vec` nid yw'n gwarantu unrhyw strategaeth dwf benodol wrth ailddyrannu pan fydd yn llawn, na phan elwir [`reserve`].Mae'r strategaeth gyfredol yn sylfaenol a gallai fod yn ddymunol defnyddio ffactor twf nad yw'n gyson.Bydd pa bynnag strategaeth a ddefnyddir wrth gwrs yn gwarantu *O*(1) wedi'i amorteiddio [`push`].
///
/// `vec![x; n]`, Bydd `vec![a, b, c, d]`, a [`Vec::with_capacity(n)`][`Vec::with_capacity`], i gyd yn cynhyrchu `Vec` gyda'r gallu y gofynnwyd amdano yn union.
/// Os [`len`]`==`[`capasiti`], (fel sy'n wir am y macro [`vec!`]), yna gellir trosi `Vec<T>` i ac o [`Box<[T]>`][owned slice] heb ailddyrannu na symud yr elfennau.
///
/// `Vec` ni fydd yn trosysgrifo'n benodol unrhyw ddata sy'n cael ei dynnu ohono, ond ni fydd hefyd yn ei gadw'n benodol.Ei gof anghyfarwydd yw gofod crafu y gall ei ddefnyddio sut bynnag y mae eisiau.Bydd yn gyffredinol, dim ond gwneud beth bynnag sydd fwyaf effeithlon neu fel arall yn hawdd i'w gweithredu.Peidiwch â dibynnu ar ddata sydd wedi'i dynnu i'w ddileu at ddibenion diogelwch.
/// Hyd yn oed os byddwch chi'n gollwng `Vec`, mae'n bosib y bydd ei byffer yn cael ei ailddefnyddio gan `Vec` arall.
/// Hyd yn oed os ydych chi'n sero cof `Vec` yn gyntaf, efallai na fydd hynny'n digwydd mewn gwirionedd oherwydd nad yw'r optimizer yn ystyried hyn yn sgil-effaith y mae'n rhaid ei gadw.
/// Fodd bynnag, mae un achos na fyddwn yn ei dorri: mae defnyddio cod `unsafe` i ysgrifennu at y capasiti gormodol, ac yna cynyddu'r hyd i gyfateb, bob amser yn ddilys.
///
/// Ar hyn o bryd, nid yw `Vec` yn gwarantu yn y drefn y mae elfennau'n cael eu gollwng.
/// Mae'r gorchymyn wedi newid yn y gorffennol a gall newid eto.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Dulliau cynhenid
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Yn adeiladu `Vec<T>` newydd, gwag.
    ///
    /// Ni fydd y vector dyrannu nes elfennau yn cael eu gwthio arno.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Yn adeiladu `Vec<T>` newydd, gwag gyda'r gallu penodedig.
    ///
    /// Bydd y vector yn gallu cynnal yn union elfennau `capacity` heb ailddyrannu.
    /// Os yw `capacity` yn 0, ni fydd y vector yn dyrannu.
    ///
    /// Mae'n bwysig nodi, er bod gan y vector a ddychwelwyd y *capasiti* a nodwyd, bydd gan y vector hyd sero *.
    ///
    /// Am esboniad o'r gwahaniaeth rhwng hyd a chynhwysedd, gweler *[Gallu ac ailddyrannu]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Nid yw'r vector yn cynnwys unrhyw eitemau, er bod ganddo allu i wneud mwy
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Gwneir y rhain i gyd heb ailddyrannu ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ond gall hyn wneud y ailddyrannu vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Yn creu `Vec<T>` yn uniongyrchol o gydrannau amrwd vector arall.
    ///
    /// # Safety
    ///
    /// Mae hyn yn hynod anniogel, oherwydd nifer yr invariants nad ydyn nhw'n cael eu gwirio:
    ///
    /// * `ptr` mae angen bod wedi cael ei ddyrannu o'r blaen trwy [`String`]/`Vec<T>`(o leiaf, mae'n debygol iawn o fod yn anghywir os nad oedd).
    /// * `T` mae angen i'r un maint ac aliniad fod â'r hyn a ddyrannwyd i `ptr`.
    ///   (Nid yw `T` ag aliniad llai caeth yn ddigonol, mae gwir angen i'r aliniad fod yn gyfartal i fodloni'r gofyniad [`dealloc`] bod yn rhaid dyrannu cof a'i ddeall gyda'r un cynllun.)
    ///
    /// * `length` mae angen iddo fod yn llai na neu'n hafal i `capacity`.
    /// * `capacity` mae angen i'r gallu y dyrannwyd y pwyntydd iddo.
    ///
    /// Gall torri'r rhain achosi problemau fel llygru strwythurau data mewnol y dyrannwr.Er enghraifft, nid yw'n ** ddiogel adeiladu `Vec<u8>` o bwyntydd i arae C `char` gyda hyd `size_t`.
    /// Hefyd, nid yn ddiogel i adeiladu un o `Vec<u16>` a ei hyd, gan fod y gofalu am y dyrannydd aliniad, ac mae'r rhain yn ddau fath gwahanol aliniadau.
    /// Dyrannwyd aliniad 2 (ar gyfer `u16`) i'r byffer, ond ar ôl ei droi yn `Vec<u8>` bydd yn cael ei ddeall gydag aliniad 1.
    ///
    /// Mae perchnogaeth `ptr` yn cael ei drosglwyddo i bob pwrpas i'r `Vec<T>` a all wedyn ddeallocateiddio, ailddyrannu neu newid cynnwys y cof y mae'r pwyntydd yn tynnu sylw ato yn ôl ewyllys.
    /// Sicrhewch nad oes unrhyw beth arall yn defnyddio'r pwyntydd ar ôl galw'r swyddogaeth hon.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Diweddarwch hyn pan fydd vec_into_raw_parts wedi'i sefydlogi.
    ///     // Atal rhedeg dinistriwr `v` fel ein bod mewn rheolaeth lwyr dros y dyraniad.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tynnwch allan y gwahanol ddarnau pwysig o wybodaeth am `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Ysgrifennu cof gyda 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rhoi popeth yn ôl at ei gilydd i mewn i VEC
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Yn adeiladu `Vec<T, A>` newydd, gwag.
    ///
    /// Ni fydd y vector dyrannu nes elfennau yn cael eu gwthio arno.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Yn adeiladu `Vec<T, A>` gwag newydd gyda'r gallu penodedig gyda'r dyranwr a ddarperir.
    ///
    /// Bydd y vector yn gallu cynnal yn union elfennau `capacity` heb ailddyrannu.
    /// Os yw `capacity` yn 0, ni fydd y vector yn dyrannu.
    ///
    /// Mae'n bwysig nodi, er bod gan y vector a ddychwelwyd y *capasiti* a nodwyd, bydd gan y vector hyd sero *.
    ///
    /// Am esboniad o'r gwahaniaeth rhwng hyd a chynhwysedd, gweler *[Gallu ac ailddyrannu]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Nid yw'r vector yn cynnwys unrhyw eitemau, er bod ganddo allu i wneud mwy
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Gwneir y rhain i gyd heb ailddyrannu ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ond gall hyn wneud y ailddyrannu vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Creu `Vec<T, A>` yn uniongyrchol gan y cydrannau crai vector arall.
    ///
    /// # Safety
    ///
    /// Mae hyn yn hynod anniogel, oherwydd nifer yr invariants nad ydyn nhw'n cael eu gwirio:
    ///
    /// * `ptr` mae angen bod wedi cael ei ddyrannu o'r blaen trwy [`String`]/`Vec<T>`(o leiaf, mae'n debygol iawn o fod yn anghywir os nad oedd).
    /// * `T` mae angen i'r un maint ac aliniad fod â'r hyn a ddyrannwyd i `ptr`.
    ///   (Nid yw `T` ag aliniad llai caeth yn ddigonol, mae gwir angen i'r aliniad fod yn gyfartal i fodloni'r gofyniad [`dealloc`] bod yn rhaid dyrannu cof a'i ddeall gyda'r un cynllun.)
    ///
    /// * `length` mae angen iddo fod yn llai na neu'n hafal i `capacity`.
    /// * `capacity` mae angen i'r gallu y dyrannwyd y pwyntydd iddo.
    ///
    /// Gall torri'r rhain achosi problemau fel llygru strwythurau data mewnol y dyrannwr.Er enghraifft, nid yw'n ** ddiogel adeiladu `Vec<u8>` o bwyntydd i arae C `char` gyda hyd `size_t`.
    /// Hefyd, nid yn ddiogel i adeiladu un o `Vec<u16>` a ei hyd, gan fod y gofalu am y dyrannydd aliniad, ac mae'r rhain yn ddau fath gwahanol aliniadau.
    /// Dyrannwyd aliniad 2 (ar gyfer `u16`) i'r byffer, ond ar ôl ei droi yn `Vec<u8>` bydd yn cael ei ddeall gydag aliniad 1.
    ///
    /// Mae perchnogaeth `ptr` yn cael ei drosglwyddo i bob pwrpas i'r `Vec<T>` a all wedyn ddeallocateiddio, ailddyrannu neu newid cynnwys y cof y mae'r pwyntydd yn tynnu sylw ato yn ôl ewyllys.
    /// Sicrhewch nad oes unrhyw beth arall yn defnyddio'r pwyntydd ar ôl galw'r swyddogaeth hon.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Diweddarwch hyn pan fydd vec_into_raw_parts wedi'i sefydlogi.
    ///     // Atal rhedeg dinistriwr `v` fel ein bod mewn rheolaeth lwyr dros y dyraniad.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tynnwch allan y gwahanol ddarnau pwysig o wybodaeth am `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Ysgrifennu cof gyda 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rhoi popeth yn ôl at ei gilydd i mewn i VEC
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Yn dadelfennu `Vec<T>` yn ei gydrannau amrwd.
    ///
    /// Yn dychwelyd y pwyntydd amrwd i'r data sylfaenol, hyd y vector (mewn elfennau), a chynhwysedd dyranedig y data (mewn elfennau).
    /// Dyma'r un dadleuon yn yr un drefn â'r dadleuon i [`from_raw_parts`].
    ///
    /// Ar ôl galw'r swyddogaeth hon, mae'r galwr yn gyfrifol am y cof a reolwyd yn flaenorol gan yr `Vec`.
    /// Yr unig ffordd i wneud hyn yw trosi'r pwyntydd amrwd, ei hyd a'i allu yn ôl yn `Vec` gyda'r swyddogaeth [`from_raw_parts`], gan ganiatáu i'r dinistriwr gyflawni'r gwaith glanhau.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Bellach gallwn wneud newidiadau i'r cydrannau, megis trosglwyddo'r pwyntydd amrwd i fath cydnaws.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Yn dadelfennu `Vec<T>` yn ei gydrannau amrwd.
    ///
    /// Yn dychwelyd y pwyntydd amrwd i'r data sylfaenol, hyd y vector (mewn elfennau), gallu dyranedig y data (mewn elfennau), a'r dyrannwr.
    /// Mae'r rhain yr un dadleuon yn yr un drefn ag y dadleuon i [`from_raw_parts_in`].
    ///
    /// Ar ôl galw'r swyddogaeth hon, mae'r galwr yn gyfrifol am y cof a reolwyd yn flaenorol gan yr `Vec`.
    /// Yr unig ffordd i wneud hyn yw trosi'r pwyntydd amrwd, ei hyd a'i allu yn ôl yn `Vec` gyda'r swyddogaeth [`from_raw_parts_in`], gan ganiatáu i'r dinistriwr gyflawni'r gwaith glanhau.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Bellach gallwn wneud newidiadau i'r cydrannau, megis trosglwyddo'r pwyntydd amrwd i fath cydnaws.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Yn dychwelyd nifer yr elfennau y gall y vector eu dal heb ailddyrannu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Yn cadw'r gallu i fewnosod o leiaf `additional` mwy o elfennau yn yr `Vec<T>` a roddir.
    /// Efallai y bydd y casgliad yn cadw mwy o le i osgoi ailddyrannu yn aml.
    /// Ar ôl ffonio `reserve`, bydd y capasiti yn fwy na neu'n hafal i `self.len() + additional`.
    /// Yn gwneud dim os yw'r gallu eisoes yn ddigonol.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn fwy na beit `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Yn cadw'r capasiti lleiaf ar gyfer mewnosod `additional` yn fwy o elfennau yn yr `Vec<T>` a roddir.
    ///
    /// Ar ôl ffonio `reserve_exact`, bydd y capasiti yn fwy na neu'n hafal i `self.len() + additional`.
    /// Yn gwneud dim os yw'r gallu eisoes yn ddigonol.
    ///
    /// Sylwch y gall y dyrannwr roi mwy o le i'r casgliad nag y mae'n gofyn amdano.
    /// Felly, ni ellir dibynnu ar gapasiti i fod yn union leiaf.
    /// Mae'n well gennych `reserve` os oes disgwyl mewnosodiadau future.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn gorlifo `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Yn ceisio cadw capasiti i o leiaf `additional` mwy o elfennau gael eu mewnosod yn yr `Vec<T>` a roddir.
    /// Efallai y bydd y casgliad yn cadw mwy o le i osgoi ailddyrannu yn aml.
    /// Ar ôl ffonio `try_reserve`, bydd y capasiti yn fwy na neu'n hafal i `self.len() + additional`.
    /// Yn gwneud dim os yw'r gallu eisoes yn ddigonol.
    ///
    /// # Errors
    ///
    /// Os yw'r capasiti yn gorlifo, neu os yw'r dyrannwr yn adrodd am fethiant, yna dychwelir gwall.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Archebwch y cof ymlaen llaw, gan adael os na allwn wneud hynny
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nawr rydyn ni'n gwybod na all hyn OOM yng nghanol ein gwaith cymhleth
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // cymhleth iawn
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Ceisiau i gadw capasiti gofynnol ar gyfer yr union elfennau `additional` i'w mewnosod yn y `Vec<T>` a roddir.
    /// Ar ôl galw `try_reserve_exact`, bydd y capasiti yn fwy na neu'n hafal i `self.len() + additional` os yw'n dychwelyd `Ok(())`.
    ///
    /// Yn gwneud dim os yw'r gallu eisoes yn ddigonol.
    ///
    /// Sylwch y gall y dyrannwr roi mwy o le i'r casgliad nag y mae'n gofyn amdano.
    /// Felly, ni ellir dibynnu ar gapasiti i fod yn union leiaf.
    /// Mae'n well gennych `reserve` os oes disgwyl mewnosodiadau future.
    ///
    /// # Errors
    ///
    /// Os yw'r capasiti yn gorlifo, neu os yw'r dyrannwr yn adrodd am fethiant, yna dychwelir gwall.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Archebwch y cof ymlaen llaw, gan adael os na allwn wneud hynny
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nawr rydyn ni'n gwybod na all hyn OOM yng nghanol ein gwaith cymhleth
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // cymhleth iawn
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Yn crebachu gallu'r vector gymaint â phosibl.
    ///
    /// Bydd yn cwympo i lawr mor agos â phosibl i'r hyd ond efallai y bydd y dyrannwr yn dal i hysbysu'r vector bod lle i ychydig mwy o elfennau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Nid yw'r gallu byth yn llai na'r hyd, ac nid oes unrhyw beth i'w wneud pan fyddant yn gyfartal, felly gallwn osgoi achos panic yn `RawVec::shrink_to_fit` trwy ei alw â mwy o gapasiti yn unig.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Yn crebachu gallu'r vector gyda rhwymiad is.
    ///
    /// Bydd y capasiti yn aros o leiaf mor fawr â'r hyd a'r gwerth a gyflenwir.
    ///
    ///
    /// Os yw'r gallu cyfredol yn llai na'r terfyn isaf, mae hwn yn ddim-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Trosi'r vector yn [`Box<[T]>`][owned slice].
    ///
    /// Sylwch y bydd hyn yn gollwng unrhyw gapasiti gormodol.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Mae unrhyw gapasiti gormodol yn cael ei ddileu:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Yn byrhau'r vector, gan gadw'r elfennau `len` cyntaf a gollwng y gweddill.
    ///
    /// Os yw `len` yn fwy na hyd cyfredol y vector, nid yw hyn yn cael unrhyw effaith.
    ///
    /// Gall y dull [`drain`] efelychu `truncate`, ond mae'n achosi i'r elfennau gormodol gael eu dychwelyd yn lle eu gollwng.
    ///
    ///
    /// Noder bod y dull hwn yn cael unrhyw effaith ar y gallu a ddyrannwyd y vector.
    ///
    /// # Examples
    ///
    /// Yn torri vector pum elfen i ddwy elfen:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Nid oes unrhyw gwtogi'n digwydd pan fydd `len` yn fwy na hyd cyfredol y vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Yn torri pan fydd `len == 0` yn gyfwerth â galw'r dull [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Mae hyn yn ddiogel oherwydd:
        //
        // * mae'r sleisen a basiwyd i `drop_in_place` yn ddilys;yr Osgoi achos `len > self.len` creu sleisen annilys, ac
        // * mae'r `len` o'r vector yn cael ei grebachu cyn galw `drop_in_place`, fel na fydd unrhyw werth yn cael ei ollwng ddwywaith rhag ofn y byddai `drop_in_place` i panic unwaith (os yw'n panics ddwywaith, mae'r rhaglen yn erthylu).
        //
        //
        //
        unsafe {
            // Note: Mae'n fwriadol bod hyn yn `>` ac nid `>=`.
            //       Newid i `>=` Mae goblygiadau perfformiad negyddol mewn rhai achosion.
            //       Gweler #78884 am fwy.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Darnau sleisen cynnwys y vector cyfan.
    ///
    /// Cyfwerth â `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Yn tynnu darn tafladwy o'r vector cyfan.
    ///
    /// Cyfwerth â `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Yn dychwelyd pwyntydd amrwd i byffer y vector.
    ///
    /// Rhaid i'r galwr sicrhau bod y vector yn goroesi'r pwyntydd y mae'r swyddogaeth hon yn ei ddychwelyd, neu fel arall bydd yn pwyntio at sothach.
    /// Gall addasu'r vector achosi i'w byffer gael ei ailddyrannu, a fyddai hefyd yn gwneud unrhyw awgrymiadau iddo yn annilys.
    ///
    /// Mae'n rhaid i'r galwr hefyd sicrhau bod y cof pwyntydd pwyntiau (non-transitively) i byth yn cael ei ysgrifennu i (ac eithrio tu fewn i `UnsafeCell`) gan ddefnyddio pwyntydd hwn neu unrhyw pwyntydd deillio ohono.
    /// Os oes angen i addasu cynnwys y dafell, defnyddiwch [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Rydyn ni'n cysgodi'r dull tafell o'r un enw er mwyn osgoi mynd trwy `deref`, sy'n creu cyfeirnod canolradd.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Yn dychwelyd pwyntydd symudol anniogel i byffer y vector.
    ///
    /// Rhaid i'r galwr sicrhau bod y vector yn goroesi'r pwyntydd y mae'r swyddogaeth hon yn ei ddychwelyd, neu fel arall bydd yn pwyntio at sothach.
    ///
    /// Gall addasu'r vector achosi i'w byffer gael ei ailddyrannu, a fyddai hefyd yn gwneud unrhyw awgrymiadau iddo yn annilys.
    ///
    /// # Examples
    ///
    /// ```
    /// // Dyrannu vector yn ddigon mawr ar gyfer 4 elfen.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Ymgychwyn elfennau drwy ysgrifennu yn pwyntydd crai, yna gosod hyd.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Rydym yn cysgodi y dull tafell o'r un enw i osgoi mynd trwy `deref_mut`, sy'n creu cyfeirio canolradd.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Yn dychwelyd cyfeiriad at y dyrannwr sylfaenol.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Yn gorfodi hyd y vector i `new_len`.
    ///
    /// Mae hwn yn waith lefel isel sy'n cynnal unrhyw un o'r invariants arferol o'r math.
    /// Fel rheol, mae newid hyd vector yn cael ei wneud gan ddefnyddio un o'r gweithrediadau diogel yn lle, fel [`truncate`], [`resize`], [`extend`], neu [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` rhaid iddo fod yn llai na neu'n hafal i [`capacity()`].
    /// - Rhaid cychwyn yr elfennau yn `old_len..new_len`.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Gall y dull hwn fod yn ddefnyddiol ar gyfer sefyllfaoedd lle mae'r vector yn gweithredu fel byffer ar gyfer cod arall, yn enwedig dros FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dim ond sgerbwd lleiaf posibl yw hwn ar gyfer yr enghraifft doc;
    /// # // peidiwch â defnyddio hwn fel man cychwyn ar gyfer llyfrgell go iawn.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Fesul docs dull FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // DIOGELWCH: Pan fydd `deflateGetDictionary` yn dychwelyd `Z_OK`, mae'n dal:
    ///     // 1. `dict_length` dechreuwyd elfennau.
    ///     // 2.
    ///     // `dict_length` <=y gallu (32_768) sy'n gwneud `set_len` yn ddiogel i'w alw.
    ///     unsafe {
    ///         // Gwnewch alwad FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... a diweddaru'r hyd i'r hyn a gychwynnwyd.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Er bod yr enghraifft ganlynol yn gadarn, mae cof yn gollwng gan na ryddhawyd y vectors mewnol cyn yr alwad `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` yn wag, felly mae angen eu ymgychwyn unrhyw elfennau.
    /// // 2. `0 <= capacity` bob amser yn dal beth bynnag yw `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Fel rheol, yma, byddai rhywun yn defnyddio [`clear`] yn lle i ollwng y cynnwys yn gywir ac felly i beidio â gollwng cof.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Yn tynnu elfen o'r vector a'i dychwelyd.
    ///
    /// Mae'r elfen sydd wedi'i dileu yn cael ei disodli gan elfen olaf y vector.
    ///
    /// Nid yw hyn yn cadw archebu, ond mae O(1).
    ///
    /// # Panics
    ///
    /// Panics os yw `index` allan o ffiniau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Rydym yn disodli hunan [mynegai] gyda'r elfen olaf.
            // Noder os bydd y terfynau yn gwirio uchod yn llwyddo rhaid cael elfen olaf (a all fod yn hunan [mynegai] ei hun).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Yn mewnosod elfen yn safle `index` yn y vector, gan symud yr holl elfennau ar ei ôl i'r dde.
    ///
    ///
    /// # Panics
    ///
    /// Panics os `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // lle ar gyfer yr elfen newydd
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // anffaeledig Y fan a'r lle i roi'r gwerth newydd
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Symud popeth drosodd i wneud lle.
                // (Dyblygu'r elfen `mynegai` yn ddau le yn olynol.)
                ptr::copy(p, p.offset(1), len - index);
                // Ysgrifennwch i mewn, trosysgrifo y copi cyntaf y `elfen index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Yn tynnu ac yn dychwelyd yr elfen yn safle `index` yn y vector, gan symud yr holl elfennau ar ei ôl i'r chwith.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `index` allan o ffiniau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // y lle rydyn ni'n cymryd ohono.
                let ptr = self.as_mut_ptr().add(index);
                // copïwch ef allan, gan gael copi o'r gwerth ar y pentwr ac yn y vector ar yr un pryd.
                //
                ret = ptr::read(ptr);

                // Symud popeth i lawr i lenwi'r fan a'r lle.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Yn cadw'r elfennau a bennir gan y predicate yn unig.
    ///
    /// Mewn geiriau eraill, tynnwch yr holl elfennau `e` fel bod `f(&e)` yn dychwelyd `false`.
    /// Mae'r dull hwn yn gweithredu yn ei le, gan ymweld â phob elfen yn union unwaith yn y drefn wreiddiol, ac mae'n cadw trefn yr elfennau wrth gefn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Oherwydd bod yr elfennau yn cael ymweliad yn union ar ôl yn y gorchymyn gwreiddiol, efallai y wladwriaeth allanol yn cael ei ddefnyddio i benderfynu pa elfennau i gadw.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Ceisiwch osgoi gostyngiad dwbl os nad yw'r gard galw heibio yn cael ei gyflawni, oherwydd efallai y byddwn yn gwneud rhai tyllau yn ystod y broses.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-prosesu Len-> |^-nesaf i wirio
        //                  | <-CNT dileu-> |
        //      | <-original_len-> |Wedi cadw: Elfennau sy'n dychwelyd predicate wir ar.
        //
        // Twll: Slot elfen wedi'i symud neu ei ollwng.
        // Heb eu gwirio: Elfennau dilys heb eu gwirio.
        //
        // Bydd y gard gollwng hwn yn cael ei ddefnyddio pan fydd ysglyfaethu neu `drop` o elfen yn mynd i banig.
        // Mae'n symud elfennau heb eu gwirio i orchuddio tyllau a `set_len` i'r hyd cywir.
        // Mewn achosion pan nad yw predicate a `drop` byth yn mynd i banig, bydd yn cael ei optimeiddio.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // DIOGELWCH: Rhaid i lorio eitemau heb eu gwirio fod yn ddilys gan nad ydym byth yn eu cyffwrdd.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // DIOGELWCH: Ar ôl llenwi'r tyllau, pob eitem yn y cof cyffiniol.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // DIOGELWCH: Rhaid i'r elfen heb ei gwirio fod yn ddilys.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ymlaen yn gynnar i osgoi cwymp dwbl os yw `drop_in_place` yn mynd i banig.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // DIOGELWCH: Nid ydym byth yn cyffwrdd â'r elfen hon eto ar ôl ei gollwng.
                unsafe { ptr::drop_in_place(cur) };
                // Rydym eisoes wedi datblygu'r cownter.
                continue;
            }
            if g.deleted_cnt > 0 {
                // DIOGELWCH: `deleted_cnt`> 0, felly rhaid i'r slot twll beidio â gorgyffwrdd â'r elfen gyfredol.
                // Rydym yn defnyddio copi ar gyfer symud, a pheidiwch byth â chyffwrdd elfen hon eto.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Mae'r holl eitem yn cael ei phrosesu.Gellir optimeiddio hyn i `set_len` gan LLVM.
        drop(g);
    }

    /// Yn cael gwared ar yr holl elfennau olynol ond y cyntaf yn y vector sy'n datrys i'r un allwedd.
    ///
    ///
    /// Os yw'r vector yn cael ei ddidoli, mae hyn yn dileu'r holl ddyblygiadau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Yn cael gwared ar yr holl elfennau olynol ond y cyntaf yn y vector gan fodloni perthynas cydraddoldeb benodol.
    ///
    /// Mae'r swyddogaeth `same_bucket` yn cael ei drosglwyddo cyfeiriadau at ddwy elfen o'r vector a rhaid iddo benderfynu a yw'r elfennau yn cymharu gyfartal.
    /// Mae'r elfennau'n cael eu pasio mewn trefn arall o'u trefn yn y dafell, felly os yw `same_bucket(a, b)` yn dychwelyd `true`, mae `a` yn cael ei dynnu.
    ///
    ///
    /// Os yw'r vector yn cael ei ddidoli, mae hyn yn dileu'r holl ddyblygiadau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Yn atodi elfen i gefn casgliad.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn fwy na beit `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Bydd hyn yn panic neu'n erthylu pe byddem yn dyrannu> bytes isize::MAX neu a fyddai'r cynyddiad hyd yn gorlifo ar gyfer mathau o faint sero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Yn tynnu'r elfen olaf o vector a'i dychwelyd, neu [`None`] os yw'n wag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Yn symud holl elfennau `other` i `Self`, gan adael `other` yn wag.
    ///
    /// # Panics
    ///
    /// Panics os yw nifer yr elfennau yn y vector yn gorlifo `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Yn atodi elfennau i `Self` o byffer arall.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Yn creu ailadroddwr draenio sy'n dileu'r ystod benodol yn y vector ac yn cynhyrchu'r eitemau sydd wedi'u tynnu.
    ///
    /// Pan fydd yr ailadroddwr **yn cael ei ollwng**, mae'r holl elfennau yn yr ystod yn cael eu tynnu o'r vector, hyd yn oed os na ddefnyddiwyd yr ailadroddwr yn llawn.
    /// Os na chaiff yr ailadroddwr **ei ollwng**(gyda [`mem::forget`] er enghraifft), mae'n amhenodol faint o elfennau sy'n cael eu tynnu.
    ///
    /// # Panics
    ///
    /// Panics os yw'r man cychwyn yn fwy na'r pwynt gorffen neu os yw'r pwynt gorffen yn fwy na hyd y vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Mae ystod lawn yn clirio'r vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Diogelwch cof
        //
        // Pan fydd y Drain yn cael ei greu gyntaf, mae'n byrhau hyd y ffynhonnell vector i sicrhau nad oes unrhyw elfennau anfwriadol neu symud-o-hygyrch yn hygyrch o gwbl os nad yw dinistriwr y Drain byth yn gorfod rhedeg.
        //
        //
        // Bydd Drain yn ptr::read allan y gwerthoedd i'w dileu.
        // Ar ôl gorffen, copïir y gynffon sy'n weddill o'r llysiau yn ôl i orchuddio'r twll, ac mae'r hyd vector yn cael ei adfer i'r hyd newydd.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // gosod hyd self.vec i ddechrau, i fod yn ddiogel rhag ofn i Drain gael ei ollwng
            self.set_len(start);
            // Defnyddiwch y benthyciad yn yr IterMut i nodi ymddygiad benthyca'r ailadroddwr Drain cyfan (fel &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Yn clirio'r vector, gan ddileu'r holl werthoedd.
    ///
    /// Noder bod y dull hwn yn cael unrhyw effaith ar y gallu a ddyrannwyd y vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Yn dychwelyd nifer yr elfennau yn y vector, y cyfeirir ato hefyd fel ei 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Yn dychwelyd `true` os nad yw'r vector yn cynnwys unrhyw elfennau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Yn rhannu'r casgliad yn ddau ar y mynegai penodol.
    ///
    /// Yn dychwelyd vector sydd newydd ei ddyrannu sy'n cynnwys yr elfennau yn yr ystod `[at, len)`.
    /// Ar ôl yr alwad, bydd y vector gwreiddiol yn cael ei adael sy'n cynnwys yr elfennau `[0, at)` gyda'i allu blaenorol yn ddigyfnewid.
    ///
    ///
    /// # Panics
    ///
    /// Panics os `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // gall y vector newydd gymryd y byffer gwreiddiol drosodd ac osgoi'r copi
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` yn anniogel a chopïo eitemau i `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Newid maint y `Vec` yn-waith fel bod `len` yn hafal i `new_len`.
    ///
    /// Os yw `new_len` yn fwy na `len`, mae'r gwahaniaeth yn ymestyn yr `Vec`, gyda phob slot ychwanegol wedi'i lenwi â chanlyniad galw'r cau yn `f`.
    ///
    /// Bydd y gwerthoedd dychwelyd o `f` yn gorffen yn yr `Vec` yn y drefn y cawsant eu cynhyrchu.
    ///
    /// Os yw `new_len` yn llai na `len`, mae'r `Vec` yn cael ei gwtogi'n syml.
    ///
    /// Mae'r dull hwn yn defnyddio cau i greu gwerthoedd newydd ar bob gwthiad.Os byddai'n well gennych [`Clone`] werth penodol, defnyddiwch [`Vec::resize`].
    /// Os ydych chi am ddefnyddio'r [`Default`] trait i gynhyrchu gwerthoedd, gallwch basio [`Default::default`] fel yr ail ddadl.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Yn bwyta ac yn gollwng yr `Vec`, gan ddychwelyd cyfeiriad treiddgar at y cynnwys, `&'a mut [T]`.
    /// Sylwch fod yn rhaid i'r math `T` oroesi'r oes a ddewiswyd `'a`.
    /// Os mai cyfeiriadau statig yn unig sydd gan y math, neu ddim cyfeiriadau o gwbl, yna gellir dewis hwn i fod yn `'static`.
    ///
    /// Mae'r swyddogaeth hon yn debyg i'r swyddogaeth [`leak`][Box::leak] ar [`Box`] ac eithrio nad oes unrhyw ffordd i adennill y cof gollwng.
    ///
    ///
    /// Mae'r swyddogaeth hon yn ddefnyddiol yn bennaf ar gyfer data sy'n byw am weddill oes y rhaglen.
    /// Bydd gollwng y cyfeirnod a ddychwelwyd yn achosi gollyngiad cof.
    ///
    /// # Examples
    ///
    /// Defnydd syml:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Yn dychwelyd y capasiti sbâr sy'n weddill o'r vector fel sleisen o `MaybeUninit<T>`.
    ///
    /// Gellir defnyddio'r sleisen a ddychwelwyd i lenwi'r vector â data (ee
    /// trwy ddarllen o ffeil) cyn marcio'r data fel y'i cychwynnwyd gan ddefnyddio'r dull [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Dyrannu vector yn ddigon mawr ar gyfer 10 elfen.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Llenwch y 3 elfen gyntaf.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marciwch 3 elfen gyntaf y vector fel rhai cychwynnol.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ni weithredir y dull hwn o ran `split_at_spare_mut`, er mwyn atal annilysu awgrymiadau i'r byffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Yn dychwelyd cynnwys vector fel sleisen o `T`, ynghyd â chynhwysedd sbâr sy'n weddill o'r vector fel sleisen o `MaybeUninit<T>`.
    ///
    /// Gellir defnyddio'r sleisen capasiti sbâr a ddychwelwyd i lenwi'r vector â data (ee trwy ddarllen o ffeil) cyn marcio'r data fel y'i cychwynnwyd gan ddefnyddio'r dull [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Sylwch mai API lefel isel yw hwn, y dylid ei ddefnyddio'n ofalus at ddibenion optimeiddio.
    /// Os oes angen i chi atodi data i `Vec` gallwch ddefnyddio [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] neu [`resize_with`], yn dibynnu ar eich union anghenion.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Cadwch le ychwanegol yn ddigon mawr ar gyfer 10 elfen.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Llenwch y 4 elfen nesaf.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marciwch y 4 elfen y vector fel rhai ymgychwyn.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - anwybyddir len ac felly ni chaiff ei newid byth
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Diogelwch: mae newid a ddychwelwyd .2 (&mut usize) yn cael ei ystyried yr un peth â galw `.set_len(_)`.
    ///
    /// Defnyddir y dull hwn i gael mynediad unigryw i bob rhan vec ar unwaith yn `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` yn sicr o fod yn ddilys ar gyfer elfennau `len`
        // - `spare_ptr` yn pwyntio un elfen heibio'r byffer, felly nid yw'n gorgyffwrdd â `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Newid maint y `Vec` yn-waith fel bod `len` yn hafal i `new_len`.
    ///
    /// Os yw `new_len` yn fwy na `len`, mae'r gwahaniaeth yn ymestyn yr `Vec`, gyda phob slot ychwanegol wedi'i lenwi â `value`.
    ///
    /// Os yw `new_len` yn llai na `len`, mae'r `Vec` yn cael ei gwtogi'n syml.
    ///
    /// Mae'r dull hwn yn ei gwneud yn ofynnol i weithredu `T` [`Clone`], er mwyn gallu clonio gwerth pasio.
    /// Os oes angen mwy o hyblygrwydd arnoch (neu eisiau dibynnu ar [`Default`] yn lle [`Clone`]), defnyddiwch [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clonio ac atodi pob elfen mewn sleisen i'r `Vec`.
    ///
    /// Iterates dros y sleisen `other`, clonio pob elfen, ac yna ei atodi i'r `Vec` hwn.
    /// Mae'r vector `other` yn croesi'r yn-drefn.
    ///
    /// Sylwch fod y swyddogaeth hon yr un peth â [`extend`] ac eithrio ei bod yn arbenigol gweithio gyda sleisys yn lle.
    ///
    /// Os a phan fydd Rust yn cael ei arbenigo, mae'n debygol na fydd y swyddogaeth hon yn cael ei dirprwyo (ond ar gael o hyd).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Copïau o elfennau o ystod `src` i ddiwedd y vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` yn gwarantu bod yr ystod a roddir yn ddilys ar gyfer mynegeio'ch hun
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Mae'r cod hwn yn generalizes `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Ymestyn y vector yn ôl gwerthoedd `n`, gan ddefnyddio'r generadur a roddir.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Defnyddiwch SetLenOnDrop i weithio o amgylch nam lle mae'n bosibl na fydd y casglwr yn sylweddoli'r storfa trwy `ptr` trwy self.set_len() peidiwch ag alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Ysgrifennwch bob elfen ac eithrio'r un olaf
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Cynyddwch y hyd ym mhob cam rhag ofn next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Gallwn ysgrifennu'r elfen olaf yn uniongyrchol heb glonio yn ddiangen
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // set Len gan gard cwmpas
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Yn dileu elfennau olynol olynol yn y vector yn ôl gweithrediad [`PartialEq`] trait.
    ///
    ///
    /// Os yw'r vector yn cael ei ddidoli, mae hyn yn dileu'r holl ddyblygiadau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Dulliau a swyddogaethau mewnol
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` mae angen iddo fod yn fynegai dilys
    /// - `self.capacity() - self.len()` rhaid iddo fod yn `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - dim ond ar ôl cychwyn elfennau y cynyddir len
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - mae'r galwr yn gwarantu bod src yn fynegai dilys
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Dechreuwyd yr elfen gyda `MaybeUninit::write` yn unig, felly mae'n iawn cynyddu hyd
            // - cynyddir len ar ôl pob elfen i atal gollyngiadau (gweler rhifyn #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - mae'r galwr yn gwarantu bod `src` yn fynegai dilys
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Mae'r ddau awgrym yn cael eu creu o gyfeiriadau tafell unigryw (`&mut [_]`) felly maen nhw'n ddilys ac nid ydyn nhw'n gorgyffwrdd.
            //
            // - Yr elfennau yw: Copïwch felly mae'n iawn eu copïo, heb wneud dim gyda'r gwerthoedd gwreiddiol
            // - `count` yn hafal i len `source`, felly mae'r ffynhonnell yn ddilys ar gyfer darlleniadau `count`
            // - `.reserve(count)` sicrwydd y `spare.len() >= count` mor sbâr yn ddilys am ysgrifennu yn `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Dechreuwyd yr elfennau gan `copy_nonoverlapping` yn unig
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Gweithrediadau cyffredin trait ar gyfer Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): gyda cfg(test) nid yw'r dull `[T]::to_vec` cynhenid, sy'n ofynnol ar gyfer y diffiniad dull hwn, ar gael.
    // Yn lle defnyddio'r swyddogaeth `slice::to_vec` sydd ond ar gael gyda cfg(test) NB gweler y modwl slice::hack yn slice.rs am fwy o wybodaeth
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // gollwng unrhyw beth na fydd yn cael overwritten
        self.truncate(other.len());

        // self.len <= other.len oherwydd y cwtogi uchod, felly mae'r tafelli yma bob amser yn gaeth.
        //
        let (init, tail) = other.split_at(self.len());

        // ailddefnyddio'r gwerthoedd a gynhwysir allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Yn creu ailadroddwr llafurus, hynny yw, un sy'n symud pob gwerth allan o'r vector (o'r dechrau i'r diwedd).
    /// Ni all y vector yn cael ei ddefnyddio ar ôl galw hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s mae Llinyn math, nid &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // dull dail y mae amryw o weithrediadau SpecFrom/SpecExtend yn ei ddirprwyo iddo pan nad oes ganddynt unrhyw optimeiddiadau pellach i gymhwyso
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Mae hyn yn wir am ailadroddwr cyffredinol.
        //
        // Dylai'r swyddogaeth hon fod yn gyfwerth moesol â:
        //
        //      ar gyfer eitem yn iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Ni all DS orlifo gan y byddem wedi gorfod dyrannu'r gofod cyfeiriad
                self.set_len(len + 1);
            }
        }
    }

    /// Yn creu ailadroddwr splicing sy'n disodli'r ystod benodol yn y vector gyda'r ailadroddwr `replace_with` a roddir ac yn cynhyrchu'r eitemau sydd wedi'u tynnu.
    ///
    /// `replace_with` Nid oes angen iddynt fod o'r un hyd ag `range`.
    ///
    /// `range` yn cael ei dynnu hyd yn oed os na chaiff yr ailadroddwr ei yfed tan y diwedd.
    ///
    /// Mae'n amhenodol faint o elfennau yn cael eu tynnu oddi ar y vector os yw gwerth `Splice` yn cael ei gollwng.
    ///
    /// Dim ond pan fydd gwerth `Splice` yn cael ei ollwng y caiff yr ailadroddydd mewnbwn `replace_with` ei yfed.
    ///
    /// Mae hyn yn optimaidd os:
    ///
    /// * Mae'r gynffon (elfennau yn y vector ar ôl `range`) yn wag,
    /// * neu mae `replace_with` yn cynhyrchu llai neu elfennau cyfartal na hyd `amrediad`
    /// * neu is rhwymo ei `size_hint()` yn union.
    ///
    /// Fel arall, dyrennir vector dros dro a symudir y gynffon ddwywaith.
    ///
    /// # Panics
    ///
    /// Panics os yw'r man cychwyn yn fwy na'r pwynt gorffen neu os yw'r pwynt gorffen yn fwy na hyd y vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Yn creu ailadroddwr sy'n defnyddio cau i benderfynu a ddylid tynnu elfen.
    ///
    /// Os yw'r cau yn dychwelyd yn wir, yna caiff yr elfen ei thynnu a'i chynhyrchu.
    /// Os bydd y cau yn dychwelyd yn ffug, bydd yr elfen yn aros yn y vector ac ni fydd yr ailadroddwr yn ei chynhyrchu.
    ///
    /// Mae defnyddio'r dull hwn yn cyfateb i'r cod canlynol:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // eich cod yma
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ond `drain_filter` yn haws i'w defnyddio.
    /// `drain_filter` hefyd yn fwy effeithlon, oherwydd gall wrth-bacio elfennau'r arae mewn swmp.
    ///
    /// Sylwch fod `drain_filter` hefyd yn gadael i chi dreiglo pob elfen wrth gau'r hidlydd, ni waeth a ydych chi'n dewis ei gadw neu ei dynnu.
    ///
    ///
    /// # Examples
    ///
    /// Rhannu arae yn nosweithiau ac ods, gan ailddefnyddio'r dyraniad gwreiddiol:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Gwyliwch rhag i ni ollwng (ymhelaethu ar ollyngiadau)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Ymestyn y gweithredu sy'n copïo elfennau allan o gyfeiriadau cyn eu gwthio i'r Vec.
///
/// Mae'r gweithredu yn arbenigol ar gyfer iterators tafell, lle mae'n defnyddio [`copy_from_slice`] i atodi y dafell cyfan ar unwaith.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Yn gweithredu cymhariaeth o vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Yn gweithredu archebu vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // defnyddio gostyngiad ar gyfer [T] defnyddiwch dafell amrwd i gyfeirio at elfennau'r vector fel y math gwannaf angenrheidiol;
            //
            // Gallai osgoi cwestiynau dilysrwydd mewn rhai achosion
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // Mae RawVec yn trin deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Yn creu `Vec<T>` gwag.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: prawf yn tynnu libstd i mewn, sy'n achosi gwallau yma
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: prawf yn tynnu libstd i mewn, sy'n achosi gwallau yma
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Cael cynnwys cyfan yr `Vec<T>` fel arae, os yw ei faint yn cyfateb yn union â maint yr arae y gofynnwyd amdani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Os nad yw'r hyd yn cyfateb, daw'r mewnbwn yn ôl yn `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Os ydych chi'n iawn gyda chael rhagddodiad o'r `Vec<T>` yn unig, gallwch ffonio [`.truncate(N)`](Vec::truncate) yn gyntaf.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // DIOGELWCH: `.set_len(0)` bob amser yn gadarn.
        unsafe { vec.set_len(0) };

        // DIOGELWCH: Mae pwyntydd `Vec` bob amser wedi'i alinio'n iawn, a
        // mae'r aliniad sydd ei angen ar yr arae yr un peth â'r eitemau.
        // Gwnaethom wirio yn gynharach fod gennym ddigon o eitemau.
        // Ni fydd yr eitemau'n gollwng ddwywaith gan fod yr `set_len` yn dweud wrth yr `Vec` i beidio â'u gollwng hefyd.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}