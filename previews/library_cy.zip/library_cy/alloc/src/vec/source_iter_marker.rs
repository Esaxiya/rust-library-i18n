use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marciwr arbenigedd ar gyfer casglu piblinell ailadroddwr i mewn i Vec wrth ailddefnyddio'r dyraniad ffynhonnell, h.y.
/// gweithredu'r biblinell yn ei lle.
///
/// Mae angen y rhiant SourceIter trait ar gyfer y swyddogaeth sy'n arbenigo i gael mynediad i'r dyraniad sydd i'w hailddefnyddio.
/// Ond nid yw'n ddigonol i'r arbenigedd fod yn ddilys.
/// Gweler ffiniau ychwanegol ar yr impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Mae'r std-mewnol SourceIter/InPlaceIterable traits yn cael eu gweithredu yn unig gan gadwyni o adapter <Adapter<Adapter<IntoIter>>> (pob un yn eiddo i core/std).
// Mae ffiniau ychwanegol ar weithrediadau'r addasydd (y tu hwnt i `impl<I: Trait> Trait for Adapter<I>`) ond yn dibynnu ar traits eraill sydd eisoes wedi'u nodi fel arbenigedd traits (Copi, TrustedRandomAccess, FusedIterator).
//
// I.e. nid yw'r marciwr yn dibynnu ar oes y mathau a gyflenwir gan ddefnyddwyr.Modwlo y twll Copi, a nifer o arbenigeddau eraill sydd eisoes yn dibynnu ar.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Gofynion ychwanegol na ellir mynegi drwy trait bounds.Rydym yn dibynnu ar werthuso const yn lle:
        // a) dim ZSTs gan na fyddai unrhyw ddyraniad i'w ailddefnyddio a byddai rhifyddeg pwyntydd yn cyfateb maint panic b) fel sy'n ofynnol gan gontract Alloc c) mae aliniadau'n cyfateb fel sy'n ofynnol gan gontract Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // wrth gefn i weithrediadau mwy generig
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // defnyddio try-fold ers hynny
        // - mae'n fectoreiddio'n well i rai addaswyr ailadroddwr
        // - yn wahanol i'r mwyafrif o ddulliau iteriad mewnol, dim ond hunan &mut y mae'n ei gymryd
        // - mae'n gadael i ni edau pwyntydd ysgrifennu drwy ei innards a gael yn ôl yn y diwedd
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteriad wedi llwyddo, peidiwch â gollwng pen
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // gwiriwch cafeat pe contract SourceIter chadarnhawyd: os nad oeddent yn efallai na hyd yn oed yn ei gwneud yn at y pwynt hwn
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // gwirio contract InPlaceIterable.Mae hyn yn bosibl dim ond os yw'r ailadroddwr wedi symud y pwyntydd ffynhonnell o gwbl.
        // Os yw'n defnyddio mynediad heb ei wirio trwy TrustedRandomAccess yna bydd pwyntydd y ffynhonnell yn aros yn ei safle cychwynnol ac ni allwn ei ddefnyddio fel cyfeirnod
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // gollwng unrhyw werthoedd sy'n weddill wrth gynffon y ffynhonnell ond atal gollwng y dyraniad ei hun unwaith y bydd IntoIter yn mynd allan o'i gwmpas os yw'r cwymp panics yna rydym hefyd yn gollwng unrhyw elfennau a gesglir i mewn i dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ni ellir gwirio'r contract InPlaceIterable yn union yma gan fod gan try_fold gyfeiriad unigryw at y pwyntydd ffynhonnell y cyfan y gallwn ei wneud yw gwirio a yw'n dal i fod mewn amrediad
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}