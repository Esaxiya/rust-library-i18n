// Gosodwch hyd y vec pan fydd y gwerth `SetLenOnDrop` yn mynd allan o'i gwmpas.
//
// Y syniad yw: Mae'r maes hyd yn SetLenOnDrop yn newidyn lleol y bydd yr optimizer yn ei weld nad yw'n cyd-fynd ag unrhyw storfeydd trwy bwyntydd data'r Vec.
// Mae hwn yn fater datrysiad dros dro ar gyfer dadansoddi alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}