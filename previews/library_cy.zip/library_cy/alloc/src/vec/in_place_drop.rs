use core::ptr::{self};
use core::slice::{self};

// Strwythur cynorthwyydd ar gyfer iteriad yn ei le sy'n gollwng y sleisen gyrchfan o iteriad, hy y pen.
// Mae'r sleisen ffynhonnell (y gynffon) yn cael ei gollwng gan IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}