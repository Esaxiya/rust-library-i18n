//! Golygfa o faint deinamig i mewn i ddilyniant cyffiniol, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Mae tafelli yn olygfa i mewn i floc o gof a gynrychiolir fel pwyntydd a hyd.
//!
//! ```
//! // sleisio Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // gorfodi arae i dafell
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Mae tafelli naill ai'n gyfnewidiol neu'n cael eu rhannu.
//! Y math tafell a rennir yw `&[T]`, tra bod y math tafell symudol yn `&mut [T]`, lle mae `T` yn cynrychioli'r math o elfen.
//! Er enghraifft, gallwch dreiglo'r bloc cof y mae sleisen symudol yn pwyntio ato:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Dyma rai o'r pethau mae'r modiwl hwn yn eu cynnwys:
//!
//! ## Structs
//!
//! Mae yna sawl strwythur sy'n ddefnyddiol ar gyfer sleisys, fel [`Iter`], sy'n cynrychioli iteriad dros dafell.
//!
//! ## Gweithrediadau Trait
//!
//! Mae sawl gweithrediad o traits cyffredin ar gyfer tafelli.Mae rhai enghreifftiau yn cynnwys:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ar gyfer sleisys y mae eu math elfen yn [`Eq`] neu [`Ord`].
//! * [`Hash`] - i sleisys y mae eu math elfen yw [`Hash`].
//!
//! ## Iteration
//!
//! Mae'r sleisys yn gweithredu `IntoIterator`.Mae'r ailadroddwr yn cynhyrchu cyfeiriadau at yr elfennau tafell.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Mae'r sleisen gyfnewidiol yn cynhyrchu cyfeiriadau treiddgar at yr elfennau:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Mae'r ailadroddwr hwn yn cynhyrchu cyfeiriadau symudol at elfennau'r sleisen, felly er mai math elfen y dafell yw `i32`, math elfen yr ailadroddwr yw `&mut i32`.
//!
//!
//! * [`.iter`] a [`.iter_mut`] yw'r dulliau penodol i ddychwelyd yr ailadroddwyr diofyn.
//! * Dulliau pellach sy'n dychwelyd ailadroddwyr yw [`.split`], [`.splitn`], [`.chunks`], [`.windows`] a mwy.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Dim ond yn y ffurfweddiad prawf y defnyddir llawer o'r defnyddiau yn y modiwl hwn.
// Mae'n lanach i ddiffodd y rhybudd nas defnyddiwyd_imports na'u trwsio.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Dulliau estyn sleis sylfaenol
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) sydd ei angen ar gyfer gweithredu macro `vec!` wrth brofi DS, gweler y modiwl `hack` yn y ffeil hon am ragor o fanylion.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) sydd ei angen ar gyfer gweithredu `Vec::clone` wrth brofi DS, gweler y modiwl `hack` yn y ffeil hon am ragor o fanylion.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Gyda cfg(test) `impl [T]` ddim ar gael, mae'r tair swyddogaeth hyn mewn gwirionedd yn ddulliau sydd yn `impl [T]` ond nid yn `core::slice::SliceExt`, mae angen i ni gyflenwi'r swyddogaethau hyn ar gyfer y prawf `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Ni ddylem ychwanegu priodoledd mewnol at hyn gan fod hwn yn cael ei ddefnyddio yn macro `vec!` yn bennaf ac yn achosi atchweliad perffaith.
    // Gweler #71204 am drafodaeth a chanlyniadau perffaith.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // marciwyd eitemau yn y ddolen isod
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) yn angenrheidiol er mwyn i LLVM gael gwared ar wiriadau ffiniau ac mae ganddo well codgen na sip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // dyrannwyd a chychwynnwyd y vec uchod i'r hyd hwn o leiaf.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // dyrannu uchod gyda'r gallu o `s`, ac ymgychwyn i `s.len()` yn ptr::copy_to_non_overlapping isod.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Yn didoli'r dafell.
    ///
    /// Mae'r math hwn yn sefydlog (h.y., nid yw'n ail-archebu elfennau cyfartal) ac *O*(*n*\*log(* n*)) achos gwaethaf.
    ///
    /// Pan fo'n berthnasol, mae'n well didoli ansefydlog oherwydd ei fod yn gyflymach yn gyffredinol na didoli sefydlog ac nid yw'n dyrannu cof ategol.
    /// Gweler [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn fath uno addasol, ailadroddol wedi'i ysbrydoli gan [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Fe'i cynlluniwyd i fod yn gyflym iawn mewn achosion lle mae'r sleisen bron wedi'i didoli, neu'n cynnwys dau ddilyniant wedi'u didoli neu fwy wedi'u cyd-daro un ar ôl y llall.
    ///
    ///
    /// Hefyd, mae'n dyrannu storfa dros dro hanner maint `self`, ond ar gyfer tafelli byr defnyddir math mewnosod nad yw'n dyrannu yn lle.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Yn didoli'r dafell gyda swyddogaeth gymharol.
    ///
    /// Mae'r math hwn yn sefydlog (h.y., nid yw'n ail-archebu elfennau cyfartal) ac *O*(*n*\*log(* n*)) achos gwaethaf.
    ///
    /// Rhaid i'r swyddogaeth gymharydd ddiffinio cyfanswm archebu ar gyfer yr elfennau yn y dafell.Os nad yw'r archebu'n gyfanswm, mae trefn yr elfennau yn amhenodol.
    /// Gorchymyn yw cyfanswm archeb os yw (ar gyfer pob `a`, `b` a `c`):
    ///
    /// * cyfanswm a gwrthsymmetrig: mae union un o `a < b`, `a == b` neu `a > b` yn wir, a
    /// * trawsnewidiol, mae `a < b` a `b < c` yn awgrymu `a < c`.Rhaid i'r un peth ddal ar gyfer `==` a `>`.
    ///
    /// Er enghraifft, er nad yw [`f64`] yn gweithredu [`Ord`] oherwydd `NaN != NaN`, gallwn ddefnyddio `partial_cmp` fel ein swyddogaeth didoli pan wyddom nad yw'r sleisen yn cynnwys `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Pan fo'n berthnasol, mae'n well didoli ansefydlog oherwydd ei fod yn gyflymach yn gyffredinol na didoli sefydlog ac nid yw'n dyrannu cof ategol.
    /// Gweler [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn fath uno addasol, ailadroddol wedi'i ysbrydoli gan [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Fe'i cynlluniwyd i fod yn gyflym iawn mewn achosion lle mae'r sleisen bron wedi'i didoli, neu'n cynnwys dau ddilyniant wedi'u didoli neu fwy wedi'u cyd-daro un ar ôl y llall.
    ///
    /// Hefyd, mae'n dyrannu storfa dros dro hanner maint `self`, ond ar gyfer tafelli byr defnyddir math mewnosod nad yw'n dyrannu yn lle.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // didoli gwrthdroi
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Yn didoli'r dafell gyda swyddogaeth echdynnu allweddol.
    ///
    /// Mae'r math hwn yn sefydlog (h.y., nid yw'n ail-archebu elfennau cyfartal) ac *O*(*m*\* * n *\* log(*n*)) achos gwaethaf, lle mae'r swyddogaeth allweddol yn *O*(*m*).
    ///
    /// Ar gyfer swyddogaethau allweddol drud (ee
    /// swyddogaethau nad ydynt yn fynediad eiddo syml nac yn weithrediadau sylfaenol), mae [`sort_by_cached_key`](slice::sort_by_cached_key) yn debygol o fod yn sylweddol gyflymach, gan nad yw'n ailgyflwyno allweddi elfen.
    ///
    ///
    /// Pan fo'n berthnasol, mae'n well didoli ansefydlog oherwydd ei fod yn gyflymach yn gyffredinol na didoli sefydlog ac nid yw'n dyrannu cof ategol.
    /// Gweler [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn fath uno addasol, ailadroddol wedi'i ysbrydoli gan [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Fe'i cynlluniwyd i fod yn gyflym iawn mewn achosion lle mae'r sleisen bron wedi'i didoli, neu'n cynnwys dau ddilyniant wedi'u didoli neu fwy wedi'u cyd-daro un ar ôl y llall.
    ///
    /// Hefyd, mae'n dyrannu storfa dros dro hanner maint `self`, ond ar gyfer tafelli byr defnyddir math mewnosod nad yw'n dyrannu yn lle.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Yn didoli'r dafell gyda swyddogaeth echdynnu allweddol.
    ///
    /// Wrth ddidoli, dim ond unwaith yr elfen y gelwir y swyddogaeth allweddol.
    ///
    /// Mae'r math yma yn sefydlog (hy, yn elfennau cyfartal Nid yw ail-archebu) a *O*(*m*\* * n *+* n *\* log(*n*)) achos gwaethaf, lle y swyddogaeth allweddol yw *O*(*m*) .
    ///
    /// Ar gyfer swyddogaethau allweddol syml (ee swyddogaethau sy'n fynediad i eiddo neu'n weithrediadau sylfaenol), mae [`sort_by_key`](slice::sort_by_key) yn debygol o fod yn gyflymach.
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn seiliedig ar [pattern-defeating quicksort][pdqsort] gan Orson Peters, sy'n cyfuno achos cyflym cyflym quicksort ar hap â'r achos gwaethaf cyflym o heapsort, wrth gyflawni amser llinellol ar dafelli â phatrymau penodol.
    /// Mae'n defnyddio rhywfaint o hap i osgoi achosion dirywiol, ond gyda seed sefydlog i ddarparu ymddygiad penderfyniadol bob amser.
    ///
    /// Yn yr achos gwaethaf, mae'r algorithm yn dyrannu storfa dros dro mewn `Vec<(K, usize)>` hyd y dafell.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Micro cynorthwyydd ar gyfer mynegeio ein vector yn ôl y math lleiaf posibl, i leihau dyraniad.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Mae elfennau `indices` yn unigryw, gan eu bod wedi'u mynegeio, felly bydd unrhyw fath yn sefydlog o ran y sleisen wreiddiol.
                // Rydym yn defnyddio `sort_unstable` yma oherwydd mae angen llai o ddyraniad cof.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Copïau `self` i mewn i `Vec` newydd.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Yma, gellir addasu `s` a `x` yn annibynnol.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Copïwch `self` i mewn i `Vec` newydd gyda dyrannwr.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Yma, gellir addasu `s` a `x` yn annibynnol.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // DS, gweler y modiwl `hack` yn y ffeil hon am ragor o fanylion.
        hack::to_vec(self, alloc)
    }

    /// Trosi `self` mewn i vector heb clonau neu ddyraniad.
    ///
    /// Gellir trosi'r vector sy'n deillio o hyn yn ôl i mewn i flwch trwy `Vec<T>dull `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ni ellir ei ddefnyddio mwyach oherwydd ei fod wedi'i drosi'n `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // DS, gweler y modiwl `hack` yn y ffeil hon am ragor o fanylion.
        hack::into_vec(self)
    }

    /// Yn creu vector trwy ailadrodd tafell `n` gwaith.
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon yn panic pe bai'r capasiti yn gorlifo.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic ar orlif:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Os yw `n` yn fwy na sero, gellir ei rannu fel `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` yw'r rhif a gynrychiolir gan y darn '1' mwyaf chwith o `n`, a `rem` yw'r rhan sy'n weddill o `n`.
        //
        //

        // Defnyddio `Vec` i gael mynediad at `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` mae ailadrodd yn cael ei wneud trwy ddyblu amseroedd `buf` `expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Os `m > 0`, mae darnau ar ôl hyd at yr '1' mwyaf chwith.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` mae ganddo gapasiti o `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` Gwneir ailadrodd (`=n, 2 ^ expn`) trwy gopïo ailadroddiadau `rem` cyntaf o `buf` ei hun.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Nid yw hyn yn gorgyffwrdd ers `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` yn cyfateb i `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens sleisen o `T` i mewn i werth un `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Yn fflatio tafell o `T` i mewn i werth sengl `Self::Output`, gan osod gwahanydd penodol rhwng pob un.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Yn fflatio tafell o `T` i mewn i werth sengl `Self::Output`, gan osod gwahanydd penodol rhwng pob un.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Yn dychwelyd vector sy'n cynnwys copi o'r sleisen hon lle mae pob beit wedi'i fapio i'w gyfwerth ag achos uchaf ASCII.
    ///
    ///
    /// Mae llythyrau ASCII 'a' i 'z' wedi'u mapio i 'A' i 'Z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I ychwanegu at y gwerth yn ei le, defnyddiwch [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Yn dychwelyd vector sy'n cynnwys copi o'r sleisen hon lle mae pob beit wedi'i fapio i'w gyfwerth â llythrennau bach ASCII.
    ///
    ///
    /// Mae llythyrau ASCII 'A' i 'Z' wedi'u mapio i 'a' i 'z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I ostwng y gwerth yn ei le, defnyddiwch [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Estyniad traits ar gyfer sleisys dros fathau penodol o ddata
////////////////////////////////////////////////////////////////////////////////

/// Heliwr trait ar gyfer [`[T]: : concat`](sleisen::concat).
///
/// Note: ni ddefnyddir y paramedr math `Item` yn y trait hwn, ond mae'n caniatáu i impls fod yn fwy generig.
/// Hebddo, rydym yn cael y gwall hwn:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Y rheswm am hyn yw y gallai fodoli mathau `V` gyda sawl impls `Borrow<[_]>`, fel y byddai sawl math `T` yn berthnasol:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Y math sy'n deillio o hynny ar ôl concatenation
    type Output;

    /// Gweithredu [`[T]: : concat`](sleisen::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Heliwr trait ar gyfer [`[T]: : ymuno`](sleisen::ymuno)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Y math sy'n deillio o hynny ar ôl concatenation
    type Output;

    /// Gweithredu [`[T]: : ymuno`](sleisen::ymuno)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Gweithrediadau safonol trait ar gyfer tafelli
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // gollwng unrhyw beth yn y targed na fydd yn cael ei drosysgrifo
        target.truncate(self.len());

        // target.len <= self.len oherwydd y cwtogi uchod, felly mae'r tafelli yma bob amser yn gaeth.
        //
        let (init, tail) = self.split_at(target.len());

        // ailddefnyddio'r gwerthoedd a gynhwysir allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Mewnosod `v[0]` yn y dilyniant `v[1..]` wedi'i ddidoli ymlaen llaw fel bod `v[..]` cyfan yn cael ei ddidoli.
///
/// Dyma'r is-reolwaith annatod o fath mewnosod.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Mae tair ffordd i weithredu mewnosod yma:
            //
            // 1. Cyfnewid elfennau cyfagos nes i'r un cyntaf gyrraedd ei gyrchfan derfynol.
            //    Fodd bynnag, fel hyn rydym yn copïo data o gwmpas mwy nag sy'n angenrheidiol.
            //    Os yw elfennau'n strwythurau mawr (costus i'w copïo), bydd y dull hwn yn araf.
            //
            // 2. Iterate nes dod o hyd i'r lle iawn ar gyfer yr elfen gyntaf.
            // Yna symudwch yr elfennau gan ei olynu i wneud lle iddo a'i roi yn y twll sy'n weddill.
            // Mae hwn yn ddull da.
            //
            // 3. Copïwch yr elfen gyntaf yn newidyn dros dro.Ailadrodd nes bod y lle iawn ar ei gyfer yn dod o hyd.
            // Wrth inni fynd ymlaen, copïwch bob elfen wedi'i chroesi i'r slot o'i blaen.
            // Yn olaf, copïwch ddata o'r newidyn dros dro i'r twll sy'n weddill.
            // Mae'r dull hwn yn dda iawn.
            // Dangosodd meincnodau berfformiad ychydig yn well na gyda'r 2il ddull.
            //
            // Meincnodwyd pob dull, a dangosodd y 3ydd y canlyniadau gorau.Felly fe wnaethon ni ddewis yr un hwnnw.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Mae cyflwr canolraddol y broses fewnosod bob amser yn cael ei olrhain gan `hole`, sy'n cyflawni dau bwrpas:
            // 1. Yn amddiffyn cyfanrwydd `v` rhag panics yn `is_less`.
            // 2. Yn llenwi'r twll sy'n weddill yn `v` yn y diwedd.
            //
            // Diogelwch Panic:
            //
            // Os yw `is_less` panics ar unrhyw adeg yn ystod y broses, bydd `hole` yn cael ei ollwng ac yn llenwi'r twll yn `v` gyda `tmp`, gan sicrhau felly bod `v` yn dal i ddal pob gwrthrych a ddaliodd i ddechrau yn union unwaith.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` yn cael ei ollwng ac felly'n copïo `tmp` i'r twll sy'n weddill yn `v`.
        }
    }

    // Pan ollyngir nhw, copïau o `src` i `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Mae uno heb fod yn gostwng yn rhedeg `v[..mid]` a `v[mid..]` gan ddefnyddio `buf` fel storfa dros dro, ac yn storio'r canlyniad yn `v[..]`.
///
/// # Safety
///
/// Rhaid i'r ddwy dafell fod yn wag a rhaid i `mid` fod mewn ffiniau.
/// Rhaid i byffer `buf` fod yn ddigon hir i ddal copi o'r sleisen fyrrach.
/// Hefyd, rhaid i `T` beidio â bod yn fath sero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Mae'r broses uno yn copïo'r rhediad byrrach yn `buf` yn gyntaf.
    // Yna mae'n olrhain y rhediad sydd newydd ei gopïo a'r rhediad hirach ymlaen (neu'n ôl), gan gymharu eu elfennau heb eu cymeradwyo nesaf a chopïo'r un lleiaf (neu fwy) i mewn i `v`.
    //
    // Cyn gynted ag y bydd y rhediad byrrach yn cael ei fwyta'n llawn, mae'r broses yn cael ei gwneud.Os yw'r rhediad hirach yn cael ei fwyta gyntaf, yna mae'n rhaid i ni gopïo beth bynnag sydd ar ôl o'r rhediad byrrach i'r twll sy'n weddill yn `v`.
    //
    // Mae cyflwr canolraddol y broses bob amser yn cael ei olrhain gan `hole`, sy'n cyflawni dau bwrpas:
    // 1. Yn amddiffyn cyfanrwydd `v` rhag panics yn `is_less`.
    // 2. Llenwch y twll sy'n weddill yn `v` os yw'r rhediad hirach yn cael ei fwyta gyntaf.
    //
    // Diogelwch Panic:
    //
    // Os yw `is_less` panics ar unrhyw adeg yn ystod y broses, bydd `hole` yn cael ei ollwng ac yn llenwi'r twll yn `v` gyda'r amrediad digymell yn `buf`, gan sicrhau bod `v` yn dal i ddal pob gwrthrych a ddaliodd i ddechrau yn union unwaith.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Mae'r rhediad chwith yn fyrrach.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // I ddechrau, mae'r awgrymiadau hyn yn tynnu sylw at ddechreuadau eu araeau.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Defnyddiwch yr ochr leiaf.
            // Os gyfartal, well gan y rhediad chwith i gynnal sefydlogrwydd.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Mae'r rhediad cywir yn fyrrach.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // I ddechrau, awgrymiadau hyn yn tynnu sylw yn y gorffennol yn dod i ben eu araeau.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Defnyddiwch yr ochr fwyaf.
            // Os yw'n gyfartal, mae'n well gennych y rhediad cywir i gynnal sefydlogrwydd.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Yn olaf, mae `hole` yn cael ei ollwng.
    // Os na ddefnyddiwyd y rhediad byrrach yn llawn, bydd pa bynnag olion ohono nawr yn cael eu copïo i'r twll yn `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Pan fydd wedi'i ollwng, copïwch yr ystod `start..end` i mewn i `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` nid yw'n fath o faint sero, felly mae'n iawn ei rannu yn ôl ei faint.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Mae'r math uno hwn yn benthyca rhai syniadau (ond nid pob un) gan TimSort, a ddisgrifir yn fanwl [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Mae'r algorithm yn nodi dilyniannau sy'n disgyn yn llwyr ac nad ydynt yn disgyn, a elwir yn rediadau naturiol.Mae pentwr o rediadau sydd ar ddod eto i'w huno.
/// Mae pob rhediad newydd ei ddarganfod yn cael ei wthio i'r pentwr, ac yna mae rhai parau o rediadau cyfagos yn cael eu huno nes bod y ddau invariant hyn yn fodlon:
///
/// 1. am bob `i` yn `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. am bob `i` yn `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Mae'r invariants yn sicrhau mai cyfanswm yr amser rhedeg yw *O*(*n*\*log(* n*)) achos gwaethaf.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mae tafelli hyd at y darn hwn yn cael eu didoli gan ddefnyddio math mewnosod.
    const MAX_INSERTION: usize = 20;
    // Mae rhediadau byr iawn yn cael eu hymestyn gan ddefnyddio math mewnosod i rychwantu o leiaf cymaint o elfennau.
    const MIN_RUN: usize = 10;

    // Nid oes gan ddidoli unrhyw ymddygiad ystyrlon ar fathau o faint sero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Mae araeau byr yn cael eu didoli yn eu lle trwy eu mewnosod er mwyn osgoi dyraniadau.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Dyrannu byffer i'w ddefnyddio fel cof crafu.Rydym yn cadw'r hyd 0 fel y gallwn gadw copïau bas o gynnwys `v` ynddo heb beryglu'r dtors sy'n rhedeg ar gopïau os yw `is_less` panics.
    //
    // Wrth uno dau rediad wedi'u didoli, mae'r byffer hwn yn dal copi o'r rhediad byrrach, a fydd bob amser â hyd ar y mwyaf o `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Er mwyn nodi rhediadau naturiol yn `v`, rydym yn ei groesi yn ôl.
    // Gallai hynny ymddangos fel penderfyniad rhyfedd, ond ystyriwch y ffaith bod uno yn amlach yn mynd i'r cyfeiriad arall (forwards).
    // Yn ôl meincnodau, mae uno ymlaen ychydig yn gyflymach nag uno yn ôl.
    // I gloi, mae nodi rhediadau trwy groesi tuag yn ôl yn gwella perfformiad.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Dewch o hyd i'r rhediad naturiol nesaf, a gwrthdroi'r os yw'n llym ddisgynnol.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Mewnosodwch ychydig mwy o elfennau yn y rhediad os yw'n rhy fyr.
        // Mae didoli mewnosod yn gyflymach na didoli uno ar ddilyniannau byr, felly mae hyn yn gwella perfformiad yn sylweddol.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Gwthiwch y rhediad hwn ar y pentwr.
        runs.push(Run { start, len: end - start });
        end = start;

        // Uno rhai parau o rediadau cyfagos i fodloni'r invariants.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Yn olaf, rhaid i un rhediad yn union aros yn y pentwr.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Yn archwilio'r pentwr o rediadau ac yn nodi'r pâr nesaf o rediadau i uno.
    // Yn fwy penodol, os dychwelir `Some(r)`, mae hynny'n golygu bod yn rhaid uno `runs[r]` a `runs[r + 1]` nesaf.
    // Os dylai'r algorithm barhau i adeiladu rhediad newydd yn lle, dychwelir `None`.
    //
    // Mae TimSort yn enwog am ei weithrediadau bygi, fel y disgrifir yma:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Hanfod y stori yw: rhaid i ni orfodi'r invariants ar y pedwar rhediad uchaf ar y pentwr.
    // Nid yw eu gorfodi ar ddim ond y tri uchaf yn ddigonol i sicrhau y bydd yr invariants yn dal i ddal am bob rhediad * yn y pentwr.
    //
    // Mae'r swyddogaeth hon yn gwirio invariants yn gywir ar gyfer y pedwar rhediad uchaf.
    // Yn ogystal, os bydd y rhediad uchaf yn cychwyn ym mynegai 0, bydd bob amser yn mynnu gweithrediad uno nes bod y pentwr wedi cwympo'n llawn, er mwyn cwblhau'r math.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}