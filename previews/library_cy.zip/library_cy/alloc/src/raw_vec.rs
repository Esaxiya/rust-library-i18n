#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Mae cynnwys y cof newydd yn anfwriadol.
    Uninitialized,
    /// Gwarantir y bydd y cof newydd yn sero.
    Zeroed,
}

/// Cyfleustodau lefel isel ar gyfer dyrannu, ailddyrannu a deall byffer cof ar y domen yn fwy ergonomegol heb orfod poeni am yr holl achosion cornel dan sylw.
///
/// Mae'r math hwn yn ardderchog ar gyfer adeiladu eich strwythurau data eich hun fel Vec a VecDeque.
/// Yn benodol:
///
/// * Yn cynhyrchu `Unique::dangling()` ar fathau o faint sero.
/// * Yn cynhyrchu `Unique::dangling()` ar ddyraniadau hyd sero.
/// * Yn osgoi rhyddhau `Unique::dangling()`.
/// * Yn dal pob gorlif mewn cyfrifiannau capasiti (yn eu hyrwyddo i "capacity overflow" panics).
/// * Gwarchodlu yn erbyn systemau 32-did sy'n dyrannu mwy na beit isize::MAX.
/// * Gwarchodlu rhag gorlifo'ch hyd.
/// * Yn galw `handle_alloc_error` am ddyraniadau codadwy.
/// * Yn cynnwys `ptr::Unique` ac felly'n rhoi i'r defnyddiwr yr holl fuddion cysylltiedig.
/// * Yn defnyddio'r gormodedd a ddychwelwyd gan y dyrannwr i ddefnyddio'r capasiti mwyaf sydd ar gael.
///
/// Nid yw'r math hwn beth bynnag yn archwilio'r cof y mae'n ei reoli.Pan fydd yn cael ei ollwng bydd * yn rhyddhau ei gof, ond ni fydd yn ceisio gollwng ei gynnwys.
/// Cyfrifoldeb defnyddiwr `RawVec` yw trin y pethau gwirioneddol *sydd wedi'u storio* y tu mewn i `RawVec`.
///
/// Sylwch fod gormodedd o fathau sero bob amser yn anfeidrol, felly mae `capacity()` bob amser yn dychwelyd `usize::MAX`.
/// Mae hyn yn golygu bod angen i chi fod yn ofalus wrth faglu'r math hwn gyda `Box<[T]>`, gan na fydd `capacity()` yn ildio'r hyd.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Mae hyn yn bodoli oherwydd nad oes angen i `#[unstable]` `const fn`s gydymffurfio â `min_const_fn` ac felly ni ellir eu galw yn`min_const_fn`s chwaith.
    ///
    /// Os byddwch chi'n newid `RawVec<T>::new` neu ddibyniaethau, cymerwch ofal i beidio â chyflwyno unrhyw beth a fyddai'n torri `min_const_fn` yn wirioneddol.
    ///
    /// NOTE: Gallem osgoi'r darnia hwn a gwirio cydymffurfiad â rhywfaint o briodoledd `#[rustc_force_min_const_fn]` sy'n gofyn am gydymffurfio â `min_const_fn` ond nid yw o reidrwydd yn caniatáu ei alw yn `stable(...) const fn`/cod defnyddiwr ddim yn galluogi `foo` pan fydd `#[rustc_const_unstable(feature = "foo", issue = "01234")]` yn bresennol.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Creu y `RawVec` posibl mwyaf (ar y system domen) heb ddyrannu.
    /// Os oes gan `T` faint positif, yna mae hyn yn gwneud `RawVec` gyda chynhwysedd `0`.
    /// Os yw `T` o faint sero, yna mae'n gwneud `RawVec` gyda chynhwysedd `usize::MAX`.
    /// Yn ddefnyddiol ar gyfer gweithredu dyraniad gohiriedig.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Yn creu `RawVec` (ar domen y system) gyda'r gofynion capasiti ac alinio ar gyfer `[T; capacity]` yn union.
    /// Mae hyn yn cyfateb i alw `RawVec::new` pan fydd `capacity` yn `0` neu `T` o faint sero.
    /// Sylwch, os yw `T` o faint sero, mae hyn yn golygu na fyddwch * yn cael `RawVec` gyda'r gallu y gofynnwyd amdano.
    ///
    /// # Panics
    ///
    /// Panics os yw'r capasiti y gofynnwyd amdano yn fwy na beit `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Erthyliadau ar OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Fel `with_capacity`, ond mae'n gwarantu bod y byffer yn sero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Yn ailgyfansoddi `RawVec` o bwyntydd a chynhwysedd.
    ///
    /// # Safety
    ///
    /// Rhaid dyrannu'r `ptr` (ar domen y system), a chyda'r `capacity` a roddir.
    /// Ni all yr `capacity` fod yn fwy na `isize::MAX` ar gyfer mathau o faint.(dim ond pryder ar systemau 32-did).
    /// Efallai y bydd gan ZST vectors gapasiti hyd at `usize::MAX`.
    /// Os yw'r `ptr` a'r `capacity` yn dod o `RawVec`, yna mae hyn wedi'i warantu.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Mae Vecs bach yn fud.Neidio i:
    // - 8 os yw maint yr elfen yn 1, oherwydd mae unrhyw ddyrannwyr domen yn debygol o dalgrynnu cais o lai nag 8 beit io leiaf 8 beit.
    //
    // - 4 os yw'r elfennau o faint cymedrol (<=1 KiB).
    // - 1 fel arall, er mwyn osgoi gwastraffu gormod o le ar gyfer Vecs byr iawn.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Fel `new`, ond wedi'i baramedreiddio dros y dewis o ddyrannwr ar gyfer yr `RawVec` a ddychwelwyd.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` yw "unallocated".mathau sero maint yn cael eu hanwybyddu.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Fel `with_capacity`, ond wedi'i baramedreiddio dros y dewis o ddyrannwr ar gyfer yr `RawVec` a ddychwelwyd.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Fel `with_capacity_zeroed`, ond wedi'i baramedreiddio dros y dewis o ddyrannwr ar gyfer yr `RawVec` a ddychwelwyd.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Trosi `Box<[T]>` yn `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Trosi'r byffer cyfan yn `Box<[MaybeUninit<T>]>` gyda'r `len` penodedig.
    ///
    /// Sylwch y bydd hyn yn ailgyfansoddi'n gywir unrhyw newidiadau `cap` a allai fod wedi'u cyflawni.(Gweler y disgrifiad o'r math am fanylion.)
    ///
    /// # Safety
    ///
    /// * `len` rhaid iddo fod yn fwy na neu'n hafal i'r gallu y gofynnwyd amdano yn fwyaf diweddar, a
    /// * `len` rhaid iddo fod yn llai na neu'n hafal i `self.capacity()`.
    ///
    /// Sylwch, y gallai'r capasiti y gofynnwyd amdano a'r `self.capacity()` fod yn wahanol, gan y gallai dyrannwr ddyrannu a dychwelyd bloc cof mwy na'r hyn a ofynnwyd.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Gwiriwch sancteiddrwydd hanner y gofyniad diogelwch (ni allwn wirio'r hanner arall).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Rydym yn osgoi `unwrap_or_else` yma oherwydd ei fod yn chwyddo faint o IR LLVM a gynhyrchir.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Yn ailgyfansoddi `RawVec` o bwyntydd, capasiti a dyrannwr.
    ///
    /// # Safety
    ///
    /// Rhaid dyrannu'r `ptr` (trwy'r dyrannwr `alloc` a roddir), a chyda'r `capacity` a roddir.
    /// Ni all yr `capacity` fod yn fwy na `isize::MAX` ar gyfer mathau o faint.
    /// (Dim ond yn bryder ar systemau 32-bit).
    /// Efallai y bydd gan ZST vectors gapasiti hyd at `usize::MAX`.
    /// Os bydd y `ptr` a `capacity` yn dod o `RawVec` a grëwyd drwy `alloc`, yna mae hyn yn cael ei warantu.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Cael pwyntydd amrwd i ddechrau'r dyraniad.
    /// Sylwch mai `Unique::dangling()` yw hwn os yw `capacity == 0` neu `T` o faint sero.
    /// Yn yr achos blaenorol, rhaid i chi fod yn ofalus.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Cael gallu'r dyraniad.
    ///
    /// Bydd hyn bob amser yn `usize::MAX` os yw `T` o faint sero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Yn dychwelyd cyfeiriad a rennir at y dyrannwr sy'n cefnogi'r `RawVec` hwn.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Mae gennym ddarn o gof wedi'i ddyrannu, felly gallwn osgoi gwiriadau rhedeg i gael ein cynllun cyfredol.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Yn sicrhau bod y byffer yn cynnwys o leiaf ddigon o le i ddal elfennau `len + additional`.
    /// Os nad oes ganddo ddigon o gapasiti eisoes, bydd yn ailddyrannu digon o le ynghyd â lle llac cyfforddus i gael ymddygiad amorteiddiedig *O*(1).
    ///
    /// Bydd yn cyfyngu'r ymddygiad hwn pe bai'n achosi ei hun yn ddiangen i panic.
    ///
    /// Os yw `len` yn fwy na `self.capacity()`, gall hyn fethu â dyrannu'r lle y gofynnwyd amdano.
    /// Nid yw hyn yn anniogel mewn gwirionedd, ond gall y cod anniogel * rydych chi'n ei ysgrifennu sy'n dibynnu ar ymddygiad y swyddogaeth hon dorri.
    ///
    /// Mae hyn yn ddelfrydol ar gyfer gweithredu gweithrediad gwthio-swmp fel `extend`.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn fwy na beit `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Erthyliadau ar OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // byddai'r gronfa wrth gefn wedi erthylu neu banicio pe bai'r len yn fwy na `isize::MAX` felly mae'n ddiogel gwneud hyn heb ei wirio nawr.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Yr un peth â `reserve`, ond mae'n dychwelyd ar wallau yn lle mynd i banig neu erthylu.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Yn sicrhau bod y byffer yn cynnwys o leiaf ddigon o le i ddal elfennau `len + additional`.
    /// Os nad yw eisoes, bydd yn ailddyrannu'r lleiafswm cof sy'n angenrheidiol.
    /// Yn gyffredinol, bydd hyn yn union faint o gof sy'n angenrheidiol, ond mewn egwyddor mae'r dyrannwr yn rhydd i roi mwy yn ôl nag y gwnaethom ofyn amdano.
    ///
    ///
    /// Os yw `len` yn fwy na `self.capacity()`, gall hyn fethu â dyrannu'r lle y gofynnwyd amdano.
    /// Nid yw hyn yn anniogel mewn gwirionedd, ond gall y cod anniogel * rydych chi'n ei ysgrifennu sy'n dibynnu ar ymddygiad y swyddogaeth hon dorri.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn fwy na beit `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Erthyliadau ar OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Yr un peth â `reserve_exact`, ond mae'n dychwelyd ar wallau yn lle mynd i banig neu erthylu.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Yn crebachu'r dyraniad i lawr i'r swm penodedig.
    /// Os yw'r swm a roddir yn 0, mewn gwirionedd yn deallocates yn llwyr.
    ///
    /// # Panics
    ///
    /// Panics os yw'r swm a roddir yn *fwy* na'r capasiti cyfredol.
    ///
    /// # Aborts
    ///
    /// Erthyliadau ar OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Yn dychwelyd os oes angen i'r byffer dyfu i gyflawni'r capasiti ychwanegol sydd ei angen.
    /// Defnyddir yn bennaf i wneud galwadau wrth gefn llinellol yn bosibl heb amlinellu `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Mae'r dull hwn fel arfer yn cael ei gyflymu lawer gwaith.Felly rydyn ni am iddo fod mor fach â phosib, er mwyn gwella amseroedd llunio.
    // Ond rydym hefyd eisiau i gymaint o'i gynnwys fod yn statudol y gellir ei gyfrifo â phosibl, er mwyn gwneud i'r cod a gynhyrchir redeg yn gyflymach.
    // Felly, mae'r dull hwn wedi'i ysgrifennu'n ofalus fel bod yr holl god sy'n dibynnu ar `T` ynddo, tra bod cymaint o'r cod nad yw'n dibynnu ar `T` â phosibl mewn swyddogaethau nad ydynt yn generig dros `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Sicrheir hyn gan y cyd-destunau galw.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ers i ni ddychwelyd cynhwysedd o `usize::MAX` pan fydd `elem_size`
            // 0, mynd i fan hyn o reidrwydd yn golygu bod y `RawVec` yn orlawn.
            return Err(CapacityOverflow);
        }

        // Yn anffodus, dim byd y gallwn ei wneud ynglŷn â'r gwiriadau hyn.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Mae hyn yn gwarantu twf esbonyddol.
        // Ni all y dyblu orlifo oherwydd `cap <= isize::MAX` a'r math o `cap` yw `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` yn an-generig dros `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Mae'r cyfyngiadau ar y dull hwn yn debyg iawn i'r rhai ar `grow_amortized`, ond mae'r dull hwn fel arfer yn cael ei gyflymu yn llai aml felly mae'n llai beirniadol.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ers i ni ddychwelyd gapasiti o `usize::MAX` pan fydd y maint math yn
            // 0, mynd i fan hyn o reidrwydd yn golygu bod y `RawVec` yn orlawn.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` yn an-generig dros `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Mae'r swyddogaeth hon y tu allan i `RawVec` i leihau amseroedd llunio.Gweler y sylw uchod `RawVec::grow_amortized` am fanylion.
// (Nid yw'r paramedr `A` yn arwyddocaol, oherwydd mae nifer y gwahanol fathau `A` a welir yn ymarferol yn llawer llai na nifer y mathau `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Gwiriwch am y gwall yma i leihau maint `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Mae'r dyrannwr yn gwirio cydraddoldeb aliniad
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Frees y cof eiddo i'r `RawVec`*heb* ceisio i ollwng ei gynnwys.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Swyddogaeth ganolog ar gyfer trin gwallau wrth gefn.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Mae angen i ni warantu'r canlynol:
// * Nid ydym byth yn dyrannu gwrthrychau maint beit `> isize::MAX`.
// * Nid ydym yn gorlifo `usize::MAX` ac yn dyrannu rhy ychydig mewn gwirionedd.
//
// Ar 64-bit, mae angen i ni wirio am orlif gan y bydd ceisio dyrannu beit `> isize::MAX` yn sicr o fethu.
// Ar 32-bit ac 16-bit mae angen i ni ychwanegu gard ychwanegol ar gyfer hyn rhag ofn ein bod ni'n rhedeg ar blatfform a all ddefnyddio'r 4GB i gyd mewn gofod defnyddiwr, ee PAE neu x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Un swyddogaeth ganolog gyfrifol am adrodd gorlifo capasiti.
// Bydd hyn yn sicrhau bod y cynhyrchiad cod sy'n gysylltiedig â'r panics hyn yn fach iawn gan mai dim ond un lleoliad sydd â panics yn hytrach na chriw trwy'r modiwl.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}