// Dyma ymgais i weithredu yn dilyn y ddelfryd
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Gan nad oes gan Rust fathau dibynnol a dychweliad polymorffig, rydym yn ymwneud â llawer o anniogelrwydd.
//

// Un o brif nodau'r modiwl hwn yw osgoi cymhlethdod trwy drin y goeden fel cynhwysydd generig (os yw'n siâp rhyfedd) ac osgoi delio â'r rhan fwyaf o'r invariants B-Tree.
//
// Yn hynny o beth, nid yw'r modiwl hwn yn poeni a yw'r cofnodion yn cael eu didoli, pa nodau all fod yn danddaearol, neu hyd yn oed yr hyn y mae tanddwr yn ei olygu.Fodd bynnag, rydym yn dibynnu ar ychydig o invariants:
//
// - Rhaid bod gan goed depth/height unffurf.Mae hyn yn golygu bod gan bob llwybr i lawr i ddeilen o nod penodol yr un hyd yn union.
// - Mae gan nod o hyd `n` allweddi `n`, gwerthoedd `n`, ac ymylon `n + 1`.
//   Mae hyn yn awgrymu bod gan hyd yn oed nod gwag o leiaf un edge.
//   Ar gyfer nod dail, mae "having an edge" yn golygu y gallwn nodi safle yn y nod yn unig, gan fod ymylon dail yn wag ac nid oes angen cynrychiolaeth data arnynt.
// Mewn nod mewnol, mae edge yn nodi safle ac yn cynnwys pwyntydd i nod plentyn.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Cynrychiolaeth sylfaenol nodau dail a rhan o gynrychiolaeth nodau mewnol.
struct LeafNode<K, V> {
    /// Rydym am fod yn gyfochrog yn `K` a `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Mynegai y nod hwn i mewn i arae `edges` y nod rhiant.
    /// `*node.parent.edges[node.parent_idx]` dylai fod yr un peth â `node`.
    /// Dim ond pan fydd `parent` yn ddi-null y mae hyn yn sicr o gael ei gychwyn.
    parent_idx: MaybeUninit<u16>,

    /// Nifer yr allweddi a'r gwerthoedd y mae'r nod hwn yn eu storio.
    len: u16,

    /// Y araeau sy'n storio data gwirioneddol y nod.
    /// Dim ond yr elfennau `len` cyntaf o bob arae sy'n cychwynnol ac yn ddilys.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Yn cychwyn `LeafNode` newydd yn ei le.
    unsafe fn init(this: *mut Self) {
        // Fel polisi cyffredinol, rydym yn gadael caeau heb eu datganoli os gallant fod, gan y dylai hyn fod ychydig yn gyflymach ac yn haws i'w olrhain yn Valgrind.
        //
        unsafe {
            // mae parent_idx, allweddi, a vals i gyd yn MayUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Yn creu `LeafNode` mewn bocs newydd.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Cynrychiolaeth sylfaenol nodau mewnol.Yn yr un modd â `LeafNode`s, dylid cuddio'r rhain y tu ôl i`BoxedNode`s i atal gollwng allweddi a gwerthoedd heb eu datganoli.
/// Gellir casio unrhyw bwyntydd i `InternalNode` yn uniongyrchol i bwyntydd i ran sylfaenol `LeafNode` y nod, gan ganiatáu i'r cod weithredu ar nodau dail a mewnol yn gyffredinol heb orfod gwirio hyd yn oed pa un o'r ddau y mae pwyntydd yn pwyntio atynt.
///
/// Mae'r eiddo hwn wedi'i alluogi trwy ddefnyddio `repr(C)`.
///
#[repr(C)]
// gdb_providers.py yn defnyddio'r enw math hwn ar gyfer mewnblannu.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Yr awgrymiadau i blant y nod hwn.
    /// `len + 1` ystyrir bod y rhain yn rhai cychwynnol a dilys, ac eithrio'r hyn sy'n agos at y diwedd, tra bod y goeden yn cael ei dal trwy fenthyg math `Dying`, mae rhai o'r awgrymiadau hyn yn hongian.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Yn creu `InternalNode` mewn bocs newydd.
    ///
    /// # Safety
    /// Un o nodau mewnol yw bod ganddyn nhw o leiaf un edge cychwynnol a dilys.
    /// Nid yw'r swyddogaeth hon yn sefydlu edge o'r fath.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Nid oes ond angen i ni gychwyn y data;yr ymylon yw MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Pwyntydd di-null wedi'i reoli i nod.Mae hwn naill ai'n pwyntydd sy'n eiddo i `LeafNode<K, V>` neu'n bwyntydd sy'n eiddo i `InternalNode<K, V>`.
///
/// Fodd bynnag, nid yw `BoxedNode` yn cynnwys unrhyw wybodaeth ynghylch pa un o'r ddau fath o nodau sydd ynddo mewn gwirionedd, ac, yn rhannol oherwydd y diffyg gwybodaeth hwn, nid yw'n fath ar wahân ac nid oes ganddo ddistryw.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Nod gwraidd coeden sy'n eiddo.
///
/// Sylwch nad oes gan hwn ddistryw, a rhaid ei lanhau â llaw.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Yn dychwelyd coeden newydd dan berchnogaeth, gyda'i nod gwraidd ei hun sy'n wag i ddechrau.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` rhaid iddo beidio â bod yn sero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Yn benthyg y nod gwraidd sy'n eiddo iddo.
    /// Yn wahanol i `reborrow_mut`, mae hyn yn ddiogel oherwydd ni ellir defnyddio'r gwerth dychwelyd i ddinistrio'r gwreiddyn, ac ni all fod cyfeiriadau eraill at y goeden.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mae ychydig yn fenthyca'n benthyg y nod gwraidd sy'n eiddo iddo.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Trosi yn anadferadwy i gyfeirnod sy'n caniatáu croesi ac yn cynnig dulliau dinistriol a fawr ddim arall.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Yn ychwanegu nod mewnol newydd gydag un edge yn pwyntio at y nod gwraidd blaenorol, gwnewch y nod newydd hwnnw'n nod y gwreiddyn, a'i ddychwelyd.
    /// Mae hyn yn cynyddu'r uchder o 1 ac i'r gwrthwyneb i `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, eithrio ein bod newydd wedi anghofio rydym yn fewnol yn awr:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Yn dileu'r nod gwreiddiau mewnol, gan ddefnyddio ei blentyn cyntaf fel y nod gwraidd newydd.
    /// Gan mai dim ond un plentyn y bwriedir ei alw, dim ond un plentyn sydd gan y nod gwraidd, ni wneir unrhyw lanhau ar unrhyw un o'r allweddi, y gwerthoedd a phlant eraill.
    ///
    /// Mae hyn yn gostwng yr uchder o 1 ac i'r gwrthwyneb i `push_internal_level`.
    ///
    /// Yn gofyn am fynediad unigryw i'r gwrthrych `Root` ond nid i'r nod gwraidd;
    /// ni fydd yn annilysu dolenni na chyfeiriadau eraill at y nod gwraidd.
    ///
    /// Panics os nad oes lefel fewnol, hy, os yw'r nod gwraidd yn ddeilen.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // DIOGELWCH: roeddem yn honni ein bod yn fewnol.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // DIOGELWCH: gwnaethom fenthyg `self` yn unig ac mae ei fath o fenthyg yn unigryw.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // DIOGELWCH: mae'r edge cyntaf bob amser yn cael ei ymsefydlu.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Mae `NodeRef` bob amser yn gyfochrog yn `K` a `V`, hyd yn oed pan fo'r `BorrowType` yn `Mut`.
// Mae hyn yn dechnegol anghywir, ond ni all arwain at unrhyw ansicrwydd oherwydd defnydd mewnol o `NodeRef` oherwydd ein bod yn aros yn hollol generig dros `K` a `V`.
//
// Fodd bynnag, pryd bynnag y mae math cyhoeddus yn lapio `NodeRef`, gwnewch yn siŵr bod ganddo'r amrywiant cywir.
//
/// Cyfeiriad at nod.
///
/// Mae gan y math hwn nifer o baramedrau sy'n rheoli sut mae'n gweithredu:
/// - `BorrowType`: Math dymi sy'n disgrifio'r math o fenthyg ac sy'n cario oes.
///    - Pan mai `Immut<'a>` yw hwn, mae'r `NodeRef` yn gweithredu'n fras fel `&'a Node`.
///    - Pan mai `ValMut<'a>` yw hwn, mae'r `NodeRef` yn gweithredu'n fras fel `&'a Node` mewn perthynas ag allweddi a strwythur coed, ond mae hefyd yn caniatáu i lawer o gyfeiriadau symudol at werthoedd trwy'r goeden gydfodoli.
///    - Pan mai `Mut<'a>` yw hwn, mae'r `NodeRef` yn gweithredu'n fras fel `&'a mut Node`, er bod dulliau mewnosod yn caniatáu pwyntydd symudol i werth gydfodoli.
///    - Pan mai `Owned` yw hwn, mae'r `NodeRef` yn gweithredu'n fras fel `Box<Node>`, ond nid oes ganddo ddistryw, a rhaid ei lanhau â llaw.
///    - Pan mai `Dying` yw hwn, mae'r `NodeRef` yn dal i weithredu'n fras fel `Box<Node>`, ond mae ganddo ddulliau i ddinistrio'r goeden fesul tipyn, a gall dulliau cyffredin, er nad ydynt wedi'u marcio fel rhai anniogel i'w galw, alw UB os caiff ei galw'n anghywir.
///
///   Gan fod unrhyw `NodeRef` yn caniatáu llywio trwy'r goeden, mae `BorrowType` i bob pwrpas yn berthnasol i'r goeden gyfan, nid dim ond i'r nod ei hun.
/// - `K` a `V`: Dyma'r mathau o allweddi a gwerthoedd sy'n cael eu storio yn y nodau.
/// - `Type`: Gall hyn fod yn `Leaf`, `Internal`, neu `LeafOrInternal`.
/// Pan mai `Leaf` yw hwn, mae'r `NodeRef` yn pwyntio at nod dail, pan mai hwn yw `Internal` mae'r `NodeRef` yn pwyntio at nod mewnol, a phan mai hwn yw `LeafOrInternal` gallai'r `NodeRef` fod yn pwyntio at y naill fath neu'r llall o nod.
///   `Type` yn cael ei enwi'n `NodeType` pan gaiff ei ddefnyddio y tu allan i `NodeRef`.
///
/// Mae `BorrowType` a `NodeType` yn cyfyngu pa ddulliau a weithredwn, er mwyn manteisio ar ddiogelwch math statig.Mae cyfyngiadau yn y ffordd y gallwn gymhwyso cyfyngiadau o'r fath:
/// - Ar gyfer pob paramedr math, dim ond naill ai'n gyffredinol neu ar gyfer un math penodol y gallwn ddiffinio dull.
/// Er enghraifft, ni allwn ddiffinio dull fel `into_kv` yn gyffredinol ar gyfer pob `BorrowType`, neu unwaith ar gyfer pob math sy'n cario oes, oherwydd rydym am iddo ddychwelyd cyfeiriadau `&'a`.
///   Felly, rydym yn ei ddiffinio ar gyfer y math lleiaf pwerus `Immut<'a>` yn unig.
/// - Ni allwn gael gorfodaeth ymhlyg o ddweud `Mut<'a>` i `Immut<'a>`.
///   Felly, mae'n rhaid i ni ffonio `reborrow` yn benodol ar `NodeRef` mwy pwerus er mwyn cyrraedd dull fel `into_kv`.
///
/// Pob dull ar `NodeRef` sy'n dychwelyd rhyw fath o gyfeirnod, naill ai:
/// - Cymerwch `self` yn ôl gwerth, a dychwelwch yr oes a gariwyd gan `BorrowType`.
///   Weithiau, er mwyn defnyddio dull o'r fath, mae angen i ni ffonio `reborrow_mut`.
/// - Cymerwch `self` trwy gyfeirio, ac mae (implicitly) yn dychwelyd oes y cyfeirnod hwnnw, yn lle'r oes a gludir gan `BorrowType`.
/// Trwy hynny, mae'r gwiriwr benthyg yn gwarantu bod yr `NodeRef` yn parhau i gael ei fenthyg cyhyd â bod y cyfeirnod a ddychwelwyd yn cael ei ddefnyddio.
///   Mae'r dulliau sy'n cefnogi mewnosod yn plygu'r rheol hon trwy ddychwelyd pwyntydd amrwd, hy cyfeirnod heb unrhyw oes.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Nifer y lefelau y mae'r nod a lefel y dail ar wahân, cysonyn o'r nod na ellir ei ddisgrifio'n llwyr gan `Type`, ac nad yw'r nod ei hun yn storio.
    /// Nid oes ond angen i ni storio uchder y nod gwraidd, a chael uchder pob nod arall ohono.
    /// Rhaid iddo fod yn sero os yw `Type` yn `Leaf` ac yn ddi-sero os yw `Type` yn `Internal`.
    ///
    ///
    height: usize,
    /// Y pwyntydd i'r ddeilen neu'r nod mewnol.
    /// Mae'r diffiniad o `InternalNode` yn sicrhau bod y pwyntydd yn ddilys y naill ffordd neu'r llall.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Dadbaciwch gyfeirnod nod a oedd wedi'i bacio fel `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Yn datgelu data nod mewnol.
    ///
    /// Yn dychwelyd ptr amrwd er mwyn osgoi annilysu cyfeiriadau eraill at y nod hwn.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // DIOGELWCH: y math nod statig yw `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Yn benthyca mynediad unigryw i ddata nod mewnol.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Yn darganfod hyd y nod.Dyma nifer yr allweddi neu'r gwerthoedd.
    /// Nifer yr ymylon yw `len() + 1`.
    /// Sylwch, er ei fod yn ddiogel, gall galw'r swyddogaeth hon gael sgil-effaith annilysu cyfeiriadau symudol y mae cod anniogel wedi'u creu.
    ///
    pub fn len(&self) -> usize {
        // Yn hanfodol, dim ond yma yr ydym yn cyrchu'r maes `len`.
        // Os yw BorrowType yn marker::ValMut, efallai y bydd cyfeiriadau symudol tuag at werthoedd na ddylem eu hannilysu.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Yn dychwelyd nifer y lefelau y mae'r nod a'r dail ar wahân.
    /// Mae uchder sero yn golygu bod y nod yn ddeilen ei hun.
    /// Os ydych chi'n darlunio coed gyda'r gwreiddyn ar ei ben, mae'r rhif yn dweud ar ba ddrychiad mae'r nod yn ymddangos.
    /// Os ydych chi'n darlunio coed gyda dail ar ei ben, mae'r rhif yn dweud pa mor uchel mae'r goeden yn ymestyn uwchben y nod.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Dros dro yn cymryd cyfeiriad arall na ellir ei symud at yr un nod.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Yn datgelu cyfran ddeilen unrhyw ddeilen neu nod mewnol.
    ///
    /// Yn dychwelyd ptr amrwd er mwyn osgoi annilysu cyfeiriadau eraill at y nod hwn.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Rhaid i'r nod fod yn ddilys am y gyfran LeafNode o leiaf.
        // Nid yw hwn yn gyfeiriad yn y math NodeRef oherwydd nid ydym yn gwybod a ddylai fod yn unigryw neu wedi'i rannu.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Yn dod o hyd i riant y nod cyfredol.
    /// Yn dychwelyd `Ok(handle)` os oes gan y nod cyfredol riant mewn gwirionedd, lle mae `handle` yn pwyntio at edge y rhiant sy'n pwyntio at y nod cyfredol.
    ///
    /// Yn dychwelyd `Err(self)` os nad oes gan y nod cyfredol riant, gan roi'r `NodeRef` gwreiddiol yn ôl.
    ///
    /// Mae enw'r dull yn tybio eich bod chi'n darlunio coed gyda'r nod gwraidd ar ei ben.
    ///
    /// `edge.descend().ascend().unwrap()` a dylai `node.ascend().unwrap().descend()` ill dau, ar ôl llwyddo, wneud dim.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mae angen i ni ddefnyddio awgrymiadau amrwd i nodau oherwydd, os yw BorrowType yn marker::ValMut, efallai y bydd cyfeiriadau symudol tuag at werthoedd na ddylem eu hannilysu.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Sylwch fod yn rhaid i `self` fod yn ddiamwys.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Sylwch fod yn rhaid i `self` fod yn ddiamwys.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Yn datgelu cyfran ddeilen unrhyw ddeilen neu nod mewnol mewn coeden na ellir ei symud.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // DIOGELWCH: ni all fod unrhyw gyfeiriadau symudol at y goeden hon a fenthycwyd fel `Immut`.
        unsafe { &*ptr }
    }

    /// Yn benthyg golygfa i'r allweddi sydd wedi'u storio yn y nod.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Yn debyg i `ascend`, yn cael cyfeiriad at nod rhiant nod, ond mae hefyd yn deall y nod cyfredol yn y broses.
    /// Mae hyn yn anniogel oherwydd bydd y nod cyfredol yn dal i fod yn hygyrch er gwaethaf ei ddeall.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Yn anniogel yn honni i'r casglwr y wybodaeth statig bod y nod hwn yn `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Yn anniogel yn honni i'r casglwr y wybodaeth statig bod y nod hwn yn `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Mae dros dro yn cymryd cyfeiriad arall y gellir ei newid at yr un nod.Gwyliwch, gan fod y dull hwn yn beryglus iawn, yn ddyblyg felly oherwydd efallai na fydd yn ymddangos yn beryglus ar unwaith.
    ///
    /// Oherwydd y gall awgrymiadau symudol grwydro unrhyw le o amgylch y goeden, mae'n hawdd defnyddio'r pwyntydd a ddychwelwyd i wneud y pwyntydd gwreiddiol yn hongian, allan o ffiniau, neu'n annilys o dan reolau benthyca wedi'u pentyrru.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) ystyried ychwanegu eto paramedr fath arall i `NodeRef` sy'n cyfyngu ar y defnydd o ddulliau llywio ar awgrymiadau reborrowed, atal unsafety hwn.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Yn benthyca mynediad unigryw i ran ddeilen unrhyw ddeilen neu nod mewnol.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // DIOGELWCH: mae gennym fynediad unigryw i'r nod cyfan.
        unsafe { &mut *ptr }
    }

    /// Mae'n cynnig mynediad unigryw i ran dail unrhyw ddeilen neu nod mewnol.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // DIOGELWCH: mae gennym fynediad unigryw i'r nod cyfan.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Yn benthyca mynediad unigryw i elfen o'r ardal storio allweddol.
    ///
    /// # Safety
    /// `index` mewn ffiniau o 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // DIOGELWCH: ni fydd y galwr yn gallu galw dulliau pellach arno'i hun
        // nes bod y cyfeirnod tafell allweddol yn cael ei ollwng, gan fod gennym fynediad unigryw am oes y benthyciad.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Yn benthyca mynediad unigryw i elfen neu dafell o ardal storio gwerth y nod.
    ///
    /// # Safety
    /// `index` mewn ffiniau o 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // DIOGELWCH: ni fydd y galwr yn gallu galw dulliau pellach arno'i hun
        // nes bod y cyfeirnod tafell gwerth yn cael ei ollwng, gan fod gennym fynediad unigryw am oes y benthyciad.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Yn benthyca mynediad unigryw i elfen neu dafell o ardal storio'r nod ar gyfer cynnwys edge.
    ///
    /// # Safety
    /// `index` mewn ffiniau o 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // DIOGELWCH: ni fydd y galwr yn gallu galw dulliau pellach arno'i hun
        // nes bod cyfeirnod sleisen edge yn cael ei ollwng, gan fod gennym fynediad unigryw am oes y benthyciad.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Mae gan y nod fwy na elfennau cychwynnol `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Nid ydym ond yn creu cyfeiriad at yr un elfen y mae gennym ddiddordeb ynddo, er mwyn osgoi cyd-fynd â chyfeiriadau rhagorol at elfennau eraill, yn benodol, y rhai a ddychwelwyd at y galwr mewn iteriadau cynharach.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rhaid i ni orfodi i awgrymiadau arae heb eu maint oherwydd Rust rhifyn #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Yn benthyca mynediad unigryw i hyd y nod.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Yn gosod cyswllt y nod â'i riant edge, heb annilysu cyfeiriadau eraill at y nod.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Yn clirio cyswllt y gwreiddyn â'i riant edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Yn ychwanegu pâr gwerth allweddol at ddiwedd y nod.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Mae pob eitem a ddychwelir gan `range` yn fynegai edge dilys ar gyfer y nod.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Yn ychwanegu pâr gwerth allweddol, a edge i fynd i'r dde o'r pâr hwnnw, i ddiwedd y nod.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Yn gwirio a yw nod yn nod `Internal` neu'n nod `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Cyfeiriad at bâr gwerth allweddol penodol neu edge o fewn nod.
/// Rhaid i'r paramedr `Node` fod yn `NodeRef`, tra gall yr `Type` naill ai fod yn `KV` (yn dynodi handlen ar bâr gwerth allweddol) neu'n `Edge` (yn dynodi handlen ar edge).
///
/// Sylwch y gall hyd yn oed nodau `Leaf` gael dolenni `Edge`.
/// Yn lle cynrychioli pwyntydd i nod plentyn, mae'r rhain yn cynrychioli'r lleoedd lle byddai awgrymiadau plant yn mynd rhwng y parau gwerth allweddol.
/// Er enghraifft, mewn nod â hyd 2, byddai 3 lleoliad edge posib, un i'r chwith o'r nod, un rhwng y ddau bâr, ac un ar ochr dde'r nod.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Nid oes angen cyffredinolrwydd llawn `#[derive(Clone)]` arnom, oherwydd yr unig amser y bydd `Node` yn `Clôn` yw pan fydd yn gyfeirnod na ellir ei symud ac felly `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Yn adfer y nod sy'n cynnwys y edge neu'r pâr gwerth allweddol y mae'r handlen hon yn pwyntio atynt.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Yn dychwelyd lleoliad yr handlen hon yn y nod.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Yn creu handlen newydd i bâr gwerth allweddol yn `node`.
    /// Anniogel oherwydd rhaid i'r galwr sicrhau bod `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Gallai fod yn weithred gyhoeddus o PartialEq, ond dim ond yn y modiwl hwn y caiff ei ddefnyddio.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Dros dro yn cymryd handlen arall na ellir ei symud yn yr un lleoliad.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ni allwn ddefnyddio Handle::new_kv neu Handle::new_edge oherwydd nid ydym yn gwybod ein math
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Yn anniogel yn honni i'r casglwr y wybodaeth statig mai nod yr handlen yw `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Mae dros dro yn cymryd handlen arall y gellir ei symud yn yr un lleoliad.
    /// Gwyliwch, gan fod y dull hwn yn beryglus iawn, yn ddyblyg felly oherwydd efallai na fydd yn ymddangos yn beryglus ar unwaith.
    ///
    ///
    /// Am fanylion, gweler `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ni allwn ddefnyddio Handle::new_kv neu Handle::new_edge oherwydd nid ydym yn gwybod ein math
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Yn creu handlen newydd i edge yn `node`.
    /// Anniogel oherwydd rhaid i'r galwr sicrhau bod `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// O ystyried mynegai edge lle rydym am ei fewnosod mewn nod wedi'i lenwi i'w gapasiti, mae'n cyfrifo mynegai KV synhwyrol o bwynt hollt a ble i gyflawni'r mewnosodiad.
///
/// Nod y pwynt rhannu yw i'w allwedd a'i werth ddod i ben mewn nod rhiant;
/// mae'r allweddi, y gwerthoedd a'r ymylon i'r chwith o'r pwynt hollti yn dod yn blentyn chwith;
/// mae'r allweddi, y gwerthoedd a'r ymylon i'r dde o'r pwynt hollti yn dod yn blentyn iawn.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Mae rhifyn Rust #74834 yn ceisio egluro'r rheolau cymesur hyn.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Yn mewnosod pâr gwerth allweddol newydd rhwng y parau gwerth allweddol i'r dde ac i'r chwith o'r edge hwn.
    /// Mae'r dull hwn yn tybio bod digon o le yn y nod i'r pâr newydd ffitio.
    ///
    /// Mae'r pwyntydd a ddychwelwyd yn pwyntio at y gwerth a fewnosodwyd.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Yn mewnosod pâr gwerth allweddol newydd rhwng y parau gwerth allweddol i'r dde ac i'r chwith o'r edge hwn.
    /// Mae'r dull hwn yn rhannu'r nod os nad oes digon o le.
    ///
    /// Mae'r pwyntydd a ddychwelwyd yn pwyntio at y gwerth a fewnosodwyd.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Yn trwsio'r pwyntydd rhiant a'r mynegai yn y nod plentyn y mae'r edge hwn yn cysylltu ag ef.
    /// Mae hyn yn ddefnyddiol pan fydd trefn yr ymylon wedi'i newid,
    fn correct_parent_link(self) {
        // Creu backpointer heb annilysu cyfeiriadau eraill at y nod.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Yn mewnosod pâr gwerth allweddol newydd a edge a fydd yn mynd i'r dde o'r pâr newydd hwnnw rhwng y edge hwn a'r pâr gwerth allweddol i'r dde o'r edge hwn.
    /// Mae'r dull hwn yn tybio bod digon o le yn y nod i'r pâr newydd ffitio.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Yn mewnosod pâr gwerth allweddol newydd a edge a fydd yn mynd i'r dde o'r pâr newydd hwnnw rhwng y edge hwn a'r pâr gwerth allweddol i'r dde o'r edge hwn.
    /// Mae'r dull hwn yn rhannu'r nod os nad oes digon o le.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Yn mewnosod pâr gwerth allweddol newydd rhwng y parau gwerth allweddol i'r dde ac i'r chwith o'r edge hwn.
    /// Mae'r dull hwn yn hollti'r nod os nad oes digon o le, ac yn ceisio mewnosod y rhan sydd wedi'i rhannu yn y rhiant nod yn gylchol, nes cyrraedd y gwreiddyn.
    ///
    ///
    /// Os yw'r canlyniad a ddychwelwyd yn `Fit`, gall nod ei handlen fod yn nod y edge hwn neu'n hynafiad.
    /// Os mai'r canlyniad a ddychwelwyd yw `Split`, y maes `left` fydd y nod gwraidd.
    /// Mae'r pwyntydd a ddychwelwyd yn pwyntio at y gwerth a fewnosodwyd.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Yn dod o hyd i'r nod y mae'r edge hwn yn cyfeirio ato.
    ///
    /// Mae enw'r dull yn tybio eich bod chi'n darlunio coed gyda'r nod gwraidd ar ei ben.
    ///
    /// `edge.descend().ascend().unwrap()` a dylai `node.ascend().unwrap().descend()` ill dau, ar ôl llwyddo, wneud dim.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mae angen i ni ddefnyddio awgrymiadau amrwd i nodau oherwydd, os yw BorrowType yn marker::ValMut, efallai y bydd cyfeiriadau symudol tuag at werthoedd na ddylem eu hannilysu.
        // Nid oes unrhyw bryder cyrchu'r cae uchder oherwydd copïir y gwerth hwnnw.
        // Gwyliwch, unwaith y bydd pwyntydd y nod wedi'i ddadreoleiddio, ein bod yn cyrchu'r arae ymylon gyda chyfeirnod (Rust rhifyn #73987) ac yn annilysu unrhyw gyfeiriadau eraill at yr arae neu y tu mewn iddi, pe bai unrhyw un o gwmpas.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ni allwn alw dulliau allweddol a gwerth ar wahân, oherwydd mae galw'r ail un yn annilysu'r cyfeirnod a ddychwelwyd gan y cyntaf.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Amnewid yr allwedd a'r gwerth y mae'r handlen KV yn cyfeirio atynt.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Yn helpu gweithrediadau `split` ar gyfer `NodeType` penodol, trwy ofalu am ddata dail.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Yn rhannu'r nod sylfaenol yn dair rhan:
    ///
    /// - Mae'r nod yn cael ei gwtogi i gynnwys y parau gwerth allweddol i'r chwith o'r handlen hon yn unig.
    /// - Mae'r allwedd a'r gwerth y mae'r handlen hon yn tynnu sylw atynt yn cael eu tynnu.
    /// - Mae'r holl barau gwerth allweddol i'r dde o'r handlen hon yn cael eu rhoi mewn nod sydd newydd ei ddyrannu.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Yn dileu'r pâr gwerth allweddol y mae'r handlen hon yn cyfeirio ato a'i ddychwelyd, ynghyd â'r edge y cwympodd y pâr gwerth allweddol iddo.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Yn rhannu'r nod sylfaenol yn dair rhan:
    ///
    /// - Mae'r nod yn cael ei gwtogi i gynnwys yr ymylon a'r parau gwerth allweddol i'r chwith o'r handlen hon yn unig.
    /// - Mae'r allwedd a'r gwerth y mae'r handlen hon yn tynnu sylw atynt yn cael eu tynnu.
    /// - Mae'r holl ymylon a'r parau gwerth allweddol i'r dde o'r handlen hon yn cael eu rhoi mewn nod sydd newydd ei ddyrannu.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Yn cynrychioli sesiwn ar gyfer gwerthuso a pherfformio gweithred gydbwyso o amgylch pâr gwerth allweddol mewnol.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Yn dewis cyd-destun cydbwyso sy'n cynnwys y nod fel plentyn, felly rhwng y KV yn syth i'r chwith neu i'r dde yn y nod rhiant.
    /// Yn dychwelyd `Err` os nad oes rhiant.
    /// Panics os yw'r rhiant yn wag.
    ///
    /// Mae'n well gan yr ochr chwith, i fod yn optimaidd os yw'r nod a roddir rywsut yn danddaearol, sy'n golygu yma dim ond bod ganddo lai o elfennau na'i frawd neu chwaer chwith a'i frawd neu chwaer dde, os ydyn nhw'n bodoli.
    /// Yn yr achos hwnnw, mae uno â'r brawd neu chwaer chwith yn gyflymach, gan mai dim ond elfennau N y nod sydd eu hangen arnom, yn lle eu symud i'r dde a symud mwy nag elfennau N o'ch blaen.
    /// Mae dwyn o'r brawd neu chwaer chwith hefyd yn gyflymach yn nodweddiadol, gan nad oes ond angen i ni symud elfennau N y nod i'r dde, yn lle symud o leiaf N o elfennau'r brawd neu chwaer i'r chwith.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Yn dychwelyd a yw uno yn bosibl, hy, a oes digon o le mewn nod i gyfuno'r KV canolog â'r ddau nod plentyn cyfagos.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Yn uno ac yn gadael i gau benderfynu beth i'w ddychwelyd.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // DIOGELWCH: mae uchder y nodau sy'n cael eu huno un islaw'r uchder
                // o nod y edge hwn, felly uwchlaw sero, felly maen nhw'n fewnol.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Yn uno pâr gwerth allweddol y rhiant a'r ddau nod plentyn cyfagos i nod y plentyn chwith ac yn dychwelyd y nod rhiant crebachlyd.
    ///
    ///
    /// Panics oni bai ein bod ni'n `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Yn uno pâr gwerth allweddol y rhiant a'r ddau nod plentyn cyfagos i nod y plentyn chwith ac yn dychwelyd y nod plentyn hwnnw.
    ///
    ///
    /// Panics oni bai ein bod ni'n `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Yn uno pâr gwerth allweddol y rhiant a'r ddau nod plentyn cyfagos i nod y plentyn chwith ac yn dychwelyd y ddolen edge yn y nod plentyn hwnnw lle daeth y plentyn wedi'i dracio edge i ben,
    ///
    ///
    /// Panics oni bai ein bod ni'n `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Yn tynnu pâr gwerth allweddol o'r plentyn chwith a'i roi yn storfa gwerth allweddol y rhiant, wrth wthio'r hen bâr gwerth allweddol i'r rhiant cywir.
    ///
    /// Yn dychwelyd handlen i'r edge yn y plentyn iawn sy'n cyfateb i ble y daeth y edge gwreiddiol a nodwyd gan `track_right_edge_idx` i ben.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Yn tynnu pâr gwerth allweddol o'r plentyn iawn a'i roi yn storfa gwerth allweddol y rhiant, wrth wthio'r hen bâr gwerth allweddol i'r rhiant chwith.
    ///
    /// Yn dychwelyd handlen i'r edge yn y plentyn chwith a nodwyd gan `track_left_edge_idx`, na symudodd.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Mae hyn yn dwyn tebyg i `steal_left` ond yn dwyn sawl elfen ar unwaith.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Gwnewch yn siŵr ein bod ni'n dwyn yn ddiogel.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Symud data dail.
            {
                // Gwnewch le i elfennau sydd wedi'u dwyn yn y plentyn iawn.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Symud elfennau o'r plentyn chwith i'r un dde.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Symudwch y pâr sydd wedi'i ddwyn fwyaf i'r rhiant.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Symud pâr gwerth allweddol rhiant i'r plentyn iawn.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gwneud lle ar gyfer ymylon wedi'u dwyn.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Dwyn ymylon.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Clôn cymesur `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Gwnewch yn siŵr ein bod ni'n dwyn yn ddiogel.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Symud data dail.
            {
                // Symudwch y pâr sydd wedi'i ddwyn fwyaf i'r rhiant.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Symud pâr gwerth allweddol rhiant i'r plentyn chwith.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Symud elfennau o'r plentyn iawn i'r un chwith.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Llenwch y bwlch lle roedd elfennau wedi'u dwyn yn arfer bod.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Dwyn ymylon.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Llenwch y bwlch lle roedd ymylon wedi'u dwyn yn arfer bod.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Yn dileu unrhyw wybodaeth statig gan honni bod y nod hwn yn nod `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Yn dileu unrhyw wybodaeth statig gan honni bod y nod hwn yn nod `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Yn gwirio a yw'r nod sylfaenol yn nod `Internal` neu'n nod `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Symudwch yr ôl-ddodiad ar ôl `self` o un nod i'r llall.Rhaid i `right` fod yn wag.
    /// Mae'r edge cyntaf o `right` yn aros yr un fath.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Canlyniad ei fewnosod, pan oedd angen i nod ehangu y tu hwnt i'w allu.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nod wedi'i newid yn y goeden bresennol gydag elfennau ac ymylon sy'n perthyn i'r chwith o `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Rhennir peth allwedd a gwerth, i'w fewnosod mewn man arall.
    pub kv: (K, V),
    // Nôd newydd, heb gysylltiad, gydag elfennau ac ymylon sy'n perthyn i'r dde o `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // P'un a yw cyfeiriadau nod o'r math hwn o fenthyg yn caniatáu croesi i nodau eraill yn y goeden.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Nid oes angen traversal, mae'n digwydd gan ddefnyddio canlyniad `borrow_mut`.
        // Trwy analluogi traversal, a chreu cyfeiriadau newydd at wreiddiau yn unig, gwyddom fod pob cyfeiriad o'r math `Owned` at nod gwraidd.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Mewnosod gwerth mewn tafell o elfennau cychwynnol ac yna un elfen heb ei datganoli.
///
/// # Safety
/// Mae gan y sleisen fwy nag elfennau `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Yn dileu ac yn dychwelyd gwerth o dafell o'r holl elfennau cychwynnol, gan adael ar ôl un elfen ddieithriad llusgo.
///
///
/// # Safety
/// Mae gan y sleisen fwy nag elfennau `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Yn symud yr elfennau mewn tafell `distance` swyddi i'r chwith.
///
/// # Safety
/// Mae gan y sleisen o leiaf elfennau `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Yn symud yr elfennau mewn tafell `distance` swyddi i'r dde.
///
/// # Safety
/// Mae gan y sleisen o leiaf elfennau `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Yn symud yr holl werthoedd o dafell o elfennau cychwynnol i dafell o elfennau heb eu datganoli, gan adael `src` ar ôl fel pob un heb ei ddynodi.
///
/// Yn gweithio fel `dst.copy_from_slice(src)` ond nid yw'n ei gwneud yn ofynnol i `T` fod yn `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;