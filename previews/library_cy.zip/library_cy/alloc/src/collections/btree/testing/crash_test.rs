use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Glasbrint ar gyfer achosion ffug o brofion damwain sy'n monitro digwyddiadau penodol.
/// Gellir ffurfweddu rhai achosion i panic ar ryw adeg.
/// Y digwyddiadau yw `clone`, `drop` neu rai `query` anhysbys.
///
/// Mae dymis prawf damweiniau yn cael eu nodi a'u harchebu gan id, felly gellir eu defnyddio fel allweddi mewn BTreeMap.
/// Nid yw'r gweithredu a ddefnyddir yn fwriadol yn dibynnu ar unrhyw beth a ddiffinnir yn y crate, ar wahân i'r `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Yn creu dyluniad ffug prawf damwain.Mae'r `id` yn pennu trefn a chydraddoldeb achosion.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Yn creu enghraifft o dymi prawf damwain sy'n cofnodi pa ddigwyddiadau y mae'n eu profi ac yn ddewisol panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Yn dychwelyd sawl gwaith mae enghreifftiau o'r dymi wedi'u clonio.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Ffurflenni sawl gwaith achosion o'r dymi wedi cael eu gollwng.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Yn dychwelyd sawl gwaith y cafodd ei aelod `query` ei alw yn achos y dymi.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Rhyw ymholiad dienw, y rhoddir ei ganlyniad eisoes.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}