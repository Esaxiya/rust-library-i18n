use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Yn atodi'r holl barau gwerth allweddol o undeb dau ailadroddwr esgynnol, gan gynyddu newidyn `length` ar hyd y ffordd.Mae'r olaf yn ei gwneud hi'n haws i'r galwr osgoi gollyngiad pan fydd triniwr gollwng yn panicio.
    ///
    /// Os yw'r ddau ailadroddwr yn cynhyrchu'r un allwedd, mae'r dull hwn yn gollwng y pâr o'r ailadroddwr chwith ac yn atodi'r pâr o'r ailadroddwr cywir.
    ///
    /// Os ydych chi am i'r goeden ddod i ben mewn trefn esgynnol hollol, fel ar gyfer `BTreeMap`, dylai'r ddau ailadroddwr gynhyrchu allweddi mewn trefn esgynnol yn llym, pob un yn fwy na'r holl allweddi yn y goeden, gan gynnwys unrhyw allweddi sydd eisoes yn y goeden wrth fynd i mewn.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Rydym yn paratoi i uno `left` a `right` i ddilyniant wedi'i ddidoli mewn amser llinellol.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Yn y cyfamser, rydyn ni'n adeiladu coeden o'r dilyniant wedi'i didoli mewn amser llinellol.
        self.bulk_push(iter, length)
    }

    /// Yn gwthio'r holl barau gwerth allweddol i ddiwedd y goeden, gan gynyddu newidyn `length` ar hyd y ffordd.
    /// Mae'r olaf yn ei gwneud hi'n haws i'r galwr osgoi gollyngiad pan fydd yr ailadroddwr yn mynd i banig.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterate trwy'r holl barau gwerth allweddol, gan eu gwthio i nodau ar y lefel gywir.
        for (key, value) in iter {
            // Ceisiwch wthio pâr gwerth allweddol i'r nod dail cyfredol.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Dim lle ar ôl, ewch i fyny a gwthio yno.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Wedi dod o hyd i nod gyda lle ar ôl, gwthiwch yma.
                                open_node = parent;
                                break;
                            } else {
                                // Ewch i fyny eto.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Rydyn ni ar y brig, yn creu nod gwraidd newydd ac yn gwthio yno.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Gwthiwch bâr gwerth allweddol ac is-radd dde newydd.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Ewch i lawr i'r ddeilen fwyaf cywir eto.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Hyd y cynnydd bob iteriad, er mwyn sicrhau bod y map yn gollwng yr elfennau atodol hyd yn oed os ydynt yn symud y panig ailadroddwr.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ailadroddwr ar gyfer uno dau ddilyniant wedi'u didoli yn un
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Os yw dwy allwedd yn gyfartal, dychwelwch y pâr gwerth allwedd o'r ffynhonnell gywir.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}