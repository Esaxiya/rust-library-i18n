use core::intrinsics;
use core::mem;
use core::ptr;

/// Mae hyn yn disodli'r gwerth y tu ôl i gyfeirnod unigryw `v` trwy ffonio'r swyddogaeth berthnasol.
///
///
/// Os bydd panic yn digwydd yn y cau `change`, bydd y broses gyfan yn cael ei erthylu.
#[allow(dead_code)] // cadwch fel enghraifft ac at ddefnydd future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Mae hyn yn disodli'r gwerth y tu ôl i gyfeirnod unigryw `v` trwy ffonio'r swyddogaeth berthnasol, ac mae'n dychwelyd canlyniad a gafwyd ar hyd y ffordd.
///
///
/// Os bydd panic yn digwydd yn y cau `change`, bydd y broses gyfan yn cael ei erthylu.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}