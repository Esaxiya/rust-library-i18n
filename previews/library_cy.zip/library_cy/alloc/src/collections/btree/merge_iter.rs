use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Craidd ailadroddwr sy'n uno allbwn dau ailadroddwr sy'n esgyn yn llym, er enghraifft undeb neu wahaniaeth cymesur.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Meincnodau yn gyflymach na lapio'r ddau ailadroddwr mewn Peekable, yn ôl pob tebyg oherwydd y gallwn fforddio gosod Rhwymwr Ffiws.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Yn creu craidd newydd ar gyfer ailadroddwr sy'n uno pâr o ffynonellau.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Yn dychwelyd y pâr nesaf o eitemau sy'n deillio o'r pâr o ffynonellau sy'n cael eu huno.
    /// Os yw'r ddau opsiwn a ddychwelwyd yn cynnwys gwerth, mae'r gwerth hwnnw'n gyfartal ac yn digwydd yn y ddwy ffynhonnell.
    /// Os yw un o'r opsiynau a ddychwelwyd yn cynnwys gwerth, nid yw'r gwerth hwnnw'n digwydd yn y ffynhonnell arall (neu nid yw'r ffynonellau'n esgyn yn llwyr).
    ///
    /// Os nad yw'r naill opsiwn neu'r llall yn dychwelyd gwerth, mae iteriad wedi gorffen a bydd galwadau dilynol yn dychwelyd yr un pâr gwag.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Yn dychwelyd pâr o ffiniau uchaf ar gyfer `size_hint` yr ailadroddwr terfynol.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}