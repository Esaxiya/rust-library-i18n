use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Yn tynnu pâr gwerth allweddol o'r goeden, ac yn dychwelyd y pâr hwnnw, yn ogystal â'r ddeilen edge sy'n cyfateb i'r cyn bâr hwnnw.
    /// Mae'n bosibl bod hyn yn gwagio nod gwraidd sy'n fewnol, y dylai'r galwr ei popio o'r map sy'n dal y goeden.
    /// Dylai'r galwr hefyd ostwng hyd y map.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Mae'n rhaid i ni anghofio'r math o blentyn dros dro, oherwydd nid oes math nod penodol ar gyfer rhieni uniongyrchol deilen.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // DIOGELWCH: `new_pos` yw'r ddeilen y gwnaethom ddechrau ohoni neu frawd neu chwaer.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Dim ond os gwnaethom uno, mae'r rhiant (os oes un) wedi crebachu, ond nid yw sgipio'r cam canlynol fel arall yn talu ar ei ganfed mewn meincnodau.
            //
            // DIOGELWCH: Ni fyddwn yn dinistrio nac aildrefnu'r ddeilen lle mae `pos`
            // trwy drin ei riant yn gylchol;ar y gwaethaf byddwn yn dinistrio neu'n aildrefnu'r rhiant trwy'r nain a'r taid, ac felly'n newid y ddolen i'r rhiant y tu mewn i'r ddeilen.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Tynnwch KV cyfagos o'i ddeilen ac yna ei roi yn ôl yn lle'r elfen y gofynnwyd i ni ei dynnu.
        //
        // Mae'n well gennych y KV chwith cyfagos, am y rhesymau a restrir yn `choose_parent_kv`.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Efallai bod y nod mewnol wedi'i ddwyn neu ei uno.
        // Ewch yn ôl i'r dde i ddarganfod ble daeth y KV gwreiddiol i ben.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}