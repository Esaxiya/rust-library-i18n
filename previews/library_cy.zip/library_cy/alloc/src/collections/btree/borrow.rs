use core::marker::PhantomData;
use core::ptr::NonNull;

/// Mae'n modelu ailgyfeiriad o ryw gyfeirnod unigryw, pan wyddoch na fydd yr ad-daliad a'i holl ddisgynyddion (h.y., yr holl awgrymiadau a chyfeiriadau sy'n deillio ohono) yn cael eu defnyddio mwyach ar ryw adeg, ac ar ôl hynny rydych chi am ddefnyddio'r cyfeirnod unigryw gwreiddiol eto .
///
///
/// Mae'r gwiriwr benthyca fel arfer yn delio â'r pentyrru hwn o fenthyciadau i chi, ond mae rhai llifau rheoli sy'n cyflawni'r pentyrru hwn yn rhy gymhleth i'r casglwr eu dilyn.
/// Mae `DormantMutRef` yn caniatáu ichi wirio benthyca eich hun, wrth barhau i fynegi ei natur wedi'i bentyrru, a chrynhoi'r cod pwyntydd amrwd sydd ei angen i wneud hyn heb ymddygiad heb ei ddiffinio.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Dal benthyciad unigryw, a'i ailgyflwyno ar unwaith.
    /// Ar gyfer y casglwr, mae oes y cyfeirnod newydd yr un peth ag oes y cyfeirnod gwreiddiol, ond rydych chi'n promise i'w ddefnyddio am gyfnod byrrach.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // DIOGELWCH: rydym yn dal y benthyciad trwy gydol 'a trwy `_marker`, ac rydym yn ei ddatgelu
        // dim ond y cyfeiriad hwn, felly mae'n unigryw.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Dychwelwch at y benthyciad unigryw a ddaliwyd i ddechrau.
    ///
    /// # Safety
    ///
    /// Rhaid i'r ad-daliad fod wedi dod i ben, hy, rhaid peidio â defnyddio'r cyfeirnod a ddychwelwyd gan `new` a'r holl awgrymiadau a chyfeiriadau sy'n deillio ohono.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // DIOGELWCH: mae ein hamodau diogelwch ein hunain yn awgrymu bod y cyfeirnod hwn yn unigryw unwaith eto.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;