//! Rhestr â chysylltiad dwbl â nodau dan berchnogaeth.
//!
//! Mae'r `LinkedList` yn caniatáu gwthio a phopio elfennau ar y naill ben a'r llall mewn amser cyson.
//!
//! NOTE: Mae bron bob amser yn well defnyddio [`Vec`] neu [`VecDeque`] oherwydd bod cynwysyddion sy'n seiliedig ar arae yn gyflymach ar y cyfan, yn fwy effeithlon o ran cof, ac yn gwneud defnydd gwell o storfa CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Rhestr â chysylltiad dwbl â nodau dan berchnogaeth.
///
/// Mae'r `LinkedList` yn caniatáu gwthio a phopio elfennau ar y naill ben a'r llall mewn amser cyson.
///
/// NOTE: Mae bron bob amser yn well defnyddio `Vec` neu `VecDeque` oherwydd bod cynwysyddion sy'n seiliedig ar arae yn gyflymach ar y cyfan, yn fwy effeithlon o ran cof, ac yn gwneud defnydd gwell o storfa CPU.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Ailadroddwr dros elfennau `LinkedList`.
///
/// Mae'r `struct` hwn yn cael ei greu gan [`LinkedList::iter()`].
/// Gweler ei ddogfennaeth am fwy.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Tynnu o blaid `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Ailadroddwr treiddgar dros elfennau `LinkedList`.
///
/// Mae'r `struct` hwn yn cael ei greu gan [`LinkedList::iter_mut()`].
/// Gweler ei ddogfennaeth am fwy.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Nid ydym * yn berchen ar y rhestr gyfan yn unig yma, mae cyfeiriadau at `element` y nod wedi'u dosbarthu gan yr ailadroddwr!Felly byddwch yn ofalus wrth ddefnyddio hwn;rhaid i'r dulliau a elwir fod yn ymwybodol y gall fod awgrymiadau gogwyddo at `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Ailadroddwr sy'n berchen ar elfennau `LinkedList`.
///
/// Mae'r `struct` hwn yn cael ei greu gan y dull [`into_iter`] ar [`LinkedList`] (a ddarperir gan yr `IntoIterator` trait).
/// Gweler ei ddogfennaeth am fwy.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// dulliau preifat
impl<T> LinkedList<T> {
    /// Yn ychwanegu'r nod a roddir i flaen y rhestr.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Mae'r dull hwn yn cymryd gofal i beidio â chreu cyfeiriadau symudol at nodau cyfan, er mwyn cynnal dilysrwydd awgrymiadau gwyro i mewn i `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Peidio â chreu cyfeiriadau (unique!) treiddgar newydd yn gorgyffwrdd `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Yn tynnu ac yn dychwelyd y nod ar flaen y rhestr.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Mae'r dull hwn yn cymryd gofal i beidio â chreu cyfeiriadau symudol at nodau cyfan, er mwyn cynnal dilysrwydd awgrymiadau gwyro i mewn i `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Peidio â chreu cyfeiriadau (unique!) treiddgar newydd yn gorgyffwrdd `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Yn ychwanegu'r nod a roddir i gefn y rhestr.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Mae'r dull hwn yn cymryd gofal i beidio â chreu cyfeiriadau symudol at nodau cyfan, er mwyn cynnal dilysrwydd awgrymiadau gwyro i mewn i `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Peidio â chreu cyfeiriadau (unique!) treiddgar newydd yn gorgyffwrdd `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Yn tynnu ac yn dychwelyd y nod yng nghefn y rhestr.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Mae'r dull hwn yn cymryd gofal i beidio â chreu cyfeiriadau symudol at nodau cyfan, er mwyn cynnal dilysrwydd awgrymiadau gwyro i mewn i `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Peidio â chreu cyfeiriadau (unique!) treiddgar newydd yn gorgyffwrdd `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Yn datgysylltu'r nod penodedig o'r rhestr gyfredol.
    ///
    /// Rhybudd: ni fydd hyn yn gwirio bod y nod a ddarperir yn perthyn i'r rhestr gyfredol.
    ///
    /// Mae'r dull hwn yn cymryd gofal i beidio â chreu cyfeiriadau mutable i `element`, er mwyn cynnal dilysrwydd aliasing awgrymiadau.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // yr un yma yn ein un ni yn awr, gallwn greu &mut.

        // Peidio â chreu cyfeiriadau (unique!) treiddgar newydd yn gorgyffwrdd `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // y nod hwn yw'r nod pen
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // y nod hwn yw nod y gynffon
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Yn rhannu cyfres o nodau rhwng dau nod sy'n bodoli.
    ///
    /// Rhybudd: ni fydd hyn yn gwirio bod y nod a ddarperir yn perthyn i'r ddwy restr bresennol.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Mae'r dull hwn yn cymryd gofal i beidio â chreu cyfeiriadau treiddgar lluosog at nodau cyfan ar yr un pryd, er mwyn cynnal dilysrwydd awgrymiadau gwyro i mewn i `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Yn canfod pob nod o restr gysylltiedig fel cyfres o nodau.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Y nod rhanedig yw nod pen newydd yr ail ran
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Trwsiwch ptr pen yr ail ran
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Y nod rhanedig yw nod cynffon newydd y rhan gyntaf ac mae'n berchen ar ben yr ail ran.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Trwsiwch y ptr cynffon o'r rhan gyntaf
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Yn creu `LinkedList<T>` gwag.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Yn creu `LinkedList` gwag.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Yn symud pob elfen o `other` i ddiwedd y rhestr.
    ///
    /// Mae hyn yn ailddefnyddio'r holl nodau o `other` ac yn eu symud i `self`.
    /// Ar ôl y llawdriniaeth hon, daw `other` yn wag.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(1) a *O*(1) cof.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` yn iawn yma oherwydd mae gennym fynediad unigryw i'r ddwy restr gyfan.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Yn symud pob elfen o `other` i ddechrau'r rhestr.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` yn iawn yma oherwydd mae gennym fynediad unigryw i'r ddwy restr gyfan.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Yn darparu ailadroddwr ymlaen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Mae'n darparu cyfeiriadau symudol i ailadroddwr ymlaen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Yn darparu cyrchwr yn yr elfen flaen.
    ///
    /// Mae'r cyrchwr yn pwyntio at yr elfen "ghost" os yw'r rhestr yn wag.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Mae'n darparu cyrchwr gyda gweithrediadau golygu yn yr elfen flaen.
    ///
    /// Mae'r cyrchwr yn pwyntio at yr elfen "ghost" os yw'r rhestr yn wag.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Yn darparu cyrchwr yn yr elfen gefn.
    ///
    /// Mae'r cyrchwr yn pwyntio at yr elfen "ghost" os yw'r rhestr yn wag.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Mae'n darparu cyrchwr gyda gweithrediadau golygu yn yr elfen gefn.
    ///
    /// Mae'r cyrchwr yn pwyntio at yr elfen "ghost" os yw'r rhestr yn wag.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Yn dychwelyd `true` os yw'r `LinkedList` yn wag.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Yn dychwelyd hyd yr `LinkedList`.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Yn tynnu pob elfen o'r `LinkedList`.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(*n*).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Yn dychwelyd `true` os yw'r `LinkedList` yn cynnwys elfen sy'n hafal i'r gwerth a roddir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Mae'n darparu cyfeiriad at yr elfen flaen, neu `None` os yw'r rhestr yn wag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Mae'n darparu cyfeiriad symudol at yr elfen flaen, neu `None` os yw'r rhestr yn wag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Mae'n darparu cyfeiriad at yr elfen gefn, neu `None` os yw'r rhestr yn wag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Mae'n darparu cyfeiriad symudol at yr elfen gefn, neu `None` os yw'r rhestr yn wag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Yn ychwanegu elfen yn gyntaf yn y rhestr.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Yn dileu'r elfen gyntaf a'i dychwelyd, neu `None` os yw'r rhestr yn wag.
    ///
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Yn atodi elfen i gefn rhestr.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Yn tynnu'r elfen olaf o restr a'i dychwelyd, neu `None` os yw'n wag.
    ///
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Yn rhannu'r rhestr yn ddwy yn y mynegai penodol.
    /// Yn dychwelyd popeth ar ôl y mynegai penodol, gan gynnwys y mynegai.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(*n*).
    ///
    /// # Panics
    ///
    /// Panics os `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Isod, rydym yn ailadrodd tuag at y nod `i-1`, naill ai o'r dechrau neu'r diwedd, yn dibynnu ar ba un fyddai'n gyflymach.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // yn lle sgipio gan ddefnyddio .skip() (sy'n creu strwythur newydd), rydyn ni'n sgipio â llaw er mwyn i ni allu cyrchu'r maes pen heb ddibynnu ar fanylion gweithredu Skip
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // gwell eich byd yn cychwyn o'r diwedd
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Yn dileu'r elfen ar y mynegai penodol a'i dychwelyd.
    ///
    /// Dylai'r llawdriniaeth hon gyfrifo mewn amser *O*(*n*).
    ///
    /// # Panics
    /// Panics os ar>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Isod, rydym yn ailadrodd tuag at y nod ar y mynegai penodol, naill ai o'r dechrau neu'r diwedd, yn dibynnu ar ba un fyddai'n gyflymach.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Yn creu ailadroddwr sy'n defnyddio cau i benderfynu a ddylid tynnu elfen.
    ///
    /// Os yw'r cau yn dychwelyd yn wir, yna caiff yr elfen ei thynnu a'i chynhyrchu.
    /// Os bydd y cau yn dychwelyd yn ffug, bydd yr elfen yn aros ar y rhestr ac ni fydd yr ailadroddwr yn ei rhoi.
    ///
    /// Sylwch fod `drain_filter` yn gadael ichi dreiglo pob elfen wrth gau'r hidlydd, ni waeth a ydych chi'n dewis ei gadw neu ei dynnu.
    ///
    ///
    /// # Examples
    ///
    /// Rhannu rhestr yn nosweithiau ac ods, gan ailddefnyddio'r rhestr wreiddiol:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // osgoi materion benthyca.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Parhewch â'r un ddolen a wnawn isod.Dim ond pan fydd dinistriwr wedi mynd i banig y mae hyn yn rhedeg.
                // Os yw un arall panics bydd hyn yn erthylu.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Angen oes ddi-rwym i gael 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Angen oes ddi-rwym i gael 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Angen oes ddi-rwym i gael 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Angen oes ddi-rwym i gael 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Cyrchwr dros `LinkedList`.
///
/// Mae `Cursor` fel ailadroddwr, heblaw y gall geisio'n ôl ac ymlaen yn rhydd.
///
/// Mae cyrchwyr bob amser yn gorffwys rhwng dwy elfen yn y rhestr, ac yn mynegeio mewn ffordd gylchol yn rhesymegol.
/// I ddarparu ar gyfer hyn, mae yna elfen nad yw'n elfen "ghost" sy'n cynhyrchu `None` rhwng pen a chynffon y rhestr.
///
///
/// Pan gânt eu creu, mae cyrchwyr yn cychwyn ar flaen y rhestr, neu'r "ghost" nad yw'n elfen os yw'r rhestr yn wag.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Cyrchwr dros `LinkedList` gyda gweithrediadau golygu.
///
/// Mae `Cursor` fel ailadroddwr, heblaw ei fod yn gallu ceisio yn ôl ac ymlaen yn rhydd, a gall dreiglo'r rhestr yn ddiogel yn ystod iteriad.
/// Mae hyn oherwydd bod oes ei gyfeiriadau a ildiwyd ynghlwm wrth ei oes ei hun, yn lle dim ond y rhestr sylfaenol.
/// Mae hyn yn golygu na all cyrchwyr gynhyrchu sawl elfen ar unwaith.
///
/// Mae cyrchwyr bob amser yn gorffwys rhwng dwy elfen yn y rhestr, ac yn mynegeio mewn ffordd gylchol yn rhesymegol.
/// I ddarparu ar gyfer hyn, mae yna elfen nad yw'n elfen "ghost" sy'n cynhyrchu `None` rhwng pen a chynffon y rhestr.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Yn dychwelyd y mynegai sefyllfa cyrchwr o fewn yr `LinkedList`.
    ///
    /// Mae hyn yn dychwelyd `None` os yw'r cyrchwr ar hyn o bryd yn pwyntio at yr elfen "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Symud y cyrchwr i elfen nesaf yr `LinkedList`.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna bydd hyn yn ei symud i elfen gyntaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen olaf yr `LinkedList` yna bydd hyn yn ei symud i'r elfen nad yw'n elfen "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Nid oedd gennym unrhyw elfen gyfredol;roedd y cyrchwr yn eistedd yn y man cychwyn Dylai'r elfen nesaf fod yn bennaeth y rhestr
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Roeddem wedi elfen blaenorol, felly gadewch i ni fynd i'w nesaf
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Symud y cyrchwr i elfen flaenorol yr `LinkedList`.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna bydd hyn yn ei symud i elfen olaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen gyntaf yr `LinkedList` yna bydd hyn yn ei symud i'r elfen "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Dim cyfredol.Rydyn ni ar ddechrau'r rhestr.Cynnyrch Dim a neidio i'r diwedd.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Cael prev.Ei ennill a mynd i'r elfen flaenorol.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Yn dychwelyd cyfeiriad at yr elfen y mae'r cyrchwr yn tynnu sylw ati ar hyn o bryd.
    ///
    /// Mae hyn yn dychwelyd `None` os yw'r cyrchwr ar hyn o bryd yn pwyntio at yr elfen "ghost".
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Yn dychwelyd cyfeiriad at yr elfen nesaf.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mae hyn yn dychwelyd elfen gyntaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen olaf yr `LinkedList` yna mae hyn yn dychwelyd `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Yn dychwelyd cyfeiriad at yr elfen flaenorol.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mae hyn yn dychwelyd elfen olaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen gyntaf yr `LinkedList` yna mae hyn yn dychwelyd `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Yn dychwelyd y mynegai sefyllfa cyrchwr o fewn yr `LinkedList`.
    ///
    /// Mae hyn yn dychwelyd `None` os yw'r cyrchwr ar hyn o bryd yn pwyntio at yr elfen "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Symud y cyrchwr i elfen nesaf yr `LinkedList`.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna bydd hyn yn ei symud i elfen gyntaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen olaf yr `LinkedList` yna bydd hyn yn ei symud i'r elfen nad yw'n elfen "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Nid oedd gennym unrhyw elfen gyfredol;roedd y cyrchwr yn eistedd yn y man cychwyn Dylai'r elfen nesaf fod yn bennaeth y rhestr
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Roeddem wedi elfen blaenorol, felly gadewch i ni fynd i'w nesaf
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Symud y cyrchwr i elfen flaenorol yr `LinkedList`.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna bydd hyn yn ei symud i elfen olaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen gyntaf yr `LinkedList` yna bydd hyn yn ei symud i'r elfen "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Dim cyfredol.Rydyn ni ar ddechrau'r rhestr.Cynnyrch Dim a neidio i'r diwedd.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Cael prev.Ei ennill a mynd i'r elfen flaenorol.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Yn dychwelyd cyfeiriad at yr elfen y mae'r cyrchwr yn tynnu sylw ati ar hyn o bryd.
    ///
    /// Mae hyn yn dychwelyd `None` os yw'r cyrchwr ar hyn o bryd yn pwyntio at yr elfen "ghost".
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Yn dychwelyd cyfeiriad at yr elfen nesaf.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mae hyn yn dychwelyd elfen gyntaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen olaf yr `LinkedList` yna mae hyn yn dychwelyd `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Yn dychwelyd cyfeiriad at yr elfen flaenorol.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mae hyn yn dychwelyd elfen olaf yr `LinkedList`.
    /// Os yw'n pwyntio at elfen gyntaf yr `LinkedList` yna mae hyn yn dychwelyd `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Yn dychwelyd cyrchwr darllen yn unig sy'n pwyntio at yr elfen gyfredol.
    ///
    /// Mae oes yr `Cursor` a ddychwelwyd yn rhwym i oes yr `CursorMut`, sy'n golygu na all oroesi'r `CursorMut` a bod yr `CursorMut` wedi'i rewi am oes yr `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Nawr y gweithrediadau golygu rhestr

impl<'a, T> CursorMut<'a, T> {
    /// Mewnosod elfen newydd yn yr `LinkedList` ar ôl yr un gyfredol.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mewnosodir yr elfen newydd ar flaen yr `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Mae mynegai di-elfen "ghost" wedi newid.
                self.index = self.list.len;
            }
        }
    }

    /// Mewnosod elfen newydd yn yr `LinkedList` cyn yr un gyfredol.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mewnosodir yr elfen newydd ar ddiwedd yr `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Yn dileu'r elfen gyfredol o'r `LinkedList`.
    ///
    /// Dychwelir yr elfen a dynnwyd, a symudir y cyrchwr i bwyntio at yr elfen nesaf yn yr `LinkedList`.
    ///
    ///
    /// Os yw'r cyrchwr ar hyn o bryd yn pwyntio at yr elfen "ghost" yna ni chaiff unrhyw elfen ei thynnu a dychwelir `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Yn dileu'r elfen gyfredol o'r `LinkedList` heb ddeall y nod rhestr.
    ///
    /// Mae'r nod a gafodd ei dynnu yn cael ei ddychwelyd fel `LinkedList` newydd sy'n cynnwys y nod hwn yn unig.
    /// Mae'r cyrchwr yn cael ei symud i bwyntio at yr elfen nesaf yn yr `LinkedList` cyfredol.
    ///
    /// Os yw'r cyrchwr ar hyn o bryd yn pwyntio at yr elfen "ghost" yna ni chaiff unrhyw elfen ei thynnu a dychwelir `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Mewnosod yr elfennau o'r `LinkedList` a roddir ar ôl yr un gyfredol.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mewnosodir yr elfennau newydd ar ddechrau'r `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Mae mynegai di-elfen "ghost" wedi newid.
                self.index = self.list.len;
            }
        }
    }

    /// Mewnosod yr elfennau o'r `LinkedList` a roddir cyn yr un gyfredol.
    ///
    /// Os yw'r cyrchwr yn pwyntio at yr elfen "ghost" yna mewnosodir yr elfennau newydd ar ddiwedd yr `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Yn rhannu'r rhestr yn ddwy ar ôl yr elfen gyfredol.
    /// Bydd hyn yn dychwelyd rhestr newydd yn cynnwys popeth ar ôl y cyrchwr, gyda'r rhestr wreiddiol yn cadw popeth o'r blaen.
    ///
    ///
    /// Os bydd y cyrchwr yn pwyntio at y "ghost" heb elfen, yna holl gynnwys y `LinkedList` yn cael eu symud.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Mae mynegai di-elfen "ghost" wedi newid i 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Yn rhannu'r rhestr yn ddwy cyn yr elfen gyfredol.
    /// Bydd hyn yn dychwelyd rhestr newydd yn cynnwys popeth cyn y cyrchwr, gyda'r rhestr wreiddiol yn cadw popeth ar ôl.
    ///
    ///
    /// Os bydd y cyrchwr yn pwyntio at y "ghost" heb elfen, yna holl gynnwys y `LinkedList` yn cael eu symud.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Ailadroddwr a gynhyrchir trwy ffonio `drain_filter` ar LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` yn iawn gyda chyfeiriadau `element` aliasing.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Yn defnyddio'r rhestr yn ailadroddwr sy'n cynhyrchu elfennau yn ôl gwerth.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Sicrhewch fod `LinkedList` a'i ailadroddwyr darllen yn unig yn gyfochrog yn eu paramedrau math.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}