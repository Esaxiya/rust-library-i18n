//! Ciw blaenoriaeth wedi'i weithredu gyda thomen ddeuaidd.
//!
//! Mae mewnosod a phopio'r elfen fwyaf â chymhlethdod amser *O*(log(*n*)).
//! Gwirio'r elfen fwyaf yw *O*(1).Gellir trosi vector yn domen ddeuaidd yn ei le, ac mae ganddo gymhlethdod *O*(*n*).
//! Gellir trosi tomen ddeuaidd hefyd yn vector wedi'i didoli yn ei lle, gan ganiatáu iddo gael ei ddefnyddio ar gyfer heapsort yn ei le *O*(*n*\*log(* n*)).
//!
//! # Examples
//!
//! Mae hon yn enghraifft fwy sy'n gweithredu [Dijkstra's algorithm][dijkstra] i ddatrys yr [shortest path problem][sssp] ar [directed graph][dir_graph].
//!
//! Mae'n dangos sut i ddefnyddio [`BinaryHeap`] gyda mathau penodol.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Mae'r ciw blaenoriaeth yn dibynnu ar `Ord`.
//! // Gweithredwch y trait yn benodol fel bod y ciw yn dod yn domen fach yn lle tomen uchaf.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Sylwch ein bod yn troi'r archebu ar gostau.
//!         // Mewn achos o glymu rydym yn cymharu swyddi, mae'r cam hwn yn angenrheidiol i wneud gweithrediadau `PartialEq` a `Ord` yn gyson.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` mae angen ei weithredu hefyd.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Cynrychiolir pob nod fel `usize`, i'w weithredu'n fyrrach.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Algorithm llwybr byrraf Dijkstra.
//!
//! // Dechreuwch yn `start` a defnyddiwch `dist` i olrhain y pellter byrraf cyfredol i bob nod.Nid yw'r gweithrediad hwn yn effeithlon o ran cof oherwydd gall adael nodau dyblyg yn y ciw.
//! //
//! // Mae hefyd yn defnyddio `usize::MAX` fel gwerth sentinel, ar gyfer gweithredu symlach.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nod]=pellter byrraf cyfredol o `start` i `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Rydyn ni ar `start`, heb gost sero
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Archwiliwch y ffin â nodau cost is yn gyntaf (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Fel arall gallem fod wedi parhau i ddod o hyd i'r holl lwybrau byrraf
//!         if position == goal { return Some(cost); }
//!
//!         // Pwysig fel efallai ein bod eisoes wedi dod o hyd i ffordd well
//!         if cost > dist[position] { continue; }
//!
//!         // Ar gyfer pob nod y gallwn ei gyrraedd, gweld a allwn ddod o hyd i ffordd gyda chost is yn mynd trwy'r nod hwn
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Os felly, ychwanegwch ef i'r ffin a pharhewch
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Ymlacio, rydym bellach wedi dod o hyd i ffordd well
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Nid oes modd cyrchu'r nod
//!     None
//! }
//!
//! fn main() {
//!     // Dyma'r graff cyfeiriedig rydyn ni'n mynd i'w ddefnyddio.
//!     // Mae rhifau'r nod yn cyfateb i'r gwahanol daleithiau, ac mae'r pwysau edge yn symbol o'r gost o symud o un nod i'r llall.
//!     //
//!     // Sylwch fod yr ymylon yn unffordd.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Cynrychiolir y graff fel rhestr agosrwydd lle mae gan bob mynegai, sy'n cyfateb i werth nod, restr o ymylon sy'n mynd allan.
//!     // Dewiswyd am ei effeithlonrwydd.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nod 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nod 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nod 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nod 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nod 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Ciw blaenoriaeth wedi'i weithredu gyda thomen ddeuaidd.
///
/// Bydd hwn yn domen uchaf.
///
/// Mae'n wall rhesymeg i eitem gael ei haddasu yn y fath fodd fel bod archeb yr eitem mewn perthynas ag unrhyw eitem arall, fel y'i pennir gan yr `Ord` trait, yn newid tra ei bod yn y domen.
///
/// Fel rheol dim ond trwy `Cell`, `RefCell`, cyflwr byd-eang, I/O, neu god anniogel y mae hyn yn bosibl.
/// Nid yw'r ymddygiad sy'n deillio o wall rhesymeg o'r fath wedi'i nodi, ond ni fydd yn arwain at ymddygiad heb ei ddiffinio.
/// Gallai hyn gynnwys panics, canlyniadau anghywir, erthyliadau, gollyngiadau cof, a pheidio â therfynu.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Mae casglu math yn caniatáu inni hepgor llofnod math penodol (a fyddai`n `BinaryHeap<i32>` yn yr enghraifft hon).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Gallwn ddefnyddio peek i edrych ar yr eitem nesaf yn y domen.
/// // Yn yr achos hwn, nid oes unrhyw eitemau i mewn yno eto felly rydym yn cael Dim.
/// assert_eq!(heap.peek(), None);
///
/// // Gadewch i ni ychwanegu rhai sgoriau ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Nawr mae peek yn dangos yr eitem bwysicaf yn y domen.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Gallwn wirio hyd tomen.
/// assert_eq!(heap.len(), 3);
///
/// // Gallwn ailadrodd dros yr eitemau yn y domen, er eu bod yn cael eu dychwelyd mewn trefn ar hap.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Os ydym yn hytrach yn popio'r sgorau hyn, dylent ddod yn ôl mewn trefn.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Gallwn glirio'r domen o unrhyw eitemau sy'n weddill.
/// heap.clear();
///
/// // Dylai'r domen fod yn wag nawr.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Gellir defnyddio naill ai `std::cmp::Reverse` neu weithrediad `Ord` wedi'i deilwra i wneud `BinaryHeap` yn domen fach.
/// Mae hyn yn gwneud i `heap.pop()` ddychwelyd y gwerth lleiaf yn lle'r un mwyaf.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Lapiwch werthoedd yn `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Os ydym yn popio'r sgorau hyn nawr, dylent ddod yn ôl yn y drefn arall.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Cymhlethdod amser
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Mae'r gwerth ar gyfer `push` yn gost ddisgwyliedig;mae'r ddogfennaeth dull yn rhoi dadansoddiad manylach.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Strwythur yn lapio cyfeiriad symudol at yr eitem fwyaf ar `BinaryHeap`.
///
///
/// Mae'r `struct` hwn yn cael ei greu gan y dull [`peek_mut`] ar [`BinaryHeap`].
/// Gweler ei ddogfennaeth am fwy.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // DIOGELWCH: Dim ond ar gyfer tomenni nad ydynt yn wag y mae PeekMut yn cael ei gyflymu.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // DIOGEL: Dim ond ar gyfer tomenni nad ydynt yn wag y mae PeekMut yn cael ei gyflymu
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // DIOGEL: Dim ond ar gyfer tomenni nad ydynt yn wag y mae PeekMut yn cael ei gyflymu
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Yn tynnu'r gwerth peeked o'r domen a'i ddychwelyd.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Yn creu `BinaryHeap<T>` gwag.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Yn creu `BinaryHeap` gwag fel tomen uchaf.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Yn creu `BinaryHeap` gwag gyda chynhwysedd penodol.
    /// Mae hyn yn rhagddyrannu digon o gof ar gyfer elfennau `capacity`, fel nad oes rhaid ailddyrannu'r `BinaryHeap` nes ei fod yn cynnwys o leiaf cymaint o werthoedd.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Yn dychwelyd cyfeiriad treiddgar at yr eitem fwyaf yn y domen ddeuaidd, neu `None` os yw'n wag.
    ///
    /// Note: Os yw'r gwerth `PeekMut` yn cael ei ollwng, gall y domen fod mewn cyflwr anghyson.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Cymhlethdod amser
    ///
    /// Os yw'r eitem yn cael ei haddasu yna'r cymhlethdod amser achos gwaethaf yw *O*(log(*n*)), fel arall mae'n *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Yn tynnu'r eitem fwyaf o'r domen ddeuaidd a'i dychwelyd, neu `None` os yw'n wag.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Cymhlethdod amser
    ///
    /// Y gost achos waethaf o `pop` ar domen sy'n cynnwys elfennau *n* yw *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // DIOGELWCH: Mae !self.is_empty() yn golygu bod self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Yn gwthio eitem ar y domen ddeuaidd.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Cymhlethdod amser
    ///
    /// Y gost ddisgwyliedig o `push`, ar gyfartaledd dros bob archeb bosibl o'r elfennau sy'n cael eu gwthio, a dros nifer ddigon mawr o wthio, yw *O*(1).
    ///
    /// Dyma'r metrig cost mwyaf ystyrlon wrth wthio elfennau nad ydyn nhw *eisoes* mewn unrhyw batrwm wedi'i ddidoli.
    ///
    /// Mae'r cymhlethdod amser yn dirywio os yw elfennau'n cael eu gwthio mewn trefn esgynnol yn bennaf.
    /// Yn yr achos gwaethaf, mae elfennau'n cael eu gwthio yn nhrefn ddidoli esgynnol a'r gost amorteiddiedig fesul gwthio yw *O*(log(*n*)) yn erbyn tomen sy'n cynnwys elfennau *n*.
    ///
    /// Cost achos gwaethaf galwad *sengl* i `push` yw *O*(*n*).Mae'r achos gwaethaf yn digwydd pan fydd capasiti wedi disbyddu ac angen newid maint.
    /// Amorteiddiwyd y gost newid maint yn y ffigurau blaenorol.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // DIOGELWCH: Ers i ni wthio eitem newydd mae'n golygu hynny
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Yn defnyddio'r `BinaryHeap` ac yn dychwelyd vector mewn trefn (ascending) wedi'i didoli.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // DIOGELWCH: Mae `end` yn mynd o `self.len() - 1` i 1 (y ddau wedi'u cynnwys),
            //  felly mae bob amser yn fynegai dilys i'w gyrchu.
            //  Mae'n ddiogel cyrchu mynegai 0 (hy `ptr`), oherwydd
            //  1 <=diwedd <self.len(), sy'n golygu self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // DIOGELWCH: Mae `end` yn mynd o `self.len() - 1` i 1 (y ddau wedi'u cynnwys) felly:
            //  0 <1 <=diwedd <= self.len(), 1 <self.len() Sy'n golygu 0 <diwedd a diwedd <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Mae gweithrediadau sift_up a sift_down yn defnyddio blociau anniogel er mwyn symud elfen allan o'r vector (gan adael twll ar ôl), symud ar hyd y lleill a symud yr elfen wedi'i symud yn ôl i'r vector yn lleoliad olaf y twll.
    //
    // Defnyddir y math `Hole` i gynrychioli hyn, a sicrhau bod y twll yn cael ei lenwi yn ôl ar ddiwedd ei gwmpas, hyd yn oed ar panic.
    // Mae defnyddio twll yn lleihau'r ffactor cyson o'i gymharu â defnyddio cyfnewidiadau, sy'n golygu dwywaith cymaint o symudiadau.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Rhaid i'r galwr warantu bod `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Tynnwch y gwerth yn `pos` a chreu twll.
        // DIOGELWCH: Mae'r galwr yn gwarantu bod pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // DIOGELWCH: hole.pos()> cychwyn>=0, sy'n golygu hole.pos()> 0
            //  ac felly ni all hole.pos(), 1 orlifo.
            //  Mae hyn yn gwarantu bod rhiant <hole.pos() felly mae'n fynegai dilys a hefyd!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // DIOGELWCH: Yr un fath ag uchod
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Cymerwch elfen yn `pos` a'i symud i lawr y domen, tra bod ei blant yn fwy.
    ///
    ///
    /// # Safety
    ///
    /// Rhaid i'r galwr warantu bod `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // DIOGELWCH: Mae'r galwr yn gwarantu bod pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Dolen invariant: plentyn==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // cymharwch â'r mwyaf o'r ddau blentyn DIOGELWCH: plentyn <diwedd, 1 <self.len() a phlentyn + 1 <diwedd <= self.len(), felly maen nhw'n fynegeion dilys.
            //
            //  plentyn==2 *hole.pos() + 1!= hole.pos() a phlentyn + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: Gallai 2 *hole.pos() + 1 neu 2* hole.pos() + 2 orlifo os yw T yn ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // os ydym eisoes mewn trefn, stopiwch.
            // DIOGELWCH: mae'r plentyn bellach naill ai'n hen blentyn neu'r hen blentyn + 1
            //  Fe wnaethon ni brofi eisoes bod y ddau yn <self.len() a!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // DIOGELWCH: yr un fath ag uchod.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // DIOGELWCH: &&cylched fer, sy'n golygu hynny yn y
        //  ail gyflwr mae eisoes yn wir bod plentyn==diwedd, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // DIOGELWCH: profwyd bod y plentyn eisoes yn fynegai dilys a
            //  plentyn==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Rhaid i'r galwr warantu bod `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // DIOGELWCH: gwarantir pos <len gan y galwr a
        //  yn amlwg len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Cymerwch elfen yn `pos` a'i symud yr holl ffordd i lawr y domen, yna ei didoli i'w safle.
    ///
    ///
    /// Note: Mae hyn yn gyflymach pan wyddys bod yr elfen yn fawr/dylai fod yn agosach at y gwaelod.
    ///
    /// # Safety
    ///
    /// Rhaid i'r galwr warantu bod `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // DIOGELWCH: Mae'r galwr yn gwarantu bod pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Dolen invariant: plentyn==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // DIOGELWCH: plentyn <diwedd, 1 <self.len() a
            //  plentyn + 1 <diwedd <= self.len(), felly maen nhw'n fynegeion dilys.
            //  plentyn==2 *hole.pos() + 1!= hole.pos() a phlentyn + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: Gallai 2 *hole.pos() + 1 neu 2* hole.pos() + 2 orlifo os yw T yn ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // DIOGELWCH: Yr un fath ag uchod
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // DIOGELWCH: plentyn==diwedd, 1 <self.len(), felly mae'n fynegai dilys
            //  a phlentyn==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // DIOGELWCH: pos yw'r safle yn y twll ac fe'i profwyd eisoes
        //  i fod yn fynegai dilys.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // DIOGELWCH: n yn cychwyn o self.len()/2 ac yn mynd i lawr i 0.
            //  Yr unig achos pan! (N <self.len()) yw os self.len() ==0, ond mae'n cael ei ddiystyru gan gyflwr y ddolen.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Yn symud holl elfennau `other` i `self`, gan adael `other` yn wag.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` yn cymryd gweithrediadau O(len1 + len2) a thua 2 *(len1 + len2) cymariaethau yn yr achos gwaethaf tra bod `extend` yn cymryd gweithrediadau O(len2* log(len1)) a thua 1 *len2* log_2(len1) yn yr achos gwaethaf, gan dybio len1>= len2.
        // Ar gyfer tomenni mwy, nid yw'r pwynt croesi bellach yn dilyn yr ymresymiad hwn ac fe'i pennwyd yn empirig.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Yn dychwelyd ailadroddwr sy'n adfer elfennau yn nhrefn y domen.
    /// Mae'r elfennau a adenillwyd yn cael eu tynnu o'r domen wreiddiol.
    /// Bydd yr elfennau sy'n weddill yn cael eu tynnu wrth drefn y domen galw heibio.
    ///
    /// Note:
    /// * `.drain_sorted()` yw *O*(*n*\*log(* n*)); yn arafach o lawer na `.drain()`.
    ///   Dylech ddefnyddio'r olaf ar gyfer y rhan fwyaf o achosion.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // yn cael gwared ar yr holl elfennau yn nhrefn y domen
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Yn cadw'r elfennau a bennir gan y predicate yn unig.
    ///
    /// Mewn geiriau eraill, tynnwch yr holl elfennau `e` fel bod `f(&e)` yn dychwelyd `false`.
    /// Ymwelir â'r elfennau mewn trefn ddigymell (ac amhenodol).
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // dim ond cadw eilrifau
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Yn dychwelyd ailadroddwr yn ymweld â'r holl werthoedd yn y vector sylfaenol, yn nhrefn fympwyol.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Argraffu 1, 2, 3, 4 yn nhrefn fympwyol
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Yn dychwelyd ailadroddwr sy'n adfer elfennau yn nhrefn y domen.
    /// Mae'r dull hwn yn defnyddio'r domen wreiddiol.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Yn dychwelyd yr eitem fwyaf yn y domen ddeuaidd, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Cymhlethdod amser
    ///
    /// Y gost yw *O*(1) yn yr achos gwaethaf.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Yn dychwelyd nifer yr elfennau y gall y domen ddeuaidd eu dal heb ailddyrannu.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Yn cadw'r capasiti lleiaf ar gyfer mewnosod `additional` yn fwy o elfennau yn yr `BinaryHeap` a roddir.
    /// Yn gwneud dim os yw'r gallu eisoes yn ddigonol.
    ///
    /// Sylwch y gall y dyrannwr roi mwy o le i'r casgliad nag y mae'n gofyn amdano.
    /// Felly ni ellir dibynnu ar gapasiti i fod yn union leiaf.
    /// Mae'n well gennych [`reserve`] os oes disgwyl mewnosodiadau future.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn gorlifo `usize`.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Yn cadw'r gallu i fewnosod o leiaf `additional` mwy o elfennau yn yr `BinaryHeap`.
    /// Efallai y bydd y casgliad yn cadw mwy o le i osgoi ailddyrannu yn aml.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn gorlifo `usize`.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Yn taflu cymaint o gapasiti ychwanegol â phosib.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Yn taflu capasiti gyda rhwymiad is.
    ///
    /// Bydd y capasiti yn aros o leiaf mor fawr â'r hyd a'r gwerth a gyflenwir.
    ///
    ///
    /// Os yw'r gallu cyfredol yn llai na'r terfyn isaf, mae hwn yn ddim-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Yn defnyddio'r `BinaryHeap` ac yn dychwelyd y vector sylfaenol mewn trefn fympwyol.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // A fydd yn argraffu mewn rhyw drefn
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Yn dychwelyd hyd y domen ddeuaidd.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Yn gwirio a yw'r domen ddeuaidd yn wag.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Yn clirio'r domen ddeuaidd, gan ddychwelyd ailadroddwr dros yr elfennau sydd wedi'u tynnu.
    ///
    /// Mae'r elfennau'n cael eu tynnu mewn trefn fympwyol.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Yn gollwng pob eitem o'r domen ddeuaidd.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Mae twll yn cynrychioli twll mewn tafell hy, mynegai heb werth dilys (oherwydd iddo gael ei symud ohono neu ei ddyblygu).
///
/// Wrth ollwng, bydd `Hole` yn adfer y dafell trwy lenwi safle'r twll gyda'r gwerth a gafodd ei dynnu'n wreiddiol.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Creu `Hole` newydd ar fynegai `pos`.
    ///
    /// Anniogel oherwydd rhaid i bos fod o fewn y sleisen ddata.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // DIOGEL: dylai pos fod y tu mewn i'r sleisen
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Yn dychwelyd cyfeiriad at yr elfen a dynnwyd.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Yn dychwelyd cyfeiriad at yr elfen yn `index`.
    ///
    /// Anniogel oherwydd rhaid i'r mynegai fod o fewn y sleisen ddata ac nid yw'n hafal i'r pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Symud twll i leoliad newydd
    ///
    /// Anniogel oherwydd rhaid i'r mynegai fod o fewn y sleisen ddata ac nid yw'n hafal i'r pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // llenwch y twll eto
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Ailadroddwr dros elfennau `BinaryHeap`.
///
/// Mae'r `struct` hwn yn cael ei greu gan [`BinaryHeap::iter()`].
/// Gweler ei ddogfennaeth am fwy.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Tynnu o blaid `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Ailadroddwr sy'n berchen ar elfennau `BinaryHeap`.
///
/// Mae'r `struct` hwn yn cael ei greu gan [`BinaryHeap::into_iter()`] (a ddarperir gan yr `IntoIterator` trait).
/// Gweler ei ddogfennaeth am fwy.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Ailadroddwr sy'n draenio dros elfennau `BinaryHeap`.
///
/// Mae'r `struct` hwn yn cael ei greu gan [`BinaryHeap::drain()`].
/// Gweler ei ddogfennaeth am fwy.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Ailadroddwr sy'n draenio dros elfennau `BinaryHeap`.
///
/// Mae'r `struct` hwn yn cael ei greu gan [`BinaryHeap::drain_sorted()`].
/// Gweler ei ddogfennaeth am fwy.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Yn dileu elfennau domen yn nhrefn y domen.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Trosi `Vec<T>` yn `BinaryHeap<T>`.
    ///
    /// Mae'r trawsnewidiad hwn yn digwydd yn ei le, ac mae ganddo gymhlethdod amser *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Trosi `BinaryHeap<T>` yn `Vec<T>`.
    ///
    /// Nid yw'r trawsnewidiad hwn yn gofyn am symud na dyrannu data, ac mae ganddo gymhlethdod amser cyson.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Yn creu ailadroddwr llafurus, hynny yw, un sy'n symud pob gwerth allan o'r domen ddeuaidd yn nhrefn fympwyol.
    /// Ni ellir defnyddio'r domen ddeuaidd ar ôl galw hwn.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Argraffu 1, 2, 3, 4 yn nhrefn fympwyol
    /// for x in heap.into_iter() {
    ///     // mae gan x fath i32, nid &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}