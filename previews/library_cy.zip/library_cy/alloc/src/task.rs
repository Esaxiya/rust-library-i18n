#![stable(feature = "wake_trait", since = "1.51.0")]
//! Mathau a Traits ar gyfer gweithio gyda thasgau asyncronig.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Gweithredu deffro tasg ar ysgutor.
///
/// Gellir defnyddio'r trait hwn i greu [`Waker`].
/// Gall ysgutor ddiffinio gweithrediad o'r trait hwn, a'i ddefnyddio i lunio Waker i drosglwyddo i'r tasgau a gyflawnir ar yr ysgutor hwnnw.
///
/// Mae'r trait yn cof-ddiogel ac amgen ergonomig i adeiladu [`RawWaker`].
/// Mae'n cefnogi dyluniad ysgutor cyffredin lle mae'r data a ddefnyddiwyd i ddeffro tasg yn cael ei storio mewn [`Arc`].
/// Ni all rhai ysgutorion (yn enwedig y rhai ar gyfer systemau gwreiddio) ddefnyddio'r API hwn, a dyna pam mae [`RawWaker`] yn bodoli fel dewis arall ar gyfer y systemau hynny.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Swyddogaeth `block_on` sylfaenol sy'n cymryd future ac yn ei redeg i'w chwblhau ar yr edefyn cyfredol.
///
/// **Note:** Mae'r enghraifft hon yn masnachu cywirdeb er symlrwydd.
/// Er mwyn atal deadlocks, bydd angen i weithrediadau gradd cynhyrchu hefyd drin galwadau canolradd i `thread::unpark` yn ogystal â gwahoddiadau nythu.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Dewin sy'n deffro'r edau gyfredol pan gaiff ei alw.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Cynnal future i gwblhau ar y edau cyfredol.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Piniwch y future fel y gellir ei polio.
///     let mut fut = Box::pin(fut);
///
///     // Creu cyd-destun newydd gael ei throsglwyddo i'r future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Rhedeg y future i'w gwblhau.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Wake dasg hon.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Deffro'r dasg hon heb yfed y waker.
    ///
    /// Os yw ysgutor yn cefnogi ffordd ratach o ddeffro heb yfed y waker, dylai ddiystyru'r dull hwn.
    /// Yn ddiofyn, mae'n clonio'r [`Arc`] ac yn galw [`wake`] ar y clôn.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // DIOGELWCH: Mae hyn yn ddiogel oherwydd bod raw_waker yn llunio'n ddiogel
        // mae RawWaker o Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Mae'r swyddogaeth preifat ar gyfer adeiladu RawWaker cael ei ddefnyddio, yn hytrach na
// gan amlinellu hyn i'r impl `From<Arc<W>> for RawWaker`, er mwyn sicrhau nad yw diogelwch `From<Arc<W>> for Waker` yn dibynnu ar yr anfoniad trait cywir, yn lle hynny mae'r ddau impls yn galw'r swyddogaeth hon yn uniongyrchol ac yn benodol.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Cynyddu cyfrif cyfeirnod yr arc i'w glonio.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wake yn ôl gwerth, gan symud Arc i mewn i'r swyddogaeth Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Deffro trwy gyfeirio, lapiwch y waker yn ManuallyDrop er mwyn osgoi ei ollwng
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Gostwng cyfrif cyfeirnod yr Arc wrth ollwng
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}