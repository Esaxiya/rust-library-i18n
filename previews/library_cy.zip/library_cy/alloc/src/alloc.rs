//! APIs dyrannu cof

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Dyma'r symbolau hud i alw'r dynodwr byd-eang.Mae rustc yn eu cynhyrchu i ffonio `__rg_alloc` ac ati.
    // os oes priodoledd `#[global_allocator]` (mae'r cod sy'n ehangu sy'n priodoli macro yn cynhyrchu'r swyddogaethau hynny), neu i alw'r gweithrediadau diofyn yn libstd (`__rdl_alloc` ac ati.
    //
    // yn `library/std/src/alloc.rs`) fel arall.
    // Mae'r rustc fork o LLVM hefyd yn achosion arbennig yr enwau swyddogaeth hyn i allu eu optimeiddio fel `malloc`, `realloc`, a `free`, yn y drefn honno.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Y dyrannwr cof byd-eang.
///
/// Mae'r math hwn yn gweithredu'r [`Allocator`] trait trwy anfon galwadau at y dyrannwr sydd wedi'i gofrestru gyda'r priodoledd `#[global_allocator]` os oes un, neu ragosodiad yr `std` crate.
///
///
/// Note: er bod y math hwn yn ansefydlog, gellir cyrchu'r swyddogaeth y mae'n ei darparu trwy'r [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Dyrannu cof gyda'r dyrannwr byd-eang.
///
/// Mae'r swyddogaeth hon yn anfon galwadau ymlaen i ddull [`GlobalAlloc::alloc`] y dyrannwr sydd wedi'i gofrestru gyda'r priodoledd `#[global_allocator]` os oes un, neu ragosodiad yr `std` crate.
///
///
/// Disgwylir i'r swyddogaeth hon gael ei dirprwyo o blaid y dull `alloc` o'r math [`Global`] pan ddaw hi a'r [`Allocator`] trait yn sefydlog.
///
/// # Safety
///
/// Gweler [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Dadddyrannu cof gyda'r dynodwr byd-eang.
///
/// Mae'r swyddogaeth hon yn anfon galwadau ymlaen i ddull [`GlobalAlloc::dealloc`] y dyrannwr sydd wedi'i gofrestru gyda'r priodoledd `#[global_allocator]` os oes un, neu ragosodiad yr `std` crate.
///
///
/// Disgwylir i'r swyddogaeth hon gael ei dirprwyo o blaid y dull `dealloc` o'r math [`Global`] pan ddaw hi a'r [`Allocator`] trait yn sefydlog.
///
/// # Safety
///
/// Gweler [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Ailddyrannu cof gyda'r dyrannwr byd-eang.
///
/// Mae'r swyddogaeth hon yn anfon galwadau ymlaen i ddull [`GlobalAlloc::realloc`] y dyrannwr sydd wedi'i gofrestru gyda'r priodoledd `#[global_allocator]` os oes un, neu ragosodiad yr `std` crate.
///
///
/// Disgwylir i'r swyddogaeth hon gael ei dirprwyo o blaid y dull `realloc` o'r math [`Global`] pan ddaw hi a'r [`Allocator`] trait yn sefydlog.
///
/// # Safety
///
/// Gweler [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Dyrannu cof sero-cychwynnol gyda'r dynodwr byd-eang.
///
/// Mae'r swyddogaeth hon yn anfon galwadau ymlaen i ddull [`GlobalAlloc::alloc_zeroed`] y dyrannwr sydd wedi'i gofrestru gyda'r priodoledd `#[global_allocator]` os oes un, neu ragosodiad yr `std` crate.
///
///
/// Disgwylir i'r swyddogaeth hon gael ei dirprwyo o blaid y dull `alloc_zeroed` o'r math [`Global`] pan ddaw hi a'r [`Allocator`] trait yn sefydlog.
///
/// # Safety
///
/// Gweler [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // DIOGELWCH: Mae `layout` yn ddi-sero o ran maint,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // DIOGELWCH: Yr un fath â `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // DIOGELWCH: Mae `new_size` yn ddi-sero gan fod `old_size` yn fwy na neu'n hafal i `new_size`
            // fel sy'n ofynnol gan amodau diogelwch.Rhaid i'r galwr gynnal amodau eraill
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` yn ôl pob tebyg gwiriadau am `new_size >= old_layout.size()` neu rywbeth tebyg.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // DIOGELWCH: oherwydd rhaid i `new_layout.size()` fod yn fwy na neu'n hafal i `old_size`,
            // mae'r dyraniad cof hen a newydd yn ddilys ar gyfer darlleniadau ac ysgrifennu ar gyfer beitiau `old_size`.
            // Hefyd, oherwydd nad oedd yr hen ddyraniad wedi'i ddeall eto, ni all orgyffwrdd `new_ptr`.
            // Felly, mae'r alwad i `copy_nonoverlapping` yn ddiogel.
            // Rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // DIOGELWCH: Mae `layout` yn ddi-sero o ran maint,
            // rhaid i'r galwr gynnal amodau eraill
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DIOGELWCH: rhaid i'r galwr gynnal yr holl amodau
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DIOGELWCH: rhaid i'r galwr gynnal yr holl amodau
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // DIOGELWCH: rhaid i'r galwr gynnal amodau
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // DIOGELWCH: Mae `new_size` yn ddi-sero.Rhaid i'r galwr gynnal amodau eraill
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` yn ôl pob tebyg gwiriadau am `new_size <= old_layout.size()` neu rywbeth tebyg.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // DIOGELWCH: oherwydd rhaid i `new_size` fod yn llai na neu'n hafal i `old_layout.size()`,
            // mae'r dyraniad cof hen a newydd yn ddilys ar gyfer darlleniadau ac ysgrifennu ar gyfer beitiau `new_size`.
            // Hefyd, oherwydd nad oedd yr hen ddyraniad wedi'i ddeall eto, ni all orgyffwrdd `new_ptr`.
            // Felly, mae'r alwad i `copy_nonoverlapping` yn ddiogel.
            // Rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Y dyrannwr ar gyfer awgrymiadau unigryw.
// Rhaid i'r swyddogaeth hon beidio â dadflino.Os bydd, bydd MIR codegen yn methu.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Rhaid i'r llofnod hwn fod yr un peth â `Box`, fel arall bydd ICE yn digwydd.
// Pan ychwanegir paramedr ychwanegol i `Box` (fel `A: Allocator`), mae'n rhaid ychwanegu hwn yma hefyd.
// Er enghraifft, os yw `Box` yn cael ei newid i `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, mae'n rhaid newid y swyddogaeth hon i `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` hefyd.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Triniwr gwallau dyrannu

extern "Rust" {
    // Dyma'r symbol hud i alw'r triniwr gwallau dyrannu byd-eang.
    // Mae rustc yn ei gynhyrchu i ffonio `__rg_oom` os oes `#[alloc_error_handler]`, neu i alw'r gweithrediadau diofyn o dan (`__rdl_oom`) fel arall.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Erthylwch ar wall neu fethiant dyrannu cof.
///
/// Anogir galwyr APIs dyrannu cof sy'n dymuno erthylu cyfrifiant mewn ymateb i wall dyrannu i alw'r swyddogaeth hon, yn hytrach na galw `panic!` neu debyg yn uniongyrchol.
///
///
/// Ymddygiad diofyn y swyddogaeth hon yw argraffu neges i wall safonol ac erthylu'r broses.
/// Gellir ei ddisodli â [`set_alloc_error_hook`] a [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Ar gyfer prawf dyrannu gellir defnyddio `std::alloc::handle_alloc_error` yn uniongyrchol.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // a elwir trwy `__rust_alloc_error_handler` a gynhyrchir

    // os nad oes `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // os oes `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Arbenigwch glonau i gof heb ei ddyrannu ymlaen llaw.
/// Defnyddir gan `Box::clone` a `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ar ôl dyrannu *cyntaf* gall ganiatáu i'r optimizer greu'r gwerth wedi'i glonio yn ei le, gan hepgor y lleol a symud.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Gallwn ni gopïo yn ei le bob amser, heb gynnwys gwerth lleol erioed.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}