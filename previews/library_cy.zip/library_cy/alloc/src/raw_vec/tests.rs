use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Mae ysgrifennu prawf integreiddio rhwng dyranwyr trydydd parti a `RawVec` ychydig yn anodd oherwydd nid yw'r API `RawVec` yn datgelu dulliau dyrannu codadwy, felly ni allwn wirio beth sy'n digwydd pan fydd dyranwr wedi blino'n lân (y tu hwnt i ganfod panic).
    //
    //
    // Yn lle, mae hyn yn gwirio bod y dulliau `RawVec` o leiaf yn mynd trwy'r API Allocator pan fydd yn cadw storfa.
    //
    //
    //
    //
    //

    // Dyrannwr fud sy'n defnyddio swm sefydlog o danwydd cyn i ymdrechion dyrannu ddechrau methu.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (yn achosi ail-ddyrannu, a thrwy hynny ddefnyddio 50 + 150=200 uned o danwydd)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Yn gyntaf, `reserve` yn dyrannu fel `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // Mae 97 yn fwy na dwbl o 7, felly dylai `reserve` weithio fel `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // Mae 3 yn llai na hanner 12, felly mae'n rhaid i `reserve` dyfu'n esbonyddol.
        // Ar adeg ysgrifennu'r prawf hwn, ffactor tyfu yw 2, felly mae capasiti newydd yn 24, fodd bynnag, mae ffactor tyfu 1.5 yn iawn hefyd.
        //
        // Felly `>= 18` yn haeru.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}