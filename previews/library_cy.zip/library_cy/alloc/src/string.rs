//! Llinyn tyfadwy UTF-8-wedi'i amgodio.
//!
//! Mae'r modiwl hwn yn cynnwys y math [`String`], yr [`ToString`] trait ar gyfer trosi i dannau, a sawl math o wall a allai ddeillio o weithio gyda [`String`] s.
//!
//!
//! # Examples
//!
//! Mae sawl ffordd o greu [`String`] newydd o lythren llythrennol:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Gallwch greu [`String`] newydd o un sy'n bodoli eisoes trwy gyd-fynd â
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Os oes gennych vector o beit UTF-8 dilys, gallwch wneud [`String`] allan ohono.Gallwch chi wneud y gwrthwyneb hefyd.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Rydym yn gwybod bytes hyn yn ddilys, felly byddwn yn defnyddio `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Llinyn tyfadwy UTF-8-wedi'i amgodio.
///
/// Y math `String` yw'r math llinyn mwyaf cyffredin sydd â pherchnogaeth dros gynnwys y llinyn.Mae ganddo berthynas agos â'i gymar benthyg, yr [`str`] cyntefig.
///
/// # Examples
///
/// Gallwch greu `String` o [a literal string][`str`] gyda [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Gallwch atodi [`char`] i `String` gyda'r dull [`push`], ac atodi [`&str`] gyda'r dull [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Os oes gennych vector o beit UTF-8, gallwch greu `String` ohono gyda'r dull [`from_utf8`]:
///
/// ```
/// // rhai beit, mewn vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Rydym yn gwybod bytes hyn yn ddilys, felly byddwn yn defnyddio `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Mae `llinynnau 'bob amser yn ddilys UTF-8.Mae gan hyn ychydig o oblygiadau, a'r cyntaf ohonynt yw, os oes angen llinyn nad yw'n UTF-8 arnoch chi, ystyriwch [`OsString`].Mae'n debyg, ond heb y cyfyngiad UTF-8.Yr ail goblygiad yw y gallwch nad mynegai i mewn i `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Bwriad mynegeio yw bod yn weithrediad amser cyson, ond nid yw amgodio UTF-8 yn caniatáu inni wneud hyn.Ar ben hynny, nid yw'n glir pa fath o beth ddylai'r mynegai ei ddychwelyd: beit, pwynt cod, neu glwstwr grapheme.
/// Mae'r dulliau [`bytes`] a [`chars`] yn dychwelyd ailadroddwyr dros y ddau gyntaf, yn y drefn honno.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Mae `String`s yn gweithredu [`Deref`] `<Target=str>`, ac felly etifeddu pob un o ddulliau [`str`].Yn ogystal, mae hyn yn golygu y gallwch basio `String` i swyddogaeth sy'n cymryd [`&str`] trwy ddefnyddio ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Bydd hyn yn creu [`&str`] o'r `String` a'i basio i mewn. Mae'r trawsnewidiad hwn yn rhad iawn, ac felly yn gyffredinol, bydd swyddogaethau'n derbyn [`&str`] s fel dadleuon oni bai bod angen `String` arnyn nhw am ryw reswm penodol.
///
/// Mewn rhai achosion, nid oes gan Rust ddigon o wybodaeth i wneud trawsnewid hwn, a elwir yn [`Deref`] gorfodaeth.Yn yr enghraifft ganlynol mae sleisen llinyn [`&'a str`][`&str`] yn gweithredu'r trait `TraitExample`, ac mae'r swyddogaeth `example_func` yn cymryd unrhyw beth sy'n gweithredu'r trait.
/// Yn yr achos hwn, byddai angen i Rust wneud dau drosiad ymhlyg, nad oes gan Rust y modd i'w wneud.
/// Am y rheswm hwnnw, ni fydd yr enghraifft ganlynol llunio.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Mae dau opsiwn a fyddai'n gweithio yn lle.Y cyntaf fyddai i newid y llinell `example_func(&example_string);` i `example_func(example_string.as_str());`, gan ddefnyddio'r dull [`as_str()`] i dynnu benodol y dafell llinyn sy'n cynnwys y llinyn.
/// Mae'r ail ffordd yn newid `example_func(&example_string);` i `example_func(&*example_string);`.
/// Yn yr achos hwn rydym yn dad-gyfeiriadu `String` i [`str`][`&str`], yna'n cyfeirio'r [`str`][`&str`] yn ôl i [`&str`].
/// Mae'r ail ffordd yn fwy idiomatig, fodd bynnag mae'r ddau yn gweithio i wneud y trawsnewid yn benodol yn hytrach na dibynnu ar y trawsnewid ymhlyg.
///
/// # Representation
///
/// Mae `String` yn cynnwys tair cydran: pwyntydd i rai beit, hyd, a chynhwysedd.Mae'r pwyntydd yn pwyntio at byffer mewnol y mae `String` yn ei ddefnyddio i storio ei ddata.Y hyd yw nifer y beit sy'n cael eu storio yn y byffer ar hyn o bryd, a'r cynhwysedd yw maint y byffer mewn beit.
///
/// O'r herwydd, bydd y hyd bob amser yn llai na neu'n hafal i'r gallu.
///
/// Mae'r byffer hwn bob amser yn cael ei storio ar y domen.
///
/// Gallwch edrych ar y rhain gyda'r dulliau [`as_ptr`], [`len`], a [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Diweddarwch hyn pan fydd vec_into_raw_parts wedi'i sefydlogi.
/// // Atal gollwng data'r Llinyn yn awtomatig
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // mae gan y stori bedwar ar bymtheg beit
/// assert_eq!(19, len);
///
/// // Gallwn ailadeiladu Llinyn allan o ptr, len, a chynhwysedd.
/// // Mae hyn i gyd yn anniogel oherwydd rydym yn gyfrifol am sicrhau bod y cydrannau'n ddilys:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Os oes gan `String` ddigon o gapasiti, ni fydd ychwanegu elfennau ato yn ailddyrannu.Er enghraifft, ystyriwch y rhaglen hon:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Bydd hyn yn allbwn y canlynol:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Ar y dechrau, nid oes cof wedi'i ddyrannu o gwbl, ond wrth i ni atodi i'r llinyn, mae'n cynyddu ei allu yn briodol.Os ydym yn lle defnyddio'r dull [`with_capacity`] i ddyrannu'r capasiti cywir i ddechrau:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Mae gennym allbwn gwahanol yn y pen draw:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Yma, nid oes angen dyrannu mwy o gof y tu mewn i'r ddolen.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Gwerth gwall posib wrth drosi `String` o beit UTF-8 vector.
///
/// Y math hwn yw'r math gwall ar gyfer y dull [`from_utf8`] ar [`String`].
/// Fe'i cynlluniwyd yn y fath fodd i osgoi ailddyraniadau yn ofalus: bydd y dull [`into_bytes`] yn rhoi'r beit vector a ddefnyddiwyd yn yr ymgais i drosi yn ôl.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Mae'r math [`Utf8Error`] a ddarperir gan [`std::str`] yn cynrychioli camgymeriad a all ddigwydd wrth drosi tafell o [`u8`] au i [`&str`].
/// Yn yr ystyr hwn, mae'n analog i `FromUtf8Error`, a gallwch gael un o `FromUtf8Error` trwy'r dull [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// // rhai beit annilys, mewn vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Gwerth gwall posib wrth drosi `String` o dafell beit UTF-16.
///
/// Y math hwn yw'r math gwall ar gyfer y dull [`from_utf16`] ar [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Yn creu `String` gwag newydd.
    ///
    /// O ystyried bod yr `String` yn wag, ni fydd hyn yn dyrannu unrhyw byffer cychwynnol.Er bod hynny'n golygu bod y llawdriniaeth gychwynnol hon yn rhad iawn, gall achosi dyraniad gormodol yn ddiweddarach pan ychwanegwch ddata.
    ///
    /// Os oes gennych syniad o faint o ddata fydd gan yr `String`, ystyriwch y dull [`with_capacity`] i atal ailddyrannu gormodol.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Yn creu `String` gwag newydd gyda gallu penodol.
    ///
    /// Mae gan `llinynnau 'byffer mewnol i ddal eu data.
    /// Y cynhwysedd yw hyd y byffer hwnnw, a gellir ei holi gyda'r dull [`capacity`].
    /// Mae'r dull hwn yn creu `String` gwag, ond un gyda byffer cychwynnol sy'n gallu dal beitiau `capacity`.
    /// Mae hyn yn ddefnyddiol pan allech fod yn atodi criw o ddata i'r `String`, gan leihau nifer yr ailddyraniadau y mae angen iddo eu gwneud.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Os yw'r capasiti a roddir yn `0`, ni fydd unrhyw ddyraniad yn digwydd, ac mae'r dull hwn yn union yr un fath â'r dull [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Nid yw'r Llinyn yn cynnwys unrhyw siars, er bod ganddo allu i wneud mwy
    /// assert_eq!(s.len(), 0);
    ///
    /// // Gwneir y rhain i gyd heb ailddyrannu ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ond gall hyn wneud i'r llinyn ailddyrannu
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): gyda cfg(test) nid yw'r dull `[T]::to_vec` cynhenid, sy'n ofynnol ar gyfer y diffiniad dull hwn, ar gael.
    // Gan nad oes angen y dull hwn arnom at ddibenion profi, byddaf yn ei sticio NB gweler y modiwl slice::hack yn slice.rs i gael mwy o wybodaeth
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Trosi vector o bytes i `String`.
    ///
    /// Mae llinyn ([`String`]) wedi ei wneud o bytes ([`u8`]), a vector o bytes ([`Vec<u8>`]) cael ei wneud o bytes, felly swyddogaeth hon yn trosi rhwng y ddau.
    /// Nid yw pob sleisen beit yn `Llinynnau 'dilys, fodd bynnag: mae `String` yn mynnu ei fod yn ddilys UTF-8.
    /// `from_utf8()` gwiriadau i sicrhau bod y bytes yn UTF-8 dilys, ac yna'n gwneud y trawsnewid.
    ///
    /// Os ydych chi'n siŵr bod y sleisen beit yn ddilys UTF-8, ac nad ydych chi am fynd i orbenion y gwiriad dilysrwydd, mae fersiwn anniogel o'r swyddogaeth hon, [`from_utf8_unchecked`], sydd â'r un ymddygiad ond sy'n sgipio'r gwiriad.
    ///
    ///
    /// Bydd y dull hwn yn cymryd gofal i beidio â chopïo'r vector, er mwyn effeithlonrwydd.
    ///
    /// Os oes angen [`&str`] arnoch yn lle `String`, ystyriwch [`str::from_utf8`].
    ///
    /// Gwrthdro'r dull hwn yw [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Yn dychwelyd [`Err`] os nad yw'r sleisen yn UTF-8 gyda disgrifiad o pam nad yw'r bytes a ddarperir yn UTF-8.Mae'r vector y gwnaethoch chi symud i mewn hefyd wedi'i gynnwys.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // rhai beit, mewn vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Rydym yn gwybod bytes hyn yn ddilys, felly byddwn yn defnyddio `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Beitiau anghywir:
    ///
    /// ```
    /// // rhai beit annilys, mewn vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Gweler y docs ar gyfer [`FromUtf8Error`] i gael mwy o fanylion am yr hyn y gallwch chi ei wneud gyda'r gwall hwn.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Trosi tafell o bytes i linyn, gan gynnwys nodau annilys.
    ///
    /// Gwneir llinynnau o bytes ([`u8`]), ac mae sleisen o bytes ([`&[u8]`][byteslice]) wedi'i wneud o bytes, felly mae'r swyddogaeth hon yn trosi rhwng y ddau.Fodd bynnag, nid yw pob tafell beit yn llinynnau dilys: mae'n ofynnol i dannau fod yn ddilys UTF-8.
    /// Yn ystod y trawsnewid hwn, bydd `from_utf8_lossy()` yn disodli unrhyw ddilyniannau UTF-8 annilys gyda [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], sy'n edrych fel hyn:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Os ydych chi'n siŵr bod y sleisen beit yn ddilys UTF-8, ac nad ydych chi am fynd i orbenion y trawsnewid, mae fersiwn anniogel o'r swyddogaeth hon, [`from_utf8_unchecked`], sydd â'r un ymddygiad ond sy'n sgipio'r gwiriadau.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Mae'r swyddogaeth hon yn dychwelyd [`Cow<'a, str>`].Os yw ein tafell beit yn annilys UTF-8, yna mae angen i ni fewnosod y nodau amnewid, a fydd yn newid maint y llinyn, ac felly, angen `String`.
    /// Ond os yw eisoes yn ddilys UTF-8, nid oes angen dyraniad newydd arnom.
    /// Mae'r math hwn o ddychweliad yn caniatáu inni drin y ddau achos.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // rhai beit, mewn vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Beitiau anghywir:
    ///
    /// ```
    /// // rhai beit annilys
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Datgodio vector `v` UTF-16-wedi'i amgodio i mewn i `String`, gan ddychwelyd [`Err`] os yw `v` yn cynnwys unrhyw ddata annilys.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ni wneir hyn trwy collect: : <Result<_, _>> () am resymau perfformiad.
        // FIXME: gellir symleiddio'r swyddogaeth eto pan fydd #48994 ar gau.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Datgodio sleisen `v` wedi'i hamgodio UTF-16 i mewn i `String`, gan ddisodli data annilys â [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Yn wahanol i [`from_utf8_lossy`] sy'n dychwelyd [`Cow<'a, str>`], mae `from_utf16_lossy` yn dychwelyd `String` gan fod angen dyraniad cof ar gyfer y trawsnewidiad UTF-16 i UTF-8.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Yn dadelfennu `String` yn ei gydrannau amrwd.
    ///
    /// Yn dychwelyd y pwyntydd amrwd i'r data sylfaenol, hyd y llinyn (mewn beitiau), a chynhwysedd dyranedig y data (mewn beitiau).
    /// Dyma'r un dadleuon yn yr un drefn â'r dadleuon i [`from_raw_parts`].
    ///
    /// Ar ôl galw y swyddogaeth hon, mae'r galwr yn gyfrifol am y cof a reolir yn flaenorol gan y `String`.
    /// Yr unig ffordd i wneud hyn yw trosi'r pwyntydd amrwd, ei hyd a'i allu yn ôl yn `String` gyda'r swyddogaeth [`from_raw_parts`], gan ganiatáu i'r dinistriwr gyflawni'r gwaith glanhau.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Yn creu `String` newydd o hyd, gallu a phwyntydd.
    ///
    /// # Safety
    ///
    /// Mae hyn yn hynod anniogel, oherwydd nifer yr invariants nad ydyn nhw'n cael eu gwirio:
    ///
    /// * Mae angen i'r cof yn `buf` fod wedi'i ddyrannu'n flaenorol gan yr un dyrannwr y mae'r llyfrgell safonol yn ei ddefnyddio, gydag aliniad gofynnol o 1 yn union.
    /// * `length` mae angen iddo fod yn llai na neu'n hafal i `capacity`.
    /// * `capacity` mae angen iddo fod y gwerth cywir.
    /// * Y `length` cyntaf bytes yn rhaid i `buf` yn ddilys UTF-8.
    ///
    /// Gall torri'r rhain achosi problemau fel llygru strwythurau data mewnol y dyrannwr.
    ///
    /// Mae perchnogaeth `buf` yn cael ei drosglwyddo i bob pwrpas i'r `String` a all wedyn ddeallocateiddio, ailddyrannu neu newid cynnwys y cof y mae'r pwyntydd yn tynnu sylw ato yn ôl ewyllys.
    /// Sicrhewch nad oes unrhyw beth arall yn defnyddio'r pwyntydd ar ôl galw'r swyddogaeth hon.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Diweddarwch hyn pan fydd vec_into_raw_parts wedi'i sefydlogi.
    ///     // Atal gollwng data'r Llinyn yn awtomatig
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Trosi vector o bytes i `String` heb wirio bod y llinyn yn cynnwys UTF-8 dilys.
    ///
    /// Gweler y fersiwn ddiogel, [`from_utf8`], am ragor o fanylion.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel oherwydd nad yw'n gwirio bod y bytes a ddaeth iddo yn ddilys UTF-8.
    /// Os bydd y cyfyngiad hwn yn cael ei dorri, gall achosi problemau annigonolrwydd cof gyda defnyddwyr future yr `String`, gan fod gweddill y llyfrgell safonol yn tybio bod `String`s yn ddilys UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // rhai beit, mewn vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Trosi `String` yn beit vector.
    ///
    /// Mae hyn yn defnyddio'r `String`, felly nid oes angen i ni gopïo ei gynnwys.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Yn tynnu sleisen llinyn sy'n cynnwys yr `String` cyfan.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Trosi `String` yn dafell llinyn symudol.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Appends sleisen llinyn a roddir ar ddiwedd y `String` hwn.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Yn dychwelyd gallu'r `Llinyn 'hwn, mewn beitiau.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Yn sicrhau bod gallu'r `Llinyn 'hwn o leiaf `additional` beit yn fwy na'i hyd.
    ///
    /// Gellir cynyddu'r capasiti o fwy na beit `additional` os yw'n dewis, er mwyn atal ailddyrannu yn aml.
    ///
    ///
    /// Os nad ydych chi eisiau'r ymddygiad "at least" hwn, gweler y dull [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn gorlifo [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Efallai na fydd hyn yn cynyddu'r capasiti mewn gwirionedd:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // bellach mae gan 2 hyd a chynhwysedd o 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Gan fod gennym eisoes gapasiti 8 ychwanegol, mae galw hyn yn ...
    /// s.reserve(8);
    ///
    /// // ... ddim yn cynyddu mewn gwirionedd.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Yn sicrhau bod hyn yn `gallu String` yn cael ei `additional` bytes fwy na'r ei hyd.
    ///
    /// Ystyriwch ddefnyddio'r dull [`reserve`] oni bai eich bod chi'n hollol gwybod yn well na'r dyrannwr.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics os yw'r gallu newydd yn gorlifo `usize`.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Efallai na fydd hyn yn cynyddu'r capasiti mewn gwirionedd:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // bellach mae gan 2 hyd a chynhwysedd o 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Gan fod gennym eisoes gapasiti 8 ychwanegol, mae galw hyn yn ...
    /// s.reserve_exact(8);
    ///
    /// // ... ddim yn cynyddu mewn gwirionedd.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Yn ceisio cadw capasiti i o leiaf `additional` mwy o elfennau gael eu mewnosod yn yr `String` a roddir.
    /// Efallai y bydd y casgliad yn cadw mwy o le i osgoi ailddyrannu yn aml.
    /// Ar ôl ffonio `reserve`, bydd y capasiti yn fwy na neu'n hafal i `self.len() + additional`.
    /// Yn gwneud dim os yw'r gallu eisoes yn ddigonol.
    ///
    /// # Errors
    ///
    /// Os yw'r capasiti yn gorlifo, neu os yw'r dyrannwr yn adrodd am fethiant, yna dychwelir gwall.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Archebwch y cof ymlaen llaw, gan adael os na allwn wneud hynny
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nawr rydyn ni'n gwybod na all hyn OOM yng nghanol ein gwaith cymhleth
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Yn ceisio cadw'r capasiti lleiaf ar gyfer mewnosod yn union `additional` mwy o elfennau yn yr `String` a roddir.
    ///
    /// Ar ôl ffonio `reserve_exact`, bydd y capasiti yn fwy na neu'n hafal i `self.len() + additional`.
    /// Yn gwneud dim os yw'r gallu eisoes yn ddigonol.
    ///
    /// Sylwch y gall y dyrannwr roi mwy o le i'r casgliad nag y mae'n gofyn amdano.
    /// Felly, ni ellir dibynnu ar gapasiti i fod yn union leiaf.
    /// Mae'n well gennych `reserve` os oes disgwyl mewnosodiadau future.
    ///
    /// # Errors
    ///
    /// Os yw'r capasiti yn gorlifo, neu os yw'r dyrannwr yn adrodd am fethiant, yna dychwelir gwall.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Archebwch y cof ymlaen llaw, gan adael os na allwn wneud hynny
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nawr rydyn ni'n gwybod na all hyn OOM yng nghanol ein gwaith cymhleth
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Crebachu gallu'r `String` hwn i gyd-fynd ei hyd.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Yn crebachu gallu'r `String` hwn gyda rhwymiad is.
    ///
    /// Bydd y capasiti yn aros o leiaf mor fawr â'r hyd a'r gwerth a gyflenwir.
    ///
    ///
    /// Os yw'r gallu cyfredol yn llai na'r terfyn isaf, mae hwn yn ddim-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Yn atodi'r [`char`] a roddir i ddiwedd yr `String` hwn.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Yn dychwelyd darn beit o gynnwys y `Llinyn 'hwn.
    ///
    /// Gwrthdro'r dull hwn yw [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Yn byrhau'r `String` hwn i'r hyd penodedig.
    ///
    /// Os yw `new_len` yn fwy na hyd cyfredol y llinyn, nid yw hyn yn cael unrhyw effaith.
    ///
    ///
    /// Sylwch nad yw'r dull hwn yn cael unrhyw effaith ar gapasiti dynodedig y llinyn
    ///
    /// # Panics
    ///
    /// Panics os nad `new_len` yn gorwedd ar ffin [`char`].
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Yn tynnu'r cymeriad olaf o'r byffer llinyn a'i ddychwelyd.
    ///
    /// Yn dychwelyd [`None`] os yw'r `String` hwn yn wag.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Yn tynnu [`char`] o'r `String` hwn mewn safle beit a'i ddychwelyd.
    ///
    /// Gweithrediad *O*(*n*) yw hwn, gan fod angen copïo pob elfen yn y byffer.
    ///
    /// # Panics
    ///
    /// Panics os yw `idx` yn fwy na neu'n hafal i hyd y `Llinyn ', neu os nad yw'n gorwedd ar ffin [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Tynnwch yr holl fatsis o batrwm `pat` yn yr `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Bydd matsys yn cael eu canfod a'u symud yn ailadroddol, felly mewn achosion lle mae patrymau'n gorgyffwrdd, dim ond y patrwm cyntaf fydd yn cael ei ddileu:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // DIOGELWCH: bydd y dechrau a'r diwedd ar ffiniau beit utf8 yr un
        // y docs chwiliwr
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Yn cadw'r cymeriadau a bennir gan y predicate yn unig.
    ///
    /// Hynny yw, tynnwch yr holl nodau `c` fel bod `f(c)` yn dychwelyd `false`.
    /// Mae'r dull hwn yn gweithredu yn ei le, yn ymweld pob cymeriad yn union ar ôl yn y gorchymyn gwreiddiol, ac yn cadw trefn y cymeriadau cadw.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Gall yr union drefn fod yn ddefnyddiol ar gyfer olrhain y wladwriaeth allanol, fel mynegai.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Pwyntiwch idx i'r torgoch nesaf
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Mewnosod cymeriad yn yr `String` hwn mewn safle beit.
    ///
    /// Mae hon yn llawdriniaeth *O*(*n*) gan ei fod yn ei gwneud yn ofynnol copïo pob elfen yn y byffer.
    ///
    /// # Panics
    ///
    /// Panics os `idx` yn fwy na'r `hyd String` yn, neu os nad yw'n gorwedd ar ffin [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Mewnosod sleisen llinyn yn yr `String` hwn mewn safle beit.
    ///
    /// Mae hon yn llawdriniaeth *O*(*n*) gan ei fod yn ei gwneud yn ofynnol copïo pob elfen yn y byffer.
    ///
    /// # Panics
    ///
    /// Panics os `idx` yn fwy na'r `hyd String` yn, neu os nad yw'n gorwedd ar ffin [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Yn dychwelyd cyfeiriad cyfnewidiol at gynnwys yr `String` hwn.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel oherwydd nad yw'n gwirio bod y bytes a ddaeth iddo yn ddilys UTF-8.
    /// Os bydd y cyfyngiad hwn yn cael ei dorri, gall achosi problemau annigonolrwydd cof gyda defnyddwyr future yr `String`, gan fod gweddill y llyfrgell safonol yn tybio bod `String`s yn ddilys UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Yn dychwelyd hyd yr `String` hwn, mewn beitiau, nid [`char`] s na graphemes.
    /// Mewn geiriau eraill, efallai nad dyna mae dyn yn ei ystyried hyd y llinyn.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Yn dychwelyd `true` os oes gan yr `String` hwn hyd o sero, a `false` fel arall.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Yn rhannu'r llinyn yn ddwy yn y mynegai beit a roddir.
    ///
    /// Yn dychwelyd `String` sydd newydd ei ddyrannu.
    /// `self` yn cynnwys bytes `[0, at)`, ac mae'r `String` a ddychwelwyd yn cynnwys beit `[at, len)`.
    /// `at` rhaid iddo fod ar ffin pwynt cod UTF-8.
    ///
    /// Sylwch nad yw gallu `self` yn newid.
    ///
    /// # Panics
    ///
    /// Panics os nad `at` ar ffin bwynt cod `UTF-8`, neu os yw'n y tu hwnt i'r pwynt cod olaf y llinyn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncates `String` hwn, gwared ar yr holl gynnwys.
    ///
    /// Er bod hyn yn golygu y bydd gan yr `String` hyd o sero, nid yw'n cyffwrdd â'i allu.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Creu draenio iterator sy'n cael gwared yr amrediad penodol yn y `String` ac yn cynnyrch y `chars` dileu.
    ///
    ///
    /// Note: Mae'r ystod elfen yn cael ei dynnu hyd yn oed os na chaiff yr ailadroddwr ei fwyta tan y diwedd.
    ///
    /// # Panics
    ///
    /// Panics os nad yw'r man cychwyn neu'r pwynt gorffen yn gorwedd ar ffin [`char`], neu os ydyn nhw allan o ffiniau.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Tynnwch yr amrediad hyd at y β o'r llinyn
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Mae ystod lawn yn clirio'r llinyn
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Diogelwch cof
        //
        // Nid oes gan fersiwn Llinynnol Drain faterion diogelwch cof y fersiwn vector.
        // Mae'r data'n beit unig plaen.
        // Oherwydd bod y tynnu amrediad yn digwydd yn Drop, os yw'r ailadroddwr Drain yn cael ei ollwng, ni fydd y tynnu yn digwydd.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Cymerwch ddau fenthyciad ar yr un pryd.
        // Ni fydd mynediad i'r Llinyn &mut nes bod yr iteriad drosodd, yn Drop.
        let self_ptr = self as *mut _;
        // DIOGELWCH: Mae `slice::range` a `is_char_boundary` yn gwneud y gwiriadau ffiniau priodol.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Yn dileu'r ystod benodol yn y llinyn, ac yn ei le gyda'r llinyn a roddir.
    /// Nid oes angen i'r llinyn a roddir fod yr un hyd â'r amrediad.
    ///
    /// # Panics
    ///
    /// Panics os nad yw'r man cychwyn neu'r pwynt gorffen yn gorwedd ar ffin [`char`], neu os ydyn nhw allan o ffiniau.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Amnewid yr ystod hyd at y β o'r llinyn
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Diogelwch cof
        //
        // Nid oes gan Replace_range faterion diogelwch cof Sblis vector.
        // o'r fersiwn vector.Beitiau plaen yn unig yw'r data.

        // RHYBUDD: Byddai amlinellu'r newidyn hwn yn ddi-sail (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // RHYBUDD: Byddai amlinellu'r newidyn hwn yn ddi-sail (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Byddai defnyddio `range` eto yn ddi-sail (#81138) Rydym yn tybio bod y ffiniau a adroddwyd gan `range` yn aros yr un fath, ond gallai gweithrediad gwrthwynebus newid rhwng galwadau
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Trosi `String` hwn i mewn i [`Box`]`<`[`str`] `>`.
    ///
    /// Bydd hyn yn gollwng unrhyw gapasiti gormodol.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Yn dychwelyd tafell o [`u8`] s beit y ceisiwyd eu trosi i `String`.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // rhai beit annilys, mewn vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Dychwelyd y bytes a gafodd eu ceisio i drosi i `String`.
    ///
    /// Mae'r dull hwn wedi'i lunio'n ofalus i osgoi dyrannu.
    /// Bydd yn defnyddio'r gwall, gan symud y beit allan, fel nad oes angen gwneud copi o'r beit.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // rhai beit annilys, mewn vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Nôl `Utf8Error` i gael rhagor o fanylion am y methiant trosi.
    ///
    /// Mae'r math [`Utf8Error`] a ddarperir gan [`std::str`] yn cynrychioli camgymeriad a all ddigwydd wrth drosi tafell o [`u8`] au i [`&str`].
    /// Yn yr ystyr hwn, mae'n analog i `FromUtf8Error`.
    /// Gweler ei ddogfennaeth am ragor o fanylion ar ei ddefnyddio.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // rhai beit annilys, mewn vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // mae'r beit cyntaf yn annilys yma
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Oherwydd ein bod yn ailadrodd dros `Llinynnau ', gallwn osgoi o leiaf un dyraniad trwy gael y llinyn cyntaf gan yr ailadroddwr ac atodi'r holl dannau dilynol iddo.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Oherwydd ein bod yn ailadrodd dros CoWs, gallwn (potentially) osgoi o leiaf un dyraniad trwy gael yr eitem gyntaf ac atodi'r holl eitemau dilynol iddi.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Impl cyfleustra sy'n dirprwyo i'r impl ar gyfer `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Yn creu `String` gwag.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Yn gweithredu'r gweithredwr `+` ar gyfer concatenating dau dant.
///
/// Mae hyn yn defnyddio'r `String` ar yr ochr chwith ac yn ail-ddefnyddio ei byffer (ei dyfu os oes angen).
/// Gwneir hyn er mwyn osgoi dyrannu `String` newydd a chopïo'r cynnwys cyfan ar bob gweithrediad, a fyddai'n arwain at amser rhedeg *O*(*n*^ 2) wrth adeiladu llinyn *n*-tete trwy gyd-daro dro ar ôl tro.
///
///
/// Dim ond benthyg y llinyn ar yr ochr dde;copïir ei gynnwys i'r `String` a ddychwelwyd.
///
/// # Examples
///
/// Gydgadwyno'r dau `String`s yn cymryd y cyntaf gan werth ac yn benthyg yr ail:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` yn cael ei symud ac ni ellir ei ddefnyddio yma mwyach.
/// ```
///
/// Os ydych chi am barhau i ddefnyddio'r `String` cyntaf, gallwch ei glonio a'i atodi i'r clôn yn lle:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` yn dal i fod yn ddilys yma.
/// ```
///
/// Gellir gwneud sleisys `&str` sy'n cyd-fynd trwy drosi'r cyntaf yn `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Yn gweithredu'r gweithredwr `+=` ar gyfer atodi i `String`.
///
/// Mae gan hyn yr un ymddygiad â'r dull [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Alias math ar gyfer [`Infallible`].
///
/// Mae'r ffugenw yn bodoli ar gyfer cysondeb yn ôl, a gellir ei anghymeradwy yn y pen draw.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait ar gyfer trosi gwerth i `String`.
///
/// Mae'r trait hwn yn cael ei weithredu'n awtomatig ar gyfer unrhyw fath sy'n gweithredu'r [`Display`] trait.
/// O'r herwydd, ni ddylid gweithredu `ToString` yn uniongyrchol:
/// [`Display`] dylid ei weithredu yn lle, a chewch weithrediad `ToString` am ddim.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Yn trosi'r gwerth a roddir i `String`.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Yn y gweithrediad hwn, y dull `to_string` panics os bydd gweithrediad `Display` yn dychwelyd gwall.
/// Mae hyn yn dynodi gweithrediad `Display` anghywir gan nad yw `fmt::Write for String` byth yn dychwelyd gwall ei hun.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Canllaw cyffredin yw peidio â mewnlinio swyddogaethau generig.
    // Fodd bynnag, mae tynnu `#[inline]` o'r dull hwn yn achosi atchweliadau nad ydynt yn ddibwys.
    // Gweler <https://github.com/rust-lang/rust/pull/74852>, yr ymgais olaf i geisio ei dynnu.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Trosi `&mut str` yn `String`.
    ///
    /// Dyrennir y canlyniad ar y domen.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: prawf yn tynnu libstd i mewn, sy'n achosi gwallau yma
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Trosi'r sleisen `str` mewn bocs a roddir yn `String`.
    /// Mae'n werth nodi bod y sleisen `str` yn eiddo.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Trosi'r `String` a roddir i dafell `str` mewn bocs sy'n eiddo.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Trosi sleisen llinyn i mewn i amrywiad Fenthycwyd.
    /// Ni chyflawnir dyraniad domen, ac ni chopïir y llinyn.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Trosi Llinyn yn amrywiad Perchnogaeth.
    /// Ni chyflawnir dyraniad domen, ac ni chopïir y llinyn.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Trosi cyfeiriad Llinynnol yn amrywiad Fenthycwyd.
    /// Ni chyflawnir dyraniad domen, ac ni chopïir y llinyn.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Yn trosi'r `String` a roddir i vector `Vec` sy'n dal gwerthoedd math `u8`.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Ailadroddwr draenio ar gyfer `String`.
///
/// Mae'r strwythur hwn yn cael ei greu gan y dull [`drain`] ar [`String`].
/// Gweler ei ddogfennaeth am fwy.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Bydd yn cael ei ddefnyddio fel&'a mut String yn y dinistriwr
    string: *mut String,
    /// Dechrau rhan i'w dynnu
    start: usize,
    /// Diwedd y rhan i'w dynnu
    end: usize,
    /// ystod sy'n weddill ar hyn o bryd i dynnu
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Defnyddiwch Vec::drain.
            // "Reaffirm" y gwiriadau ffiniau i osgoi mewnosod cod panic eto.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Yn dychwelyd y llinyn (is) sy'n weddill o'r ailadroddwr hwn fel sleisen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment impls AsRef isod wrth sefydlogi.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment wrth sefydlogi `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>ar gyfer Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ar gyfer Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}