#![stable(feature = "rust1", since = "1.0.0")]

//! Awgrymiadau cyfrif cyfeirnod diogel-edau.
//!
//! Gweler y ddogfennaeth [`Arc<T>`][Arc] i gael mwy o fanylion.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Terfyn meddal ar faint o gyfeiriadau y gellir eu gwneud at `Arc`.
///
/// Bydd mynd uwchlaw'r terfyn hwn yn erthylu'ch rhaglen (er nad o reidrwydd) yng nghyfeiriadau _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// Nid yw ThreadSanitizer yn cefnogi ffensys cof.
// Er mwyn osgoi adroddiadau positif ffug wrth weithredu Arc/Weak, defnyddiwch lwythi atomig ar gyfer cydamseru yn lle.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Pwyntydd cyfrif cyfeirnod-ddiogel.Mae 'Arc' yn sefyll am 'Atomically Reference Counted'.
///
/// Mae'r math `Arc<T>` yn darparu perchnogaeth a rennir o werth math `T`, wedi'i ddyrannu yn y domen.Mae galw [`clone`][clone] ar `Arc` yn cynhyrchu enghraifft `Arc` newydd, sy'n tynnu sylw at yr un dyraniad ar y domen â'r ffynhonnell `Arc`, wrth gynyddu cyfrif cyfeirio.
/// Pan fydd y pwyntydd `Arc` olaf i ddyraniad penodol yn cael ei ddinistrio, mae'r gwerth sy'n cael ei storio yn y dyraniad hwnnw (y cyfeirir ato'n aml fel "inner value") hefyd yn cael ei ollwng.
///
/// Mae cyfeiriadau a rennir yn Rust yn gwrthod treiglo yn ddiofyn, ac nid yw `Arc` yn eithriad: yn gyffredinol ni allwch gael cyfeiriad treiddgar at rywbeth y tu mewn i `Arc`.Os oes angen treiglo trwy `Arc`, defnyddiwch [`Mutex`][mutex], [`RwLock`][rwlock], neu un o'r mathau [`Atomic`][atomic].
///
/// ## Diogelwch Edau
///
/// Yn wahanol i [`Rc<T>`], `Arc<T>` yn defnyddio gweithrediadau atomig ar gyfer ei gyfrif cyfeirio.Mae hyn yn golygu ei fod yn ddiogel o ran edau.Yr anfantais yw bod gweithrediadau atomig yn ddrytach na mynediad cof cyffredin.Os nad ydych yn rhannu dyraniadau wedi'u cyfrif cyfeirnod rhwng edafedd, ystyriwch ddefnyddio [`Rc<T>`] ar gyfer gorbenion is.
/// [`Rc<T>`] yn ddiofyn diogel, oherwydd bydd y casglwr yn dal unrhyw ymgais i anfon [`Rc<T>`] rhwng edafedd.
/// Fodd bynnag, gallai llyfrgell ddewis `Arc<T>` er mwyn rhoi mwy o hyblygrwydd i ddefnyddwyr llyfrgell.
///
/// `Arc<T>` yn gweithredu [`Send`] a [`Sync`] cyhyd â bod yr `T` yn gweithredu [`Send`] a [`Sync`].
/// Pam na allwch chi roi math `T` nad yw'n ddiogel o ran edau mewn `Arc<T>` i'w wneud yn ddiogel o ran edau?Gall hyn fod ychydig yn wrth-reddfol ar y dechrau: wedi'r cyfan, onid pwynt diogelwch edau `Arc<T>`?Yr allwedd yw hyn: mae `Arc<T>` yn ei gwneud hi'n ddiogel i edau fod â pherchnogaeth luosog o'r un data, ond nid yw'n ychwanegu diogelwch edau at ei ddata.
///
/// Ystyriwch `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] nid [`Sync`], ac os oedd `Arc<T>` bob amser yn [`Send`], `Arc <` [`RefCell<T>byddai`]`>`hefyd.
/// Ond yna byddai gennym broblem:
/// [`RefCell<T>`] Nid yw edau diogel;mae'n cadw golwg ar y cyfrif benthyca gan ddefnyddio gweithrediadau nad ydynt yn atomig.
///
/// Yn y diwedd, mae hyn yn golygu efallai y bydd angen i chi baru `Arc<T>` gyda rhyw fath o fath [`std::sync`], [`Mutex<T>`][mutex] fel arfer.
///
/// ## Cylchoedd torri gyda `Weak`
///
/// Gellir defnyddio'r dull [`downgrade`][downgrade] i greu pwyntydd [`Weak`] nad yw'n berchen arno.Gall [`Weak`] pwyntydd fod [`upgrade`][uwchraddio] d i `Arc`, ond bydd hyn yn dychwelyd [`None`] os yw gwerth ei storio yn y dyraniad eisoes wedi cael ei ollwng.
/// Mewn geiriau eraill, nid yw awgrymiadau `Weak` yn cadw'r gwerth y tu mewn i'r dyraniad yn fyw;fodd bynnag, maen nhw *yn* cadw'r * dyraniad (y storfa gefn am y gwerth) yn fyw.
///
/// Ni fydd cylch rhwng awgrymiadau `Arc` byth yn cael ei ddeallocated.
/// Am y rheswm hwn, defnyddir [`Weak`] i dorri beiciau.Er enghraifft, gallai coeden gael awgrymiadau `Arc` cryf o nodau rhiant i blant, ac awgrymiadau [`Weak`] gan blant yn ôl i'w rhieni.
///
/// # Cyfeiriadau clonio
///
/// Mae creu cyfeirnod newydd o bwyntydd cyfrif-gyfeiriedig presennol yn cael ei wneud gan ddefnyddio'r `Clone` trait a weithredir ar gyfer [`Arc<T>`][Arc] a [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Mae'r ddau gystrawen isod yn gyfwerth.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, ac foo gyd arcau y pwynt i'r un lleoliad cof
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` dad-gyfeiriadau i `T` yn awtomatig (trwy'r [`Deref`][deref] trait), felly gallwch chi alw dulliau `T` ar werth math `Arc<T>`.Er mwyn osgoi gwrthdaro enwau â dulliau `T`, mae dulliau `Arc<T>` ei hun yn swyddogaethau cysylltiedig, a elwir yn defnyddio [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Gellir hefyd galw gweithrediadau traits fel `Clone` gan ddefnyddio cystrawen gwbl gymwys.
/// Mae'n well gan rai pobl ddefnyddio cystrawen gwbl gymwys, tra bod yn well gan eraill ddefnyddio cystrawen dull-galw.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Cystrawen dull-galw
/// let arc2 = arc.clone();
/// // Cystrawen gwbl gymwys
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] nid yw'n awto-barchu i `T`, oherwydd mae'n bosibl bod y gwerth mewnol eisoes wedi'i ollwng.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Rhannu rhywfaint o ddata na ellir ei symud rhwng edafedd:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Sylwer nad ydym **yn** rhedeg profion hyn yma.
// Mae'r adeiladwyr windows yn mynd yn hynod anhapus os yw edau yn goroesi'r brif edau ac yna'n gadael ar yr un pryd (rhywbeth deadlocks) felly rydyn ni'n osgoi hyn yn gyfan gwbl trwy beidio â rhedeg y profion hyn.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Rhannu [`AtomicUsize`] treiddiol:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Gweler yr [`rc` documentation][rc_examples] i gael mwy o enghreifftiau o gyfrif cyfeirnod yn gyffredinol.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` yn fersiwn o [`Arc`] sy'n dal cyfeiriad nad yw'n berchen ar y dyraniad a reolir.
/// Gellir cyrchu'r dyraniad trwy ffonio [`upgrade`] ar y pwyntydd `Weak`, sy'n dychwelyd [`Opsiwn`]`<`[`Arc`]<T>> `.
///
/// Gan nid yw cyfeiriad `Weak` yn cyfrif tuag at berchnogaeth, ni fydd yn atal y gwerth ei storio yn y dyraniad rhag cael ei ollwng, a `Weak` ei hun yn gwneud unrhyw warant ynglŷn â gwerth yn dal i fod yn bresennol.
///
/// Felly gall ddychwelyd [`None`] pan fydd [`uwchraddio`] d.
/// Sylwch, fodd bynnag, fod cyfeirnod `Weak`*yn* atal y dyraniad ei hun (y storfa gefn) rhag cael ei ddeallocated.
///
/// Mae pwyntydd `Weak` yn ddefnyddiol ar gyfer cadw cyfeiriad dros dro at y dyraniad a reolir gan [`Arc`] heb atal ei werth mewnol rhag cael ei ollwng.
/// Fe'i defnyddir hefyd i atal cyfeiriadau cylchol rhwng awgrymiadau [`Arc`], gan na fyddai cyfeiriadau cydberchnogaeth byth yn caniatáu gollwng naill ai [`Arc`].
/// Er enghraifft, gallai coeden gael awgrymiadau [`Arc`] cryf gan rieni nodau i blant, a `Weak` awgrymiadau gan blant yn ôl i'w rhieni.
///
/// Y ffordd arferol i gael pwyntydd `Weak` yw galw [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Mae hwn yn `NonNull` i ganiatáu optimeiddio maint y math hwn mewn enymau, ond nid yw o reidrwydd yn bwyntydd dilys.
    //
    // `Weak::new` yn gosod hwn i `usize::MAX` fel nad oes angen iddo ddyrannu lle ar y domen.
    // Nid yw hynny'n werth y bydd pwyntydd go iawn byth yn ei gael oherwydd bod gan RcBox aliniad o leiaf 2.
    // Mae hyn yn bosibl dim ond pan fydd `T: Sized`;bythol `T` byth yn hongian.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Mae hyn yn brawf repr(C) i future yn erbyn ail-archebu maes posibl, a fyddai'n ymyrryd â [into|from]_raw() sydd fel arall yn ddiogel o fathau mewnol trosglwyddadwy.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // mae'r gwerth usize::MAX yn gweithredu fel sentinel ar gyfer "locking" dros dro y gallu i uwchraddio awgrymiadau gwan neu israddio rhai cryf;defnyddir hwn i osgoi rasys yn `make_mut` a `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Yn adeiladu `Arc<T>` newydd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Dechreuwch y cyfrif pwyntydd gwan fel 1 sef y pwyntydd gwan sydd gan yr holl awgrymiadau cryf (kinda), gweler std/rc.rs i gael mwy o wybodaeth
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Yn llunio `Arc<T>` newydd gan ddefnyddio cyfeiriad gwan ato'i hun.
    /// Bydd ceisio uwchraddio'r cyfeirnod gwan cyn i'r swyddogaeth hon ddychwelyd yn arwain at werth `None`.
    /// Fodd bynnag, gellir clonio'r cyfeirnod gwan yn rhydd a'i storio i'w ddefnyddio yn nes ymlaen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Lluniwch y mewnol yn nhalaith "uninitialized" gydag un cyfeiriad gwan.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Mae'n bwysig nad ydym yn ildio perchnogaeth o'r pwyntydd gwan, neu fel arall gallai'r cof gael ei ryddhau erbyn i `data_fn` ddychwelyd.
        // Pe byddem wir eisiau pasio perchnogaeth, gallem greu pwyntydd gwan ychwanegol inni ein hunain, ond byddai hyn yn arwain at ddiweddariadau ychwanegol i'r cyfrif cyfeiriadau gwan na fyddai efallai'n angenrheidiol fel arall.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nawr gallwn gychwyn y gwerth mewnol yn iawn a throi ein cyfeirnod gwan yn gyfeirnod cryf.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Rhaid i'r ysgrifennu uchod i'r maes data fod yn weladwy i unrhyw edafedd sy'n arsylwi cyfrif cryf nad yw'n sero.
            // Felly mae angen o leiaf archebu "Release" er mwyn cydamseru â'r `compare_exchange_weak` yn `Weak::upgrade`.
            //
            // "Acquire" nid oes angen archebu.
            // Wrth ystyried ymddygiadau posibl `data_fn` does ond angen i ni edrych ar yr hyn y gallai ei wneud gyda chyfeiriad at `Weak` na ellir ei uwchraddio:
            //
            // - Gall *glonio* yr `Weak`, gan gynyddu'r cyfrif cyfeirio gwan.
            // - Gall ollwng y clonau hynny, gan ostwng y cyfrif cyfeirio gwan (ond byth i sero).
            //
            // Nid yw'r sgîl-effeithiau hyn yn effeithio arnom mewn unrhyw ffordd, ac nid oes unrhyw sgîl-effeithiau eraill yn bosibl gyda chod diogel yn unig.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Dylai cyfeiriadau cryf gyda'i gilydd fod yn berchen ar gyfeirnod gwan a rennir, felly peidiwch â rhedeg y dinistriwr ar gyfer ein hen gyfeirnod gwan.
        //
        mem::forget(weak);
        strong
    }

    /// Yn llunio `Arc` newydd gyda chynnwys heb ei ddynodi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yn adeiladu `Arc` newydd gyda chynnwys uninitialized, gyda'r cof yn cael ei llenwi â `0` bytes.
    ///
    ///
    /// Gweler [`MaybeUninit::zeroed`][zeroed] am enghreifftiau o ddefnydd cywir ac anghywir o'r dull hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yn adeiladu `Pin<Arc<T>>` newydd.
    /// Os nad yw `T` yn gweithredu `Unpin`, yna bydd `data` yn cael ei binio yn y cof ac ni ellir ei symud.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Yn llunio `Arc<T>` newydd, gan ddychwelyd gwall os bydd y dyraniad yn methu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Dechreuwch y cyfrif pwyntydd gwan fel 1 sef y pwyntydd gwan sydd gan yr holl awgrymiadau cryf (kinda), gweler std/rc.rs i gael mwy o wybodaeth
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Yn llunio `Arc` newydd gyda chynnwys heb ei ddynodi, gan ddychwelyd gwall os yw'r dyraniad yn methu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Yn adeiladu `Arc` newydd gyda chynnwys uninitialized, gyda'r cof yn cael ei llenwi â `0` bytes, gan ddychwelyd gwall os dyraniad yn methu.
    ///
    ///
    /// Gweler [`MaybeUninit::zeroed`][zeroed] am enghreifftiau o ddefnydd cywir ac anghywir o'r dull hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Yn dychwelyd y gwerth mewnol, os oes gan yr `Arc` un cyfeiriad cryf yn union.
    ///
    /// Fel arall, dychwelir [`Err`] gyda'r un `Arc` ag a basiwyd i mewn.
    ///
    ///
    /// Bydd hyn yn llwyddo hyd yn oed os oes cyfeiriadau gwan rhagorol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Gwnewch bwyntydd gwan i lanhau'r cyfeirnod cryf-wan ymhlyg
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Yn llunio tafell newydd wedi'i chyfrifo â chyfeirnod atomig gyda chynnwys heb ei ddynodi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Yn llunio tafell newydd wedi'i chyfrifo â chyfeirnod atomig gyda chynnwys heb ei ddynodi, gyda'r cof yn cael ei lenwi â beit `0`.
    ///
    ///
    /// Gweler [`MaybeUninit::zeroed`][zeroed] am enghreifftiau o ddefnydd cywir ac anghywir o'r dull hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Trosi i `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Yn yr un modd â [`MaybeUninit::assume_init`], mater i'r galwr yw gwarantu bod y gwerth mewnol mewn cyflwr cychwynnol.
    ///
    /// Mae galw hyn pan nad yw'r cynnwys wedi'i gychwyn yn llawn eto yn achosi ymddygiad heb ei ddiffinio ar unwaith.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Trosi i `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Yn yr un modd â [`MaybeUninit::assume_init`], mater i'r galwr yw gwarantu bod y gwerth mewnol mewn cyflwr cychwynnol.
    ///
    /// Mae galw hyn pan nad yw'r cynnwys wedi'i gychwyn yn llawn eto yn achosi ymddygiad heb ei ddiffinio ar unwaith.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Cychwyn cychwynnol:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Yn defnyddio y `Arc`, gan ddychwelyd y pwyntydd lapio.
    ///
    /// Er mwyn osgoi gollyngiad cof rhaid trosi'r pwyntydd yn ôl i `Arc` gan ddefnyddio [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Mae'n darparu pwyntydd amrwd i'r data.
    ///
    /// Nid yw'r cyfrifon yn cael eu heffeithio mewn unrhyw ffordd ac ni chaiff yr `Arc` ei fwyta.
    /// Mae'r pwyntydd yn ddilys cyhyd â bod cyfrifiadau cryf yn yr `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // DIOGELWCH: Ni all hyn fynd trwy Deref::deref neu RcBoxPtr::inner oherwydd
        // mae hyn yn ofynnol i gadw tarddiad raw/mut fel bod ee
        // `get_mut` yn gallu ysgrifennu trwy'r pwyntydd ar ôl i'r Rc gael ei adfer trwy `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Yn adeiladu `Arc<T>` o bwyntydd amrwd.
    ///
    /// Rhaid bod y pwyntydd amrwd wedi'i ddychwelyd o'r blaen trwy alwad i [`Arc<U>::into_raw`][into_raw] lle mae'n rhaid i `U` fod â'r un maint ac aliniad â `T`.
    /// Mae hyn yn ddibwys yn wir os yw `U` yn `T`.
    /// Sylwch, os nad yw `U` yn `T` ond bod ganddo'r un maint ac aliniad, mae hyn yn y bôn fel cyfeiriadau trawsrywiol o wahanol fathau.
    /// Gweler [`mem::transmute`][transmute] i gael mwy o wybodaeth am ba gyfyngiadau sy'n berthnasol yn yr achos hwn.
    ///
    /// Rhaid i ddefnyddiwr `from_raw` sicrhau bod gwerth penodol o `T` yn cael ei ollwng unwaith yn unig.
    ///
    /// Mae'r swyddogaeth hon yn anniogel oherwydd gall defnydd amhriodol arwain at unsafety cof, hyd yn oed os nad y `Arc<T>` ddychwelwyd yn cael ei defnyddio.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Trosi yn ôl i `Arc` i atal gollyngiadau.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Byddai galwadau pellach i `Arc::from_raw(x_ptr)` yn anniogel o ran cof.
    /// }
    ///
    /// // Rhyddhawyd y cof pan aeth `x` allan o'i gwmpas uchod, felly mae `x_ptr` bellach yn hongian!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Gwrthdroi'r gwrthbwyso i ddod o hyd i'r ArcInner gwreiddiol.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Yn creu pwyntydd [`Weak`] newydd i'r dyraniad hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Mae'r Ymlacio hwn yn iawn oherwydd rydyn ni'n gwirio'r gwerth yn y CAS isod.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // gwirio a yw'r cownter gwan ar hyn o bryd "locked";os felly, troelli.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: mae'r cod hwn ar hyn o bryd yn anwybyddu'r posibilrwydd o orlif
            // i mewn i usize::MAX;yn gyffredinol mae angen addasu Rc ac Arc i ddelio â gorlif.
            //

            // Yn wahanol i Clone(), mae angen i hwn fod yn ddarlleniad Caffael i gydamseru â'r ysgrifen sy'n dod o `is_unique`, fel bod y digwyddiadau cyn yr ysgrifen honno'n digwydd cyn i'r darlleniad hwn.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Sicrhewch nad ydym yn creu Gwan hongian
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Cael nifer yr awgrymiadau [`Weak`] i'r dyraniad hwn.
    ///
    /// # Safety
    ///
    /// Mae'r dull hwn ei ben ei hun yn ddiogel, ond gan ddefnyddio ei fod yn gofyn gofal ychwanegol yn gywir.
    /// Gall edau arall newid y cyfrif gwan ar unrhyw adeg, gan gynnwys o bosibl rhwng y galw dull hwn ac yn gweithredu ar y canlyniad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Mae'r honiad hwn yn benderfynol oherwydd nid ydym wedi rhannu'r `Arc` neu'r `Weak` rhwng edafedd.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Os bydd y cyfrif gwan ei gloi ar hyn o bryd, mae'r gwerth y cyfrif yn 0 yn union cyn cymryd y clo.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Cael nifer yr awgrymiadau (`Arc`) cryf i'r dyraniad hwn.
    ///
    /// # Safety
    ///
    /// Mae'r dull hwn ei ben ei hun yn ddiogel, ond gan ddefnyddio ei fod yn gofyn gofal ychwanegol yn gywir.
    /// Gall edau arall newid y cyfrif cryf ar unrhyw adeg, gan gynnwys o bosibl rhwng galw'r dull hwn a gweithredu ar y canlyniad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Mae'r honiad hwn yn benderfynol oherwydd nid ydym wedi rhannu'r `Arc` rhwng edafedd.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Yn cynyddu'r cyfrif cyfeirio cryf ar yr `Arc<T>` sy'n gysylltiedig â'r pwyntydd a ddarperir gan un.
    ///
    /// # Safety
    ///
    /// Rhaid bod y pwyntydd wedi'i sicrhau trwy `Arc::into_raw`, a rhaid i'r enghraifft `Arc` gysylltiedig fod yn ddilys (h.y.
    /// rhaid i'r cyfrif cryf fod o leiaf 1) am hyd y dull hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Mae'r honiad hwn yn benderfynol oherwydd nid ydym wedi rhannu'r `Arc` rhwng edafedd.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Cadw'r Arc, ond peidiwch â chyffwrdd refcount drwy lapio mewn ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Nawr cynyddu refcount, ond nid ydynt yn gollwng refcount newydd naill ai
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Yn lleihau'r cyfrif cyfeirnod cryf ar yr `Arc<T>` sy'n gysylltiedig â'r pwyntydd a ddarperir gan un.
    ///
    /// # Safety
    ///
    /// Rhaid bod y pwyntydd wedi'i sicrhau trwy `Arc::into_raw`, a rhaid i'r enghraifft `Arc` gysylltiedig fod yn ddilys (h.y.
    /// rhaid i'r cyfrif cryf fod o leiaf 1) wrth alw'r dull hwn.
    /// Gellir defnyddio'r dull hwn i ryddhau'r `Arc` terfynol a'r storfa gefn, ond ni ddylid galw ** ar ôl i'r `Arc` terfynol gael ei ryddhau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Mae'r honiadau hynny'n benderfynol oherwydd nid ydym wedi rhannu'r `Arc` rhwng edafedd.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Mae'r anniogelrwydd hwn yn iawn oherwydd er bod yr arc hwn yn fyw rydym yn sicr bod y pwyntydd mewnol yn ddilys.
        // Ar ben hynny, rydyn ni'n gwybod bod strwythur `ArcInner` ei hun yn `Sync` oherwydd bod y data mewnol yn `Sync` hefyd, felly rydyn ni'n iawn benthyg pwyntydd na ellir ei symud i'r cynnwys hwn.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Rhan heb linell o `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Dinistriwch y data ar yr adeg hon, er efallai na fyddwn yn rhyddhau'r dyraniad blwch ei hun (efallai y bydd awgrymiadau gwan yn gorwedd o gwmpas o hyd).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Gollyngwch y cyfeirnod gwan ar y cyd a ddelir gan bob cyfeiriad cryf
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ffurflenni `true` os yw'r ddau `Arc`s bwynt at yr un dyraniad (mewn modd tebyg i [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Yn dyrannu `ArcInner<T>` gyda digon o le ar gyfer gwerth mewnol nad yw'n sicr o fod lle mae'r cynllun wedi'i ddarparu.
    ///
    /// Gelwir y swyddogaeth `mem_to_arcinner` gyda'r pwyntydd data a rhaid iddi ddychwelyd pwyntydd (a allai fod yn dew) ar gyfer yr `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Cyfrifwch gosodiad gan ddefnyddio'r cynllun gwerth a roddir.
        // Yn flaenorol, cyfrifwyd y cynllun ar yr ymadrodd `&*(ptr as* const ArcInner<T>)`, ond roedd hyn yn creu cyfeiriad wedi'i gamlinio (gweler #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Yn dyrannu `ArcInner<T>` gyda digon o le ar gyfer gwerth mewnol a allai fod yn anenwog lle mae'r cynllun wedi'i ddarparu, gan ddychwelyd gwall os yw'r dyraniad yn methu.
    ///
    ///
    /// Gelwir y swyddogaeth `mem_to_arcinner` gyda'r pwyntydd data a rhaid iddi ddychwelyd pwyntydd (a allai fod yn dew) ar gyfer yr `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Cyfrifwch gosodiad gan ddefnyddio'r cynllun gwerth a roddir.
        // Yn flaenorol, cyfrifwyd y cynllun ar yr ymadrodd `&*(ptr as* const ArcInner<T>)`, ond roedd hyn yn creu cyfeiriad wedi'i gamlinio (gweler #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Cychwyn yr ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Yn dyrannu `ArcInner<T>` gyda digon o le ar gyfer gwerth mewnol heb ei feintio.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Dyrannu ar gyfer yr `ArcInner<T>` gan ddefnyddio'r gwerth a roddir.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copïwch werth fel beit
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Rhyddhewch y dyraniad heb ollwng ei gynnwys
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Yn dyrannu `ArcInner<[T]>` gyda'r hyd penodol.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copïwch elfennau o'r sleisen i Arc <\[T\]> sydd newydd ei ddyrannu
    ///
    /// Yn anniogel oherwydd bod yn rhaid i'r galwr naill ai gymryd perchnogaeth neu rwymo `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Yn llunio `Arc<[T]>` o ailadroddwr y gwyddys ei fod o faint penodol.
    ///
    /// Nid yw ymddygiad wedi'i ddiffinio pe bai'r maint yn anghywir.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Gwarchod Panic wrth glonio elfennau T.
        // Os bydd panic, bydd elfennau sydd wedi'u hysgrifennu i'r ArcInner newydd yn cael eu gollwng, yna bydd y cof yn cael ei ryddhau.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pwyntydd i'r elfen gyntaf
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // I gyd yn glir.Anghofiwch y gard felly nid yw'n rhyddhau'r ArcInner newydd.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Arbenigedd trait a ddefnyddir ar gyfer `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Yn gwneud clôn o'r pwyntydd `Arc`.
    ///
    /// Mae hyn yn creu pwyntydd arall i'r un dyraniad, gan gynyddu'r cyfrif cyfeirio cryf.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Mae defnyddio archeb hamddenol yn iawn yma, gan fod gwybodaeth o'r cyfeirnod gwreiddiol yn atal edafedd eraill rhag dileu'r gwrthrych yn wallus.
        //
        // Fel yr eglurwyd yn yr [Boost documentation][1], Gellir cynyddu'r cownter cyfeirio bob amser gyda memory_order_relaxed: Dim ond o gyfeirnod sy'n bodoli y gellir ffurfio cyfeiriadau newydd at wrthrych, a rhaid i basio cyfeirnod sy'n bodoli eisoes o un edefyn i'r llall ddarparu unrhyw gydamseriad gofynnol.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Fodd bynnag, mae angen i ni warchod rhag refcounts enfawr rhag ofn bod rhywun yn `mem: : forget`ing arcau.
        // Os na wnawn hyn gall y cyfrif orlifo a bydd defnyddwyr yn defnyddio am ddim.
        // Rydym yn dirlawn yn hiliol i `isize::MAX` gan dybio nad oes edafedd ~2 biliwn yn cynyddu'r cyfrif cyfeirio ar unwaith.
        //
        // Ni fydd y branch hwn byth yn cael ei gymryd mewn unrhyw raglen realistig.
        //
        // Rydym yn erthylu oherwydd bod rhaglen o'r fath yn hynod degenerate, ac nid ydym yn poeni i'w gefnogi.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Yn gwneud cyfeiriad symudol i'r `Arc` a roddir.
    ///
    /// Os oes eraill yn arwyddion `Arc` neu [`Weak`] i'r un dyraniad, yna bydd `make_mut` yn creu dyraniad newydd a invoke [`clone`][clone] ar werth mewnol er mwyn sicrhau perchnogaeth unigryw.
    /// Cyfeirir at hyn hefyd fel clôn-ar-ysgrifennu.
    ///
    /// Sylwch fod hyn yn wahanol i ymddygiad [`Rc::make_mut`] sy'n disassociates unrhyw awgrymiadau `Weak` sy'n weddill.
    ///
    /// Gweler hefyd [`get_mut`][get_mut], a fydd yn methu yn hytrach na chlonio.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ddim yn clonio unrhyw beth
    /// let mut other_data = Arc::clone(&data); // Ddim yn clonio data mewnol
    /// *Arc::make_mut(&mut data) += 1;         // Clonau data mewnol
    /// *Arc::make_mut(&mut data) += 1;         // Ddim yn clonio unrhyw beth
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ddim yn clonio unrhyw beth
    ///
    /// // Nawr mae `data` a `other_data` yn pwyntio at wahanol ddyraniadau.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Sylwch fod gennym gyfeirnod cryf a chyfeirnod gwan.
        // Felly, gan ryddhau ein cyfeirnod cryf yn unig y bydd peidio, ei ben ei hun, yn achosi i'r cof i gael ei deallocated.
        //
        // Defnyddiwch Acquire i sicrhau ein bod yn gweld unrhyw ysgrifeniadau i `weak` sy'n digwydd cyn i ryddhad ysgrifennu (hy, gostyngiadau) i `strong`.
        // Gan ein bod yn dal cyfrif gwan, does dim siawns y gallai'r ArcInner ei hun gael ei ddeall.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Mae pwyntydd cryf arall yn bodoli, felly mae'n rhaid i ni glonio.
            // Rhag-ddyrannu'r cof i ganiatáu ysgrifennu'r gwerth wedi'i glonio yn uniongyrchol.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Mae ymlacio yn yr uchod oherwydd bod hyn yn sylfaenol yn optimeiddiad: rydym bob amser yn rasio gydag awgrymiadau gwan yn cael eu gollwng.
            // Achos gwaethaf, dyrannwyd Arc newydd yn ddiangen yn y pen draw.
            //

            // Gwnaethom ddileu'r cyf cryf olaf, ond mae cyfeiriadau gwan ychwanegol ar ôl.
            // Byddwn yn symud y cynnwys i Arc newydd, ac yn annilysu'r cyfeiriadau gwan eraill.
            //

            // Sylwch nad yw'n bosibl i ddarlleniad `weak` esgor ar usize::MAX (h.y., wedi'i gloi), gan mai dim ond edau sydd â chyfeirnod cryf y gellir cloi'r cyfrif gwan.
            //
            //

            // Gwireddwch ein pwyntydd gwan ymhlyg ein hunain, fel y gall lanhau'r ArcInner yn ôl yr angen.
            //
            let _weak = Weak { ptr: this.ptr };

            // Yn gallu dwyn y data yn unig, y cyfan sydd ar ôl yw Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Ni oedd y cyfeiriad yn unig o naill ai bath;taro yn ôl i fyny'r cyfrif cyf cryf.
            //
            this.inner().strong.store(1, Release);
        }

        // Yn yr un modd â `get_mut()`, mae'r anniogelrwydd yn iawn oherwydd bod ein cyfeirnod naill ai'n unigryw i ddechrau, neu'n dod yn un wrth glonio'r cynnwys.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Yn dychwelyd cyfeiriad symudol i'r `Arc` a roddir, os nad oes unrhyw awgrymiadau `Arc` neu [`Weak`] eraill i'r un dyraniad.
    ///
    ///
    /// Yn dychwelyd [`None`] fel arall, oherwydd nid yw'n ddiogel treiglo gwerth a rennir.
    ///
    /// Gweler hefyd [`make_mut`][make_mut], a fydd yn [`clone`][clone] y gwerth mewnol pan fydd awgrymiadau eraill.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Mae'r anniogelrwydd hwn yn iawn oherwydd rydym yn sicr mai'r pwyntydd a ddychwelir yw'r *unig* pwyntydd a fydd byth yn cael ei ddychwelyd i T.
            // Gwarantir y bydd ein cyfrif cyfeirio yn 1 ar y pwynt hwn, ac roeddem yn mynnu bod yr Arc ei hun yn `mut`, felly rydym yn dychwelyd yr unig gyfeiriad posibl at y data mewnol.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Yn dychwelyd cyfeiriad symudol i'r `Arc` a roddir, heb unrhyw wiriad.
    ///
    /// Gweler hefyd [`get_mut`], sy'n ddiogel ac yn gwneud gwiriadau priodol.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ni ddylai unrhyw awgrymiadau eraill `Arc` neu [`Weak`] i'r un dyraniad yn cael ei dereferenced drwy gydol y benthyg a ddychwelwyd.
    ///
    /// Mae hyn yn wir yn wir os nad oes unrhyw awgrymiadau o'r fath yn bodoli, er enghraifft yn syth ar ôl `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Rydym yn ofalus i *beidio* creu cyfeirnod sy'n cwmpasu'r meysydd "count", gan y byddai hyn yn cyd-fynd â mynediad cydamserol i'r cyfrif cyfeirnod (ee.
        // gan `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Darganfyddwch ai hwn yw'r cyfeiriad unigryw (gan gynnwys cyfeiriadau gwan) at y data sylfaenol.
    ///
    ///
    /// Sylwch fod hyn yn gofyn am gloi'r cyfrif cyf gwan.
    fn is_unique(&mut self) -> bool {
        // clowch y cyfrif pwyntydd gwan os ymddengys mai ni yw'r unig ddeiliad pwyntydd gwan.
        //
        // Mae'r label caffael yma yn sicrhau perthynas cyn-digwydd ag unrhyw ysgrifeniadau i `strong` (yn enwedig yn `Weak::upgrade`) cyn gostyngiadau yn y cyfrif `weak` (trwy `Weak::drop`, sy'n defnyddio rhyddhau).
        // Pe na bai'r cyfeirnod gwan wedi'i uwchraddio byth yn cael ei ollwng, bydd y CAS yma yn methu felly nid ydym yn poeni cydamseru.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Rhaid i hwn fod yn `Acquire` i gydamseru â gostyngiad y cownter `strong` yn `drop`-yr unig fynediad sy'n digwydd pan fydd unrhyw un ond y cyfeirnod olaf yn cael ei ollwng.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Mae'r ysgrifen rhyddhau yma yn cydamseru â darlleniad yn `downgrade`, i bob pwrpas yn atal y darlleniad uchod o `strong` rhag digwydd ar ôl yr ysgrifennu.
            //
            //
            self.inner().weak.store(1, Release); // rhyddhewch y clo
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Yn gollwng yr `Arc`.
    ///
    /// Bydd hyn yn lleihau'r cyfrif cyfeirio cryf.
    /// Os yw'r cyfrif cyfeirnod cryf yn cyrraedd sero yna'r unig gyfeiriadau eraill (os oes rhai) yw [`Weak`], felly rydyn ni'n `drop` y gwerth mewnol.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Nid yw'n argraffu unrhyw beth
    /// drop(foo2);   // Printiau "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Oherwydd bod `fetch_sub` eisoes yn atomig, nid oes angen i ni gydamseru ag edafedd eraill oni bai ein bod yn mynd i ddileu'r gwrthrych.
        // Mae'r un rhesymeg yn berthnasol i'r `fetch_sub` isod i'r cyfrif `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Mae angen y ffens hon i atal ail-drefnu'r defnydd o'r data a dileu'r data.
        // Oherwydd ei fod yn cael ei farcio `Release`, y gostwng y synchronizes cyfeirio cyfrif gyda hyn ffens `Acquire`.
        // Mae hyn yn golygu bod defnyddio'r data yn digwydd cyn gostwng y cyfrif cyfeirnod, sy'n digwydd cyn y ffens hon, sy'n digwydd cyn dileu'r data.
        //
        // Fel yr eglurwyd yn y [Boost documentation][1],
        //
        // > Mae'n bwysig gorfodi unrhyw fynediad posibl i'r gwrthrych mewn un
        // > edau (drwy gyfeirio presennol) at *ddigwydd cyn dileu*
        // > y gwrthrych mewn edau wahanol.Cyflawnir hyn gan "release"
        // > gweithrediad ar ôl gollwng cyfeirnod (unrhyw fynediad i'r gwrthrych
        // > trwy'r cyfeiriad hwn yn amlwg mae'n rhaid digwydd o'r blaen), a
        // > "acquire" gweithredu cyn ei dileu y gwrthrych.
        //
        // Yn benodol, tra bod y cynnwys o Arc fel arfer yn ddigyfnewid, mae'n bosibl cael ysgrifennu yn tu i rhywbeth fel Mutex<T>.
        // Gan na chaiff Mutex ei gaffael pan gaiff ei ddileu, ni allwn ddibynnu ar ei resymeg cydamseru i wneud ysgrifeniadau yn edau A yn weladwy i ddistryw sy'n rhedeg yn edau B.
        //
        //
        // Hefyd yn nodi y gallai'r ffens Gaffael yma yn ôl pob tebyg yn cael ei ddisodli gyda llwyth Caffael, a allai wella perfformiad mewn sefyllfaoedd hynod dadlau.Gweler [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ceisiwch israddio'r `Arc<dyn Any + Send + Sync>` i fath concrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Yn adeiladu `Weak<T>` newydd, heb ddyrannu unrhyw gof.
    /// Mae galw [`upgrade`] ar y gwerth dychwelyd bob amser yn rhoi [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Math o gynorthwyydd i ganiatáu cyrchu'r cyfrif cyfeiriadau heb wneud unrhyw honiadau am y maes data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Yn dychwelyd pwyntydd amrwd i'r gwrthrych `T` y mae'r `Weak<T>` hwn yn cyfeirio ato.
    ///
    /// Mae'r pwyntydd yn ddilys dim ond os oes rhai cyfeiriadau cryf.
    /// Gall y pwyntydd fod yn hongian, heb ei lofnodi neu hyd yn oed [`null`] fel arall.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Mae'r ddau bwynt i'r un gwrthrych
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Mae'r cryf yma yn ei gadw'n fyw, felly gallwn ddal i gyrchu'r gwrthrych.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ond dim mwy.
    /// // Gallwn wneud weak.as_ptr(), ond byddai cyrchu'r pwyntydd yn arwain at ymddygiad heb ei ddiffinio.
    /// // assert_eq ("helo", anniogel {&*weak.as_ptr() })!;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Os yw'r pwyntydd yn hongian, byddwn yn dychwelyd y sentinel yn uniongyrchol.
            // Ni all hyn fod yn, cyfeiriad prif lwyth dilys, gan fod y prif lwyth o leiaf cyn halinio â ArcInner (usize).
            ptr as *const T
        } else {
            // DIOGELWCH: os yw is_dangling yn dychwelyd yn ffug, yna mae'r pwyntydd yn ddadreferencable.
            // Efallai y bydd y llwyth tâl yn cael ei ollwng ar y pwynt hwn, ac mae'n rhaid i ni gynnal tarddiad, felly defnyddiwch drin pwyntydd amrwd.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Yn bwyta'r `Weak<T>` a'i droi'n bwyntydd amrwd.
    ///
    /// Mae hyn yn trosi'r pwyntydd gwan yn bwyntydd amrwd, gan ddal i gadw perchnogaeth un cyfeirnod gwan (nid yw'r cyfrifiad gwan yn addasu'r cyfrif gwan).
    /// Gellir ei droi yn ôl i'r `Weak<T>` gyda [`from_raw`].
    ///
    /// Mae'r un cyfyngiadau o ran cyrchu targed y pwyntydd â [`as_ptr`] yn berthnasol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Yn trosi pwyntydd amrwd a grëwyd yn flaenorol gan [`into_raw`] yn ôl i `Weak<T>`.
    ///
    /// Gellir defnyddio hwn i gael cyfeirnod cryf yn ddiogel (trwy ffonio [`upgrade`] yn ddiweddarach) neu i ddeallocateiddio'r cyfrif gwan trwy ollwng yr `Weak<T>`.
    ///
    /// Mae'n cymryd perchnogaeth o un cyfeiriad gwan (ac eithrio'r awgrymiadau a grëwyd gan [`new`], gan nad yw'r rhain yn berchen ar unrhyw beth; mae'r dull yn dal i weithio arnynt).
    ///
    /// # Safety
    ///
    /// Rhaid bod y pwyntydd wedi tarddu o'r [`into_raw`] a rhaid iddo fod yn berchen ar ei gyfeirnod gwan posibl o hyd.
    ///
    /// Caniateir i'r cyfrif cryf fod yn 0 ar adeg galw hwn.
    /// Serch hynny, mae hyn yn cymryd perchnogaeth o un cyfeirnod gwan a gynrychiolir ar hyn o bryd fel pwyntydd amrwd (nid yw'r cyfrifiad gwan yn addasu'r cyfrif gwan) ac felly mae'n rhaid ei baru â galwad flaenorol i [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Gostwng y cyfrif gwan olaf.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Gweler Weak::as_ptr i gael cyd-destun ar sut mae'r pwyntydd mewnbwn yn deillio.

        let ptr = if is_dangling(ptr as *mut T) {
            // Mae hwn yn Wan hongian.
            ptr as *mut ArcInner<T>
        } else {
            // Fel arall, rydym yn sicr y daeth y pwyntydd o Weak nondangling.
            // DIOGELWCH: mae data_offset yn ddiogel i'w alw, gan fod ptr yn cyfeirio at T. go iawn (a allai gael ei ollwng).
            let offset = unsafe { data_offset(ptr) };
            // Felly, rydym yn gwrthdroi'r gwrthbwyso i gael y RcBox cyfan.
            // DIOGELWCH: tarddodd y pwyntydd o Wan, felly mae'r gwrthbwyso hwn yn ddiogel.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // DIOGELWCH: rydym bellach wedi adfer y pwyntydd Gwan gwreiddiol, felly gallwn greu'r Gwan.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Ymdrechion i uwchraddio'r pwyntydd `Weak` i [`Arc`], oedi gollwng o werth mewnol os yw'n llwyddiannus.
    ///
    ///
    /// Yn dychwelyd [`None`] os yw'r gwerth mewnol wedi'i ollwng ers hynny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Dinistrio pob awgrym cryf.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Rydym yn defnyddio dolen CAS i gynyddu'r cyfrif cryf yn lle fetch_add gan na ddylai'r swyddogaeth hon fyth gymryd y cyfrif cyfeirnod o sero i un.
        //
        //
        let inner = self.inner()?;

        // Llwyth ymlaciol oherwydd bod unrhyw ysgrifen o 0 y gallwn ei harsylwi yn gadael y cae mewn cyflwr parhaol sero (felly mae darlleniad "stale" o 0 yn iawn), a chadarnheir unrhyw werth arall trwy'r CAS isod.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Gweler y sylwadau yn `Arc::clone` am pam rydyn ni'n gwneud hyn (ar gyfer `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Mae ymlacio yn iawn ar gyfer yr achos methu oherwydd nid oes gennym unrhyw ddisgwyliadau am y wladwriaeth newydd.
            // Caffael yn angenrheidiol ar gyfer yr achos o lwyddiant i gydamseru â `Arc::new_cyclic`, pryd y gall y gwerth mewnol ei hymgychwyn ar ôl cyfeiriadau `Weak` eisoes wedi cael eu creu.
            // Yn yr achos hwnnw, rydym yn disgwyl arsylwi ar y gwerth cychwynnol llawn.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null wedi'i wirio uchod
                Err(old) => n = old,
            }
        }
    }

    /// Cael nifer yr awgrymiadau (`Arc`) cryf sy'n pwyntio at y dyraniad hwn.
    ///
    /// Os crëwyd `self` gan ddefnyddio [`Weak::new`], bydd hyn yn dychwelyd 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Yn rhoi brasamcan o nifer yr awgrymiadau `Weak` sy'n pwyntio at y dyraniad hwn.
    ///
    /// Os crëwyd `self` gan ddefnyddio [`Weak::new`], neu os nad oes unrhyw awgrymiadau cryf ar ôl, bydd hyn yn dychwelyd 0.
    ///
    /// # Accuracy
    ///
    /// Oherwydd y manylion gweithredu, gall y gwerth a ddychwelwyd fod i ffwrdd gan 1 yn y ddau gyfeiriad pan edafedd eraill yn trin unrhyw `Arc`s neu`Weak`s pwyntio at yr un dyraniad.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Ers i ni arsylwi bod o leiaf un pwyntydd cryf ar ôl darllen y cyfrif gwan, gwyddom fod y cyfeirnod gwan ymhlyg (yn bresennol pryd bynnag y mae unrhyw gyfeiriadau cryf yn fyw) yn dal i fod o gwmpas pan wnaethom arsylwi ar y cyfrif gwan, ac felly gall ei dynnu'n ddiogel.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Yn dychwelyd `None` pan fydd y pwyntydd yn hongian ac nad oes `ArcInner` wedi'i ddyrannu, (hy, pan gafodd yr `Weak` hwn ei greu gan `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Rydym yn ofalus i *beidio* creu cyfeirnod sy'n cwmpasu'r maes "data", oherwydd gall y maes gael ei dreiglo ar yr un pryd (er enghraifft, os yw'r `Arc` olaf yn cael ei ollwng, bydd y maes data yn cael ei ollwng yn ei le).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Yn dychwelyd `true` os yw'r ddau `Gwan 'yn pwyntio at yr un dyraniad (tebyg i [`ptr::eq`]), neu os nad yw'r ddau yn pwyntio at unrhyw ddyraniad (oherwydd iddynt gael eu creu gyda `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Gan fod hyn yn cymharu awgrymiadau, mae'n golygu y bydd `Weak::new()` yn hafal i'w gilydd, er nad ydyn nhw'n pwyntio at unrhyw ddyraniad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Cymharu `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gwneud clôn o'r pwyntydd `Weak` bod pwyntiau i'r un dyraniad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Gweler y sylwadau yn Arc::clone() am pam mae hyn yn hamddenol.
        // Gall hyn ddefnyddio fetch_add (gan anwybyddu'r clo) oherwydd bod y cyfrif gwan wedi'i gloi dim ond lle nad oes *unrhyw awgrymiadau gwan* eraill yn bodoli.
        //
        // (Felly ni allwn fod yn rhedeg y cod hwn yn yr achos hwnnw).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Gweler y sylwadau yn Arc::clone() am pam rydyn ni'n gwneud hyn (ar gyfer mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Yn adeiladu `Weak<T>` newydd, heb ddyrannu'r cof.
    /// Mae galw [`upgrade`] ar y gwerth dychwelyd bob amser yn rhoi [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Yn gollwng y pwyntydd `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nid yw'n argraffu unrhyw beth
    /// drop(foo);        // Printiau "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Os byddwn yn cael gwybod mai ni oedd y pwyntydd wan diwethaf, yna mae'n amser i deallocate data yn gyfan gwbl.Gweler y drafodaeth yn Arc::drop() am y orderings cof
        //
        // Nid yw'n angenrheidiol i wirio ar gyfer y wladwriaeth cloi yma, oherwydd y gall y cyfrif gwan yn cael eu cloi yn unig os oedd yn union un cyf gwan, sy'n golygu bod galw heibio dim ond wedyn yn rhedeg AR bod yn weddill cyf gwan, sydd ond yn gallu digwydd ar ôl y clo yn cael ei ryddhau.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Rydym yn gwneud yr arbenigedd hwn yma, ac nid fel optimeiddiad mwy cyffredinol ar `&T`, oherwydd byddai fel arall yn ychwanegu cost at bob gwiriad cydraddoldeb ar gyfeiriadau.
/// Rydym yn cymryd yn ganiataol bod `Arc`s yn cael eu defnyddio i storio gwerthoedd mawr, sydd yn araf i clôn, ond mae hefyd yn drwm i wirio am gydraddoldeb, gan achosi gost hon i dalu yn haws.
///
/// Mae hefyd yn fwy tebygol o gael dau glon `Arc`, sy'n pwyntio i'r un gwerth, na dau `&T`s.
///
/// Gallwn ond wneud hyn pan allai `T: Eq` fel `PartialEq` yn fwriadol irreflexive.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Cydraddoldeb i ddau `Arc '.
    ///
    /// Mae dau `Arc 'yn hafal os yw eu gwerthoedd mewnol yn gyfartal, hyd yn oed os cânt eu storio mewn dyraniad gwahanol.
    ///
    /// Os `T` hefyd yn gweithredu `Eq` (awgrymu ymatblyg cydraddoldeb), dau `Arc`s y pwynt i'r un dyraniad bob amser yn gyfartal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Anghydraddoldeb i ddau `Arc`.
    ///
    /// Mae dau `Arc 'yn anghyfartal os yw eu gwerthoedd mewnol yn anghyfartal.
    ///
    /// Os `T` hefyd yn gweithredu `Eq` (awgrymu ymatblyg cydraddoldeb), dau `Arc`s y pwynt i'r un gwerth byth yn anghyfartal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Cymhariaeth rannol ar gyfer dau `Arc`s.
    ///
    /// Cymharir y ddau trwy ffonio `partial_cmp()` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Cymhariaeth llai na dau `Arc`.
    ///
    /// Cymharir y ddau trwy ffonio `<` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Cymhariaeth 'Llai na neu'n hafal i' dau `Arc`.
    ///
    /// Mae'r ddau yn cael eu cymharu drwy ffonio `<=` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Mwy na chymhariaeth ar gyfer dau `Arc`s.
    ///
    /// Cymharir y ddau trwy ffonio `>` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Fwy na neu'n hafal i' cymhariaeth ar gyfer dau `Arc`s.
    ///
    /// Cymharir y ddau trwy ffonio `>=` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Cymhariaeth ar gyfer dau `Arc`s.
    ///
    /// Cymharir y ddau trwy ffonio `cmp()` ar eu gwerthoedd mewnol.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Yn creu `Arc<T>` newydd, gyda'r gwerth `Default` ar gyfer `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Dyrannwch dafell wedi'i chyfrif wedi'i chyfeirio a'i llenwi trwy glonio eitemau `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Dyrannu `str` wedi'i gyfrifo â chyfeirnod a chopïo `v` ynddo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Dyrannu `str` wedi'i gyfrifo â chyfeirnod a chopïo `v` ynddo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Symudwch wrthrych mewn bocs i ddyraniad newydd, wedi'i gyfrifo â chyfeirnod.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Dyrannwch dafell wedi'i chyfrif cyfeirnod a symud eitemau `v` i mewn iddi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Caniatáu i'r Vec ryddhau ei gof, ond heb ddinistrio ei gynnwys
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Yn cymryd pob elfen yn y `Iterator` ac yn casglu i mewn i `Arc<[T]>`.
    ///
    /// # Nodweddion perfformiad
    ///
    /// ## Yr achos cyffredinol
    ///
    /// Yn gyffredinol, mae casglu i mewn i `Arc<[T]>` yn cael ei wneud trwy gasglu i mewn i `Vec<T>` yn gyntaf.Hynny yw, wrth ysgrifennu'r canlynol:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// mae hyn yn ymddwyn fel pe baem yn ysgrifennu:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Mae'r set gyntaf o ddyraniadau yn digwydd yma.
    ///     .into(); // Mae ail ddyraniad ar gyfer `Arc<[T]>` yn digwydd yma.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bydd hyn yn dyrannu cymaint o weithiau ag sydd ei angen ar gyfer llunio'r `Vec<T>` ac yna bydd yn dyrannu unwaith ar gyfer troi'r `Vec<T>` yn `Arc<[T]>`.
    ///
    ///
    /// ## Iterators o hyd hysbys
    ///
    /// Pan fydd eich `Iterator` yn gweithredu `TrustedLen` ac o faint union, bydd dyraniad sengl yn cael ei wneud ar gyfer yr `Arc<[T]>`.Er enghraifft:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Dim ond un dyraniad sy'n digwydd yma.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Arbenigo trait ddefnyddir i gasglu i mewn i `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Mae hyn yn wir am ailadroddwr `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // DIOGELWCH: Mae angen i ni sicrhau bod gan yr ailadroddwr yr union hyd ac sydd gennym ni.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Disgyn yn ôl i weithredu arferol.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Cael y gwrthbwyso mewn `ArcInner` gyfer y prif lwyth y tu ôl pwyntydd.
///
/// # Safety
///
/// Rhaid i'r pwyntydd bwyntio at (a bod â metadata dilys ar gyfer) enghraifft T a oedd yn ddilys o'r blaen, ond caniateir i'r T gael ei ollwng.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alinio'r gwerth heb ei fesur i ddiwedd yr ArcInner.
    // Gan fod RcBox yw repr(C), bydd bob amser yn y maes olaf yn y cof.
    // DIOGELWCH: gan mai'r unig fathau heb eu maint sy'n bosibl yw tafelli, gwrthrychau trait,
    // a mathau extern, y gofyniad diogelwch mewnbwn yn ddigon ar hyn o bryd i fodloni gofynion align_of_val_raw;mae hyn yn manylu ar waith yr iaith nad ydynt efallai yn dibynnu ar y tu allan i std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}