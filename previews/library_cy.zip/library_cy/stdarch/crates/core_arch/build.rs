use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Fe'i defnyddir i ddweud wrth ein hanodiadau `#[assert_instr]` bod yr holl gynhenid simd ar gael i brofi eu codgen, gan fod rhai yn cael eu cadw y tu ôl i `-Ctarget-feature=+unimplemented-simd128` ychwanegol nad oes ganddo unrhyw gyfwerth yn `#[target_feature]` ar hyn o bryd.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}