`core::arch` - intrinsics pensaernïaeth-benodol llyfrgell craidd Rust yn
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Mae'r modiwl `core::arch` yn gweithredu cynhenid pensaernïaeth-ddibynnol (ee SIMD).

# Usage 

`core::arch` ar gael fel rhan o `libcore` ac mae'n cael ei ail-allforio gan `libstd`.Mae'n well gen i ei ddefnyddio trwy `core::arch` neu `std::arch` na thrwy'r crate hwn.
Nodweddion ansefydlog ar gael yn aml mewn Rust nosweithiol drwy'r `feature(stdsimd)`.

Mae defnyddio `core::arch` trwy'r crate hwn yn gofyn am Rust nosweithiol, a gall (ac mae'n) torri'n aml.Yr unig achosion y dylech ystyried ei ddefnyddio trwy'r crate hwn yw:

* os oes angen i chi ail-lunio `core::arch` eich hun, ee, gyda nodweddion targed penodol wedi'u galluogi nad ydynt wedi'u galluogi ar gyfer `libcore`/`libstd`.
Note: os oes angen i ail-lunio ar gyfer darged ansafonol, os gwelwch yn dda yn well gan ddefnyddio `xargo` ac ail-lunio'r `libcore`/`libstd` fel y bo'n briodol yn hytrach na defnyddio crate hwn.
  
* ddefnyddio rhai o nodweddion na allai fod yn hyd yn oed y tu ôl i gael ansefydlog Rust nodweddion.Rydyn ni'n ceisio cadw'r rhain i'r lleiafswm.
Os oes angen i chi ddefnyddio rhai o'r nodweddion hyn, agorwch rifyn fel y gallwn eu datgelu yn Rust nosweithiol a gallwch eu defnyddio oddi yno.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` yn cael ei ddosbarthu'n bennaf o dan delerau'r drwydded MIT a'r Drwydded Apache (Fersiwn 2.0), gyda dognau'n dod o dan amrywiol drwyddedau tebyg i BSD.

Gweler TRWYDDED-APACHE, a TRWYDDED-MIT am fanylion.

# Contribution

Oni nodwch yn benodol fel arall, bydd unrhyw gyfraniad a gyflwynir yn fwriadol i'w gynnwys yn `core_arch` gennych chi, fel y'i diffinnir yn y drwydded Apache-2.0, yn drwyddedig ddeuol fel uchod, heb unrhyw delerau neu amodau ychwanegol.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












