# Cyfrannu at stdarch

Mae'r crate `stdarch` yn fwy na pharod i dderbyn cyfraniadau!Yn gyntaf mae'n debyg y byddwch am edrych ar yr ystorfa a sicrhau bod profion yn pasio i chi:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Lle `<your-target-arch>` yw'r triphlyg targed fel y'i defnyddir gan `rustup`, ee `x86_x64-unknown-linux-gnu` (heb unrhyw `nightly-` blaenorol neu debyg).
Hefyd, cofiwch fod sefydliad yn gofyn am y sianel nosweithiol o Rust!
Mewn gwirionedd, mae'r profion uchod yn ei gwneud yn ofynnol i rust nosweithiol fod y rhagosodiad ar eich system, i osod y defnydd hwnnw `rustup default nightly` (a `rustup default stable` i ddychwelyd).

Os nad yw unrhyw un o'r camau uchod yn gweithio, [please let us know][new]!

Nesaf i fyny gallwch [find an issue][issues] i helpu allan ar, rydym wedi dewis rhai gyda'r tagiau [`help wanted`][help] a [`impl-period`][impl] a allai yn arbennig defnyddio rhywfaint o help. 
Efallai eich bod yn ddiddordeb yn y rhan fwyaf [#40][vendor], gweithredu pob intrinsics gwerthwr ar x86.Y mater hwnnw yn cael rhai awgrymiadau da am ble i ddechrau!

Os oes gennych gwestiynau cyffredinol mae croeso i [join us on gitter][gitter] a gofyn o gwmpas!Mae croeso i chi ping ai@BurntSushi neu@alexcrichton gyda chwestiynau.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Sut i ysgrifennu enghreifftiau ar gyfer cynhenid stdarch

Mae yna ychydig o nodweddion y mae'n rhaid eu galluogi ar gyfer y gynhenid a roddir i waith yn iawn a rhaid i'r enghraifft ond yn cael ei redeg gan `cargo test --doc` pan fydd y nodwedd yn cael ei gefnogi gan y CPU.

O ganlyniad, ni fydd y diofyn `fn main` sy'n cael ei gynhyrchu gan `rustdoc` yn gweithio (yn y rhan fwyaf o achosion).
Ystyriwch ddefnyddio y canlynol fel canllaw i sicrhau bod eich esiampl yn gweithio yn ôl y disgwyl.

```rust
/// # // angen Rydym cfg_target_feature i sicrhau bod yr enghraifft yn unig
/// # // rhedeg gan `cargo test --doc` pan fydd y CPU yn cefnogi'r nodwedd
/// # #![feature(cfg_target_feature)]
/// # // rhaid Rydym target_feature i'r gynhenid i waith
/// # #![feature(target_feature)]
/// #
/// # // mae rustdoc yn ddiofyn yn defnyddio `extern crate stdarch`, ond mae angen y
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // Y brif swyddogaeth go iawn
/// # fn main() {
/// #     // Peidiwch â rhedeg hwn oni bai bod `<target feature>` yn cael ei gefnogi
/// #     os cfg_feature_enabled! ("<target feature>"){
/// #         // Creu swyddogaeth `worker` a fydd ond yn cael ei rhedeg os yw'r nodwedd darged
/// #         // Cefnogir a sicrhau bod `target_feature` wedi ei alluogi ar gyfer eich gweithiwr
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         anniogel fn worker() {
/// // Ysgrifennwch eich enghraifft yma.Bydd intrinsics nodwedd benodol yn gweithio yma!Ewch yn wyllt!
///
/// #         }
///
/// #         anniogel { worker(); }
/// #     }
/// # }
```

Os nad yw rhai o'r gystrawen uchod yn edrych yn gyfarwydd, mae adran [Documentation as tests] yr [Rust Book] yn disgrifio'r gystrawen `rustdoc` yn eithaf da.
Fel bob amser, mae croeso i [join us on gitter][gitter] a gofyn i ni os byddwch yn taro unrhyw rhwystrau, ac yn diolch i chi am helpu i wella'r ddogfennaeth y `stdarch`!

# Cyfarwyddiadau Profi Amgen

Argymhellir yn gyffredinol eich bod yn defnyddio `ci/run.sh` i gynnal y profion.
Fodd bynnag, efallai na fydd hyn yn gweithio i chi, ee os ydych ar Windows.

Yn yr achos hwnnw, gallwch ddisgyn yn ôl i redeg `cargo +nightly test` a `cargo +nightly test --release -p core_arch` ar gyfer profi y genhedlaeth cod.
Noder bod y rhain yn ei gwneud yn ofynnol i'r toolchain nos i gael ei osod ac i `rustc` i wybod am eich targed triphlyg a'i CPU.
Yn benodol mae angen i chi osod y newidyn amgylchedd `TARGET` fel y byddech chi ar gyfer `ci/run.sh`.
Yn ogystal mae angen i chi osod `RUSTCFLAGS` (angen y `C`) i ddynodi nodweddion targed, ee `RUSTCFLAGS="-C -target-features=+avx2"`.
Gallwch hefyd osod `-C -target-cpu=native` os ydych chi'n "just" yn datblygu yn erbyn eich CPU cyfredol.

Byddwch yn rhybuddio bod pan fyddwch yn defnyddio cyfarwyddiadau amgen hyn, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ee
Gall profion cynhyrchu cyfarwyddyd yn methu oherwydd y disassembler enwir yn wahanol, ee
gall gynhyrchu `vaesenc` yn lle cyfarwyddiadau `aesenc` er eu bod yn ymddwyn yr un peth.
Hefyd cyfarwyddiadau hyn gweithredu llai o brofion na fyddai fel arfer yn cael ei wneud, felly peidiwch â synnu bod-yn gofyn tynnu efallai y bydd rhai gwallau arddangos i fyny ar gyfer profion nad ydynt yn dod yma pan fyddwch yn y pen draw.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






