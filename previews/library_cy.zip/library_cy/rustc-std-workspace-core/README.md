# Mae'r `rustc-std-workspace-core` crate

Mae'r crate yn shim a crate gwag sydd yn syml yn dibynnu ar `libcore` a reexports ei holl gynnwys.
Y crate yw'r craidd o rymuso'r llyfrgell safonol i ddibynnu ar crates o crates.io

Crates ar crates.io fod y llyfrgell safonol yn dibynnu ar yr angen i ddibynnu ar y `rustc-std-workspace-core` crate o crates.io, sydd yn wag.

Rydym yn defnyddio `[patch]` i droi'r fantol i crate hwn mewn sefydliad.
O ganlyniad, bydd crates ar crates.io tynnu dibyniaeth edge i `libcore`, y fersiwn a ddiffinnir yn sefydliad.
Dylai hynny yn tynnu holl ymylon dibyniaeth i sicrhau Cargo yn adeiladu crates yn llwyddiannus!

Sylwch fod angen i crates ar crates.io ddibynnu ar y crate hwn gyda'r enw `core` er mwyn i bopeth weithio'n gywir.I wneud hynny gallant ddefnyddio:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Trwy ddefnyddio allwedd `package` y crate ei ailenwi i `core`, sy'n golygu bydd yn edrych fel

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

pan Cargo galw ar y compiler, bodloni'r gyfarwyddeb `extern crate core` ymhlyg chwistrellu gan y compiler.




