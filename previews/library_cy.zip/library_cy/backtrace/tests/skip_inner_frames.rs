use backtrace::Backtrace;

// Dim ond ar lwyfannau sydd â swyddogaeth `symbol_address` weithredol ar gyfer fframiau sy'n adrodd cyfeiriad cychwyn symbol y mae'r prawf hwn yn gweithio.
// O ganlyniad, dim ond ar ychydig o blatfformau y mae wedi'i alluogi.
//
const ENABLED: bool = cfg!(all(
    // Windows nid yw wedi cael ei brofi mewn gwirionedd, ac nid yw OSX yn cefnogi dod o hyd i ffrâm amgáu, felly analluoga hyn
    //
    target_os = "linux",
    // Ar ARM dod o hyd i'r swyddogaeth amgáu yn syml ddychwelyd y ip ei hun.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}