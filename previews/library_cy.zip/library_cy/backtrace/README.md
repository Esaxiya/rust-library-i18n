# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Llyfrgell ar gyfer caffael backtraces ar amser rhedeg ar gyfer Rust.
Mae hyn yn nodau llyfrgell i wella cefnogaeth y llyfrgell safonol drwy ddarparu rhyngwyneb rhaglennol i weithio â nhw, ond mae hefyd yn cefnogi syml hawdd argraffu'r olrheiniad bresennol fel panics libstd yn.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

I ddal ôl-gefn yn unig a gohirio delio ag ef tan amser diweddarach, gallwch ddefnyddio'r math `Backtrace` lefel uchaf.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Fodd bynnag, os hoffech gael mwy o fynediad amrwd i'r swyddogaeth olrhain wirioneddol, gallwch ddefnyddio'r swyddogaethau `trace` a `resolve` yn uniongyrchol.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Ddatrys y pwyntydd cyfarwyddyd i enw symbol
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // dal i fynd i'r ffrâm nesaf
    });
}
```

# License

Mae'r prosiect hwn wedi'i drwyddedu o dan y naill neu'r llall

 * Trwydded Apache, Fersiwn 2.0, ([LICENSE-APACHE](LICENSE-APACHE) neu http://www.apache.org/licenses/LICENSE-2.0)
 * Trwydded MIT ([LICENSE-MIT](LICENSE-MIT) neu http://opensource.org/licenses/MIT)

ar eich opsiwn chi.

### Contribution

Oni bai eich bod yn nodi fel arall yn benodol, bydd unrhyw gyfraniad a gyflwynir yn fwriadol i'w gynnwys mewn backtrace-rs gennych chi, fel y'i diffinnir yn y drwydded Apache-2.0, yn drwyddedig ddeuol fel uchod, heb unrhyw delerau neu amodau ychwanegol.







