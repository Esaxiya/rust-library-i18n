use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Datrys cyfeiriad i symbol, gan basio'r symbol i'r cau penodedig.
///
/// Bydd y swyddogaeth hon yn edrych i fyny'r cyfeiriad a roddir mewn meysydd fel y tabl symbolau lleol, tabl symbolau deinamig, neu wybodaeth ddadfygio DWARF (yn dibynnu ar y gweithredu wedi'i actifadu) i ddod o hyd i symbolau i'w cynhyrchu.
///
///
/// Efallai na fydd y cau yn cael ei alw os na ellid cyflawni datrysiad, a gellir ei alw hefyd fwy nag unwaith yn achos swyddogaethau wedi'u leinio.
///
/// Mae'r symbolau a gynhyrchir yn cynrychioli'r dienyddiad yn yr `addr` penodedig, gan ddychwelyd parau file/line ar gyfer y cyfeiriad hwnnw (os yw ar gael).
///
/// Sylwch, os oes gennych `Frame` yna argymhellir defnyddio'r swyddogaeth `resolve_frame` yn lle'r un hon.
///
/// # Nodweddion gofynnol
///
/// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol y nodwedd `std` y `backtrace` crate i'w alluogi, ac mae'r nodwedd `std` ei alluogi yn ddiofyn.
///
/// # Panics
///
/// Mae'r swyddogaeth hon yn ymdrechu i beidio byth â panic, ond pe bai'r `cb` yn darparu panics yna bydd rhai platfformau'n gorfodi panic dwbl i erthylu'r broses.
/// Mae rhai platfformau'n defnyddio llyfrgell C sy'n defnyddio galwadau ffôn yn fewnol na ellir eu trwsio drwodd, felly gall panicio o `cb` ysgogi erthyliad proses.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // Dim ond yn edrych ar y ffrâm uchaf
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Datryswch ffrâm ddal o'r blaen i symbol, gan basio'r symbol i'r cau penodedig.
///
/// Mae'r functin hwn yn cyflawni'r un swyddogaeth â `resolve` heblaw ei fod yn cymryd `Frame` fel dadl yn lle cyfeiriad.
/// Gall hyn ganiatáu i rai gweithrediadau platfform yn ôl-gefn ddarparu gwybodaeth symbolaidd gywirach neu wybodaeth am fframiau mewnol er enghraifft.
///
/// Argymhellir defnyddio hwn os gallwch chi.
///
/// # Nodweddion gofynnol
///
/// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol y nodwedd `std` y `backtrace` crate i'w alluogi, ac mae'r nodwedd `std` ei alluogi yn ddiofyn.
///
/// # Panics
///
/// Mae'r swyddogaeth hon yn ymdrechu i beidio byth â panic, ond pe bai'r `cb` yn darparu panics yna bydd rhai platfformau'n gorfodi panic dwbl i erthylu'r broses.
/// Mae rhai platfformau'n defnyddio llyfrgell C sy'n defnyddio galwadau ffôn yn fewnol na ellir eu trwsio drwodd, felly gall panicio o `cb` ysgogi erthyliad proses.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // Dim ond yn edrych ar y ffrâm uchaf
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Mae gwerthoedd IP o fframiau pentwr fel arfer yn (always?) y cyfarwyddyd *ar ôl* yr alwad dyna'r olrhain pentwr go iawn.
// Symbol hwn ar achosion y rhif filename/line i fod yn un o'n blaenau ac efallai i mewn i'r ddi-rym os yw'n agos at ddiwedd y swyddogaeth.
//
// Mae hyn yn ymddangos i yn y bôn bob amser yn wir ar bob llwyfan, felly rydym bob amser yn tynnu un o ip penderfynu datrys y cyfarwyddyd alwad blaenorol yn lle y cyfarwyddyd yn cael eu dychwelyd i.
//
//
// Yn ddelfrydol ni fyddem yn gwneud hyn.
// Yn ddelfrydol byddem yn ei gwneud yn ofynnol i alwyr yr APIs `resolve` yma wneud yr -1 â llaw a chyfrif eu bod eisiau gwybodaeth am leoliad ar gyfer y cyfarwyddyd *blaenorol*, nid y cyfredol.
// Yn ddelfrydol byddem hefyd yn amlygu ar `Frame` os ydym yn wir y cyfeiriad y cyfarwyddyd nesaf neu'r presennol.
//
// Am y tro er bod hyn yn bryder arbenigol 'n bert, felly rydym yn unig yn fewnol bob amser yn tynnu un.
// Dylai defnyddwyr yn parhau i weithio a chael canlyniadau 'n bert da, felly dylem fod yn ddigon da.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Yr un peth â `resolve`, dim ond yn anniogel gan ei fod heb ei gydamseru.
///
/// Nid oes gan y swyddogaeth hon warantau cydamseru ond mae ar gael pan nad yw nodwedd `std` y crate hon wedi'i llunio ynddo.
/// Gweler swyddogaeth `resolve` i gael mwy o ddogfennaeth ac enghreifftiau.
///
/// # Panics
///
/// Gweler y `resolve` i chafeatau ar `cb` fynd i banig.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Yr un peth â'r `resolve_frame`, dim ond anniogel gan ei fod yn unsynchronized.
///
/// Nid oes gan y swyddogaeth hon warantau cydamseru ond mae ar gael pan nad yw nodwedd `std` y crate hon wedi'i llunio ynddo.
/// Gweler y swyddogaeth `resolve_frame` am fwy o ddogfennau ac enghreifftiau.
///
/// # Panics
///
/// Gweler gwybodaeth ar `resolve_frame` am gafeatau ar banicio `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait cynrychioli ddatrys symbol mewn ffeil.
///
/// Mae'r trait yn esgor fel trait gwrthwynebu'r cau a roddir i'r swyddogaeth `backtrace::resolve`, ac mae'n cael ei anfon gan ei fod yn fwy neu lai yn hysbys sy'n gweithredu y tu ôl iddo.
///
///
/// Gall symbol roi gwybodaeth gyd-destunol am swyddogaeth, er enghraifft yr enw, enw ffeil, rhif llinell, union gyfeiriad, ac ati.
/// Fodd bynnag, nid yw'r holl wybodaeth ar gael mewn symbol bob amser, felly mae pob dull yn dychwelyd `Option`.
///
///
pub struct Symbol {
    // TODO: oes hon anghenion rhwym o gael eu parhau yn y pen draw i `Symbol`,
    // ond mae hynny'n newid sy'n torri ar hyn o bryd.
    // Am y tro mae hyn yn ddiogel ers `Symbol` yn unig byth yn cael ei dosbarthu drwy gyfeirio ac ni ellir eu clonio.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Yn dychwelyd enw'r swyddogaeth hon.
    ///
    /// Gellir defnyddio'r strwythur a ddychwelwyd i holi priodweddau amrywiol am enw'r symbol:
    ///
    ///
    /// * Bydd gweithrediad `Display` yn argraffu'r symbol demangled.
    /// * Gellir cyrchu gwerth `str` amrwd y symbol (os yw'n ddilys utf-8).
    /// * Gellir cyrchu'r beitiau amrwd ar gyfer enw'r symbol.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Dychwelyd y cyfeiriad cychwynnol o swyddogaeth hon.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Yn dychwelyd enw'r ffeil amrwd fel sleisen.
    /// Mae hyn yn ddefnyddiol yn bennaf ar gyfer amgylcheddau `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Yn dychwelyd rhif y golofn ar gyfer y symbol hwn ar hyn o bryd.
    ///
    /// Dim ond gimli sy'n darparu gwerth yma ar hyn o bryd a hyd yn oed wedyn dim ond os yw `filename` yn dychwelyd `Some`, ac felly mae o ganlyniad yn destun cafeatau tebyg.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Dychwelyd y nifer lein ar gyfer ble y symbol hwn yn gweithredu ar hyn o bryd.
    ///
    /// Y gwerth dychwelyd hwn yn nodweddiadol yw `Some` os yw `filename` yn dychwelyd `Some`, ac o ganlyniad mae'n destun cafeatau tebyg.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Dychwelyd y enw ffeil lle y swyddogaeth hon ei ddiffinio.
    ///
    /// Ar hyn o bryd dim ond pan fydd libbacktrace neu gimli yn cael ei ddefnyddio y mae hyn ar gael (ee
    /// unix llwyfannau eraill) a phan fydd deuaidd yn cael ei lunio gyda debuginfo.
    /// Os nad yw'r un o'r amodau hyn yn cael eu bodloni, yna bydd hyn yn debygol o ddychwelyd `None`.
    ///
    /// # Nodweddion gofynnol
    ///
    /// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol y nodwedd `std` y `backtrace` crate i'w alluogi, ac mae'r nodwedd `std` ei alluogi yn ddiofyn.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Efallai symbol C++ dosranedig, pe bai dosrannu`r symbol mangled fel Rust yn methu.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Gwnewch yn siŵr eich bod yn cadw'r maint sero hwn, fel nad oes cost i'r nodwedd `cpp_demangle` pan yn anabl.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Mae deunydd lapio o amgylch enw symbol i ddarparu accessors ergonomig i'r enw demangled, y bytes crai, y llinyn crai, ac ati
///
// Caniatáu cod marw ar gyfer pan nad yw'r nodwedd `cpp_demangle` wedi ei alluogi.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Creu enw symbol newydd gan y bytes sylfaenol amrwd.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Yn dychwelyd enw symbol (mangled) amrwd fel `str` os yw'r symbol yn ddilys utf-8.
    ///
    /// Defnyddiwch y gweithredu `Display` os ydych chi am gael y fersiwn wedi'i demanglo.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Yn dychwelyd enw'r symbol amrwd fel rhestr o bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Efallai y bydd hyn yn argraffu os nad yw'r symbol demangled yn ddilys mewn gwirionedd, felly ymdriniwch â'r gwall yma'n osgeiddig trwy beidio â'i ledaenu tuag allan.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Ceisio adennill bod cof storfa yn cael ei ddefnyddio i symboleiddio cyfeiriadau.
///
/// Bydd y dull hwn yn ceisio rhyddhau unrhyw strwythurau data byd-eang sydd fel arall wedi'u storio'n fyd-eang neu yn yr edefyn sy'n nodweddiadol yn cynrychioli gwybodaeth DWARF wedi'i dosrannu neu debyg.
///
///
/// # Caveats
///
/// Er bod y swyddogaeth hon ar gael bob amser, nid yw'n gwneud unrhyw beth ar y mwyafrif o weithrediadau.
/// Nid yw llyfrgelloedd fel dbghelp neu libbacktrace yn darparu cyfleusterau i ddeallocate state a rheoli'r cof a ddyrannwyd.
/// Am y tro nodwedd `gimli-symbolize` y crate hwn yw'r unig nodwedd lle mae'r swyddogaeth hon yn cael unrhyw effaith.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}