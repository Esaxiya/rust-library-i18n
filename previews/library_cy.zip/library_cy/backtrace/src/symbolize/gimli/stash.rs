// dim ond yn cael ei ddefnyddio ar Linux ar hyn o bryd, felly caniatewch god marw mewn man arall
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Mae dyrannydd arena syml ar gyfer byfferau beit.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Yn dyrannu byffer o'r maint penodedig ac yn dychwelyd cyfeiriad symudol ato.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // DIOGELWCH: dyma'r unig swyddogaeth honno erioed yn adeiladu mutable
        // cyfeiriad at `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // DIOGELWCH: yr ydym byth yn cael gwared ar elfennau o `self.buffers`, felly geirda
        // i'r data y tu mewn i unrhyw byffer bydd yn byw cyhyd ag y mae `self` yn ei wneud.
        &mut buffers[i]
    }
}