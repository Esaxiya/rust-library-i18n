//! Cefnogaeth ar gyfer symboleiddio gan ddefnyddio'r `gimli` crate ar crates.io
//!
//! Dyma'r gweithrediad symboli diofyn ar gyfer Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // mae oes statig yn gelwydd i hacio diffyg cefnogaeth i strwythurau hunan-gyfeiriadol.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Trosi i 'oes statig gan y dylai'r symbolau fenthyg `map` a `stash` yn unig ac rydym yn eu cadw isod.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Ar gyfer llwytho llyfrgelloedd brodorol ar Windows, gweler peth trafodaeth ar rust-lang/rust#71060 am yr amrywiol strategaethau yma.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW llyfrgelloedd ar hyn o bryd nid ydynt yn cefnogi ASLR (rust-lang/rust#16514), ond gellir DLLs yn dal i gael eu hadleoli o gwmpas yn y gofod cyfeiriad.
            // Mae'n ymddangos bod cyfeiriadau mewn gwybodaeth ddadfygio i gyd fel pe bai'r llyfrgell hon wedi'i llwytho ar ei "image base", sy'n faes yn ei phenawdau ffeiliau COFF.
            // Gan mai dyma mae'n ymddangos bod debuginfo yn ei restru rydym yn dosrannu'r tabl symbolau ac yn storio cyfeiriadau fel petai'r llyfrgell wedi'i llwytho yn "image base" hefyd.
            //
            // Efallai na fydd y llyfrgell yn cael ei llwytho yn "image base", fodd bynnag.
            // (mae'n debyg y gellir llwytho rhywbeth arall yno?) Dyma lle mae'r cae `bias` yn cael ei chwarae, ac mae angen i ni gyfrifo gwerth `bias` yma.Yn anffodus er nad yw'n glir sut i gaffael hwn o fodiwl wedi'i lwytho.
            // Yr hyn sydd gennym, fodd bynnag, yw'r cyfeiriad llwyth gwirioneddol (`modBaseAddr`).
            //
            // Fel tipyn o gopïo am y tro, rydyn ni'n mmapio'r ffeil, yn darllen gwybodaeth pennawd y ffeil, yna'n gollwng y mmap.Mae hyn yn wastraffus oherwydd mae'n debyg y byddwn yn ailagor y mmap yn ddiweddarach, ond dylai hyn weithio'n ddigon da am y tro.
            //
            // Ar ôl i ni gael yr `image_base` (lleoliad llwyth a ddymunir) a'r `base_addr` (lleoliad llwyth gwirioneddol) gallwn lenwi'r `bias` (gwahaniaeth rhwng yr union a'r hyn a ddymunir) ac yna cyfeiriad datganedig pob segment yw'r `image_base` gan mai dyna mae'r ffeil yn ei ddweud.
            //
            //
            // Am y tro mae'n ymddangos y gallwn ni wneud yn wahanol i ELF/MachO gydag un segment i bob llyfrgell, gan ddefnyddio `modBaseSize` fel y maint cyfan.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS defnyddio APIs fformat ffeil Mach-O a defnyddiau DYLD-benodol i lwytho rhestr o lyfrgelloedd cynhenid sy'n rhan o'r cais.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Chwiliwch am enw'r llyfrgell hon sy'n cyfateb i'r llwybr ble i'w llwytho hefyd.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Llwythwch bennawd delwedd y llyfrgell hon a'i ddirprwyo i `object` i ddosrannu'r holl orchmynion llwyth fel y gallwn ni gyfrifo'r holl segmentau dan sylw yma.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Ailadrodd dros y segmentau a gofrestr rhanbarthau adnabyddus am segmentau ein bod yn dod o hyd.
            // Hefyd, cofnodwch segmentau testun pwl gwybodaeth i'w prosesu yn nes ymlaen, gweler y sylwadau isod.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Darganfyddwch yr "slide" ar gyfer y llyfrgell hon sy'n dod i ben fel y gogwydd a ddefnyddiwn i ddarganfod ble mae gwrthrychau cof yn cael eu llwytho.
            // Mae hyn yn dipyn o gyfrifiant rhyfedd serch hynny ac mae'n ganlyniad rhoi cynnig ar ychydig o bethau yn y gwyllt a gweld beth sy'n glynu.
            //
            // Y syniad cyffredinol yw y bydd yr `bias` ynghyd â `stated_virtual_memory_address` segment yn mynd i fod yn y gofod cyfeiriad gwirioneddol y mae'r segment yn preswylio.
            // Y peth arall rydyn ni'n dibynnu arno yw mai cyfeiriad go iawn heb yr `bias` yw'r mynegai i edrych i fyny yn y tabl symbolau a debuginfo.
            //
            // Mae'n ymddangos, serch hynny, bod y cyfrifiadau hyn yn anghywir ar gyfer llyfrgelloedd â llwyth system.Fodd bynnag, ar gyfer gweithredwyr brodorol, mae'n ymddangos yn gywir.
            // Gan godi rhywfaint o resymeg o ffynhonnell LLDB mae ganddo rywfaint o gasys arbennig ar gyfer yr adran `__TEXT` gyntaf wedi'i llwytho o wrthbwyso ffeil 0 gyda maint nonzero.
            // Am ba bynnag reswm pan fydd hyn yn bresennol ymddengys ei fod yn golygu bod y tabl symbolau yn gymharol â'r sleid vmaddr yn unig ar gyfer y llyfrgell.
            // Os nad yw'n *bresennol* yna mae'r tabl symbolau yn gymharol â'r sleid vmaddr ynghyd â chyfeiriad datganedig y segment.
            //
            // I drin y sefyllfa hon os ydym nad oes * * dod o hyd i adran testun ar ffeil gwrthbwyso sero, yna byddwn yn cynyddu rhagfarn drwy gyfeiriad datganedig yr adrannau testun cyntaf a lleihau yr holl gyfeiriadau a nodwyd gan y swm hwnnw yn ogystal.
            //
            // Yn y ffordd honno mae'r tabl symbolau bob amser yn ymddangos yn gymharol â swm gogwydd y llyfrgell.
            // Mae'n ymddangos bod gan hyn y canlyniadau cywir ar gyfer symboleiddio trwy'r tabl symbolau.
            //
            // Yn onest nid wyf yn hollol siŵr a yw hyn yn iawn neu a oes rhywbeth arall a ddylai nodi sut i wneud hyn.
            // Am y tro, mae'n ymddangos bod hyn yn gweithio'n ddigon da (?) a dylem bob amser allu newid hyn dros amser os oes angen.
            //
            // Am ychydig mwy o wybodaeth gweler #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix arall (ee
        // Mae llwyfannau Linux) yn defnyddio ELF fel fformat ffeil gwrthrych ac yn nodweddiadol maent yn gweithredu API o'r enw `dl_iterate_phdr` i lwytho llyfrgelloedd brodorol.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` dylai fod yn awgrymiadau dilys.
        // `vec` dylai fod yn pwyntydd dilys i `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 nid yw'n cefnogi gwybodaeth ddadfygio yn frodorol, ond bydd y system adeiladu yn gosod gwybodaeth ddadfygio ar lwybr `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Dylai popeth arall ddefnyddio ELF, ond nid yw'n gwybod sut i lwytho llyfrgelloedd cynhenid.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Pob llyfrgell hysbys a rennir sydd wedi'i llwytho.
    libraries: Vec<Library>,

    /// Mapiau storfa lle rydyn ni'n cadw gwybodaeth gorrach wedi'i dosrannu.
    ///
    /// Mae'r rhestr hon wedi gallu sefydlog ar gyfer ei liftime cyfan sydd byth yn cynyddu.
    /// Mae elfen `usize` pob pâr yn fynegai i `libraries` uchod os `usize::max_value()` cynrychioli'r gweithredadwy ar hyn o bryd.
    ///
    /// Mae'r `Mapping` yn wybodaeth corrach dosranedig gyfatebol.
    ///
    /// Sylwch mai storfa LRU yw hwn yn y bôn a byddwn yn symud pethau o gwmpas yma wrth i ni symboleiddio cyfeiriadau.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Mae rhannau o'r llyfrgell hon wedi'u llwytho i'r cof, a lle maen nhw'n cael eu llwytho.
    segments: Vec<LibrarySegment>,
    /// "bias" y llyfrgell hon, yn nodweddiadol lle caiff ei lwytho i'r cof.
    /// Ychwanegir y gwerth hwn at gyfeiriad datganedig pob segment i gael y cyfeiriad cof rhithwir y mae'r segment yn cael ei lwytho ynddo.
    /// Yn ogystal, mae'r gogwydd hwn yn cael ei dynnu o gyfeiriadau cof rhithwir go iawn i'w mynegeio i mewn i debuginfo a'r tabl symbolau.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Cyfeiriad datganedig y segment hwn yn y ffeil gwrthrych.
    /// Nid dyma lle mae'r segment wedi'i lwytho mewn gwirionedd, ond yn hytrach y cyfeiriad hwn ynghyd ag `bias` y llyfrgell sy'n cynnwys yw ble i ddod o hyd iddo.
    ///
    stated_virtual_memory_address: usize,
    /// Maint y segment ths er cof.
    len: usize,
}

// anniogel oherwydd bod angen cydamseru hyn yn allanol
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // anniogel oherwydd bod angen cydamseru hyn yn allanol
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Cache LRU bach iawn, syml iawn ar gyfer mapio gwybodaeth ddadfygio.
        //
        // Dylai'r gyfradd daro fod yn uchel iawn, gan nad yw'r pentwr nodweddiadol yn croesi rhwng llawer o lyfrgelloedd a rennir.
        //
        // Mae'r strwythurau `addr2line::Context` yn eithaf drud i'w creu.
        // Disgwylir ei gost gael ei amorteiddio gan ymholiadau `locate` dilynol, sy'n trosoledd adeiladodd y strwythurau wrth lunio `addr2line: : Context`s i gael speedups 'n glws.
        //
        // Pe na bai'r storfa hon gennym, ni fyddai'r amorteiddiad hwnnw byth yn digwydd, a symbyliad o gefnlenni fyddai ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Yn gyntaf, profwch a oes gan yr `lib` hwn unrhyw segment sy'n cynnwys yr `addr` (trin adleoli).Os yw gwiriad hwn yn mynd yna gallwn barhau isod ac mewn gwirionedd yn cyfieithu y cyfeiriad.
                //
                // Sylwer ein bod yn defnyddio `wrapping_add` yma i osgoi gorlifo sieciau.Mae wedi bod yn ei weld yn y gwyllt fod y cyfrifiant rhagfarn SVMA + gorlifo.
                // Mae'n ymddangos braidd yn rhyfedd fyddai hynny'n digwydd, ond nid oes llawer iawn y gallwn ei wneud am y peth ac eithrio yn ôl pob tebyg dim ond anwybyddu'r segmentau y rhai gan eu bod yn debygol o pwyntio i ffwrdd i'r gofod.
                //
                // Daeth hyn i fyny yn wreiddiol yn rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Nawr ein bod yn gwybod `lib` yn cynnwys `addr`, gallwn wneud iawn â'r duedd i ddod o hyd i'r cyfeiriad cof virutal nodir.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Ddigyfnewid: ar ôl Mae hyn yn cwblhau'r amodol heb ddychwelyd yn gynnar
        // o wall, mae'r cofnod storfa ar gyfer y llwybr hwn ar fynegai 0.

        if let Some(idx) = idx {
            // Pan fydd y mapio eisoes yn y cache, symud i'r tu blaen.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Pan nad yw'r mapio yn y storfa, crëwch fap newydd, ei fewnosod ym mlaen y storfa, a dadfeddiannu'r cofnod storfa hynaf os oes angen.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // peidiwch â gollwng oes `'static`, gwnewch yn siŵr ei fod wedi'i gwmpasu i ddim ond ein hunain
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Ymestyn oes `sym` i `'static` gan fod gofyn i ni yma yn anffodus, ond mae'n mynd ymlaen fel cyfeiriad felly ni ddylid parhau i gyfeirio ato y tu hwnt i'r ffrâm hon beth bynnag.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Yn olaf, yn cael mapio cached neu greu mapiau newydd ar gyfer y ffeil, a gwerthuso'r wybodaeth corrach i ddod o hyd i'r file/line/name gyfer y cyfeiriad hwn.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Roeddem yn gallu dod o hyd i wybodaeth ffrâm ar gyfer y symbol hwn, ac mae ffrâm `addr2line` yn fewnol yn cynnwys yr holl fanylion graenus nitty.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Methu canfod gwybodaeth dadfygio, ond yr ydym yn ei chael yn y tabl symbol o'r gweithredadwy Elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}