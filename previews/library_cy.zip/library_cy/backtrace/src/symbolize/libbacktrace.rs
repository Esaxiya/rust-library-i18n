//! Strategaeth symboleiddio gan ddefnyddio'r cod dosrannu DWARF yn libbacktrace.
//!
//! Mae'r llyfrgell libbacktrace C, a ddosberthir yn nodweddiadol gyda gcc, yn cefnogi nid yn unig cynhyrchu backtrace (nad ydym yn ei ddefnyddio mewn gwirionedd) ond hefyd yn symboleiddio'r backtrace ac yn trin gwybodaeth am ddadfygio corrach am bethau fel fframiau wedi'u leinio a beth nad ydyn nhw.
//!
//!
//! Mae hyn yn gymharol gymhleth oherwydd llawer o bryderon amrywiol yma, ond y syniad sylfaenol yw:
//!
//! * Yn gyntaf rydyn ni'n galw `backtrace_syminfo`.Mae hyn yn cael gwybodaeth symbol o'r tabl symbolau deinamig os gallwn.
//! * Nesaf rydyn ni'n galw `backtrace_pcinfo`.Bydd hyn yn dosrannu tablau debuginfo os ydyn nhw ar gael ac yn caniatáu inni adfer gwybodaeth am fframiau mewnlin, enwau ffeiliau, rhifau llinell, ac ati.
//!
//! Mae yna lawer o dwyllo ynglŷn â chael y tablau corrach i mewn i libbacktrace, ond gobeithio nad yw'n ddiwedd y byd ac mae'n ddigon clir wrth ddarllen isod.
//!
//! Mae hyn yn y strategaeth symbolication diofyn ar gyfer nad ydynt yn MSVC a llwyfannau heb OSX.Yn libstd er mai dyma'r strategaeth ddiofyn ar gyfer OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Os yn bosibl, mae'n well gennych yr enw `function` sy'n dod o debuginfo ac a all fod yn fwy cywir ar gyfer fframiau mewnol er enghraifft.
                // Os nad yw hynny'n bresennol er disgyn yn ôl i'r enw tabl symbol a nodir yn `symname`.
                //
                // Sylwch y gall `function` deimlo ychydig yn llai cywir weithiau, er enghraifft cael ei restru fel `try<i32,closure>` isntead o `std::panicking::try::do_call`.
                //
                // Dyw hi ddim yn wir yn glir pam, ond ar y cyfan mae'r enw `function` yn ymddangos yn fwy cywir.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // gwneud dim am y tro
}

/// Math o'r pwyntydd `data` a basiwyd i `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Unwaith y bydd hyn yn cael ei alwad yn ôl galw i rym o `backtrace_syminfo` pan fyddwn yn dechrau datrys rydym yn mynd ymhellach i alw `backtrace_pcinfo`.
    // Bydd y swyddogaeth `backtrace_pcinfo` yn ymgynghori gwybodaeth dadfygio a attemp tto wneud pethau yn hoffi adfer gwybodaeth file/line fel fframiau ogystal â inlined.
    // Sylwch, serch hynny, y gall `backtrace_pcinfo` fethu neu beidio â gwneud llawer os nad oes gwybodaeth ddadfygio, felly os yw hynny'n digwydd rydym yn sicr o alw'r alwad yn ôl gydag o leiaf un symbol o'r `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Math o'r pwyntydd `data` a basiwyd i `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Mae'r API libbacktrace yn cefnogi creu gwladwriaeth, ond nid yw'n cefnogi dinistrio gwladwriaeth.
// Yn bersonol, cymeraf i hyn olygu bod gwladwriaeth i fod i gael ei chreu ac yna byw am byth.
//
// Byddwn wrth fy modd yn cofrestru triniwr at_exit() sy'n glanhau'r wladwriaeth hon, ond nid yw libbacktrace yn darparu unrhyw ffordd i wneud hynny.
//
// Gyda'r cyfyngiadau hyn, mae gan y swyddogaeth hon gyflwr wedi'i storio'n statig sy'n cael ei gyfrif y tro cyntaf y gofynnir am hyn.
//
// Cofiwch fod ôl-dracio popeth yn digwydd yn gyfresol (un clo byd-eang).
//
// Sylwch fod y diffyg cydamseru yma oherwydd y gofyniad bod `resolve` yn cael ei gydamseru'n allanol.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Peidiwch ag ymarfer galluoedd e-bost libbacktrace gan ein bod bob amser yn ei alw mewn dull cydamserol.
        //
        0,
        error_cb,
        ptr::null_mut(), // data ddim ychwanegol
    );

    return STATE;

    // Sylwch, er mwyn i libbacktrace weithredu o gwbl, mae angen iddo ddod o hyd i wybodaeth ddadfygio DWARF ar gyfer y gweithredadwy cyfredol.Yn nodweddiadol mae'n gwneud hynny trwy nifer o fecanweithiau gan gynnwys, ond heb fod yn gyfyngedig i:
    //
    // * /proc/self/exe ar lwyfannau a gefnogir
    // * Mae'r enw ffeil basiwyd yn benodol wrth greu wladwriaeth
    //
    // Mae'r llyfrgell libbacktrace yn wad mawr o god C.Mae hyn yn naturiol yn golygu bod ganddo wendidau diogelwch cof, yn enwedig wrth drin debuginfo camffurfiedig.
    // Mae Libstd wedi rhedeg i mewn i ddigon o'r rhain yn hanesyddol.
    //
    // Os defnyddir /proc/self/exe yna gallwn anwybyddu'r rhain fel rheol gan ein bod yn tybio mai lib01trace yw "mostly correct" ac fel arall nid yw'n gwneud pethau rhyfedd gyda gwybodaeth dadfygio corrach "attempted to be correct".
    //
    //
    // Os ydym yn pasio enw ffeil i mewn, fodd bynnag, yna mae'n bosibl ar rai platfformau (fel BSDs) lle gall actor maleisus beri i ffeil fympwyol gael ei gosod yn y lleoliad hwnnw.
    // Mae hyn yn golygu, os ydym yn dweud wrth libbacktrace am enw ffeil, efallai ei fod yn defnyddio ffeil fympwyol, gan achosi segfaults o bosibl.
    // Os na fyddwn yn dweud wrth unrhyw beth libbacktrace er hynny ni fydd yn gwneud unrhyw beth ar lwyfannau nad ydynt yn cefnogi llwybrau fel /proc/self/exe!
    //
    // O ystyried popeth yr ydym yn ceisio mor galed â phosibl i *beidio* pasio enw ffeil, ond mae'n rhaid i ni ar lwyfannau nad ydyn nhw'n cefnogi /proc/self/exe o gwbl.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Noder bod yn ddelfrydol byddem yn defnyddio `std::env::current_exe`, ond ni allwn ei gwneud yn ofynnol `std` yma.
            //
            // Defnyddiwch `_NSGetExecutablePath` i lwytho'r llwybr gweithredadwy cyfredol i mewn i ardal sefydlog (sydd, os yw'n rhy fach, yn rhoi'r gorau iddi).
            //
            //
            // Sylwer ein bod ni'n ymddiried yn ddifrifol libbacktrace yma i beidio marw ar executables llwgr, ond mae'n sicr yn ei wneud ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows Mae dull o ffeiliau lle ar ôl ei fod yn agor, ni ellir ei ddileu agor.
            // Bod yn gyffredinol yr hyn yr ydym ei eisiau yma am ein bod am sicrhau nad yw ein gweithredadwy yn newid allan o dan ni ar ôl i ni ei roi i ffwrdd i libbacktrace, gobeithio lliniaru y gallu i basio mewn data mympwyol yn libbacktrace (y gellir eu cam-drin).
            //
            //
            // O ystyried ein bod yn gwneud ychydig o ddawns yma i geisio cael math o glo ar ein delwedd ein hunain:
            //
            // * Cael handlen at y broses bresennol, lwytho ei ffeil.
            // * Agorwch ffeil i'r enw ffeil hwnnw gyda'r fflagiau cywir.
            // * Ail-lwytho enw ffeil y broses gyfredol, gan sicrhau ei fod yr un peth
            //
            // Os yw hynny i gyd, rydym mewn theori, yn wir, wedi agor ffeil ein proses ac rydym yn sicr na fydd yn newid.FWIW copïir criw o hyn o libstd yn hanesyddol, felly dyma fy nehongliad gorau o'r hyn oedd yn digwydd.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Mae hyn yn byw mewn cof statig fel y gallwn ei ddychwelyd.
                static mut BUF: [i8; N] = [0; N];
                // ... ac mae hyn yn byw ar y pentwr ers ei fod dros dro
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // gollyngwch `handle` yma yn fwriadol oherwydd dylai cael yr agoriad hwnnw gadw ein clo ar enw'r ffeil hon.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Rydym am ddychwelyd tafell sydd heb derfyniad nul, felly pe bai popeth wedi'i lenwi a'i fod yn hafal i'r cyfanswm hyd yna cyfatebwch hynny i fethiant.
                //
                //
                // Fel arall wrth ddychwelyd llwyddiant gwnewch yn siŵr bod y beit nul wedi'i gynnwys yn y dafell.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // ar hyn o bryd mae gwallau backtrace yn cael eu sgubo o dan y ryg
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Ffoniwch yr API `backtrace_syminfo` a ddylai (o ddarllen y cod) ffonio `syminfo_cb` yn union unwaith (neu fethu â chamgymeriad yn ôl pob tebyg).
    // Yna byddwn yn trin mwy o fewn yr `syminfo_cb`.
    //
    // Bydd Sylwer ein bod yn gwneud hyn ers `syminfo` ymgynghori â'r tabl symbol, dod o hyd i enwau symbol hyd yn oed os nad oes gwybodaeth dadfygio yn y deuaidd.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}