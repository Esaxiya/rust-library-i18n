use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // Mae dl_iterate_phdr yn cymryd galwad yn ôl a fydd yn derbyn pwyntydd dl_phdr_info ar gyfer pob DSO sydd wedi'i gysylltu â'r broses.
    // Mae dl_iterate_phdr hefyd yn sicrhau bod y cysylltydd deinamig wedi'i gloi o ddechrau i ddiwedd yr iteriad.
    // Os bydd yr alwad yn ôl yn dychwelyd gwerth nad yw'n sero, bydd yr iteriad yn cael ei derfynu'n gynnar.
    // 'data' yn cael ei basio fel y drydedd ddadl i'r alwad yn ôl ar bob galwad.
    // 'size' yn rhoi maint y dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Mae angen i ni gramadegu allan ID adeiladu a rhywfaint o ddata pennawd rhaglen sylfaenol y modd y mae angen i ni ychydig o bethau o'r spec ELF hefyd.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nawr mae'n rhaid i ni efelychu, fesul tipyn, strwythur y math dl_phdr_info a ddefnyddir gan gysylltydd deinamig cyfredol fuchsia.
// Mae gan cromiwm hefyd y ffin ABI hon yn ogystal â crashpad.
// Yn y pen draw, hoffem symud yr achosion hyn i ddefnyddio chwiliad elf ond byddai angen i ni ddarparu hynny yn y SDK ac nid yw hynny wedi'i wneud eto.
//
// Felly rydyn ni (a nhw) yn sownd yn gorfod defnyddio'r dull hwn sy'n arwain at gyplu tynn â'r fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nid oes gennym unrhyw ffordd o wybod a yw e_phoff ac e_phnum yn ddilys.
    // dylai libc sicrhau hyn i ni fodd bynnag felly mae'n ddiogel ffurfio tafell yma.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Mae Elf_Phdr yn cynrychioli pennawd rhaglen ELF 64-did yn niwedd y bensaernïaeth darged.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Mae Phdr yn cynrychioli pennawd rhaglen ELF dilys a'i gynnwys.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Nid oes gennym unrhyw ffordd o wirio a yw p_addr neu p_memsz yn ddilys.
    // Mae libc Fuchsia yn dosrannu'r nodiadau yn gyntaf ond felly yn rhinwedd bod yma mae'n rhaid i'r penawdau hyn fod yn ddilys.
    //
    // Nid yw NoteIter yn ei gwneud yn ofynnol i'r data sylfaenol fod yn ddilys ond mae'n ei gwneud yn ofynnol i'r ffiniau fod yn ddilys.
    // Hyderwn fod libc wedi sicrhau bod hyn yn wir i ni yma.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Y math o nodyn ar gyfer IDau adeiladu.
const NT_GNU_BUILD_ID: u32 = 3;

// Mae Elf_Nhdr yn cynrychioli pennawd nodyn ELF yn nherfynoldeb y targed.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nodyn yn cynrychioli nodyn ELF (pennawd + cynnwys).
// Mae'r enw'n cael ei adael fel tafell u8 oherwydd nid yw bob amser yn cael ei derfynu ac mae rust yn ei gwneud hi'n ddigon hawdd gwirio bod y beitiau'n cyfateb y naill ffordd neu'r llall.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter yn gadael i chi yn ddiogel ailadrodd dros segment nodyn.
// Mae'n dod i ben cyn gynted ag y bydd gwall yn digwydd neu os nad oes mwy o nodiadau.
// Os byddwch yn ailadrodd data dros annilys, bydd yn gweithredu fel pe na nodiadau Cafwyd hyd.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Mae'n invariant o swyddogaeth bod y pwyntydd a'r maint a roddir yn dynodi ystod ddilys o bytes y gellir eu darllen i gyd.
    // Gall y cynnwys y bytes hyn fod yn unrhyw beth ond mae'n rhaid i'r amrediad fod yn ddilys i hyn fod yn ddiogel.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to yn alinio 'x' ag aliniad 'to'-byte gan dybio bod 'to' yn bwer o 2.
// Mae hyn yn dilyn patrwm safonol yng nghod dosrannu ELF C/C ++ lle defnyddir (x + i, 1) a -to.
// Nid yw Rust yn gadael ichi negyddu defnydd felly rwy'n ei ddefnyddio
// trosi 2's-ategu i ail-greu'r hynny.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 yn ei ddefnyddio num bytes o'r dafell (os yw'n bresennol) a hefyd yn sicrhau bod y dafell olaf yn cyd-fynd properlly.
// Os yw naill ai nifer y bytes y gofynnir amdanynt yn rhy fawr neu na ellir ailalinio'r sleisen wedi hynny oherwydd nad oes digon o bytes ar ôl, ni ddychwelir yr un ac ni chaiff y dafell ei haddasu.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Nid oes gan y swyddogaeth hon unrhyw invariants go iawn y mae'n rhaid i'r galwr eu cynnal heblaw efallai y dylid alinio 'bytes' ar gyfer perfformiad (ac ar gywirdeb rhai pensaernïaeth).
// Efallai bod y gwerthoedd ym meysydd Elf_Nhdr yn nonsens ond nid yw'r swyddogaeth hon yn sicrhau unrhyw beth o'r fath.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Mae hyn yn ddiogel cyn belled â bod digon o le ac rydym newydd gadarnhau na ddylai'r datganiad hwn fod yn anniogel yn y datganiad uchod.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Noder bod sice_of: :<Elf_Nhdr>() Bob amser 4-beit halinio.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Gwiriwch a ydym wedi cyrraedd y diwedd.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Rydym transmute allan nhdr ond rydym yn ofalus yn ystyried y struct deillio.
        // Nid ydym yn ymddiried yn yr namesz na'r descsz ac nid ydym yn gwneud unrhyw benderfyniadau anniogel yn seiliedig ar y math.
        //
        // Felly hyd yn oed os ydym yn cael sothach llwyr, dylem fod yn ddiogel o hyd.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Mae'n nodi bod segment yn gweithredadwy.
const PERM_X: u32 = 0b00000001;
/// Yn nodi bod modd ysgrifennu segment.
const PERM_W: u32 = 0b00000010;
/// Mae'n nodi bod segment yn ddarllenadwy.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Yn cynrychioli segment ELF yn Rhedeg.
struct Segment {
    /// Mae'n rhoi cyfeiriad rhithwir runtime cynnwys y segment hwn.
    addr: usize,
    /// Mae'n rhoi maint cof cynnwys y segment hwn.
    size: usize,
    /// Mae'n rhoi cyfeiriad rhithwir modiwl y segment hwn gyda'r ffeil ELF.
    mod_rel_addr: usize,
    /// Mae'n rhoi caniatadau a geir yn y ffeil ELF.
    /// Fodd bynnag, nid y caniatadau hyn o reidrwydd yw'r caniatâd sy'n bresennol ar amser rhedeg.
    flags: Perm,
}

/// Yn gadael un iteriad dros Segmentau o DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Yn cynrychioli DSO ELF (Gwrthrych a Rennir Dynamig).
/// Mae'r math hwn yn cyfeirio at y data sy'n cael ei storio yn y DSO go iawn yn hytrach na gwneud ei gopi ei hun.
struct Dso<'a> {
    /// Mae'r linker deinamig bob amser yn rhoi enw i ni, hyd yn oed os yw'r enw yn wag.
    /// Yn achos y prif weithredadwy bydd yr enw hwn yn wag.
    /// Yn achos gwrthrych a rennir, bydd y soname (gweler DT_SONAME).
    name: &'a str,
    /// Ar Fuchsia bron pob binaries cael IDs adeiladu, ond nid yw hyn yn requierment llym.
    /// Does dim ffordd i gyfateb i fyny Gwybodaeth DSO gyda ffeil ELF go iawn wedi hynny os nad oes build_id felly rydym yn gofyn bod pob DSO gael un yma.
    ///
    /// DSO heb build_id yn cael eu hanwybyddu.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Yn dychwelyd ailadroddwr dros Segmentau yn y DSO hwn.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Mae'r rhain yn camgymeriadau amgodio materion sy'n codi wrth ddosrannu gwybodaeth am bob DSO.
///
enum Error {
    /// fodd NameError bod gwall wedi digwydd wrth drosi llinyn arddull C mewn i linyn rust.
    ///
    NameError(core::str::Utf8Error),
    /// Mae BuildIDError yn golygu na ddaethom o hyd i ID adeiladu.
    /// Gallai hyn fod naill ai oherwydd nad oedd gan y DSO ID adeiladu neu oherwydd bod y segment sy'n cynnwys yr ID adeiladu wedi'i gamffurfio.
    ///
    BuildIDError,
}

/// Yn galw naill ai 'dso' neu 'error' ar gyfer pob DSO sy'n gysylltiedig â'r broses gan y cysylltydd deinamig.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter a fydd ag un o ddulliau bwyta o'r enw foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // mae dl_iterate_phdr yn sicrhau y bydd info.name yn pwyntio at leoliad dilys.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Mae'r swyddogaeth hon yn argraffu marciwr symbolaidd Fuchsia ar gyfer yr holl wybodaeth sydd wedi'i chynnwys mewn DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}