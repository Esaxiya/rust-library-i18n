#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Mae Formatter i olrheiniadau.
///
/// Gellir defnyddio'r math hwn i argraffu ôl-gefn waeth ble mae'r backtrace ei hun yn dod.
/// Os oes gennych chi fath `Backtrace`, yna ei weithredu `Debug` eisoes yn defnyddio fformat argraffu hwn.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Yr arddulliau argraffu y gallwn eu hargraffu
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Yn argraffu cefndir terser sydd, yn ddelfrydol, yn cynnwys gwybodaeth berthnasol yn unig
    Short,
    /// Yn argraffu cefndir sy'n cynnwys yr holl wybodaeth bosibl
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Creu `BacktraceFmt` newydd a fydd yn ysgrifennu allbwn i'r `fmt` a ddarperir.
    ///
    /// Bydd dadl `format` yn rheoli'r arddull y mae'r backtrace wedi'i argraffu ynddo, a bydd dadl `print_path` yn cael ei defnyddio i argraffu'r enghreifftiau `BytesOrWideString` o enwau ffeiliau.
    /// Nid yw'r math hwn ei hun yn gwneud unrhyw argraffu enwau ffeiliau, ond mae angen alwad yn ôl yma i wneud hynny.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Printiau rhagarweiniad i'r olrheiniad fin cael ei argraffu.
    ///
    /// Mae hyn yn ofynnol ar rai platfformau er mwyn i gefnlenni gael eu symboleiddio'n llawn yn ddiweddarach, ac fel arall dylai hyn fod y dull cyntaf y byddwch chi'n ei alw ar ôl creu `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Yn ychwanegu ffrâm at yr allbwn backtrace.
    ///
    /// Mae hyn yn cyflawni enghraifft RAII o `BacktraceFrameFmt` y gellir ei ddefnyddio i mewn gwirionedd argraffu ffrâm ffurflenni, ac ar y bydd yn dinistrio gynyddran y ffrâm cownter.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Yn cwblhau'r allbwn backtrace.
    ///
    /// Ar hyn o bryd, dim dewis yw hwn ond fe'i ychwanegir ar gyfer cydnawsedd future â fformatau backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Ar hyn o bryd dim-op-- gan gynnwys y hook hwn i ganiatáu ar gyfer ychwanegiadau future.
        Ok(())
    }
}

/// Fformatydd ar gyfer un ffrâm yn unig o gefn.
///
/// Mae'r math hwn yn cael ei greu gan y swyddogaeth `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Printiau a `BacktraceFrame` gyda hyn Formatter ffrâm.
    ///
    /// Bydd hyn yn argraffu pob achos `BacktraceSymbol` yn yr `BacktraceFrame` yn gylchol.
    ///
    /// # Nodweddion gofynnol
    ///
    /// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol y nodwedd `std` y `backtrace` crate i'w alluogi, ac mae'r nodwedd `std` ei alluogi yn ddiofyn.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Printiau a `BacktraceSymbol` fewn `BacktraceFrame`.
    ///
    /// # Nodweddion gofynnol
    ///
    /// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol y nodwedd `std` y `backtrace` crate i'w alluogi, ac mae'r nodwedd `std` ei alluogi yn ddiofyn.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: nid yw hyn yn wych nad ydym yn argraffu unrhyw beth yn y pen draw
            // gyda enwau ffeiliau nad ydynt yn UTF8.
            // Diolch byth fod bron popeth yn utf8 felly ni ddylai hyn fod yn rhy ddrwg.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Printiau o crai olrhain `Frame` a `Symbol`, fel arfer o'r tu mewn i'r callbacks crai crate hwn.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Yn ychwanegu ffrâm amrwd i'r allbwn backtrace.
    ///
    /// Mae'r dull hwn, yn wahanol i'r blaenorol, yn cymryd y dadleuon amrwd rhag ofn eu bod yn cael ffynhonnell o wahanol leoliadau.
    /// Sylwch y gellir galw hyn sawl gwaith ar gyfer un ffrâm.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Yn ychwanegu ffrâm crai i'r cynnyrch olrheiniad, gan gynnwys gwybodaeth colofn.
    ///
    /// Mae'r dull hwn, fel y blaenorol, yn cymryd y dadleuon amrwd rhag ofn eu bod yn cael ffynhonnell o wahanol leoliadau.
    /// Sylwch y gellir galw hyn sawl gwaith ar gyfer un ffrâm.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia yn gallu symboleiddio fewn proses felly mae ganddo fformat arbennig y gellir ei ddefnyddio i symboleiddio yn nes ymlaen.
        // Argraffwch hynny yn lle argraffu cyfeiriadau yn ein fformat ein hunain yma.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Nid oes angen argraffu fframiau "null", yn y bôn mae'n golygu bod backtrace y system ychydig yn awyddus i olrhain yn ôl yn bell iawn.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // I leihau maint y TCB yn SGX cilfach, nid ydym am i weithredu ymarferoldeb ddatrys symbol.
        // Yn hytrach, gallwn argraffu y gwrthbwyso y cyfeiriad yma, a allai gael eu mapio yn ddiweddarach i swyddogaeth gywir.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Argraffu mynegai y ffrâm yn ogystal â pwyntydd cyfarwyddiadau dewisol y ffrâm.
        // Os ydym yn y tu hwnt i'r symbol cyntaf y ffrâm hon er ein bod dim ond argraffu gofod gwyn priodol.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // fyny Nesaf ysgrifennu allan yr enw symbol, gan ddefnyddio'r ail fformatio am fwy o wybodaeth os ydym olrheiniad llawn.
        // Yma rydym hefyd yn trin symbolau nad oes enw iddynt,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ac yn olaf, argraffwch y rhif filename/line os ydyn nhw ar gael.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line yn cael eu hargraffu ar linellau o dan yr enw symbol, felly argraffwch rywfaint o le gwyn priodol i ddidoli ein hunain yn iawn.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Dirprwyo i'n galwad yn ôl fewnol i argraffu enw'r ffeil ac yna argraffu rhif y llinell.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Ychwanegwch rif colofn, os yw ar gael.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Nid ydym ond yn poeni am symbol cyntaf ffrâm
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}