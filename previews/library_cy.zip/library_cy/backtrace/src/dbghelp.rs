//! Modiwl i gynorthwyo i reoli rhwymiadau dbghelp ar Windows
//!
//! Mae backtraces ar Windows (o leiaf ar gyfer MSVC) yn cael eu pweru i raddau helaeth trwy `dbghelp.dll` a'r amrywiol swyddogaethau sydd ynddo.
//! Ar hyn o bryd mae'r swyddogaethau hyn yn cael eu llwytho *yn ddeinamig* yn hytrach na chysylltu â `dbghelp.dll` yn statig.
//! Gwneir hyn ar hyn o bryd gan y llyfrgell safonol (ac mae ei angen yno mewn theori), ond mae'n ymdrech i helpu i leihau dibyniaethau statig dll llyfrgell gan fod y cefn yn nodweddiadol yn eithaf dewisol.
//!
//! Hynny'n cael ei ddweud, `dbghelp.dll` llwythi bron bob amser yn llwyddiannus ar Windows.
//!
//! Sylwch, ers i ni lwytho'r holl gefnogaeth hon yn ddeinamig, ni allwn ddefnyddio'r diffiniadau amrwd yn `winapi`, ond yn hytrach mae angen i ni ddiffinio'r mathau pwyntydd swyddogaeth ein hunain a defnyddio hynny.
//! Nid ydym wir eisiau bod yn y busnes o ddyblygu winapi, felly mae gennym nodwedd Cargo `verify-winapi` sy'n honni bod pob rhwymiad yn cyfateb i'r rhai yn winapi ac mae'r nodwedd hon wedi'i galluogi ar CI.
//!
//! Yn olaf, byddwch yn nodi yma fod y dll ar gyfer `dbghelp.dll` byth yn cael ei ddadlwytho, ac mae hynny'n fwriadol ar hyn o bryd.
//! Y meddwl yw y gallwn ei storio'n fyd-eang a'i ddefnyddio rhwng galwadau i'r API, gan osgoi loads/unloads drud.
//! Os yw hyn yn broblem i synwyryddion gollwng neu rywbeth felly gallwn groesi'r bont pan gyrhaeddwn.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Gweithio o amgylch `SymGetOptions` a `SymSetOptions` heb fod yn bresennol yn winapi ei hun.
// Fel arall, dim ond pan fyddwn yn gwirio mathau yn erbyn winapi y defnyddir hyn.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Heb ei ddiffinio yn winapi eto
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Diffinnir hyn yn winapi, ond mae'n anghywir (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Heb ei ddiffinio yn winapi eto
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Defnyddir y macro hwn i ddiffinio strwythur `Dbghelp` sy'n cynnwys yn fewnol yr holl awgrymiadau swyddogaeth y gallem eu llwytho.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Y DLL wedi'i lwytho ar gyfer `dbghelp.dll`
            dll: HMODULE,

            // Pob pwyntydd swyddogaeth ar gyfer pob swyddogaeth y gallem ei defnyddio
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Ar y dechrau nid ydym wedi llwytho y DLL
            dll: 0 as *mut _,
            // Yn y lle cyntaf yr holl swyddogaethau yn cael eu gosod i sero i ddweud mae angen iddynt gael eu llwytho ddeinamig.
            //
            $($name: 0,)*
        };

        // Teipedef cyfleustra ar gyfer pob math o swyddogaeth.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Ymdrechion i agor `dbghelp.dll`.
            /// Ffurflenni llwyddiant os bydd yn gweithio neu gamgymeriad os `LoadLibraryW` yn methu.
            ///
            /// Panics os yw'r llyfrgell eisoes wedi'i llwytho.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Swyddogaeth ar gyfer pob dull yr hoffem ei ddefnyddio.
            // Pan elwir bydd naill ai'n darllen y pwyntydd swyddogaeth cached neu lwytho ac yn dychwelyd y gwerth llwythog.
            // Llwythi yn mynnu i lwyddo.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dirprwy cyfleustra i ddefnyddio'r cloeon glanhau i gyfeirio at swyddogaethau dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Ymgychwyn holl gymorth angenrheidiol i swyddogaethau API mynediad `dbghelp` o'r crate hwn.
///
///
/// Sylwch fod y swyddogaeth hon yn **ddiogel**, mae ganddi ei chydamseriad ei hun yn fewnol.
/// Hefyd yn nodi ei bod yn ddiogel i alw swyddogaeth hon sawl gwaith recursively.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Y peth cyntaf mae angen i ni ei wneud yw i gydamseru swyddogaeth hon.Gellir galw hyn yr un pryd o edafedd eraill neu'n gylchol o fewn un edefyn.
        // Sylwch ei bod yn anoddach na hynny, oherwydd mae angen cydamseru'r hyn rydyn ni'n ei ddefnyddio yma, `dbghelp`,*hefyd* gyda'r holl alwyr eraill i `dbghelp` yn y broses hon.
        //
        // Fel arfer nid oes iawn bod llawer o alwadau i `dbghelp` o fewn yr un broses a gallwn gymryd yn ganiataol yn ôl pob tebyg yn ddiogel bod ni yw'r unig rai gael mynediad iddo.
        // Fodd bynnag, mae un defnyddiwr sylfaenol arall y mae'n rhaid i ni boeni amdano sydd yn eironig ein hunain, ond yn y llyfrgell safonol.
        // Mae'r llyfrgell safonol Rust dibynnu ar crate hwn am gymorth olrheiniad, a crate mae hyn hefyd yn bodoli ar crates.io.
        // Mae hyn yn golygu os bydd y llyfrgell safonol yn cael ei argraffu olrheiniad panic gall rasio gyda crate hwn yn dod o crates.io, gan achosi segfaults.
        //
        // I help datrys problem cydamseru hwn rydym yn cyflogi tric Windows-benodol yma (y mae, wedi'r cyfan, cyfyngiad Windows-penodol am synchronization).
        // Rydym yn creu mutex a enwir *sesiwn-leol* i amddiffyn yr alwad hon.
        // Y bwriad yma yw nad oes rhaid i'r llyfrgell safonol a'r crate hwn rannu APIs lefel Rust i gydamseru yma ond yn hytrach gallant weithio y tu ôl i'r llenni i sicrhau eu bod yn cydamseru â'i gilydd.
        //
        // Y ffordd honno pan elwir y swyddogaeth hon trwy'r llyfrgell safonol neu drwy crates.io gallwn fod yn sicr bod yr un mutex yn cael ei gaffael.
        //
        // Felly hynny i gyd yw dweud mai'r peth cyntaf rydyn ni'n ei wneud yma yw ein bod ni'n atomig yn creu `HANDLE` sy'n fudiad a enwir ar Windows.
        // Rydym yn cydamseru ychydig ag edafedd eraill sy'n rhannu'r swyddogaeth hon yn benodol ac yn sicrhau mai dim ond un handlen sy'n cael ei chreu fesul enghraifft o'r swyddogaeth hon.
        // Noder nad yw byth yr handlen ar gau unwaith y caiff ei storio yn y byd-eang.
        //
        // Ar ôl i ni fynd y clo mewn gwirionedd, rydym yn syml yn ei gaffael, a bydd ein handlen `Init` rydyn ni'n ei dosbarthu yn gyfrifol am ei ollwng yn y pen draw.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Iawn, phew!Nawr ein bod ni i gyd wedi'u cydamseru'n ddiogel, gadewch i ni ddechrau prosesu popeth mewn gwirionedd.
        // Yn gyntaf, mae angen i ni sicrhau bod `dbghelp.dll` yn cael ei lwytho yn y broses hon.
        // Rydym yn gwneud hyn yn ddeinamig i osgoi dibyniaeth statig.
        // Yn hanesyddol gwnaed hyn i weithio o amgylch materion cysylltu rhyfedd a'i fwriad yw gwneud ysbardunau ychydig yn fwy cludadwy gan mai cyfleustodau difa chwilod yn unig yw hwn i raddau helaeth.
        //
        //
        // Unwaith y byddwn wedi agor `dbghelp.dll` mae angen i alw rhai swyddogaethau initialization ynddo, ac mae hynny'n manylir yn fwy isod.
        // Dim ond unwaith rydyn ni'n gwneud hyn, felly mae gennym ni boolean byd-eang sy'n nodi a ydyn ni wedi gwneud eto ai peidio.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Sicrhewch fod y faner `SYMOPT_DEFERRED_LOADS` wedi'i gosod, oherwydd yn ôl docs MSVC ei hun ynglŷn â hyn: "This is the fastest, most efficient way to use the symbol handler.", felly gadewch i ni wneud hynny!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // A dweud y gwir ymgychwyn symbolau gyda MSVC.Sylwch y gall hyn fethu, ond rydym yn ei anwybyddu.
        // Nid oes tunnell o gelf flaenorol ar gyfer hyn fel y cyfryw, ond ymddengys yn fewnol bod LLVM yn anwybyddu'r gwerth dychwelyd yma ac mae un o'r llyfrgelloedd glanweithdra yn LLVM yn argraffu rhybudd brawychus os yw hyn yn methu ond yn y bôn yn ei anwybyddu yn y tymor hir.
        //
        //
        // Mae un achos mae hyn yn dod i fyny llawer am Rust yw bod y llyfrgell safonol ac crate hwn crates.io yn awyddus i gystadlu am `SymInitializeW`.
        // Mae'r llyfrgell safonol yn hanesyddol yn awyddus i ymgychwyn yna glanhau rhan fwyaf o'r amser, ond erbyn hyn ei fod yn defnyddio'r crate hwn mae'n golygu y bydd rhywun yn cael i initialization gyntaf a bydd y llall yn codi y initialization.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}