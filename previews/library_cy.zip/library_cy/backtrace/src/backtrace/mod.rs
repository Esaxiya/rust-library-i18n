use core::ffi::c_void;
use core::fmt;

/// Yn archwilio'r pentwr galwadau cyfredol, gan basio'r holl fframiau gweithredol i'r cau a ddarperir i gyfrifo olrhain pentwr.
///
/// Y swyddogaeth hon yw blaen gwaith y llyfrgell hon wrth gyfrifo'r olion pentwr ar gyfer rhaglen.Mae'r `cb` Rhoddir gau yn esgor enghreifftiau o `Frame` sy'n cynrychioli gwybodaeth am y ffrâm galw ar y pentwr.
/// Mae'r cau yn cael ei gynhyrchu fframiau mewn dull o'r brig i lawr (a elwir yn swyddogaethau yn gyntaf yn gyntaf).
///
/// Mae gwerth dychwelyd y cau yn arwydd a ddylai'r backtrace barhau.Bydd gwerth dychwelyd o `false` yn terfynu'r backtrace ac yn dychwelyd ar unwaith.
///
/// Ar ôl caffael `Frame` mae'n debyg y byddwch am ffonio `backtrace::resolve` i drosi'r `ip` (pwyntydd cyfarwyddiadau) neu'r cyfeiriad symbol yn `Symbol` y gellir dysgu'r enw a/neu'r enw ffeil/rhif llinell drwyddo.
///
///
/// Sylwch fod hon yn swyddogaeth lefel gymharol isel ac os hoffech chi, er enghraifft, ddal ôl-gefn i'w harchwilio'n ddiweddarach, yna efallai y bydd y math `Backtrace` yn fwy priodol.
///
/// # Nodweddion gofynnol
///
/// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol y nodwedd `std` y `backtrace` crate i'w alluogi, ac mae'r nodwedd `std` ei alluogi yn ddiofyn.
///
/// # Panics
///
/// Mae'r swyddogaeth hon yn ymdrechu i beidio byth â panic, ond pe bai'r `cb` yn darparu panics yna bydd rhai platfformau'n gorfodi panic dwbl i erthylu'r broses.
/// Mae rhai platfformau'n defnyddio llyfrgell C sy'n defnyddio galwadau ffôn yn fewnol na ellir eu trwsio drwodd, felly gall panicio o `cb` ysgogi erthyliad proses.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // parhau â'r backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Yr un peth â `trace`, dim ond yn anniogel gan ei fod heb ei gydamseru.
///
/// Nid oes gan y swyddogaeth hon warantau cydamseru ond mae ar gael pan nad yw nodwedd `std` y crate hon wedi'i llunio ynddo.
/// Gweler swyddogaeth `trace` i gael mwy o ddogfennaeth ac enghreifftiau.
///
/// # Panics
///
/// Gweler gwybodaeth ar `trace` am gafeatau ar banicio `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Mae trait yn cynrychioli un ffrâm o gefn, wedi'i esgor ar swyddogaeth `trace` y crate hwn.
///
/// Bydd fframiau'n cau'r swyddogaeth olrhain, ac mae'r ffrâm bron yn cael ei hanfon gan nad yw'r gweithredu sylfaenol bob amser yn hysbys tan amser rhedeg.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Yn dychwelyd pwyntydd cyfarwyddiadau cyfredol y ffrâm hon.
    ///
    /// Fel rheol, hwn yw'r cyfarwyddyd nesaf i'w weithredu yn y ffrâm, ond nid yw pob gweithrediad yn rhestru hyn gyda chywirdeb 100% (ond ar y cyfan mae'n eithaf agos).
    ///
    ///
    /// Argymhellir pasio'r gwerth hwn i `backtrace::resolve` i'w droi yn enw symbol.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Yn dychwelyd pwyntydd pentwr cyfredol y ffrâm hon.
    ///
    /// Yn achos na all ol-wyneb adennill y pwyntydd stac ar gyfer ffrâm hon, pwyntydd null cael ei ddychwelyd.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Yn dychwelyd cyfeiriad symbol cychwynnol ffrâm y swyddogaeth hon.
    ///
    /// Bydd hyn yn ceisio ailddirwyn y pwyntydd cyfarwyddiadau a ddychwelwyd gan `ip` i ddechrau'r swyddogaeth, gan ddychwelyd y gwerth hwnnw.
    ///
    /// Mewn rhai achosion, fodd bynnag, bydd backends yn dychwelyd `ip` o'r swyddogaeth hon yn unig.
    ///
    /// Weithiau gellir defnyddio'r gwerth a ddychwelwyd os methodd `backtrace::resolve` ar yr `ip` a roddir uchod.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Yn dychwelyd cyfeiriad sylfaenol y modiwl y mae'r ffrâm yn perthyn iddo.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Mae angen i hyn ddod yn gyntaf, er mwyn sicrhau bod Miri yn cymryd blaenoriaeth dros y llwyfan llu
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // dim ond yn cael ei ddefnyddio mewn dbghelp yn symboleiddio
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}