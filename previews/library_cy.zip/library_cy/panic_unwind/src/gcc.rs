//! Gweithredu panics gyda chefnogaeth libgcc/libunwind (ar ryw ffurf).
//!
//! Am gefndir ar drin eithriad a simnai ymlacio gweler "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) a dogfennau cysylltiedig ohono.
//! Mae'r rhain hefyd yn ddarlleniadau da:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Mae crynodeb byr
//!
//! trin Eithriad yn digwydd mewn dau gam: cyfnod chwilio a chyfnod glanhau.
//!
//! Yn y ddau gyfnod mae'r dad-dynnu yn cerdded fframiau pentwr o'r top i'r gwaelod gan ddefnyddio gwybodaeth o'r adrannau pentyrru dadflino o fodiwlau'r broses gyfredol (mae "module" yma'n cyfeirio at fodiwl OS, hy, gweithredadwy neu lyfrgell ddeinamig).
//!
//!
//! Ar gyfer pob ffrâm pentwr, mae'n galw'r "personality routine" cysylltiedig, y mae ei gyfeiriad hefyd wedi'i storio yn yr adran wybodaeth ddadflino.
//!
//! Yn y cam chwilio, y gwaith o drefn personoliaeth yw archwilio eithriad gwrthrych yn cael eu taflu, a phenderfynu a ddylid ei ddal ar y ffrâm pentwr.Unwaith y bydd y ffrâm trafodwr wedi cael ei adnabod, cam glanhau yn dechrau.
//!
//! Yn y cam glanhau, y unwinder ennyn pob trefn personoliaeth eto.
//! Y tro hwn mae'n penderfynu pa (os o gwbl) Anghenion cod glanhau i gael ei gynnal ar gyfer y ffrâm pentwr presennol.Os felly, mae'r rheolaeth yn cael ei drosglwyddo i branch arbennig yn y corff swyddogaeth, y "landing pad", sy'n ennyn destructors, cof Frees, ac ati
//! Ar ddiwedd y pad glanio, rheolaeth yn cael ei drosglwyddo yn ôl i'r unwinder ac yn ailddechrau ymlacio.
//!
//! Unwaith y stac wedi bod i lawr ddirwyn i lefel ffrâm triniwr, atalnodau dad-ddirwyn a'r bersonoliaeth diwethaf trosglwyddiadau rheolaidd rheoli i'r bloc dal.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Dynodwr dosbarth eithriad Rust.
// Mae hyn yn cael ei ddefnyddio gan arferion bersonoliaeth i benderfynu a yw'r eithriad ei daflu gan eu Rhedeg hunain.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // Moz\0 RUST-gwerthwr, iaith
    0x4d4f5a_00_52555354
}

// Cofrestru bidiau eu codi o TargetLowering::getExceptionPointerRegister() a TargetLowering::getExceptionSelectorRegister() LLVM ar gyfer pob pensaernïaeth, yna mapio i rifau gofrestr gorrach drwy dablau diffiniad gofrestr (fel arfer<arch>RegisterInfo.td, chwiliwch am "DwarfRegNum").
//
// Gweler hefyd http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Mae'r cod canlynol yn seiliedig ar arferion personoliaeth C a C++ GCC.Am gyfeirnod, gweler:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Trefn bersonoliaeth EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS defnyddio'r drefn diofyn yn lle gan ei fod yn defnyddio SjLj dad-ddirwyn.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Bydd backtraces ar ARM yn galw'r drefn bersonoliaeth gyda state==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Yn yr achosion hynny, rydym am barhau i dad-ddirwyn y simnai, fel arall i gyd fyddai ein olrheiniadau gorffen am __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Mae'r unwinder corrach yn tybio bod_Unwind_Context dal pethau fel y swyddogaeth ac awgrymiadau LSDA, fodd bynnag ARM EHABI gosod i mewn i'r gwrthrych eithriad.
            // Er mwyn gwarchod llofnodion o swyddogaethau fel _Unwind_GetLanguageSpecificData(), sy'n cymryd dim ond y pwyntydd cyd-destun, arferion personoliaeth GCC stash pwyntydd i exception_object yng nghyd-destun, gan ddefnyddio lleoliad neilltuo ar gyfer Archifau a Chofnodion yn "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Byddai dull mwy egwyddorol fydd darparu diffiniad llawn o_Unwind_Context ARM yn ein rhwymiadau libunwind a nôl y data sy'n ofynnol oddi yno yn uniongyrchol, osgoi swyddogaethau cydweddoldeb Corrach.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // Mae EHABI yn ei gwneud yn ofynnol i'r drefn bersonoliaeth ddiweddaru'r gwerth SP yng storfa rwystr y gwrthrych eithriad.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Ar ARM EHABI mae'r drefn bersonoliaeth yn gyfrifol am ddadflino ffrâm pentwr sengl cyn dychwelyd (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // a ddiffinnir yn libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // arferol personoliaeth ddiofyn, sy'n cael ei ddefnyddio yn uniongyrchol ar y rhan fwyaf o dargedau ac yn anuniongyrchol ar Windows x86_64 drwy SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // O ran targedau x86_64 MinGW, y mecanwaith dad-ddirwyn yn SEH ond mae'r data triniwr ymlacio (aka LSDA) yn defnyddio amgodio GCC-gydnaws.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Y drefn bersonoliaeth ar gyfer y rhan fwyaf o'n targedau.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Gall y cyfeiriad dychwelyd pwyntiau 1 beit heibio i'r cyfarwyddyd alwad, a allai fod yn yr ystod IP nesaf yn nhabl ystod LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Ffrâm cofrestru gwybodaeth dadflino
//
// image pob modiwl yn cynnwys adran info ymlacio ffrâm (fel arfer ".eh_frame").Pan fydd modiwl yn loaded/unloaded yn y broses, rhaid hysbysu'r dad-ddirwynwr am leoliad yr adran hon er cof.Mae'r dulliau o gyflawni hynny'n amrywio yn ôl y platfform.
// Ar rai (ee, Linux), gall y dad-dynnu ddarganfod adrannau gwybodaeth dadflino ar ei ben ei hun (trwy gyfrif yn ddynamig fodiwlau sydd wedi'u llwytho ar hyn o bryd trwy'r dl_iterate_phdr() API and finding their ".eh_frame" sections); Mae eraill, fel Windows, yn ei gwneud yn ofynnol i fodiwlau gofrestru eu hadrannau gwybodaeth dadflino trwy API dad-dynnu.
//
//
// Mae'r modiwl hwn yn diffinio dau symbol y cyfeirir atynt ac a elwir o rsbegin.rs i gofrestru ein gwybodaeth gyda'r amser rhedeg GCC.
// Mae gweithredu dad-ddirwyn stac yw (ar hyn o bryd) tan libgcc_eh, fodd bynnag Rust crates defnyddio'r rhain bwyntiau mynediad Rust-benodol er mwyn osgoi gwrthdaro posibl ag unrhyw runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}