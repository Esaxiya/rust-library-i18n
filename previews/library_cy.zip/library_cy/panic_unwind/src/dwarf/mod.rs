//! Cyfleustodau ar gyfer dosrannu ffrydiau data wedi'u hamgodio gan DWARF.
//! Gweler safon <http://www.dwarfstd.org>, DWARF-4, Adran 7, "Data Representation"
//!

// Dim ond x86_64-pc-windows-gnu sy'n defnyddio'r modiwl hwn am y tro, ond rydyn ni'n ei lunio ym mhobman er mwyn osgoi atchweliadau.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Mae ffrydiau DWARF wedi'u pacio, felly ee, ni fyddai u32 o reidrwydd yn cael ei alinio ar ffin 4-beit.
    // Gall hyn achosi problemau ar lwyfannau â gofynion aliniad llym.
    // Trwy lapio data mewn strwythur "packed", rydym yn dweud wrth y backend i gynhyrchu cod "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 a SLEB128 amgodiadau eu diffinio yn Adran 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}