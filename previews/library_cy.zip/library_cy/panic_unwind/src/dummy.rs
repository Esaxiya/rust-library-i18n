//! Yn ddiarwybod am darged *wasm32*.
//!
//! Ar hyn o bryd nid ydym yn cefnogi hyn, felly mae hyn yn bonion yn unig.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}