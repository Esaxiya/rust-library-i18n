//! Dad-ddirwyn panics am Miri.
use alloc::boxed::Box;
use core::any::Any;

// Y math o y prif lwyth bod y peiriant Miri ehangun drwy dad-ddirwyn i ni.
// Rhaid bod o faint pwyntydd.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Swyddogaeth allanol a ddarperir gan Miri i ddechrau dadflino.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Bydd y prif lwyth yn trosglwyddo i `miri_start_panic` fod yn union y ddadl a gawn yn `cleanup` isod.
    // Felly rydyn ni jyst yn ei focsio unwaith, i gael rhywbeth maint pwyntydd.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Adennill yr `Box` sylfaenol.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}