//! Windows SEH
//!
//! Ar Windows (ar hyn o bryd yn unig ar MSVC), y mecanwaith trin eithriad diofyn yn cael ei Strwythuredig Eithriad Trin (SEH).
//! Mae hyn yn wahanol iawn nag trin Dwarf-seiliedig eithriad (ee, pa lwyfannau unix eraill yn defnyddio) o ran mewnolion compiler, felly mae angen LLVM i gael llawer o gymorth ychwanegol i SEH.
//!
//! Yn gryno, yr hyn sy'n digwydd yma yw:
//!
//! 1. Mae'r swyddogaeth `panic` yn galw y swyddogaeth Windows safonol `_CxxThrowException` i daflu C++ -fel eithriad, sbarduno'r broses ymlacio.
//! 2.
//! Mae pob padiau glanio a gynhyrchir gan y compiler defnyddio'r swyddogaeth personoliaeth `__CxxFrameHandler3`, swyddogaeth yn y CRT, a bydd y cod ymlacio yn Windows yn defnyddio'r swyddogaeth personoliaeth hwn i weithredu pob cod glanhau ar y pentwr.
//!
//! 3. Mae gan bob galwad a gynhyrchir gan grynhowr i `invoke` bad glanio wedi'i osod fel cyfarwyddyd `cleanuppad` LLVM, sy'n nodi dechrau'r drefn lanhau.
//! Mae'r personoliaeth (mewn cam 2, a ddiffinnir yn y CRT) yn gyfrifol am redeg y drefn glanhau.
//! 4. Yn y pen draw mae'r cod "catch" yn y cynhenid `try` (a gynhyrchir gan y compiler) ei gyflawni ac mae'n dangos y dylai rheolaeth ddod yn ôl i Rust.
//! Gwneir hyn drwy `catchswitch` yn ogystal â chyfarwyddyd `catchpad` mewn termau LLVM IR, yn olaf dychwelyd rheoli arferol i'r rhaglen gyda chyfarwyddyd `catchret`.
//!
//! Rhai gwahaniaethau penodol o'r ymdriniaeth eithriad sy'n seiliedig ar gcc yw:
//!
//! * Rust nid oes swyddogaeth personoliaeth arfer, mae'n lle hynny *bob amser*`__CxxFrameHandler3`.Yn ogystal, nid oes unrhyw hidlo ychwanegol yn cael ei pherfformio, felly rydym yn y pen draw yn dal unrhyw++ eithriadau C sy'n digwydd i edrych fel y math rydym yn ei daflu.
//! Noder bod taflu eithriad i Rust yw ymddygiad anniffiniedig beth bynnag, felly dylai hyn fod yn iawn.
//! * Mae gennym ni rywfaint o ddata i'w drosglwyddo ar draws y ffin ddad-ddirwyn, `Box<dyn Any + Send>` yn benodol.Fel gydag eithriadau Rhostir y ddau awgrym yn cael eu storio fel prif lwyth yn eithrio ei hun.
//! Ar MSVC, fodd bynnag, nid oes angen dyraniad domen ychwanegol oherwydd y pentwr alwad yn cael ei gadw tra swyddogaethau hidlo yn cael eu dienyddio.
//! Mae hyn yn golygu bod yr awgrymiadau'n cael eu trosglwyddo'n uniongyrchol i `_CxxThrowException` sydd wedyn yn cael eu hadfer yn y swyddogaeth hidlo i'w hysgrifennu i ffrâm pentwr yr `try` cynhenid.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Mae hyn angen i fod yn opsiwn oherwydd ein bod yn dal eithrio trwy gyfeirio a'i destructor cael ei gyflawni gan y C++ runtime.
    // Pan fyddwn yn cymryd y Box allan o'r eithriad, mae angen i ni adael y eithriad mewn cyflwr dilys am ei destructor i redeg heb dwbl-gollwng y Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Yn gyntaf, criw cyfan o ddiffiniadau math.Mae yna ychydig o bethau rhyfedd platfform-benodol yma, a llawer sydd wedi'i gopïo'n eglur gan LLVM.Pwrpas hyn i gyd yw gweithredu'r swyddogaeth `panic` isod trwy alwad i `_CxxThrowException`.
//
// Mae'r swyddogaeth hon yn cymryd dau dadleuon.Mae'r cyntaf yn pwyntydd at y data yr ydym yn pasio i mewn, sydd yn yr achos hwn yn ein trait gwrthrych.Pretty hawdd dod o hyd!Mae'r nesaf, fodd bynnag, yn fwy cymhleth.
// Mae hwn yn pwyntydd i strwythur `_ThrowInfo`, ac mae'n cael ei dim ond y bwriedir gyffredinol i ychydig ddisgrifio'r eithriad yn cael ei daflu.
//
// Ar hyn o bryd mae'r diffiniad o'r math hwn [1] ychydig yn flewog, ac mae'r prif Eithriad (a gwahaniaeth o erthygl ar-lein) yw y ar 32-bit y awgrymiadau yn awgrymiadau, ond ar 64-bit y awgrymiadau yn cael eu mynegi fel gwrthbwyso 32-bit o'r Symbol `__ImageBase`.
//
// Defnyddir y macro `ptr_t` a `ptr!` yn y modiwlau isod i fynegi hyn.
//
// Mae'r ddrysfa o ddiffiniadau fath hefyd yn dilyn yn agos yr hyn LLVM allyrru gyfer y math hwn o weithredu.Er enghraifft, os ydych yn llunio y cod C++ ar MSVC ac yn allyrru y LLVM IR:
//
//      #include <stdint.h>
//
//      strwythr rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      gwagle foo() { rust_panic a = {0, 1};
//          taflu;}
//
// Dyna yn y bôn yr hyn rydyn ni'n ceisio ei efelychu.Copïwyd y rhan fwyaf o'r gwerthoedd cyson isod o LLVM,
//
// Mewn unrhyw achos, strwythurau hyn i gyd hadeiladu mewn ffordd debyg, ac mai dim ond braidd yn amleiriog i ni.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Sylwer ein bod yn fwriadol anwybyddu enw rheolau ystumio yma: nid ydym am C++ i fod yn gallu dal Rust panics gan syml datgan `struct rust_panic`.
//
//
// Wrth addasu, gwnewch yn siŵr bod y llinyn enw math yn cyfateb yn union i'r un a ddefnyddir yn `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Mae'r beit `\x01` blaenllaw yma mewn gwirionedd yn signal hudolus i LLVM i * beidio â chymhwyso unrhyw waith rheoli arall fel rhagddodi gyda chymeriad `_`.
    //
    //
    // Y symbol hwn yw'r vtable a ddefnyddir gan C++ 's `std::type_info`.
    // Gwrthrychau o'r math `std::type_info`, disgrifwyr math, rhaid pwyntydd i'r tabl hwn.
    // disgrifyddion Math cyfeirir gan y strwythurau C++ EH ddiffinnir uchod a'n bod yn adeiladu isod.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Mae'r disgrifydd math hwn yn unig a ddefnyddir wrth daflu eithriad.
// Mae'r rhan dal yn cael ei drin gan y cynhenid cais, sydd yn cynhyrchu ei TypeDescriptor hun.
//
// Mae hyn yn iawn gan fod amser rhedeg MSVC yn defnyddio cymhariaeth llinyn ar yr enw math i gyd-fynd â TypeDescriptors yn hytrach na chydraddoldeb pwyntydd.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Dinistriwr a ddefnyddir os yw'r cod C++ yn penderfynu dal yr eithriad a'i ollwng heb ei luosogi.
// Bydd rhan ddal y cynnig cynhenid yn gosod gair cyntaf y gwrthrych eithriad i 0 fel ei fod yn cael ei hepgor gan y dinistriwr.
//
// Noder bod x86 Windows yn defnyddio'r confensiwn yn galw "thiscall" ar gyfer swyddogaethau aelodau C++ yn lle y confensiwn yn galw diofyn "C".
//
// Mae'r swyddogaeth exception_copy yn dipyn arbennig yma: mae'n cael ei galw i rym gan y Rhedeg MSVC dan bloc try/catch a'r panic ein bod yn cynhyrchu yma yn cael eu defnyddio o ganlyniad y copi eithriad.
//
// Mae hyn yn cael ei ddefnyddio gan y C++ runtime i gefnogi eithriadau dal gyda std::exception_ptr, na allwn gefnogi oherwydd Box<dyn Any>Nid yw clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException executes yn gyfan gwbl ar y ffrâm pentwr, felly does dim angen i fel arall trosglwyddo `data` i'r domen.
    // Rydym yn pasio pwyntydd pentwr i'r swyddogaeth hon yn unig.
    //
    // Mae angen y ManuallyDrop yma gan nad ydym am i Eithriad gael ei ollwng wrth ddadflino.
    // Yn lle bydd yn cael ei ollwng gan eithriad_cleanup sy'n cael ei ddefnyddio gan amser rhedeg C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Mae hyn yn ... Gall ymddangos yn syndod, ac yn haeddiannol felly.Ar 32-bit MSVC yr awgrymiadau rhwng adeiledd mae'r rhain yn unig hynny, awgrymiadau.
    // Ar 64-bit MSVC, fodd bynnag, mae'r arwyddion rhwng strwythurau yn cael eu mynegi yn hytrach fel gwrthbwyso 32-bit o `__ImageBase`.
    //
    // O ganlyniad, ar MSVC 32-did gallwn ddatgan yr holl awgrymiadau hyn yn yr `statig 'uchod.
    // Ar 64-bit MSVC, byddai'n rhaid i ni fynegi tynnu o awgrymiadau mewn carafanau sefydlog, nad yw'n caniatáu Rust ar hyn o bryd, felly ni allwn wneud mewn gwirionedd hynny.
    //
    // Y peth gorau nesaf, yna yw llenwi yn y strwythurau hyn yn Rhedeg (i banig eisoes yn y "slow path" beth bynnag).
    // Felly dyma ni ailddehongli holl feysydd pwyntydd hyn fel gyfanrifau 32-bit ac yna'i storio gwerth perthnasol i mewn iddo (atomically, gan y gall gydamserol panics yn digwydd).
    //
    // Yn dechnegol mae'n debyg y bydd yr amser rhedeg yn darllen y meysydd hyn yn nonatomig, ond mewn theori, nid ydyn nhw byth yn darllen y gwerth *anghywir* felly ni ddylai fod yn rhy ddrwg ...
    //
    // Mewn unrhyw achos, mae angen i ni yn y bôn i wneud rhywbeth fel hyn hyd nes y byddwn yn gallu mynegi mwy o lawdriniaethau mewn carafanau sefydlog (a byth efallai y byddwn yn gallu).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Mae prif lwyth NULL yma'n golygu ein bod yn cael yma o ddalfa (...) o __rust_try.
    // Mae hyn yn digwydd pan fydd eithriad dramor heb Rust ei ddal.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Mae hyn yn ofynnol gan y compiler i fodoli (ee, 'i' yn eitem lang), ond byth fe'i gelwir mewn gwirionedd gan y casglwr fod __C_specific_handler neu_except_handler3 yw swyddogaeth personoliaeth sy'n cael ei ddefnyddio bob amser.
//
// Felly, dim ond bonyn erthylu yw hwn.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}