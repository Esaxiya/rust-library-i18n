//! Gweithredu Rust panics drwy erthylu proses
//!
//! O'i gymharu â gweithredu drwy ymlacio, crate hyn yn *llawer* symlach!Wedi dweud hynny, nid yw mor hyblyg, ond yma yn mynd!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" y llwyth tâl a'r shim i'r erthyliad perthnasol ar y platfform dan sylw.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ffoniwch std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Ar Windows, defnyddiwch y prosesydd-benodol __fastfail mecanwaith.Yn Windows 8 ac yn ddiweddarach, bydd hyn yn dod i ben y broses ar unwaith heb redeg unrhyw trinwyr eithriad ym-broses.
            // Mewn fersiynau cynharach o Windows, bydd y gyfres hon o gyfarwyddiadau yn cael eu trin fel tramgwydd mynediad, gan derfynu'r broses ond heb o reidrwydd osgoi'r holl drinwyr eithriad.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: mae hyn yr un fath ag yn gweithredu `abort_internal` libstd yn
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Mae hwn ... yn dipyn o rhyfedd.Mae'r tl; dr;yw bod angen hwn i gysylltu yn gywir, yr esboniad hirach yn is.
//
// Ar hyn o bryd mae'r binaries libcore/libstd yr ydym yn eu llongio i gyd wedi'u llunio â `-C panic=unwind`.Gwneir hyn i sicrhau bod y binaries yn gydnaws â chynifer â phosibl o sefyllfaoedd.
// Fodd bynnag, mae'r casglwr yn gofyn am "personality function" ar gyfer yr holl swyddogaethau a luniwyd gyda `-C panic=unwind`.Mae'r swyddogaeth hon yn cael ei bersonoliaeth hardcoded i'r symbol `rust_eh_personality` ac yn cael ei ddiffinio gan y eitem `eh_personality` lang.
//
// So...
// beth am ddiffinio'r eitem lang yma yn unig?Cwestiwn da!Bydd y ffordd y runtimes panic yn gysylltiedig mewn gwirionedd ychydig cynnil yn eu bod "sort of" yn y siop crate y casglwr, ond dim ond yn gysylltiedig mewn gwirionedd os nid un arall ei gysylltu mewn gwirionedd.
//
// Mae hyn yn dod i ben i fyny sy'n golygu y gall y ddau crate hwn a'r panic_unwind crate ymddangos yn y siop crate y casglwr, ac os yw'r ddau yn diffinio'r eitem `eh_personality` lang yna bydd yn taro gwall.
//
// Er mwyn ymdrin â hyn y compiler yn unig yn gofyn y `eh_personality` ei ddiffinio os yw'r Rhedeg panic cael eu cysylltu yn yr Rhedeg dad-ddirwyn, ac fel arall ni ei angen iddo gael ei ddiffinio (haeddiannol felly).
// Yn yr achos hwn, fodd bynnag, mae'r llyfrgell hon yn diffinio'r symbol hwn yn unig felly mae rhywfaint o bersonoliaeth yn rhywle o leiaf.
//
// Yn y bôn symbol hwn yn unig y diffinnir yn cael gwifrau i binaries libcore/libstd, ond ni ddylid byth ei alw gan nad ydym yn cysylltu mewn Rhedeg ymlacio o gwbl.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Ar x86_64-pc-ffenestri-gnu rydym yn defnyddio ein swyddogaeth personoliaeth hunain bod angen i ddychwelyd `ExceptionContinueSearch` gan ein bod yn pasio ar ein holl fframiau.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Yn debyg i'r uchod, mae hyn yn cyfateb i'r eitem `eh_catch_typeinfo` lang sydd ond yn cael ei defnyddio ar Emscripten ar hyn o bryd.
    //
    // Gan nad panics yn cynhyrchu eithriadau ac eithriadau tramor ar hyn o bryd UB gyda -C panic=Erthylu (er y gall hyn fod yn amodol ar newid), bydd unrhyw alwadau catch_unwind peidiwch byth â defnyddio typeinfo hwn.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Mae'r ddau yn cael eu galw gan ein hamcanion startup ar i686-pc-ffenestri-gnu, ond nid oes angen iddynt wneud unrhyw beth felly mae'r cyrff yn nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}