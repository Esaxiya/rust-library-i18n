//! traits a mathau Cyntefig cynrychioli priodweddau sylfaenol o fathau.
//!
//! Gellir dosbarthu mathau Rust mewn amryw o ffyrdd defnyddiol yn ôl eu priodweddau cynhenid.
//! Mae'r dosbarthiadau yn cael eu cynrychioli fel traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Mathau gellir eu trosglwyddo ar draws ffiniau edau.
///
/// Mae'r trait cael ei weithredu yn awtomatig pan fydd y compiler yn penderfynu ei fod yn briodol.
///
/// Enghraifft o fath nad yw'n 'Send` yw'r pwyntydd cyfrif cyfeirnod [`rc::Rc`][`Rc`].
/// Os yw dwy edefyn yn ceisio clonio [`Rc`] s sy'n pwyntio at yr un gwerth â chyfrif cyfeirnod, gallent geisio diweddaru'r cyfrif cyfeirnod ar yr un pryd, sef [undefined behavior][ub] oherwydd nad yw [`Rc`] yn defnyddio gweithrediadau atomig.
///
/// Mae ei gefnder [`sync::Arc`][arc] yn defnyddio gweithrediadau atomig (achosi rhywfaint uwchben) ac felly mae'n `Send`.
///
/// Gweler [the Nomicon](../../nomicon/send-and-sync.html) am fwy o fanylion.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Mathau gyda maint cyson yn hysbys ar amser llunio.
///
/// Mae gan bob paramedr math rwym ymhlyg o `Sized`.Gall y gystrawen arbennig `?Sized` yn cael eu defnyddio i gael gwared ar hyn yn rhwymo os nad yw'n briodol.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//Gwall: nid yw eu Maint yn cael ei weithredu ar gyfer [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Yr un eithriad yw'r math `Self` ymhlyg o trait.
/// Nid oes gan trait `Sized` ymhlyg wedi'i rwymo gan fod hyn yn anghydnaws â [gwrthrych trait] lle, yn ôl diffiniad, mae angen i'r trait weithio gyda'r holl weithredwyr posibl, ac felly gallai fod o unrhyw faint.
///
///
/// Er y bydd yn gadael i chi Rust rhwymo `Sized` i trait, ni fyddwch yn gallu ei ddefnyddio i ffurfio gwrthrych trait ddiweddarach:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // gadewch y: &dyn Bar= &Impl;//Gwall: mae'r trait `Bar` ni ellir gwneud i mewn i wrthrych
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ar gyfer Diffyg, er enghraifft, sy'n ei gwneud yn ofynnol i `[T]: !Default` gael ei werthuso
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Mathau a all fod yn "unsized" i fath maint deinamig.
///
/// Er enghraifft, y math amrywiaeth maint `[i8; 2]` yn gweithredu `Unsize<[i8]>` a `Unsize<dyn fmt::Debug>`.
///
/// Darperir holl weithrediadau `Unsize` yn awtomatig gan y casglwr.
///
/// `Unsize` yn cael ei weithredu ar gyfer:
///
/// - `[T; N]` yw `Unsize<[T]>`
/// - `T` yw `Unsize<dyn Trait>` pan `T: Trait`
/// - `Foo<..., T, ...>` yw `Unsize<Foo<..., U, ...>>` os:
///   - `T: Unsize<U>`
///   - Mae Foo yn strwythur
///   - Dim ond y cae olaf `Foo` Mae gan fath sy'n cynnwys `T`
///   - `T` Nid yw rhan o'r math o unrhyw feysydd eraill
///   - `Bar<T>: Unsize<Bar<U>>`, os y maes olaf `Foo` wedi `Bar<T>` math
///
/// `Unsize` yn cael ei ddefnyddio ynghyd â [`ops::CoerceUnsized`] i ganiatáu i gynwysyddion "user-defined" fel [`Rc`] gynnwys mathau o faint deinamig.
/// Gweler yr [DST coercion RFC][RFC982] a [the nomicon entry on coercion][nomicon-coerce] i gael mwy o fanylion.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait gofynnol ar gyfer cysonion a ddefnyddir mewn matsys patrwm.
///
/// Mae unrhyw fath sy'n deillio o `PartialEq` yn gweithredu'r trait hwn yn awtomatig, * ni waeth a yw ei baramedrau math yn gweithredu `Eq`.
///
/// Os yw eitem `const` yn cynnwys rhyw fath nad yw'n gweithredu trait hwn, yna y math hwnnw naill ai (1.) nid yw'n gweithredu `PartialEq` (sy'n golygu y gyson na fydd darparu'r dull cymharu, a oedd yn cynhyrchu cod yn cymryd yn ganiataol ar gael), neu (2.) ei offer *ei ben ei hun* fersiwn `PartialEq` (yr ydym yn tybio nad yw'n cydymffurfio â cymhariaeth strwythurol-cydraddoldeb).
///
///
/// Yn y naill o'r ddau senario uchod, rydym yn gwrthod y defnydd o cyson o'r fath mewn gêm patrwm.
///
/// Gweler hefyd y [structural match RFC][RFC1445], ac [issue 63438] sy'n mudo llawn cymhelliant o ddylunio seiliedig priodoledd-i trait hwn.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait gofynnol ar gyfer cysonion a ddefnyddir mewn matsys patrwm.
///
/// Mae unrhyw fath sy'n deillio o `Eq` yn gweithredu'r trait hwn yn awtomatig, * ni waeth a yw ei baramedrau math yn gweithredu `Eq`.
///
/// Mae hwn yn darnia i weithio o amgylch cyfyngiad yn ein system math.
///
/// # Background
///
/// Rydym am ei gwneud yn ofynnol bod y mathau o consts a ddefnyddir mewn gemau patrwm yn cael y priodoledd `#[derive(PartialEq, Eq)]`.
///
/// Mewn byd delfrydol mwy, gallem wirio gofyniad hwnnw at jyst yn gwirio bod yr offer fath penodol y `StructuralPartialEq` trait *a* y `Eq` trait.
/// Fodd bynnag, gallwch gael ADTs bod *yn*`derive(PartialEq, Eq)`, a bod yn achos ein bod am i'r compiler i dderbyn, ac eto math y cyson yn methu â gweithredu `Eq`.
///
/// Sef, achos fel hyn:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Y broblem yn y cod uchod yw nad `Wrap<fn(&())>` yn gweithredu `PartialEq`, nac `Eq`, oherwydd `am < 'a> fn(&'a _)` does not implement those traits.)
///
/// Felly, ni allwn ddibynnu ar wiriad naïf am `StructuralPartialEq` a dim ond `Eq`.
///
/// Fel darnia i'r gwaith o gwmpas hyn, rydym yn defnyddio dau traits wahân chwistrellu gan bob un o'r ddau yn deillio (`#[derive(PartialEq)]` a `#[derive(Eq)]`) a gwirio bod y ddau ohonynt yn bresennol fel rhan o gwirio strwythurol-gêm.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Mathau eu gwerthoedd y gellir eu dyblygu yn syml drwy gopïo darnau.
///
/// Yn ddiofyn, rwymiadau amrywiol wedi 'semanteg symud.'Mewn geiriau eraill:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` wedi symud i mewn i `y`, ac felly ni ellir ei ddefnyddio
///
/// // println ("{: ?}", x)!;//Gwall: defnydd o werth eu cyffroi
/// ```
///
/// Fodd bynnag, os y math o offer `Copy`, yn lle mae 'copïo semanteg':
///
/// ```
/// // Gallwn ddeillio gweithrediad `Copy`.
/// // `Clone` mae hefyd yn ofynnol, gan ei fod yn supertrait o `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` mae copi o `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Mae'n bwysig nodi mai'r unig wahaniaeth yn y ddwy enghraifft hyn yw a ydych chi'n cael mynediad i `x` ar ôl yr aseiniad.
/// O dan y cwfl, gall y ddau gopi a symud yn arwain at ddarnau cael ei gopïo mewn cof, er bod hyn yn cael ei optimeiddio ar ffwrdd weithiau.
///
/// ## Sut y gallaf weithredu `Copy`?
///
/// Mae dwy ffordd i weithredu `Copy` ar eich math chi.Y symlaf yw defnyddio `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Gallwch hefyd yn gweithredu `Copy` a `Clone` llaw:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Mae gwahaniaeth bychan rhwng y ddau: y strategaeth `derive`, bydd hefyd yn rhoi `Copy` rhwymo ar baramedrau math, nad yw'n cael ei ddymunir bob amser.
///
/// ## Beth yw'r gwahaniaeth rhwng `Copy` a `Clone`?
///
/// Mae copïau'n digwydd yn ymhlyg, er enghraifft fel rhan o aseiniad `y = x`.Nid oes modd gorlwytho ymddygiad `Copy`;mae bob amser yn gopi syml bit-ddoeth.
///
/// Mae clonio yn weithred benodol, `x.clone()`.Gall gweithredu [`Clone`] ddarparu unrhyw ymddygiad math-benodol sy'n angenrheidiol i ddyblygu gwerthoedd yn ddiogel.
/// Er enghraifft, mae angen i'r o [`Clone`] gweithredu ar gyfer [`String`] i copi y-i pigfain llinyn byffer yn y domen.
/// Byddai copi bitwise syml o werthoedd [`String`] yn unig copi y pwyntydd, gan arwain at ddim ddwbl i lawr y lein.
/// Am y rheswm hwn, [`String`] yw [`Clone`] ond nid `Copy`.
///
/// [`Clone`] yn oruchafiaeth o `Copy`, felly mae'n rhaid i bopeth sy'n `Copy` weithredu [`Clone`] hefyd.
/// Os fath yn yna dim ond angen `Copy` ei weithredu [`Clone`] i ddychwelyd `*self` (gweler yr enghraifft uchod).
///
/// ## Pryd all fy math i fod yn `Copy`?
///
/// Gall math weithredu `Copy` os yw ei holl gydrannau'n gweithredu `Copy`.Er enghraifft, gall hyn fod yn struct `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Gall struct fod `Copy`, a [`i32`] yn `Copy`, felly `Point` yn gymwys i fod `Copy`.
/// Mewn cyferbyniad, ystyriwch
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Ni all y struct `PointList` gweithredu `Copy`, gan nad yw [`Vec<T>`] `Copy`.Os byddwn yn ceisio ddeillio gweithrediad `Copy`, byddwn yn cael gwall:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Mae cyfeiriadau a rennir (`&T`) hefyd yn `Copy`, felly gall math fod yn `Copy`, hyd yn oed pan fydd ganddo gyfeiriadau a rennir o fathau `T` nad ydynt *yn*`Copy`.
/// Ystyriwch y canlynol struct, sy'n gallu gweithredu `Copy`, gan ei fod ond yn dal *rennir cyfeirio* at ein math nad ydynt yn `Copy` `PointList` i'r uchod:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Pan na all * fy math i fod yn `Copy`?
///
/// Ni all rhai mathau eu copïo ddiogel.Er enghraifft, byddai copïo `&mut T` yn creu cyfeirnod symudol arall.
/// Copïo Byddai [`String`] dyblygu gyfrifol am reoli'r [`String`] byffer 's, gan arwain at ddim dwbl.
///
/// Gan gyffredinoli'r achos olaf hwn, ni all unrhyw fath sy'n gweithredu [`Drop`] fod yn `Copy`, oherwydd mae'n rheoli rhywfaint o adnodd ar wahân i'w beit [`size_of::<T>`] ei hun.
///
/// Os ydych yn ceisio gweithredu `Copy` ar struct neu enum cynnwys data nad ydynt yn `Copy`, byddwch yn cael y gwall [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Pan * * Dylai fy math yn `Copy`?
///
/// A siarad yn gyffredinol, os yw eich math _can_ gweithredu `Copy`, y dylai.
/// Fodd bynnag, cofiwch fod gweithredu `Copy` yn rhan o'r API cyhoeddus o'ch math chi.
/// Os gallai'r math yn ddi-`Copy` yn y future, gallai fod yn ddoeth i hepgor gweithredu `Copy` yn awr, er mwyn osgoi newid API torri.
///
/// ## implementors ychwanegol
///
/// Yn ychwanegol at y [implementors listed below][impls], y mathau canlynol hefyd yn gweithredu `Copy`:
///
/// * Mathau o eitemau swyddogaeth (hy, y mathau penodol a ddiffinnir ar gyfer pob swyddogaeth)
/// * Mathau pwyntydd swyddogaeth (ee, `fn() -> i32`)
/// * mathau Array, i bob maint, os yw'r math o eitem hefyd yn gweithredu `Copy` (ee, `[i32; 123456]`)
/// * mathau tuple, os pob cydran hefyd yn gweithredu `Copy` (ee, `()`, `(i32, bool)`)
/// * Mathau cau, os nad ydyn nhw'n cipio unrhyw werth o'r amgylchedd neu os yw'r holl werthoedd sydd wedi'u dal yn gweithredu `Copy` eu hunain.
///   Sylwch fod newidynnau sy'n cael eu dal trwy gyfeirnod a rennir bob amser yn gweithredu `Copy` (hyd yn oed os nad yw'r canolwr yn gwneud hynny), tra bod newidynnau sy'n cael eu dal trwy gyfeirnod symudol byth yn gweithredu `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Mae hyn yn caniatáu copïo yn fath nad yw'n gweithredu `Copy` oherwydd terfynau oes anfodlon (copïo `A<'_>` pan mai dim ond `A<'static>: Copy` a `A<'_>: Clone`).
// Rydym wedi priodoledd hwn yma am awr yn unig oherwydd mae cryn dipyn o arbenigedd sydd eisoes yn bodoli ar `Copy` sydd eisoes yn bodoli yn y llyfrgell safonol, a does dim ffordd i ddiogel ag ymddygiad hwn ar hyn o bryd.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Deillio macro sy'n cynhyrchu impl o'r trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Mathau y mae'n ddiogel i rannu cyfeiriadau rhwng edafedd.
///
/// Mae'r trait cael ei weithredu yn awtomatig pan fydd y compiler yn penderfynu ei fod yn briodol.
///
/// Mae'r diffiniad manwl yw: a `T` fath yn [`Sync`] os a dim ond os yw `&T` [`Send`].
/// Mewn geiriau eraill, os nad oes unrhyw bosibilrwydd o [undefined behavior][ub] (gan gynnwys rasys data) wrth basio cyfeiriadau `&T` rhwng edafedd.
///
/// Yn ôl y disgwyl, mathau cyntefig fel [`u8`] a [`f64`] i gyd [`Sync`], ac felly yn fathau agregau syml sy'n eu cynnwys, fel tuples, structs a enums.
/// Mwy o enghreifftiau o fath sylfaenol [`Sync`] yn cynnwys mathau "immutable" fel `&T`, a'r rhai sydd â syml etifeddwyd mutability, megis [`Box<T>`][box], [`Vec<T>`][vec] a rhan fwyaf o fathau casglu eraill.
///
/// (Mae angen i baramedrau Generig fod [`Sync`] am eu cynhwysydd fod [`Sync`].)
///
/// Canlyniad syndod braidd y diffiniad yw bod `&mut T` yn `Sync` (os `T` yn `Sync`) er ei fod yn ymddangos fel y gallai fod yn darparu treiglad unsynchronized.
/// Y gamp yw bod cyfeiriad symudol y tu ôl i gyfeirnod a rennir (hynny yw, `& &mut T`) yn dod yn ddarllenadwy yn unig, fel petai'n `& &T`.
/// Felly nid oes unrhyw berygl o ras data.
///
/// Y mathau nad ydynt yn `Sync` yw'r rhai sydd â "interior mutability" ar ffurf nad yw'n ddiogel o ran edau, fel [`Cell`][cell] a [`RefCell`][refcell].
/// Mae'r mathau hyn yn caniatáu ar gyfer treiglo o'u cynnwys, hyd yn oed trwy, cyfeirio ddigyfnewid a rennir.
/// Er enghraifft, y dull `set` ar [`Cell<T>`][cell] yn cymryd `&self`, felly mae'n gofyn dim ond rhannu geirda [`&Cell<T>`][cell].
/// Mae'r perfformio dull dim synchronization, felly ni all fod yn [`Cell`][cell] `Sync`.
///
/// Enghraifft arall o fath nad yw'n `Sync` yw'r cyfeiriad-gyfrif pwyntydd [`Rc`][rc].
/// O ystyried unrhyw gyfeirnod [`&Rc<T>`][rc], gallwch glonio [`Rc<T>`][rc] newydd, gan addasu'r cyfrif cyfeirnod mewn ffordd nad yw'n atomig.
///
/// Ar gyfer achosion pan fydd angen mutability mewnol diogel ar edau, mae Rust yn darparu [atomic data types], yn ogystal â chloi penodol trwy [`sync::Mutex`][mutex] a [`sync::RwLock`][rwlock].
/// Mae'r mathau hyn yn sicrhau na all unrhyw dreiglad achosi rasys data, felly'r mathau yw `Sync`.
/// Yn yr un modd, [`sync::Arc`][arc] yn darparu analog edau-diogel [`Rc`][rc].
///
/// Rhaid i unrhyw fath gyda mutability tu hefyd yn defnyddio'r papur lapio o amgylch y [`cell::UnsafeCell`][unsafecell] value(s) y gellir eu treiglo trwy gyfeirio rennir.
/// Methu â gwneud hyn yw [undefined behavior][ub].
/// Er enghraifft, mae [`transmute`][transmute]-ing o `&T` i `&mut T` yn annilys.
///
/// Gweler [the Nomicon][nomicon-send-and-sync] i gael mwy o fanylion am `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): unwaith y bydd cefnogaeth i ychwanegu nodiadau yn `rustc_on_unimplemented` yn glanio mewn beta, ac wedi'i ymestyn i wirio a yw cau unrhyw le yn y gadwyn ofynion, ei ymestyn fel y cyfryw (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Math o faint sero a ddefnyddir i farcio pethau y mae "act like" yn berchen arnynt `T`.
///
/// Ychwanegu cae `PhantomData<T>` i'ch math yn dweud wrth y compiler bod eich math yn gweithredu fel er ei storio werth o fath `T`, er nad yw'n gwneud mewn gwirionedd.
/// Defnyddir y wybodaeth hon wrth cyfrifiadura eiddo diogelwch penodol.
///
/// Am esboniad mwy manwl o sut i ddefnyddio `PhantomData<T>`, gweler [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Mae nodyn ofnadwy 👻👻👻
///
/// Er eu bod yn enwau brawychus, `PhantomData` a 'mathau ffug' yn gysylltiedig, ond nid yn union yr un fath.Mae paramedr Math rhith yn unig yw baramedr fath sydd byth yn cael ei ddefnyddio.
/// Yn Rust, mae hyn yn aml yn achosi i'r compiler i gwyno, ac mae'r ateb yn ychwanegu ddefnydd "dummy" trwy `PhantomData`.
///
/// # Examples
///
/// ## paramedrau oes heb ei ddefnyddio
///
/// Efallai mai'r mwyaf achos defnydd cyffredin i `PhantomData` yn struct sydd â paramedr oes heb ei ddefnyddio, fel arfer fel rhan o rai cod anniogel.
/// Er enghraifft, dyma struct `Slice` sydd wedi dau awgrymiadau o'r math `*const T`, yn ôl pob tebyg bwyntio i mewn i rywle arae:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Y bwriad yw bod y data sylfaenol yn ddilys am oes `'a`, felly dylai `Slice` `'a` Nid yw byw'n hwy.
/// Fodd bynnag, nid yw bwriad hwn yn cael ei fynegi yn y cod, gan nad oes unrhyw ddefnydd o'r oes `'a` ac felly nid yw'n glir pa ddata y mae'n berthnasol i.
/// Gallwn gywiro hyn trwy ddweud wrth y compiler i weithredu *fel pe* y struct `Slice` cynnwys cyfeiriad `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Mae hyn hefyd yn ei dro yn gofyn am anodiad `T: 'a`, gan nodi bod unrhyw gyfeiriadau yn `T` yn ddilys dros oes `'a`.
///
/// Wrth ymgychwyn yn `Slice` i chi yn syml rhoi'r `PhantomData` gwerth ar gyfer y maes `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Paramedrau math nas defnyddiwyd
///
/// Mae'n digwydd weithiau bod gennych paramedrau fath heb eu defnyddio sy'n dangos pa fath o ddata a struct yw "tied" i, hyd yn oed er nad yw data yn dod o hyd mewn gwirionedd yn y struct ei hun.
/// Dyma enghraifft lle mae hyn yn codi gyda [FFI].
/// Mae'r defnyddiau rhyngwyneb tramor dolenni o'r math `*mut ()` i gyfeirio at werthoedd Rust o wahanol fathau.
/// Rydym yn olrhain y math Rust ddefnyddio paramedr fath rhith ar y struct `ExternalResource` sy'n wraps handlen.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Perchnogaeth a siec gollwng
///
/// Ychwanegu cae o'r math `PhantomData<T>` yn dangos bod eich math berchen data o'r math `T`.Mae hyn yn ei dro yn awgrymu bod pan fydd eich math yn cael ei ollwng, gall alw heibio un neu ragor o achosion o'r math `T`.
/// Mae hyn yn effeithio ar ddadansoddiad [drop check] y casglwr Rust.
///
/// Os nad yw'ch strwythur mewn gwirionedd yn *berchen* ar ddata math `T`, mae'n well defnyddio math cyfeirio, fel `PhantomData<&'a T>` (ideally) neu `PhantomData<*const T>` (os nad oes oes yn berthnasol), er mwyn peidio â nodi perchnogaeth.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-mewnol trait defnyddio i ddangos y math o gwahanolion enum.
///
/// Mae'r trait hwn yn cael ei weithredu'n awtomatig ar gyfer pob math ac nid yw'n ychwanegu unrhyw warantau at [`mem::Discriminant`].
/// Mae'n Ymddygiad undefined ** ** i transmute rhwng `DiscriminantKind::Discriminant` a `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Y math o Gwahanolyn, y mae'n rhaid iddo fodloni'r trait bounds ofynnol gan `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-mewnol trait a ddefnyddir i benderfynu a yw cynnwys unrhyw fath `UnsafeCell` yn fewnol, ond nid drwy indirection.
///
/// Mae hyn yn effeithio, er enghraifft, a yw `static` o'r math sy'n cael ei roi yn darllen yn unig cof statig neu cof sefydlog ysgrifenadwy.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Mathau gellir eu symud yn ddiogel ar ôl cael pinned.
///
/// Mae gan Rust ei hun dim syniad o fathau na ellir ei symud, ac yn ystyried symud (ee, drwy aseiniad neu [`mem::replace`]) i fod yn ddiogel bob amser.
///
/// Defnyddir y math [`Pin`][Pin] yn lle hynny i atal symud drwy'r system math.Ni ellir symud allan awgrymiadau `P<T>` sydd wedi'u lapio yn y deunydd lapio [`Pin<P<T>>`][Pin].
/// Gweler dogfennaeth [`pin` module] i gael mwy o wybodaeth am binio.
///
/// Gweithredu'r trait `Unpin` i `T` yn codi'r cyfyngiadau o binio oddi ar y math, sydd wedyn yn caniatáu symud `T` allan o [`Pin<P<T>>`][Pin] gyda swyddogaethau fel [`mem::replace`].
///
///
/// `Unpin` Mae gan unrhyw bwys o gwbl ar gyfer data heb ei pinned.
/// Yn benodol, mae [`mem::replace`] yn symud data `!Unpin` yn hapus (mae'n gweithio i unrhyw `&mut T`, nid dim ond pan `T: Unpin`).
/// Fodd bynnag, ni allwch ddefnyddio [`mem::replace`] ar ddata lapio y tu mewn i [`Pin<P<T>>`][Pin] oherwydd na allwch gael y `&mut T` hangen arnoch ar gyfer hynny, a *bod* yn yr hyn sy'n gwneud y system hon weithio.
///
/// Felly, mae hyn, er enghraifft, dim ond yn cael ei wneud ar fathau gweithredu `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Mae angen cyfeirnod symudol arnom i ffonio `mem::replace`.
/// // Gallwn gael cyfeiriad o'r fath trwy (implicitly) yn galw `Pin::deref_mut`, ond mae hynny'n bosibl dim ond oherwydd bod `String` yn gweithredu `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Mae'r trait cael ei weithredu yn awtomatig ar gyfer bron pob math.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Mae math marciwr nad yw'n gweithredu `Unpin`.
///
/// Os fath yn cynnwys `PhantomPinned`, ni fydd yn gweithredu `Unpin` yn ddiofyn.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Gweithrediadau o `Copy` gyfer mathau cyntefig.
///
/// Gweithredir gweithrediadau na ellir eu disgrifio yn Rust yn `traits::SelectionContext::copy_clone_conditions()` yn `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Gall cyfeiriadau Rhannu ei gopïo, ond mae cyfeiriadau mutable *ni all*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}