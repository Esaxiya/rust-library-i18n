//! Cefnogaeth Panic yn y llyfrgell safonol.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Strwythur sy'n darparu gwybodaeth am panic.
///
/// `PanicInfo` mae'r strwythur yn cael ei basio i panic hook wedi'i osod gan y swyddogaeth [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Yn dychwelyd y llwyth tâl sy'n gysylltiedig â'r panic.
    ///
    /// Yn gyffredin, ond nid bob amser, bydd hwn yn `&'static str` neu [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Os defnyddiwyd y macro `panic!` o'r `core` crate (nid o `std`) gyda llinyn fformatio a rhai dadleuon ychwanegol, mae'n dychwelyd y neges honno'n barod i'w defnyddio er enghraifft gyda [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Yn dychwelyd gwybodaeth am y lleoliad y tarddodd y panic ohono, os yw ar gael.
    ///
    /// Ar hyn o bryd bydd y dull hwn bob amser yn dychwelyd [`Some`], ond gall hyn newid yn fersiynau future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Os yw hyn yn cael ei newid i ddychwelyd Dim weithiau,
        // delio â'r achos hwnnw yn std::panicking::default_hook a std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ni allwn ddefnyddio downcast_ref: :<String>() yma
        // gan nad yw Llinyn ar gael yn libcore!
        // Llinyn yw'r llwyth tâl pan elwir `std::panic!` gyda sawl dadl, ond yn yr achos hwnnw mae'r neges ar gael hefyd.
        //

        self.location.fmt(formatter)
    }
}

/// Strwythur sy'n cynnwys gwybodaeth am leoliad panic.
///
/// Mae'r strwythur hwn yn cael ei greu gan [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Gwneir cymariaethau ar gyfer cydraddoldeb ac archebu mewn ffeil, llinell, ac yna blaenoriaeth colofn.
/// Mae ffeiliau'n cael eu cymharu fel tannau, nid `Path`, a allai fod yn annisgwyl.
/// Gweler dogfennaeth [`Lleoliad: : ffeil`] i gael mwy o drafodaeth.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Yn dychwelyd lleoliad ffynhonnell galwr y swyddogaeth hon.
    /// Os yw galwr y swyddogaeth honno wedi'i hanodi yna bydd lleoliad ei alwad yn cael ei ddychwelyd, ac yn y blaen i fyny'r pentwr i'r alwad gyntaf o fewn corff swyddogaeth heb ei dracio.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Yn dychwelyd yr [`Location`] y mae'n cael ei alw arno.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Yn dychwelyd [`Location`] o fewn diffiniad y swyddogaeth hon.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // mae rhedeg yr un swyddogaeth heb ei gloi mewn lleoliad gwahanol yn rhoi'r un canlyniad i ni
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // mae rhedeg y swyddogaeth wedi'i olrhain mewn lleoliad gwahanol yn cynhyrchu gwerth gwahanol
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Yn dychwelyd enw'r ffeil ffynhonnell y tarddodd y panic ohoni.
    ///
    /// # `&str`, nid `&Path`
    ///
    /// Mae'r enw a ddychwelwyd yn cyfeirio at lwybr ffynhonnell ar y system grynhoi, ond nid yw'n ddilys cynrychioli hyn yn uniongyrchol fel `&Path`.
    /// Efallai y bydd y cod a luniwyd yn rhedeg ar system wahanol gyda gweithrediad `Path` gwahanol i'r system sy'n darparu'r cynnwys ac ar hyn o bryd nid oes gan y llyfrgell hon fath "host path" gwahanol.
    ///
    /// Mae'r ymddygiad mwyaf syndod yn digwydd pan fydd modd cyrchu ffeil "the same" trwy sawl llwybr yn y system fodiwl (gan ddefnyddio'r priodoledd `#[path = "..."]` neu debyg fel rheol), a all beri i'r hyn sy'n ymddangos yn god union yr un fath ddychwelyd gwahanol werthoedd o'r swyddogaeth hon.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Nid yw'r gwerth hwn yn addas i'w basio i `Path::new` neu adeiladwyr tebyg pan fydd y platfform gwesteiwr a'r platfform targed yn wahanol.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Yn dychwelyd y rhif llinell y tarddodd y panic ohono.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Yn dychwelyd y golofn y tarddodd y panic ohoni.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait mewnol a ddefnyddir gan libstd i basio data o libstd i `panic_unwind` ac amseroedd rhedeg panic eraill.
/// Ni fwriedir iddo gael ei sefydlogi unrhyw amser yn fuan, peidiwch â defnyddio.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Cymerwch berchnogaeth lawn o'r cynnwys.
    /// Y math dychwelyd yw `Box<dyn Any + Send>` mewn gwirionedd, ond ni allwn ddefnyddio `Box` yn libcore.
    ///
    /// Ar ôl i'r dull hwn gael ei alw, dim ond rhywfaint o werth diofyn ffug sydd ar ôl yn `self`.
    /// Mae galw'r dull hwn ddwywaith, neu ffonio `get` ar ôl galw'r dull hwn, yn wall.
    ///
    /// Benthycir y ddadl oherwydd bod amser rhedeg panic (`__rust_start_panic`) yn cael `dyn BoxMeUp` wedi'i fenthyg yn unig.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Dim ond benthyg y cynnwys.
    fn get(&mut self) -> &(dyn Any + Send);
}