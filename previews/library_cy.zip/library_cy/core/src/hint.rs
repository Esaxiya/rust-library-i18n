#![stable(feature = "core_hint", since = "1.27.0")]

//! Awgrymiadau i compiler sy'n effeithio ar sut y dylai gael ei cod ei allyrru neu optimized.
//! Efallai Awgrymiadau fod amser crynhoi neu'n Rhedeg.

use crate::intrinsics;

/// Yn hysbysu'r compiler nad y pwynt hwn yn y cod yn gyraeddadwy, gan alluogi optimizations pellach.
///
/// # Safety
///
/// Cyrraedd y swyddogaeth hon yn gwbl *ymddygiad anniffiniedig*(UB).Yn benodol, mae'r compiler yn tybio bod rhaid i bob UB byth yn digwydd, ac felly bydd yn dileu pob ganghennau sy'n cyrraedd i alwad i `unreachable_unchecked()`.
///
/// Fel pob achos o UB, os y rhagdybiaeth hon yn troi allan i fod yn anghywir, hy, yr alwad `unreachable_unchecked()` mewn gwirionedd gyraeddadwy ymhlith yr holl llif rheoli bosibl, bydd y casglwr yn berthnasol i'r strategaeth optimization anghywir, a gall weithiau hyd yn oed llygredig cod sy'n ymddangos nad ydynt yn perthyn, gan achosi difficult-problemau i-debug.
///
///
/// Defnyddiwch swyddogaeth hon dim ond pan fyddwch yn gallu profi y bydd y cod byth yn ei alw.
/// Fel arall, ystyried defnyddio macro [`unreachable!`], nad yw'n caniatáu optimeiddiad ond bydd panic pan ddienyddio.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` bob amser yn gadarnhaol (nid sero), felly ni fydd `checked_div` byth yn dychwelyd `None`.
/////
///     // Felly, mae'r arall branch yn anghyraeddadwy.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // DIOGELWCH: rhaid i'r contract diogelwch ar gyfer `intrinsics::unreachable`
    // cael ei gadarnhau gan y galwr.
    unsafe { intrinsics::unreachable() }
}

/// Allyrru cyfarwyddyd peiriant i ddangos y prosesydd fod yn cael ei rhedeg mewn prysur-aros spin-ddolen ("clo sbin").
///
/// Ar ôl derbyn y signal spin-dolen y prosesydd yn gallu gwneud y gorau ei ymddygiad drwy, er enghraifft, pŵer arbed neu newid hyper-edafedd.
///
/// Mae'r swyddogaeth hon yn wahanol i [`thread::yield_now`] sy'n ildio yn uniongyrchol i'r scheduler y system, ond nid `spin_loop` yn rhyngweithio gyda'r system weithredu.
///
/// Mae achos defnydd cyffredin ar gyfer `spin_loop` yn gweithredu nyddu optimistaidd wedi'i ffinio mewn dolen CAS mewn pethau cychwynnol cydamseru.
/// I broblemau osgoi fel gwrthdroad blaenoriaeth, argymhellir yn gryf bod y ddolen sbin ei derfynu ar ôl swm cyfyngedig o iteriadau a syscall blocio priodol yn cael ei wneud.
///
///
/// **Sylwer**: Ar lwyfannau nad ydynt yn cefnogi derbyn awgrymiadau spin-dolen Nid yw swyddogaeth hon yn gwneud unrhyw beth o gwbl.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Gwerth atomig a rennir y bydd edafedd yn ei ddefnyddio i gydlynu
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Mewn edefyn cefndir byddwn yn gosod y gwerth yn y pen draw
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Gwnewch ychydig o waith, yna gwnewch y gwerth yn fyw
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Yn ôl ar ein edau presennol, rydym yn aros am y gwerth i fod yn set
/// while !live.load(Ordering::Acquire) {
///     // Mae'r ddolen sbin yn awgrym i'r CPU ein bod yn aros, ond yn ôl pob tebyg nid ar gyfer hir iawn
/////
///     hint::spin_loop();
/// }
///
/// // Mae gwerth ei osod yn awr
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // DIOGELWCH: y attr Yn sicrhau bod `cfg` ein bod ond yn gweithredu hyn ar dargedau x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // DIOGELWCH: mae'r atwr `cfg` yn sicrhau mai dim ond ar dargedau x86_64 yr ydym yn gweithredu hyn.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // DIOGELWCH: y attr Yn sicrhau bod `cfg` ein bod ond yn gweithredu hyn ar dargedau aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // DIOGELWCH: y attr Yn sicrhau bod `cfg` ein bod ond yn gweithredu hyn ar dargedau fraich
            // gyda chefnogaeth ar gyfer y nodwedd v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Swyddogaeth adnabod sy'n *__ awgrymu __* i'r casglwr i fod yn besimistaidd i'r eithaf am yr hyn y gallai `black_box` ei wneud.
///
/// Yn wahanol i [`std::convert::identity`], casglwr Rust ei annog i gymryd yn ganiataol y gall `black_box` ddefnyddio `dummy` mewn unrhyw ffordd ddilys bosibl y Rust cod yn cael ei ganiatáu i heb gyflwyno ymddygiad anniffiniedig yn y cod galw.
///
/// eiddo hyn yn gwneud `black_box` yn ddefnyddiol ar gyfer cod lle nad yw rhai optimeiddiad yn ddymunol, fel meincnodau ysgrifennu.
///
/// Noder, fodd bynnag, mai dim ond `black_box` (a dim ond yn cael ei) ddarparu ar sail "best-effort".Gall y graddau y gall rwystro optimistiaid amrywio yn dibynnu ar y backend platfform a chod-gen a ddefnyddir.
/// Ni all rhaglenni ddibynnu ar `black_box` am gywirdeb * * mewn unrhyw ffordd.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Mae angen i ni "use" y ddadl mewn rhyw ffordd LLVM all INTROSPECT, ac ar dargedau sy'n ei gefnogi, gallwn fel arfer yn trosoledd inline cynulliad i wneud hyn.
    // Dehongliad LLVM o gynulliad mewnol yw ei fod, wel, yn flwch du.
    // Nid yw hyn yn gweithredu mwyaf gan ei fod fwy na thebyg deoptimizes fwy nag yr ydym ei eisiau, ond mae'n hyd yn hyn yn ddigon da.
    //
    //

    #[cfg(not(miri))] // Mae hyn yn unig awgrym, felly mae'n iawn i sgip yn Miri.
    // DIOGELWCH: mae'r inline cynulliad yn dim-op.
    unsafe {
        // FIXME: Methu defnyddio `asm!` oherwydd nad yw'n cefnogi MIPS a saernïaeth eraill.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}