//! intrinsics compiler.
//!
//! Mae'r diffiniadau cyfatebol yn `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Mae'r gweithrediadau Etholaeth cyfatebol yn `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intricsics
//!
//! Note: Dylai unrhyw newidiadau i constness o intrinsics yn cael eu trafod gyda'r tîm iaith.
//! Mae hyn yn cynnwys newidiadau yn y sefydlogrwydd y constness.
//!
//! Er mwyn gwneud y gellir ei ddefnyddio cynhenid ar crynhoi amser, anghenion un gopïo'r o <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> gweithredu i `compiler/rustc_mir/src/interpret/intrinsics.rs` ac ychwanegu `#[rustc_const_unstable(feature = "foo", issue = "01234")]` i'r cynhenid.
//!
//!
//! Os bydd cynhenid i fod i gael ei ddefnyddio gan `const fn` gyda priodoledd `rustc_const_stable`, rhaid priodoledd y cynhenid fydd `rustc_const_stable`, hefyd.
//! Ni ddylid gwneud newid o'r fath heb ymgynghoriad T-lang, oherwydd ei fod yn tynnu nodwedd i'r iaith na ellir ei hefelychu mewn cod defnyddiwr heb gefnogaeth crynhowr.
//!
//! # Volatiles
//!
//! Mae'r intrinsics anweddol yn darparu Bwriedir gweithrediadau i weithredu ar gof I/O, sydd yn sicr o beidio cael eu had-drefnu gan y casglwr draws intrinsics anweddol eraill.Gweler y ddogfennaeth LLVM ar [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Mae'r intrinsics atomig yn darparu gweithrediadau atomig cyffredin ar eiriau beiriant, gyda orderings cof lluosog posibl.Maent yn ufuddhau i'r un semanteg â C++ 11.Gweler y dogfennau LLVM ar [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Mae gloywi cyflym ar archebu cof:
//!
//! * Caffael, yn rhwystr ar gyfer caffael clo.Yn dilyn darllen ac ysgrifennu yn cael eu cynnal ar ôl y rhwystr.
//! * Rhyddhau, rhwystr rhag rhyddhau clo.Mae rhagflaenu darllen ac ysgrifennu yn digwydd cyn y rhwystr.
//! * gweithrediadau ddilyniannol gyson, ddilyniannol gyson yn sicr o ddigwydd mewn trefn.Mae hyn yn y dull safonol ar gyfer gweithio gyda mathau atomig ac mae'n cyfateb i `volatile` Java yn.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Defnyddir y mewnforion hyn i symleiddio cysylltiadau o fewn doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // DIOGELWCH: gweler `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // DS, intrinsics hyn yn cymryd awgrymiadau crai oherwydd eu bod yn treiglo'n cof aliased, nad yw'n ddilys ar gyfer naill ai `&` neu `&mut`.
    //

    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` drwy basio [`Ordering::SeqCst`] gan fod y ddau y `success` a `failure` paramedrau.
    ///
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` drwy basio [`Ordering::Acquire`] gan fod y ddau y `success` a `failure` paramedrau.
    ///
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` trwy basio [`Ordering::Release`] fel yr `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` drwy basio [`Ordering::AcqRel`] fel `success` a [`Ordering::Acquire`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` drwy basio [`Ordering::Relaxed`] gan fod y ddau y `success` a `failure` paramedrau.
    ///
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` drwy basio [`Ordering::SeqCst`] fel `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` trwy basio [`Ordering::SeqCst`] fel yr `success` a [`Ordering::Acquire`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` drwy basio [`Ordering::Acquire`] fel `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange` drwy basio [`Ordering::AcqRel`] fel `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` drwy basio [`Ordering::SeqCst`] gan fod y ddau y `success` a `failure` paramedrau.
    ///
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` trwy basio [`Ordering::Acquire`] fel paramedrau `success` a `failure`.
    ///
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` trwy basio [`Ordering::Release`] fel yr `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` drwy basio [`Ordering::AcqRel`] fel `success` a [`Ordering::Acquire`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` trwy basio [`Ordering::Relaxed`] fel paramedrau `success` a `failure`.
    ///
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` drwy basio [`Ordering::SeqCst`] fel `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` drwy basio [`Ordering::SeqCst`] fel `success` a [`Ordering::Acquire`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` trwy basio [`Ordering::Acquire`] fel yr `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Storio gwerth os yw gwerth cyfredol yn yr un fath â'r gwerth `old`.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `compare_exchange_weak` trwy basio [`Ordering::AcqRel`] fel yr `success` a [`Ordering::Relaxed`] fel y paramedrau `failure`.
    /// Er enghraifft, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Yn llwytho gwerth cyfredol y pwyntydd.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `load` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Yn llwytho gwerth cyfredol y pwyntydd.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `load` drwy basio [`Ordering::Acquire`] fel `order`.
    /// Er enghraifft, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Yn llwytho gwerth cyfredol y pwyntydd.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `load` trwy basio [`Ordering::Relaxed`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Storfeydd y gwerth yn y lleoliad cof penodedig.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `store` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Storfeydd y gwerth yn y lleoliad cof penodedig.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `store` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Storfeydd y gwerth yn y lleoliad cof penodedig.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `store` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Yn storio'r gwerth yn y lleoliad cof penodedig, gan ddychwelyd yr hen werth.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `swap` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn storio'r gwerth yn y lleoliad cof penodedig, gan ddychwelyd yr hen werth.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `swap` trwy basio [`Ordering::Acquire`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn storio'r gwerth yn y lleoliad cof penodedig, gan ddychwelyd yr hen werth.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `swap` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn storio'r gwerth yn y lleoliad cof penodedig, gan ddychwelyd yr hen werth.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `swap` trwy basio [`Ordering::AcqRel`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn storio'r gwerth yn y lleoliad cof penodedig, gan ddychwelyd yr hen werth.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `swap` trwy basio [`Ordering::Relaxed`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Yn ychwanegu at y gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_add` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ychwanegu at y gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_add` trwy basio [`Ordering::Acquire`] fel yr `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ychwanegu at y gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_add` trwy basio [`Ordering::Release`] fel yr `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ychwanegu at y gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_add` drwy basio [`Ordering::AcqRel`] fel `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ychwanegu at y gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_add` trwy basio [`Ordering::Relaxed`] fel yr `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tynnwch o'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_sub` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tynnwch o'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_sub` drwy basio [`Ordering::Acquire`] fel `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tynnwch o'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_sub` trwy basio [`Ordering::Release`] fel yr `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tynnwch o'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_sub` drwy basio [`Ordering::AcqRel`] fel `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tynnwch o'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_sub` trwy basio [`Ordering::Relaxed`] fel yr `order`.
    /// Er enghraifft, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Yn ddidrafferth a chyda'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_and` trwy basio [`Ordering::SeqCst`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ddidrafferth a chyda'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_and` trwy basio [`Ordering::Acquire`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ddidrafferth a chyda'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_and` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ddidrafferth a chyda'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_and` trwy basio [`Ordering::AcqRel`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yn ddidrafferth a chyda'r gwerth cyfredol, gan ddychwelyd y gwerth blaenorol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_and` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// NAND bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y math [`AtomicBool`] trwy'r dull `fetch_nand` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y math [`AtomicBool`] trwy'r dull `fetch_nand` drwy basio [`Ordering::Acquire`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y math [`AtomicBool`] trwy'r dull `fetch_nand` trwy basio [`Ordering::Release`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y math [`AtomicBool`] trwy'r dull `fetch_nand` drwy basio [`Ordering::AcqRel`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y math [`AtomicBool`] trwy'r dull `fetch_nand` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise neu gyda'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_or` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise neu gyda'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_or` drwy basio [`Ordering::Acquire`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise neu gyda'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_or` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise neu gyda'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_or` drwy basio [`Ordering::AcqRel`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise neu gyda'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_or` trwy basio [`Ordering::Relaxed`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// XOR bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_xor` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_xor` drwy basio [`Ordering::Acquire`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_xor` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau [`atomic`] trwy'r dull `fetch_xor` trwy basio [`Ordering::AcqRel`] fel yr `order`.
    /// Er enghraifft, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise â'r gwerth cyfredol, gan ddychwelyd y gwerth diwethaf.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y mathau [`atomic`] trwy'r dull `fetch_xor` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_max` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_max` drwy basio [`Ordering::Acquire`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_max` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau cyfanrif wedi'u llofnodi [`atomic`] trwy'r dull `fetch_max` trwy basio [`Ordering::AcqRel`] fel yr `order`.
    /// Er enghraifft, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm y gwerth cyfredol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_max` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_min` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau cyfanrif wedi'u llofnodi [`atomic`] trwy'r dull `fetch_min` trwy basio [`Ordering::Acquire`] fel yr `order`.
    /// Er enghraifft, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_min` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_min` drwy basio [`Ordering::AcqRel`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth wedi'i llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon ar gael ar y [`atomic`] lofnodwyd cyfanrif mathau drwy'r dull `fetch_min` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y [`atomic`] mathau cyfanrif heb ei arwyddo trwy gyfrwng y dull `fetch_min` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau cyfanrif [`atomic`] heb eu llofnodi trwy'r dull `fetch_min` trwy basio [`Ordering::Acquire`] fel yr `order`.
    /// Er enghraifft, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau cyfanrif [`atomic`] heb eu llofnodi trwy'r dull `fetch_min` trwy basio [`Ordering::Release`] fel yr `order`.
    /// Er enghraifft, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y [`atomic`] mathau cyfanrif heb ei arwyddo trwy gyfrwng y dull `fetch_min` drwy basio [`Ordering::AcqRel`] fel `order`.
    /// Er enghraifft, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Isafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y [`atomic`] mathau cyfanrif heb ei arwyddo trwy gyfrwng y dull `fetch_min` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y [`atomic`] mathau cyfanrif heb ei arwyddo trwy gyfrwng y dull `fetch_max` drwy basio [`Ordering::SeqCst`] fel `order`.
    /// Er enghraifft, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael ar y mathau cyfanrif [`atomic`] heb eu llofnodi trwy'r dull `fetch_max` trwy basio [`Ordering::Acquire`] fel yr `order`.
    /// Er enghraifft, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y [`atomic`] mathau cyfanrif heb ei arwyddo trwy gyfrwng y dull `fetch_max` drwy basio [`Ordering::Release`] fel `order`.
    /// Er enghraifft, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y [`atomic`] mathau cyfanrif heb ei arwyddo trwy gyfrwng y dull `fetch_max` drwy basio [`Ordering::AcqRel`] fel `order`.
    /// Er enghraifft, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uchafswm gyda'r gwerth cyfredol gan ddefnyddio cymhariaeth heb ei llofnodi.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael ar y [`atomic`] mathau cyfanrif heb ei arwyddo trwy gyfrwng y dull `fetch_max` drwy basio [`Ordering::Relaxed`] fel `order`.
    /// Er enghraifft, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mae'r cynhenid `prefetch` yn awgrym i'r generadur cod mewnosod cyfarwyddyd prefetch os caiff ei ategu;fel arall, mae'n no-op.
    /// Nid yw rhagddodiad yn cael unrhyw effaith ar ymddygiad y rhaglen ond gallant newid ei nodweddion perfformiad.
    ///
    /// Rhaid i'r ddadl `locality` yn cyfanrif cyson ac mae'n rhagnodwr tymhorol ardal yn amrywio o (0), dim ardal, i (3), yn hynod cadw lleol mewn cache.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Mae'r cynhenid `prefetch` yn awgrym i'r generadur cod mewnosod cyfarwyddyd prefetch os caiff ei ategu;fel arall, mae'n no-op.
    /// Nid yw rhagddodiad yn cael unrhyw effaith ar ymddygiad y rhaglen ond gallant newid ei nodweddion perfformiad.
    ///
    /// Rhaid i'r ddadl `locality` yn cyfanrif cyson ac mae'n rhagnodwr tymhorol ardal yn amrywio o (0), dim ardal, i (3), yn hynod cadw lleol mewn cache.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Mae'r cynhenid `prefetch` yn awgrym i'r generadur cod mewnosod cyfarwyddyd prefetch os caiff ei ategu;fel arall, mae'n no-op.
    /// Nid yw rhagddodiad yn cael unrhyw effaith ar ymddygiad y rhaglen ond gallant newid ei nodweddion perfformiad.
    ///
    /// Rhaid i'r ddadl `locality` yn cyfanrif cyson ac mae'n rhagnodwr tymhorol ardal yn amrywio o (0), dim ardal, i (3), yn hynod cadw lleol mewn cache.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Mae'r cynhenid `prefetch` yn awgrym i'r generadur cod mewnosod cyfarwyddyd prefetch os caiff ei ategu;fel arall, mae'n no-op.
    /// Nid yw rhagddodiad yn cael unrhyw effaith ar ymddygiad y rhaglen ond gallant newid ei nodweddion perfformiad.
    ///
    /// Rhaid i'r ddadl `locality` yn cyfanrif cyson ac mae'n rhagnodwr tymhorol ardal yn amrywio o (0), dim ardal, i (3), yn hynod cadw lleol mewn cache.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ffens atomig.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael yn [`atomic::fence`] drwy basio [`Ordering::SeqCst`] fel `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ffens atomig.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael yn [`atomic::fence`] drwy basio [`Ordering::Acquire`] fel `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ffens atomig.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael yn [`atomic::fence`] trwy basio [`Ordering::Release`] fel yr `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ffens atomig.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael yn [`atomic::fence`] drwy basio [`Ordering::AcqRel`] fel `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Rhwystr cof casglwr yn unig.
    ///
    /// Ni fydd mynediad cof byth yn cael ei aildrefnu ar draws y rhwystr hwn gan y casglwr, ond ni fydd unrhyw gyfarwyddiadau yn cael eu rhyddhau ar ei gyfer.
    /// Mae hyn yn briodol ar gyfer gweithrediadau ar yr un edefyn a allai gael eu preempted, megis wrth ryngweithio â thrinwyr signal.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael yn [`atomic::compiler_fence`] trwy basio [`Ordering::SeqCst`] fel yr `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Rhwystr cof casglwr yn unig.
    ///
    /// Ni fydd mynediad cof byth yn cael ei aildrefnu ar draws y rhwystr hwn gan y casglwr, ond ni fydd unrhyw gyfarwyddiadau yn cael eu rhyddhau ar ei gyfer.
    /// Mae hyn yn briodol ar gyfer gweithrediadau ar yr un edefyn a allai gael eu preempted, megis wrth ryngweithio â thrinwyr signal.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael yn [`atomic::compiler_fence`] drwy basio [`Ordering::Acquire`] fel `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Rhwystr cof casglwr yn unig.
    ///
    /// Ni fydd mynediad cof byth yn cael ei aildrefnu ar draws y rhwystr hwn gan y casglwr, ond ni fydd unrhyw gyfarwyddiadau yn cael eu rhyddhau ar ei gyfer.
    /// Mae hyn yn briodol ar gyfer gweithrediadau ar yr un edefyn a allai gael eu preempted, megis wrth ryngweithio â thrinwyr signal.
    ///
    /// Mae'r fersiwn sefydlog o'r cynhenid hon ar gael yn [`atomic::compiler_fence`] trwy basio [`Ordering::Release`] fel yr `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Rhwystr cof casglwr yn unig.
    ///
    /// Ni fydd mynediad cof byth yn cael ei aildrefnu ar draws y rhwystr hwn gan y casglwr, ond ni fydd unrhyw gyfarwyddiadau yn cael eu rhyddhau ar ei gyfer.
    /// Mae hyn yn briodol ar gyfer gweithrediadau ar yr un edefyn a allai gael eu preempted, megis wrth ryngweithio â thrinwyr signal.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn ar gael yn [`atomic::compiler_fence`] drwy basio [`Ordering::AcqRel`] fel `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// cynhenid Magic sy'n deillio ei ystyr o nodweddion sydd ynghlwm wrth y swyddogaeth.
    ///
    /// Er enghraifft, dataflow defnyddiau hyn i chwistrellu honiadau sefydlog fel bod `rustc_peek(potentially_uninitialized)` byddai mewn gwirionedd yn dwbl-wirio bod dataflow yn wir gyfrifo fod yn cael ei uninitialized ar yr adeg honno yn y llif rheoli.
    ///
    ///
    /// Ni ddylai hyn fod y tu allan cynhenid a ddefnyddir i'r compiler.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts gweithredu i roi'r broses.
    ///
    /// Fersiwn mwy hawdd ei ddefnyddio a sefydlog o'r llawdriniaeth hon yw [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Yn hysbysu'r optimizer nad y pwynt hwn yn y cod yn gyraeddadwy, gan alluogi optimizations pellach.
    ///
    /// NB, mae hyn yn wahanol iawn i'r macro `unreachable!()`: Yn wahanol i'r macro, mae panics pan fydd yn cael ei gyflawni, mae'n *Ymddygiad undefined* i gyrraedd cod marcio â swyddogaeth hon.
    ///
    ///
    /// Y fersiwn sefydlog o'r cynhenid hon yw [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Hysbysu'r optimizer bod amod bob amser yn wir.
    /// Os yw'r cyflwr yn ffug, mae'r ymddygiad yn cael ei diffinio.
    ///
    /// Dim cod yn cael ei gynhyrchu ar gyfer cynhenid hwn, ond bydd y optimizer geisio diogelu ei (a'i gyflwr) rhwng tocynnau, a all ymyrryd â optimeiddio cyfagos cod a lleihau perfformiad.
    /// Ni ddylid ei ddefnyddio os gall y ddigyfnewid eu darganfod gan y optimizer ar ei ben ei hun, neu os nad yw'n alluogi unrhyw optimeiddiad arwyddocaol.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Awgrymiadau i'r casglwr bod cyflwr branch yn debygol o fod yn wir.
    /// Dychwelyd y gwerth a basiwyd ymlaen iddo.
    ///
    /// Mae'n debyg na fydd unrhyw ddefnydd heblaw gyda datganiadau `if` yn cael effaith.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Awgrymiadau i'r casglwr bod cyflwr branch yn debygol o fod yn ffug.
    /// Dychwelyd y gwerth a basiwyd ymlaen iddo.
    ///
    /// Mae'n debyg na fydd unrhyw ddefnydd heblaw gyda datganiadau `if` yn cael effaith.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Yn cyflawni trap torbwynt, i'w archwilio gan ddadfygiwr.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn breakpoint();

    /// Mae maint o fath mewn bytes.
    ///
    /// Yn fwy penodol, mae hyn yn y gwrthbwyso mewn bytes rhwng eitemau olynol o'r un math, gan gynnwys padding aliniad.
    ///
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Yr aliniad lleiaf o fath.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Mae aliniad a ffafrir o fath.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Mae maint y gwerth y cyfeirir atynt yn bytes.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Mae aliniad sy'n ofynnol o werth y cyfeirir.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Gets sleisen llinyn statig cynnwys enw o fath.
    ///
    /// Y fersiwn sefydlog o'r cynhenid hon yw [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Cael dynodwr sy'n unigryw yn fyd-eang i'r math penodedig.
    /// Bydd y swyddogaeth hon yn dychwelyd yr un gwerth ar gyfer math waeth beth pa un bynnag crate mae'n cael ei galw i rym i mewn.
    ///
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Mae gard ar gyfer swyddogaethau anniogel na ellir byth ei weithredu os `T` oes neb yn byw:
    /// Bydd hyn naill ai'n llonydd panic, neu wneud dim.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Mae gard ar gyfer swyddogaethau anniogel na ellir byth ei weithredu os nad `T` yn caniatáu sero-initialization: Bydd hyn naill ai'n llonydd panic, neu wneud dim.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn assert_zero_valid<T>();

    /// Gwarchodwr ar gyfer swyddogaethau anniogel na ellir byth eu cyflawni os oes gan `T` batrymau didau annilys: Bydd hyn yn statudol naill ai panic, neu'n gwneud dim.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn assert_uninit_valid<T>();

    /// Yn cael cyfeiriad at `Location` statig sy'n nodi lle cafodd ei alw.
    ///
    /// Ystyriwch ddefnyddio [`core::panic::Location::caller`](crate::panic::Location::caller) yn lle.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Symud gwerth allan o gwmpas heb redeg glud galw heibio.
    ///
    /// Mae hyn yn bodoli yn unig ar gyfer [`mem::forget_unsized`];mae `forget` arferol yn defnyddio `ManuallyDrop` yn lle.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets y darnau o werth un fath gan fod y math arall.
    ///
    /// Mae'n rhaid i ddau fath gael yr un maint.
    /// Nid oes gan y gwreiddiol, nac ychwaith yn ganlyniad, gall fod yn [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` yn semantig cyfateb i bitwise symud o un math mewn i un arall.Mae'n copïo'r darnau o'r gwerth ffynhonnell i'r gwerth cyrchfan, yna'n anghofio'r gwreiddiol.
    /// Mae'n cyfateb i C `memcpy` o dan y cwfl, yn union fel `transmute_copy`.
    ///
    /// Gan fod `transmute` yn llawdriniaeth drwy-werth, aliniad y gwerthoedd *transmuted eu hunain* Nid yn bryder.
    /// Fel gydag unrhyw swyddogaeth arall, y casglwr eisoes yn sicrhau y ddau `T` a `U` yn cyd-fynd yn briodol.
    /// Fodd bynnag, wrth drawsnewid gwerthoedd sy'n *pwyntio mewn man arall*(megis awgrymiadau, cyfeiriadau, blychau ...), mae'n rhaid i'r galwr sicrhau aliniad cywir o'r gwerthoedd pwyntiedig.
    ///
    /// `transmute` yn ** ** hynod anniogel.Mae yna nifer fawr o ffyrdd i achosi [undefined behavior][ub] gyda'r swyddogaeth hon.Dylai `transmute` fod y dewis olaf absoliwt.
    ///
    /// Mae gan yr [nomicon](../../nomicon/transmutes.html) ddogfennaeth ychwanegol.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Mae yna ychydig o bethau y mae `transmute` yn ddefnyddiol iawn ar eu cyfer.
    ///
    /// Troi pwyntydd yn bwyntydd swyddogaeth.Nid yw hyn yn *gludadwy* i beiriannau lle mae gan awgrymiadau swyddogaeth ac awgrymiadau data wahanol feintiau.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ymestyn oes, neu fyrhau oes ddigyfnewid.Mae hyn yn ddatblygedig, anniogel iawn Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Peidiwch anobaith: Gall sawl defnydd o `transmute` cael ei gyflawni drwy ddulliau eraill.
    /// Isod mae ceisiadau cyffredin o `transmute` y gellir eu disodli gyda lluniadau mwy diogel.
    ///
    /// Gan droi bytes(`&[u8]`) crai i `u32`, `f64`, ac ati .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // defnydd `u32::from_ne_bytes` yn lle hynny
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // neu defnyddiwch `u32::from_le_bytes` neu `u32::from_be_bytes` i nodi'r terfynoldeb
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Troi pwyntydd i mewn i `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Defnyddiwch gast `as` yn lle
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Troi yn `*mut T` i mewn i `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Defnyddiwch reborrow yn lle hynny
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Troi i `&mut T` i mewn i `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Yn awr, rhoi at ei gilydd `as` a reborrowing, yn nodi nad oedd y gadwyno y `as` `as` yn transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Troi i `&str` i mewn i `&[u8]`:
    ///
    /// ```
    /// // nid yw hyn yn ffordd dda o wneud hyn.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Gallech ddefnyddio `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Neu, defnyddiwch linyn beit, os oes gennych reolaeth dros y llinyn llythrennol
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Troi yn `Vec<&T>` mewn i `Vec<Option<&T>>`.
    ///
    /// I transmute math mewnol o gynnwys cynhwysydd, rhaid i chi wneud yn siwr i beidio â torri unrhyw un o invariants y cynhwysydd yn.
    /// Ar gyfer `Vec`, mae hyn yn golygu bod yn rhaid i faint *ac aliniad* y mathau mewnol gyfateb.
    /// Efallai y cynwysyddion eraill yn dibynnu ar faint y math, aliniad, neu hyd yn oed y `TypeId`, lle na fyddai transmuting achos yn bosibl o gwbl heb darfu ar y invariants cynhwysydd.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // glonio y vector gan y byddwn yn eu hailddefnyddio yn nes ymlaen
    /// let v_clone = v_orig.clone();
    ///
    /// // Gan ddefnyddio'r transmute: mae hyn yn dibynnu ar y cynllun data amhenodol o `Vec`, sydd yn syniad gwael a gallai achosi Anniffiniedig Ymddygiad.
    /////
    /// // Fodd bynnag, nid yw'n-gopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Mae hyn yn y awgrymir, ffordd ddiogel.
    /// // Yw'n copïo'r vector cyfan, fodd bynnag, i mewn i amrywiaeth newydd.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dyma'r briodol dim-gopi, ffordd anniogel o "transmuting" a `Vec`, heb ddibynnu ar y cynllun data.
    /// // Yn hytrach na llythrennol galw `transmute`, rydym yn perfformio cast pwyntydd, ond o ran trosi'r math mewnol gwreiddiol (`&i32`) i'r un (`Option<&i32>`) newydd, mae gan hyn i gyd yr un cafeatau.
    /////
    /// // Heblaw am y wybodaeth a ddarperir uchod, hefyd yn ymgynghori â'r ddogfennaeth [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Diweddarwch hyn pan fydd vec_into_raw_parts wedi'i sefydlogi.
    ///     // Sicrhewch nad yw'r vector gwreiddiol yn cael ei ollwng.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Gweithredu `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Mae nifer o ffyrdd i wneud hyn, ac mae problemau lluosog gyda'r (transmute) ffordd ganlynol.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // yn gyntaf: Nid yw transmute yn teipio diogel;holl wiriadau yw hi y T a
    ///         // U o'r un maint.
    ///         // Yn ail, dde yma, mae gennych ddau eirda mutable pwyntio at yr un cof.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Mae hyn yn cael gwared ar y problemau diogelwch math;Bydd `&mut *`* yn unig *rhoi i chi gael `&mut T` o `&mut T` neu `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Fodd bynnag, yr ydych yn dal i gael dau eirda mutable pwyntio at yr un cof.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dyma sut mae'r llyfrgell safonol ei wneud.
    /// // Mae hyn yn y dull gorau, os oes angen i wneud rhywbeth fel hyn
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Bellach mae gan hwn dri chyfeiriad cyfnewidiol sy'n pwyntio at yr un cof.`slice`, mae'r ret.0 rvalue, a'r ret.1 rvalue.
    ///         // `slice` byth yn cael ei ddefnyddio ar ôl `let ptr = ...`, ac felly gall rhywun ei drin fel "dead", ac felly, dim ond dwy dafell symudol go iawn sydd gennych.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Er bod hyn yn gwneud y stabl Etholaeth cynhenid, mae gennym rai cod arfer yn fn Etholaeth
    // sieciau sy'n atal ei ddefnydd o fewn `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Dychwelyd `true` os yw'r math gwirioneddol a roddir fel `T` yn gofyn glud galw heibio;dychwelyd `false` os yw'r math gwirioneddol a ddarperir ar gyfer `T` yn gweithredu `Copy`.
    ///
    ///
    /// Os nad oes angen glud gollwng na gweithredu `Copy` ar y math gwirioneddol, yna mae gwerth dychwelyd y swyddogaeth hon yn amhenodol.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd.
    ///
    /// Gweithredir hyn fel rhywbeth cynhenid er mwyn osgoi trosi i gyfanrif ac oddi yno, gan y byddai'r trawsnewidiad yn taflu gwybodaeth arall.
    ///
    /// # Safety
    ///
    /// Rhaid i'r pwyntydd cychwynnol a'r pwyntydd canlyniadol fod naill ai mewn ffiniau neu un beit heibio i ddiwedd gwrthrych a ddyrannwyd.
    /// Os bydd y naill pwyntydd yn waharddedig neu orlif rhifyddeg yn digwydd, yna bydd unrhyw ddefnydd pellach o'r gwerth a ddychwelwyd yn arwain at ymddygiad anniffiniedig.
    ///
    ///
    /// Y fersiwn sefydlog o'r cynhenid hon yw [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd, a allai lapio o bosibl.
    ///
    /// Mae hyn yn cael ei weithredu fel gynhenid i osgoi trosi i ac o'r cyfanrif, gan fod yr addasiad yn atal rhai optimizations.
    ///
    /// # Safety
    ///
    /// Yn wahanol i'r cynhenid `offset`, nid yw hyn yn gynhenid yn cyfyngu pwyntydd deillio i bwynt i mewn neu un beit heibio diwedd gwrthrych a ddyrannwyd, ac mae'n lapio gyda dau yn rhifyddeg ategu.
    /// Nid yw gwerth sy'n deillio o hyn o reidrwydd yn ddilys i'w defnyddio i gof mynediad mewn gwirionedd.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Sy'n cyfateb i'r briodol `llvm.memcpy.p0i8.0i8.*` cynhenid, gyda maint o `count`*`size_of::<T>()` ac alinio
    ///
    /// `min_align_of::<T>()`
    ///
    /// Mae'r paramedr anweddol ei osod i `true`, felly ni fydd yn cael ei optimeiddio allan oni bai bod maint yn hafal i sero.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sy'n cyfateb i'r briodol `llvm.memmove.p0i8.0i8.*` cynhenid, gyda maint o `count* size_of::<T>()` ac alinio
    ///
    /// `min_align_of::<T>()`
    ///
    /// Mae'r paramedr anweddol ei osod i `true`, felly ni fydd yn cael ei optimeiddio allan oni bai bod maint yn hafal i sero.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Yn gyfwerth â'r `llvm.memset.p0i8.*` cynhenid priodol, gyda maint o `count* size_of::<T>()` ac aliniad o `min_align_of::<T>()`.
    ///
    ///
    /// Mae'r paramedr anweddol ei osod i `true`, felly ni fydd yn cael ei optimeiddio allan oni bai bod maint yn hafal i sero.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Perfformio llwyth gyfnewidiol o'r pwyntydd `src`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Yn perfformio storfa gyfnewidiol i'r pwyntydd `dst`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hon yw [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Yn perfformio llwyth cyfnewidiol o'r pwyntydd `src` Nid yw'n ofynnol i'r pwyntydd gael ei alinio.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Yn perfformio storfa gyfnewidiol i'r pwyntydd `dst`.
    /// Nid yw'n ofynnol i'r pwyntydd gael ei alinio.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Dychwelyd ail isradd o `f32`
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Dychwelyd ail isradd o `f64`
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Yn codi `f32` i pŵer cyfanrif.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Yn codi `f64` i pŵer cyfanrif.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Dychwelyd y sin o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Dychwelyd y sin o `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Dychwelyd y cosin o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Dychwelyd y cosin o `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Yn codi `f32` i `f32` pŵer.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Yn codi `f64` i bŵer `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Dychwelyd y esbonyddol o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Dychwelyd y esbonyddol o `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Ffurflenni 2 godi i bŵer o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Ffurflenni 2 godi i bŵer o `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Dychwelyd y logarithm naturiol o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Dychwelyd y logarithm naturiol o `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Dychwelyd y sylfaen 10 logarithm o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Yn dychwelyd logarithm sylfaen 10 `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Dychwelyd y sylfaen 2 logarithm o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Dychwelyd y sylfaen 2 logarithm o `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Yn dychwelyd `a * b + c` ar gyfer gwerthoedd `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Ffurflenni `a * b + c` gyfer gwerthoedd `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Dychwelyd y gwerth absoliwt o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Yn dychwelyd gwerth absoliwt `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Yn dychwelyd yr isafswm o ddau werth `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Dychwelyd y lleiafswm o ddau werth `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Dychwelyd y uchafswm o ddau werth `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Yn dychwelyd yr uchafswm o ddau werth `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copïwch yr arwydd o `y` i `x` ar gyfer gwerthoedd `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Mae copïau mae'r arwydd o `y` i `x` i `f64` gwerthoedd.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Ffurflenni cyfanrif mwyaf yn llai na neu'n hafal i `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Ffurflenni cyfanrif mwyaf yn llai na neu'n hafal i `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Yn dychwelyd y cyfanrif lleiaf sy'n fwy na neu'n hafal i `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Dychwelyd y mwyaf cyfanrif lleiaf na neu'n hafal i `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Dychwelyd y rhan gyfanrif o `f32`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Dychwelyd y rhan gyfanrif o `f64`.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Yn dychwelyd y cyfanrif agosaf i `f32`.
    /// Mai godi eithriad cyffredinol-bwynt anfanwl os nad yw'r ddadl yn gyfanrif.
    pub fn rintf32(x: f32) -> f32;
    /// Yn dychwelyd y cyfanrif agosaf i `f64`.
    /// Mai godi eithriad cyffredinol-bwynt anfanwl os nad yw'r ddadl yn gyfanrif.
    pub fn rintf64(x: f64) -> f64;

    /// Yn dychwelyd y cyfanrif agosaf i `f32`.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Yn dychwelyd y cyfanrif agosaf i `f64`.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Yn dychwelyd y cyfanrif agosaf i `f32`.achosion Rowndiau hanner ffordd i ffwrdd o sero.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Yn dychwelyd y cyfanrif agosaf i `f64`.achosion Rowndiau hanner ffordd i ffwrdd o sero.
    ///
    /// Mae'r fersiwn sefydlogi o'r gynhenid hwn yw
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ychwanegiad arnofio sy'n caniatáu optimeiddiadau yn seiliedig ar reolau algebraidd.
    /// Mai tybio mewnbynnau yn gyfyngedig.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Arnofio tynnu sy'n caniatáu optimeiddiad seiliedig ar reolau algebraidd.
    /// Mai tybio mewnbynnau yn gyfyngedig.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Lluosi arnofio sy'n caniatáu optimeiddiadau yn seiliedig ar reolau algebraidd.
    /// Mai tybio mewnbynnau yn gyfyngedig.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float adran sy'n caniatáu optimeiddiad seiliedig ar reolau algebraidd.
    /// Mai tybio mewnbynnau yn gyfyngedig.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Gweddill arnofio sy'n caniatáu optimeiddiadau yn seiliedig ar reolau algebraidd.
    /// Mai tybio mewnbynnau yn gyfyngedig.
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Trosi gyda fptoui/fptosi LLVM, a all ddychwelyd undef ar gyfer gwerthoedd y tu hwnt i amrediad
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Wedi'i sefydlogi fel [`f32::to_int_unchecked`] a [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Ffurflenni y nifer o ddarnau gosod mewn math cyfanrif `T`
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `count_ones`.
    /// Er enghraifft,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Dychwelyd y nifer o brif ddarnau playlist (zeroes) mewn math cyfanrif `T`.
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `leading_zeros`.
    /// Er enghraifft,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Bydd `x` gyda gwerth `0` yn dychwelyd y darn lled `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Fel `ctlz`, ond yn hynod anniogel wrth iddo ddychwelyd `undef` pan roddir `x` iddo sydd â gwerth `0`.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Dychwelyd y nifer o llusgo darnau playlist (zeroes) mewn math cyfanrif `T`.
    ///
    /// Mae'r fersiynau sefydlog o'r cynhenid hwn ar gael ar y primitive cyfanrif trwy'r dull `trailing_zeros`.
    /// Er enghraifft,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Bydd `x` gyda gwerth `0` yn dychwelyd y darn lled `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Fel `cttz`, ond all-anniogel gan ei fod yn dychwelyd `undef` pan cael `x` gyda gwerth `0`.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Gwrthdroi bytes mewn math cyfanrif `T`.
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `swap_bytes`.
    /// Er enghraifft,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Yn gwrthdroi y darnau mewn math cyfanrif `T`.
    ///
    /// Mae'r fersiynau sefydlog o'r cynhenid hwn ar gael ar y primitive cyfanrif trwy'r dull `reverse_bits`.
    /// Er enghraifft,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// gwirio perfformio cyfanrif ogystal.
    ///
    /// Mae'r fersiynau sefydlog o'r cynhenid hwn ar gael ar y primitive cyfanrif trwy'r dull `overflowing_add`.
    /// Er enghraifft,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yn perfformio tynnu cyfanrif wedi'i wirio
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `overflowing_sub`.
    /// Er enghraifft,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// gwirio perfformio cyfanrif lluosi
    ///
    /// Mae'r fersiynau sefydlog o'r cynhenid hwn ar gael ar y primitive cyfanrif trwy'r dull `overflowing_mul`.
    /// Er enghraifft,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Perfformio union adran, gan arwain at ymddygiad undefined lle `x % y != 0` neu `y == 0` neu `x == T::MIN && y == -1`
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Perfformio adran unchecked, gan arwain at ymddygiad undefined lle `y == 0` neu `x == T::MIN && y == -1`
    ///
    ///
    /// deunydd lapio Diogel ar gyfer gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `checked_div`.
    /// Er enghraifft,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Yn dychwelyd gweddill rhaniad heb ei wirio, gan arwain at ymddygiad heb ei ddiffinio pan fydd `y == 0` neu `x == T::MIN && y == -1`
    ///
    ///
    /// deunydd lapio Diogel ar gyfer gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `checked_rem`.
    /// Er enghraifft,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Perfformio sifft chwith unchecked, gan arwain at ymddygiad undefined pan `y < 0` neu `y >= N`, lle mae N yn lled T yn ddarnau.
    ///
    ///
    /// Mae deunydd lapio diogel ar gyfer y cynhenid hwn ar gael ar y primitive cyfanrif trwy'r dull `checked_shl`.
    /// Er enghraifft,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Perfformio sifft cywir unchecked, gan arwain at ymddygiad undefined pan `y < 0` neu `y >= N`, lle mae N yn lled T yn ddarnau.
    ///
    ///
    /// deunydd lapio Diogel ar gyfer gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `checked_shr`.
    /// Er enghraifft,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Yn dychwelyd canlyniad ychwanegiad heb ei wirio, gan arwain at ymddygiad heb ei ddiffinio pan fydd `x + y > T::MAX` neu `x + y < T::MIN`.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Yn dychwelyd canlyniad tynnu heb ei wirio, gan arwain at ymddygiad heb ei ddiffinio pan fydd `x - y > T::MAX` neu `x - y < T::MIN`.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Dychwelyd ganlyniad i luosi unchecked, gan arwain at ymddygiad undefined pan `x *y > T::MAX` neu `x* y < T::MIN`.
    ///
    ///
    /// Nid oes gan y cynhenid hwn gymar sefydlog.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Perfformio cylchdroi chwith.
    ///
    /// Mae'r fersiynau sefydlog o'r cynhenid hwn ar gael ar y primitive cyfanrif trwy'r dull `rotate_left`.
    /// Er enghraifft,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Perfformio cylchdroi i'r dde.
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `rotate_right`.
    /// Er enghraifft,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Dychweliadau (a + b) mod 2 <sup>N</sup>, lle N yw lled T mewn darnau.
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `wrapping_add`.
    /// Er enghraifft,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Ffurflenni (a, b) mod 2 <sup>N,</sup> lle mae N yn lled T yn ddarnau.
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `wrapping_sub`.
    /// Er enghraifft,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Ffurflenni (a * b) mod 2 <sup>N,</sup> lle mae N yn lled T yn ddarnau.
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `wrapping_mul`.
    /// Er enghraifft,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating mewn terfynau rhifol.
    ///
    /// Mae fersiynau sefydlogi y gynhenid hwn ar gael ar y primitives cyfanrif drwy'r dull `saturating_add`.
    /// Er enghraifft,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, saturating mewn terfynau rhifol.
    ///
    /// Mae'r fersiynau sefydlog o'r cynhenid hwn ar gael ar y primitive cyfanrif trwy'r dull `saturating_sub`.
    /// Er enghraifft,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Dychwelyd y gwerth y Gwahanolyn gyfer y amrywiad yn 'v';
    /// os `T` nid oes Gwahanolyn, yn dychwelyd `0`.
    ///
    /// Y fersiwn sefydlog o'r cynhenid hon yw [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Ffurflenni y nifer o amrywiadau o'r fath `T` bwrw i `usize`;
    /// os oes gan `T` oes amrywiadau, yn dychwelyd `0`.Bydd amrywiadau anghyfannedd yn cael eu cyfrif.
    ///
    /// Mae'r fersiwn i-fod-sefydlogi o gynhenid hon yw [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Llun "try catch" Rust sy'n galw'r pwyntydd swyddogaeth `try_fn` gyda'r pwyntydd data `data`.
    ///
    /// Y trydydd ddadl yn swyddogaeth o'r enw os bydd panic digwydd.
    /// Mae'r swyddogaeth hon yn cymryd y pwyntydd data a pwyntydd i'r gwrthrych eithrio targedau penodol a oedd yn dal.
    ///
    /// Am ragor o wybodaeth gweler ffynhonnell y casglwr yn ogystal â gweithredu'r dal std yn.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Allyrru siop `!nontemporal` yn ôl LLVM (gweler eu docs).
    /// Mae'n debyg na fydd yn dod yn sefydlog.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Gweler dogfennaeth o `<*const T>::offset_from` am fanylion.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Gweler dogfennaeth o `<*const T>::guaranteed_eq` am fanylion.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Gweler dogfennaeth `<*const T>::guaranteed_ne` am fanylion.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Dyrannu ar adeg crynhoi.Ni ddylai gael ei alw yn Rhedeg.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Diffinnir rhai swyddogaethau yma oherwydd eu bod ar gael yn ddamweiniol yn y modiwl hwn ar sefydlog.
// Gweler <https://github.com/rust-lang/rust/issues/15702>.
// (Mae `transmute` hefyd yn y categori hwn, ond ni ellir ei lapio oherwydd y gwiriad bod gan `T` a `U` yr un maint.)
//

/// Gwiriadau boed `ptr` yn cyd-fynd yn briodol mewn perthynas â `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copïau `count *size_of::<T>()` bytes o `src` i `dst`.Rhaid i'r ffynhonnell a'r gyrchfan* beidio * gorgyffwrdd.
///
/// Ar gyfer rhanbarthau cof a allai orgyffwrdd, defnyddiwch [`copy`] yn lle.
///
/// `copy_nonoverlapping` yn cyfateb yn semantig i C's [`memcpy`], ond gyda'r gorchymyn dadl wedi'i gyfnewid.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `src` Mae'n rhaid fod [valid] i darllen o `count * size_of::<T>()` bytes.
///
/// * `dst` rhaid iddo fod yn [valid] ar gyfer ysgrifennu am beitiau `count * size_of::<T>()`.
///
/// * Mae'n rhaid i'r ddau `src` a `dst` yn cyd-fynd yn briodol.
///
/// * Rhanbarth y cof yn dechrau yn `src` gyda maint o `gyfrif *
///   maint_of: :<T>() Rhaid i `beit *beidio* gorgyffwrdd â rhanbarth y cof sy'n dechrau yn `dst` gyda'r un maint.
///
/// Fel [`read`], mae `copy_nonoverlapping` yn creu copi bitwise o `T`, ni waeth a yw `T` yn [`Copy`].
/// Os nad yw `T` [`Copy`], gan ddefnyddio *ddau* gwerthoedd yn y rhanbarth yn dechrau am `*src` a'r rhanbarth yn dechrau am `* dst` gall [violate memory safety][read-ownership].
///
///
/// Sylwch, hyd yn oed os yw'r maint a gopïwyd yn effeithiol (`count * size_of: :<T>()`) yw `0`, rhaid i'r awgrymiadau fod yn rhai nad ydynt yn NULL ac wedi'u halinio'n iawn.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manually gweithredu [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Symud holl elfennau `src` i `dst`, gan adael `src` wag.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Sicrhau bod `dst` ddigon o allu i ddal pob un o'r `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Mae'r alwad i wrthbwyso bob amser yn ddiogel oherwydd ni fydd `Vec` byth yn dyrannu mwy na beitiau `isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` heb ollwng ei gynnwys.
///         // Rydym yn gwneud hyn yn gyntaf, er mwyn osgoi problemau rhag ofn bod rhywbeth ymhellach i lawr panics.
///         src.set_len(0);
///
///         // Ni all y ddau ranbarth orgyffwrdd oherwydd nad yw cyfeiriadau symudol yn alias, ac ni all dau vectors gwahanol fod yn berchen ar yr un cof.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Rhoi gwybod i `dst` fod yn awr yn dal y cynnwys `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Perfformiwch y gwiriadau hyn ar amser rhedeg yn unig
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Peidio â mynd i banig i gadw effaith codegen yn llai.
        abort();
    }*/

    // DIOGELWCH: mae'n rhaid i'r contract diogelwch ar gyfer `copy_nonoverlapping` yn
    // gadarnhau gan y galwr.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copïau `count * size_of::<T>()` bytes o `src` i `dst`.Efallai y bydd y ffynhonnell a chyrchfan yn gorgyffwrdd.
///
/// Os bydd y ffynhonnell a'r gyrchfan a fydd *byth yn gorgyffwrdd*, [`copy_nonoverlapping`] gellir ei ddefnyddio yn lle.
///
/// `copy` yn cyfateb semantig i C yn [`memmove`], ond gyda'r gorchymyn ddadl cyfnewid.
/// Copïo yn digwydd fel pe bai'r bytes cael eu copïo o `src` i amrywiaeth dros dro ac yna gopïo o'r amrywiaeth i `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `src` Mae'n rhaid fod [valid] i darllen o `count * size_of::<T>()` bytes.
///
/// * `dst` rhaid iddo fod yn [valid] ar gyfer ysgrifennu am beitiau `count * size_of::<T>()`.
///
/// * Mae'n rhaid i'r ddau `src` a `dst` yn cyd-fynd yn briodol.
///
/// Fel [`read`], `copy` yn creu copi bitwise o `T`, heb ystyried a yw `T` [`Copy`].
/// Os nad yw `T` [`Copy`], gan ddefnyddio gwerthoedd yn y rhanbarth yn dechrau am `*src` a'r rhanbarth yn dechrau am `* dst` gall [violate memory safety][read-ownership].
///
///
/// Sylwch, hyd yn oed os yw'r maint a gopïwyd yn effeithiol (`count * size_of: :<T>()`) yw `0`, rhaid i'r awgrymiadau fod yn rhai nad ydynt yn NULL ac wedi'u halinio'n iawn.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Effeithlon greu vector Rust o byffer anniogel:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` Rhaid eu halinio yn gywir am ei fath a heb fod yn sero.
/// /// * `ptr` rhaid iddo fod yn ddilys ar gyfer darlleniadau o elfennau cyffiniol `elts` o fath `T`.
/// /// * Ni ddylai elfennau hynny gael eu defnyddio ar ôl galw y swyddogaeth hon oni bai `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // DIOGELWCH: Mae ein rhagamod yn sicrhau bod y ffynhonnell yn cyd-fynd ac yn ddilys,
///     // a `Vec::with_capacity` yn sicrhau bod gennym le defnyddiadwy eu hysgrifennu.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // DIOGELWCH: Rydym yn creu ei gyda llawer capasiti hwn yn gynharach,
///     // ac mae'r `copy` blaenorol wedi ymgychwyn elfennau hyn.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Perfformiwch y gwiriadau hyn ar amser rhedeg yn unig
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Peidio â mynd i banig i gadw effaith codegen yn llai.
        abort();
    }*/

    // DIOGELWCH: rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `copy`.
    unsafe { copy(src, dst, count) }
}

/// Yn gosod beitiau cof `count * size_of::<T>()` gan ddechrau ar `dst` i `val`.
///
/// `write_bytes` yn debyg i C [`memset`], ond yn gosod `count * size_of::<T>()` bytes i `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `dst` rhaid iddo fod yn [valid] ar gyfer ysgrifennu am beitiau `count * size_of::<T>()`.
///
/// * `dst` rhaid ei alinio'n iawn.
///
/// Yn ogystal, mae'n rhaid i'r sawl sy'n galw yn sicrhau bod ysgrifennu `count * size_of::<T>()` bytes i'r rhanbarth penodol o ganlyniadau cof mewn gwerth dilys o `T`.
/// Gan ddefnyddio ranbarth o gof teipio fel `T` sy'n cynnwys werth annilys o `T` yn ymddygiad anniffiniedig.
///
/// Sylwer bod hyd yn oed os bydd maint gopïo effeithiol (`cyfrif size_of *: :<T>()`) Yw `0`, mae'n rhaid i'r pwyntydd fod yn ddi-NULL a halinio'n briodol.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Creu gwerth annilys:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Yn gollwng y gwerth a ddaliwyd yn flaenorol trwy drosysgrifo'r `Box<T>` gyda chyfeiriadur null.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Ar y pwynt hwn, yn defnyddio neu'n gollwng canlyniadau `v` mewn ymddygiad anniffiniedig.
/// // drop(v); // ERROR
///
/// // Hyd yn oed yn gollwng `v` "uses" iddo, ac felly mae ymddygiad anniffiniedig.
/// // mem::forget(v); // ERROR
///
/// // Mewn gwirionedd, mae `v` yn annilys yn ôl invariants cynllun math sylfaenol, felly mae * unrhyw weithrediad sy'n ei gyffwrdd yn ymddygiad heb ei ddiffinio.
/////
/// // gadewch i v2 =v;//GWALL
///
/// unsafe {
///     // Yn lle hynny, gadewch inni roi gwerth dilys
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nawr bod y blwch yn iawn
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // DIOGELWCH: mae'n rhaid i'r contract diogelwch ar gyfer `write_bytes` yn cael ei gadarnhau gan y galwr.
    unsafe { write_bytes(dst, val, count) }
}