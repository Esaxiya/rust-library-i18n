use crate::iter::FromIterator;

/// Cwympo holl eitemau uned o iterator i mewn i un.
///
/// Mae hyn yn fwy defnyddiol wrth eu cyfuno ag echdynnu lefel uwch, fel casglu i `Result<(), E>` lle rydych yn unig yn poeni am gamgymeriadau:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}