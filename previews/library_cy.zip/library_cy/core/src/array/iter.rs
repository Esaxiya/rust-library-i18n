//! Diffinio'r `IntoIter` yn berchen iterator am araeau.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Ailadroddwr [array] is-werth.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dyma'r arae rydyn ni'n ailadrodd drosto.
    ///
    /// Elfennau gyda mynegai `i` lle na chynhyrchwyd `alive.start <= i < alive.end` eto ac maent yn gofnodion arae dilys.
    /// Elfennau gyda mynegeion `i < alive.start` neu `i >= alive.end` wedi cael eu ildio eisoes ac ni ddylid cael mynediad anymore!Gall y rhai elfennau marw hyd yn oed fod mewn cyflwr uninitialized yn llwyr!
    ///
    ///
    /// Felly, y invariants yw:
    /// - `data[alive]` yn fyw (hy yn cynnwys elfennau dilys)
    /// - `data[..alive.start]` a `data[alive.end..]` yn marw (hy yr elfennau eisoes yn darllen ac ni ddylid cyffwrdd anymore!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Yr elfennau yn `data` na chawsant eu cynhyrchu eto.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Yn creu ailadroddwr newydd dros yr `array` a roddir.
    ///
    /// *Noder*: gallai dull hwn yn cael ei ddibrisio yn y future, ar ôl [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Mae'r math o `value` yn `i32` yma, yn hytrach na `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // DIOGELWCH: Mae'r trosglwyddiad yma yn ddiogel mewn gwirionedd.Y docs o `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` yn sicr o fod â'r un maint ac aliniad
        // > fel `T`.
        //
        // Mae'r docs hyd yn oed yn dangos trawsfudiad o amrywiaeth o `MaybeUninit<T>` i amrywiaeth o `T`.
        //
        //
        // Gyda hynny, initialization hon bodloni'r invariants.

        // FIXME(LukasKalbertodt): mewn gwirionedd yn defnyddio `mem::transmute` yma, unwaith y bydd yn gweithio gyda generig Etholaeth:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Tan hynny, gallwn ddefnyddio `mem::transmute_copy` i greu copi bitwise fel math gwahanol, yna anghofio `array` fel na chaiff ei ollwng.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Yn dychwelyd tafell anadferadwy o'r holl elfennau na chawsant eu cynhyrchu eto.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // DIOGELWCH: Rydym yn gwybod bod yr holl elfennau o fewn `alive` yn cael eu initialized briodol.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Dychwelyd sleisen mutable o'r holl elfennau sydd heb eu ildio eto.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // DIOGELWCH: Rydym yn gwybod bod yr holl elfennau o fewn `alive` yn cael eu initialized briodol.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Sicrhewch y mynegai nesaf o'r tu blaen.
        //
        // Mae cynyddu `alive.start` o 1 yn cynnal yr invariant ynghylch `alive`.
        // Fodd bynnag, oherwydd y newid hwn, am gyfnod byr, nid `data[alive]` yw'r parth byw mwyach, ond `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Darllenwch yr elfen o'r casgliad.
            // DIOGELWCH: Mynegai i hen ranbarth "alive" yr ardal yw `idx`
            // arae.Mae darllen yr elfen hon yn golygu bod `data[idx]` yn cael ei ystyried yn farw nawr (hy peidiwch â chyffwrdd).
            // Gan mai `idx` oedd dechrau'r parth byw, mae'r parth byw bellach yn `data[alive]` eto, gan adfer yr holl invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Cael y mynegai nesaf o gefn.
        //
        // Lleihau `alive.end` erbyn 1 yn cynnal y ddigyfnewid ynghylch `alive`.
        // Fodd bynnag, oherwydd y newid hwn, am gyfnod byr, nid `data[alive]` yw'r parth byw mwyach, ond `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Darllenwch yr elfen o'r casgliad.
            // DIOGELWCH: Mynegai i hen ranbarth "alive" yr ardal yw `idx`
            // arae.Mae darllen yr elfen hon yn golygu bod `data[idx]` yn cael ei ystyried yn farw nawr (hy peidiwch â chyffwrdd).
            // Gan fod `idx` diwedd y yn fyw-barth, y parth yn fyw yn awr `data[alive]` eto, adfer pob invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // DIOGELWCH: Mae hyn yn ddiogel: mae `as_mut_slice` yn dychwelyd yr is-dafell yn union
        // o elfennau sydd heb eu symud allan eto ac sydd eto i'w gollwng.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // A fydd byth islif oherwydd y ddigyfnewid `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Mae'r ailadroddwr yn wir yn adrodd y hyd cywir.
// Nifer yr elfennau "alive" (a fydd yn dal i gael eu cynhyrchu) yw hyd yr ystod `alive`.
// Mae'r amrediad hwn wedi'i ostwng o ran hyd yn naill ai `next` neu `next_back`.
// Mae bob amser yn cael ei ostwng gan 1 yn y dulliau hynny, ond dim ond os dychwelir `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Sylwer, nid oes angen i ni mewn gwirionedd i gyd-fynd â'r un ystod fyw union, felly gallwn ni yn unig i mewn clôn gwrthbwyso 0 waeth ble `self` yn.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Cloniwch yr holl elfennau byw.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Ysgrifennwch clôn i mewn i'r casgliad newydd, ac yna diweddaru ei amrediad yn fyw.
            // Os clonio panics, byddwn yn gollwng yr eitemau blaenorol yn gywir.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Dim ond argraffu yr elfennau nad oedd yn ildio eto: ni allwn gael mynediad i'r elfennau ildio anymore.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}