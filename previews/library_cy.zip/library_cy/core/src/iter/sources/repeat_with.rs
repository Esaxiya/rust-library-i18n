use crate::iter::{FusedIterator, TrustedLen};

/// Creu iterator newydd sy'n ailadrodd elfennau o'r math `A` ddiddiwedd drwy gymhwyso'r ddarperir cau, mae'r ailadrodd, `F: FnMut() -> A`.
///
/// Mae'r swyddogaeth `repeat_with()` yn galw y ailadrodd drosodd a throsodd.
///
/// Mae ailadroddwyr anfeidrol fel `repeat_with()` yn aml yn cael eu defnyddio gydag addaswyr fel [`Iterator::take()`], er mwyn eu gwneud yn gyfyngedig.
///
/// Os yw'r math o elfen o'r ailadroddwr sydd ei angen arnoch yn gweithredu [`Clone`], a'i bod yn iawn cadw'r elfen ffynhonnell yn y cof, dylech ddefnyddio'r swyddogaeth [`repeat()`] yn lle hynny.
///
///
/// Nid yw ailadroddwr a gynhyrchir gan `repeat_with()` yn [`DoubleEndedIterator`].
/// Os oes angen `repeat_with()` i ddychwelyd [`DoubleEndedIterator`], os gwelwch yn dda agor fater GitHub esbonio eich achos eu defnyddio.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::iter;
///
/// // gadewch i ni dybio gennym rywfaint o werth o fath nad yw'n `Clone` neu nad ydynt yn dymuno cael er cof eto oherwydd ei fod yn ddrud:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // gwerth arbennig am byth:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Defnyddio treiglad a mynd yn gyfyngedig:
///
/// ```rust
/// use std::iter;
///
/// // O'r 0eg i'r trydydd grym dau:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ac yn awr rydym yn ei wneud
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ailadroddwr sy'n ailadrodd elfennau o fath `A` yn ddiddiwedd trwy gymhwyso'r cau `F: FnMut() -> A` a ddarperir.
///
///
/// Mae'r `struct` yn cael ei greu gan y swyddogaeth [`repeat_with()`].
/// Gweler ei ddogfennaeth am fwy.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}