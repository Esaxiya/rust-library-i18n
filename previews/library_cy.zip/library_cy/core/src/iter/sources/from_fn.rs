use crate::fmt;

/// Creu iterator newydd lle pob iteriad galwadau cau ddarperir `F: FnMut() -> Option<T>`.
///
/// Mae hyn yn caniatáu creu iterator arfer ag unrhyw ymddygiad heb ddefnyddio'r mwy amleiriog cystrawen o greu math ymroddedig a gweithredu'r [`Iterator`] trait ar ei gyfer.
///
/// Noder nad yw'r `FromFn` iterator yn gwneud rhagdybiaethau am ymddygiad gau, ac felly nid ceidwadol yn gweithredu [`FusedIterator`], neu gwrthwneud [`Iterator::size_hint()`] o'i diofyn `(0, None)`.
///
///
/// Gall y cau ddefnyddio cipio a'i amgylchedd i olrhain cyflwr ar draws iteriadau.Yn dibynnu ar sut y mae'r iterator yn cael ei ddefnyddio, gall hyn ei gwneud yn ofynnol gan nodi'r gair allweddol [`move`] ar gau.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Gadewch i ni ail-weithredu'r iterator cownter o [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Cynyddiad ein cyfrif.Dyma pam ein bod yn dechrau ar sero.
///     count += 1;
///
///     // Edrychwch i weld os rydym wedi cyfrif gorffenedig neu beidio.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Mae iterator lle mae pob iteriad galwadau cau ddarperir `F: FnMut() -> Option<T>`.
///
/// Mae'r `struct` yn cael ei greu gan y swyddogaeth [`iter::from_fn()`].
/// Gweler ei ddogfennaeth am fwy.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}