use crate::iter::{FusedIterator, TrustedLen};

/// Creu iterator newydd sy'n ddiddiwedd ailadrodd elfen sengl.
///
/// Mae'r swyddogaeth `repeat()` yn ailadrodd gwerth sengl drosodd a throsodd.
///
/// iterators ddiddiwedd fel `repeat()` yn cael eu defnyddio'n aml gyda addaswyr fel [`Iterator::take()`], er mwyn eu gwneud yn gyfyngedig.
///
/// Os bydd y math elfen o'r iterator hangen arnoch nid yw'n gweithredu `Clone`, neu os nad ydych am i gadw'r elfen hailadrodd yn y cof, gallwch chi yn hytrach na defnyddio'r swyddogaeth [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::iter;
///
/// // rhif pedwar 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, yn dal pedwar
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Mynd cyfyngedig gyda [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // bod enghraifft olaf oedd gormod o bedwar.Gadewch i ni dim ond ar bedwar pedwar.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ac yn awr rydym yn ei wneud
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Mae iterator sy'n ailadrodd elfen ddiddiwedd.
///
/// Mae'r `struct` yn cael ei greu gan y swyddogaeth [`repeat()`].Gweler ei ddogfennaeth i ddarganfod mwy.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}