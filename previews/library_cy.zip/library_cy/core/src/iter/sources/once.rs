use crate::iter::{FusedIterator, TrustedLen};

/// Yn creu ailadroddwr sy'n cynhyrchu elfen yn union unwaith.
///
/// Defnyddir hwn yn gyffredin i addasu gwerth sengl yn [`chain()`] o iteriadau eraill.
/// Efallai bod gennych iterator bod cloriau bron popeth, ond mae angen i chi gael achos arbennig ychwanegol.
/// Efallai bod gennych swyddogaeth sy'n gweithio ar ailadroddwyr, ond dim ond un gwerth sydd ei angen arnoch chi.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::iter;
///
/// // un yw'r rhif mwyaf unig
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // un yn unig, dyna'r cyfan a gawn
/// assert_eq!(None, one.next());
/// ```
///
/// Cadwyno ynghyd ag ailadroddwr arall.
/// Dewch i ddweud ein bod am ailadrodd dros bob ffeil o'r cyfeiriadur `.foo`, ond hefyd yn ffeil cyfluniad,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // mae angen i drosi o iterator o DirEntry-au i iterator o PathBufs, felly rydym yn defnyddio map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // Erbyn hyn, mae ein iterator yn unig ar gyfer ein config ffeil
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // cadwyn y ddau iterators ynghyd mewn un iterator mawr
/// let files = dirs.chain(config);
///
/// // bydd hyn yn rhoi pob un o'r ffeiliau yn .foo yn ogystal â .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Mae iterator sy'n cynhyrchu elfen yn union yr un pryd.
///
/// Mae'r `struct` yn cael ei greu gan y swyddogaeth [`once()`].Gweler ei ddogfennaeth am fwy.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}