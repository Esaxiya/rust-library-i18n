use crate::iter::{FusedIterator, TrustedLen};

/// Creu iterator sy'n ddiog yn creu gwerth yn union unwaith drwy galw ar y ddarperir cau.
///
/// Defnyddir hyn yn gyffredin i addasu generadur gwerth unigol i mewn i [`chain()`] o fathau eraill o ailadrodd.
/// Efallai bod gennych iterator bod cloriau bron popeth, ond mae angen i chi gael achos arbennig ychwanegol.
/// Efallai bod gennych swyddogaeth sy'n gweithio ar ailadroddwyr, ond dim ond un gwerth sydd ei angen arnoch chi.
///
/// Yn wahanol i [`once()`], bydd y swyddogaeth hon ddiog creu gwerth ar gais.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::iter;
///
/// // un yw'r rhif mwyaf unig
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // un yn unig, dyna'r cyfan a gawn
/// assert_eq!(None, one.next());
/// ```
///
/// Cadwyno ynghyd ag ailadroddwr arall.
/// Dewch i ddweud ein bod am ailadrodd dros bob ffeil o'r cyfeiriadur `.foo`, ond hefyd yn ffeil cyfluniad,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // mae angen i drosi o iterator o DirEntry-au i iterator o PathBufs, felly rydym yn defnyddio map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // Erbyn hyn, mae ein iterator yn unig ar gyfer ein config ffeil
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // cadwyn y ddau iterators ynghyd mewn un iterator mawr
/// let files = dirs.chain(config);
///
/// // bydd hyn yn rhoi pob un o'r ffeiliau yn .foo yn ogystal â .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ailadroddwr sy'n cynhyrchu un elfen o fath `A` trwy gymhwyso'r cau `F: FnOnce() -> A` a ddarperir.
///
///
/// Mae'r `struct` hwn yn cael ei greu gan y swyddogaeth [`once_with()`].
/// Gweler ei ddogfennaeth am fwy.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}