/// Trosi o [`Iterator`].
///
/// Trwy weithredu `FromIterator` ar gyfer math, rydych chi'n diffinio sut y bydd yn cael ei greu o ailadroddwr.
/// Mae hyn yn gyffredin ar gyfer mathau sy'n disgrifio casgliad o ryw fath.
///
/// [`FromIterator::from_iter()`] Anaml iawn y mae enw benodol, ac yn cael ei ddefnyddio yn lle trwy ddull [`Iterator::collect()`].
///
/// Gweler dogfennaeth [`Iterator::collect()`]'s i gael mwy o enghreifftiau.
///
/// Gweld hefyd: [`IntoIterator`].
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Defnyddio [`Iterator::collect()`] i ddefnyddio `FromIterator` yn ymhlyg:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Gweithredu `FromIterator` ar gyfer eich math:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Casgliad sampl, dim ond deunydd lapio dros Vec yw hwnnw<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gadewch i ni roi rhai dulliau iddo fel y gallwn greu un ac ychwanegu pethau ato.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a byddwn yn gweithredu FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nawr gallwn wneud ailadroddwr newydd ...
/// let iter = (0..5).into_iter();
///
/// // ... a gwneud MyCollection allan ohono
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // casglu gweithiau hefyd!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Creu gwerth o iterator.
    ///
    /// Gweler yr [module-level documentation] am fwy.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Trosi i mewn i [`Iterator`].
///
/// Trwy weithredu `IntoIterator` ar gyfer math, rydych chi'n diffinio sut y bydd yn cael ei drawsnewid yn ailadroddwr.
/// Mae hyn yn gyffredin ar gyfer mathau sy'n disgrifio casgliad o ryw fath.
///
/// Un fantais o weithredu `IntoIterator` yw bod eich math bydd [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Gweld hefyd: [`FromIterator`].
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Gweithredu `IntoIterator` ar gyfer eich math:
///
/// ```
/// // Casgliad sampl, dim ond deunydd lapio dros Vec yw hwnnw<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gadewch i ni roi rhai dulliau iddo fel y gallwn greu un ac ychwanegu pethau ato.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a byddwn yn gweithredu IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nawr gallwn wneud casgliad newydd ...
/// let mut c = MyCollection::new();
///
/// // ... ychwanegu ychydig o bethau ato ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ac yna trowch i mewn i Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Mae'n gyffredin i ddefnyddio `IntoIterator` fel trait bound.Mae hyn yn caniatáu i'r math casglu mewnbwn i newid, cyn belled â'i fod yn dal i fod yn iterator.
/// Gellir terfynau ychwanegol yn cael ei nodi drwy gyfyngu ar
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Y math o elfennau sy'n cael eu Ailadroddodd drosodd.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Pa fath o ailadroddwr ydyn ni'n troi hwn ynddo?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Creu iterator o werth.
    ///
    /// Gweler yr [module-level documentation] am fwy.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Ymestyn casgliad gyda chynnwys ailadroddwr.
///
/// Iterators cynhyrchu cyfres o werthoedd, a gall casgliadau hefyd yn cael ei ystyried fel cyfres o werthoedd.
/// Mae'r trait `Extend` yn pontio'r bwlch hwn, sy'n eich galluogi i ymestyn casgliad drwy gynnwys cynnwys y iterator.
/// Wrth estyn casgliad gyda allwedd sydd eisoes yn bodoli, bod mynediad yn cael ei ddiweddaru neu, yn achos casgliadau sy'n caniatáu ceisiadau lluosog gydag allweddi cyfartal, bod mynediad yn cael ei roi i mewn.
///
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// // Gallwch estyn Llinynnol gyda rhai chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Gweithredu `Extend`:
///
/// ```
/// // Casgliad sampl, dim ond deunydd lapio dros Vec yw hwnnw<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gadewch i ni roi rhai dulliau iddo fel y gallwn greu un ac ychwanegu pethau ato.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ers MyCollection restr o i32s, yr ydym yn gweithredu Ymestyn am i32
/// impl Extend<i32> for MyCollection {
///
///     // Mae hyn ychydig yn symlach gyda'r llofnod math concrit: gallwn alw ymestyn ar unrhyw beth y gellir ei droi yn Iterator sy'n rhoi i32s inni.
///     // Oherwydd bod angen i32s arnom i'w rhoi yn MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Mae'r gweithredu yn syml iawn: dolen trwy'r ailadroddwr, a add() pob elfen i ni ein hunain.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // gadewch i ni ymestyn ein casgliad gyda thri fwy o rifau
/// c.extend(vec![1, 2, 3]);
///
/// // rydym wedi ychwanegu elfennau hyn ar y diwedd
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Ymestyn casgliad â chynnwys o iterator.
    ///
    /// Gan mai hwn yw'r dull yn unig eu hangen ar gyfer trait hwn, mae'r docs [trait-level] yn cynnwys mwy o fanylion.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // Gallwch estyn Llinynnol gyda rhai chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Yn estyn casgliad gydag un elfen yn union.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Cronfeydd Wrth Gefn capasiti mewn casgliad ar gyfer y nifer penodol o elfennau ychwanegol.
    ///
    /// Mae gweithredu rhagosodedig yn gwneud dim.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}