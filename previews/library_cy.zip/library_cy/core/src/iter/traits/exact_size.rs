/// Mae iterator sy'n adnabod ei union hyd.
///
/// Nid yw llawer [`Iterator`] yn gwybod sawl gwaith y byddant yn ailadrodd, ond mae rhai yn gwneud hynny.
/// Os yw ailadroddwr yn gwybod sawl gwaith y gall ailadrodd, gall darparu mynediad i'r wybodaeth honno fod yn ddefnyddiol.
/// Er enghraifft, os ydych chi am ailadrodd yn ôl, dechrau da yw gwybod ble mae'r diwedd.
///
/// Wrth gweithredu `ExactSizeIterator`, rhaid i chi hefyd yn gweithredu [`Iterator`].
/// Wrth wneud hynny, rhaid i weithrediad [`Iterator::size_hint`]* * ddychwelyd union faint yr ailadroddwr.
///
/// Mae gan y dull [`len`] weithrediad diofyn, felly fel arfer ni ddylech ei weithredu.
/// Fodd bynnag, efallai y byddwch yn medru darparu gweithrediad mwy performant na 'r ball, felly drech yn yr achos hwn yn gwneud synnwyr.
///
///
/// Sylwch fod trait hwn yn ddiogel trait ac fel y cyfryw yn * * Nid yw ac ni all * * gwarantu bod hyd a ddychwelwyd yn gywir.
/// Mae hyn yn golygu na ddylai cod **01X** ddibynnu ar gywirdeb [`Iterator::size_hint`].
/// Mae'r ansefydlog ac anniogel [`TrustedLen`](super::marker::TrustedLen) trait yn rhoi gwarant ychwanegol hwn.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// // amrediad cyfyngedig yn gwybod yn union faint o weithiau y bydd yn ailadrodd
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Yn y [module-level docs], rydym yn rhoi ar waith yn [`Iterator`], `Counter`.
/// Gadewch i ni weithredu `ExactSizeIterator` ar ei gyfer, yn ogystal:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Gallwn yn hawdd gyfrifo'r gweddill o iteriadau.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // A nawr gallwn ei ddefnyddio!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Dychwelyd union hyd y iterator.
    ///
    /// Mae'r yn sicrhau gweithredu y bydd y iterator yn dychwelyd yn union `len()` fwy yr werth [`Some(T)`], cyn dychwelyd [`None`].
    ///
    /// Mae gan y dull hwn weithrediad diofyn, felly fel arfer ni ddylech ei weithredu'n uniongyrchol.
    /// Fodd bynnag, os gallwch ddarparu gweithrediad mwy effeithlon, gallwch wneud hynny.
    /// Gweler y docs [trait-level] am enghraifft.
    ///
    /// Mae gan y swyddogaeth hon yr un gwarantau diogelwch fel y swyddogaeth [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // amrediad cyfyngedig yn gwybod yn union faint o weithiau y bydd yn ailadrodd
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Mae'r honiad yn rhy amddiffynnol, ond mae'n gwiriadau y ddigyfnewid
        // wedi'i warantu gan y trait.
        // Pe bai'r trait hwn yn rust-fewnol, gallem ddefnyddio debug_assert!;assert_eq!yn gwirio pob implementations defnyddiwr Rust hefyd.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Ffurflenni `true` os yw'r iterator yn wag.
    ///
    /// Mae'r dull hwn mae gweithredu rhagosodedig ddefnyddio [`ExactSizeIterator::len()`], felly nid oes angen i chi ei roi ar waith eich hun.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}