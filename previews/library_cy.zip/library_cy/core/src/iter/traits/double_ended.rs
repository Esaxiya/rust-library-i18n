use crate::ops::{ControlFlow, Try};

/// Mae iterator gallu elfennau cynnyrch o'r ddau ben.
///
/// Mae gan rywbeth sy'n gweithredu `DoubleEndedIterator` un gallu ychwanegol dros rywbeth sy'n gweithredu [`Iterator`]: y gallu i gymryd `Eitem o'r cefn, yn ogystal â'r tu blaen.
///
///
/// Mae'n bwysig nodi bod gwaith yn ôl ac ymlaen yn gweithio ar yr un ystod, ac nad ydyn nhw'n croesi: mae iteriad drosodd pan maen nhw'n cwrdd yn y canol.
///
/// Mewn modd tebyg i'r protocol [`Iterator`], unwaith y `DoubleEndedIterator` yn dychwelyd [`None`] o [`next_back()`], yn galw eto neu beidio byth yn dychwelyd [`Some`] eto.
/// [`next()`] a [`next_back()`] yn ymgyfnewidiol at y diben hwn.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Yn tynnu ac yn dychwelyd elfen o ddiwedd yr ailadroddwr.
    ///
    /// Ffurflenni `None` pan nad oes mwy o elfennau.
    ///
    /// Mae'r docs [trait-level] yn cynnwys mwy o fanylion.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Yr elfennau ildio gan `ddulliau DoubleEndedIterator` fod yn wahanol i'r rhai ildio trwy ddulliau [`Iterator`] 's:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Datblygiadau y iterator o gefn gan elfennau `n`.
    ///
    /// `advance_back_by` yw'r fersiwn gefn [`advance_by`].Bydd y dull hwn yn hepgor elfennau `n` yn eiddgar gan ddechrau o'r cefn trwy ffonio [`next_back`] hyd at amseroedd `n` nes dod ar draws [`None`].
    ///
    /// `advance_back_by(n)` Bydd yn dychwelyd [`Ok(())`] os yw'r iterator datblygiadau llwyddiannus gan elfennau `n`, neu [`Err(k)`] os [`None`] yn dod ar eu traws, lle `k` yw'r nifer o elfennau y iterator yn uwch gan cyn rhedeg allan o elfennau (hy
    /// hyd y iterator).
    /// Sylwch fod `k` bob amser yn llai na `n`.
    ///
    /// Nid yw Galw `advance_back_by(0)` yn defnyddio unrhyw elfennau a bob amser yn dychwelyd [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // Dim ond `&3` ei hepgor
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Ffurflenni y `elfen n`th o ddiwedd y iterator.
    ///
    /// Mae hyn yn y bôn fersiwn wyrdroi o [`Iterator::nth()`].
    /// Er fel y mwyafrif o weithrediadau mynegeio, mae'r cyfrif yn cychwyn o sero, felly mae `nth_back(0)` yn dychwelyd y gwerth cyntaf o'r diwedd, `nth_back(1)` yr ail, ac ati.
    ///
    ///
    /// Noder y bydd pob elfen rhwng diwedd a'r elfen a ddychwelwyd yn cael ei yfed, gan gynnwys yr elfen dychwelyd.
    /// Mae hyn hefyd yn golygu y bydd galw `nth_back(0)` sawl gwaith ar yr un iterator dychwelyd gwahanol elfennau.
    ///
    /// `nth_back()` yn dychwelyd [`None`] os yw `n` yn fwy na neu'n hafal i hyd yr ailadroddwr.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Nid yw Galw `nth_back()` sawl gwaith yn ailddirwyn y iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Yn dychwelyd `None` os oes llai na elfennau `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Dyma fersiwn gefn [`Iterator::try_fold()`]: mae'n cymryd elfennau ddechrau o gefn y iterator.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Oherwydd ei fod yn fyr-gylchedig, mae'r elfennau sy'n weddill yn dal i fod ar gael trwy'r ailadroddwr.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Dull iterator sy'n lleihau elfennau y iterator i gwerth sengl, terfynol, gan ddechrau o'r cefn.
    ///
    /// Dyma fersiwn gefn [`Iterator::fold()`]: mae'n cymryd elfennau ddechrau o gefn y iterator.
    ///
    /// `rfold()` yn cymryd dwy ddadl: gwerth cychwynnol, a chau gyda dwy ddadl: 'accumulator', ac elfen.
    /// Mae cau'r dychwelyd y gwerth y dylai'r cronadur gennych ar gyfer y fersiwn nesaf.
    ///
    /// Mae gwerth cychwynnol yw gwerth y bydd y cronadur gael ar yr alwad gyntaf.
    ///
    /// Ar ôl cymhwyso'r cau hwn i bob elfen o'r ailadroddwr, mae `rfold()` yn dychwelyd y crynhowr.
    ///
    /// Weithiau gelwir y llawdriniaeth hon yn 'reduce' neu 'inject'.
    ///
    /// Plygu yn ddefnyddiol pryd bynnag y byddwch yn cael casgliad o rywbeth, ac yn awyddus i gynhyrchu gwerth unigol ohono.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // swm holl elfennau a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Mae'r enghraifft hon yn adeiladu llinyn, gan ddechrau gyda gwerth cychwynnol a pharhaus gyda phob elfen o gefn tan y blaen:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Chwiliadau am elfen o iterator o gefn y bodloni yn predicate.
    ///
    /// `rfind()` cymryd cau sy'n dychwelyd `true` neu `false`.
    /// Mae'n berthnasol cau hwn i bob elfen o'r iterator, gan ddechrau ar y diwedd, ac os bydd unrhyw un yn eu dychwelyd `true`, yna `rfind()` yn dychwelyd [`Some(element)`].
    /// Os ydyn nhw i gyd yn dychwelyd `false`, mae'n dychwelyd [`None`].
    ///
    /// `rfind()` yn fyr-gylchdroi;mewn geiriau eraill, bydd yn rhoi'r gorau i brosesu cyn gynted ag y cau yn dychwelyd `true`.
    ///
    /// Gan fod `rfind()` yn cymryd cyfeirio, ac mae llawer o iterators ailadrodd dros gyfeiriadau, mae hyn yn arwain at sefyllfa o bosibl ddryslyd lle mae'r ddadl yn gyfeiriad dwbl.
    ///
    /// Gallwch weld yr effaith hon yn yr enghreifftiau isod, gyda `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stopio ar yr `true` cyntaf:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // gallwn barhau i ddefnyddio `iter`, gan fod mwy o elfennau.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}