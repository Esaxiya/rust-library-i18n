/// Mae iterator sydd bob amser yn parhau i ildio `None` pan disbyddu.
///
/// Mae galw nesaf ar ailadroddwr wedi'i asio sydd wedi dychwelyd `None` unwaith yn sicr o ddychwelyd [`None`] eto.
/// Dylai'r trait hwn gael ei weithredu gan bob ailadroddwr sy'n ymddwyn fel hyn oherwydd ei fod yn caniatáu optimeiddio [`Iterator::fuse()`].
///
///
/// Note: Yn gyffredinol, ni ddylech ddefnyddio `FusedIterator` mewn ffiniau generig os oes angen ailadroddwr wedi'i asio arnoch.
/// Yn lle hynny, dylech chi ffonio [`Iterator::fuse()`] ar yr ailadroddwr.
/// Os yw'r iterator eisoes yn asio, bydd y [`Fuse`] lapio ychwanegol fod dim-op heb unrhyw gosb perfformiad.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Mae iterator sy'n adrodd yn hyd cywir gan ddefnyddio size_hint.
///
/// Mae'r iterator adrodd awgrym faint lle mae'n naill ai yn union (is rhwymo yn hafal i rhwymo uchaf), neu'r rhwymo uchaf yw [`None`].
///
/// Rhaid i'r rhwymiad uchaf fod yn [`None`] dim ond os yw hyd yr ailadroddwr yn fwy na [`usize::MAX`].
/// Yn yr achos hwnnw, rhaid i'r is rhwym yn [`usize::MAX`], gan arwain at [`Iterator::size_hint()`] o `(usize::MAX, None)`.
///
/// Rhaid i'r ailadroddwr gynhyrchu yn union nifer yr elfennau y gwnaeth adrodd arnynt neu eu dargyfeirio cyn cyrraedd y diwedd.
///
/// # Safety
///
/// Rhaid i hyn trait eu gweithredu ond pan fydd y contract yn cael ei chadarnhau.
/// Rhaid i ddefnyddwyr y trait hwn archwilio [`Iterator::size_hint()`]’s wedi'i rwymo uchaf.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ailadroddwr a fydd, wrth gynhyrchu eitem, wedi cymryd o leiaf un elfen o'i [`SourceIter`] sylfaenol.
///
/// Galw unrhyw ddull sy'n hybu y iterator, ee
/// [`next()`] neu [`try_fold()`], yn gwarantu bod o leiaf un gwerth o ffynhonnell sylfaenol yr ailadroddwr wedi'i symud allan ar gyfer pob cam ac y gellid mewnosod canlyniad y gadwyn ailadroddwr yn ei le, gan dybio bod cyfyngiadau strwythurol y ffynhonnell yn caniatáu mewnosod o'r fath.
///
/// Mewn geiriau eraill trait mae hyn yn dangos y gall pibell iterator yn cael ei gasglu yn ei le.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}