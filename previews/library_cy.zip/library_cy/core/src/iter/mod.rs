//! iteriad allanol Composable.
//!
//! Os ydych chi wedi dod o hyd eich hun gyda chasgliad o ryw fath, a bod angen i berfformio llawdriniaeth ar yr elfennau o gasgliad dweud, byddwch yn rhedeg i mewn i yn gyflym 'iterators'.
//! Iterators yn cael eu defnyddio yn helaeth yn y cod Rust idiomatig, felly mae'n yn werth dod yn gyfarwydd â hwy.
//!
//! Cyn egluro mwy, gadewch i ni siarad am strwythur y modiwl hwn:
//!
//! # Organization
//!
//! Mae'r modiwl hwn yn cael ei drefnu i raddau helaeth yn ôl math:
//!
//! * [Traits] yn y rhan craidd: traits mae'r rhain yn diffinio pa fath o iterators yn bodoli a'r hyn y gallwch ei wneud gyda nhw.Mae dulliau o traits rhain yn werth rhoi rhywfaint o amser astudio ychwanegol i mewn.
//! * [Functions] darparu rhai ffyrdd defnyddiol i greu rhai ailadroddwyr sylfaenol.
//! * [Structs] Yn aml, y mathau dychwelyd y gwahanol ddulliau ar traits modiwl hwn.Fel arfer, byddwch chi am edrych ar y dull sy'n creu'r `struct`, yn hytrach na'r `struct` ei hun.
//! I gael mwy o fanylion am pam, gweler '[Gweithredu Iterator](#weithredu-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Dyna ni!Gadewch i ni cloddio i mewn i iterators.
//!
//! # Iterator
//!
//! Calon ac enaid y modiwl hwn yw'r [`Iterator`] trait.Mae craidd [`Iterator`] yn edrych fel hyn:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Mae gan iterator ddull, [`next`], a oedd pan elwir, yn dychwelyd i [`Option`]`<Item>`.
//! [`next`] yn dychwelyd [`Some(Item)`] cyhyd â bod elfennau, ac unwaith y byddant i gyd wedi disbyddu, byddant yn dychwelyd `None` i nodi bod iteriad wedi'i orffen.
//! Gall iterators unigolyn ddewis i ailddechrau iteriad, ac felly yn galw [`next`] eto neu beidio yn y pen draw yn dechrau dychwelyd [`Some(Item)`] eto ar ryw adeg (er enghraifft, gweler [`TryIter`]).
//!
//!
//! Mae diffiniad llawn [`Iterator`] yn cynnwys nifer o ddulliau eraill hefyd, ond maent yn ddulliau diofyn, wedi'u hadeiladu ar ben [`next`], ac felly rydych chi'n eu cael am ddim.
//!
//! Iterators hefyd yn composable, a 'i' yn gyffredin i gadwyn nhw at ei gilydd i wneud ffurfiau mwy cymhleth o brosesu.Gweler yr adran [Adapters](#adapters) isod am ragor o fanylion.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Mae tri math o ailadrodd
//!
//! Mae tri dull cyffredin a all greu iterators o gasgliad:
//!
//! * `iter()`, sy'n ailadrodd dros `&T`.
//! * `iter_mut()`, sy'n ailadrodd dros `&mut T`.
//! * `into_iter()`, sy'n ailadrodd dros `T`.
//!
//! Gall pethau Amrywiol yn y llyfrgell safonol gweithredu un neu fwy o'r tri, lle bo hynny'n briodol.
//!
//! # Gweithredu Iterator
//!
//! Creu iterator eich hun yn cynnwys dau gam: creu `struct` i ddal y wladwriaeth y iterator, ac yna gweithredu [`Iterator`] am hynny `struct`.
//! Dyma pam mae cynifer o `struct`s yn y modiwl hwn: mae un ar gyfer pob iterator iterator ac adapter.
//!
//! Gadewch i ni wneud yn iterator enwir `Counter` sy'n cyfrif o `1` i `5`:
//!
//! ```
//! // Yn gyntaf, y strwythur:
//!
//! /// Ailadroddwr sy'n cyfrif o un i bump
//! struct Counter {
//!     count: usize,
//! }
//!
//! // rydym am i'n cyfrif i ddechrau am un, felly gadewch i ni ychwanegu dull new() i help.
//! // Nid yw hyn yn hollol angenrheidiol, ond yn gyfleus.
//! // Sylwer ein bod yn dechrau ar sero `count`, byddwn yn gweld pam wrth weithredu `next()`'s isod.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Yna, rydym yn gweithredu `Iterator` gyfer ein `Counter`:
//!
//! impl Iterator for Counter {
//!     // byddwn yn cyfrif gyda ni
//!     type Item = usize;
//!
//!     // next() yw'r dull yn unig sy'n ofynnol
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Cynyddiad ein cyfrif.Dyma pam ein bod yn dechrau ar sero.
//!         self.count += 1;
//!
//!         // Edrychwch i weld os rydym wedi cyfrif gorffenedig neu beidio.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // A nawr gallwn ei ddefnyddio!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Mae galw [`next`] fel hyn yn mynd yn ailadroddus.Mae gan Rust lluniad a all alw [`next`] ar eich iterator, nes iddo gyrraedd `None`.Gadewch i ni fynd dros hynny nesaf.
//!
//! Sylwch hefyd fod `Iterator` yn darparu dulliau diofyn o ddulliau fel `nth` a `fold` sy'n galw `next` yn fewnol.
//! Fodd bynnag, mae hefyd yn bosibl ysgrifennu gweithrediad penodol o ddulliau fel `nth` a `fold` os gall ailadroddwr eu cyfrif yn fwy effeithlon heb ffonio `next`.
//!
//! # `for` dolenni a `IntoIterator`
//!
//! cystrawen dolen `for` Rust yw gwirionedd siwgr ar gyfer iterators.Dyma enghraifft sylfaenol o `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Bydd hyn yn argraffu rhifau un drwy bump, pob un ar eu llinell eu hunain.Ond byddwch yn sylwi rhywbeth yma: yr ydym byth a elwir yn unrhyw beth ar ein vector i gynhyrchu iterator.Beth sy'n rhoi?
//!
//! Mae 'na trait yn y llyfrgell safonol ar gyfer trosi i mewn i rywbeth iterator: [`IntoIterator`].
//! Mae gan y trait hwn un dull, [`into_iter`], sy'n trosi'r peth sy'n gweithredu [`IntoIterator`] yn ailadroddwr.
//! Gadewch i ni edrych ar y `for` ddolen eto, a'r hyn y mae'r compiler dychweledigion i mewn:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-Siwgrau hyn i:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Yn gyntaf, rydym yn galw `into_iter()` ar werth.Yna, rydym yn cyd-fynd ar y iterator y ffurflenni, yn galw [`next`] drosodd a throsodd hyd nes y byddwn yn gweld `None`.
//! Ar yr adeg honno, rydym yn `break` allan o'r ddolen, ac rydym yn ei wneud ailadrodd.
//!
//! Mae yna un ychydig yn fwy cynnil yma: llyfrgell safonol yn cynnwys gweithredu diddorol o [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Hynny yw, mae pob [`Iterator`] yn gweithredu [`IntoIterator`], trwy ddychwelyd eu hunain yn unig.Mae hyn yn golygu dau beth:
//!
//! 1. Os ydych chi'n ysgrifennu [`Iterator`], gallwch ei ddefnyddio gyda dolen `for`.
//! 2. Os ydych yn creu casgliad, gweithredu [`IntoIterator`] am y bydd yn caniatáu eich casgliad i'w defnyddio gyda'r ddolen `for`.
//!
//! # Iterating trwy gyfeirnod
//!
//! Ers [`into_iter()`] yn cymryd `self` yn ôl gwerth, gan ddefnyddio dolen `for` i ailadrodd dros casgliad o yn ei ddefnyddio y casgliad.Yn aml, efallai y byddwch am ailadrodd dros casgliad heb cymryd llawer iddo.
//! Mae llawer o gasgliadau yn cynnig dulliau sy'n darparu iterators dros gyfeiriadau, a elwir yn gonfensiynol `iter()` a `iter_mut()` yn y drefn honno:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` yn parhau ym mherchnogaeth y swyddogaeth hon.
//! ```
//!
//! Os yw math o gasgliad `C` yn darparu `iter()`, mae fel arfer hefyd yn gweithredu `IntoIterator` ar gyfer `&C`, gyda gweithrediad sy'n galw `iter()` yn unig.
//! Yn yr un modd, mae casgliad `C` sy'n darparu `iter_mut()` yn gyffredinol yn gweithredu `IntoIterator` ar gyfer `&mut C` trwy ddirprwyo i `iter_mut()`.Mae hyn yn galluogi llaw-fer cyfleus:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // yr un peth â `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // un fath ag `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Er bod llawer o gasgliadau cynnig `iter()`, nid yw pob un yn cynnig `iter_mut()`.
//! Er enghraifft, gallai treiglo allweddi [`HashSet<T>`] neu [`HashMap<K, V>`] roi'r casgliad mewn cyflwr anghyson os yw'r hashes allweddol yn newid, felly dim ond `iter()` y mae'r casgliadau hyn yn ei gynnig.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Gelwir Swyddogaethau sy'n cymryd [`Iterator`] a dychwelyd [`Iterator`] arall yn aml 'addaswyr iterator', gan eu bod yn bod yn ffurf y 'adapter
//! pattern'.
//!
//! Mae addaswyr ailadroddwr cyffredin yn cynnwys [`map`], [`take`], a [`filter`].
//! I gael mwy o, gweld eu dogfennaeth.
//!
//! Os bydd iterator adapter panics, bydd y iterator fod mewn (ond cof diogel) wladwriaeth amhenodol.
//! Nid yw'r wladwriaeth hon ychwaith yn sicr o aros yr un fath ar draws fersiynau o Rust, felly dylech osgoi dibynnu ar yr union werthoedd a ddychwelwyd gan ailadroddwr a aeth i banig.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Mae Iterators (ac ailadroddwr [adapters](#adapters)) yn *ddiog*. Mae hyn yn golygu nad yw creu ailadroddwr yn _do_ yn llwyr. Nid oes dim yn digwydd nes i chi ffonio [`next`].
//! Mae hyn weithiau yn ffynhonnell o ddryswch wrth greu iterator yn unig ar gyfer ei sgîl-effeithiau.
//! Er enghraifft, y dull [`map`] yn galw cau ysgol ar bob elfen y mae'n ailadrodd drosodd:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ni fydd hyn yn argraffu unrhyw werthoedd, gan mai dim ond creu iterator, yn hytrach na defnyddio ei.Bydd y casglwr rhybuddio i ni am y math hwn o ymddygiad:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Y ffordd idiomatig i ysgrifennu [`map`] gyfer ei sgîl-effeithiau yw defnyddio dolen `for` neu ffoniwch y dull [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Ffordd gyffredin arall o werthuso ailadroddwr yw defnyddio'r dull [`collect`] i gynhyrchu casgliad newydd.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Nid oes rhaid i echdynnwyr fod yn gyfyngedig.Fel enghraifft, amrywiaeth penagored yn iterator ddiddiwedd:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Mae'n gyffredin i ddefnyddio'r adapter iterator [`take`] i droi iterator anfeidrol i mewn i un cyfyngedig:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Bydd hyn yn argraffu rhifau `0` drwy `4`, pob un ar eu llinell eu hunain.
//!
//! Cadwch mewn cof nad yw dulliau ar iterators anfeidrol, hyd yn oed y rhai y gellir canlyniad yn cael ei benderfynu yn fathemategol mewn amser cyfyngedig, yn dod i ben.
//! Yn benodol, dulliau fel [`min`], sydd yn yr achos gyffredinol yn gofyn croesi pob elfen yn y iterator, yn debygol o beidio â dychwelyd yn llwyddiannus ar gyfer unrhyw iterators ddiddiwedd.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // O na!Dolen anfeidrol!
//! // `ones.min()` achosi dolen ddiddiwedd, felly ni fyddwn yn cyrraedd y pwynt hwn!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;