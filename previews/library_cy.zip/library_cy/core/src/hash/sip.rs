//! Mae gweithredu'r SipHash.

#![allow(deprecated)] // y mathau yn y modiwl hwn yn anghymeradwyo

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Mae gweithrediad SipHash 1-3.
///
/// Mae hyn yn y swyddogaeth stwnsio rhagosodedig a ddefnyddir gan lyfrgell safonol (ee, `collections::HashMap` yn ei ddefnyddio yn ddiofyn) ar hyn o bryd.
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Mae gweithrediad SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Mae gweithrediad SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash yn swyddogaeth stwnsio cyffredinol-bwrpas: mae'n rhedeg ar gyflymder da (gystadleuol gyda Spooky a City) ac yn caniatáu stwnsio _keyed_ cryf.
///
/// Mae hyn yn gadael i chi allweddol eich tablau hash o RNG cryf, megis [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Er bod y algorithm SipHash yn cael ei ystyried i fod yn gryf yn gyffredinol, ni fwriedir ar gyfer dibenion cryptograffig.
/// Fel y cyfryw, pob defnydd cryptographic gweithredu hwn yw _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // faint o bytes rydyn ni wedi'u prosesu
    state: State,  // Wladwriaeth hash
    tail: u64,     // heb eu prosesu bytes le
    ntail: usize,  // faint o bytes mewn cynffon yn ddilys
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 a v1, v3 arddangos i fyny mewn parau yn y algorithm, a bydd gweithrediadau SIMD o SipHash defnyddio vectors o v02 a v13.
    //
    // Trwy eu rhoi yn y drefn hon yn y strwythur, gall y casglwr nodi ychydig o optimeiddiadau simd ynddo'i hun.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Llwythi yn gyfanrif o'r math a ddymunir o nant beit, er LE.
/// Yn defnyddio `copy_nonoverlapping` i adael i'r casglwr gynhyrchu'r ffordd fwyaf effeithlon i'w lwytho o gyfeiriad a allai fod heb ei lofnodi.
///
///
/// Anniogel oherwydd: mynegeio heb ei wirio yn i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Llwythi a u64 yn defnyddio hyd at 7 bytes o sleisen beit.
/// Mae'n edrych galwadau trwsgl, ond mae'r `copy_nonoverlapping` sy'n digwydd (drwy `load_int_le!`) i gyd wedi gosod maint a osgoi galw `memcpy`, sy'n dda ar gyfer cyflymder.
///
///
/// oherwydd anniogel: mynegeio unchecked yn start..start + Len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // Mynegai beit cyfredol (o'r BGLl) yn yr allbwn u64
    let mut out = 0;
    if i + 3 < len {
        // DIOGELWCH: Ni all `i` fod yn fwy na `len`, ac mae'r warant rhaid galwr
        // bod y mynegai cychwyn..start + len mewn ffiniau.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // DIOGELWCH: yr un fath ag uchod.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // DIOGELWCH: yr un fath ag uchod.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Creu `SipHasher` newydd gyda'r ddau allweddi cychwynnol osod i 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Creu `SipHasher` sy'n cael ei keyed oddi ar yr allweddi a ddarperir.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Creu `SipHasher13` newydd gyda'r ddau allweddi cychwynnol osod i 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Yn creu `SipHasher13` sydd wedi'i allweddi oddi ar yr allweddi a ddarperir.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: dim cyfanrif dulliau stwnsio (`write_u *`, `write_i*`) eu diffinio
    // ar gyfer y math hwn.
    // Gallem eu hychwanegu, copïo gweithrediad `short_write` yn librustc_data_structures/sip128.rs, ac ychwanegu dulliau `write_u *`/`write_i*` at `SipHasher`, `SipHasher13`, a `DefaultHasher`.
    //
    // Byddai hyn yn cyflymu yn fawr i fyny stwnsio cyfanrif gan hashers hynny, ar y gost o ychydig yn arafu cyflymder crynhoi ar rai meincnodau.
    // Gweler #69152 am fanylion.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // DIOGELWCH: Gwarantir na fydd `cmp::min(length, needed)` dros `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // cynffon buffered awr yn fflysio, prosesu mewnbwn newydd.
        let len = length - needed;
        let left = len & 0x7; // Len% 8

        let mut i = needed;
        while i < len - left {
            // DIOGELWCH: oherwydd `len - left` yw'r lluosog mwyaf o 8 dan
            // `len`, ac oherwydd bod `i` yn cychwyn yn `needed` lle mae `len` yn `length - needed`, mae `i + 8` yn sicr o fod yn llai na neu'n hafal i `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // DIOGELWCH: Mae `i` bellach yn `needed + len.div_euclid(8) * 8`,
        // felly `i + left` = `needed + len` = `length`, sydd drwy ddiffiniad cyfartal i `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Yn creu `Hasher<S>` gyda'r ddwy allwedd gychwynnol wedi'u gosod i 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}