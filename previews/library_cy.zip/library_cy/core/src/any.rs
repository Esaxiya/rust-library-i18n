//! Mae'r modiwl hwn yn gweithredu y `Any` trait, sy'n galluogi teipio deinamig o unrhyw fath `'static` trwy fyfyrio Rhedeg.
//!
//! `Any` Gellir ei hun yn cael ei ddefnyddio i gael `TypeId`, a bod ganddo fwy o nodweddion pan gaiff ei ddefnyddio fel gwrthrych trait.
//! Fel `&dyn Any` (gwrthrych trait a fenthycwyd), mae ganddo'r dulliau `is` a `downcast_ref`, i brofi a yw'r gwerth a gynhwysir o fath penodol, ac i gael cyfeiriad at y gwerth mewnol fel math.
//! Fel `&mut dyn Any`, mae yna hefyd y dull `downcast_mut`, ar gyfer cael cyfeiriad symudol at y gwerth mewnol.
//! `Box<dyn Any>` yn ychwanegu dull `downcast`, pa ymdrechion i drosi i `Box<T>`.
//! Gweler y dogfennau [`Box`] gyfer y manylion llawn.
//!
//! Sylwch fod `&dyn Any` wedi'i gyfyngu i brofi a yw gwerth o fath concrit penodol, ac ni ellir ei ddefnyddio i brofi a yw math yn gweithredu trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Awgrymiadau Smart a `dyn Any`
//!
//! Un darn o ymddygiad i'w gadw mewn cof wrth ddefnyddio `Any` fel gwrthrych trait, yn enwedig gyda mathau fel `Box<dyn Any>` neu `Arc<dyn Any>`, yw y bydd galw `.type_id()` ar y gwerth yn cynhyrchu `TypeId` y *cynhwysydd*, nid y gwrthrych trait sylfaenol.
//!
//! Gellir osgoi hyn drwy drosi pwyntydd smart i mewn i `&dyn Any` yn lle hynny, a fydd yn dychwelyd `TypeId` y gwrthrych.
//! Er enghraifft:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Rydych yn fwy tebygol o fod eisiau hyn:
//! let actual_id = (&*boxed).type_id();
//! // ... na hyn:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Ystyriwch sefyllfa lle rydym eisiau allgofnodi gwerth trosglwyddo i'r swyddogaeth.
//! Rydyn ni'n gwybod y gwerth rydyn ni'n gweithio arno yn gweithredu Debug, ond nid ydym yn gwybod ei fath concrit.Rydym am roi triniaeth arbennig i rai mathau: yn yr achos hwn argraffu hyd gwerthoedd Llinynnol cyn eu gwerth.
//! Nid ydym yn gwybod pa fath concrid ein gwerth ar adeg crynhoi, felly mae angen i ddefnyddio myfyrio Rhedeg yn lle hynny.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // swyddogaeth Cofnodydd ar gyfer unrhyw fath bod offer Dadnamu.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Ceisiwch i drosi ein gwerth i `String`.
//!     // Os yn llwyddiannus, rydym am allbwn hyd y Llinyn yn ogystal â'i werth.
//!     // Os na, mae'n fath gwahanol: dim ond ei argraffu heb ei addurno.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Mae'r swyddogaeth hon am allgofnodi ei baramedr cyn gwneud gwaith ag ef.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... wneud rhywfaint o waith arall
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Unrhyw trait
///////////////////////////////////////////////////////////////////////////////

/// trait i efelychu teipio deinamig.
///
/// Mae'r mwyafrif o fathau yn gweithredu `Any`.Fodd bynnag, nid yw unrhyw fath sy'n cynnwys cyfeiriad nad yw'n `'static` wneud.
/// Gweler y [module-level documentation][mod] am fwy o fanylion.
///
/// [mod]: crate::any
// Nid yw'r trait hwn yn anniogel, er ein bod yn dibynnu ar fanylion ei swyddogaeth `type_id` unig impl mewn cod anniogel (ee, `downcast`).Fel arfer, byddai hynny'n broblem, ond oherwydd yr unig impl o `Any` yn gweithredu blanced, ni all unrhyw cod arall yn gweithredu `Any`.
//
// Gallem wneud y trait hwn yn anniogel yn gredadwy-ni fyddai'n achosi torri, gan ein bod yn rheoli'r holl weithrediadau-ond rydym yn dewis peidio â gwneud hynny gan nad yw hynny'n angenrheidiol mewn gwirionedd a gallwn ddrysu defnyddwyr ynghylch gwahaniaethu traits anniogel a dulliau anniogel (h.y., byddai `type_id` yn dal i fod yn ddiogel i alw, ond byddem yn debygol o eisiau nodi fel y cyfryw mewn dogfennaeth).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Yn cael yr `TypeId` o `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Dulliau estyn ar gyfer Unrhyw wrthrychau trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Sicrhewch y gellir argraffu canlyniad ee, ymuno ag edau ac felly ei ddefnyddio gyda `unwrap`.
// Yn y pen draw, ni fydd angen mwyach os bydd anfon yn gweithio gyda diweddaru.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Yn dychwelyd `true` os yw'r math mewn bocs yr un peth â `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Cael `TypeId` o'r math swyddogaeth hon yn cael ei instantiated gyda.
        let t = TypeId::of::<T>();

        // Cael `TypeId` o'r math yn y gwrthrych trait (`self`).
        let concrete = self.type_id();

        // Cymharwch y ddau `TypeId 'ar gydraddoldeb.
        t == concrete
    }

    /// Yn dychwelyd rhywfaint o gyfeiriad at y gwerth mewn bocs os yw o fath `T`, neu `None` os nad ydyw.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // DIOGELWCH: newydd wirio a ydym yn pwyntio at y math cywir, a gallwn ddibynnu arno
            // sy'n gwirio am ddiogelwch cof oherwydd ein bod wedi gweithredu Unrhyw un ar gyfer pob math;dim Gall impls eraill yn bodoli fel y byddent yn gwrthdaro â'n impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Dychwelyd rhai cyfeiriadau mutable at werth blwch os yw o fath `T`, neu `None` os nad yw'n.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // DIOGELWCH: newydd wirio a ydym yn pwyntio at y math cywir, a gallwn ddibynnu arno
            // sy'n gwirio am ddiogelwch cof oherwydd ein bod wedi gweithredu Unrhyw un ar gyfer pob math;dim Gall impls eraill yn bodoli fel y byddent yn gwrthdaro â'n impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Blaenwyr at y dull a ddiffinnir ar y math `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Blaenwyr at y dull a ddiffinnir ar y math `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Blaenwyr at y dull a ddiffinnir ar y math `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Blaenwyr at y dull a ddiffinnir ar y math `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Blaenwyr at y dull a ddiffinnir ar y math `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Blaenwyr at y dull a ddiffinnir ar y math `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID a'i ddulliau
///////////////////////////////////////////////////////////////////////////////

/// A `TypeId` yn cynrychioli dynodwr unigryw cyffredin am fath.
///
/// Mae pob `TypeId` yn wrthrych afloyw nad yw'n caniatáu archwilio'r hyn sydd y tu mewn ond sy'n caniatáu gweithrediadau sylfaenol fel clonio, cymharu, argraffu a dangos.
///
///
/// Ar hyn o bryd dim ond ar gyfer mathau sy'n priodoli i `'static` y mae `TypeId` ar gael, ond gellir dileu'r cyfyngiad hwn yn y future.
///
/// Tra `TypeId` yn gweithredu `Hash`, `PartialOrd`, ac `Ord`, mae'n werth nodi y bydd y hashes ac archebu yn amrywio rhwng datganiadau Rust.
/// Gwyliwch rhag dibynnu arnyn nhw y tu mewn i'ch cod!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Dychwelyd y `TypeId` o'r math swyddogaeth generig hwn wedi cael ei instantiated gyda.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Dychwelyd enw o fath fel tafell llinyn.
///
/// # Note
///
/// Mae hyn wedi'i fwriadu ar gyfer defnydd diagnostig.
/// Nid yw union gynnwys a fformat y llinyn a ddychwelwyd yn cael eu nodi, ac eithrio bod disgrifiad gorau-ymdrech o'r math.
/// Er enghraifft, ymhlith y tannau y gallai `type_name::<Option<String>>()` eu dychwelyd mae `"Option<String>"` a `"std::option::Option<std::string::String>"`.
///
///
/// Ni ddylai'r llinyn dychwelyd yn cael eu hystyried i fod yn adnabod unigryw o fath gan y gall mathau lluosog map i un enw math.
/// Yn yr un modd, nid oes unrhyw sicrwydd y bydd pob rhan o fath yn ymddangos yn y llinyn a ddychwelwyd: er enghraifft, nid oes manylebwyr yn cael eu cynnwys ar hyn o bryd.
/// Yn ogystal, gall yr allbwn newid rhwng fersiynau o'r crynhoydd.
///
/// Mae gweithredu'r presennol yn defnyddio'r un isadeiledd fel diagnosteg compiler a debuginfo, ond nid yw hyn yn cael ei warantu.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Dychwelyd enw'r math yr pigfain-i werth fel tafell llinyn.
/// Mae hyn yr un fath â `type_name::<T>()`, ond gellir eu defnyddio lle nad y math o newidyn ar gael yn rhwydd.
///
/// # Note
///
/// Mae hwn wedi'i fwriadu ar gyfer defnydd diagnostig.Nid yw union gynnwys a fformat y llinyn yn cael eu nodi, ac eithrio bod disgrifiad gorau-ymdrech o'r math.
/// Er enghraifft, gallai `type_name_of_val::<Option<String>>(None)` ddychwelyd `"Option<String>"` neu `"std::option::Option<std::string::String>"`, ond nid `"foobar"`.
///
/// Yn ogystal, gall yr allbwn newid rhwng fersiynau o'r crynhoydd.
///
/// Nid yw'r swyddogaeth hon yn datrys gwrthrychau trait, sy'n golygu y gall `type_name_of_val(&7u32 as &dyn Debug)` ddychwelyd `"dyn Debug"`, ond nid `"u32"`.
///
/// Ni ddylid ystyried enw'r math yn ddynodwr unigryw o fath;
/// gall sawl math rannu'r un enw math.
///
/// Mae gweithredu'r presennol yn defnyddio'r un isadeiledd fel diagnosteg compiler a debuginfo, ond nid yw hyn yn cael ei warantu.
///
/// # Examples
///
/// Yn argraffu'r cyfanrif diofyn a'r mathau arnofio.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}