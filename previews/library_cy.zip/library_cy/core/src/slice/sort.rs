//! Didoli sleisys
//!
//! Mae'r modiwl hwn yn cynnwys algorithm didoli yn seiliedig ar quicksort sy'n trechu patrwm Orson Peters, a gyhoeddwyd yn: <https://github.com/orlp/pdqsort>
//!
//!
//! Mae didoli ansefydlog yn gydnaws â libcore oherwydd nid yw'n dyrannu'r cof, yn wahanol i'n gweithrediad didoli sefydlog.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Pan ollyngir nhw, copïau o `src` i `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // DIOGELWCH: Dosbarth cynorthwyydd yw hwn.
        //          Cyfeiriwch at ei ddefnydd er mwyn cywirdeb.
        //          Sef, rhaid sicrhau nad yw `src` a `dst` yn gorgyffwrdd fel sy'n ofynnol gan `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Yn symud yr elfen gyntaf i'r dde nes ei bod yn dod ar draws elfen fwy neu gyfartal.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // DIOGELWCH: Mae'r gweithrediadau anniogel isod yn cynnwys mynegeio heb wiriad wedi'i rwymo (`get_unchecked` a `get_unchecked_mut`)
    // a chopïo cof (`ptr::copy_nonoverlapping`).
    //
    // a.mynegeio:
    //  1. Gwnaethom wirio maint yr arae i>=2.
    //  2. Mae'r holl fynegeio y byddwn yn ei wneud bob amser rhwng {0 <= index < len} ar y mwyaf.
    //
    // b.Copïo cof
    //  1. Rydym yn cael awgrymiadau ar gyfer tystlythyrau sy'n sicr o fod yn ddilys.
    //  2. Ni allant orgyffwrdd oherwydd ein bod yn cael awgrymiadau ar fynegeion gwahaniaeth y dafell.
    //     Sef, `i` a `i-1`.
    //  3. Os yw'r sleisen wedi'i alinio'n iawn, mae'r elfennau wedi'u halinio'n iawn.
    //     Cyfrifoldeb y galwr yw sicrhau bod y dafell wedi'i halinio'n iawn.
    //
    // Gweler y sylwadau isod am fanylion pellach.
    unsafe {
        // Os yw'r ddwy elfen gyntaf allan o drefn ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Darllenwch yr elfen gyntaf i mewn i newidyn wedi'i ddyrannu pentwr.
            // Os yw gweithrediad cymhariaeth ganlynol panics, bydd `hole` yn cael ei ollwng ac yn ysgrifennu'r elfen yn ôl i'r sleisen yn awtomatig.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Symudwch elfen `i`-th un lle i'r chwith, gan symud y twll i'r dde.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` yn cael ei ollwng ac felly'n copïo `tmp` i'r twll sy'n weddill yn `v`.
        }
    }
}

/// Yn symud yr elfen olaf i'r chwith nes ei bod yn dod ar draws elfen lai neu gyfartal.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // DIOGELWCH: Mae'r gweithrediadau anniogel isod yn cynnwys mynegeio heb wiriad wedi'i rwymo (`get_unchecked` a `get_unchecked_mut`)
    // a chopïo cof (`ptr::copy_nonoverlapping`).
    //
    // a.mynegeio:
    //  1. Gwnaethom wirio maint yr arae i>=2.
    //  2. Mae'r holl fynegeio y byddwn yn ei wneud bob amser rhwng `0 <= index < len-1` ar y mwyaf.
    //
    // b.Copïo cof
    //  1. Rydym yn cael awgrymiadau ar gyfer tystlythyrau sy'n sicr o fod yn ddilys.
    //  2. Ni allant orgyffwrdd oherwydd ein bod yn cael awgrymiadau ar fynegeion gwahaniaeth y dafell.
    //     Sef, `i` a `i+1`.
    //  3. Os yw'r sleisen wedi'i alinio'n iawn, mae'r elfennau wedi'u halinio'n iawn.
    //     Cyfrifoldeb y galwr yw sicrhau bod y dafell wedi'i halinio'n iawn.
    //
    // Gweler y sylwadau isod am fanylion pellach.
    unsafe {
        // Os yw'r ddwy elfen olaf allan o drefn ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Darllenwch yr elfen olaf yn newidyn a ddyrannwyd ar gyfer pentwr.
            // Os yw gweithrediad cymhariaeth ganlynol panics, bydd `hole` yn cael ei ollwng ac yn ysgrifennu'r elfen yn ôl i'r sleisen yn awtomatig.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Symudwch elfen `i`-th un lle i'r dde, gan symud y twll i'r chwith.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` yn cael ei ollwng ac felly'n copïo `tmp` i'r twll sy'n weddill yn `v`.
        }
    }
}

/// Yn rhannol didoli sleisen trwy symud sawl elfen allan o drefn o gwmpas.
///
/// Yn dychwelyd `true` os yw'r sleisen wedi'i didoli ar y diwedd.Y swyddogaeth hon yw *O*(*n*) achos gwaethaf.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Uchafswm nifer y parau y tu allan i'r drefn cyfagos a fydd yn cael eu symud.
    const MAX_STEPS: usize = 5;
    // Os yw'r sleisen yn fyrrach na hyn, peidiwch â symud unrhyw elfennau.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // DIOGELWCH: Gwnaethom eisoes y gwirio rhwym gyda `i < len`.
        // Dim ond yn yr ystod `0 <= index < len` y mae ein holl fynegeio dilynol
        unsafe {
            // Dewch o hyd i'r pâr nesaf o elfennau allan o drefn cyfagos.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ydyn ni'n gwneud?
        if i == len {
            return true;
        }

        // Peidiwch â symud elfennau ar araeau byr, sydd â chost perfformiad.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Cyfnewid y pâr o elfennau a ddarganfuwyd.Mae hyn yn eu rhoi mewn trefn gywir.
        v.swap(i - 1, i);

        // Symudwch yr elfen lai i'r chwith.
        shift_tail(&mut v[..i], is_less);
        // Symudwch yr elfen fwy i'r dde.
        shift_head(&mut v[i..], is_less);
    }

    // Heb lwyddo i ddidoli'r dafell yn y nifer gyfyngedig o gamau.
    false
}

/// Yn didoli sleisen gan ddefnyddio math mewnosod, sef *O*(*n*^ 2) yn yr achos gwaethaf.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Yn didoli `v` gan ddefnyddio heapsort, sy'n gwarantu *O*(*n*\*log(* n*)) achos gwaethaf.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mae'r domen ddeuaidd hon yn parchu'r `parent >= child` invariant.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Plant `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Dewiswch y plentyn mwy.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stopiwch os yw'r invariant yn dal yn `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Cyfnewid `node` gyda'r plentyn mwyaf, symud un cam i lawr, a pharhau i ogwyddo.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Adeiladu'r domen mewn amser llinellol.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elfennau mwyaf posibl o'r domen.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Rhaniadau `v` yn elfennau llai na `pivot`, ac yna elfennau sy'n fwy na neu'n hafal i `pivot`.
///
///
/// Yn dychwelyd nifer yr elfennau sy'n llai na `pivot`.
///
/// Gwneir rhaniad bloc-wrth-floc er mwyn lleihau cost gweithrediadau canghennog.
/// Cyflwynir y syniad hwn yn y papur [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Nifer yr elfennau mewn bloc nodweddiadol.
    const BLOCK: usize = 128;

    // Mae'r algorithm rhannu yn ailadrodd y camau canlynol nes ei gwblhau:
    //
    // 1. Olrheiniwch floc o'r ochr chwith i nodi elfennau sy'n fwy na neu'n hafal i'r colyn.
    // 2. Olrheiniwch floc o'r ochr dde i nodi elfennau llai na'r colyn.
    // 3. Cyfnewid yr elfennau a nodwyd rhwng yr ochr chwith a'r dde.
    //
    // Rydym yn cadw'r newidynnau canlynol ar gyfer bloc o elfennau:
    //
    // 1. `block` - Nifer yr elfennau yn y bloc.
    // 2. `start` - Dechreuwch y pwyntydd i mewn i'r arae `offsets`.
    // 3. `end` - Diwedd pwyntydd i mewn i'r arae `offsets`.
    // 4. `gwrthbwyso, Mynegeion elfennau y tu allan i drefn yn y bloc.

    // Y bloc cyfredol ar yr ochr chwith (o `l` i `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Y bloc cyfredol ar yr ochr dde (o `r.sub(block_r)` to `r`).
    // DIOGELWCH: Mae'r ddogfennaeth ar gyfer .add() yn sôn yn benodol bod `vec.as_ptr().add(vec.len())` bob amser yn ddiogel`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Pan gawn VLAs, ceisiwch greu un amrywiaeth o hyd `min(v.len(), 2 * BLOCK) `yn hytrach
    // na dau arae maint sefydlog o hyd `BLOCK`.Gallai VLAs fod yn fwy effeithlon o ran storfa.

    // Yn dychwelyd nifer yr elfennau rhwng awgrymiadau `l` (inclusive) a `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Rydym yn gwneud gyda rhannu'ch bloc-wrth-bloc pan `l` a `r` mynd yn agos iawn.
        // Yna rydyn ni'n gwneud rhywfaint o waith clytio er mwyn rhannu'r elfennau sy'n weddill rhyngddynt.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Nifer yr elfennau sy'n weddill (heb eu cymharu â'r colyn o hyd).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Addaswch feintiau bloc fel nad yw'r bloc chwith a dde yn gorgyffwrdd, ond eu halinio'n berffaith i gwmpasu'r bwlch sy'n weddill.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Olrhain elfennau `block_l` o'r ochr chwith.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // DIOGELWCH: Mae'r gweithrediadau anniogelrwydd isod yn cynnwys defnyddio'r `offset`.
                //         Yn ôl yr amodau sy'n ofynnol gan y swyddogaeth, rydym yn eu bodloni oherwydd:
                //         1. `offsets_l` yn cael ei ddyrannu ar gyfer pentyrrau, ac felly'n cael ei ystyried yn wrthrych wedi'i ddyrannu ar wahân.
                //         2. Mae'r swyddogaeth `is_less` yn dychwelyd `bool`.
                //            Ni fydd castio `bool` byth yn gorlifo `isize`.
                //         3. Rydym wedi gwarantu y bydd `block_l` yn `<= BLOCK`.
                //            Hefyd, gosodwyd `end_l` i bwyntydd cychwyn `offsets_` i ddechrau a ddatganwyd ar y pentwr.
                //            Felly, rydym yn gwybod hyd yn oed yn yr achos gwaethaf (mae pob gwahoddiad o `is_less` yn dychwelyd yn ffug) mai dim ond 1 beit fydd yn pasio'r diwedd ar y mwyaf.
                //        Gweithrediad anniogel arall yma yw dadreoleiddio `elem`.
                //        Fodd bynnag, i ddechrau, `elem` oedd pwyntydd cychwyn y dafell sydd bob amser yn ddilys.
                unsafe {
                    // Cymhariaeth heb ganghennau.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Olrhain elfennau `block_r` o'r ochr dde.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // DIOGELWCH: Mae'r gweithrediadau anniogelrwydd isod yn cynnwys defnyddio'r `offset`.
                //         Yn ôl yr amodau sy'n ofynnol gan y swyddogaeth, rydym yn eu bodloni oherwydd:
                //         1. `offsets_r` yn cael ei ddyrannu ar gyfer pentyrrau, ac felly'n cael ei ystyried yn wrthrych wedi'i ddyrannu ar wahân.
                //         2. Mae'r swyddogaeth `is_less` yn dychwelyd `bool`.
                //            Ni fydd castio `bool` byth yn gorlifo `isize`.
                //         3. Rydym wedi gwarantu y bydd `block_r` yn `<= BLOCK`.
                //            Hefyd, gosodwyd `end_r` i bwyntydd cychwyn `offsets_` i ddechrau a ddatganwyd ar y pentwr.
                //            Felly, rydym yn gwybod hyd yn oed yn yr achos gwaethaf (mae pob gwahoddiad o ffurflenni `is_less` yn wir) mai dim ond 1 beit fydd yn pasio'r diwedd ar y mwyaf.
                //        Gweithrediad anniogel arall yma yw dadreoleiddio `elem`.
                //        Fodd bynnag, roedd `elem` i ddechrau `1 *sizeof(T)` heibio'r diwedd ac rydym yn ei ostwng gan `1* sizeof(T)` cyn ei gyrchu.
                //        Hefyd, honnwyd bod `block_r` yn llai na `BLOCK` ac felly bydd `elem` felly'n pwyntio at ddechrau'r sleisen ar y mwyaf.
                unsafe {
                    // Cymhariaeth heb ganghennau.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Nifer yr elfennau allan o drefn i'w cyfnewid rhwng yr ochr chwith a'r ochr dde.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Yn lle cyfnewid un pâr ar y pryd, mae'n fwy effeithlon perfformio mewnlifiad cylchol.
            // Nid yw hyn yn hollol gyfwerth â chyfnewid, ond mae'n cynhyrchu canlyniad tebyg gan ddefnyddio llai o weithrediadau cof.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Symudwyd yr holl elfennau allan o drefn yn y bloc chwith.Symud i'r bloc nesaf.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Symudwyd yr holl elfennau allan o drefn yn y bloc cywir.Symud i'r bloc blaenorol.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Y cyfan sy'n weddill nawr yw un bloc ar y mwyaf (naill ai'r chwith neu'r dde) gydag elfennau y tu allan i drefn y mae angen eu symud.
    // Gellir symud elfennau sy'n weddill o'r fath i'r diwedd yn eu bloc.
    //

    if start_l < end_l {
        // Erys y bloc chwith.
        // Symudwch yr elfennau sydd allan o drefn sy'n weddill i'r dde eithaf.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Erys y bloc cywir.
        // Symudwch yr elfennau sydd allan o drefn sy'n weddill i'r chwith eithaf.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Dim byd arall i'w wneud, rydyn ni wedi gwneud.
        width(v.as_mut_ptr(), l)
    }
}

/// Rhaniadau `v` yn elfennau llai na `v[pivot]`, ac yna elfennau sy'n fwy na neu'n hafal i `v[pivot]`.
///
///
/// Yn dychwelyd twple o:
///
/// 1. Nifer yr elfennau llai na `v[pivot]`.
/// 2. Gwir os oedd `v` eisoes wedi'i rannu.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Rhowch y colyn ar ddechrau'r sleisen.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Darllenwch y colyn yn newidyn a ddyrannwyd ar gyfer pentwr er mwyn effeithlonrwydd.
        // Os bydd yn dilyn llawdriniaeth cymhariaeth panics, bydd y colyn yn cael ei ysgrifennu yn awtomatig yn ôl i mewn i'r dafell.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Dewch o hyd i'r pâr cyntaf o elfennau allan o drefn.
        let mut l = 0;
        let mut r = v.len();

        // DIOGELWCH: Mae'r anniogelrwydd isod yn cynnwys mynegeio arae.
        // Am yr un cyntaf: Rydym eisoes yn gwneud y ffiniau yn gwirio yma gyda `l < r`.
        // Ar gyfer yr ail un: Mae gennym `l == 0` a `r == v.len()` i ddechrau a gwnaethom wirio bod `l < r` ym mhob gweithrediad mynegeio.
        //                     O'r fan hon rydym yn gwybod bod yn rhaid i `r` fod yn `r == l` o leiaf y dangoswyd ei fod yn ddilys o'r un cyntaf.
        unsafe {
            // Darganfyddwch yr elfen gyntaf sy'n fwy na neu'n hafal i'r colyn.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Darganfyddwch yr elfen olaf yn llai na'r colyn.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` yn mynd allan o'i gwmpas ac yn ysgrifennu'r colyn (sy'n newidyn a ddyrannwyd ar gyfer pentwr) yn ôl i'r sleisen lle'r oedd yn wreiddiol.
        // Mae'r cam hwn yn hollbwysig er mwyn sicrhau diogelwch!
        //
    };

    // Rhowch y colyn rhwng y ddau raniad.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Rhaniadau `v` yn elfennau sy'n hafal i `v[pivot]` ac yna elfennau sy'n fwy na `v[pivot]`.
///
/// Yn dychwelyd nifer yr elfennau sy'n hafal i'r colyn.
/// Tybir nad yw `v` yn cynnwys elfennau llai na'r colyn.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Rhowch y colyn ar ddechrau'r sleisen.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Darllenwch y colyn yn newidyn a ddyrannwyd ar gyfer pentwr er mwyn effeithlonrwydd.
    // Os bydd yn dilyn llawdriniaeth cymhariaeth panics, bydd y colyn yn cael ei ysgrifennu yn awtomatig yn ôl i mewn i'r dafell.
    // DIOGELWCH: Mae'r pwyntydd yma yn ddilys oherwydd ei fod ar gael o gyfeiriad at dafell.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Nawr rhannwch y dafell.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // DIOGELWCH: Mae'r anniogelrwydd isod yn cynnwys mynegeio arae.
        // Am yr un cyntaf: Rydym eisoes yn gwneud y ffiniau yn gwirio yma gyda `l < r`.
        // Ar gyfer yr ail un: Mae gennym `l == 0` a `r == v.len()` i ddechrau a gwnaethom wirio bod `l < r` ym mhob gweithrediad mynegeio.
        //                     O'r fan hon rydym yn gwybod bod yn rhaid i `r` fod yn `r == l` o leiaf y dangoswyd ei fod yn ddilys o'r un cyntaf.
        unsafe {
            // Darganfyddwch yr elfen gyntaf yn fwy na'r colyn.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Darganfyddwch yr elfen olaf sy'n hafal i'r colyn.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ydyn ni'n gwneud?
            if l >= r {
                break;
            }

            // Cyfnewid y pâr o elfennau y tu allan i drefn.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Gwelsom elfennau `l` yn hafal i'r colyn.Ychwanegwch 1 i gyfrif am y colyn ei hun.
    l + 1

    // `_pivot_guard` yn mynd allan o'i gwmpas ac yn ysgrifennu'r colyn (sy'n newidyn a ddyrannwyd ar gyfer pentwr) yn ôl i'r sleisen lle'r oedd yn wreiddiol.
    // Mae'r cam hwn yn hollbwysig er mwyn sicrhau diogelwch!
}

/// Yn gwasgaru rhai elfennau o gwmpas mewn ymgais i dorri patrymau a allai achosi rhaniadau anghytbwys mewn quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generadur rhif ffug o'r papur "Xorshift RNGs" gan George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Cymerwch modulo rhifau ar hap y rhif hwn.
        // Mae'r nifer yn ffitio i `usize` oherwydd nad yw `len` yn fwy na `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Bydd rhai ymgeiswyr colyn yn y mynegai hwn gerllaw.Gadewch i ni eu hapoli.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Cynhyrchu modulo rhif ar hap `len`.
            // Fodd bynnag, er mwyn osgoi gweithrediadau costus, rydym yn gyntaf yn cymryd pŵer o ddau i modulo, ac yna'n gostwng `len` nes ei fod yn ffitio i'r ystod `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` yn sicr o fod yn llai na `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Yn dewis colyn yn `v` ac yn dychwelyd y mynegai a `true` os yw'r sleisen yn debygol eisoes wedi'i didoli.
///
/// Efallai y bydd elfennau yn `v` yn cael eu had-drefnu yn y broses.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Hyd lleiaf i ddewis y dull canolrif-canolrifau.
    // Mae sleisys byrrach yn defnyddio'r dull canolrif-o-dri syml.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Uchafswm y cyfnewidiadau y gellir eu perfformio yn y swyddogaeth hon.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tri mynegai yr ydym yn mynd i ddewis colyn gerllaw.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Yn cyfrif cyfanswm y cyfnewidiadau rydyn ni ar fin eu perfformio wrth ddidoli mynegeion.
    let mut swaps = 0;

    if len >= 8 {
        // Cyfnewid mynegeion fel bod `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Cyfnewid mynegeion fel bod `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Yn darganfod canolrif `v[a - 1], v[a], v[a + 1]` ac yn storio'r mynegai yn `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Dewch o hyd i ganolrifoedd yng nghymdogaethau `a`, `b`, a `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Dewch o hyd i'r canolrif ymhlith `a`, `b`, a `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Perfformiwyd y nifer uchaf o gyfnewidiadau.
        // Mae'n debygol bod y sleisen yn disgyn neu'n disgyn yn bennaf, felly mae'n debyg y bydd gwrthdroi yn helpu i'w didoli'n gyflymach.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Yn didoli `v` yn gylchol.
///
/// Os oedd gan y dafell ragflaenydd yn yr arae wreiddiol, fe'i nodir fel `pred`.
///
/// `limit` yw nifer y rhaniadau anghytbwys a ganiateir cyn newid i `heapsort`.
/// Os yw'n sero, bydd y swyddogaeth hon yn newid i heapsort ar unwaith.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mae tafelli hyd at y darn hwn yn cael eu didoli gan ddefnyddio math mewnosod.
    const MAX_INSERTION: usize = 20;

    // Gwir a oedd y rhaniad olaf yn weddol gytbwys.
    let mut was_balanced = true;
    // Gwir os nad oedd y rhaniad olaf yn siffrwd elfennau (roedd y sleisen eisoes wedi'i rhannu).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Mae sleisys byr iawn yn cael eu didoli gan ddefnyddio math mewnosod.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pe bai gormod o ddewisiadau colyn gwael yn cael eu gwneud, dim ond cwympo yn ôl i heapsort er mwyn gwarantu achos gwaethaf `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Os oedd y rhaniad olaf yn anghytbwys, ceisiwch dorri patrymau yn y dafell trwy symud rhai elfennau o gwmpas.
        // Gobeithio y byddwn yn dewis colyn gwell y tro hwn.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Dewiswch golyn a cheisiwch ddyfalu a yw'r sleisen eisoes wedi'i didoli.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Pe bai'r rhaniad olaf yn gytbwys iawn ac nad oedd yn siffrwd elfennau, ac os yw dewis colyn yn rhagweld bydd y sleisen yn debygol o gael ei didoli eisoes ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Ceisiwch nodi sawl elfen allan o drefn a'u symud i swyddi cywir.
            // Os bydd y dafell yn cael ei didoli'n llwyr, rydyn ni'n gwneud.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Os bydd y colyn a ddewiswyd yn hafal i'r rhagflaenydd, yna mae'n elfen lleiaf yn y sleisen.
        // Rhannwch y dafell yn elfennau sy'n hafal i'r colyn ac elfennau sy'n fwy na'r colyn.
        // Mae'r achos hwn fel arfer yn cael ei daro pan fydd y sleisen yn cynnwys llawer o elfennau dyblyg.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Parhewch i ddidoli elfennau sy'n fwy na'r colyn.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Rhannwch y dafell.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Rhannwch y dafell i mewn i `left`, `pivot`, a `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse i mewn i ochr byrrach yn unig er mwyn lleihau cyfanswm nifer y galwadau ailadroddus ac yfed gofod llai corn.
        // Yna parhewch â'r ochr hirach (mae hyn yn debyg i ail-gynffon).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Yn didoli `v` gan ddefnyddio quicksort sy'n trechu patrwm, sef *O*(*n*\*log(* n*)) achos gwaethaf.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Nid oes gan ddidoli unrhyw ymddygiad ystyrlon ar fathau o faint sero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Cyfyngu nifer y rhaniadau anghytbwys i `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Ar gyfer tafelli hyd at y darn hwn mae'n debyg ei bod yn gyflymach i'w didoli.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Dewiswch colyn
        let (pivot, _) = choose_pivot(v, is_less);

        // Os bydd y colyn a ddewiswyd yn hafal i'r rhagflaenydd, yna mae'n elfen lleiaf yn y sleisen.
        // Rhannwch y dafell yn elfennau sy'n hafal i'r colyn ac elfennau sy'n fwy na'r colyn.
        // Mae'r achos hwn fel arfer yn cael ei daro pan fydd y sleisen yn cynnwys llawer o elfennau dyblyg.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Os ydym wedi pasio ein mynegai, yna rydym yn dda.
                if mid > index {
                    return;
                }

                // Fel arall, parhewch i ddidoli elfennau sy'n fwy na'r colyn.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Rhannwch y dafell i mewn i `left`, `pivot`, a `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Os canol==mynegai, yna rydym yn ei wneud, gan fod partition() gwarantu bod pob elfen ar ôl canol yn fwy na neu'n hafal i ganol.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Nid oes gan ddidoli unrhyw ymddygiad ystyrlon ar fathau o faint sero.Gwneud dim.
    } else if index == v.len() - 1 {
        // Dewch o hyd i elfen max a'i roi yn safle olaf yr arae.
        // Rydyn ni'n rhydd i ddefnyddio `unwrap()` yma oherwydd rydyn ni'n gwybod na ddylai v fod yn wag.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Dewch o hyd i elfen fach a'i rhoi yn safle cyntaf yr arae.
        // Rydyn ni'n rhydd i ddefnyddio `unwrap()` yma oherwydd rydyn ni'n gwybod na ddylai v fod yn wag.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}