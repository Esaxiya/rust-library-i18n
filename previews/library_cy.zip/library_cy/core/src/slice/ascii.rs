//! Gweithrediadau ar ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Gwiriadau a yw'r holl bytes yn y sleisen hon o fewn ystod ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Yn gwirio bod dwy dafell yn cyfateb achos-ansensitif ASCII.
    ///
    /// Yr un peth â `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ond heb ddyrannu a chopïo temporaries.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Trosi'r sleisen hon i'w chyfwerth ag achos uchaf ASCII yn ei lle.
    ///
    /// Mae llythyrau ASCII 'a' i 'z' wedi'u mapio i 'A' i 'Z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I ddychwelyd gwerth uchaf newydd heb addasu'r un presennol, defnyddiwch [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Trosi'r sleisen hon i'w chyfwerth â llythrennau bach ASCII yn ei lle.
    ///
    /// Mae llythyrau ASCII 'A' i 'Z' wedi'u mapio i 'a' i 'z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I ddychwelyd gwerth is newydd heb addasu'r un presennol, defnyddiwch [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Yn dychwelyd `true` os yw unrhyw beit yn y gair `v` yn nonascii (>=128).
/// Snarfed o `../str/mod.rs`, sy'n gwneud rhywbeth tebyg ar gyfer dilysu utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Prawf ASCII wedi'i optimeiddio a fydd yn defnyddio gweithrediadau usize-ar-amser yn lle gweithrediadau beit ar y tro (pan fo hynny'n bosibl).
///
/// Mae'r algorithm a ddefnyddiwn yma yn eithaf syml.Os yw `s` yn rhy fyr, rydym yn gwirio pob beit a chael ei wneud ag ef.Fel arall:
///
/// - Darllenwch y gair cyntaf gyda llwyth heb ei lofnodi.
/// - Alinio pwyntydd, darllen geiriau dilynol tan ddiwedd gyda llwythi halinio.
/// - Darllenwch yr `usize` olaf o `s` gyda llwyth heb ei lofnodi.
///
/// Os yw unrhyw un o'r llwythi hyn yn cynhyrchu rhywbeth y mae `contains_nonascii` (above) yn dychwelyd yn wir amdano, yna rydyn ni'n gwybod bod yr ateb yn ffug.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Pe na fyddem yn ennill unrhyw beth o'r gweithredu gair ar y tro, disgyn yn ôl i ddolen sgalar.
    //
    // Rydym hefyd yn gwneud hyn ar gyfer pensaernïaeth lle nad yw `size_of::<usize>()` yn alinio'n ddigonol ar gyfer `usize`, oherwydd mae'n achos rhyfedd edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Rydym bob amser yn darllen y gair cyntaf heb ei lofnodi, sy'n golygu bod `align_offset` yn
    // 0, byddem wedi darllen yr un gwerth eto ar gyfer y darlleniad wedi'i alinio.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // DIOGELWCH: Rydym yn gwirio `len < USIZE_SIZE` uchod.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Gwnaethom wirio hyn uchod, ychydig yn ymhlyg.
    // Sylwch fod `offset_to_aligned` naill ai'n `align_offset` neu `USIZE_SIZE`, mae'r ddau ohonynt wedi'u gwirio'n benodol uchod.
    //
    debug_assert!(offset_to_aligned <= len);

    // DIOGELWCH: word_ptr yw'r ptr usize (wedi'i alinio'n iawn) a ddefnyddiwn i ddarllen y
    // darn canol o'r dafell.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` yw'r mynegai beit o `word_ptr`, a ddefnyddir ar gyfer gwiriadau diwedd dolen.
    let mut byte_pos = offset_to_aligned;

    // Paranoia yn gwirio am aliniad, gan ein bod ar fin gwneud criw o lwythi heb eu llofnodi.
    // Yn ymarferol, dylai hyn fod yn amhosibl gwahardd byg yn `align_offset` serch hynny.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Darllen geiriau dilynol hyd nes y gair alinio ddiwethaf, heb gynnwys y gair aliniedig olaf ei ben ei hun i gael ei wneud dan reolaeth gynffon yn ddiweddarach, er mwyn sicrhau bod gynffon bob amser un `usize` yn y rhan fwyaf i branch `byte_pos == len` ychwanegol.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Gwiriwch sancteiddrwydd bod y darlleniad mewn ffiniau
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // A bod ein rhagdybiaethau am `byte_pos` yn eu dal.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // DIOGELWCH: Rydyn ni'n gwybod bod `word_ptr` wedi'i alinio'n iawn (oherwydd
        // `align_offset`), a gwyddom fod gennym ddigon o bytes rhwng `word_ptr` a'r diwedd
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // DIOGELWCH: Rydyn ni'n gwybod bod `byte_pos <= len - USIZE_SIZE`, sy'n golygu hynny
        // ar ôl yr `add` hwn, bydd `word_ptr` un-y-diwedd ar y mwyaf.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Gwiriad sancteiddrwydd i sicrhau mai dim ond un `usize` sydd ar ôl.
    // Dylai hyn gael ei warantu gan ein cyflwr dolen.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // DIOGELWCH: Mae hyn yn dibynnu ar `len >= USIZE_SIZE`, yr ydym yn ei wirio ar y dechrau.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}