//! Macros a ddefnyddir gan ailadroddwyr tafell.

// Mae inlinio is_empty a len yn gwneud gwahaniaeth perfformiad enfawr
macro_rules! is_empty {
    // Y ffordd yr ydym yn amgodio hyd ailadroddwr ZST, mae hyn yn gweithio ar gyfer ZST a heb fod yn ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// I gael gwared ar rai gwiriadau ffiniau (gweler `position`), rydym yn cyfrifo'r hyd mewn ffordd eithaf annisgwyl.
// (Wedi'i brofi gan `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // rydym weithiau'n cael ein defnyddio mewn bloc anniogel

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Mae'r _cannot_ hwn yn defnyddio `unchecked_sub` oherwydd ein bod yn dibynnu ar lapio i gynrychioli hyd ailadroddwyr tafell ZST hir.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Rydym yn gwybod y gall `start <= end`, felly wneud yn well na `offset_from`, y mae angen iddo ddelio â llofnod.
            // Trwy osod baneri priodol yma gallwn ddweud hyn wrth LLVM, sy'n ei helpu i gael gwared ar wiriadau ffiniau.
            // DIOGELWCH: Yn ôl y math invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Trwy hefyd ddweud wrth LLVM bod yr awgrymiadau ar wahân gan luosrif union o'r maint math, gall optimeiddio `len() == 0` i lawr i `start == end` yn lle `(end - start) < size`.
            //
            // DIOGELWCH: Yn ôl y math invariant, mae'r awgrymiadau wedi'u halinio felly mae'r
            //         rhaid i'r pellter rhyngddynt fod yn lluosrif o faint pwynt
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Y diffiniad a rennir o'r ailadroddwyr `Iter` a `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Yn dychwelyd yr elfen gyntaf ac yn symud dechrau'r ailadroddwr ymlaen gan 1.
        // Yn gwella perfformiad yn fawr o'i gymharu â swyddogaeth wedi'i leinio.
        // Rhaid i'r ailadroddwr beidio â bod yn wag.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Yn dychwelyd yr elfen olaf ac yn symud diwedd yr ailadroddwr yn ôl gan 1.
        // Yn gwella perfformiad yn fawr o'i gymharu â swyddogaeth wedi'i leinio.
        // Rhaid i'r ailadroddwr beidio â bod yn wag.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Crebachu y iterator pan T yn ZST, drwy symud diwedd y ôl iterator gan `n`.
        // `n` rhaid iddo beidio â bod yn fwy na `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Swyddogaeth cynorthwyydd ar gyfer creu tafell o'r ailadroddwr.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // DIOGELWCH: crëwyd yr ailadroddwr o dafell gyda phwyntydd
                // `self.ptr` a hyd `len!(self)`.
                // Mae hyn yn gwarantu bod yr holl ragofynion ar gyfer `from_raw_parts` yn cael eu cyflawni.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Swyddogaeth cynorthwyydd ar gyfer symud dechrau'r ailadroddwr ymlaen gan elfennau `offset`, gan ddychwelyd yr hen gychwyn.
            //
            // Anniogel oherwydd rhaid i'r gwrthbwyso beidio â bod yn fwy na `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // DIOGELWCH: mae'r galwr yn gwarantu nad yw `offset` yn fwy na `self.len()`,
                    // felly mae'r pwyntydd newydd hwn y tu mewn i `self` ac felly'n sicr o fod yn ddi-null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Swyddogaeth cynorthwyydd ar gyfer symud diwedd yr ailadroddwr yn ôl gan elfennau `offset`, gan ddychwelyd y diwedd newydd.
            //
            // Anniogel oherwydd rhaid i'r gwrthbwyso beidio â bod yn fwy na `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // DIOGELWCH: mae'r galwr yn gwarantu nad yw `offset` yn fwy na `self.len()`,
                    // sy'n sicr o beidio â gorlifo `isize`.
                    // Hefyd, mae'r pwyntydd sy'n deillio o hyn ar ffiniau `slice`, sy'n cyflawni'r gofynion eraill ar gyfer `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // gellid ei weithredu gyda sleisys, ond mae hyn yn osgoi gwiriadau ffiniau

                // DIOGELWCH: Mae galwadau `assume` yn ddiogel ers pwyntydd cychwyn tafell
                // rhaid iddo fod yn ddi-null, a rhaid bod gan dafelli dros rai nad ydynt yn ZSTs bwyntydd diwedd nad yw'n null.
                // Mae'r alwad i `next_unchecked!` yn ddiogel ers i ni wirio a yw'r ailadroddwr yn wag yn gyntaf.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Mae'r ailadroddwr hwn bellach yn wag.
                    if mem::size_of::<T>() == 0 {
                        // Mae'n rhaid i ni ei wneud fel hyn oherwydd efallai na fydd `ptr` byth yn 0, ond gallai `end` fod (oherwydd lapio).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // DIOGELWCH: ni all diwedd fod yn 0 os nad yw T yn ZST oherwydd nad yw ptr yn 0 ac yn diwedd>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // DIOGELWCH: Rydyn ni mewn ffiniau.Mae `post_inc_start` yn gwneud y peth iawn hyd yn oed ar gyfer ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Rydym yn diystyru'r gweithredu diofyn, sy'n defnyddio `try_fold`, oherwydd mae'r gweithrediad syml hwn yn cynhyrchu llai o LLVM IR ac mae'n gyflymach i'w lunio.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Rydym yn diystyru'r gweithredu diofyn, sy'n defnyddio `try_fold`, oherwydd mae'r gweithrediad syml hwn yn cynhyrchu llai o LLVM IR ac mae'n gyflymach i'w lunio.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Rydym yn diystyru'r gweithredu diofyn, sy'n defnyddio `try_fold`, oherwydd mae'r gweithrediad syml hwn yn cynhyrchu llai o LLVM IR ac mae'n gyflymach i'w lunio.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Rydym yn diystyru'r gweithredu diofyn, sy'n defnyddio `try_fold`, oherwydd mae'r gweithrediad syml hwn yn cynhyrchu llai o LLVM IR ac mae'n gyflymach i'w lunio.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Rydym yn diystyru'r gweithredu diofyn, sy'n defnyddio `try_fold`, oherwydd mae'r gweithrediad syml hwn yn cynhyrchu llai o LLVM IR ac mae'n gyflymach i'w lunio.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Rydym yn diystyru'r gweithredu diofyn, sy'n defnyddio `try_fold`, oherwydd mae'r gweithrediad syml hwn yn cynhyrchu llai o LLVM IR ac mae'n gyflymach i'w lunio.
            // Hefyd, mae'r `assume` yn osgoi gwiriad ffiniau.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // DIOGELWCH: rydym yn sicr o fod mewn ffiniau gan y ddolen invariant:
                        // pan fydd `i >= n`, `self.next()` yn dychwelyd `None` ac mae'r ddolen yn torri.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Rydym yn diystyru'r gweithredu diofyn, sy'n defnyddio `try_fold`, oherwydd mae'r gweithrediad syml hwn yn cynhyrchu llai o LLVM IR ac mae'n gyflymach i'w lunio.
            // Hefyd, mae'r `assume` yn osgoi gwiriad ffiniau.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // DIOGELWCH: Rhaid i `i` fod yn is na `n` ers iddo ddechrau yn `n`
                        // ac nid yw ond yn gostwng.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // DIOGELWCH: rhaid i'r galwr warantu bod `i` mewn ffiniau
                // y sleisen sylfaenol, felly ni all `i` orlifo `isize`, a gwarantir bod y cyfeiriadau a ddychwelwyd yn cyfeirio at elfen o'r dafell ac felly'n sicr o fod yn ddilys.
                //
                // Sylwch hefyd fod y galwr hefyd yn gwarantu na fyddwn byth yn cael ein galw gyda'r un mynegai eto, ac na elwir unrhyw ddulliau eraill a fydd yn cyrchu'r aruchel hwn, felly mae'n ddilys i'r cyfeirnod a ddychwelwyd fod yn gyfnewidiol yn achos
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // gellid ei weithredu gyda sleisys, ond mae hyn yn osgoi gwiriadau ffiniau

                // DIOGELWCH: Mae galwadau `assume` yn ddiogel gan fod yn rhaid i bwyntydd cychwyn tafell fod yn ddi-null,
                // a rhaid i dafelli dros rai nad ydynt yn ZST fod â chyfeiriadur diwedd di-null hefyd.
                // Mae'r alwad i `next_back_unchecked!` yn ddiogel ers i ni wirio a yw'r ailadroddwr yn wag yn gyntaf.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Mae'r ailadroddwr hwn bellach yn wag.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // DIOGELWCH: Rydyn ni mewn ffiniau.Mae `pre_dec_end` yn gwneud y peth iawn hyd yn oed ar gyfer ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}