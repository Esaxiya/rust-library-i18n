// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Yn cylchdroi'r ystod `[mid-left, mid+right)` fel bod yr elfen yn `mid` yn dod yn elfen gyntaf.Cyfwerth ei, cylchdroi yr ystod elfennau'r `left` i'r chwith neu `right` elfen i'r dde.
///
/// # Safety
///
/// Rhaid i'r ystod benodol fod yn ddilys ar gyfer darllen ac ysgrifennu.
///
/// # Algorithm
///
/// Defnyddir algorithm 1 ar gyfer gwerthoedd bach `left + right` neu ar gyfer `T` mawr.
/// Mae'r elfennau'n cael eu symud i'w safleoedd olaf un ar y tro gan ddechrau yn `mid - left` ac yn symud ymlaen gan gamau `right` modulo `left + right`, fel mai dim ond un dros dro sydd ei angen.
/// Yn y pen draw, rydym yn cyrraedd yn ôl ar `mid - left`.
/// Fodd bynnag, os nad yw `gcd(left + right, right)` yn 1, fe wnaeth y camau uchod hepgor dros elfennau.
/// Er enghraifft:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Yn ffodus, mae nifer yr elfennau sydd wedi'u hepgor dros elfennau terfynol bob amser yn gyfartal, felly gallwn ni wrthbwyso ein safle cychwyn a gwneud mwy o rowndiau (cyfanswm yr rowndiau yw'r `gcd(left + right, right)` value).
///
/// Y canlyniad terfynol yw bod yr holl elfennau'n cael eu cwblhau unwaith a dim ond unwaith.
///
/// Defnyddir algorithm 2 os yw `left + right` yn fawr ond mae `min(left, right)` yn ddigon bach i ffitio ar byffer pentwr.
/// Mae'r elfennau `min(left, right)` yn cael eu copïo i'r byffer, rhoddir `memmove` i'r lleill, ac mae'r rhai ar y byffer yn cael eu symud yn ôl i'r twll yr ochr arall i'r man lle y gwnaethon nhw darddu.
///
/// Mae algorithmau y gellir eu fectoreiddio yn perfformio'n well na'r uchod unwaith y bydd `left + right` yn dod yn ddigon mawr.
/// Gellir fectoreiddio algorithm 1 trwy dalpio a pherfformio llawer o rowndiau ar unwaith, ond mae rhy ychydig o rowndiau ar gyfartaledd nes bod `left + right` yn enfawr, ac mae'r achos gwaethaf o un rownd yno bob amser.
/// Yn lle, mae algorithm 3 yn defnyddio cyfnewid elfennau `min(left, right)` dro ar ôl tro nes bod problem cylchdroi llai ar ôl.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// pan fydd `left < right` mae'r cyfnewid yn digwydd o'r chwith yn lle.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. gall yr algorithmau isod fethu os na chaiff yr achosion hyn eu gwirio
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Mae microbenchmark yn nodi bod y perfformiad cyfartalog ar gyfer sifftiau ar hap yn well yr holl ffordd tan tua `left + right == 32`, ond mae'r perfformiad achos gwaethaf yn mantoli'r gyllideb hyd yn oed tua 16.
            // Dewiswyd 24 fel tir canol.
            // Os yw maint `T` yn fwy na 4 `usize`s, algorithm hwn hefyd yn perfformio'n well algorithmau eraill.
            //
            //
            let x = unsafe { mid.sub(left) };
            // dechrau'r rownd gyntaf
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` gellir dod o hyd iddo ymlaen llaw trwy gyfrifo `gcd(left + right, right)`, ond mae'n gyflymach gwneud un ddolen sy'n cyfrifo'r gcd fel sgil-effaith, ac yna'n gwneud gweddill y darn.
            //
            //
            let mut gcd = right;
            // meincnodau yn dangos ei bod yn gyflymach i temporaries cyfnewid yr holl ffordd drwy'r yn hytrach na darllen un unwaith dros dro, copïo yn ôl, ac yna ysgrifennu bod dros dro ar ddiwedd iawn.
            // Mae hyn yn bosibl oherwydd y ffaith bod cyfnewid neu ddisodli temporaries defnyddio dim ond un cyfeiriad cof yn y ddolen yn hytrach na bod angen i reoli dau.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // yn lle cynyddu `i` ac yna gwirio a yw y tu allan i'r ffiniau, rydym yn gwirio a fydd `i` yn mynd y tu allan i'r ffiniau ar yr hicyn nesaf.
                // Mae hyn yn atal lapio awgrymiadau neu `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // diwedd y rownd gyntaf
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // rhaid i'r amodol hwn fod yma os `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // gorffen y darn gyda mwy o rowndiau
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nid yw'n fath o faint sero, felly mae'n iawn ei rannu yn ôl ei faint.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 Yr `[T; 0]` yma yw sicrhau bod hyn wedi'i alinio'n briodol ar gyfer T.
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Mae yna ffordd arall o gyfnewid sy'n cynnwys darganfod ble fyddai cyfnewid olaf yr algorithm hwn, a chyfnewid gan ddefnyddio'r darn olaf hwnnw yn lle cyfnewid talpiau cyfagos fel mae'r algorithm hwn yn ei wneud, ond mae'r ffordd hon yn dal yn gyflymach.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}