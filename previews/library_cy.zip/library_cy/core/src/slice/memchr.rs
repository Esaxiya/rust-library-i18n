// Gweithrediad gwreiddiol wedi'i gymryd o rust-memchr.
// Hawlfraint 2015 Andrew Gallant, bluss a Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Defnyddiwch foncyff.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Yn dychwelyd `true` os yw `x` yn cynnwys unrhyw beit sero.
///
/// O *Matters Computational*, J. Arndt:
///
/// "Y syniad yw tynnu un o bob un o'r beit ac yna chwilio am beitiau lle mae'r benthyciad wedi lluosogi'r holl ffordd i'r mwyaf arwyddocaol
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Yn dychwelyd y mynegai cyntaf sy'n cyfateb i'r beit `x` yn `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Llwybr cyflym ar gyfer sleisys bach
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Sganiwch am werth beit sengl trwy ddarllen dau air `usize` ar y tro.
    //
    // Rhannwch `text` mewn tair rhan
    // - rhan gychwynnol heb ei llofnodi, cyn i'r gair cyntaf alinio cyfeiriad mewn testun
    // - corff, sganio gan 2 air ar y tro
    // - y rhan olaf sy'n weddill, <2 faint gair

    // chwilio hyd at ffin wedi'i halinio
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // chwilio corff y testun
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // DIOGELWCH: mae rhagfynegiad yr amser yn gwarantu pellter o leiaf 2 * usize_bytes
        // rhwng y gwrthbwyso a diwedd y dafell.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // torri os oes beit paru
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Dewch o hyd i'r beit ar ôl y pwynt y stopiodd dolen y corff.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Yn dychwelyd y mynegai olaf sy'n cyfateb i'r beit `x` yn `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Sganiwch am werth beit sengl trwy ddarllen dau air `usize` ar y tro.
    //
    // Rhannwch `text` mewn tair rhan:
    // - cynffon heb ei llofnodi, ar ôl y gair olaf wedi'i alinio cyfeiriad mewn testun,
    // - corff, wedi'i sganio gan 2 air ar y tro,
    // - y bytes cyntaf sy'n weddill, <maint 2 air.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Rydym yn galw hyn dim ond i gael hyd y rhagddodiad a'r ôl-ddodiad.
        // Yn y canol rydyn ni bob amser yn prosesu dau dalp ar unwaith.
        // DIOGELWCH: mae trosglwyddo `[u8]` i `[usize]` yn ddiogel heblaw am wahaniaethau maint sy'n cael eu trin gan `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Chwiliwch gorff y testun, gwnewch yn siŵr nad ydyn ni'n croesi min_aligned_offset.
    // mae gwrthbwyso bob amser wedi'i alinio, felly mae profi `>` yn unig yn ddigonol ac yn osgoi gorlif posibl.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // DIOGELWCH: mae'r gwrthbwyso yn dechrau ar len, suffix.len(), cyhyd â'i fod yn fwy na
        // min_aligned_offset (prefix.len()) y pellter sy'n weddill yw o leiaf 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Torri os oes beit sy'n cyfateb.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Dewch o hyd i'r beit cyn y pwynt y stopiodd dolen y corff.
    text[..offset].iter().rposition(|elt| *elt == x)
}