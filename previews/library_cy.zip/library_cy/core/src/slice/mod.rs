// ignore-tidy-filelength

//! Rheoli a thrin tafelli.
//!
//! Am fwy o fanylion gweler [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Gweithrediad memchr pur rust, wedi'i gymryd o rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Mae'r swyddogaeth hon yn gyhoeddus yn unig oherwydd nad oes unrhyw ffordd arall i brofi heapsort prawf uned.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Yn dychwelyd nifer yr elfennau yn y dafell.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // DIOGELWCH: const const oherwydd ein bod yn trosglwyddo'r maes hyd fel usize (y mae'n rhaid iddo fod)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // DIOGELWCH: mae hyn yn ddiogel oherwydd bod gan `&[T]` a `FatPtr<T>` yr un cynllun.
            // Dim ond `std` all wneud y warant hon.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Amnewid gyda `crate::ptr::metadata(self)` pan fydd hynny'n sefydlog.
            // O'r ysgrifen hon mae hyn yn achosi gwall "Const-stable functions can only call other const-stable functions".
            //

            // DIOGELWCH: Mae cyrchu'r gwerth o'r undeb `PtrRepr` yn ddiogel ers * const T.
            // a PtrComponents<T>cael yr un cynlluniau cof.
            // Dim ond std all wneud y warant hon.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Yn dychwelyd `true` os oes gan y sleisen hyd 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Yn dychwelyd elfen gyntaf y dafell, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Yn dychwelyd pwyntydd symudol i elfen gyntaf y dafell, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Yn dychwelyd y cyntaf a holl weddill elfennau'r dafell, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Yn dychwelyd y cyntaf a holl weddill elfennau'r dafell, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Yn dychwelyd yr olaf a holl weddill elfennau'r dafell, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Yn dychwelyd yr olaf a holl weddill elfennau'r dafell, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Yn dychwelyd elfen olaf y dafell, neu `None` os yw'n wag.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Yn dychwelyd pwyntydd symudol i'r eitem olaf yn y dafell.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Yn dychwelyd cyfeiriad at elfen neu aruchel yn dibynnu ar y math o fynegai.
    ///
    /// - Os rhoddir swydd iddo, dychwelwch gyfeiriad at yr elfen yn y safle hwnnw neu `None` os yw allan o ffiniau.
    ///
    /// - Os rhoddir amrediad iddo, dychwelwch yr is-gyfateb sy'n cyfateb i'r amrediad hwnnw, neu `None` os yw allan o ffiniau.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Yn dychwelyd cyfeiriad treiddgar at elfen neu aruchel yn dibynnu ar y math o fynegai (gweler [`get`]) neu `None` os yw'r mynegai allan o ffiniau.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Yn dychwelyd cyfeiriad at elfen neu aruchel, heb wirio ffiniau.
    ///
    /// Am ddewis arall diogel gweler [`get`].
    ///
    /// # Safety
    ///
    /// Mae galw'r dull hwn gyda mynegai y tu allan i ffiniau yn *[ymddygiad heb ei ddiffinio]* hyd yn oed os na ddefnyddir y cyfeirnod canlyniadol.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y rhan fwyaf o'r gofynion diogelwch ar gyfer `get_unchecked`;
        // mae'r tafell yn ddadreferencable oherwydd bod `self` yn gyfeirnod diogel.
        // Mae'r pwyntydd a ddychwelwyd yn ddiogel oherwydd bod yn rhaid i impls `SliceIndex` warantu ei fod.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Yn dychwelyd cyfeiriad treiddgar at elfen neu aruchel, heb wirio ffiniau.
    ///
    /// Am ddewis arall diogel gweler [`get_mut`].
    ///
    /// # Safety
    ///
    /// Mae galw'r dull hwn gyda mynegai y tu allan i ffiniau yn *[ymddygiad heb ei ddiffinio]* hyd yn oed os na ddefnyddir y cyfeirnod canlyniadol.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y gofynion diogelwch ar gyfer `get_unchecked_mut`;
        // mae'r tafell yn ddadreferencable oherwydd bod `self` yn gyfeirnod diogel.
        // Mae'r pwyntydd a ddychwelwyd yn ddiogel oherwydd bod yn rhaid i impls `SliceIndex` warantu ei fod.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Yn dychwelyd pwyntydd amrwd i byffer y dafell.
    ///
    /// Rhaid i'r galwr sicrhau bod y sleisen yn goroesi'r pwyntydd y mae'r swyddogaeth hon yn ei ddychwelyd, neu fel arall bydd yn pwyntio at sothach.
    ///
    /// Mae'n rhaid i'r galwr hefyd sicrhau bod y cof pwyntydd pwyntiau (non-transitively) i byth yn cael ei ysgrifennu i (ac eithrio tu fewn i `UnsafeCell`) gan ddefnyddio pwyntydd hwn neu unrhyw pwyntydd deillio ohono.
    /// Os oes angen i addasu cynnwys y dafell, defnyddiwch [`as_mut_ptr`].
    ///
    /// Addasu y cynhwysydd gyfeirio gan tafell hwn gall achosi ei byffer i gael eu hailddyrannu, a fyddai hefyd yn gwneud unrhyw awgrymiadau iddo annilys.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Dychwelyd i pwyntydd mutable anniogel i byffer y dafell yn.
    ///
    /// Rhaid i'r galwr sicrhau bod y sleisen yn goroesi'r pwyntydd y mae'r swyddogaeth hon yn ei ddychwelyd, neu fel arall bydd yn pwyntio at sothach.
    ///
    /// Addasu y cynhwysydd gyfeirio gan tafell hwn gall achosi ei byffer i gael eu hailddyrannu, a fyddai hefyd yn gwneud unrhyw awgrymiadau iddo annilys.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Yn dychwelyd y ddau awgrym amrwd sy'n rhychwantu'r sleisen.
    ///
    /// Mae'r amrediad a ddychwelwyd yn hanner agored, sy'n golygu bod y pwyntydd diwedd yn pwyntio *un heibio* elfen olaf y dafell.
    /// Fel hyn, mae sleisen wag yn cael ei chynrychioli gan ddau awgrym cyfartal, ac mae'r gwahaniaeth rhwng y ddau awgrym yn cynrychioli maint y dafell.
    ///
    /// Gweler [`as_ptr`] am rybuddion ar ddefnyddio'r awgrymiadau hyn.Mae angen gofal ychwanegol ar y pwyntydd diwedd, gan nad yw'n pwyntio at elfen ddilys yn y dafell.
    ///
    /// Mae'r swyddogaeth hon yn ddefnyddiol ar gyfer rhyngweithio â rhyngwynebau tramor sy'n defnyddio dau awgrym i gyfeirio at ystod o elfennau yn y cof, fel sy'n gyffredin yn C++ .
    ///
    ///
    /// Gall hefyd fod yn ddefnyddiol gwirio a yw pwyntydd i elfen yn cyfeirio at elfen o'r dafell hon:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // DIOGELWCH: Mae'r `add` yma yn ddiogel, oherwydd:
        //
        //   - Mae'r ddau awgrym yn rhan o'r un gwrthrych, gan fod pwyntio'n uniongyrchol heibio'r gwrthrych hefyd yn cyfrif.
        //
        //   - Nid yw maint y dafell byth yn fwy na beit isize::MAX, fel y nodir yma:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Nid oes unrhyw lapio o gwmpas, gan nad yw sleisys yn lapio heibio i ddiwedd y gofod cyfeiriad.
        //
        // Gweler dogfennaeth pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Yn dychwelyd y ddau awgrym symudol anniogel sy'n rhychwantu'r sleisen.
    ///
    /// Mae'r amrediad a ddychwelwyd yn hanner agored, sy'n golygu bod y pwyntydd diwedd yn pwyntio *un heibio* elfen olaf y dafell.
    /// Fel hyn, mae sleisen wag yn cael ei chynrychioli gan ddau awgrym cyfartal, ac mae'r gwahaniaeth rhwng y ddau awgrym yn cynrychioli maint y dafell.
    ///
    /// Gweler [`as_mut_ptr`] am rybuddion ar ddefnyddio'r awgrymiadau hyn.
    /// Mae angen gofal ychwanegol ar y pwyntydd diwedd, gan nad yw'n pwyntio at elfen ddilys yn y dafell.
    ///
    /// Mae'r swyddogaeth hon yn ddefnyddiol ar gyfer rhyngweithio â rhyngwynebau tramor sy'n defnyddio dau awgrym i gyfeirio at ystod o elfennau yn y cof, fel sy'n gyffredin yn C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // DIOGELWCH: Gweler as_ptr_range() uchod am pam mae `add` yma yn ddiogel.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Yn cyfnewid dwy elfen yn y dafell.
    ///
    /// # Arguments
    ///
    /// * a, Mynegai yr elfen gyntaf
    /// * b, Mynegai yr ail elfen
    ///
    /// # Panics
    ///
    /// Panics os yw `a` neu `b` allan o ffiniau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Methu cymryd dau fenthyciad symudol o un vector, felly yn lle hynny defnyddiwch awgrymiadau amrwd.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // DIOGELWCH: Mae `pa` a `pb` wedi'u creu o gyfeiriadau symudol y gellir eu trosglwyddo ac maent yn cyfeirio
        // i elfennau yn y dafell ac felly yn sicr o fod yn ddilys ac yn cyd-fynd.
        // Sylwch fod cyrchu'r elfennau y tu ôl i `a` a `b` yn cael ei wirio a bydd panic pan allan o ffiniau.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Yn gwrthdroi trefn yr elfennau yn y dafell, yn eu lle.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Ar gyfer mathau bach iawn, mae'r holl ddarlleniadau unigol yn y llwybr arferol yn perfformio'n wael.
        // Gallwn wneud yn well, o ystyried load/store heb ei alinio yn effeithlon, trwy lwytho darn mwy o faint ac yn gwrthdroi cofrestr.
        //

        // Yn ddelfrydol, byddai LLVM yn gwneud hyn i ni, gan ei fod yn gwybod yn well nag yr ydym yn ei wneud a yw darlleniadau heb eu llofnodi yn effeithlon (gan fod hynny'n newid rhwng gwahanol fersiynau ARM, er enghraifft) a beth fyddai'r maint talp gorau.
        // Yn anffodus, fel LLVM 4.0 (2017-05), dim ond y ddolen sy'n dadlwytho, felly mae angen i ni wneud hyn ein hunain.
        // (Rhagdybiaeth: mae'r gwrthwyneb yn drafferthus oherwydd gellir alinio'r ochrau'n wahanol-bydd, pan fydd y hyd yn od-felly nid oes unrhyw ffordd o allyrru cyn ac ôl-bostiau i ddefnyddio SIMD wedi'i alinio'n llawn yn y canol.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Defnyddiwch yr llvm.bswap cynhenid i wyrdroi u8s mewn usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // DIOGELWCH: Mae yna sawl peth i'w gwirio yma:
                //
                // - Sylwch fod `chunk` naill ai'n 4 neu'n 8 oherwydd y gwiriad cfg uchod.Felly mae `chunk - 1` yn gadarnhaol.
                // - Mae mynegeio gyda mynegai `i` yn iawn fel y mae'r gwiriad dolen yn gwarantu
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Mae mynegeio gyda mynegai `ln - i - chunk = ln - (i + chunk)` yn iawn:
                //   - `i + chunk > 0` yn ddibwys yn wir.
                //   - Mae'r gwiriad dolen yn gwarantu:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, felly nid yw tynnu yn gorlifo.
                // - Mae'r galwadau `read_unaligned` a `write_unaligned` yn iawn:
                //   - `pa` pwyntiau i fynegai `i` lle mae `i < ln / 2 - (chunk - 1)` (gweler uchod) a `pb` yn pwyntio at fynegai `ln - i - chunk`, felly mae'r ddau o leiaf `chunk` llawer o beitiau i ffwrdd o ddiwedd `self`.
                //
                //   - Mae unrhyw gof cychwynnol yn `usize` dilys.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Defnyddiwch gylchdroi-wrth-16 i wyrdroi u16s mewn u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // DIOGELWCH: Gellir darllen u32 heb ei lofnodi o `i` os `i + 1 < ln`
                // (ac yn amlwg `i < ln`), oherwydd mae pob elfen yn 2 beit ac rydyn ni'n darllen 4.
                //
                // `i + chunk - 1 < ln / 2` # tra cyflwr
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Gan ei fod yn llai na'r hyd wedi'i rannu â 2, yna mae'n rhaid iddo fod mewn ffiniau.
                //
                // Mae hyn hefyd yn golygu bod yr amod `0 < i + chunk <= ln` bob amser yn cael ei barchu, gan sicrhau y gellir defnyddio'r pwyntydd `pb` yn ddiogel.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // DIOGELWCH: Mae `i` yn israddol i hanner hyd y dafell felly
            // mae cyrchu `i` a `ln - i - 1` yn ddiogel (mae `i` yn cychwyn am 0 ac ni fydd yn mynd ymhellach na `ln / 2 - 1`).
            // Mae'r pwyntiau sy'n deillio `pa` a `pb` felly yn ddilys ac yn cyd-fynd, a gellir eu darllen o ac ysgrifenedig i.
            //
            //
            unsafe {
                // Cyfnewid anniogel i osgoi'r ffiniau gwirio mewn cyfnewid diogel.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Yn dychwelyd ailadroddwr dros y dafell.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Yn dychwelyd ailadroddwr sy'n caniatáu addasu pob gwerth.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Yn dychwelyd ailadroddwr dros yr holl windows cyffiniol o hyd `size`.
    /// Mae'r windows yn gorgyffwrdd.
    /// Os yw'r sleisen yn fyrrach na `size`, nid yw'r ailadroddwr yn dychwelyd unrhyw werthoedd.
    ///
    /// # Panics
    ///
    /// Panics os yw `size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Os yw'r sleisen yn fyrrach na `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddechrau'r sleisen.
    ///
    /// Mae'r darnau yn dafelli ac nid ydyn nhw'n gorgyffwrdd.Os nad yw `chunk_size` yn rhannu hyd y dafell, yna ni fydd gan y darn olaf hyd `chunk_size`.
    ///
    /// Gweler [`chunks_exact`] am amrywiad o'r ailadroddwr hwn sy'n dychwelyd talpiau o elfennau `chunk_size` bob amser, a [`rchunks`] am yr un ailadroddwr ond sy'n dechrau ar ddiwedd y dafell.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddechrau'r sleisen.
    ///
    /// Mae'r darnau yn dafelli treiddgar, ac nid ydynt yn gorgyffwrdd.Os nad yw `chunk_size` yn rhannu hyd y dafell, yna ni fydd gan y darn olaf hyd `chunk_size`.
    ///
    /// Gweler [`chunks_exact_mut`] am amrywiad o'r ailadroddwr hwn sy'n dychwelyd talpiau o elfennau `chunk_size` bob amser, a [`rchunks_mut`] am yr un ailadroddwr ond sy'n dechrau ar ddiwedd y dafell.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddechrau'r sleisen.
    ///
    /// Mae'r darnau yn dafelli ac nid ydyn nhw'n gorgyffwrdd.
    /// Os nad yw `chunk_size` yn rhannu hyd y dafell, yna bydd yr elfennau olaf hyd at `chunk_size-1` yn cael eu hepgor a gellir eu hadalw o swyddogaeth `remainder` yr ailadroddwr.
    ///
    ///
    /// Oherwydd bod gan bob darn elfennau `chunk_size` yn union, yn aml gall y crynhoydd wneud y gorau o'r cod sy'n deillio ohono yn well nag yn achos [`chunks`].
    ///
    /// Gweler [`chunks`] am amrywiad o'r ailadroddwr hwn sydd hefyd yn dychwelyd y gweddill fel talp llai, ac [`rchunks_exact`] ar gyfer yr un ailadroddwr ond yn dechrau ar ddiwedd y dafell.
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddechrau'r sleisen.
    ///
    /// Mae'r darnau yn dafelli treiddgar, ac nid ydynt yn gorgyffwrdd.
    /// Os nad yw `chunk_size` yn rhannu hyd y dafell, yna bydd yr elfennau olaf hyd at `chunk_size-1` yn cael eu hepgor a gellir eu hadalw o swyddogaeth `into_remainder` yr ailadroddwr.
    ///
    ///
    /// Oherwydd bod gan bob darn elfennau `chunk_size` yn union, yn aml gall y crynhoydd wneud y gorau o'r cod sy'n deillio ohono yn well nag yn achos [`chunks_mut`].
    ///
    /// Gweler [`chunks_mut`] am amrywiad o'r ailadroddwr hwn sydd hefyd yn dychwelyd y gweddill fel talp llai, ac [`rchunks_exact_mut`] ar gyfer yr un ailadroddwr ond yn dechrau ar ddiwedd y dafell.
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Rhannwch y dafell yn dafell o araeau elfen `N`, gan dybio nad oes gweddill.
    ///
    ///
    /// # Safety
    ///
    /// Dim ond pan fydd hyn yn cael ei alw
    /// - Mae'r sleisen yn hollti'n union i dalpiau elfen `N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // DIOGELWCH: Nid oes gan ddarnau 1-elfen weddill byth
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // DIOGELWCH: Mae hyd y sleisen (6) yn lluosrif o 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Byddai'r rhain yn ddi-sail:
    /// // gadewch dalpiau: &[[_;5]]= slice.as_chunks_unchecked()//Nid yw hyd y dafell yn lluosrif o 5 darn gosod:&[[_;0]]= slice.as_chunks_unchecked()//Ni chaniateir talpiau hyd sero byth
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // DIOGELWCH: Ein rhagamod yw'r union beth sydd ei angen i alw hyn
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // DIOGELWCH: Rydyn ni'n bwrw tafell o elfennau `new_len * N` i mewn
        // tafell o `new_len` llawer o dalpiau elfennau `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Rhannwch y dafell yn dafell o araeau elfen `N`, gan ddechrau ar ddechrau'r sleisen, a sleisen weddill gyda hyd yn hollol llai na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `N` yn 0. Mae'n debyg y bydd y gwiriad hwn yn cael ei newid i wall amser llunio cyn i'r dull hwn sefydlogi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // DIOGELWCH: Rydym eisoes wedi mynd i banig am sero, a sicrhau adeiladu
        // bod hyd yr aruchel yn lluosrif o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Rhannwch y dafell yn dafell o araeau elfen `N`, gan ddechrau ar ddiwedd y dafell, a sleisen weddill gyda hyd yn hollol llai na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `N` yn 0. Mae'n debyg y bydd y gwiriad hwn yn cael ei newid i wall amser llunio cyn i'r dull hwn sefydlogi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // DIOGELWCH: Rydym eisoes wedi mynd i banig am sero, a sicrhau adeiladu
        // bod hyd yr aruchel yn lluosrif o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `N` o'r sleisen ar y tro, gan ddechrau ar ddechrau'r sleisen.
    ///
    /// Mae'r darnau yn gyfeiriadau arae ac nid ydynt yn gorgyffwrdd.
    /// Os nad yw `N` yn rhannu hyd y dafell, yna bydd yr elfennau olaf hyd at `N-1` yn cael eu hepgor a gellir eu hadalw o swyddogaeth `remainder` yr ailadroddwr.
    ///
    ///
    /// Mae'r dull hwn yn cyfateb yn gyffredinol i [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics os yw `N` yn 0. Mae'n debyg y bydd y gwiriad hwn yn cael ei newid i wall amser llunio cyn i'r dull hwn sefydlogi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Rhannwch y dafell yn dafell o araeau elfen `N`, gan dybio nad oes gweddill.
    ///
    ///
    /// # Safety
    ///
    /// Dim ond pan fydd hyn yn cael ei alw
    /// - Mae'r sleisen yn hollti'n union i dalpiau elfen `N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // DIOGELWCH: Nid oes gan ddarnau 1-elfen weddill byth
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // DIOGELWCH: Mae hyd y sleisen (6) yn lluosrif o 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Byddai'r rhain yn ddi-sail:
    /// // gadewch dalpiau: &[[_;5]]= slice.as_chunks_unchecked_mut()//Nid yw hyd y dafell yn lluosrif o 5 darn gosod:&[[_;0]]= slice.as_chunks_unchecked_mut()//Ni chaniateir talpiau dim hyd byth
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // DIOGELWCH: Ein rhagamod yw'r union beth sydd ei angen i alw hyn
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // DIOGELWCH: Rydyn ni'n bwrw tafell o elfennau `new_len * N` i mewn
        // tafell o `new_len` llawer o dalpiau elfennau `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Rhannwch y dafell yn dafell o araeau elfen `N`, gan ddechrau ar ddechrau'r sleisen, a sleisen weddill gyda hyd yn hollol llai na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `N` yn 0. Mae'n debyg y bydd y gwiriad hwn yn cael ei newid i wall amser llunio cyn i'r dull hwn sefydlogi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // DIOGELWCH: Rydym eisoes wedi mynd i banig am sero, a sicrhau adeiladu
        // bod hyd yr aruchel yn lluosrif o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Rhannwch y dafell yn dafell o araeau elfen `N`, gan ddechrau ar ddiwedd y dafell, a sleisen weddill gyda hyd yn hollol llai na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `N` yn 0. Mae'n debyg y bydd y gwiriad hwn yn cael ei newid i wall amser llunio cyn i'r dull hwn sefydlogi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // DIOGELWCH: Rydym eisoes wedi mynd i banig am sero, a sicrhau adeiladu
        // bod hyd yr aruchel yn lluosrif o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `N` o'r sleisen ar y tro, gan ddechrau ar ddechrau'r sleisen.
    ///
    /// Mae'r talpiau'n gyfeiriadau arae treiddiol ac nid ydynt yn gorgyffwrdd.
    /// Os nad yw `N` yn rhannu hyd y dafell, yna bydd yr elfennau olaf hyd at `N-1` yn cael eu hepgor a gellir eu hadalw o swyddogaeth `into_remainder` yr ailadroddwr.
    ///
    ///
    /// Mae'r dull hwn yn cyfateb yn gyffredinol i [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics os yw `N` yn 0. Mae'n debyg y bydd y gwiriad hwn yn cael ei newid i wall amser llunio cyn i'r dull hwn sefydlogi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Yn dychwelyd ailadroddwr dros orgyffwrdd windows o elfennau `N` o dafell, gan ddechrau ar ddechrau'r sleisen.
    ///
    ///
    /// Dyma'r hyn sy'n cyfateb yn gyffredinol i [`windows`].
    ///
    /// Os yw `N` yn fwy na maint y dafell, ni fydd yn dychwelyd unrhyw windows.
    ///
    /// # Panics
    ///
    /// Panics os yw `N` yn 0.
    /// Mae'n debyg y bydd y gwiriad hwn yn cael ei newid i wall amser llunio cyn i'r dull hwn gael ei sefydlogi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddiwedd y dafell.
    ///
    /// Mae'r darnau yn dafelli ac nid ydyn nhw'n gorgyffwrdd.Os nad yw `chunk_size` yn rhannu hyd y dafell, yna ni fydd gan y darn olaf hyd `chunk_size`.
    ///
    /// Gweler [`rchunks_exact`] am amrywiad o'r ailadroddwr hwn sy'n dychwelyd talpiau o elfennau `chunk_size` bob amser, a [`chunks`] am yr un ailadroddwr ond sy'n dechrau ar ddechrau'r sleisen.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddiwedd y dafell.
    ///
    /// Mae'r darnau yn dafelli treiddgar, ac nid ydynt yn gorgyffwrdd.Os nad yw `chunk_size` yn rhannu hyd y dafell, yna ni fydd gan y darn olaf hyd `chunk_size`.
    ///
    /// Gweler [`rchunks_exact_mut`] am amrywiad o'r ailadroddwr hwn sy'n dychwelyd talpiau o elfennau `chunk_size` bob amser, a [`chunks_mut`] am yr un ailadroddwr ond sy'n dechrau ar ddechrau'r sleisen.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddiwedd y dafell.
    ///
    /// Mae'r darnau yn dafelli ac nid ydyn nhw'n gorgyffwrdd.
    /// Os nad yw `chunk_size` yn rhannu hyd y dafell, yna bydd yr elfennau olaf hyd at `chunk_size-1` yn cael eu hepgor a gellir eu hadalw o swyddogaeth `remainder` yr ailadroddwr.
    ///
    /// Oherwydd bod gan bob darn elfennau `chunk_size` yn union, yn aml gall y crynhoydd wneud y gorau o'r cod sy'n deillio ohono yn well nag yn achos [`chunks`].
    ///
    /// Gweler [`rchunks`] am amrywiad o iterator hwn sydd hefyd yn dychwelyd y gweddill fel talp llai, a [`chunks_exact`] ar gyfer yr un iterator ond yn dechrau ar ddechrau'r y dafell.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Yn dychwelyd ailadroddwr dros elfennau `chunk_size` o'r sleisen ar y tro, gan ddechrau ar ddiwedd y dafell.
    ///
    /// Mae'r darnau yn dafelli treiddgar, ac nid ydynt yn gorgyffwrdd.
    /// Os nad yw `chunk_size` yn rhannu hyd y dafell, yna bydd yr elfennau olaf hyd at `chunk_size-1` yn cael eu hepgor a gellir eu hadalw o swyddogaeth `into_remainder` yr ailadroddwr.
    ///
    /// Oherwydd bod gan bob darn elfennau `chunk_size` yn union, yn aml gall y crynhoydd wneud y gorau o'r cod sy'n deillio ohono yn well nag yn achos [`chunks_mut`].
    ///
    /// Gweler [`rchunks_mut`] am amrywiad o'r ailadroddwr hwn sydd hefyd yn dychwelyd y gweddill fel talp llai, ac [`chunks_exact_mut`] am yr un ailadroddwr ond yn dechrau ar ddechrau'r sleisen.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw `chunk_size` yn 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Yn dychwelyd ailadroddwr dros y sleisen gan gynhyrchu rhediadau o elfennau nad ydynt yn gorgyffwrdd gan ddefnyddio'r ysglyfaeth i'w gwahanu.
    ///
    /// Gelwir y predicate ar ddwy elfen yn dilyn eu hunain, mae'n golygu bod y predicate yn cael ei alw ar `slice[0]` a `slice[1]` yna ar `slice[1]` a `slice[2]` ac ati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Gellir defnyddio'r dull hwn i echdynnu'r is-raddfeydd wedi'u didoli:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Yn dychwelyd ailadroddwr dros y dafell gan gynhyrchu rhediadau treiddiol o elfennau nad ydynt yn gorgyffwrdd gan ddefnyddio'r ysglyfaeth i'w gwahanu.
    ///
    /// Gelwir y predicate ar ddwy elfen yn dilyn eu hunain, mae'n golygu bod y predicate yn cael ei alw ar `slice[0]` a `slice[1]` yna ar `slice[1]` a `slice[2]` ac ati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Gellir defnyddio'r dull hwn i echdynnu'r is-raddfeydd wedi'u didoli:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Rhannwch un dafell yn ddwy ar fynegai.
    ///
    /// Mae'r cyntaf yn cynnwys yr holl mynegeion o `[0, mid)` (heb gynnwys y mynegai `mid` ei hun) a'r ail bydd yn cynnwys yr holl mynegeion o `[mid, len)` (heb gynnwys y mynegai `len` ei hun).
    ///
    ///
    /// # Panics
    ///
    /// Panics os `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // DIOGELWCH: Mae `[ptr; mid]` a `[mid; len]` y tu mewn i `self`, sydd
        // yn cyflawni gofynion `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Yn rhannu un dafell gyfnewidiol yn ddwy ar fynegai.
    ///
    /// Mae'r cyntaf yn cynnwys yr holl mynegeion o `[0, mid)` (heb gynnwys y mynegai `mid` ei hun) a'r ail bydd yn cynnwys yr holl mynegeion o `[mid, len)` (heb gynnwys y mynegai `len` ei hun).
    ///
    ///
    /// # Panics
    ///
    /// Panics os `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // DIOGELWCH: Mae `[ptr; mid]` a `[mid; len]` y tu mewn i `self`, sydd
        // yn cyflawni gofynion `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Rhannwch un dafell yn ddwy ar fynegai, heb wirio ffiniau.
    ///
    /// Mae'r cyntaf yn cynnwys yr holl mynegeion o `[0, mid)` (heb gynnwys y mynegai `mid` ei hun) a'r ail bydd yn cynnwys yr holl mynegeion o `[mid, len)` (heb gynnwys y mynegai `len` ei hun).
    ///
    ///
    /// Am ddewis arall diogel gweler [`split_at`].
    ///
    /// # Safety
    ///
    /// Mae galw'r dull hwn gyda mynegai y tu allan i ffiniau yn *[ymddygiad heb ei ddiffinio]* hyd yn oed os na ddefnyddir y cyfeirnod canlyniadol.Rhaid i'r galwr sicrhau bod `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // DIOGELWCH: Rhaid i'r galwr wirio bod `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Rhannwch un dafell gyfnewidiol yn ddwy ar fynegai, heb wirio ffiniau.
    ///
    /// Mae'r cyntaf yn cynnwys yr holl mynegeion o `[0, mid)` (heb gynnwys y mynegai `mid` ei hun) a'r ail bydd yn cynnwys yr holl mynegeion o `[mid, len)` (heb gynnwys y mynegai `len` ei hun).
    ///
    ///
    /// Am ddewis arall diogel gweler [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Mae galw'r dull hwn gyda mynegai y tu allan i ffiniau yn *[ymddygiad heb ei ddiffinio]* hyd yn oed os na ddefnyddir y cyfeirnod canlyniadol.Rhaid i'r galwr sicrhau bod `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // DIOGELWCH: Rhaid i'r galwr wirio bod `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ac nid yw `[mid; len]` yn gorgyffwrdd, felly mae dychwelyd cyfeirnod symudol yn iawn.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Os yw'r elfen gyntaf yn cael ei chyfateb, sleisen wag fydd yr eitem gyntaf a ddychwelir gan yr ailadroddwr.
    /// Yn yr un modd, os yw'r elfen olaf yn y dafell wedi'i chyfateb, tafell wag fydd yr eitem olaf a ddychwelir gan yr ailadroddwr:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Os yw dwy elfen gyfatebol yn uniongyrchol gyfagos, bydd sleisen wag yn bresennol rhyngddynt:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau treiddgar wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`.
    /// Mae'r elfen gyfatebol wedi'i chynnwys ar ddiwedd yr is-adran flaenorol fel terfynwr.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Os yw elfen olaf y dafell wedi'i chyfateb, bydd yr elfen honno'n cael ei hystyried yn derfynwr y dafell flaenorol.
    ///
    /// Y sleisen honno fydd yr eitem olaf a ddychwelir gan yr ailadroddwr.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau treiddgar wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`.
    /// Mae'r elfen gyfatebol wedi'i chynnwys yn yr is-adran flaenorol fel terfynwr.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`, gan ddechrau ar ddiwedd y dafell a gweithio tuag yn ôl.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yn yr un modd â `split()`, os yw'r elfen gyntaf neu'r elfen olaf yn cyfateb, tafell wag fydd yr eitem gyntaf (neu'r olaf) a ddychwelir gan yr ailadroddwr.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau treiddgar wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`, gan ddechrau ar ddiwedd y dafell a gweithio tuag yn ôl.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`, wedi'u cyfyngu i ddychwelyd ar y mwyafrif o eitemau `n`.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// Bydd yr elfen olaf a ddychwelwyd, os o gwbl, yn cynnwys gweddill y dafell.
    ///
    /// # Examples
    ///
    /// Argraffwch y rhaniad tafell unwaith gan niferoedd rhanadwy 3 (hy, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau wedi'u gwahanu gan elfennau sy'n cyfateb i `pred`, wedi'u cyfyngu i ddychwelyd ar y mwyafrif o eitemau `n`.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// Bydd yr elfen olaf a ddychwelwyd, os o gwbl, yn cynnwys gweddill y dafell.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau wedi'u gwahanu gan elfennau sy'n cyfateb i `pred` wedi'u cyfyngu i ddychwelyd ar y mwyafrif o eitemau `n`.
    /// Mae hyn yn dechrau ar ddiwedd y dafell ac yn gweithio tuag yn ôl.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// Bydd yr elfen olaf a ddychwelwyd, os o gwbl, yn cynnwys gweddill y dafell.
    ///
    /// # Examples
    ///
    /// Argraffwch y rhaniad tafell unwaith, gan ddechrau o'r diwedd, yn ôl rhifau y gellir eu rhannu â 3 (hy, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Yn dychwelyd ailadroddwr dros is-haenau wedi'u gwahanu gan elfennau sy'n cyfateb i `pred` wedi'u cyfyngu i ddychwelyd ar y mwyafrif o eitemau `n`.
    /// Mae hyn yn dechrau ar ddiwedd y dafell ac yn gweithio tuag yn ôl.
    /// Nid yw'r elfen gyfatebol wedi'i chynnwys yn yr is-raddfeydd.
    ///
    /// Bydd yr elfen olaf a ddychwelwyd, os o gwbl, yn cynnwys gweddill y dafell.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Yn dychwelyd `true` os yw'r sleisen yn cynnwys elfen gyda'r gwerth penodol.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Os nad oes gennych `&T`, ond dim ond `&U` fel bod `T: Borrow<U>` (ee
    /// `Llinyn: Benthyg<str>`), gallwch ddefnyddio `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // sleisen o `String`
    /// assert!(v.iter().any(|e| e == "hello")); // chwilio gyda `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Yn dychwelyd `true` os yw `needle` yn rhagddodiad o'r sleisen.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Dychwelwch `true` bob amser os yw `needle` yn dafell wag:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Yn dychwelyd `true` os yw `needle` yn ôl-ddodiad o'r dafell.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Dychwelwch `true` bob amser os yw `needle` yn dafell wag:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Yn dychwelyd is-adran gyda'r rhagddodiad wedi'i dynnu.
    ///
    /// Os yw'r sleisen yn dechrau gyda `prefix`, yn dychwelyd yr aruchel ar ôl y rhagddodiad, wedi'i lapio yn `Some`.
    /// Os yw `prefix` yn wag, dim ond dychwelyd y sleisen wreiddiol.
    ///
    /// Os nad yw'r sleisen yn dechrau gyda `prefix`, yn dychwelyd `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Bydd angen ailysgrifennu'r swyddogaeth hon os a phan ddaw SlicePattern yn fwy soffistigedig.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Yn dychwelyd is-adran gyda'r ôl-ddodiad wedi'i dynnu.
    ///
    /// Os yw'r sleisen yn gorffen gyda `suffix`, yn dychwelyd yr is-ddeiliad cyn yr ôl-ddodiad, wedi'i lapio yn `Some`.
    /// Os yw `suffix` yn wag, dim ond dychwelyd y sleisen wreiddiol.
    ///
    /// Os nad yw'r sleisen yn gorffen gyda `suffix`, yn dychwelyd `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Bydd angen ailysgrifennu'r swyddogaeth hon os a phan ddaw SlicePattern yn fwy soffistigedig.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Mae Binary yn chwilio'r sleisen hon wedi'i didoli am elfen benodol.
    ///
    /// Os canfyddir y gwerth yna dychwelir [`Result::Ok`], sy'n cynnwys mynegai yr elfen baru.
    /// Os oes sawl gêm, yna gellid dychwelyd unrhyw un o'r gemau.
    /// Os na ddarganfyddir y gwerth yna dychwelir [`Result::Err`], sy'n cynnwys y mynegai lle y gellid mewnosod elfen baru wrth gynnal trefn wedi'i didoli.
    ///
    ///
    /// Gweler hefyd [`binary_search_by`], [`binary_search_by_key`], a [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Yn edrych ar gyfres o bedair elfen.
    /// Mae'r cyntaf i'w gael, gyda safle unigryw;ni cheir yr ail a'r trydydd;gallai'r pedwerydd gyd-fynd ag unrhyw safle yn `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Os ydych chi am fewnosod eitem i vector wedi'i didoli, wrth gynnal trefn didoli:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Mae Binary yn chwilio'r sleisen hon wedi'i didoli gyda swyddogaeth gymharydd.
    ///
    /// Dylai'r swyddogaeth gymharydd weithredu gorchymyn sy'n gyson â threfn didoli'r sleisen sylfaenol, gan ddychwelyd cod archeb sy'n nodi ai `Less`, `Equal` neu `Greater` yw'r ddadl a ddymunir.
    ///
    ///
    /// Os canfyddir y gwerth yna dychwelir [`Result::Ok`], sy'n cynnwys mynegai yr elfen baru.Os oes sawl gêm, yna gellid dychwelyd unrhyw un o'r gemau.
    /// Os na ddarganfyddir y gwerth yna dychwelir [`Result::Err`], sy'n cynnwys y mynegai lle y gellid mewnosod elfen baru wrth gynnal trefn wedi'i didoli.
    ///
    /// Gweler hefyd [`binary_search`], [`binary_search_by_key`], a [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Yn edrych ar gyfres o bedair elfen.Mae'r cyntaf i'w gael, gyda safle unigryw;ni cheir yr ail a'r trydydd;gallai'r pedwerydd gyd-fynd ag unrhyw safle yn `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // DIOGELWCH: mae'r alwad yn ddiogel gan yr invariants canlynol:
            // - `mid >= 0`
            // - `mid < size`: Mae `mid` wedi'i gyfyngu gan `[left; right)` wedi'i rwymo.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Y rheswm pam ein bod yn defnyddio llif rheoli if/else yn hytrach na chyfateb yw oherwydd bod paru yn ail-archebu gweithrediadau cymharu, sy'n berffaith sensitif.
            //
            // Dyma asm x86 ar gyfer u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Mae Binary yn chwilio'r sleisen hon wedi'i didoli gyda swyddogaeth echdynnu allweddol.
    ///
    /// Yn tybio bod y dafell yn cael ei didoli yn ôl yr allwedd, er enghraifft gyda [`sort_by_key`] yn defnyddio'r un swyddogaeth echdynnu allweddol.
    ///
    /// Os canfyddir y gwerth yna dychwelir [`Result::Ok`], sy'n cynnwys mynegai yr elfen baru.
    /// Os oes sawl gêm, yna gellid dychwelyd unrhyw un o'r gemau.
    /// Os na ddarganfyddir y gwerth yna dychwelir [`Result::Err`], sy'n cynnwys y mynegai lle y gellid mewnosod elfen baru wrth gynnal trefn wedi'i didoli.
    ///
    ///
    /// Gweler hefyd [`binary_search`], [`binary_search_by`], a [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Yn edrych ar gyfres o bedair elfen mewn tafell o barau wedi'u didoli yn ôl eu hail elfennau.
    /// Mae'r cyntaf i'w gael, gyda safle unigryw;ni cheir yr ail a'r trydydd;gallai'r pedwerydd gyd-fynd ag unrhyw safle yn `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Caniateir Lint rustdoc::broken_intra_doc_links gan fod `slice::sort_by_key` yn crate `alloc`, ac o'r herwydd nid yw'n bodoli eto wrth adeiladu `core`.
    //
    // dolenni i lawr yr afon crate: #74481.Gan mai dim ond yn libstd (#73423) y cofnodir pethau cyntefig, nid yw hyn byth yn arwain at dorri cysylltiadau yn ymarferol.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Yn didoli'r dafell, ond efallai na fydd yn cadw trefn elfennau cyfartal.
    ///
    /// Mae'r math hwn yn ansefydlog (h.y., gall ail-archebu elfennau cyfartal), yn ei le (hy, nid yw'n dyrannu), ac *O*(*n*\*log(* n*)) achos gwaethaf.
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn seiliedig ar [pattern-defeating quicksort][pdqsort] gan Orson Peters, sy'n cyfuno achos cyflym cyflym quicksort ar hap â'r achos gwaethaf cyflym o heapsort, wrth gyflawni amser llinellol ar dafelli â phatrymau penodol.
    /// Mae'n defnyddio rhywfaint o hap i osgoi achosion dirywiol, ond gyda seed sefydlog i ddarparu ymddygiad penderfyniadol bob amser.
    ///
    /// Yn nodweddiadol mae'n gyflymach na didoli sefydlog, ac eithrio mewn ychydig o achosion arbennig, ee, pan fydd y sleisen yn cynnwys sawl dilyniant didoli cydgysylltiedig.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Yn didoli'r sleisen â swyddogaeth gymharydd, ond efallai na fydd yn cadw trefn elfennau cyfartal.
    ///
    /// Mae'r math hwn yn ansefydlog (h.y., gall ail-archebu elfennau cyfartal), yn ei le (hy, nid yw'n dyrannu), ac *O*(*n*\*log(* n*)) achos gwaethaf.
    ///
    /// Rhaid i'r swyddogaeth gymharydd ddiffinio cyfanswm archebu ar gyfer yr elfennau yn y dafell.Os nad yw'r archebu'n gyfanswm, mae trefn yr elfennau yn amhenodol.Gorchymyn yw cyfanswm archeb os yw (ar gyfer pob `a`, `b` a `c`):
    ///
    /// * cyfanswm a gwrthsymmetrig: mae union un o `a < b`, `a == b` neu `a > b` yn wir, a
    /// * trawsnewidiol, mae `a < b` a `b < c` yn awgrymu `a < c`.Rhaid i'r un peth ddal ar gyfer `==` a `>`.
    ///
    /// Er enghraifft, er nad yw [`f64`] yn gweithredu [`Ord`] oherwydd `NaN != NaN`, gallwn ddefnyddio `partial_cmp` fel ein swyddogaeth didoli pan wyddom nad yw'r sleisen yn cynnwys `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn seiliedig ar [pattern-defeating quicksort][pdqsort] gan Orson Peters, sy'n cyfuno achos cyflym cyflym quicksort ar hap â'r achos gwaethaf cyflym o heapsort, wrth gyflawni amser llinellol ar dafelli â phatrymau penodol.
    /// Mae'n defnyddio rhywfaint o hap i osgoi achosion dirywiol, ond gyda seed sefydlog i ddarparu ymddygiad penderfyniadol bob amser.
    ///
    /// Yn nodweddiadol mae'n gyflymach na didoli sefydlog, ac eithrio mewn ychydig o achosion arbennig, ee, pan fydd y sleisen yn cynnwys sawl dilyniant didoli cydgysylltiedig.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // didoli gwrthdroi
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Yn didoli'r dafell â swyddogaeth echdynnu allweddol, ond efallai na fydd yn cadw trefn elfennau cyfartal.
    ///
    /// Mae'r math hwn yn ansefydlog (hy, gall ail-archebu elfennau cyfartal), yn ei le (hy, nid yw'n dyrannu), ac *O*(m\* * n *\* log(*n*)) achos gwaethaf, lle mae'r swyddogaeth allweddol yn *O*(*m*).
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn seiliedig ar [pattern-defeating quicksort][pdqsort] gan Orson Peters, sy'n cyfuno achos cyflym cyflym quicksort ar hap â'r achos gwaethaf cyflym o heapsort, wrth gyflawni amser llinellol ar dafelli â phatrymau penodol.
    /// Mae'n defnyddio rhywfaint o hap i osgoi achosion dirywiol, ond gyda seed sefydlog i ddarparu ymddygiad penderfyniadol bob amser.
    ///
    /// Oherwydd ei strategaeth galw allweddol, mae [`sort_unstable_by_key`](#method.sort_unstable_by_key) yn debygol o fod yn arafach na [`sort_by_cached_key`](#method.sort_by_cached_key) mewn achosion lle mae'r swyddogaeth allweddol yn ddrud.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ail-drefnwch y dafell fel bod yr elfen yn `index` yn ei safle olaf wedi'i didoli.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Ail-drefnwch y sleisen â swyddogaeth gymharydd fel bod yr elfen yn `index` yn ei safle didoli terfynol.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Ail-drefnwch y dafell gyda swyddogaeth echdynnu allweddol fel bod yr elfen yn `index` yn ei safle terfynol wedi'i didoli.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Ail-drefnwch y dafell fel bod yr elfen yn `index` yn ei safle olaf wedi'i didoli.
    ///
    /// Mae gan yr ail-archebu hwn yr eiddo ychwanegol y bydd unrhyw werth yn safle `i < index` yn llai na neu'n hafal i unrhyw werth yn safle `j > index`.
    /// Yn ogystal, mae'r aildrefnu hwn yn ansefydlog (h.y.
    /// gall unrhyw nifer o elfennau cyfartal ddod i ben yn safle `index`), yn ei le (h.y.
    /// ddim yn dyrannu), ac *O*(*n*) achos gwaethaf.
    /// Gelwir y swyddogaeth hon hefyd yn "kth element" mewn llyfrgelloedd eraill.
    /// Mae'n dychwelyd tripled o'r gwerthoedd canlynol: pob elfen yn llai na'r un yn y mynegai penodol, y gwerth yn y mynegai penodol, a phob elfen yn fwy na'r un yn y mynegai penodol.
    ///
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn seiliedig ar y gyfran quickselect o'r un algorithm quicksort a ddefnyddir ar gyfer [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics pan `index >= len()`, sy'n golygu ei fod bob amser yn panics ar dafelli gwag.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Dewch o hyd i'r canolrif
    /// v.select_nth_unstable(2);
    ///
    /// // Byddwn ond yn cael eu gwarantu y bydd y dafell fod yn un o'r canlynol, yn seiliedig ar y ffordd yr ydym yn trefnu am y mynegai penodol.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ail-drefnwch y sleisen â swyddogaeth gymharydd fel bod yr elfen yn `index` yn ei safle didoli terfynol.
    ///
    /// Mae gan yr aildrefnu hwn yr eiddo ychwanegol y bydd unrhyw werth yn safle `i < index` yn llai na neu'n hafal i unrhyw werth yn safle `j > index` gan ddefnyddio'r swyddogaeth gymharydd.
    /// Yn ogystal, mae'r aildrefnu hwn yn ansefydlog (hy gall unrhyw nifer o elfennau cyfartal ddod i ben yn safle `index`), yn ei le (hy ddim yn dyrannu), ac *O*(*n*) yn yr achos gwaethaf.
    /// Gelwir y swyddogaeth hon hefyd yn "kth element" mewn llyfrgelloedd eraill.
    /// Mae'n dychwelyd tripled o'r gwerthoedd canlynol: pob elfen yn llai na'r un yn y mynegai penodol, y gwerth yn y mynegai penodol, a'r holl elfennau sy'n fwy na'r un yn y mynegai penodol, gan ddefnyddio'r swyddogaeth gymharydd a ddarperir.
    ///
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn seiliedig ar y gyfran quickselect o'r un algorithm quicksort a ddefnyddir ar gyfer [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics pan `index >= len()`, sy'n golygu ei fod bob amser yn panics ar dafelli gwag.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Darganfyddwch y canolrif fel petai'r sleisen wedi'i didoli mewn trefn ddisgynnol.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Byddwn ond yn cael eu gwarantu y bydd y dafell fod yn un o'r canlynol, yn seiliedig ar y ffordd yr ydym yn trefnu am y mynegai penodol.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ail-drefnwch y dafell gyda swyddogaeth echdynnu allweddol fel bod yr elfen yn `index` yn ei safle terfynol wedi'i didoli.
    ///
    /// Mae gan yr ail-archebu hwn yr eiddo ychwanegol y bydd unrhyw werth yn safle `i < index` yn llai na neu'n hafal i unrhyw werth yn safle `j > index` gan ddefnyddio'r swyddogaeth echdynnu allweddol.
    /// Yn ogystal, mae'r aildrefnu hwn yn ansefydlog (hy gall unrhyw nifer o elfennau cyfartal ddod i ben yn safle `index`), yn ei le (hy ddim yn dyrannu), ac *O*(*n*) yn yr achos gwaethaf.
    /// Gelwir y swyddogaeth hon hefyd yn "kth element" mewn llyfrgelloedd eraill.
    /// Mae'n dychwelyd tripled o'r gwerthoedd canlynol: pob elfen yn llai na'r un yn y mynegai penodol, y gwerth yn y mynegai penodol, a'r holl elfennau sy'n fwy na'r un yn y mynegai penodol, gan ddefnyddio'r swyddogaeth echdynnu allweddol a ddarperir.
    ///
    ///
    /// # Gweithredu cyfredol
    ///
    /// Mae'r algorithm cyfredol yn seiliedig ar y gyfran quickselect o'r un algorithm quicksort a ddefnyddir ar gyfer [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics pan `index >= len()`, sy'n golygu ei fod bob amser yn panics ar dafelli gwag.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Dychwelwch y canolrif fel pe bai'r arae wedi'i didoli yn ôl ei werth absoliwt.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Byddwn ond yn cael eu gwarantu y bydd y dafell fod yn un o'r canlynol, yn seiliedig ar y ffordd yr ydym yn trefnu am y mynegai penodol.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Yn symud yr holl elfennau ailadroddus yn olynol i ddiwedd y dafell yn ôl gweithrediad [`PartialEq`] trait.
    ///
    ///
    /// Yn dychwelyd dwy dafell.Nid yw'r cyntaf yn cynnwys unrhyw elfennau ailadroddus yn olynol.
    /// Mae'r ail yn cynnwys yr holl ddyblygiadau mewn unrhyw drefn benodol.
    ///
    /// Os yw'r sleisen yn cael ei didoli, nid yw'r sleisen gyntaf a ddychwelwyd yn cynnwys unrhyw ddyblygiadau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Yn symud pob elfen ond y cyntaf o elfennau olynol i ddiwedd y dafell gan fodloni perthynas gydraddoldeb benodol.
    ///
    /// Yn dychwelyd dwy dafell.Nid yw'r cyntaf yn cynnwys unrhyw elfennau ailadroddus yn olynol.
    /// Mae'r ail yn cynnwys yr holl ddyblygiadau mewn unrhyw drefn benodol.
    ///
    /// Mae'r swyddogaeth `same_bucket` yn cael ei basio cyfeiriadau at ddwy elfen o'r dafell a rhaid iddi benderfynu a yw'r elfennau'n cymharu'n gyfartal.
    /// Mae'r elfennau'n cael eu pasio mewn trefn arall o'u trefn yn y dafell, felly os yw `same_bucket(a, b)` yn dychwelyd `true`, mae `a` yn cael ei symud ar ddiwedd y dafell.
    ///
    ///
    /// Os yw'r sleisen yn cael ei didoli, nid yw'r sleisen gyntaf a ddychwelwyd yn cynnwys unrhyw ddyblygiadau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Er bod gennym gyfeiriad treiddgar at `self`, ni allwn wneud newidiadau *mympwyol*.Gallai'r galwadau `same_bucket` panic, felly mae'n rhaid i ni sicrhau bod y dafell mewn cyflwr dilys bob amser.
        //
        // Y ffordd yr ydym yn delio â hyn yw trwy ddefnyddio cyfnewidiadau;rydym yn ailadrodd dros yr holl elfennau, gan gyfnewid wrth i ni fynd fel bod yr elfennau yr ydym am eu cadw yn y blaen ar y diwedd, a'r rhai yr ydym am eu gwrthod yn y cefn.
        // Yna gallwn rannu'r dafell.
        // Mae'r llawdriniaeth hon yn dal i fod yn `O(n)`.
        //
        // Enghraifft: Dechreuwn yn y wladwriaeth hon, lle mae `r` yn cynrychioli "nesaf
        // darllenwch "ac mae `w` yn cynrychioli" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // O gymharu self[r] yn erbyn yr hunan [w-1], nid yw hwn yn ddyblyg, felly rydym yn cyfnewid self[r] a self[w] (dim effaith fel r==w) ac yna'n cynyddu'n r ac w, gan ein gadael gyda:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // O gymharu self[r] yn erbyn yr hunan [w-1], mae'r gwerth hwn yn ddyblyg, felly rydym yn cynyddiad `r` ond yn gadael popeth arall yn ddigyfnewid:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // O gymharu self[r] yn erbyn eich hun [w-1], nid yw hwn yn ddyblyg, felly cyfnewidiwch self[r] a self[w] a symud ymlaen r ac w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ddim yn ddyblyg, ailadroddwch:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Dyblyg, advance r. End o dafell.Wedi'i rannu yn w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // DIOGELWCH: mae'r cyflwr `while` yn gwarantu `next_read` a `next_write`
        // yn llai na `len`, felly maent y tu mewn i `self`.
        // `prev_ptr_write` yn pwyntio at un elfen cyn `ptr_write`, ond mae `next_write` yn dechrau am 1, felly nid yw `prev_ptr_write` byth yn llai na 0 ac mae y tu mewn i'r dafell.
        // Mae hyn yn cyflawni'r gofynion ar gyfer dad-gynadledda `ptr_read`, `prev_ptr_write` a `ptr_write`, ac ar gyfer defnyddio `ptr.add(next_read)`, `ptr.add(next_write - 1)` a `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` hefyd yn cael ei gynyddu fesul awr ar y mwyaf ar y mwyaf, sy'n golygu nad oes unrhyw elfen yn cael ei hepgor pan fydd angen ei chyfnewid.
        //
        // `ptr_read` ac nid yw `prev_ptr_write` byth yn pwyntio at yr un elfen.Mae hyn yn ofynnol er mwyn i `&mut *ptr_read`, `&mut* prev_ptr_write` fod yn ddiogel.
        // Yr esboniad yn syml yw bod `next_read >= next_write` bob amser yn wir, felly mae `next_read > next_write - 1` hefyd.
        //
        //
        //
        //
        //
        unsafe {
            // Osgoi gwiriadau ffiniau trwy ddefnyddio awgrymiadau amrwd.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Yn symud pob elfen ond y cyntaf o elfennau olynol i ddiwedd y dafell sy'n datrys i'r un allwedd.
    ///
    ///
    /// Yn dychwelyd dwy dafell.Nid yw'r cyntaf yn cynnwys unrhyw elfennau ailadroddus yn olynol.
    /// Mae'r ail yn cynnwys yr holl ddyblygiadau mewn unrhyw drefn benodol.
    ///
    /// Os yw'r sleisen yn cael ei didoli, nid yw'r sleisen gyntaf a ddychwelwyd yn cynnwys unrhyw ddyblygiadau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Yn cylchdroi'r sleisen yn ei lle fel bod elfennau `mid` cyntaf y dafell yn symud i'r diwedd tra bod yr elfennau `self.len() - mid` olaf yn symud i'r tu blaen.
    /// Ar ôl galw `rotate_left`, yr elfen o'r blaen ym mynegai `mid` fydd yr elfen gyntaf yn y dafell.
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon yn panic os yw `mid` yn fwy na hyd y dafell.Sylwch fod `mid == self.len()` yn gwneud _not_ panic a'i fod yn gylchdro dim-op.
    ///
    /// # Complexity
    ///
    /// Yn cymryd llinellol (mewn amser `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Cylchdroi aruchel:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // DIOGELWCH: Mae'r ystod `[p.add(mid) - mid, p.add(mid) + k)` yn ddibwys
        // ddilys ar gyfer darllen ac ysgrifennu, fel sy'n ofynnol gan `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Yn cylchdroi'r sleisen yn ei lle fel bod elfennau `self.len() - k` cyntaf y dafell yn symud i'r diwedd tra bod yr elfennau `k` olaf yn symud i'r tu blaen.
    /// Ar ôl galw `rotate_right`, yr elfen o'r blaen ym mynegai `self.len() - k` fydd yr elfen gyntaf yn y dafell.
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon yn panic os yw `k` yn fwy na hyd y dafell.Sylwch fod `k == self.len()` yn gwneud _not_ panic a'i fod yn gylchdro dim-op.
    ///
    /// # Complexity
    ///
    /// Yn cymryd llinellol (mewn amser `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Cylchdroi aruchel:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // DIOGELWCH: Mae'r ystod `[p.add(mid) - mid, p.add(mid) + k)` yn ddibwys
        // ddilys ar gyfer darllen ac ysgrifennu, fel sy'n ofynnol gan `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Yn llenwi `self` gydag elfennau trwy glonio `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Yn llenwi `self` gydag elfennau'n cael eu dychwelyd trwy alw cau dro ar ôl tro.
    ///
    /// Mae'r dull hwn yn defnyddio cau i greu gwerthoedd newydd.Os byddai'n well gennych [`Clone`] werth penodol, defnyddiwch [`fill`].
    /// Os ydych chi am ddefnyddio'r [`Default`] trait i gynhyrchu gwerthoedd, gallwch drosglwyddo [`Default::default`] wrth i'r ddadl.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Copïwch yr elfennau o `src` i `self`.
    ///
    /// Rhaid i hyd `src` fod yr un peth â `self`.
    ///
    /// Os yw `T` yn gweithredu `Copy`, gall fod yn fwy perfformiadol i ddefnyddio [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon panic os yw'r ddau dafell wedi wahanol hyd.
    ///
    /// # Examples
    ///
    /// Clonio dwy elfen o dafell i mewn i un arall:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Oherwydd bod yn rhaid i'r tafelli fod yr un hyd, rydyn ni'n sleisio'r dafell ffynhonnell o bedair elfen i ddwy.
    /// // Bydd yn panic os na wnawn hyn.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Mae Rust yn gorfodi mai dim ond un cyfeiriad symudol y gellir ei gael heb unrhyw gyfeiriadau na ellir eu trosglwyddo at ddarn penodol o ddata mewn cwmpas penodol.
    /// Oherwydd hyn, bydd ceisio defnyddio `clone_from_slice` ar dafell sengl yn arwain at fethiant llunio:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// I weithio o amgylch hyn, gallwn ddefnyddio [`split_at_mut`] i greu dau is-dafell benodol o dafell:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Copïwch yr holl elfennau o `src` i `self`, gan ddefnyddio cofiadwy.
    ///
    /// Rhaid i hyd `src` fod yr un peth â `self`.
    ///
    /// Os nad yw `T` yn gweithredu `Copy`, defnyddiwch [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon panic os yw'r ddau dafell wedi wahanol hyd.
    ///
    /// # Examples
    ///
    /// Copïo dwy elfen o dafell i mewn i un arall:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Oherwydd bod yn rhaid i'r tafelli fod yr un hyd, rydyn ni'n sleisio'r dafell ffynhonnell o bedair elfen i ddwy.
    /// // Bydd yn panic os na wnawn hyn.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Mae Rust yn gorfodi mai dim ond un cyfeiriad symudol y gellir ei gael heb unrhyw gyfeiriadau na ellir eu trosglwyddo at ddarn penodol o ddata mewn cwmpas penodol.
    /// Oherwydd hyn, bydd ceisio defnyddio `copy_from_slice` ar dafell sengl yn arwain at fethiant llunio:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// I weithio o amgylch hyn, gallwn ddefnyddio [`split_at_mut`] i greu dau is-dafell benodol o dafell:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Rhoddwyd llwybr cod panic mewn swyddogaeth oer i beidio â chwyddo'r safle galw.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // DIOGELWCH: Mae `self` yn ddilys ar gyfer elfennau `self.len()` yn ôl diffiniad, ac roedd `src`
        // gwirio i fod yr un hyd.
        // Ni all y tafelli orgyffwrdd oherwydd bod cyfeiriadau symudol yn unigryw.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Copïwch elfennau o un rhan o'r dafell i ran arall ohono'i hun, gan ddefnyddio memmove.
    ///
    /// `src` yw'r ystod o fewn `self` i gopïo ohoni.
    /// `dest` yw mynegai cychwynnol yr ystod o fewn `self` i gopïo iddo, a fydd yr un hyd â `src`.
    /// Gall y ddwy ystod orgyffwrdd.
    /// Rhaid i bennau'r ddwy ystod fod yn llai na neu'n hafal i `self.len()`.
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon yn panic os yw'r naill amrediad yn fwy na diwedd y dafell, neu os yw diwedd `src` cyn cychwyn.
    ///
    ///
    /// # Examples
    ///
    /// Copïo pedwar beit mewn sleisen:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // DIOGELWCH: mae'r amodau ar gyfer `ptr::copy` i gyd wedi'u gwirio uchod,
        // felly hefyd y rhai ar gyfer `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Yn cyfnewid pob elfen yn `self` gyda'r rhai yn `other`.
    ///
    /// Rhaid i hyd `other` fod yr un peth â `self`.
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon panic os yw'r ddau dafell wedi wahanol hyd.
    ///
    /// # Example
    ///
    /// Cyfnewid dwy elfen ar draws tafelli:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Mae Rust yn gorfodi mai dim ond un cyfeiriad cyfnewidiol y gellir ei gael at ddarn penodol o ddata mewn cwmpas penodol.
    ///
    /// Oherwydd hyn, bydd ceisio defnyddio `swap_with_slice` ar sleisen unigol yn arwain at fethiant crynhoi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// I weithio o amgylch hyn, gallwn ddefnyddio [`split_at_mut`] i greu dau is-dafell symudol wahanol o dafell:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // DIOGELWCH: Mae `self` yn ddilys ar gyfer elfennau `self.len()` yn ôl diffiniad, ac roedd `src`
        // gwirio i fod yr un hyd.
        // Ni all y tafelli orgyffwrdd oherwydd bod cyfeiriadau symudol yn unigryw.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Swyddogaeth i gyfrifo darnau o'r sleisen ganol a llusgo ar gyfer `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Yr hyn yr ydym yn ei wneud am `rest` yw darganfod pa luosog o `U`s y gallwn eu rhoi yn y nifer isaf o`T`s.
        //
        // A faint o `T`s sydd eu hangen arnom ar gyfer pob "multiple" o'r fath.
        //
        // Ystyriwch er enghraifft T=u8 U=u16.Yna gallwn roi 1 U mewn 2 Ts.Syml.
        // Nawr, ystyriwch, er enghraifft, achos lle mae maint_of: :<T>=16, maint_of::<U>=24.</u>
        // Gallwn roi 2 Ni yn lle pob 3 Ts yn y sleisen `rest`.
        // Ychydig yn fwy cymhleth.
        //
        // Y fformiwla i gyfrifo hyn yw:
        //
        // Ni= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Ehangu a symleiddio:
        //
        // Ni=maint_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Yn ffodus gan fod hyn i gyd yn cael ei werthuso'n gyson ... nid yw perfformiad yma o bwys!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algorithm ailadroddol stein Dylem ddal i wneud yr `const fn` hwn (a dychwelyd i algorithm ailadroddus os gwnawn hynny) oherwydd mae dibynnu ar llvm i gyd-fynd â hyn i gyd ... wel, mae'n fy ngwneud yn anghyfforddus.
            //
            //

            // DIOGELWCH: Gwirir bod `a` a `b` yn werthoedd nad ydynt yn sero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // tynnu holl ffactorau 2 o b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // DIOGELWCH: Gwirir bod `b` yn ddi-sero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Gyda'r wybodaeth hon, gallwn ddarganfod faint o `U` y gallwn eu ffitio!
        let us_len = self.len() / ts * us;
        // A faint o `T`s fydd yn y sleisen llusgo!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Trosglwyddwch y dafell i dafell o fath arall, gan sicrhau bod aliniad y mathau yn cael ei gynnal.
    ///
    /// Mae'r dull hwn yn rhannu'r sleisen yn dair sleisen benodol: rhagddodiad, tafell ganol o fath newydd wedi'i halinio'n gywir, a'r sleisen ôl-ddodiad.
    /// Efallai y bydd y dull yn gwneud y sleisen ganol yr hyd mwyaf posibl ar gyfer math penodol a sleisen fewnbwn, ond dim ond perfformiad eich algorithm ddylai ddibynnu ar hynny, nid ei gywirdeb.
    ///
    /// Caniateir dychwelyd yr holl ddata mewnbwn fel y rhagddodiad neu'r sleisen ôl-ddodiad.
    ///
    /// Nid oes pwrpas i'r dull hwn pan fydd naill ai elfen fewnbwn `T` neu elfen allbwn `U` o faint sero a bydd yn dychwelyd y dafell wreiddiol heb hollti unrhyw beth.
    ///
    /// # Safety
    ///
    /// Yn y bôn, `transmute` yw'r dull hwn mewn perthynas â'r elfennau yn y sleisen ganol a ddychwelwyd, felly mae'r holl gafeatau arferol sy'n ymwneud â `transmute::<T, U>` hefyd yn berthnasol yma.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Sylwch y bydd y rhan fwyaf o'r swyddogaeth hon yn cael ei gwerthuso'n gyson,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // trin ZSTs yn arbennig, hynny yw-peidiwch â'u trin o gwbl.
            return (self, &[], &[]);
        }

        // Yn gyntaf, darganfyddwch ar ba bwynt rydyn ni'n rhannu rhwng y sleisen gyntaf a'r 2il dafell.
        // Hawdd gyda ptr.align_offset.
        let ptr = self.as_ptr();
        // DIOGELWCH: Gweler y dull `align_to_mut` i gael y sylw diogelwch manwl.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // DIOGELWCH: nawr mae `rest` wedi'i alinio'n bendant, felly mae `from_raw_parts` isod yn iawn,
            // gan fod y galwr yn gwarantu y gallwn drawsnewid `T` i `U` yn ddiogel.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Trosglwyddwch y dafell i dafell o fath arall, gan sicrhau bod aliniad y mathau yn cael ei gynnal.
    ///
    /// Mae'r dull hwn yn rhannu'r sleisen yn dair sleisen benodol: rhagddodiad, tafell ganol o fath newydd wedi'i halinio'n gywir, a'r sleisen ôl-ddodiad.
    /// Efallai y bydd y dull yn gwneud y sleisen ganol yr hyd mwyaf posibl ar gyfer math penodol a sleisen fewnbwn, ond dim ond perfformiad eich algorithm ddylai ddibynnu ar hynny, nid ei gywirdeb.
    ///
    /// Caniateir dychwelyd yr holl ddata mewnbwn fel y rhagddodiad neu'r sleisen ôl-ddodiad.
    ///
    /// Nid oes pwrpas i'r dull hwn pan fydd naill ai elfen fewnbwn `T` neu elfen allbwn `U` o faint sero a bydd yn dychwelyd y dafell wreiddiol heb hollti unrhyw beth.
    ///
    /// # Safety
    ///
    /// Yn y bôn, `transmute` yw'r dull hwn mewn perthynas â'r elfennau yn y sleisen ganol a ddychwelwyd, felly mae'r holl gafeatau arferol sy'n ymwneud â `transmute::<T, U>` hefyd yn berthnasol yma.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Sylwch y bydd y rhan fwyaf o'r swyddogaeth hon yn cael ei gwerthuso'n gyson,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // trin ZSTs yn arbennig, hynny yw-peidiwch â'u trin o gwbl.
            return (self, &mut [], &mut []);
        }

        // Yn gyntaf, darganfyddwch ar ba bwynt rydyn ni'n rhannu rhwng y sleisen gyntaf a'r 2il dafell.
        // Hawdd gyda ptr.align_offset.
        let ptr = self.as_ptr();
        // DIOGELWCH: Dyma ni yn sicrhau y byddwn yn defnyddio awgrymiadau wedi'u halinio ar gyfer U ar gyfer y
        // gweddill y dull.Gwneir hyn trwy basio pwyntydd i&[T] gydag aliniad wedi'i dargedu at U.
        // `crate::ptr::align_offset` yn cael ei alw gyda phwyntydd `ptr` wedi'i alinio'n gywir ac yn ddilys (mae'n dod o gyfeiriad at `self`) a gyda maint sy'n bwer o ddau (gan ei fod yn dod o'r alignement ar gyfer U), gan fodloni ei gyfyngiadau diogelwch.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ni allwn ddefnyddio `rest` eto ar ôl hyn, byddai hynny'n annilysu ei alias `mut_ptr`!DIOGELWCH: gweler y sylwadau ar gyfer `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Yn gwirio a yw elfennau'r sleisen hon yn cael eu didoli.
    ///
    /// Hynny yw, ar gyfer pob elfen `a` a'i elfen `b` ganlynol, rhaid i `a <= b` ddal.Os yw'r sleisen yn cynhyrchu'n union sero neu un elfen, dychwelir `true`.
    ///
    /// Sylwer mai dim ond os `PartialOrd`, ond nid `Ord` `Self::Item` yw, y diffiniad uchod yn awgrymu y ffwythiant yma yn dychwelyd `false` os nad yw unrhyw ddwy eitem yn olynol yn gymaradwy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Yn gwirio a yw elfennau'r sleisen hon yn cael eu didoli gan ddefnyddio'r swyddogaeth gymharydd benodol.
    ///
    /// Yn lle defnyddio `PartialOrd::partial_cmp`, swyddogaeth hon yn defnyddio'r swyddogaeth `compare` a roddir i benderfynu ar y archebu dwy elfen.
    /// Ar wahân i hynny, mae'n cyfateb i [`is_sorted`];gweld ei ddogfennaeth am ragor o wybodaeth.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Yn gwirio a yw elfennau'r sleisen hon yn cael eu didoli gan ddefnyddio'r swyddogaeth echdynnu allweddol a roddir.
    ///
    /// Yn lle cymharu elfennau'r sleisen yn uniongyrchol, mae'r swyddogaeth hon yn cymharu allweddi'r elfennau, fel y'u pennir gan `f`.
    /// Ar wahân i hynny, mae'n cyfateb i [`is_sorted`];gweld ei ddogfennaeth am ragor o wybodaeth.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Yn dychwelyd mynegai pwynt y rhaniad yn ôl y rhagfynegiad a roddir (mynegai elfen gyntaf yr ail raniad).
    ///
    /// Tybir bod y dafell wedi'i rhannu yn ôl yr ysglyfaeth a roddir.
    /// Mae hyn yn golygu bod yr holl elfennau y mae'r enillion ysglyfaethus yn wir amdanynt ar ddechrau'r sleisen a bod yr holl elfennau y mae'r dychweliadau ysglyfaethus yn ffug ar eu cyfer ar y diwedd.
    ///
    /// Er enghraifft, mae [7, 15, 3, 5, 4, 12, 6] wedi'i rannu o dan y rhagfynegiad x% 2!=0 (mae'r odrifau i gyd ar y dechrau, i gyd hyd yn oed ar y diwedd).
    ///
    /// Os nad yw'r sleisen hon wedi'i rhannu, mae'r canlyniad a ddychwelwyd yn amhenodol ac yn ddiystyr, gan fod y dull hwn yn cyflawni math o chwiliad deuaidd.
    ///
    /// Gweler hefyd [`binary_search`], [`binary_search_by`], a [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // DIOGELWCH: Pan fydd `left < right`, `left <= mid < right`.
            // Felly mae `left` bob amser yn cynyddu ac mae `right` bob amser yn gostwng, a dewisir y naill neu'r llall ohonynt.Yn y ddau achos mae `left <= right` yn fodlon.Felly os yw `left < right` mewn cam, mae `left <= right` yn fodlon yn y cam nesaf.
            //
            // Felly cyhyd â bod `left != right`, mae `0 <= left < right <= len` yn fodlon ac os yw'r achos hwn mae `0 <= mid < len` yn fodlon hefyd.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Mae angen i ni eu sleisio'n benodol i'r un hyd
        // i'w gwneud hi'n haws i'r optimizer ddileu ffiniau.
        // Ond gan na ellir dibynnu arno mae gennym hefyd arbenigedd penodol ar gyfer T: Copi.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Yn creu sleisen wag.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Yn creu sleisen wag symudol.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Patrymau mewn sleisys, ar hyn o bryd, dim ond `strip_prefix` a `strip_suffix` sy'n eu defnyddio.
/// Ar bwynt future, rydym yn gobeithio cyffredinoli `core::str::Pattern` (sydd ar adeg ysgrifennu yn gyfyngedig i `str`) i dafelli, ac yna bydd y trait hwn yn cael ei ddisodli neu ei ddiddymu.
///
pub trait SlicePattern {
    /// Math o elfen y dafell sy'n cael ei chyfateb.
    type Item;

    /// Ar hyn o bryd, mae angen sleisen ar ddefnyddwyr `SlicePattern`.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}