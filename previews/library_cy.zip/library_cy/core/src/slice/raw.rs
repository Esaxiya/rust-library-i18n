//! Swyddogaethau am ddim i greu `&[T]` a `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Yn ffurfio sleisen o bwyntydd a hyd.
///
/// Dadl `len` yw nifer yr **elfennau**, nid nifer y bytes.
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `data` rhaid iddo fod yn [valid] ar gyfer darlleniadau ar gyfer `len * mem::size_of::<T>()` llawer o beit, a rhaid ei alinio'n iawn.Mae hyn yn golygu yn benodol:
///
///     * Rhaid cynnwys ystod cof gyfan y dafell hon mewn un gwrthrych a ddyrannwyd!
///       Ni all tafelli fyth rychwantu sawl gwrthrych a ddyrannwyd.Gweler [below](#incorrect-usage) am enghraifft yn anghywir heb ystyried hyn.
///     * `data` rhaid iddo fod yn ddi-null ac wedi'i alinio hyd yn oed ar gyfer sleisys hyd sero.
///     Un rheswm am hyn yw y gall optimeiddiadau cynllun enwm ddibynnu ar gyfeiriadau (gan gynnwys sleisys o unrhyw hyd) yn cael eu halinio a heb fod yn null i'w gwahaniaethu oddi wrth ddata arall.
///     Gallwch gael pwyntydd y gellir ei ddefnyddio fel `data` ar gyfer sleisys hyd sero gan ddefnyddio [`NonNull::dangling()`].
///
/// * `data` rhaid pwyntio at werthoedd `len` olynol a gychwynnwyd yn gywir o fath `T`.
///
/// * Rhaid peidio â threiglo'r cof y cyfeirir ato gan y dafell a ddychwelwyd trwy gydol oes `'a`, ac eithrio y tu mewn i `UnsafeCell`.
///
/// * Rhaid i gyfanswm maint `len * mem::size_of::<T>()` y dafell beidio â bod yn fwy na `isize::MAX`.
///   Gweler dogfennaeth ddiogelwch [`pointer::offset`].
///
/// # Caveat
///
/// Mae oes y sleisen a ddychwelwyd yn cael ei chasglu o'i defnyddio.
/// Er mwyn atal camddefnydd damweiniol, awgrymir clymu'r oes â pha bynnag ffynhonnell ffynhonnell sy'n ddiogel yn y cyd-destun, megis trwy ddarparu swyddogaeth cynorthwyydd sy'n cymryd oes gwerth gwesteiwr ar gyfer y dafell, neu trwy anodi penodol.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // amlygu tafell ar gyfer un elfen
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Defnydd anghywir
///
/// Mae'r swyddogaeth `join_slices` ganlynol yn **ddi-sail** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Mae'r honiad uchod yn sicrhau bod `fst` a `snd` yn gyfagos, ond gallent gael eu cynnwys yn _different allocated objects_ o hyd, ac os felly mae creu'r sleisen hon yn ymddygiad heb ei ddiffinio.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` a `b` yn wahanol wrthrychau a ddyrannwyd ...
///     let a = 42;
///     let b = 27;
///     // ... a all serch hynny gael ei osod allan yn gyfagos er cof: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Cyflawni'r un swyddogaeth â [`from_raw_parts`], ac eithrio bod tafell mutable cael ei ddychwelyd.
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `data` rhaid iddo fod yn [valid] ar gyfer darllen ac ysgrifennu ar gyfer `len * mem::size_of::<T>()` lawer o beit, a rhaid ei alinio'n iawn.Mae hyn yn golygu yn benodol:
///
///     * Rhaid cynnwys ystod cof gyfan y dafell hon mewn un gwrthrych a ddyrannwyd!
///       Ni all tafelli fyth rychwantu sawl gwrthrych a ddyrannwyd.
///     * `data` rhaid iddo fod yn ddi-null ac wedi'i alinio hyd yn oed ar gyfer sleisys hyd sero.
///     Un rheswm am hyn yw y gall optimeiddiadau cynllun enwm ddibynnu ar gyfeiriadau (gan gynnwys sleisys o unrhyw hyd) yn cael eu halinio a heb fod yn null i'w gwahaniaethu oddi wrth ddata arall.
///
///     Gallwch gael pwyntydd y gellir ei ddefnyddio fel `data` ar gyfer sleisys hyd sero gan ddefnyddio [`NonNull::dangling()`].
///
/// * `data` rhaid pwyntio at werthoedd `len` olynol a gychwynnwyd yn gywir o fath `T`.
///
/// * Rhaid peidio â chyrchu'r cof y cyfeirir ato gan y sleisen a ddychwelwyd trwy unrhyw bwyntydd arall (nad yw'n deillio o'r gwerth dychwelyd) trwy gydol oes `'a`.
///   Gwaherddir darllen ac ysgrifennu mynediad.
///
/// * Rhaid i gyfanswm maint `len * mem::size_of::<T>()` y dafell beidio â bod yn fwy na `isize::MAX`.
///   Gweler dogfennaeth ddiogelwch [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Trosi cyfeiriad at T yn dafell o hyd 1 (heb gopïo).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Trosi cyfeiriad at T yn dafell o hyd 1 (heb gopïo).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}