#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Cyfleustodau sy'n gysylltiedig â rhwymiadau rhyngwyneb swyddogaeth dramor (FFI).

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Yn cyfateb i fath `void` C pan gaiff ei ddefnyddio fel [pointer].
///
/// Yn ei hanfod, `*const c_void` yn gyfwerth â C `const void*` a `*mut c_void` yn gyfwerth â C `void*`.
/// Wedi dweud hynny, nid yw hyn * yr un peth â math dychwelyd C `void`, sef math `()` Rust.
///
/// Er mwyn modelu awgrymiadau i fathau afloyw yn FFI, nes bod `extern type` wedi'i sefydlogi, argymhellir defnyddio deunydd lapio newtype o amgylch arae beit gwag.
///
/// Gweler y [Nomicon] am fanylion.
///
/// Gallai un ddefnyddio `std::os::raw::c_void` os ydyn nhw am gefnogi hen grynhowr Rust i lawr i 1.1.0.
/// Ar ôl Rust 1.30.0, cafodd ei ail-allforio y diffiniad hwn.
/// Am fwy o wybodaeth, darllenwch [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// DS, er LLVM i adnabod y math pwyntydd ddi-rym a chan swyddogaethau ymestyn fel malloc(), mae angen i ni gael ei gynrychioli fel Ff8 * yn LLVM bitcode.
// Mae'r enum a ddefnyddir yma yn sicrhau hyn ac yn atal camddefnyddio o'r fath "raw" drwy gael amrywiadau preifat yn unig.
// Mae angen dau amrywiadau, gan fod y compiler yn cwyno am y priodoledd repr fel arall ac mae angen o leiaf un amrywiad fel arall byddai'r enum cael ei anghyfannedd ac o leiaf byddai dereferencing arwyddion o'r fath yn UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// gweithredu sylfaenol `va_list`.
// Mae'r enw i yw WIP, gan ddefnyddio `VaListImpl` am y tro.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Ddigyfnewid dros `'f`, felly mae pob gwrthrych `VaListImpl<'f>` ei glymu i'r rhanbarth y swyddogaeth y mae'n ei ddiffinio yn
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 gweithredu ABI o `va_list`.
/// Gweler yr [AArch64 Procedure Call Standard] am ragor o fanylion.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC gweithredu ABI o `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 gweithredu ABI o `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Mae deunydd lapio ar gyfer `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Trosi `VaListImpl` yn `VaList` sy'n ddeuaidd-gydnaws â C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Trosi `VaListImpl` yn `VaList` sy'n ddeuaidd-gydnaws â C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Mae angen defnyddio'r VaArgSafe trait mewn rhyngwynebau cyhoeddus, fodd bynnag, rhaid peidio â chaniatáu i'r trait ei hun gael ei ddefnyddio y tu allan i'r modiwl hwn.
// Mae caniatáu i ddefnyddwyr weithredu'r trait ar gyfer math newydd (a thrwy hynny ganiatáu i'r va_arg cynhenid gael ei ddefnyddio ar fath newydd) yn debygol o achosi ymddygiad heb ei ddiffinio.
//
// FIXME(dlrobertson): Er mwyn defnyddio'r VaArgSafe trait mewn rhyngwyneb cyhoeddus ond hefyd yn sicrhau na ellir ei defnyddio mewn mannau eraill, mae angen i'r trait i fod yn gyhoeddus o fewn modiwl breifat.
// Unwaith RFC 2145 wedi cael ei roi ar waith yn edrych ar wella hyn.
//
//
//
//
mod sealed_trait {
    /// Trait sy'n caniatáu mathau ganiateir i'w defnyddio gyda [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Ymlaen i'r arg nesaf.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Mae copïau i'r `va_list` yn y lleoliad presennol.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // DIOGELWCH: rydym yn ysgrifennu at yr `MaybeUninit`, felly mae'n cael ei ymsefydlu ac mae `assume_init` yn gyfreithiol
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: dylai hyn ffonio `va_end`, ond does dim ffordd lân i wneud hynny
        // warantu y `drop` bob amser yn cael inlined yn ei galwr, felly byddai'r `va_end` yn cael eu galw yn uniongyrchol o'r un swyddogaeth fel y `va_copy` cyfatebol.
        // `man va_end` yn datgan bod C yn gofyn hyn, ac yn y bôn LLVM dilyn y semanteg C, felly mae angen i wneud yn siŵr fod `va_end` a elwir bob amser o'r un swyddogaeth â `va_copy`.
        //
        // Am fwy o fanylion, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Mae hyn yn gweithio am y tro, gan fod `va_end` yn no-op ar yr holl dargedau LLVM cyfredol.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Dinistrio'r arglist `ap` ar ôl ymgychwyn gyda `va_start` neu `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Mae copïau lleoliad presennol `src` arglist i'r `dst` arglist.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Llwythi dadl o'r math `T` o'r `va_list` `ap` a cynyddiad ddadl pwyntiau `ap` i.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}