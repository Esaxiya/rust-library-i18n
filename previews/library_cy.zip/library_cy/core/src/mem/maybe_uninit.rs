use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Mae math deunydd lapio i adeiladu achosion uninitialized o `T`.
///
/// # initialization ddigyfnewid
///
/// Mae'r casglwr, yn gyffredinol, yn tybio bod newidyn yn cael ei ymsefydlu'n iawn yn unol â gofynion math y newidyn.Er enghraifft, rhaid i amrywiol o fath cyfeirio yn cyd-fynd a di-null.
/// Mae hwn yn invariant y mae'n rhaid ei gynnal *bob amser*, hyd yn oed mewn cod anniogel.
/// O ganlyniad, sero-ymgychwyn newidyn o'r math cyfeirio achosi [undefined behavior][ub] y pryd, ni waeth a yw'r cyfeiriad byth yn cael ei ddefnyddio i gof mynediad:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ymddygiad heb ei ddiffinio!⚠️
/// // Y cod cyfatebol gyda `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ymddygiad heb ei ddiffinio!⚠️
/// ```
///
/// Mae'r casglwr yn manteisio ar hyn ar gyfer optimeiddiadau amrywiol, megis dileu gwiriadau amser rhedeg a gwneud y gorau o gynllun `enum`.
///
/// Yn yr un modd, efallai y cof uninitialized yn gyfan gwbl gennych unrhyw gynnwys, er bod yn rhaid i bob amser fod yn `bool` `true` neu `false`.Felly, gan greu `bool` uninitialized yw ymddygiad undefined:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ymddygiad heb ei ddiffinio!⚠️
/// // Mae'r cod cyfatebol gyda `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ymddygiad heb ei ddiffinio!⚠️
/// ```
///
/// Ar ben hynny, cof uninitialized yn arbennig yn yr ystyr nad oes ganddo werth sefydlog ("fixed" "it won't change without being written to" ystyr).Gall darllen yr un beit heb ei ddynodi sawl gwaith roi canlyniadau gwahanol.
/// Mae hyn yn ei gwneud yn undefined ymddygiad i gael data uninitialized mewn newidyn hyd yn oed os nad newidyn yn cael math cyfanrif, a all fel arall yn dal unrhyw batrwm bit *sefydlog*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ymddygiad heb ei ddiffinio!⚠️
/// // Y cod cyfatebol gyda `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ymddygiad heb ei ddiffinio!⚠️
/// ```
/// (Sylwch nad yw'r rheolau ynghylch cyfanrifau anfwriadol yn derfynol eto, ond hyd nes eu bod, fe'ch cynghorir i'w hosgoi.)
///
/// Ar ben hynny, cofiwch fod rhan fwyaf o fathau wedi invariants ychwanegol y tu hwnt yn cael eu hystyried yn unig ymgychwyn ar y lefel math.
/// Er enghraifft, mae [`Vec<T>`] 1`-initialized ei ystyried ymgychwyn (o dan y gweithrediad cyfredol; nid yw hyn yn gyfystyr â gwarant sefydlog) oherwydd yr unig ofyniad y casglwr yn gwybod am y peth yw bod yn rhaid i'r pwyntydd data fod yn ddi-null.
/// Creu fath `Vec<T>` nid yw'n achosi ymddygiad undefined *ar unwaith*, ond bydd yn achosi ymddygiad anniffiniedig gyda'r rhan fwyaf o lawdriniaethau yn ddiogel (gan gynnwys gollwng).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` yn galluogi cod anniogel i ddelio â data heb ei ddynodi.
/// Mae'n signal i'r casglwr sy'n nodi efallai na fydd y data yma * yn cael ei gychwyn:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Creu cyfeirio uninitialized penodol.
/// // Mae'r casglwr yn gwybod y gallai data y tu mewn i `MaybeUninit<T>` fod yn annilys, ac felly nid yw hyn yn UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Gosodwch ef i werth dilys.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Tynnwch y data cychwynnol-dim ond ar ôl *cychwyn `x` yn iawn y caniateir hyn*!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Mae'r compiler wedyn yn gwybod i beidio gwneud unrhyw ragdybiaethau neu optimeiddiad anghywir ar y cod hwn.
///
/// Gallwch chi feddwl am `MaybeUninit<T>` â bod yn ychydig fel `Option<T>` ond heb unrhyw o'r olrhain amser rhedeg a heb unrhyw un o'r gwiriadau diogelwch.
///
/// ## out-pointers
///
/// Gallwch ddefnyddio `MaybeUninit<T>` i weithredu "out-pointers": yn hytrach na dychwelyd data o swyddogaeth, basio pwyntydd i ryw gof (uninitialized) i roi'r canlyniad i mewn.
/// Gall hyn fod yn ddefnyddiol pan fydd yn bwysig i'r galwr reoli sut mae'r cof y mae'r canlyniad yn cael ei storio ynddo yn cael ei ddyrannu, ac rydych chi am osgoi symudiadau diangen.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nid yw'n gollwng yr hen cynnwys, sy'n bwysig.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nawr rydym yn gwybod `v` ei ymgychwyn!Mae hyn hefyd yn sicrhau bod y vector yn cael ei ollwng yn iawn.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Ymgychwyn elfen fesul elfen amrywiaeth
///
/// `MaybeUninit<T>` gellir ei ddefnyddio i ymgychwyn amrywiaeth mawr elfen-wrth-elfen:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Creu amrywiaeth uninitialized o `MaybeUninit`.
///     // Mae'r `assume_init` yn ddiogel oherwydd bod y math yr ydym yn honni ei fod wedi'i gychwyn yma yn griw o `EfallaiUninit`s, nad oes angen eu cychwyn.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Gollwng `MaybeUninit` yn gwneud dim.
///     // Felly nid yw defnyddio aseiniad pwyntydd amrwd yn lle `ptr::write` yn achosi i'r hen werth anfwriadol gael ei ollwng.
/////
///     // Hefyd, os oes panic ystod y ddolen hon, mae gennym gof gollwng, ond nid oes unrhyw fater diogelwch cof.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Mae popeth yn cael ei ymgychwyn.
///     // Transmute yr amrywiaeth i'r math ymgychwyn.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Gallwch hefyd weithio gyda araeau rhannol gychwynnol, y gellid eu canfod mewn datastrwythurau lefel isel.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Creu amrywiaeth uninitialized o `MaybeUninit`.
/// // Mae'r `assume_init` yn ddiogel oherwydd bod y math yr ydym yn honni ei fod wedi'i gychwyn yma yn griw o `EfallaiUninit`s, nad oes angen eu cychwyn.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Cyfrif y nifer o elfennau, rydym wedi neilltuo.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Ar gyfer pob eitem yn yr arae, gollwng os gwnaethom ei ddyrannu.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Ymgychwyn cae-wrth-cae struct
///
/// Gallwch ddefnyddio `MaybeUninit<T>`, a'r macro [`std::ptr::addr_of_mut`], ymgychwyn maes structs drwy gae:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Ymgychwyn y cae `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ymgychwyn y cae `list` Os oes panic yma, yna bydd y `String` yn y `name` yn gollwng cae.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Mae pob un o'r meysydd yn cael eu hymgychwyn, gan felly rydym yn galw `assume_init` i gael Foo ymgychwyn.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` yn sicr o gael yr un maint, aliniad, ac ABI fel `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Fodd bynnag, cofiwch fod yn fath *cynnwys* nad yw `MaybeUninit<T>` o reidrwydd yr un cynllun;Nid Rust wneud mewn gwarantu gyffredinol bod y meysydd a `Foo<T>` yn cael yr un drefn ag a `Foo<U>` hyd yn oed os `T` a `U` gael yr un maint ac aliniad.
///
/// Ar ben hynny oherwydd bod unrhyw werth bit yn ddilys am `MaybeUninit<T>` ni all y casglwr wneud cais optimeiddiad non-zero/niche-filling, a allai arwain at fwy o faint:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Os `T` yn FFI-ddiogel, yna felly yw `MaybeUninit<T>`.
///
/// Er mai `#[repr(transparent)]` yw `MaybeUninit` (sy'n nodi ei fod yn gwarantu'r un maint, aliniad, ac ABI â `T`), nid yw hyn *yn* newid unrhyw un o'r cafeatau blaenorol.
/// `Option<T>` ac efallai y bydd yn dal i gael `Option<MaybeUninit<T>>` wahanol faint, a gall mathau sy'n cynnwys cae o'r math `T` yn cael ei osod allan (a maint) yn wahanol na phe y maes hwnnw yn `MaybeUninit<T>`.
/// `MaybeUninit` yn fath undeb, ac `#[repr(transparent)]` ar undebau yn ansefydlog (gweler [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Dros amser, gall yr union gwarantau o `#[repr(transparent)]` ar undebau esblygu, ac efallai y `MaybeUninit` neu beidio aros `#[repr(transparent)]`.
/// Wedi dweud hynny, bydd `MaybeUninit<T>`*bob amser* yn gwarantu bod ganddo'r un maint, aliniad, ac ABI ag `T`;'i' jyst bod y ffordd offer `MaybeUninit` y gall warant esblygu.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang yr eitem er mwyn i ni lapio mathau eraill ynddo.Mae hyn yn ddefnyddiol ar gyfer generaduron.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ddim yn galw `T::clone()`, ni allwn wybod a ydym yn initialized ddigon ar gyfer hynny.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Creu `MaybeUninit<T>` newydd ymgychwyn â'r gwerth a roddir.
    /// Mae'n ddiogel ffonio [`assume_init`] ar werth dychwelyd y swyddogaeth hon.
    ///
    /// Noder y bydd gollwng `MaybeUninit<T>` byth yn galw `cod gostyngiad T` yn.
    /// Eich cyfrifoldeb chi yw sicrhau `T` yn cael ei ollwng os bydd yn got ymgychwyn.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Yn creu `MaybeUninit<T>` newydd mewn cyflwr anghyfarwydd.
    ///
    /// Noder y bydd gollwng `MaybeUninit<T>` byth yn galw `cod gostyngiad T` yn.
    /// Eich cyfrifoldeb chi yw sicrhau `T` yn cael ei ollwng os bydd yn got ymgychwyn.
    ///
    /// Gweler y [type-level documentation][MaybeUninit] am rai enghreifftiau.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Creu casgliad newydd o eitemau `MaybeUninit<T>`, mewn cyflwr uninitialized.
    ///
    /// Note: mewn fersiwn future Rust Gall y dull hwn fod yn ddiangen pan cystrawen lythrennol amrywiaeth caniatáu [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Yna gallai'r enghraifft isod ddefnyddio `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Yn dychwelyd darn (o bosibl yn llai) o ddata a ddarllenwyd mewn gwirionedd
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // DIOGELWCH: Mae uninitialized `[MaybeUninit<_>; LEN]` yn ddilys.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Creu `MaybeUninit<T>` newydd mewn cyflwr uninitialized, gyda'r cof yn cael ei llenwi â bytes `0`.Mae'n dibynnu ar `T` a yw hynny eisoes yn cychwyn yn iawn.
    ///
    /// Er enghraifft, `MaybeUninit<usize>::zeroed()` yn initialized, ond nid yw `MaybeUninit<&'static i32>::zeroed()` yw oherwydd nad rhaid i gyfeiriadau fod yn null.
    ///
    /// Noder y bydd gollwng `MaybeUninit<T>` byth yn galw `cod gostyngiad T` yn.
    /// Eich cyfrifoldeb chi yw sicrhau `T` yn cael ei ollwng os bydd yn got ymgychwyn.
    ///
    /// # Example
    ///
    /// defnydd cywir o swyddogaeth hon: ymgychwyn yn struct gyda sero, lle y gall pob maes o'r struct dal y bit-patrwm 0 fel gwerth dilys.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// * * Defnydd anghywir o'r swyddogaeth hon: ffonio `x.zeroed().assume_init()` pan nad `0` yn ychydig batrwm-ddilys ar gyfer y math:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Y tu mewn pâr, rydym yn creu `NotZero` nad yw'n cael Gwahanolyn dilys.
    /// // Mae hyn yn ymddygiad anniffiniedig.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // DIOGELWCH: `u.as_mut_ptr()` yn tynnu sylw at gof a ddyrannwyd.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Setiau gwerth y `MaybeUninit<T>`.
    /// Mae hyn yn overwrites unrhyw werth blaenorol heb ei ollwng, felly byddwch yn ofalus i beidio â defnyddio'r hyn ddwywaith oni bai eich bod am hepgor rhedeg y destructor.
    ///
    /// Er hwylustod i chi, mae hyn hefyd yn dychwelyd cyfeiriad mutable at y cynnwys (bellach initialized ddiogel) o'r `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // DIOGELWCH: Rydym newydd gychwyn y gwerth hwn.
        unsafe { self.assume_init_mut() }
    }

    /// Cael pwyntydd i'r gwerth a gynhwysir.
    /// Darllen o'r pwyntydd hwn neu droi i mewn i gyfeiriad ymddygiad anniffiniedig oni bai bod y `MaybeUninit<T>` ei ymgychwyn.
    /// Ysgrifennu i gof bod pwyntydd hon (non-transitively) bwyntiau i yw ymddygiad anniffiniedig (ac eithrio y tu fewn i `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// defnydd cywir y dull hwn:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Creu cyfeirnod i'r `MaybeUninit<T>`.Mae hyn yn iawn oherwydd ein bod ymgychwyn ef.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// * * Defnydd anghywir y dull hwn:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Rydym wedi creu cyfeiriad at vector uninitialized!Mae hyn yn ymddygiad anniffiniedig.⚠️
    /// ```
    ///
    /// (Hysbysiad nad oedd y rheolau o gwmpas cyfeiriadau at ddata uninitialized yn cael eu cwblhau eto, ond nes eu bod yn, fe'ch cynghorir i'w hosgoi.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` a `ManuallyDrop` ill dau yn `repr(transparent)` fel y gallwn fwrw pwyntydd.
        self as *const _ as *const T
    }

    /// Gets pwyntydd mutable i werth a geir.
    /// Darllen o'r pwyntydd hwn neu droi i mewn i gyfeiriad ymddygiad anniffiniedig oni bai bod y `MaybeUninit<T>` ei ymgychwyn.
    ///
    /// # Examples
    ///
    /// defnydd cywir y dull hwn:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Creu cyfeirio i mewn i'r `MaybeUninit<Vec<u32>>`.
    /// // Mae hyn yn iawn oherwydd ein bod ymgychwyn ef.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// * * Defnydd anghywir y dull hwn:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Rydym wedi creu cyfeiriad at vector uninitialized!Mae hyn yn ymddygiad anniffiniedig.⚠️
    /// ```
    ///
    /// (Hysbysiad nad oedd y rheolau o gwmpas cyfeiriadau at ddata uninitialized yn cael eu cwblhau eto, ond nes eu bod yn, fe'ch cynghorir i'w hosgoi.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` a `ManuallyDrop` ill dau yn `repr(transparent)` fel y gallwn fwrw pwyntydd.
        self as *mut _ as *mut T
    }

    /// Detholiad gwerth o'r cynhwysydd `MaybeUninit<T>`.Mae hon yn ffordd wych i sicrhau y bydd y data yn cael eu gollwng, oherwydd bod y `T` deillio o hyn yn ddarostyngedig i drin gostyngiad arferol.
    ///
    /// # Safety
    ///
    /// Mater i'r galwr yw gwarantu bod yr `MaybeUninit<T>` mewn cyflwr cychwynnol.Mae galw hyn pan nad yw'r cynnwys wedi'i gychwyn yn llawn eto yn achosi ymddygiad heb ei ddiffinio ar unwaith.
    /// Mae'r [type-level documentation][inv] yn cynnwys mwy o wybodaeth am yr invariant cychwynnol hwn.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ar ben hynny, cofiwch fod rhan fwyaf o fathau wedi invariants ychwanegol y tu hwnt yn cael eu hystyried yn unig ymgychwyn ar y lefel math.
    /// Er enghraifft, mae [`Vec<T>`] 1`-initialized ei ystyried ymgychwyn (o dan y gweithrediad cyfredol; nid yw hyn yn gyfystyr â gwarant sefydlog) oherwydd yr unig ofyniad y casglwr yn gwybod am y peth yw bod yn rhaid i'r pwyntydd data fod yn ddi-null.
    ///
    /// Creu fath `Vec<T>` nid yw'n achosi ymddygiad undefined *ar unwaith*, ond bydd yn achosi ymddygiad anniffiniedig gyda'r rhan fwyaf o lawdriniaethau yn ddiogel (gan gynnwys gollwng).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// defnydd cywir y dull hwn:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// * * Defnydd anghywir y dull hwn:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` nid oedd wedi cael ei gychwyn eto, felly achosodd y llinell olaf hon ymddygiad heb ei ddiffinio.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // DIOGELWCH: y warant rhaid galwr bod `self` ei ymgychwyn.
        // Mae hyn hefyd yn golygu bod yn rhaid i `self` fod yn amrywiad `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Yn darllen y gwerth o'r cynhwysydd `MaybeUninit<T>`.Mae'r `T` deillio o hyn yn ddarostyngedig i drin gostyngiad arferol.
    ///
    /// Pryd bynnag y bo modd, mae'n well defnyddio [`assume_init`] yn lle hynny, a oedd yn atal dyblygu cynnwys y `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Mae i fyny i'r galwr i gwarantu bod y `MaybeUninit<T>` gwirionedd mewn cyflwr ymgychwyn.Galw hyn pan na fydd y cynnwys yn cael ei initialized llawn eto achosion ymddygiad anniffiniedig.
    /// Mae'r [type-level documentation][inv] yn cynnwys mwy o wybodaeth am yr invariant cychwynnol hwn.
    ///
    /// At hynny, mae hyn yn gadael copi o'r un y tu ôl data yn y `MaybeUninit<T>`.
    /// Wrth ddefnyddio sawl copi o'r data (drwy ffonio sawl gwaith `assume_init_read`, neu yn gyntaf ffonio `assume_init_read` ac yna [`assume_init`]), eich cyfrifoldeb chi yw sicrhau y gall y data gael ei dyblygu yn wir.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// defnydd cywir y dull hwn:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` yw `Copy`, felly efallai y byddwn yn darllen sawl gwaith.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Mae dyblygu gwerth `None` yn iawn, felly efallai y byddwn yn darllen sawl gwaith.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// * * Defnydd anghywir y dull hwn:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Rydym bellach wedi creu dau gopi o'r un vector, gan arwain at ⚠️ di-ddwbl pan fydd y ddau ohonyn nhw'n cael eu gollwng!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // DIOGELWCH: y warant rhaid galwr bod `self` ei ymgychwyn.
        // Mae darllen o `self.as_ptr()` yn ddiogel gan y dylid cychwyn `self`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Yn gollwng y gwerth a gynhwysir yn ei le.
    ///
    /// Os oes gennych perchnogaeth o'r `MaybeUninit`, gallwch ddefnyddio [`assume_init`] yn lle hynny.
    ///
    /// # Safety
    ///
    /// Mae i fyny i'r galwr i gwarantu bod y `MaybeUninit<T>` gwirionedd mewn cyflwr ymgychwyn.Galw hyn pan na fydd y cynnwys yn cael ei initialized llawn eto achosion ymddygiad anniffiniedig.
    ///
    /// Ar ben hynny, rhaid i bob invariants ychwanegol o'r math `T` fod yn fodlon, yn ôl y gweithredu `Drop` o `T` (neu ei aelodau) yn dibynnu ar hyn.
    /// Er enghraifft, mae [`Vec<T>`] 1`-initialized ei ystyried ymgychwyn (o dan y gweithrediad cyfredol; nid yw hyn yn gyfystyr â gwarant sefydlog) oherwydd yr unig ofyniad y casglwr yn gwybod am y peth yw bod yn rhaid i'r pwyntydd data fod yn ddi-null.
    ///
    /// Fodd bynnag, bydd gollwng `Vec<T>` o'r fath yn achosi ymddygiad heb ei ddiffinio.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // DIOGELWCH: y warant rhaid galwr bod `self` yn cael ei initialized a
        // yn bodloni'r holl invariants o `T`.
        // Gollwng y gwerth yn eu lle yn ddiogel os yw hynny'n wir.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Gets cyfeiriad rennir at werth a geir.
    ///
    /// Gall hyn fod yn ddefnyddiol pan rydym am i gael mynediad at `MaybeUninit` sydd wedi'i ymgychwyn ond nid oes ganddynt berchnogaeth o'r `MaybeUninit` (atal defnyddio `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Galw hyn pan na fydd y cynnwys yn cael ei initialized yn llawn eto achosi ymddygiad undefined: mater i'r galwr at gwarantu bod y `MaybeUninit<T>` gwirionedd mewn cyflwr ymgychwyn.
    ///
    ///
    /// # Examples
    ///
    /// ### defnydd cywir y dull hwn:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Cychwyn `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nawr bod ein `MaybeUninit<_>` yn hysbys i gael ei hymgychwyn, gan ei fod yn iawn i greu cyfeiriad a rennir ato:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // DIOGELWCH: `x` wedi'i ymgychwyn.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Anghywir* usages y dull hwn:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Rydym wedi creu cyfeiriad at vector uninitialized!Mae hyn yn ymddygiad anniffiniedig.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Dechreuwch yr `MaybeUninit` gan ddefnyddio `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Cyfeiriad at `Cell<bool>` heb ei ddynodi: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // DIOGELWCH: y warant rhaid galwr bod `self` ei ymgychwyn.
        // Mae hyn hefyd yn golygu bod yn rhaid i `self` fod yn amrywiad `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Yn cael cyfeiriad (unique) treiddgar at y gwerth a gynhwysir.
    ///
    /// Gall hyn fod yn ddefnyddiol pan rydym am i gael mynediad at `MaybeUninit` sydd wedi'i ymgychwyn ond nid oes ganddynt berchnogaeth o'r `MaybeUninit` (atal defnyddio `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Galw hyn pan na fydd y cynnwys yn cael ei initialized yn llawn eto achosi ymddygiad undefined: mater i'r galwr at gwarantu bod y `MaybeUninit<T>` gwirionedd mewn cyflwr ymgychwyn.
    /// Er enghraifft, ni ellir `.assume_init_mut()` yn cael ei ddefnyddio i ymgychwyn `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### defnydd cywir y dull hwn:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *pob* y bytes y byffer mewnbwn.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Ymgychwyn `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nawr rydym yn gwybod bod `buf` wedi'i ymgychwyn, er mwyn i ni `.assume_init()` ei.
    /// // Fodd bynnag, gall defnyddio `.assume_init()` sbarduno `memcpy` o'r beitiau 2048.
    /// // I fynnu ein byffer wedi'i ymgychwyn heb gopïo, rydym uwchraddio'r `&mut MaybeUninit<[u8; 2048]>` i `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // DIOGELWCH: Mae `buf` wedi'i gychwyn.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nawr gallwn ddefnyddio `buf` fel sleisen arferol:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Anghywir* usages y dull hwn:
    ///
    /// Ni allwch ddefnyddio'r `.assume_init_mut()` i ymgychwyn gwerth:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Rydym wedi creu cyfeiriad (mutable) at `bool` uninitialized!
    ///     // Mae hyn yn ymddygiad anniffiniedig.⚠️
    /// }
    /// ```
    ///
    /// Er enghraifft, nad ydych yn gallu [`Read`] i mewn i byffer uninitialized:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) cyfeiriad at gof uninitialized!
    ///                             // Mae hwn yn ymddygiad heb ei ddiffinio.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ni allwch ychwaith ddefnyddio mynediad cae uniongyrchol i wneud maes-wrth-cae initialization graddol:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) cyfeiriad at gof uninitialized!
    ///                  // Mae hwn yn ymddygiad heb ei ddiffinio.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) cyfeiriad at gof uninitialized!
    ///                  // Mae hwn yn ymddygiad heb ei ddiffinio.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Rydym yn dibynnu ar hyn o bryd uchod yn anghywir, hy, mae gennym gyfeiriadau at ddata uninitialized (ee, yn `libcore/fmt/float.rs`).
    // Dylem wneud penderfyniad terfynol ynghylch y rheolau cyn sefydlogi.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // DIOGELWCH: y warant rhaid galwr bod `self` ei ymgychwyn.
        // Mae hyn hefyd yn golygu bod yn rhaid i `self` fod yn amrywiad `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Detholiad gwerthoedd o amrywiaeth o gynwysyddion `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Mae i fyny i'r galwr i sicrwydd bod pob elfen o'r casgliad bod mewn cyflwr ymgychwyn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // DIOGELWCH: Nawr yn ddiogel wrth i ni initialised holl elfennau
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Mae'r gwarantu galwr bod pob elfen y rhesi yn cael eu initialized
        // * `MaybeUninit<T>` a T yn sicr o fod â'r un cynllun
        // * Nid yw EfallaiUnint yn gollwng, felly nid oes dwy-ryddhad Ac felly mae'r trawsnewidiad yn ddiogel
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Gan dybio holl elfennau yn cael eu hymgychwyn, gan gael sleisen iddynt.
    ///
    /// # Safety
    ///
    /// Mater i'r galwr yw gwarantu bod yr elfennau `MaybeUninit<T>` mewn cyflwr cychwynnol mewn gwirionedd.
    ///
    /// Galw hyn pan na fydd y cynnwys yn cael ei initialized llawn eto achosion ymddygiad anniffiniedig.
    ///
    /// Gweler [`assume_init_ref`] am fwy o fanylion ac enghreifftiau.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // DIOGELWCH: castio sleis i `*const [T]` yn ddiogel gan fod y gwarantau galwr bod
        // `slice` yn cael ei ymsefydlu, a gwarantir y bydd gan`MaybeUninit` yr un cynllun â `T`.
        // Mae'r pwyntydd gafwyd yn ddilys gan ei fod yn cyfeirio at gof eiddo i `slice` sydd yn gyfeiriad ac felly sicr o fod yn ddilys ar gyfer darllen.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Gan dybio holl elfennau yn cael eu hymgychwyn, gan gael darn mutable iddynt.
    ///
    /// # Safety
    ///
    /// Mater i'r galwr yw gwarantu bod yr elfennau `MaybeUninit<T>` mewn cyflwr cychwynnol mewn gwirionedd.
    ///
    /// Galw hyn pan na fydd y cynnwys yn cael ei initialized llawn eto achosion ymddygiad anniffiniedig.
    ///
    /// Gweler [`assume_init_mut`] am fwy o fanylion ac enghreifftiau.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // DIOGELWCH: yn debyg i nodiadau diogelwch ar gyfer `slice_get_ref`, ond mae gennym ni a
        // cyfeirio mutable sydd hefyd yn sicr o fod yn ddilys ar gyfer ysgrifennu yn.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Gets pwyntydd i'r elfen gyntaf y rhesi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Gets pwyntydd mutable i'r elfen gyntaf y rhesi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Mae copïau elfennau o `src` i `this`, gan ddychwelyd cyfeiriad mutable i gynnwys initalized bellach o `this`.
    ///
    /// Os nad `T` yn gweithredu `Copy`, defnyddiwch [`write_slice_cloned`]
    ///
    /// Mae hyn yn debyg i [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon panic os yw'r ddau dafell wedi wahanol hyd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // DIOGELWCH: rydym newydd gopïo holl elfennau len i'r capasiti sbâr
    /// // mae elfennau src.len() cyntaf y vec yn ddilys nawr.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // DIOGELWCH: &[T] ac a [MaybeUninit<T>] Yn cael yr un cynllun
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // DIOGELWCH: Elfennau dilys wedi cael eu copïo i mewn i `this` felly mae'n cael ei initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Cloniwch yr elfennau o `src` i `this`, gan ddychwelyd cyfeiriad cyfnewidiol at gynnwys `this` sydd bellach wedi'i fewnfudo.
    /// Ni fydd unrhyw elfennau initalized eisoes yn cael eu gollwng.
    ///
    /// Os yw `T` yn gweithredu `Copy`, defnyddiwch [`write_slice`]
    ///
    /// Mae hyn yn debyg i [`slice::clone_from_slice`] ond nid yw'n gollwng elfennau sy'n bodoli eisoes.
    ///
    /// # Panics
    ///
    /// Bydd y swyddogaeth hon panic os yw'r ddau dafell wedi wahanol hyd, neu os y gwaith o `Clone` panics ar waith.
    ///
    /// Os oes panic, bydd yr elfennau sydd eisoes wedi'u clonio yn cael eu gollwng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // DIOGELWCH Yr ydym newydd clonio holl elfennau Len mewn i'r capasiti dros ben
    /// // mae elfennau src.len() cyntaf y vec yn ddilys nawr.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // yn wahanol i copy_from_slice nid yw hyn yn galw clone_from_slice ar y dafell mae hyn oherwydd nad yw `MaybeUninit<T: Clone>` yn gweithredu Clôn.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // DIOGELWCH: bydd hyn yn tafell amrwd yn cynnwys gwrthrychau yn unig initialized
                // dyna pam, caniateir ei ollwng.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Mae angen i ni eu sleisio'n benodol i'r un hyd
        // er mwyn atal gwirio ffiniau, a bydd yr optimizer yn cynhyrchu cofiadwy ar gyfer achosion syml (er enghraifft T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Mae angen gwarchod y gallai b/c panic ddigwydd yn ystod clôn
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // DIOGELWCH: Elfennau dilys wedi cael eu hysgrifennu i mewn i `this` felly mae'n cael ei initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}