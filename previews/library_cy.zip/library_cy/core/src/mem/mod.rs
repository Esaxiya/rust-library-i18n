//! Swyddogaethau sylfaenol ar gyfer delio â'r cof.
//!
//! Mae'r modiwl hwn yn cynnwys swyddogaethau ar gyfer cwestiynu maint ac aliniad mathau, gan gychwyn a thrin cof.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Yn cymryd perchnogaeth a "forgets" am y gwerth **heb redeg ei ddinistriwr**.
///
/// Unrhyw adnoddau gwerth yn rheoli, megis cof domen neu ffeil handlen, bydd lechu am byth mewn cyflwr anghyraeddadwy.Fodd bynnag, nid yw'n gwarantu y bydd awgrymiadau i gof hwn yn parhau i fod yn ddilys.
///
/// * Os ydych chi eisiau gollwng cof, gweler [`Box::leak`].
/// * Os ydych am gael pwyntydd crai i'r cof, gweler [`Box::into_raw`].
/// * Os ydych am gael gwared ar werth yn iawn, yn rhedeg ei destructor, gweler [`mem::drop`].
///
/// # Safety
///
/// `forget` nid yw wedi'i nodi fel `unsafe`, oherwydd nid yw gwarantau diogelwch Rust yn cynnwys gwarant y bydd dinistrwyr bob amser yn rhedeg.
/// Er enghraifft, gall rhaglen greu cylch cyfeirio gan ddefnyddio [`Rc`][rc], neu ffonio [`process::exit`][exit] i adael heb redeg dinistrwyr.
/// Felly, nid yw caniatáu `mem::forget` o god diogel yn newid gwarantau diogelwch Rust yn sylfaenol.
///
/// Wedi dweud hynny, adnoddau fel gof neu wrthrychau I/O fel arfer annymunol gollwng.
/// Mae'r angen yn dod i fyny mewn rhai achosion ddefnydd arbenigol ar gyfer FFI neu cod anniogel, ond hyd yn oed wedyn, [`ManuallyDrop`] cael ei ffafrio fel arfer.
///
/// Oherwydd bod anghofio gwerth yn cael ei ganiatáu, rhaid i unrhyw god `unsafe` rydych chi'n ei ysgrifennu ganiatáu ar gyfer y posibilrwydd hwn.Ni allwch ddychwelyd gwerth ac yn disgwyl y bydd y galwr reidrwydd yn rhedeg destructor gwerth ei.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Y defnydd diogel canonaidd o `mem::forget` yw osgoi'r dinistriwr gwerth a weithredir gan yr `Drop` trait.Er enghraifft, bydd hyn yn gollwng yn `File`, hy
/// adennill y gofod a gymerwyd gan y newidyn ond peidiwch byth â chau adnodd sylfaenol y system:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Mae hyn yn ddefnyddiol pan perchnogaeth yr adnodd sylfaenol ei drosglwyddo flaenorol i cod y tu allan i Rust, er enghraifft drwy drosglwyddo'r disgrifydd ffeil crai i C cod.
///
/// # Perthynas gyda `ManuallyDrop`
///
/// Er y gall `mem::forget` hefyd gael ei ddefnyddio i drosglwyddo cof * * perchnogaeth, gwneud hynny yn wall-dueddol.
/// [`ManuallyDrop`] dylid ei ddefnyddio yn lle.Ystyriwch, er enghraifft, y cod hwn:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Adeiladu `String` ddefnyddio cynnwys `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // gollwng `v` am fod ei gof yn awr yn cael ei reoli gan `s`
/// mem::forget(v);  // GWALL, v yn annilys ac ni ddylid ei drosglwyddo i swyddogaeth
/// assert_eq!(s, "Az");
/// // `s` yn cael ei ollwng yn ymhlyg ac mae ei gof wedi'i ddeall.
/// ```
///
/// Mae dau fater gyda'r enghraifft uchod:
///
/// * Pe bai mwy o god yn cael ei ychwanegu rhwng adeiladu `String` a galw `mem::forget()`, byddai panic ynddo yn achosi dwbl am ddim oherwydd bod yr un cof yn cael ei drin gan `v` a `s`.
/// * Ar ôl galw `v.as_mut_ptr()` a throsglwyddo perchnogaeth y data i `s`, mae'r gwerth `v` yn annilys.
/// Hyd yn oed pan fydd gwerth newydd ei symud i `mem::forget` (na fydd yn ei archwilio), mae gan rai mathau ofynion llym ar eu gwerthoedd sy'n eu gwneud yn annilys wrth hongian neu ddim yn eiddo mwyach.
/// Mae defnyddio gwerthoedd annilys mewn unrhyw ffordd, gan gynnwys eu trosglwyddo i swyddogaethau neu eu dychwelyd o swyddogaethau, yn ymddygiad heb ei ddiffinio a gall dorri'r rhagdybiaethau a wneir gan y casglwr.
///
/// Mae newid i `ManuallyDrop` yn osgoi'r ddau fater:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Cyn i ni ddadosod `v` yn ei rannau amrwd, gwnewch yn siŵr nad yw'n cael ei ollwng!
/////
/// let mut v = ManuallyDrop::new(v);
/// // `v` Now dadosod.Mae'r gweithrediadau hyn ni all panic, felly nid all beidio â bod yn gollwng.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Yn olaf, adeiladu `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` yn cael ei ollwng yn ymhlyg ac mae ei gof wedi'i ddeall.
/// ```
///
/// `ManuallyDrop` yn atal di-ddwbl yn gadarn oherwydd ein bod yn analluogi dinistriwr `v` cyn gwneud unrhyw beth arall.
/// `mem::forget()` nid yw'n caniatáu hyn oherwydd ei fod yn arddel ei ddadl, gan ein gorfodi i'w alw dim ond ar ôl tynnu unrhyw beth sydd ei angen arnom o `v`.
/// Hyd yn oed pe bai panic yn cael ei gyflwyno rhwng adeiladu `ManuallyDrop` ac adeiladu'r llinyn (na all ddigwydd yn y cod fel y dangosir), byddai'n arwain at ollyngiad ac nid rhydd dwbl.
/// Mewn geiriau eraill, mae `ManuallyDrop` yn cyfeiliorni ar ochr gollwng yn lle cyfeiliorni ar ochr gollwng (dwbl-).
///
/// Hefyd, mae `ManuallyDrop` yn ein hatal rhag gorfod "touch" `v` ar ôl trosglwyddo'r berchnogaeth i `s`-mae'r cam olaf o ryngweithio â `v` i'w waredu heb redeg ei ddinistriwr yn cael ei osgoi'n llwyr.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Fel [`forget`], ond hefyd yn derbyn gwerthoedd heb eu mesur.
///
/// Mae'r swyddogaeth hon yn ddim ond shim y bwriedir ei dileu pan fydd y nodwedd `unsized_locals` yn cael ei sefydlogi.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Yn dychwelyd maint math mewn beit.
///
/// Yn fwy penodol, dyma'r gwrthbwyso mewn beitiau rhwng elfennau olynol mewn arae gyda'r math hwnnw o eitem gan gynnwys padin alinio.
///
/// Felly, ar gyfer unrhyw fath `T` a hyd `n`, mae gan `[T; n]` faint o `n * size_of::<T>()`.
///
/// Yn gyffredinol, nid yw maint math yn sefydlog ar draws crynhoadau, ond mae mathau penodol fel pethau cyntefig.
///
/// Mae'r tabl canlynol yn rhoi'r maint ar gyfer pethau cyntefig.
///
/// Math |maint_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 torgoch |4
///
/// At hynny, mae gan `usize` a `isize` yr un maint.
///
/// Mae gan y mathau `*const T`, `&T`, `Box<T>`, `Option<&T>`, a `Option<Box<T>>` i gyd yr un maint.
/// Os yw `T` wedi'i Sized, mae gan bob un o'r mathau hynny yr un maint â `usize`.
///
/// Nid yw treiddioldeb pwyntydd yn newid ei faint.O'r herwydd, mae gan `&T` a `&mut T` yr un maint.
/// Yn yr un modd ar gyfer `*const T` a `* mut T`.
///
/// # Maint yr eitemau `#[repr(C)]`
///
/// Mae gan y gynrychiolaeth `C` ar gyfer eitemau gynllun diffiniedig.
/// Gyda'r cynllun hwn, mae maint yr eitemau hefyd yn sefydlog cyn belled â bod gan bob cae faint sefydlog.
///
/// ## Maint y Strwythurau
///
/// Ar gyfer `structs`, mae'r maint yn cael ei bennu gan yr algorithm canlynol.
///
/// Ar gyfer pob maes yn y strwythur a archebir trwy orchymyn datgan:
///
/// 1. Ychwanegwch faint y cae.
/// 2. Talgrynnwch y maint cyfredol i'r lluosrif agosaf o [alignment] y cae nesaf.
///
/// Yn olaf, talgrynnwch faint y strwythur i'r lluosrif agosaf o'i [alignment].
/// Aliniad y strwythur fel arfer yw'r aliniad mwyaf o'i holl gaeau;gellir newid hyn trwy ddefnyddio `repr(align(N))`.
///
/// Yn wahanol i `C`, nid yw strwythurau maint sero yn cael eu talgrynnu i un beit o faint.
///
/// ## Maint Enums
///
/// Mae gan enums nad ydynt yn cario unrhyw ddata heblaw'r gwahaniaethydd yr un maint ag enymau C ar y platfform y maent yn cael eu llunio ar eu cyfer.
///
/// ## Maint Undebau
///
/// Maint undeb yw maint ei gae mwyaf.
///
/// Yn wahanol i `C`, nid yw undebau maint sero yn cael eu talgrynnu i un beit o faint.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Mae rhai primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Mae rhai araeau
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Cydraddoldeb maint pwyntydd
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Gan ddefnyddio `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Mae maint y cae cyntaf yw 1, felly ychwanegwch 1 i faint.Maint yw 1.
/// // Mae aliniad y maes hwn yn ail 2, felly ychwanegwch 1 i faint ar gyfer padin.Maint yw 2.
/// // Maint yr ail gae yw 2, felly ychwanegwch 2 at y maint.Maint yw 4.
/// // Mae aliniad y trydydd maes hwn yn 1, felly ychwanegwch 0 i faint ar gyfer padin.Maint yw 4.
/// // Maint y trydydd cae yw 1, felly ychwanegwch 1 at y maint.Maint yw 5.
/// // Yn olaf, mae'r aliniad y struct yw 2 (am fod y aliniad mwyaf ymhlith ei gaeau yw 2), felly ychwanegwch 1 i faint ar gyfer padin.
/// // Maint yw 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // structs tuple yn dilyn yr un rheolau.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Noder y gall ad-drefnu'r y caeau ostwng y maint.
/// // Gallwn gael gwared ar y ddau bytes padin drwy roi `third` cyn `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Maint yr Undeb yw maint y cae mwyaf.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Yn dychwelyd maint y gwerth pwyntiedig i beit.
///
/// Mae hyn fel arfer yr un peth â `size_of::<T>()`.
/// Fodd bynnag, pan nad oes gan `T`* * unrhyw faint sy'n hysbys yn statig, ee sleisen [`[T]`][slice] neu [trait object], yna gellir defnyddio `size_of_val` i gael y maint sy'n hysbys yn ddeinamig.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // DIOGELWCH: Cyfeirnod yw `val`, felly mae'n bwyntydd amrwd dilys
    unsafe { intrinsics::size_of_val(val) }
}

/// Yn dychwelyd maint y gwerth pwyntiedig i beit.
///
/// Mae hyn fel arfer yr un peth â `size_of::<T>()`.Fodd bynnag, pan nad oes gan `T`* * unrhyw faint sy'n hysbys yn statig, ee sleisen [`[T]`][slice] neu [trait object], yna gellir defnyddio `size_of_val_raw` i gael y maint sy'n hysbys yn ddeinamig.
///
/// # Safety
///
/// Mae'r swyddogaeth hon yn unig yn ddiogel i'r alwad os yw'r amodau canlynol yn cynnal:
///
/// - Os yw `T` yn `Sized`, mae'r swyddogaeth hon bob amser yn ddiogel i'w galw.
/// - Os bydd y gynffon unsized o `T` yw:
///     - [slice], yna rhaid i hyd y gynffon dafell fod yn gyfanrif cychwynnol, a rhaid i faint y *gwerth cyfan*(hyd cynffon deinamig + rhagddodiad maint statig) ffitio yn `isize`.
///     - [trait object], yna mae'n rhaid i ran y gellir ei newid o'r pwyntydd bwyntio at hyfyw dilys a gafwyd trwy orfodaeth annifyr, a rhaid i faint y *gwerth cyfan*(hyd cynffon deinamig + rhagddodiad maint statig) ffitio yn `isize`.
///
///     - yn (unstable) [extern type], yna swyddogaeth hon bob amser yn ddiogel i alw, ond gall panic neu fel arall yn dychwelyd y gwerth anghywir, gan nad cynllun y math extern yn hysbys.
///     Dyma'r un ymddygiad â [`size_of_val`] ar gyfeiriad at fath gyda chynffon math allanol.
///     - fel arall, nid yw geidwadol chaniateir i alw swyddogaeth hon.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // DIOGELWCH: rhaid i'r galwr ddarparu pwyntydd amrwd dilys
    unsafe { intrinsics::size_of_val(val) }
}

/// Yn dychwelyd yr aliniad gofynnol o fath [ABI].
///
/// Rhaid i bob cyfeiriad at werth o'r math `T` fod yn lluosrif o'r rhif hwn.
///
/// Dyma'r aliniad a ddefnyddir ar gyfer caeau strwythuredig.Gall fod yn llai na'r aliniad a ffefrir.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Yn dychwelyd yr aliniad gofynnol [ABI] o'r math o werth y mae `val` yn pwyntio ato.
///
/// Rhaid i bob cyfeiriad at werth o'r math `T` fod yn lluosrif o'r rhif hwn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // DIOGELWCH: cyfeirnod yw val, felly mae'n bwyntydd amrwd dilys
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Yn dychwelyd yr aliniad gofynnol o fath [ABI].
///
/// Rhaid i bob cyfeiriad at werth o'r math `T` fod yn lluosrif o'r rhif hwn.
///
/// Dyma'r aliniad a ddefnyddir ar gyfer caeau strwythuredig.Gall fod yn llai na'r aliniad a ffefrir.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Yn dychwelyd yr aliniad gofynnol [ABI] o'r math o werth y mae `val` yn pwyntio ato.
///
/// Rhaid i bob cyfeiriad at werth o'r math `T` fod yn lluosrif o'r rhif hwn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // DIOGELWCH: cyfeirnod yw val, felly mae'n bwyntydd amrwd dilys
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Yn dychwelyd yr aliniad gofynnol [ABI] o'r math o werth y mae `val` yn pwyntio ato.
///
/// Rhaid i bob cyfeiriad at werth o'r math `T` fod yn lluosrif o'r rhif hwn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Mae'r swyddogaeth hon yn unig yn ddiogel i'r alwad os yw'r amodau canlynol yn cynnal:
///
/// - Os yw `T` yn `Sized`, mae'r swyddogaeth hon bob amser yn ddiogel i'w galw.
/// - Os bydd y gynffon unsized o `T` yw:
///     - [slice], yna rhaid i hyd y gynffon dafell fod yn gyfanrif cychwynnol, a rhaid i faint y *gwerth cyfan*(hyd cynffon deinamig + rhagddodiad maint statig) ffitio yn `isize`.
///     - [trait object], yna mae'n rhaid i ran y gellir ei newid o'r pwyntydd bwyntio at hyfyw dilys a gafwyd trwy orfodaeth annifyr, a rhaid i faint y *gwerth cyfan*(hyd cynffon deinamig + rhagddodiad maint statig) ffitio yn `isize`.
///
///     - yn (unstable) [extern type], yna swyddogaeth hon bob amser yn ddiogel i alw, ond gall panic neu fel arall yn dychwelyd y gwerth anghywir, gan nad cynllun y math extern yn hysbys.
///     Dyma'r un ymddygiad â [`align_of_val`] ar gyfeiriad at fath gyda chynffon math allanol.
///     - fel arall, nid yw geidwadol chaniateir i alw swyddogaeth hon.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // DIOGELWCH: rhaid i'r galwr ddarparu pwyntydd amrwd dilys
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Yn dychwelyd `true` os yw gollwng gwerthoedd math `T` yn bwysig.
///
/// Awgrym optimeiddio yn unig yw hwn, a gellir ei weithredu'n geidwadol:
/// gall ddychwelyd `true` ar gyfer mathau nad oes angen eu gollwng mewn gwirionedd.
/// O'r herwydd, byddai dychwelyd `true` bob amser yn weithred ddilys o'r swyddogaeth hon.Fodd bynnag, os yw'r swyddogaeth hon yn dychwelyd `false` mewn gwirionedd, yna gallwch fod yn sicr nad yw gollwng `T` yn cael unrhyw sgîl-effaith.
///
/// Dylai gweithrediadau lefel isel o bethau fel casgliadau, y mae angen iddynt ollwng eu data â llaw, ddefnyddio'r swyddogaeth hon i osgoi ceisio gollwng eu holl gynnwys yn ddiangen pan gânt eu dinistrio.
///
/// Efallai na fydd hyn yn gwneud gwahaniaeth mewn adeiladau rhyddhau (lle mae dolen nad oes unrhyw sgîl-effeithiau yn hawdd ei chanfod a'i dileu), ond yn aml mae'n fuddugoliaeth fawr i adeiladu dadfygio.
///
/// Sylwch fod [`drop_in_place`] eisoes yn cyflawni'r gwiriad hwn, felly os gellir lleihau eich llwyth gwaith i ryw nifer fach o alwadau [`drop_in_place`], nid oes angen defnyddio hwn.
/// Sylwch yn benodol y gallwch chi [`drop_in_place`] sleisen, a bydd hynny'n gwneud un gwiriad anghenion_drop am yr holl werthoedd.
///
/// Felly mathau fel Vec dim ond `drop_in_place(&mut self[..])` heb ddefnyddio `needs_drop` yn benodol.
/// Ar y llaw arall, mae'n rhaid i fathau fel [`HashMap`] ollwng gwerthoedd un ar y tro a dylent ddefnyddio'r API hwn.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Dyma enghraifft o sut y gallai casgliad ddefnyddio `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // gollwng y data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Yn dychwelyd gwerth math `T` a gynrychiolir gan y patrwm beit sero-sero.
///
/// Mae hyn yn golygu, er enghraifft, nad yw'r beit padio yn `(u8, u16)` o reidrwydd yn sero.
///
/// Nid oes unrhyw sicrwydd bod patrwm beit pob sero yn cynrychioli gwerth dilys o ryw fath `T`.
/// Er enghraifft, nid yw'r patrwm beit holl-sero yn werth dilys ar gyfer mathau cyfeirio (`&T`, `&mut T`) ac awgrymiadau swyddogaethau.
/// Mae defnyddio `zeroed` ar fathau o'r fath yn achosi [undefined behavior][ub] ar unwaith oherwydd [the Rust compiler assumes][inv] bod gwerth dilys bob amser mewn newidyn y mae'n ei ystyried yn gychwynnol.
///
///
/// Mae hyn yn cael yr un effaith â [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Mae'n ddefnyddiol i FFI weithiau, ond dylid ei osgoi yn gyffredinol.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Defnydd cywir o'r swyddogaeth hon: cychwyn cyfanrif â sero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Defnydd *anghywir* o'r swyddogaeth hon: cychwyn cyfeiriad gyda sero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Ymddygiad undefined!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ac eto!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // DIOGELWCH: rhaid i'r galwr warantu bod gwerth pob sero yn ddilys ar gyfer `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Yn osgoi gwiriadau cychwyn cof arferol Rust trwy esgus cynhyrchu gwerth math `T`, heb wneud dim o gwbl.
///
/// **Nid yw'r swyddogaeth hon yn cael ei dirprwyo.** Defnyddiwch [`MaybeUninit<T>`] yn lle.
///
/// Y rheswm dros ddibrisiant yw na ellir defnyddio'r swyddogaeth yn gywir yn y bôn: mae'n cael yr un effaith â [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Fel mae'r [`assume_init` documentation][assume_init] yn esbonio, [the Rust compiler assumes][inv] bod gwerthoedd yn cael eu cychwyn yn iawn.
/// O ganlyniad, galw ee
/// `mem::uninitialized::<bool>()` yn achosi ymddygiad heb ei ddiffinio ar unwaith am ddychwelyd `bool` nad yw'n bendant naill ai `true` neu `false`.
/// Mae cof gwaeth, gwirioneddol anuniongyrchol fel yr hyn sy'n cael ei ddychwelyd yma yn arbennig gan fod y casglwr yn gwybod nad oes ganddo werth sefydlog.
/// Mae hyn yn ei gwneud yn ymddygiad heb ei ddiffinio i gael data heb ei ddynodi mewn newidyn hyd yn oed os oes gan y newidyn hwnnw fath cyfanrif.
/// (Sylwch nad yw'r rheolau ynghylch cyfanrifau anfwriadol yn derfynol eto, ond hyd nes eu bod, fe'ch cynghorir i'w hosgoi.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // DIOGELWCH: rhaid i'r galwr warantu bod gwerth unedol yn ddilys ar gyfer `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Yn cyfnewid y gwerthoedd mewn dau leoliad symudol, heb ddad-ddynodi'r naill neu'r llall.
///
/// * Os ydych chi am gyfnewid gyda gwerth diofyn neu ffug, gweler [`take`].
/// * Os ydych chi am gyfnewid gyda gwerth wedi'i basio, gan ddychwelyd yr hen werth, gweler [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // DIOGELWCH: crëwyd yr awgrymiadau amrwd o gyfeiriadau symudol y gellir eu bodloni
    // cyfyngiadau ar `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Yn disodli `dest` gyda gwerth diofyn `T`, gan ddychwelyd y gwerth `dest` blaenorol.
///
/// * Os ydych chi am ddisodli gwerthoedd dau newidyn, gweler [`swap`].
/// * Os ydych chi eisiau rhoi gwerth wedi'i basio yn lle'r gwerth diofyn, gweler [`replace`].
///
/// # Examples
///
/// Enghraifft syml:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` yn caniatáu cymryd perchnogaeth ar faes strwythuredig trwy ei ddisodli â gwerth "empty".
/// Heb `take` gallwch redeg i mewn i faterion fel y rhain:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Sylwch nad yw `T` o reidrwydd yn gweithredu [`Clone`], felly ni all hyd yn oed glonio ac ailosod `self.buf`.
/// Ond gellir defnyddio `take` i ddatgysylltu gwerth gwreiddiol `self.buf` o `self`, gan ganiatáu iddo gael ei ddychwelyd:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Yn symud `src` i'r `dest` y cyfeiriwyd ato, gan ddychwelyd y gwerth `dest` blaenorol.
///
/// Nid yw'r naill werth na'r llall yn cael ei ollwng.
///
/// * Os ydych chi am ddisodli gwerthoedd dau newidyn, gweler [`swap`].
/// * Os ydych chi eisiau rhoi gwerth diofyn yn ei le, gweler [`take`].
///
/// # Examples
///
/// Enghraifft syml:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` yn caniatáu defnyddio maes strwythuredig trwy ei ddisodli â gwerth arall.
/// Heb `replace` gallwch redeg i mewn i faterion fel y rhain:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Sylwch nad yw `T` o reidrwydd yn gweithredu [`Clone`], felly ni allwn hyd yn oed glonio `self.buf[i]` i osgoi symud.
/// Ond gellir defnyddio `replace` i ddatgysylltu'r gwerth gwreiddiol ar y mynegai hwnnw o `self`, gan ganiatáu iddo gael ei ddychwelyd:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // DIOGELWCH: Rydym yn darllen o `dest` ond yn ysgrifennu `src` yn uniongyrchol iddo wedyn,
    // fel nad yw'r hen werth yn cael ei ddyblygu.
    // Nid oes unrhyw beth yn cael ei ollwng ac ni all unrhyw beth yma panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Gwarediadau o werth.
///
/// Mae hyn yn gwneud hynny trwy alw gweithrediad y ddadl o [`Drop`][drop].
///
/// I bob pwrpas, nid yw hyn yn gwneud dim ar gyfer mathau sy'n gweithredu `Copy`, ee
/// integers.
/// Mae gwerthoedd o'r fath yn cael eu copïo a _then_ yn cael ei symud i'r swyddogaeth, felly mae'r gwerth yn parhau ar ôl yr alwad swyddogaeth hon.
///
///
/// Nid yw'r swyddogaeth hon yn hud;fe'i diffinnir yn llythrennol fel
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Oherwydd bod `_x` yn cael ei symud i'r swyddogaeth, mae'n cael ei ollwng yn awtomatig cyn i'r swyddogaeth ddychwelyd.
///
/// [drop]: Drop
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // gollwng yn benodol vector
/// ```
///
/// Gan fod [`RefCell`] yn gorfodi'r rheolau benthyca ar amser rhedeg, gall `drop` ryddhau benthyciad [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ildio'r benthyciad symudol ar y slot hwn
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Nid yw `drop` yn effeithio ar gyfanrifau a mathau eraill sy'n gweithredu [`Copy`].
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // mae copi o `x` yn cael ei symud a'i ollwng
/// drop(y); // copi o `y` ei symud ac yn gollwng
///
/// println!("x: {}, y: {}", x, y.0); // ar gael o hyd
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Yn dehongli `src` fel un sydd â math `&U`, ac yna'n darllen `src` heb symud y gwerth a gynhwysir.
///
/// Bydd y swyddogaeth hon yn cymryd yn anniogel bod y pwyntydd `src` yn ddilys ar gyfer beitiau [`size_of::<U>`][size_of] trwy drawsnewid `&T` i `&U` ac yna darllen yr `&U` (heblaw bod hyn yn cael ei wneud mewn ffordd sy'n gywir hyd yn oed pan fydd `&U` yn gwneud gofynion alinio llymach na `&T`).
/// Bydd hefyd yn anniogel yn creu copi o'r gwerth a gynhwysir yn lle symud allan o `src`.
///
/// Nid yw'n wall amser llunio os oes gan `T` a `U` wahanol feintiau, ond anogir yn gryf i alw'r swyddogaeth hon dim ond lle mae gan `T` a `U` yr un maint.Mae'r swyddogaeth hon yn sbarduno [undefined behavior][ub] os yw `U` yn fwy na `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copïwch y data o 'foo_array' a'i drin fel 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Addasu'r data copïo
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Ni ddylai cynnwys 'foo_array' fod wedi newid
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Os oes gan U ofyniad alinio uwch, efallai na fydd src wedi'i alinio'n addas.
    if align_of::<U>() > align_of::<T>() {
        // DIOGELWCH: Mae `src` yn gyfeirnod y mae'n sicr y bydd yn ddilys ar gyfer darlleniadau.
        // Rhaid i'r galwr warantu bod y trosglwyddiad gwirioneddol yn ddiogel.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // DIOGELWCH: Mae `src` yn gyfeirnod y mae'n sicr y bydd yn ddilys ar gyfer darlleniadau.
        // Gwnaethom wirio bod `src as *const U` wedi'i alinio'n iawn.
        // Rhaid i'r galwr warantu bod y trosglwyddiad gwirioneddol yn ddiogel.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Math afloyw sy'n cynrychioli gwahaniaethydd enwm.
///
/// Gweler swyddogaeth [`discriminant`] yn y modiwl hwn i gael mwy o wybodaeth.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ni ellir deillio o'r gweithrediadau trait hyn oherwydd nid ydym am gael unrhyw ffiniau ar T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Yn dychwelyd gwerth sy'n nodi'r amrywiad enwm yn `v` yn unigryw.
///
/// Os nad yw `T` yn enwm, ni fydd galw'r swyddogaeth hon yn arwain at ymddygiad heb ei ddiffinio, ond mae'r gwerth dychwelyd yn amhenodol.
///
///
/// # Stability
///
/// Gall gwahaniaethydd amrywiad enwm newid os bydd y diffiniad enum yn newid.
/// Ni fydd gwahaniaethydd o ryw amrywiad yn newid rhwng crynhoadau gyda'r un crynhoydd.
///
/// # Examples
///
/// Gellir defnyddio hwn i gymharu enymau sy'n cario data, wrth ddiystyru'r data gwirioneddol:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Yn dychwelyd nifer yr amrywiadau yn y math enwm `T`.
///
/// Os nad yw `T` yn enwm, ni fydd galw'r swyddogaeth hon yn arwain at ymddygiad heb ei ddiffinio, ond mae'r gwerth dychwelyd yn amhenodol.
/// Yn yr un modd, os yw `T` yn enwm gyda mwy o amrywiadau na `usize::MAX`, mae'r gwerth dychwelyd yn amhenodol.
/// Bydd amrywiadau anghyfannedd yn cael eu cyfrif.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}