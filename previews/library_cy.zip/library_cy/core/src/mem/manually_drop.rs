use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Pecyn lapio i atal casglwr rhag galw dinistriwr `T` yn awtomatig.
/// Mae'r deunydd lapio yw 0-gost.
///
/// `ManuallyDrop<T>` yn ddarostyngedig i'r un optimizations cynllun â `T`.
/// O ganlyniad, mae wedi * * unrhyw effaith ar y rhagdybiaethau y mae'r compiler yn gwneud am ei gynnwys.
/// Er enghraifft, ymgychwyn yn `ManuallyDrop<&mut T>` gyda [`mem::zeroed`] yn ymddygiad anniffiniedig.
/// Os oes angen i drin data uninitialized, defnyddiwch [`MaybeUninit<T>`] yn lle hynny.
///
/// Nodwch fod mynediad at y gwerth y tu mewn i `ManuallyDrop<T>` yn ddiogel.
/// Mae hyn yn golygu na ddylid datgelu `ManuallyDrop<T>` y mae ei gynnwys wedi'i ollwng trwy API diogel cyhoeddus.
/// Gyfatebol, `ManuallyDrop::drop` yn anniogel.
///
/// # `ManuallyDrop` a gollwng gorchymyn.
///
/// Mae gan Rust yn [drop order] diffinio'n dda o werthoedd.
/// Er mwyn sicrhau bod caeau neu bobl leol yn cael eu gollwng mewn trefn benodol, ail-archebu y datganiadau o'r fath fod y gorchymyn gostyngiad ymhlyg yw'r un cywir.
///
/// Mae'n bosibl defnyddio `ManuallyDrop` i reoli'r drefn galw heibio, ond mae hyn yn gofyn am cod anniogel ac yn anodd i'w wneud yn gywir ym mhresenoldeb ymlacio.
///
///
/// Er enghraifft, os ydych chi am sicrhau bod maes penodol yn cael ei ollwng ar ôl y lleill, gwnewch ef yn faes olaf strwythur:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` Bydd yn cael ei ollwng ar ôl `children`.
///     // Rust gwarantu bod caeau yn cael eu gollwng yn y drefn datganiad.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Lapiwch gwerth i'w gollwng llaw.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Gallwch barhau i weithredu'n ddiogel ar y gwerth
    /// assert_eq!(*x, "Hello");
    /// // Ond ni fydd `Drop` yn cael ei redeg yma
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Detholiad gwerth o'r cynhwysydd `ManuallyDrop`.
    ///
    /// Mae hyn yn caniatáu i'r gwerth gael ei ollwng eto.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Mae hyn yn gollwng yr `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Yn cymryd y gwerth o'r tu allan cynhwysydd `ManuallyDrop<T>`.
    ///
    /// Mae'r dull hwn wedi'i fwriadu'n bennaf ar gyfer symud gwerthoedd gollwng.
    /// Yn lle defnyddio [`ManuallyDrop::drop`] i ollwng y gwerth â llaw, gallwch ddefnyddio'r dull hwn i gymryd y gwerth a'i ddefnyddio sut bynnag y dymunir.
    ///
    /// Pryd bynnag y bo modd, mae'n well defnyddio [`into_inner`][`ManuallyDrop::into_inner`] yn lle hynny, a oedd yn atal dyblygu cynnwys y `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn symud y gwerth a gynhwysir allan yn semantig heb atal defnydd pellach, gan adael cyflwr y cynhwysydd hwn yn ddigyfnewid.
    /// Eich cyfrifoldeb chi yw sicrhau na chaiff yr `ManuallyDrop` hwn ei ddefnyddio eto.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // DIOGELWCH: rydym yn darllen o gyfeirnod, sydd wedi'i warantu
        // i fod yn ddilys ar gyfer darlleniadau.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Yn gostwng y gwerth a gynhwysir â llaw.Mae hyn yn union cyfateb i alw [`ptr::drop_in_place`] gyda pwyntydd i'r gwerth a geir.
    /// Fel y cyfryw, oni bai bod y gwerth a geir yn struct sang, y destructor yn cael ei alw yn-waith heb symud y gwerth, ac felly gellir ei ddefnyddio i ddiogel gollwng data [pinned].
    ///
    /// Os oes gennych berchenogaeth o werth, gallwch ddefnyddio [`ManuallyDrop::into_inner`] yn lle hynny.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn rhedeg dinistriwr y gwerth a gynhwysir.
    /// Heblaw am newidiadau a wnaed gan y dinistriwr ei hun, mae'r cof yn cael ei adael yn ddigyfnewid, ac o ran y casglwr o hyd mae ganddo batrwm did sy'n ddilys ar gyfer y math `T`.
    ///
    ///
    /// Fodd bynnag, ni ddylai hyn gwerth "zombie" fod yn agored i cod diogel, ac ni ddylai swyddogaeth hon gael ei alw fwy nag unwaith.
    /// I ddefnyddio gwerth ôl iddo gael ei ollwng, neu gollwng werth sawl gwaith, yn gallu achosi ymddygiad amhenodol (yn dibynnu ar yr hyn y `drop` yn ei wneud).
    /// Fel arfer, mae hyn yn cael ei rwystro gan y system math, ond mae'n rhaid i ddefnyddwyr `ManuallyDrop` cynnal gwarantau rhai sydd heb gymorth gan y compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // DIOGELWCH: rydym yn gollwng y gwerth yn tynnu sylw at y cyfeiriad mutable
        // sydd yn sicr o fod yn ddilys ar gyfer ysgrifennu yn.
        // Mae i fyny i'r galwr i wneud yn siŵr nad yw `slot` cael ei ollwng eto.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}