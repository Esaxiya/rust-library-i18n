#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Mae `RawWaker` yn caniatáu i weithredwr ysgutor dasg greu [`Waker`] sy'n darparu ymddygiad deffro wedi'i addasu.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Mae'n cynnwys pwyntydd data a [virtual function pointer table (vtable)][vtable] sy'n addasu ymddygiad yr `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Pwyntydd data, y gellir ei ddefnyddio i storio data mympwyol fel sy'n ofynnol gan yr ysgutor.
    /// Gallai hyn fod ee
    /// pwyntydd wedi'i ddileu â math i `Arc` sy'n gysylltiedig â'r dasg.
    /// Mae gwerth y maes hwn yn cael ei basio i bob swyddogaeth sy'n rhan o'r hyfyw fel y paramedr cyntaf.
    ///
    data: *const (),
    /// Tabl pwyntydd swyddogaeth rithwir sy'n addasu ymddygiad y waker hwn.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Creu `RawWaker` newydd gan y pwyntydd `data` a ddarperir a `vtable`.
    ///
    /// Gellir defnyddio'r pwyntydd `data` i storio data mympwyol fel sy'n ofynnol gan yr ysgutor.Gallai hyn fod, ee
    /// pwyntydd wedi'i ddileu â math i `Arc` sy'n gysylltiedig â'r dasg.
    /// Bydd gwerth y pwyntydd hon yn cael ei throsglwyddo i'r holl swyddogaethau sy'n rhan o'r `vtable` fel paramedr cyntaf.
    ///
    /// Mae'r `vtable` yn addasu ymddygiad `Waker` sy'n cael ei greu o `RawWaker`.
    /// Ar gyfer pob gweithrediad ar yr `Waker`, gelwir y swyddogaeth gysylltiedig yn `vtable` yr `RawWaker` sylfaenol.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tabl pwyntydd swyddogaeth rithwir (vtable) sy'n nodi ymddygiad [`RawWaker`].
///
/// Pwyntydd pasio i bob swyddogaeth y tu mewn i'r vtable yw'r pwyntydd `data` o'r [`RawWaker`] gwrthrych amgáu.
///
/// Dim ond ar bwyntydd `data` gwrthrych [`RawWaker`] a adeiladwyd yn iawn o'r tu mewn i weithrediad [`RawWaker`] y bwriedir i'r swyddogaethau y tu mewn i'r strwythur hwn gael eu galw.
/// Bydd galw un o'r swyddogaethau a gynhwysir gan ddefnyddio unrhyw bwyntydd `data` arall yn achosi ymddygiad heb ei ddiffinio.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Bydd y swyddogaeth hon yn cael ei galw pan fydd yr [`RawWaker`] yn cael ei glonio, ee pan fydd yr [`Waker`] y mae'r [`RawWaker`] yn cael ei storio ynddo yn cael ei glonio.
    ///
    /// Rhaid gweithredu'r swyddogaeth hon gadw'r holl adnoddau sydd eu hangen er enghraifft ychwanegol hwn o [`RawWaker`] a tasg cysylltiedig.
    /// Dylai ffonio `wake` ar yr [`RawWaker`] sy'n deillio o hyn arwain at ddeffro o'r un dasg a fyddai wedi ei deffro gan yr [`RawWaker`] gwreiddiol.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Bydd y swyddogaeth hon yn cael ei galw pan fydd `wake` yn cael ei alw ar yr [`Waker`].
    /// Rhaid iddo ddeffro'r dasg sy'n gysylltiedig â'r [`RawWaker`] hwn.
    ///
    /// Rhaid gweithredu'r swyddogaeth hon gwnewch yn siwr i ryddhau unrhyw adnoddau sy'n gysylltiedig â achos hwn o [`RawWaker`] a tasg cysylltiedig.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Bydd y swyddogaeth hon yn cael ei alw pan elwir `wake_by_ref` ar y [`Waker`].
    /// Rhaid iddo ddeffro'r dasg sy'n gysylltiedig â'r [`RawWaker`] hwn.
    ///
    /// Mae'r swyddogaeth hon yn debyg i `wake`, ond rhaid iddi beidio â defnyddio'r pwyntydd data a ddarperir.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Mae'r swyddogaeth hon yn cael ei galw pan fydd [`RawWaker`] yn cael ei ollwng.
    ///
    /// Rhaid gweithredu'r swyddogaeth hon gwnewch yn siwr i ryddhau unrhyw adnoddau sy'n gysylltiedig â achos hwn o [`RawWaker`] a tasg cysylltiedig.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Yn creu `RawWakerVTable` newydd o'r swyddogaethau `clone`, `wake`, `wake_by_ref`, a `drop` a ddarperir.
    ///
    /// # `clone`
    ///
    /// Bydd y swyddogaeth hon yn cael ei galw pan fydd yr [`RawWaker`] yn cael ei glonio, ee pan fydd yr [`Waker`] y mae'r [`RawWaker`] yn cael ei storio ynddo yn cael ei glonio.
    ///
    /// Rhaid gweithredu'r swyddogaeth hon gadw'r holl adnoddau sydd eu hangen er enghraifft ychwanegol hwn o [`RawWaker`] a tasg cysylltiedig.
    /// Dylai ffonio `wake` ar yr [`RawWaker`] sy'n deillio o hyn arwain at ddeffro o'r un dasg a fyddai wedi ei deffro gan yr [`RawWaker`] gwreiddiol.
    ///
    /// # `wake`
    ///
    /// Bydd y swyddogaeth hon yn cael ei galw pan fydd `wake` yn cael ei alw ar yr [`Waker`].
    /// Rhaid iddo ddeffro'r dasg sy'n gysylltiedig â'r [`RawWaker`] hwn.
    ///
    /// Rhaid gweithredu'r swyddogaeth hon gwnewch yn siwr i ryddhau unrhyw adnoddau sy'n gysylltiedig â achos hwn o [`RawWaker`] a tasg cysylltiedig.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Bydd y swyddogaeth hon yn cael ei alw pan elwir `wake_by_ref` ar y [`Waker`].
    /// Rhaid iddo ddeffro'r dasg sy'n gysylltiedig â'r [`RawWaker`] hwn.
    ///
    /// Mae'r swyddogaeth hon yn debyg i `wake`, ond rhaid iddi beidio â defnyddio'r pwyntydd data a ddarperir.
    ///
    /// # `drop`
    ///
    /// Mae'r swyddogaeth hon yn cael ei galw pan fydd [`RawWaker`] yn cael ei ollwng.
    ///
    /// Rhaid gweithredu'r swyddogaeth hon gwnewch yn siwr i ryddhau unrhyw adnoddau sy'n gysylltiedig â achos hwn o [`RawWaker`] a tasg cysylltiedig.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Yr `Context` o dasg asyncronig.
///
/// Ar hyn o bryd, mae `Context` yn darparu mynediad i `&Waker` yn unig y gellir ei ddefnyddio i ddeffro'r dasg gyfredol.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Sicrhewch ein bod yn atal prawf future yn erbyn newidiadau amrywiant trwy orfodi'r oes i fod yn ddieithriad (mae oesau dadleuon yn wrthgyferbyniol tra bod oesoedd dychwelyd yn gyfochrog).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Creu `Context` newydd o `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Yn dychwelyd cyfeiriad at yr `Waker` ar gyfer y dasg gyfredol.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Mae `Waker` yn handlen ar gyfer deffro tasg trwy hysbysu ei ysgutor ei bod yn barod i'w rhedeg.
///
/// Mae'r handlen hon yn crynhoi enghraifft [`RawWaker`], sy'n diffinio'r ymddygiad deffro penodol i ysgutor.
///
///
/// Yn gweithredu [`Clone`], [`Send`], a [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Deffro y dasg sy'n gysylltiedig â'r `Waker` hwn.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Mae'r alwad ddeffro wirioneddol yn cael ei dirprwyo trwy alwad swyddogaeth rithwir i'r gweithredu a ddiffinnir gan yr ysgutor.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Peidiwch â ffonio `drop`-bydd y waker yn cael ei fwyta gan `wake`.
        crate::mem::forget(self);

        // DIOGELWCH: Mae hwn yn ddiogel oherwydd bod `Waker::from_raw` yw'r unig ffordd
        // i ymgychwyn `wake` a `data` gwneud yn ofynnol i'r defnyddiwr i gydnabod bod y contract `RawWaker` ei gadarnhau.
        //
        unsafe { (wake)(data) };
    }

    /// Deffro y dasg sy'n gysylltiedig â'r `Waker` hyn heb bwyta'r `Waker`.
    ///
    /// Mae hyn yn debyg i `wake`, ond gall fod ychydig yn llai effeithlon yn yr achos lle mae `Waker` yn eiddo ar gael.
    /// Dylai'r dull hwn gael ei ffafrio na galw `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Mae'r alwad ddeffro wirioneddol yn cael ei dirprwyo trwy alwad swyddogaeth rithwir i'r gweithredu a ddiffinnir gan yr ysgutor.
        //

        // DIOGELWCH: gweler `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Ffurflenni `true` os `Waker` hwn ac `Waker` arall wedi deffro yr un dasg.
    ///
    /// Mae'r swyddogaeth hon yn gweithio ar sail ymdrech orau, a gall ddychwelyd yn anwir hyd yn oed pan fyddai'r `Waker 'yn deffro'r un dasg.
    /// Fodd bynnag, os bydd y swyddogaeth hon yn dychwelyd `true`, gwarantir y bydd y `Waker` yn deffro'r un dasg.
    ///
    /// Defnyddir y swyddogaeth hon yn bennaf at ddibenion optimeiddio.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Yn creu `Waker` newydd o [`RawWaker`].
    ///
    /// Nid yw ymddygiad yr `Waker` a ddychwelwyd wedi'i ddiffinio os na chaiff y contract a ddiffinnir yn nogfennaeth [`RawWaker`] a [`RawWakerVTable`] ei gadarnhau.
    ///
    /// Felly mae'r dull hwn yn anniogel.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // DIOGELWCH: Mae hwn yn ddiogel oherwydd bod `Waker::from_raw` yw'r unig ffordd
            // i ymgychwyn `clone` a `data` gwneud yn ofynnol i'r defnyddiwr i gydnabod bod y contract [`RawWaker`] ei gadarnhau.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // DIOGELWCH: Mae hwn yn ddiogel oherwydd bod `Waker::from_raw` yw'r unig ffordd
        // i gychwyn `drop` a `data` gan ei gwneud yn ofynnol i'r defnyddiwr gydnabod bod contract `RawWaker` yn cael ei gynnal.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}