//! Traits gyfer trawsnewidiadau rhwng mathau.
//!
//! Mae'r traits yn y modiwl hwn yn darparu ffordd i drosi o un math i fath arall.
//! Mae pob trait yn gwasanaethu pwrpas gwahanol:
//!
//! - Gweithredu'r [`AsRef`] trait ar gyfer trawsnewidiadau cyfeirio-i-gyfeirio rhad
//! - Gweithredu'r [`AsMut`] trait gyfer trawsnewidiadau mutable-i-mutable rhad
//! - Gweithredu'r [`From`] trait ar gyfer cymryd trosiadau gwerth-i-werth
//! - Gweithredu'r [`Into`] trait am llafurus trawsnewidiadau gwerth-i-werth i fathau tu allan i'r crate cyfredol
//! - Mae'r [`TryFrom`] a [`TryInto`] traits ymddwyn fel [`From`] a [`Into`], ond dylid eu rhoi ar waith pan fydd y trawsnewid yn methu.
//!
//! Mae'r traits yn y modiwl hwn yn aml yn cael eu defnyddio fel trait bounds ar gyfer swyddogaethau generig fel bod at ddadleuon o fathau lluosog yn cael eu cefnogi.Gweler y dogfennau pob trait am enghreifftiau.
//!
//! Fel awdur llyfrgell, dylai fod yn well gennych bob amser weithredu [`From<T>`][`From`] neu [`TryFrom<T>`][`TryFrom`] yn hytrach na [`Into<U>`][`Into`] neu [`TryInto<U>`][`TryInto`], gan fod [`From`] a [`TryFrom`] yn darparu mwy o hyblygrwydd ac yn cynnig gweithrediadau [`Into`] neu [`TryInto`] cyfatebol am ddim, diolch i weithred flanced yn y llyfrgell safonol.
//! Wrth dargedu fersiwn cyn Rust 1.41, efallai y bydd angen i weithredu [`Into`] neu [`TryInto`] yn uniongyrchol wrth drosi i fath y tu allan i'r crate cyfredol.
//!
//! # Gweithrediadau Generig
//!
//! - [`AsRef`] a [`AsMut`] auto-dereference os yw'r math mewnol yn gyfeiriad
//! - [`From`]`<U>i T` awgrymu [`Into`]`</u><T><U>ar gyfer U`</u>
//! - [`TryFrom`]`<U>i T` awgrymu [`TryInto`]`</u><T><U>am U`</u>
//! - [`From`] ac mae [`Into`] yn atblygol, sy'n golygu y gall pob math `into` eu hunain a `from` eu hunain
//!
//! Gweler pob trait am enghreifftiau defnydd.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Swyddogaeth hunaniaeth.
///
/// Mae dau beth yn bwysig Nodyn am y swyddogaeth hon:
///
/// - Nid yw bob amser yn gyfwerth â chau fel `|x| x`, oherwydd gall y cau orfodi `x` i fath gwahanol.
///
/// - Mae'n symud mewnbwn `x` trosglwyddo i'r swyddogaeth.
///
/// Er y gallai ymddangos yn rhyfedd i fod â swyddogaeth honno yn dychwelyd dim ond yn ôl y mewnbwn, mae rhai defnyddiau diddorol.
///
///
/// # Examples
///
/// Defnyddio `identity` i wneud dim mewn cyfres o swyddogaethau diddorol eraill:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Gadewch i ni esgus bod ychwanegu un yn swyddogaeth ddiddorol.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Defnyddio `identity` fel achos sylfaen "do nothing" mewn amodol:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Gwneud pethau mwy diddorol ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Defnyddio `identity` i gadw'r `Some` amrywiadau o iterator o `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Fe'i defnyddir i wneud trosiad rhad cyfeirio i gyfeirio.
///
/// Mae'r trait yn debyg i [`AsMut`] sy'n cael ei ddefnyddio ar gyfer trosi rhwng cyfeiriadau mutable.
/// Os oes angen i ni wneud trosi costus mae'n well i weithredu [`From`] gyda'r math `&T` neu ysgrifennu swyddogaeth arferiad.
///
/// `AsRef` yr un llofnod fel [`Borrow`], ond [`Borrow`] yn wahanol mewn rhai agweddau:
///
/// - Yn wahanol i `AsRef`, [`Borrow`] mae gan impl flanced ar gyfer unrhyw `T`, a gellir ei ddefnyddio i dderbyn naill ai cyfeirio neu werth.
/// - [`Borrow`] hefyd yn ei gwneud yn ofynnol bod [`Hash`], [`Eq`] a [`Ord`] ar gyfer gwerth a fenthycwyd yn gyfwerth â rhai'r gwerth dan berchnogaeth.
/// Am y rheswm hwn, os ydych am i fenthyg yn unig maes unigol o struct gallwch weithredu `AsRef`, ond nid [`Borrow`].
///
/// **Note: Rhaid i hyn beidio trait methu **.Os gall y trosi yn methu, yn defnyddio dull pwrpasol, sy'n dychwelyd i [`Option<T>`] neu [`Result<T, E>`].
///
/// # Gweithrediadau Generig
///
/// - `AsRef` dad-gyfeiriadau auto os yw'r math mewnol yn gyfeirnod neu'n gyfeirnod symudol (ee: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Trwy ddefnyddio trait bounds gallwn dderbyn dadleuon o wahanol fathau cyhyd ag y gellir eu trosi i'r math penodedig `T`.
///
/// Er enghraifft: Drwy greu swyddogaeth generig sy'n cymryd `AsRef<str>` rydym yn mynegi ein bod am dderbyn pob cyfeiriad y gellir eu trosi i [`&str`] fel dadl.
/// Gan fod [`String`] a [`&str`] yn gweithredu `AsRef<str>` gallwn dderbyn y ddau fel dadl mewnbwn.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Yn perfformio'r trosiad.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Fe'i defnyddir i wneud trosi cyfeirio mutable i mutable rhad.
///
/// Mae'r trait yn debyg i [`AsRef`] ond defnyddio ar gyfer trosi rhwng cyfeiriadau mutable.
/// Os oes angen i chi drosi costus mae'n well gweithredu [`From`] gyda math `&mut T` neu ysgrifennu swyddogaeth wedi'i haddasu.
///
/// **Note: Rhaid i hyn beidio trait methu **.Os gall y trosi yn methu, yn defnyddio dull pwrpasol, sy'n dychwelyd i [`Option<T>`] neu [`Result<T, E>`].
///
/// # Gweithrediadau Generig
///
/// - `AsMut` dad-gyfeiriadau auto os yw'r math mewnol yn gyfeirnod symudol (ee: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Gan ddefnyddio `AsMut` fel trait bound ar gyfer swyddogaeth generig gallwn dderbyn yr holl gyfeiriadau symudol y gellir eu trosi i fath `&mut T`.
/// Gan fod [`Box<T>`] yn gweithredu `AsMut<T>` gallwn ysgrifennu swyddogaeth `add_one` sy'n cymryd yr holl ddadleuon y gellir eu trosi i `&mut u64`.
/// Gan fod [`Box<T>`] yn gweithredu `AsMut<T>`, `add_one` yn derbyn dadleuon o'r math `&mut Box<u64>` yn ogystal:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Yn perfformio'r trosiad.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Trosiad gwerth-i-werth sy'n defnyddio'r gwerth mewnbwn.Y gwrthwyneb i [`From`].
///
/// Dylai un osgoi gweithredu [`Into`] a gweithredu [`From`] yn lle hynny.
/// Mae gweithredu [`From`] yn awtomatig yn rhoi [`Into`] ar waith i un, diolch i weithredu'r flanced yn y llyfrgell safonol.
///
/// Mae'n well gennych ddefnyddio [`Into`] dros [`From`] wrth nodi trait bounds ar swyddogaeth generig i sicrhau y gellir defnyddio mathau sy'n gweithredu [`Into`] yn unig hefyd.
///
/// **Note: Rhaid i'r trait hwn beidio â methu **.Os gall y trawsnewid fethu, defnyddiwch [`TryInto`].
///
/// # Gweithrediadau Generig
///
/// - [`From`]`<T>ar gyfer U` yn awgrymu `Into<U> for T`
/// - [`Into`] yn atblyg, sy'n golygu bod `Into<T> for T` yn cael ei weithredu
///
/// # Gweithredu [`Into`] ar gyfer trawsnewidiadau i fathau allanol mewn hen fersiynau o Rust
///
/// Cyn Rust 1.41, os nad oedd y math o gyrchfan yn rhan o'r crate cyfredol yna ni allech weithredu [`From`] yn uniongyrchol.
/// Er enghraifft, yn cymryd y cod hwn:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Bydd hyn yn methu â lunio mewn fersiynau hŷn o'r iaith gan fod rheolau'r orphaning Rust yn arfer bod ychydig yn fwy llym.
/// I osgoi hyn, gallech gweithredu [`Into`] yn uniongyrchol:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Mae'n bwysig deall nad yw [`Into`] yn darparu gweithrediad [`From`] (fel y mae [`From`] yn ei wneud gyda [`Into`]).
/// Felly, dylech bob amser geisio gweithredu [`From`] ac yna cwympo yn ôl i [`Into`] os na ellir gweithredu [`From`].
///
/// # Examples
///
/// [`String`] offer [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Er mwyn mynegi ein bod am swyddogaeth generig i gymryd pob ddadleuon y gellir eu trosi i fath penodol `T`, gallwn ddefnyddio trait bound o [`Into`]`<T>`.
///
/// Er enghraifft: Mae'r swyddogaeth `is_hello` yn cymryd pob ddadleuon y gellir eu trosi i mewn i [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Yn perfformio'r trosiad.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Fe'i defnyddir i wneud addasiadau gwerth-i-werth wrth ddefnyddio'r gwerth mewnbwn.Mae'n cilydd [`Into`].
///
/// Dylai well gan un bob amser yn gweithredu `From` dros [`Into`] oherwydd gweithredu `From` yn awtomatig yn darparu un gyda gweithredu [`Into`] diolch i weithredu'r flanced yn y llyfrgell safonol.
///
///
/// Dim ond gweithredu [`Into`] wrth dargedu fersiwn cyn Rust 1.41 a throsi i fath y tu allan i'r crate cyfredol.
/// `From` nid oedd yn gallu gwneud y mathau hyn o drawsnewidiadau mewn fersiynau cynharach oherwydd rheolau amddifad Rust.
/// Gweler [`Into`] am ragor o fanylion.
///
/// Mae'n well gennych ddefnyddio [`Into`] yn hytrach na defnyddio `From` wrth nodi trait bounds ar swyddogaeth generig.
/// Gall y modd hwn, mathau sy'n gweithredu [`Into`] yn uniongyrchol yn cael ei ddefnyddio fel dadleuon yn ogystal.
///
/// Mae'r `From` hefyd yn ddefnyddiol iawn wrth berfformio trin gwallau.Wrth lunio swyddogaeth sy'n gallu methu, bydd y math dychwelyd yn gyffredinol ar ffurf `Result<T, E>`.
/// Mae'r `From` trait symleiddio trin drwy ganiatáu swyddogaeth i ddychwelyd math wall sengl sy'n crynhoi mathau wall lluosog wall.Gweler yr adran "Examples" a [the book][book] am fwy o fanylion.
///
/// **Note: Rhaid i hyn beidio trait methu **.Os gall y trawsnewid fethu, defnyddiwch [`TryFrom`].
///
/// # Gweithrediadau Generig
///
/// - `From<T> for U` yn awgrymu [`Into`]`ar <U>gyfer T`</u>
/// - `From` yn atblygol, sy'n golygu bod `From<T> for T` yn cael ei weithredu
///
/// # Examples
///
/// [`String`] yn gweithredu `From<&str>`:
///
/// Gwneir trosiad penodol o `&str` i Llinyn fel a ganlyn:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Tra perfformio gwall drin mae'n aml yn ddefnyddiol i weithredu `From` ar gyfer eich math wall hun.
/// Trwy drosi mathau gwall sylfaenol i'n math gwall personol ein hunain sy'n crynhoi'r math gwall sylfaenol, gallwn ddychwelyd un math gwall heb golli gwybodaeth am yr achos sylfaenol.
/// Mae'r gweithredwr '?' yn trosi'r math gwall sylfaenol yn awtomatig i'n math gwall arferol trwy ffonio `Into<CliError>::into` a ddarperir yn awtomatig wrth weithredu `From`.
/// Yna mae'r casglwr yn cynnwys pa weithrediad `Into` y dylid ei ddefnyddio.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Yn perfformio'r trosiad.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ceisiwyd trosi sy'n defnyddio `self`, a allai fod yn ddrud neu beidio.
///
/// Fel arfer, ni ddylai awduron Llyfrgell weithredu trait hwn yn uniongyrchol, ond os byddai'n well rhoi'r [`TryFrom`] trait, sy'n cynnig mwy o hyblygrwydd ac yn rhoi ar waith `TryInto` cyfatebol ar gyfer rhad ac am ddim, diolch i weithredu blanced yn y llyfrgell safonol.
/// Am ragor o wybodaeth am hyn, gweler y ddogfennaeth ar gyfer [`Into`].
///
/// # Gweithredu `TryInto`
///
/// Mae hyn yn dioddef yr un cyfyngiadau a rhesymu â gweithredu [`Into`], gweler yno am fanylion.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Mae'r math dychwelyd mewn achos o gamgymeriad trosi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Yn perfformio'r trosiad.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Syml ac addasiadau math diogel a allai fethu mewn ffordd a reolir o dan rai amgylchiadau.Mae'n cilydd [`TryInto`].
///
/// Mae hyn yn ddefnyddiol pan fyddwch yn gwneud trosi fath a all llwyddo trivially ond efallai y bydd angen trin arbennig.
/// Er enghraifft, nid oes unrhyw ffordd i drosi [`i64`] i mewn i [`i32`] ddefnyddio'r [`From`] trait, oherwydd gall [`i64`] gynnwys gwerth na all [`i32`] cynrychioli ac felly byddai'r trosi colli data.
///
/// Gallai hyn gael ei drin gan truncating y [`i64`] i [`i32`] (yn y bôn rhoi'r [`i64`] Mae gwerth modwlo [`i32::MAX`]) neu gan syml dychwelyd [`i32::MAX`], neu drwy ryw ddull arall.
/// Mae'r [`From`] trait wedi'i fwriadu ar gyfer trawsnewidiadau perffaith, felly mae'r `TryFrom` trait yn hysbysu'r rhaglennydd pryd y gallai trosi math fynd yn ddrwg ac yn gadael iddyn nhw benderfynu sut i'w drin.
///
/// # Gweithrediadau Generig
///
/// - `TryFrom<T> for U` yn awgrymu [`TryInto`]`<U>i T`</u>
/// - [`try_from`] yn atblygol, sy'n golygu bod `TryFrom<T> for T` yn cael ei weithredu ac ni all fethu-y math `Error` cysylltiedig ar gyfer galw `T::try_from()` ar werth math `T` yn [`Infallible`].
/// Pan fydd y math [`!`] wedi'i sefydlogi bydd [`Infallible`] a [`!`] yn gyfwerth.
///
/// `TryFrom<T>` gellir eu gweithredu fel a ganlyn:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Fel y disgrifiwyd, offer [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Mae distawrwydd `big_number` yn dawel, yn gofyn am ganfod a thrafod y boncyff ar ôl y ffaith.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Dychwelyd gwall gan fod `big_number` yn rhy fawr i ffitio mewn `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Yn dychwelyd `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Mae'r math dychwelyd mewn achos o gamgymeriad trosi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Yn perfformio'r trosiad.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// MEWNFORIADAU CYFFREDINOL
////////////////////////////////////////////////////////////////////////////////

// Wrth i lifftiau dros&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Wrth i lifftiau dros &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ddisodli'r impls uchod ar gyfer a/a Mut gyda'r un yn fwy cyffredinol canlynol:
// // Fel lifftiau dros Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>i D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// lifftiau AsMut dros &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ddisodli'r impl uchod ar gyfer &mut gyda'r un yn fwy cyffredinol canlynol:
// // Mae AsMut yn codi dros DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? Sized> AsMut ar <U>gyfer D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// O awgrymu Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// O (ac felly Into) yn atblygol
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nodyn sefydlogrwydd:** Nid yw'r impl hwn yn bodoli eto, ond rydym yn "reserving space" i'w ychwanegu yn y future.
/// Gweler [rust-lang/rust#64715][#64715] am fanylion.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): gwneud ateb egwyddorol yn lle hynny.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Mae TryFrom yn awgrymu TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// addasiadau anffaeledig yn semantig cyfateb i drawsnewidiadau ffaeledig gyda math wall oes neb yn byw.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// MEWNFORIO CONCRETE
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// Y MATH GWALL DIM GWALL
////////////////////////////////////////////////////////////////////////////////

/// Mae'r math gwall am gamgymeriadau byth all ddigwydd.
///
/// Gan nad oes gan yr enwm hwn amrywiad, ni all gwerth o'r math hwn fodoli mewn gwirionedd.
/// Gall hyn fod yn ddefnyddiol i APIs generig sy'n defnyddio [`Result`] a parameterize math gwall, i nodi bod y canlyniad bob amser [`Ok`].
///
/// Er enghraifft, mae'r [`TryFrom`] trait (trosi bod ffurflenni a [`Result`]) Mae gweithredu cyffredinol ar gyfer pob math lle mae gweithredu [`Into`] gwrthwyneb yn bodoli.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # cydweddoldeb Future
///
/// Mae gan yr enwm hwn yr un rôl â [the `!`“never”type][never], sy'n ansefydlog yn y fersiwn hon o Rust.
/// Pan fydd `!` wedi'i sefydlogi, rydym yn bwriadu gwneud `Infallible` yn alias math iddo:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ac yn y pen draw dibrisio `Infallible`.
///
/// Fodd bynnag, mae un achos lle gellir defnyddio cystrawen `!` cyn sefydlogi `!` fel math llawn-llawn: yn safle math dychwelyd swyddogaeth.
/// Yn benodol, mae'n gweithrediadau posibl ar gyfer dau fath gwahanol pwyntydd swyddogaeth:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Gyda `Infallible` yn enwm, mae'r cod hwn yn ddilys.
/// Fodd bynnag, pan ddaw `Infallible` yn alias ar gyfer y never type, bydd y ddau `impl`s yn dechrau gorgyffwrdd ac felly byddant yn cael eu gwrthod gan reolau cydlyniant trait yr iaith.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}