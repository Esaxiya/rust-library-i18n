//! Modiwl ar gyfer gweithio gyda data a fenthycwyd.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait am fenthyca data.
///
/// Yn Rust, mae'n gyffredin darparu gwahanol gynrychioliadau o fath ar gyfer gwahanol achosion defnydd.
/// Er enghraifft, gellir dewis lleoliad storio a rheoli am werth yn benodol fel sy'n briodol ar gyfer defnydd penodol trwy fathau pwyntydd fel [`Box<T>`] neu [`Rc<T>`].
/// Y tu hwnt deunydd lapio generig hyn y gellir ei ddefnyddio gydag unrhyw fath, mae rhai mathau yn darparu agweddau opsiynol sy'n darparu functionality a allai fod yn gostus.
/// Enghraifft ar gyfer math o'r fath yw [`String`] sy'n ychwanegu'r gallu i ymestyn llinyn i'r [`str`] sylfaenol.
/// Mae hyn yn gofyn am gadw gwybodaeth ychwanegol yn ddiangen ar gyfer llinyn syml, na ellir ei symud.
///
/// Mae'r mathau hyn yn darparu mynediad at y data sylfaenol drwy gyfeiriadau at y math o ddata hynny.Maent yn dweud i fod 'benthyg fel' math hwnnw.
/// Er enghraifft, gellir benthyg [`Box<T>`] fel `T` tra gellir benthyg [`String`] fel `str`.
///
/// Mathau mynegi y gellir eu benthyg fel ryw fath `T` drwy weithredu `Borrow<T>`, gan ddarparu cyfeiriad at `T` yn ddull [`borrow`] y trait yn.Mae math yn rhad ac am ddim i fenthyca fel sawl math gwahanol.
/// Os yw'n dymuno fenthyca mutably fel y math-gan ganiatáu i'r data sylfaenol i gael ei addasu, gall gweithredu [`BorrowMut<T>`] ychwanegol.
///
/// At hynny, wrth ddarparu gweithrediadau ar gyfer traits ychwanegol, mae angen ystyried a ddylent ymddwyn yn union yr un fath â'r rhai o'r math sylfaenol o ganlyniad i weithredu fel cynrychiolaeth o'r math sylfaenol hwnnw.
/// Mae cod generig fel arfer yn defnyddio `Borrow<T>` pan fydd yn dibynnu ar ymddygiad union yr un fath â'r gweithrediadau trait ychwanegol hyn.
/// Mae'n debyg y bydd y traits hyn yn ymddangos fel trait bounds ychwanegol.
///
/// Yn benodol `Eq`, mae'n rhaid i `Ord` a `Hash` yn cyfateb i werthoedd a fenthycwyd ac yn eiddo: Dylai `x.borrow() == y.borrow()` rhoi'r un canlyniad ag `x == y`.
///
/// Os dim ond angen cod generig i waith ar gyfer pob math sy'n gallu darparu cyfeiriad at y math cysylltiedig `T`, mae'n aml yn well defnyddio [`AsRef<T>`] gan y gall mwy o fathau o weithredu yn ddiogel.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Fel casglu data, [`HashMap<K, V>`] yn berchen ar ddau allweddi a gwerthoedd.Os data gwirioneddol yr allwedd yn cael ei lapio mewn math rheoli o ryw fath, dylai, fodd bynnag, yn dal i fod yn bosibl i chwilio am werth gan ddefnyddio cyfeiriad at ddata yr allwedd yn.
/// Er enghraifft, os yw'r allwedd yn llinyn, yna mae'n cael ei storio yn debygol â'r map hash fel [`String`], tra dylai fod yn bosibl i chwilio gan ddefnyddio [`&str`][`str`].
/// Felly, mae angen i `insert` weithredu ar `String` tra bod angen i `get` allu defnyddio `&str`.
///
/// Wedi'i symleiddio ychydig, mae rhannau perthnasol `HashMap<K, V>` yn edrych fel hyn:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // caeau wedi'u hepgor
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Mae'r map hash cyfan yn generig dros fath allweddol `K`.Oherwydd bod yr allweddi hyn yn cael eu storio gyda'r map hash, mae'n rhaid i'r math hwn fod yn berchen ar ddata'r allwedd.
/// Wrth fewnosod pâr allwedd-werth, y map yn cael ei roi yn `K` ac anghenion o'r fath i ddod o hyd i'r bwced hash gywir ac yn gwirio a yw'r allwedd eisoes yn bresennol yn seiliedig ar y `K`.Felly, Mae'n gofyn `K: Hash + Eq`.
///
/// Wrth chwilio am werth ar y map, fodd bynnag, byddai gorfod darparu cyfeiriad at `K` fel yr allwedd i chwilio amdano yn gofyn am greu gwerth mor eiddo bob amser.
/// Ar gyfer allweddi llinyn, byddai hyn yn golygu bod angen creu gwerth `String` dim ond ar gyfer chwilio am achosion lle mai dim ond `str` sydd ar gael.
///
/// Yn lle hynny, mae'r dull `get` yn gyffredinol dros y math o ddata allweddol sy'n sail, a elwir `Q` yn y llofnod dull uchod.Mae'n datgan bod `K` benthyg fel `Q` trwy fynnu bod `K: Borrow<Q>`.
/// Trwy ofyn am `Q: Hash + Eq` hefyd, mae'n nodi'r gofyniad bod `K` a `Q` yn cael gweithrediadau o'r `Hash` a `Eq` traits sy'n cynhyrchu canlyniadau union yr un fath.
///
/// Mae gweithredu `get` yn dibynnu yn arbennig ar gweithrediadau unfath o `Hash` drwy benderfynu bwced hash yr allwedd drwy ffonio'r `Hash::hash` ar werth `Q` er ei mewnosod y allweddol yn seiliedig ar werth hash cyfrif o werth `K`.
///
///
/// O ganlyniad, mae'r gwyliau map hash os yw `K` lapio gwerth `Q` yn cynhyrchu hash wahanol `Q`.Er enghraifft, dychmygwch fod gennych fath sy'n wraps llinyn ond mae'n cymharu'n llythyrau ASCII anwybyddu eu hachos:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Gan fod angen i ddau werth cyfartal i gynhyrchu'r un gwerth hash, mae angen i'r o `Hash` weithredu i anwybyddu achos ASCII, hefyd:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// A all `CaseInsensitiveString` weithredu `Borrow<str>`?Mae'n sicr yn gallu darparu cyfeiriad at sleisen llinyn drwy ei llinyn sy'n eiddo i'r cynnwys.
/// Ond oherwydd ei yn wahanol weithredu `Hash`, mae'n ymddwyn yn wahanol o `str` ac ni ddylid felly, mewn gwirionedd, yn gweithredu `Borrow<str>`.
/// Os yw am ganiatáu i eraill gael mynediad i'r `str` sylfaenol, gall wneud hynny trwy `AsRef<str>` nad oes ganddo unrhyw ofynion ychwanegol.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutably benthyg o werth sy'n eiddo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait ar gyfer benthyca data.
///
/// Fel cydymaith i [`Borrow<T>`] mae'r trait hwn yn caniatáu i fath fenthyca fel math sylfaenol trwy ddarparu cyfeirnod symudol.
/// Gweler [`Borrow<T>`] i gael mwy o wybodaeth am fenthyca fel fath arall.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutably benthyg o werth sy'n eiddo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}