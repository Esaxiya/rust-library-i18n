//! Mathau sy'n pinio data i'w leoliad yn y cof.
//!
//! Weithiau mae'n ddefnyddiol cael gwrthrychau sy'n sicr o beidio â symud, yn yr ystyr nad yw eu lleoliad yn y cof yn newid, ac y gellir dibynnu arno felly.
//! Enghraifft wych o senario o'r fath fyddai adeiladu strwythurau hunan-gyfeiriadol, gan y bydd symud gwrthrych ag awgrymiadau iddo'i hun yn annilys, a allai achosi ymddygiad heb ei ddiffinio.
//!
//! Ar lefel uchel, mae [`Pin<P>`] yn sicrhau bod gan bwyntydd unrhyw bwyntydd math `P` leoliad sefydlog yn y cof, sy'n golygu na ellir ei symud i rywle arall ac ni ellir deall ei gof nes iddo gael ei ollwng.Rydyn ni'n dweud mai'r pwynt yw "pinned".Mae pethau'n mynd yn fwy cynnil wrth drafod mathau sy'n cyfuno pinned â data heb ei binio;[see below](#projections-and-structural-pinning) am ragor o fanylion.
//!
//! Yn ddiofyn, mae pob math yn Rust yn symudol.
//! Mae Rust yn caniatáu pasio pob math yn ôl-werth, ac mae mathau pwyntydd craff cyffredin fel [`Box<T>`] a `&mut T` yn caniatáu ailosod a symud y gwerthoedd sydd ynddynt: gallwch symud allan o [`Box<T>`], neu gallwch ddefnyddio [`mem::swap`].
//! [`Pin<P>`] yn lapio pwyntydd math `P`, felly [`Pin`]`<`[`Box`] `<T>>`yn gweithredu'n debyg iawn i reolaidd
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`yn cael ei ollwng, felly hefyd ei gynnwys, ac mae'r cof yn cael
//!
//! deallocated.Yn yr un modd, mae [`Pin`]`<&mut T>`yn debyg iawn i `&mut T`.Fodd bynnag, nid yw [`Pin<P>`] yn gadael i gleientiaid gael [`Box<T>`] neu `&mut T` i ddata wedi'u pinio, sy'n awgrymu na allwch ddefnyddio gweithrediadau fel [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` angen `&mut T`, ond ni allwn ei gael.
//!     // Rydym yn sownd, ni allwn gyfnewid cynnwys y cyfeiriadau hyn.
//!     // Gallem ddefnyddio `Pin::get_unchecked_mut`, ond mae hynny'n anniogel am reswm:
//!     // ni chaniateir i ni ei ddefnyddio ar gyfer symud pethau allan o'r `Pin`.
//! }
//! ```
//!
//! Mae'n werth ailadrodd nad yw [`Pin<P>`]*yn* newid y ffaith bod crynhoydd Rust yn ystyried pob math yn symudol.Mae [`mem::swap`] yn parhau i fod yn galwadadwy ar gyfer unrhyw `T`.Yn lle, mae [`Pin<P>`] yn atal rhai gwerthoedd * (y cyfeirir atynt gan awgrymiadau sydd wedi'u lapio yn [`Pin<P>`]) rhag cael eu symud trwy ei gwneud hi'n amhosibl galw dulliau sy'n gofyn am `&mut T` arnynt (fel [`mem::swap`]).
//!
//! [`Pin<P>`] gellir ei ddefnyddio i lapio unrhyw bwyntydd math `P`, ac o'r herwydd mae'n rhyngweithio â [`Deref`] a [`DerefMut`].[`Pin<P>`] lle dylid ystyried `P: Deref` fel "`P`-style pointer" i `P::Target` pinned-felly, a [`Pin`]`<`[`Box`] `<T>>`yn bwyntydd sy'n eiddo i `T` wedi'i binio, a [`Pin`] `<` [`Rc`]`<T>>`yn bwyntydd wedi'i gyfrif cyfeirnod at `T` wedi'i binio.
//! Er mwyn cywirdeb, mae [`Pin<P>`] yn dibynnu ar weithrediadau [`Deref`] a [`DerefMut`] i beidio â symud allan o'u paramedr `self`, a dim ond byth i ddychwelyd pwyntydd i ddata pinned pan gânt eu galw ar bwyntydd pinned.
//!
//! # `Unpin`
//!
//! Mae llawer o fathau bob amser yn symudol, hyd yn oed pan fyddant wedi'u pinio, oherwydd nid ydynt yn dibynnu ar gael cyfeiriad sefydlog.Mae hyn yn cynnwys yr holl fathau sylfaenol (fel [`bool`], [`i32`], a chyfeiriadau) yn ogystal â mathau sy'n cynnwys y mathau hyn yn unig.Mae mathau nad ydyn nhw'n poeni am binio yn gweithredu'r [`Unpin`] auto-trait, sy'n canslo effaith [`Pin<P>`].
//! Ar gyfer `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`a [`Box<T>`] yn gweithredu'n union yr un fath, fel y mae [`Pin`] `<&mut T>` a `&mut T`.
//!
//! Sylwch fod pinio a [`Unpin`] yn effeithio ar y math pwyntiedig i `P::Target` yn unig, nid ar y math pwyntydd `P` ei hun a gafodd ei lapio yn [`Pin<P>`].Er enghraifft, nid yw p'un a yw [`Box<T>`] yn [`Unpin`] ai peidio yn cael unrhyw effaith ar ymddygiad [`Pin`]`<`[`Box`] `<T>>`(yma, `T` yw'r math pwyntiedig).
//!
//! # Enghraifft: strwythur hunan-gyfeiriadol
//!
//! Cyn i ni fynd i fwy o fanylion i egluro'r gwarantau a'r dewisiadau sy'n gysylltiedig â `Pin<T>`, rydym yn trafod rhai enghreifftiau ar gyfer sut y gellir ei ddefnyddio.
//! Mae croeso i [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Mae hwn yn strwythur hunan-gyfeiriadol oherwydd bod y maes tafell yn pwyntio at y maes data.
//! // Ni allwn hysbysu'r casglwr am hynny gyda chyfeirnod arferol, gan na ellir disgrifio'r patrwm hwn gyda'r rheolau benthyca arferol.
//! //
//! // Yn lle, rydyn ni'n defnyddio pwyntydd amrwd, er bod un y gwyddys nad yw'n null, gan ein bod ni'n gwybod ei fod yn pwyntio at y llinyn.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Er mwyn sicrhau nad yw'r data'n symud pan fydd y swyddogaeth yn dychwelyd, rydyn ni'n ei roi yn y domen lle bydd yn aros am oes y gwrthrych, a'r unig ffordd i gael gafael arno fyddai trwy bwyntydd iddo.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // dim ond unwaith y bydd y data yn ei le y byddwn yn creu'r pwyntydd neu fel arall bydd wedi symud cyn i ni ddechrau hyd yn oed
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // rydym yn gwybod bod hyn yn ddiogel oherwydd nid yw addasu cae yn symud y strwythur cyfan
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Dylai'r pwyntydd bwyntio at y lleoliad cywir, cyn belled nad yw'r strwythur wedi symud.
//! //
//! // Yn y cyfamser, rydyn ni'n rhydd i symud y pwyntydd o gwmpas.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Gan nad yw ein math yn gweithredu Unpin, bydd hyn yn methu â llunio:
//! // gadewch mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Enghraifft: rhestr ymwthiol gysylltiedig â dwbl
//!
//! Mewn rhestr ymwthiol â chysylltiad dwbl, nid yw'r casgliad mewn gwirionedd yn dyrannu'r cof ar gyfer yr elfennau ei hun.
//! Mae'r dyraniad yn cael ei reoli gan y cleientiaid, a gall elfennau fyw ar ffrâm pentwr sy'n byw yn fyrrach nag y mae'r casgliad yn ei wneud.
//!
//! I wneud i'r gwaith hwn weithio, mae gan bob elfen awgrymiadau i'w rhagflaenydd a'i olynydd ar y rhestr.Dim ond pan gânt eu pinio y gellir ychwanegu elfennau, oherwydd byddai symud yr elfennau o gwmpas yn annilysu'r awgrymiadau.At hynny, bydd gweithredu [`Drop`] elfen rhestr gysylltiedig yn clwtio awgrymiadau ei ragflaenydd a'i olynydd i dynnu ei hun o'r rhestr.
//!
//! Yn hanfodol, mae'n rhaid i ni allu dibynnu ar [`drop`] yn cael ei alw.Pe bai modd deall elfen neu ei hannilysu fel arall heb ffonio [`drop`], byddai'r awgrymiadau i mewn iddi o'i elfennau cyfagos yn dod yn annilys, a fyddai'n torri'r strwythur data.
//!
//! Felly, mae pinio hefyd yn dod â gwarant cysylltiedig â [`gollwng`].
//!
//! # `Drop` guarantee
//!
//! Pwrpas pinio yw gallu dibynnu ar leoliad rhywfaint o ddata er cof.
//! I wneud i hyn weithio, nid dim ond symud y data sy'n gyfyngedig;Mae deallocating, repurposing, neu annilysu fel arall y cof a ddefnyddir i storio'r data yn gyfyngedig hefyd.
//! Yn bendant, ar gyfer data pinned mae'n rhaid i chi gynnal yr invariant na fydd *ei gof yn cael ei annilysu na'i ailgyflwyno o'r eiliad y bydd yn cael ei phinio tan pan fydd [`drop`] yn cael ei alw'n*.Dim ond unwaith y bydd [`drop`] yn dychwelyd neu panics, gellir ailddefnyddio'r cof.
//!
//! Gall cof fod yn "invalidated" trwy ddeallocation, ond hefyd trwy ddisodli [`Some(v)`] gan [`None`], neu ffonio [`Vec::set_len`] i "kill" rhai elfennau i ffwrdd o vector.Gellir ei ailgyflwyno trwy ddefnyddio [`ptr::write`] i'w drosysgrifennu heb alw'r dinistriwr yn gyntaf.Ni chaniateir dim o hyn ar gyfer data pinned heb ffonio [`drop`].
//!
//! Dyma'r union fath o warant bod angen i'r rhestr gysylltiedig ymwthiol o'r adran flaenorol weithredu'n gywir.
//!
//! Sylwch nad yw'r warant hon *yn golygu* nad yw'r cof yn gollwng!Mae'n dal yn hollol iawn i beidio byth â galw [`drop`] ar elfen wedi'i phinio (ee, gallwch chi ffonio [`mem::forget`] o hyd ar [`Pin`]`<`[`Box`] `<T>>`).Yn enghraifft y rhestr â chysylltiad dwbl, byddai'r elfen honno'n aros yn y rhestr yn unig.Fodd bynnag, ni chewch ryddhau nac ailddefnyddio'r storfa *heb ffonio [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Os yw'ch math yn defnyddio pinio (fel y ddwy enghraifft uchod), mae'n rhaid i chi fod yn ofalus wrth weithredu [`Drop`].Mae'r swyddogaeth [`drop`] yn cymryd `&mut self`, ond gelwir hyn yn *hyd yn oed os oedd eich math wedi'i binio o'r blaen*!Mae fel petai'r casglwr yn cael ei alw'n [`Pin::get_unchecked_mut`] yn awtomatig.
//!
//! Ni all hyn byth achosi problem mewn cod diogel oherwydd bod angen cod anniogel ar gyfer gweithredu math sy'n dibynnu ar binio, ond byddwch yn ymwybodol bod penderfynu defnyddio pinio yn eich math chi (er enghraifft trwy weithredu rhywfaint o weithrediad ar [`Pin`]`<&Self Mae gan`` neu [`Pin`]`<&mut Self>`) ganlyniadau i'ch gweithrediad [`Drop`] hefyd: pe gallai elfen o'ch math chi fod wedi'i phinio, rhaid i chi drin [`Drop`] fel rhywbeth sy'n cymryd [`Pin`] `<&mut yn ymhlyg Hunan>`.
//!
//!
//! Er enghraifft, fe allech chi weithredu `Drop` fel a ganlyn:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` yn iawn oherwydd rydyn ni'n gwybod nad yw'r gwerth hwn byth yn cael ei ddefnyddio eto ar ôl cael ei ollwng.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Mae'r cod gollwng gwirioneddol yn mynd yma.
//!         }
//!     }
//! }
//! ```
//!
//! Mae gan swyddogaeth `inner_drop` y math y dylai [`drop`]*ei gael*, felly mae hyn yn sicrhau nad ydych yn defnyddio `self`/`this` ar ddamwain mewn ffordd sy'n gwrthdaro â phinio.
//!
//! Ar ben hynny, os yw eich math yn `#[repr(packed)]`, bydd y casglwr yn symud caeau o gwmpas yn awtomatig i allu eu gollwng.Efallai y bydd hyd yn oed yn gwneud hynny ar gyfer caeau sy'n digwydd cael eu halinio'n ddigonol.O ganlyniad, ni allwch ddefnyddio pinio gyda math `#[repr(packed)]`.
//!
//! # Rhagamcanion a Phinio Strwythurol
//!
//! Wrth weithio gyda strwythurau wedi'u pinio, mae'r cwestiwn yn codi sut y gall rhywun gyrchu caeau'r strwythur hwnnw mewn dull sy'n cymryd dim ond [`Pin`]`<&mut Struct>`.
//! Y dull arferol yw ysgrifennu dulliau cynorthwyydd (a elwir yn *amcanestyniadau*) sy'n troi [`Pin`]`<&mut Struct>`yn gyfeiriad at y maes, ond pa fath ddylai'r cyfeirnod hwnnw fod?A yw'n [`Pin`]`<&mut Field>`neu `&mut Field`?
//! Mae'r un cwestiwn yn codi gyda meysydd `enum`, a hefyd wrth ystyried mathau container/wrapper fel [`Vec<T>`], [`Box<T>`], neu [`RefCell<T>`].
//! (Mae'r cwestiwn hwn yn berthnasol i gyfeiriadau treiddgar a chyfeiriadau a rennir, rydym yn defnyddio'r achos mwy cyffredin o gyfeiriadau treiddgar yma i'w darlunio.)
//!
//! Mae'n ymddangos mai awdur y strwythur data sydd i benderfynu a yw'r amcanestyniad pinned ar gyfer maes penodol yn troi [`Pin`]`<&mut Struct>`yn [`Pin`] `<&mut Field>` neu `&mut Field`.Fodd bynnag, mae rhai cyfyngiadau, a'r cyfyngiad pwysicaf yw *cysondeb*:
//! gellir rhagamcanu pob maes *naill ai* i gyfeirnod pinned,*neu* cael tynnu pinning fel rhan o'r amcanestyniad.
//! Os yw'r ddau yn cael eu gwneud ar gyfer yr un maes, mae'n debygol y bydd hynny'n ansicr!
//!
//! Fel awdur strwythur data, mae'n rhaid i chi benderfynu ar gyfer pob maes p'un a yw'n pinio "propagates" i'r maes hwn ai peidio.
//! Gelwir pinio sy'n lluosogi hefyd yn "structural", oherwydd ei fod yn dilyn strwythur y math.
//! Yn yr is-adrannau canlynol, rydym yn disgrifio'r ystyriaethau y mae'n rhaid eu gwneud ar gyfer y naill ddewis neu'r llall.
//!
//! ## Nid yw pinio *yn* strwythurol ar gyfer `field`
//!
//! Efallai ei fod yn ymddangos yn wrth-reddfol efallai na fydd maes strwythur wedi'i binio wedi'i binio, ond dyna'r dewis hawsaf mewn gwirionedd: os na chaiff [`Pin`]`<&mut Field>`ei greu, ni all unrhyw beth fynd o'i le!Felly, os penderfynwch nad oes pinio strwythurol mewn rhai caeau, y cyfan sy'n rhaid i chi ei sicrhau yw na fyddwch byth yn creu cyfeiriad pinned i'r maes hwnnw.
//!
//! Efallai y bydd gan gaeau heb binio strwythurol ddull taflunio sy'n troi [`Pin`]`<&mut Struct>`yn `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Mae hyn yn iawn oherwydd nid yw `field` byth yn cael ei ystyried yn bin.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Gallwch hefyd `impl Unpin for Struct`*hyd yn oed os nad yw* y math o `field` yn [`Unpin`].Nid yw'r hyn y mae'r math hwnnw'n ei feddwl am binio yn berthnasol pan na chaiff [`Pin`]`<&mut Field>`ei greu erioed.
//!
//! ## Mae pinio *yn* strwythurol ar gyfer `field`
//!
//! Y dewis arall yw penderfynu mai pinio yw "structural" ar gyfer `field`, sy'n golygu os yw'r strwythur wedi'i binio, felly hefyd y maes.
//!
//! Mae hyn yn caniatáu ysgrifennu tafluniad sy'n creu [`Pin`]`<&mut Field>`, a thrwy hynny dystio bod y maes wedi'i binio:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Mae hyn yn iawn oherwydd bod `field` wedi'i binio pan mae `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Fodd bynnag, daw ychydig o ofynion ychwanegol i binio strwythurol:
//!
//! 1. Rhaid i'r strwythur fod yn [`Unpin`] dim ond os yw'r holl feysydd strwythurol yn [`Unpin`].Dyma'r rhagosodiad, ond mae [`Unpin`] yn trait diogel, felly fel awdur y strwythur eich cyfrifoldeb chi *nid* yw ychwanegu rhywbeth fel `impl<T> Unpin for Struct<T>`.
//! (Sylwch fod angen cod anniogel ar gyfer ychwanegu gweithrediad taflunio, felly nid yw'r ffaith bod [`Unpin`] yn trait diogel yn torri'r egwyddor mai dim ond os ydych chi'n defnyddio `anniogel 'y mae'n rhaid i chi boeni am unrhyw un o hyn.)
//! 2. Rhaid i ddinistriwr y strwythur beidio â symud caeau strwythurol allan o'i ddadl.Dyma'r union bwynt a godwyd yn yr [previous section][drop-impl]: mae `drop` yn cymryd `&mut self`, ond mae'n bosibl bod y strwythur (ac felly ei gaeau) wedi'i binio o'r blaen.
//!     Mae'n rhaid i chi warantu na fyddwch chi'n symud cae y tu mewn i'ch gweithrediad [`Drop`].
//!     Yn benodol, fel yr esboniwyd yn flaenorol, mae hyn yn golygu bod yn rhaid i'ch strwythur * beidio â bod yn `#[repr(packed)]`.
//!     Gweler yr adran honno am sut i ysgrifennu [`drop`] mewn ffordd y gall y casglwr eich helpu i beidio â thorri pinio ar ddamwain.
//! 3. Rhaid i chi sicrhau eich bod yn cynnal yr [`Drop` guarantee][drop-guarantee]:
//!     unwaith y bydd eich strwythur wedi'i binio, ni chaiff y cof sy'n cynnwys y cynnwys ei drosysgrifo na'i ddeall heb alw dinistrwyr y cynnwys.
//!     Gall hyn fod yn anodd, fel y tystiwyd gan [`VecDeque<T>`]: gall dinistriwr [`VecDeque<T>`] fethu â galw [`drop`] ar bob elfen os yw un o'r dinistrwyr panics.Mae hyn yn torri gwarant [`Drop`], oherwydd gall arwain at ddeall elfennau heb i'w dinistriwr gael ei alw.(Nid oes gan [`VecDeque<T>`] unrhyw ragamcanion pinio, felly nid yw hyn yn achosi ansicrwydd.)
//! 4. Rhaid i chi beidio â chynnig unrhyw weithrediadau eraill a allai arwain at symud data allan o'r meysydd strwythurol pan fydd eich math wedi'i binio.Er enghraifft, os yw'r strwythur yn cynnwys [`Option<T>`] a bod gweithrediad tebyg i `gymryd` gyda math `fn(Pin<&mut Struct<T>>) -> Option<T>`, gellir defnyddio'r gweithrediad hwnnw i symud `T` allan o `Struct<T>` wedi'i binio-sy'n golygu na all pinio fod yn strwythurol i'r cae sy'n dal hwn data.
//!
//!     Am enghraifft fwy cymhleth o symud data allan o fath pinned, dychmygwch a oedd gan [`RefCell<T>`] ddull `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Yna gallem wneud y canlynol:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Mae hyn yn drychinebus, mae'n golygu y gallwn yn gyntaf binio cynnwys yr [`RefCell<T>`] (gan ddefnyddio `RefCell::get_pin_mut`) ac yna symud y cynnwys hwnnw gan ddefnyddio'r cyfeirnod symudol a gawsom yn ddiweddarach.
//!
//! ## Examples
//!
//! Ar gyfer math fel [`Vec<T>`], mae'r ddau bosibilrwydd (pinio strwythurol ai peidio) yn gwneud synnwyr.
//! Gallai [`Vec<T>`] gyda phinio strwythurol fod â dulliau `get_pin`/`get_pin_mut` i gael cyfeiriadau pinio at elfennau.Fodd bynnag, ni allai *ganiatáu* galw [`pop`][Vec::pop] ar [`Vec<T>`] wedi'i binio oherwydd byddai hynny'n symud y cynnwys (wedi'i binio'n strwythurol)!Ni allai ganiatáu [`push`][Vec::push] ychwaith, a allai ailddyrannu a thrwy hynny symud y cynnwys.
//!
//! Gallai [`Vec<T>`] heb binio strwythurol `impl<T> Unpin for Vec<T>`, oherwydd nid yw'r cynnwys byth yn cael ei binio ac mae'r [`Vec<T>`] ei hun yn iawn gyda chael ei symud hefyd.
//! Ar y pwynt hwnnw nid yw pinio yn cael unrhyw effaith ar y vector o gwbl.
//!
//! Yn y llyfrgell safonol, yn gyffredinol nid oes gan y mathau pwyntydd binio strwythurol, ac felly nid ydynt yn cynnig amcanestyniadau pinio.Dyma pam mae `Box<T>: Unpin` yn dal pob `T`.
//! Mae'n gwneud synnwyr i wneud hyn ar gyfer mathau pwyntydd, oherwydd nid yw symud yr `Box<T>` yn symud yr `T` mewn gwirionedd: gall yr [`Box<T>`] fod yn symudol (aka `Unpin`) hyd yn oed os nad yw'r `T`.Mewn gwirionedd, hyd yn oed [`Pin`]`<`[`Box`] `<T>Mae>`a [`Pin`] `<&mut T>` bob amser yn [`Unpin`] eu hunain, am yr un rheswm: mae eu cynnwys (yr `T`) wedi'i binio, ond gellir symud yr awgrymiadau eu hunain heb symud y data pinio.
//! Ar gyfer [`Box<T>`] a [`Pin`]`<`[`Box`] `<T>>`, mae p'un a yw'r cynnwys wedi'i binio yn gwbl annibynnol ar p'un a yw'r pwyntydd wedi'i binio, sy'n golygu nad yw pinio *yn* strwythurol.
//!
//! Wrth weithredu cyfunwr [`Future`], fel rheol bydd angen pinio strwythurol arnoch chi ar gyfer y futures nythog, gan fod angen i chi gael cyfeiriadau pinio atynt i ffonio [`poll`].
//! Ond os yw'ch cyfunwr yn cynnwys unrhyw ddata arall nad oes angen ei binio, gallwch wneud i'r meysydd hynny ddim yn strwythurol ac felly cyrchu atynt yn rhydd gyda chyfeirnod treiddgar hyd yn oed pan nad oes gennych ond [`Pin`]`<&mut Self>`(o'r fath fel yn eich gweithrediad [`poll`] eich hun).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Pwyntydd pinned.
///
/// Mae hwn yn lapiwr o amgylch math o bwyntydd sy'n golygu bod y pwyntydd "pin" hwnnw ei werth yn ei le, gan atal y gwerth y cyfeirir ato gan y pwyntydd hwnnw rhag cael ei symud oni bai ei fod yn gweithredu [`Unpin`].
///
///
/// *Gweler y ddogfennaeth [`pin` module] i gael esboniad o binio.*
///
/// [`pin` module]: self
///
// Note: mae'r `Clone` sy'n deillio isod yn achosi ansicrwydd gan ei bod yn bosibl ei weithredu
// `Clone` ar gyfer cyfeiriadau symudol.
// Gweler <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> am ragor o fanylion.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Nid yw'r gweithrediadau canlynol yn deillio er mwyn osgoi materion cadernid.
// `&self.pointer` ni ddylai fod yn hygyrch i weithrediadau trait di-ymddiried.
//
// Gweler <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> am ragor o fanylion.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Llunio `Pin<P>` newydd o amgylch pwyntydd i rywfaint o ddata o fath sy'n gweithredu [`Unpin`].
    ///
    /// Yn wahanol i `Pin::new_unchecked`, mae'r dull hwn yn ddiogel oherwydd bod y pwyntydd `P` yn dirywio i fath [`Unpin`], sy'n canslo'r gwarantau pinio.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // DIOGELWCH: y gwerth y cyfeirir ato yw `Unpin`, ac felly nid oes ganddo unrhyw ofynion
        // o amgylch pinio.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Dad-lapio'r `Pin<P>` hwn gan ddychwelyd y pwyntydd sylfaenol.
    ///
    /// Mae hyn yn ei gwneud yn ofynnol mai'r data y tu mewn i'r `Pin` hwn yw [`Unpin`] fel y gallwn anwybyddu'r invariants pinio wrth ei ddadlapio.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Llunio `Pin<P>` newydd o amgylch cyfeiriad at rywfaint o ddata o fath a all weithredu `Unpin` neu beidio.
    ///
    /// Os yw `pointer` yn dereferences i fath `Unpin`, dylid defnyddio `Pin::new` yn lle.
    ///
    /// # Safety
    ///
    /// Mae'r lluniwr hwn yn anniogel oherwydd ni allwn warantu bod y data y cyfeirir ato gan `pointer` wedi'i binio, sy'n golygu na fydd y data'n cael ei symud neu y bydd ei storfa'n annilys nes iddo gael ei ollwng.
    /// Os nad yw'r `Pin<P>` a adeiladwyd yn gwarantu bod y data y mae `P` yn pwyntio ato, mae hynny'n groes i'r contract API a gall arwain at ymddygiad heb ei ddiffinio mewn gweithrediadau (safe) diweddarach.
    ///
    /// Trwy ddefnyddio'r dull hwn, rydych chi'n gwneud promise ynghylch gweithrediadau `P::Deref` a `P::DerefMut`, os ydyn nhw'n bodoli.
    /// Yn bwysicaf oll, rhaid iddynt beidio â symud allan o'u dadleuon `self`: bydd `Pin::as_mut` a `Pin::as_ref` yn galw `DerefMut::deref_mut` a `Deref::deref`*ar y pwyntydd pinned* ac yn disgwyl i'r dulliau hyn gynnal yr invariants pinio.
    /// Ar ben hynny, trwy ffonio'r dull hwn rydych chi'n promise na fydd y cyfeiriadau `P` cyfeiriol atynt yn cael eu symud allan eto;yn benodol, rhaid iddo beidio â bod yn bosibl cael `&mut P::Target` ac yna symud allan o'r cyfeirnod hwnnw (gan ddefnyddio, er enghraifft [`mem::swap`]).
    ///
    ///
    /// Er enghraifft, mae ffonio `Pin::new_unchecked` ar `&'a mut T` yn anniogel oherwydd er eich bod chi'n gallu ei binio am yr oes benodol `'a`, nid oes gennych unrhyw reolaeth dros p'un a yw'n cael ei phinio unwaith y daw `'a` i ben:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dylai hyn olygu na all yr awgrym `a` fyth symud eto.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Newidiodd cyfeiriad `a` i slot pentwr `b`, felly symudodd `a` er ein bod wedi ei bigo o'r blaen!Rydym wedi torri'r contract pinio API.
    /////
    /// }
    /// ```
    ///
    /// Rhaid i werth, ar ôl ei binio, aros yn binacl am byth (oni bai bod ei fath yn gweithredu `Unpin`).
    ///
    /// Yn yr un modd, mae galw `Pin::new_unchecked` ar `Rc<T>` yn anniogel oherwydd gallai fod arallenwau i'r un data nad ydynt yn ddarostyngedig i'r cyfyngiadau pinio:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dylai hyn olygu na all yr awgrym fyth symud eto.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Nawr, pe bai `x` yr unig gyfeirnod, mae gennym gyfeiriad treiddgar at ddata y gwnaethom ei binio uchod, y gallem ei ddefnyddio i'w symud fel y gwelsom yn yr enghraifft flaenorol.
    ///     // Rydym wedi torri'r contract pinio API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Yn cael cyfeirnod pinned wedi'i rannu o'r pwyntydd pinned hwn.
    ///
    /// Mae hwn yn ddull generig i fynd o `&Pin<Pointer<T>>` i `Pin<&T>`.
    /// Mae'n ddiogel oherwydd, fel rhan o gontract `Pin::new_unchecked`, ni all yr awgrym symud ar ôl i `Pin<Pointer<T>>` gael ei greu.
    ///
    /// "Malicious" Yn yr un modd, mae contract `Pin::new_unchecked` yn diystyru gweithredu `Pointer::Deref`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // DIOGELWCH: gweler y ddogfennaeth ar y swyddogaeth hon
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Dad-lapio'r `Pin<P>` hwn gan ddychwelyd y pwyntydd sylfaenol.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel.Rhaid i chi warantu y byddwch yn parhau i drin y pwyntydd `P` fel pinned ar ôl i chi alw'r swyddogaeth hon, fel y gellir cadarnhau'r invariants ar y math `Pin`.
    /// Os nad yw'r cod sy'n defnyddio'r `P` sy'n deillio o hyn yn parhau i gynnal yr invariants pinio sy'n groes i'r contract API a gallai arwain at ymddygiad heb ei ddiffinio mewn gweithrediadau (safe) diweddarach.
    ///
    ///
    /// Os yw'r data sylfaenol yn [`Unpin`], dylid defnyddio [`Pin::into_inner`] yn lle.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Cael cyfeiriad symudol pinned o'r pwyntydd pinned hwn.
    ///
    /// Mae hwn yn ddull generig i fynd o `&mut Pin<Pointer<T>>` i `Pin<&mut T>`.
    /// Mae'n ddiogel oherwydd, fel rhan o gontract `Pin::new_unchecked`, ni all yr awgrym symud ar ôl i `Pin<Pointer<T>>` gael ei greu.
    ///
    /// "Malicious" Yn yr un modd, mae contract `Pin::new_unchecked` yn diystyru gweithredu `Pointer::DerefMut`.
    ///
    /// Mae'r dull hwn yn ddefnyddiol wrth wneud galwadau lluosog i swyddogaethau sy'n defnyddio'r math pinned.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // gwneud rhywbeth
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` yn defnyddio `self`, felly ailgychwynwch yr `Pin<&mut Self>` trwy `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // DIOGELWCH: gweler y ddogfennaeth ar y swyddogaeth hon
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Yn neilltuo gwerth newydd i'r cof y tu ôl i'r cyfeirnod pinned.
    ///
    /// Mae hyn yn trosysgrifo data wedi'i bigo, ond mae hynny'n iawn: mae ei ddinistriwr yn cael ei redeg cyn cael ei drosysgrifo, felly ni chaiff unrhyw warant pinio ei thorri.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Yn adeiladu pin newydd trwy fapio'r gwerth mewnol.
    ///
    /// Er enghraifft, pe byddech am gael `Pin` o gae rhywbeth, fe allech chi ddefnyddio hwn i gael mynediad i'r maes hwnnw mewn un llinell o god.
    /// Fodd bynnag, mae yna sawl gotchas gyda'r "pinning projections" hyn;
    /// gweler y ddogfennaeth [`pin` module] i gael mwy o fanylion am y pwnc hwnnw.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel.
    /// Rhaid i chi warantu na fydd y data y byddwch chi'n ei ddychwelyd yn symud cyn belled nad yw gwerth y ddadl yn symud (er enghraifft, oherwydd ei fod yn un o feysydd y gwerth hwnnw), a hefyd nad ydych chi'n symud allan o'r ddadl rydych chi'n ei derbyn. y swyddogaeth fewnol.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // DIOGELWCH: rhaid i'r contract diogelwch ar gyfer `new_unchecked` fod
        // gadarnhau gan y galwr.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Cael cyfeirnod a rennir allan o pin.
    ///
    /// Mae hyn yn ddiogel oherwydd nid yw'n bosibl symud allan o gyfeirnod a rennir.
    /// Efallai ei bod yn ymddangos bod problem yma gyda chyfnewidioldeb mewnol: mewn gwirionedd, mae'n * bosibl symud `T` allan o `&RefCell<T>`.
    /// Fodd bynnag, nid yw hon yn broblem cyn belled nad oes `Pin<&T>` yn pwyntio at yr un data hefyd, ac nid yw `RefCell<T>` yn gadael ichi greu cyfeiriad pinned at ei gynnwys.
    ///
    /// Gweler y drafodaeth ar ["pinning projections"] am fanylion pellach.
    ///
    /// Note: Mae `Pin` hefyd yn gweithredu `Deref` i'r targed, y gellir ei ddefnyddio i gael mynediad i'r gwerth mewnol.
    /// Fodd bynnag, dim ond cyfeirnod sy'n byw cyhyd â benthyg yr `Pin` y mae `Deref` yn ei ddarparu, nid oes yr `Pin` ei hun.
    /// Mae'r dull hwn yn caniatáu troi'r `Pin` yn gyfeirnod sydd â'r un oes â'r `Pin` gwreiddiol.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Trosi'r `Pin<&mut T>` hwn yn `Pin<&T>` gyda'r un oes.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Yn cael cyfeiriad cyfnewidiol at y data y tu mewn i'r `Pin` hwn.
    ///
    /// Mae hyn yn gofyn bod y data y tu mewn i'r `Pin` hwn yn `Unpin`.
    ///
    /// Note: Mae `Pin` hefyd yn gweithredu `DerefMut` i'r data, y gellir ei ddefnyddio i gael mynediad i'r gwerth mewnol.
    /// Fodd bynnag, dim ond cyfeirnod sy'n byw cyhyd â benthyg yr `Pin` y mae `DerefMut` yn ei ddarparu, nid oes yr `Pin` ei hun.
    ///
    /// Mae'r dull hwn yn caniatáu troi'r `Pin` yn gyfeirnod sydd â'r un oes â'r `Pin` gwreiddiol.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Yn cael cyfeiriad cyfnewidiol at y data y tu mewn i'r `Pin` hwn.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel.
    /// Rhaid i chi warantu na fyddwch chi byth yn symud y data allan o'r cyfeirnod symudol y byddwch chi'n ei dderbyn pan fyddwch chi'n galw'r swyddogaeth hon, fel bod modd cadarnhau'r invariants ar y math `Pin`.
    ///
    ///
    /// Os yw'r data sylfaenol yn `Unpin`, dylid defnyddio `Pin::get_mut` yn lle.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Adeiladu pin newydd trwy fapio'r gwerth mewnol.
    ///
    /// Er enghraifft, pe byddech am gael `Pin` o gae rhywbeth, fe allech chi ddefnyddio hwn i gael mynediad i'r maes hwnnw mewn un llinell o god.
    /// Fodd bynnag, mae yna sawl gotchas gyda'r "pinning projections" hyn;
    /// gweler y ddogfennaeth [`pin` module] i gael mwy o fanylion am y pwnc hwnnw.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel.
    /// Rhaid i chi warantu na fydd y data y byddwch chi'n ei ddychwelyd yn symud cyn belled nad yw gwerth y ddadl yn symud (er enghraifft, oherwydd ei fod yn un o feysydd y gwerth hwnnw), a hefyd nad ydych chi'n symud allan o'r ddadl rydych chi'n ei derbyn. y swyddogaeth fewnol.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // DIOGELWCH: mae'r galwr yn gyfrifol am beidio â symud y
        // gwerth allan o'r cyfeirnod hwn.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // DIOGELWCH: gan y gwarantir na fydd gwerth `this`
        // wedi cael ei symud allan, mae'r alwad hon i `new_unchecked` yn ddiogel.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Sicrhewch gyfeirnod pinned o gyfeirnod statig.
    ///
    /// Mae hyn yn ddiogel, oherwydd benthycir `T` am oes `'static`, nad yw byth yn dod i ben.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // DIOGELWCH: Mae'r 'benthyciad statig yn gwarantu na fydd y data
        // moved/invalidated nes iddo gael ei ollwng (sydd byth).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Sicrhewch gyfeirnod symudol pinned o gyfeirnod statig mutable.
    ///
    /// Mae hyn yn ddiogel, oherwydd benthycir `T` am oes `'static`, nad yw byth yn dod i ben.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // DIOGELWCH: Mae'r 'benthyciad statig yn gwarantu na fydd y data
        // moved/invalidated nes iddo gael ei ollwng (sydd byth).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: mae hyn yn golygu bod unrhyw impl o `CoerceUnsized` sy'n caniatáu gorfodi
// mae math sy'n gorfodi `Deref<Target=impl !Unpin>` i fath sy'n impls `Deref<Target=Unpin>` yn ddi-sail.
// Fodd bynnag, mae'n debyg y byddai unrhyw impl o'r fath yn ansicr am resymau eraill, felly mae'n rhaid i ni gymryd gofal i beidio â chaniatáu i impls o'r fath lanio yn std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}