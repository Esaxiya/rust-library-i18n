//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Y pwynt cod dilys uchaf y gall `char` gael.
    ///
    /// A `char` yn [Unicode Scalar Value], a oedd yn golygu ei fod yn [Code Point], ond rhai yn unig o fewn amrywiaeth penodol.
    /// `MAX` yw'r pwynt cod dilys uchaf sy'n [Unicode Scalar Value] dilys.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () cael ei ddefnyddio yn Unicode i gynrychioli gwall datgodio.
    ///
    /// Gall ddigwydd, er enghraifft, wrth roi beitiau UTF-8 heb eu ffurfio i [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Mae fersiwn o'r [Unicode](http://www.unicode.org/) bod y rhannau Unicode dulliau `char` a `str` yn seiliedig ar.
    ///
    /// Mae fersiynau newydd o Unicode yn cael eu rhyddhau'n rheolaidd ac wedi hynny mae'r holl ddulliau yn y llyfrgell safonol yn dibynnu ar Unicode yn cael eu diweddaru.
    /// Felly ymddygiad rhai dulliau `char` a `str` a gwerth cyson hwn yn newid dros amser.
    /// Nid yw hyn * yn cael ei ystyried yn newid sy'n torri.
    ///
    /// Esbonnir y cynllun fersiwn rhifo yn [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Creu iterator dros UTF-16 hamgodio pwyntiau cod yn `iter`, gan ddychwelyd surrogates heb eu paru fel `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Gall decoder lossy ar gael drwy ddisodli canlyniadau `Err` â chymeriad newydd:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Trosi `u32` i `char`.
    ///
    /// Sylwch fod pob `torgoch 'yn ddilys [` u32`] s, a gellir eu bwrw i un â nhw
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Fodd bynnag, nid yw'r gwrthwyneb yn wir: nid yw pob dilys [`u32`] yn ddilys.
    /// `from_u32()` yn dychwelyd `None` os nad yw'r mewnbwn yn werth dilys ar gyfer `char`.
    ///
    /// Am fersiwn anniogel o'r swyddogaeth hon sy'n anwybyddu archwiliadau hyn, gweler [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Dychwelyd `None` pan nad yw'r mewnbwn yn `char` dilys:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Trosi `u32` i `char`, gan anwybyddu dilysrwydd.
    ///
    /// Sylwch fod pob `torgoch 'yn ddilys [` u32`] s, a gellir eu bwrw i un â nhw
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Fodd bynnag, nid yw'r gwrthwyneb yn wir: nid yw pob dilys [`u32`] yn ddilys.
    /// `from_u32_unchecked()` yn anwybyddu hyn, ac yn cael ei gastio'n ddall i `char`, gan greu un annilys o bosibl.
    ///
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel, gan y gallai adeiladu gwerthoedd `char` annilys.
    ///
    /// Am fersiwn ddiogel o'r swyddogaeth hon, gweler y swyddogaeth [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // DIOGELWCH: mae'n rhaid i'r contract ddiogelwch yn cael ei gadarnhau gan y galwr.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Trosi digid yn y radix a roddir i `char`.
    ///
    /// Weithiau gelwir 'radix' yma hefyd yn 'base'.
    /// Mae radix o ddau yn nodi rhif deuaidd, mae radix o ddeg, degol, a radix un ar bymtheg, hecsadegol, er mwyn rhoi rhywfaint o werthoedd cyffredin.
    ///
    /// radices mympwyol yn cael eu cefnogi.
    ///
    /// `from_digit()` Bydd yn dychwelyd `None` os nad yw'r cyfraniad yn digid yn y radix roddir.
    ///
    /// # Panics
    ///
    /// Panics os rhoddir radix mwy na 36 iddo.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Degol 11 yn un digid yn y sylfaen 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Dychwelyd `None` pan nad yw'r mewnbwn yn ddigid:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Pasio radix mawr, gan achosi panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Gwiriadau os yw `char` yn digid yn y radix roddir.
    ///
    /// Weithiau gelwir 'radix' yma hefyd yn 'base'.
    /// Mae radix o ddau yn nodi rhif deuaidd, mae radix o ddeg, degol, a radix un ar bymtheg, hecsadegol, er mwyn rhoi rhywfaint o werthoedd cyffredin.
    ///
    /// radices mympwyol yn cael eu cefnogi.
    ///
    /// O'i gymharu â [`is_numeric()`], mae'r swyddogaeth hon ond yn cydnabod y cymeriadau `0-9`, `a-z` a `A-Z`.
    ///
    /// 'Digit' Diffinnir i fod dim ond y nodau canlynol:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// I gael dealltwriaeth fwy cynhwysfawr o 'digit', gweler [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics os rhoddir radix mwy na 36 iddo.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Pasio radix mawr, gan achosi panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Trosi `char` i digid yn y radix roddir.
    ///
    /// Weithiau gelwir 'radix' yma hefyd yn 'base'.
    /// Mae radix o ddau yn nodi rhif deuaidd, mae radix o ddeg, degol, a radix un ar bymtheg, hecsadegol, er mwyn rhoi rhywfaint o werthoedd cyffredin.
    ///
    /// radices mympwyol yn cael eu cefnogi.
    ///
    /// 'Digit' Diffinnir i fod dim ond y nodau canlynol:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Yn dychwelyd `None` os nad yw'r `char` yn cyfeirio at ddigid yn y radix a roddir.
    ///
    /// # Panics
    ///
    /// Panics os rhoddir radix mwy na 36 iddo.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Mae pasio di-ddigid yn arwain at fethiant:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Pasio radix mawr, gan achosi panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // y cod wedi ei rhannu i fyny yma i wella cyflymder gweithredu ar gyfer achosion lle mae'r `radix` yn gyson a 10 neu lai
        //
        let val = if likely(radix <= 10) {
            // Os nad yw digid, bydd y nifer yn fwy na radix yn cael ei greu.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Yn dychwelyd ailadroddwr sy'n esgor ar ddihangfa hecsadegol Unicode cymeriad fel `char`s.
    ///
    /// Bydd hyn yn dianc cymeriadau gyda chystrawen Rust y ffurflen `\u{NNNNNN}` lle `NNNNNN` yn gynrychiolaeth hecsadegol.
    ///
    ///
    /// # Examples
    ///
    /// Fel ailadroddwr:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gan ddefnyddio `println!` yn uniongyrchol:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Mae'r ddau yn cyfateb i:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Defnyddio `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // mae or-ing 1 yn sicrhau bod y cod ar gyfer c==0 yn cyfrif y dylid argraffu un digid a (sydd yr un peth) yn osgoi'r gorlif (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // y mynegai y digid hecs mwyaf arwyddocaol
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Mae fersiwn estynedig o `escape_debug` bod optionally hawlen Dianc Estynedig pwynt cod graffem.
    /// Mae hyn yn ein galluogi i fformadu cymeriadau fel nonspacing marciau gwell pan fyddant yn ar ddechrau llinyn.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Ffurflenni mae iterator sy'n cynhyrchu cod dianc llythrennol o gymeriad fel `char`s.
    ///
    /// Bydd hyn yn dianc rhag y cymeriadau tebyg i weithrediadau `Debug` `str` neu `char`.
    ///
    ///
    /// # Examples
    ///
    /// Fel ailadroddwr:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gan ddefnyddio `println!` yn uniongyrchol:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Mae'r ddau yn cyfateb i:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Defnyddio `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Ffurflenni mae iterator sy'n cynhyrchu cod dianc llythrennol o gymeriad fel `char`s.
    ///
    /// Dewisir y rhagosodiad gyda gogwydd tuag at gynhyrchu llythrennau sy'n gyfreithiol mewn amrywiaeth o ieithoedd, gan gynnwys C++ 11 ac ieithoedd tebyg i deulu C.
    /// Yr union reolau yw:
    ///
    /// * Tab yn dianc fel `\t`.
    /// * Dihangir dychwelyd cerbyd fel `\r`.
    /// * bwydo llinell yn dianc fel `\n`.
    /// * dyfyniad sengl dianc fel `\'`.
    /// * Mae dyfynbris dwbl yn cael ei ddianc fel `\"`.
    /// * Mae Backslash yn cael ei ddianc fel `\\`.
    /// * Nid yw unrhyw gymeriad yn yr ystod 'ASCII argraffadwy' `0x20` .. `0x7e` cynhwysol yn cael ei ddianc.
    /// * Rhoddir dianc hecsadegol Unicode i bob cymeriad arall;gweld [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Fel ailadroddwr:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gan ddefnyddio `println!` yn uniongyrchol:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Mae'r ddau yn cyfateb i:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Defnyddio `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Dychwelyd y nifer o bytes byddai angen `char` hwn os hamgodio yn UTF-8.
    ///
    /// Mae'r nifer honno o bytes bob amser rhwng 1 a 4, yn gynhwysol.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Mae'r math `&str` yn gwarantu mai UTF-8 yw ei gynnwys, ac felly gallwn gymharu'r hyd y byddai'n ei gymryd pe bai pob pwynt cod yn cael ei gynrychioli fel `char` vs yn yr `&str` ei hun:
    ///
    ///
    /// ```
    /// // fel chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // gall y ddau cael eu cynrychioli fel tri bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // fel &str, dau rhain yn cael eu hamgodio yn UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // gallwn weld eu bod yn cymryd chwe bytes cyfanswm ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... yn union fel y &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Dychwelyd y nifer o unedau cod 16-bit byddai angen `char` hwn os hamgodio yn UTF-16.
    ///
    ///
    /// Gweler y ddogfennaeth ar gyfer [`len_utf8()`] i gael mwy o eglurhad o'r cysyniad hwn.
    /// Mae'r swyddogaeth hon yn ddrych, ond ar gyfer UTF-16 yn lle UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Amgodio'r cymeriad hwn fel UTF-8 mewn i'r byffer beit a ddarperir, ac yna dychwelyd y subslice y byffer sy'n cynnwys y cymeriad amgodio.
    ///
    ///
    /// # Panics
    ///
    /// Panics os nad yw'r byffer yn ddigon mawr.
    /// Mae byffer o hyd pedwar yn ddigon mawr i amgodio unrhyw `char`.
    ///
    /// # Examples
    ///
    /// Yn y ddwy enghraifft hyn, mae 'ß' yn cymryd dau beit i'w amgodio.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Mae byffer sy'n rhy fach:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // DIOGELWCH: Nid `char` yn dirprwyol, felly mae hyn yn ddilys UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Amgodio'r cymeriad hwn fel UTF-16 mewn i'r byffer `u16` a ddarperir, ac yna dychwelyd y subslice y byffer sy'n cynnwys y cymeriad amgodio.
    ///
    ///
    /// # Panics
    ///
    /// Panics os nad yw'r byffer yn ddigon mawr.
    /// Mae byffer o hyd 2 yn ddigon mawr i amgodio unrhyw `char`.
    ///
    /// # Examples
    ///
    /// Yn y ddwy enghraifft hyn, mae '𝕊' yn cymryd dau `u16` i'w hamgodio.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Mae byffer sy'n rhy fach:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Yn dychwelyd `true` os oes gan yr `char` hwn yr eiddo `Alphabetic`.
    ///
    /// `Alphabetic` disgrifir ym Mhennod 4 (Priodweddau Cymeriad) yr [Unicode Standard] a'i nodi yn yr [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // mae cariad yn llawer o bethau, ond nid yw'n wyddor
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Ffurflenni `true` os `char` hwn gan yr eiddo `Lowercase`.
    ///
    /// `Lowercase` disgrifir ym Mhennod 4 (Priodweddau Cymeriad) yr [Unicode Standard] a'i nodi yn yr [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Nid oes achos i'r gwahanol sgriptiau ac atalnodi Tsieineaidd, ac felly:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Ffurflenni `true` os `char` hwn gan yr eiddo `Uppercase`.
    ///
    /// `Uppercase` disgrifir ym Mhennod 4 (Priodweddau Cymeriad) yr [Unicode Standard] a'i nodi yn yr [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Nid oes achos i'r gwahanol sgriptiau ac atalnodi Tsieineaidd, ac felly:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Yn dychwelyd `true` os oes gan yr `char` hwn yr eiddo `White_Space`.
    ///
    /// `White_Space` wedi'i nodi yn yr [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // lle nad yw'n torri
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Yn dychwelyd `true` os yw'r `char` hwn yn bodloni naill ai [`is_alphabetic()`] neu [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Ffurflenni `true` os `char` hon yr categori cyffredinol ar gyfer godau rheoli.
    ///
    /// Codau Rheoli (pwyntiau Cod gyda'r categori cyffredinol `Cc`) yn cael eu disgrifio ym Mhennod (Eiddo Cymeriad) 4 o'r [Unicode Standard] a nodir yn y [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // U + 009C, Terminator STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Ffurflenni `true` os `char` hwn gan yr eiddo `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` yn cael ei ddisgrifio yn [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] a'i nodi yn yr [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Ffurflenni `true` os `char` mae hyn yn un o'r categorïau cyffredinol ar gyfer rhifau.
    ///
    /// Mae'r categorïau cyffredinol ar gyfer rhifau (`Nd` ar gyfer digidau degol, `Nl` ar gyfer nodau rhifol tebyg i lythyren, ac `No` ar gyfer nodau rhifol eraill) wedi'u nodi yn yr [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Ffurflenni mae iterator sy'n cynhyrchu y mapio llythrennau bach o `char` hwn fel un neu fwy o
    /// `char`s.
    ///
    /// Os nad oes gan `char` hwn mapio llythrennau bach, mae'r iterator cynnyrch yr un fath `char`.
    ///
    /// Os oes gan `char` hon yn mapio llythrennau bach un-i-un a roddir gan y [Unicode Character Database][ucd] [`UnicodeData.txt`], mae'r cynnyrch iterator y `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Os yw hyn yn gofyn `char` ystyriaethau arbennig (ee lluosog `char`s) y iterator cynnyrch y`char` (au) a roddir gan [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Mae'r llawdriniaeth yn cyflawni mapio diamod heb deilwra.Hynny yw, trosi yn annibynnol ar y cyd-destun ac iaith.
    ///
    /// Yn yr [Unicode Standard], mae Pennod 4 (Priodweddau Cymeriad) yn trafod mapio achosion yn gyffredinol ac mae Pennod 3 (Conformance) yn trafod yr algorithm diofyn ar gyfer trosi achosion.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Fel ailadroddwr:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gan ddefnyddio `println!` yn uniongyrchol:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Mae'r ddau yn cyfateb i:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Defnyddio `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Weithiau mae'r canlyniad yn fwy nag un cymeriad:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Mae cymeriadau nad oes ganddyn nhw uwchgynhadledd a llythrennau bach yn trosi'n nhw eu hunain.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Ffurflenni mae iterator sy'n cynhyrchu mapio priflythyren o `char` hwn fel un neu fwy o
    /// `char`s.
    ///
    /// Os nad oes gan `char` hwn mapio priflythyren, mae'r iterator cynnyrch yr un fath `char`.
    ///
    /// Os oes gan `char` hon yn mapio priflythyren un-i-un a roddir gan y [Unicode Character Database][ucd] [`UnicodeData.txt`], mae'r cynnyrch iterator y `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Os yw hyn yn gofyn `char` ystyriaethau arbennig (ee lluosog `char`s) y iterator cynnyrch y`char` (au) a roddir gan [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Mae'r llawdriniaeth yn cyflawni mapio diamod heb deilwra.Hynny yw, trosi yn annibynnol ar y cyd-destun ac iaith.
    ///
    /// Yn yr [Unicode Standard], mae Pennod 4 (Priodweddau Cymeriad) yn trafod mapio achosion yn gyffredinol ac mae Pennod 3 (Conformance) yn trafod yr algorithm diofyn ar gyfer trosi achosion.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Fel ailadroddwr:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gan ddefnyddio `println!` yn uniongyrchol:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Mae'r ddau yn cyfateb i:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Defnyddio `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Weithiau mae'r canlyniad yn fwy nag un cymeriad:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Mae cymeriadau nad oes ganddyn nhw uwchgynhadledd a llythrennau bach yn trosi'n nhw eu hunain.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nodyn ar locale
    ///
    /// Yn Twrceg, mae pum ffurflen yn hytrach na dau cyfateb i 'i' mewn Lladin:
    ///
    /// * 'Dotless': I/ı, ï ysgrifenedig weithiau
    /// * 'Dotted': İ/i
    ///
    /// Noder bod y llythrennau bach frith 'i' yn yr un fath â'r Lladin.felly:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Mae gwerth `upper_i` yma yn dibynnu ar iaith y testun: os ydym yn `en-US`, dylai fod yn `"I"`, ond os ydym yn `tr_TR`, dylai fod yn `"İ"`.
    /// `to_uppercase()` nid yw'n cymryd hyn i ystyriaeth, ac felly:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// yn dal ar draws ieithoedd.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Yn gwirio a yw'r gwerth o fewn ystod ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Gwneud copi o werth yn ei ASCII achos cyfatebol uchaf.
    ///
    /// Mae llythyrau ASCII 'a' i 'z' wedi'u mapio i 'A' i 'Z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I priflythrennau gwerth yn-waith, defnyddiwch [`make_ascii_uppercase()`].
    ///
    /// I priflythrennau cymeriadau ASCII yn ogystal â chymeriadau nad ydynt yn ASCII, defnyddiwch [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Gwneud copi o werth yn ei ASCII cyfateb llythrennau bach.
    ///
    /// Mae llythyrau ASCII 'A' i 'Z' wedi'u mapio i 'a' i 'z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I lythrennau bach gwerth yn-waith, defnyddiwch [`make_ascii_lowercase()`].
    ///
    /// I lythrennau bach nodau ASCII yn ychwanegol at nodau nad ydynt yn ASCII, defnyddiwch [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Gwirio bod dau werth yn cyfateb yn achos ansensitif ASCII.
    ///
    /// Cyfwerth â `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Yn trosi'r math hwn i'w gyfwerth ag achos uchaf ASCII yn ei le.
    ///
    /// Mae llythyrau ASCII 'a' i 'z' wedi'u mapio i 'A' i 'Z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I ddychwelyd gwerth uppercased newydd heb addasu un presennol, defnyddiwch [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Trosi math hwn i'w ASCII llythrennau bach cyfatebol yn-waith.
    ///
    /// Mae llythyrau ASCII 'A' i 'Z' wedi'u mapio i 'a' i 'z', ond mae llythyrau nad ydynt yn ASCII yn ddigyfnewid.
    ///
    /// I ddychwelyd gwerth is newydd heb addasu'r un presennol, defnyddiwch [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Yn gwirio a yw'r gwerth yn gymeriad wyddor ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', neu
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Yn gwirio a yw'r gwerth yn gymeriad uchaf ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Yn gwirio a yw'r gwerth yn gymeriad llythrennau bach ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Yn gwirio a yw'r gwerth yn gymeriad alffaniwmerig ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', neu
    /// - U + 0061 'a' ..=U + 007A 'z', neu
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Yn gwirio a yw'r gwerth yn ddigid degol ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Gwiriadau os yw gwerth yn hecsadegol digid ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', neu
    /// - U + 0041 'A' ..=U + 0046 'F', neu
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Yn gwirio a yw'r gwerth yn gymeriad atalnodi ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, neu
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, neu
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, neu
    /// - U + 007b ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Gwiriadau os yw gwerth yn gymeriad graffig ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Gwiriadau os yw gwerth yn gymeriad gofod gwyn ASCII:
    /// U + 0020 GOFOD, U + 0009 TAB HORIZONTAL, BWYD LLINELL U + 000A, BWYD FFURFLEN U + 000C, neu DYCHWELYD GOFAL U + 000D.
    ///
    /// Mae Rust yn defnyddio [definition of ASCII whitespace][infra-aw] WhatWG Infra Standard.Mae yna nifer o ddiffiniadau eraill yn cael eu defnyddio o led.
    /// Er enghraifft, mae [the POSIX locale][pct] yn cynnwys TAB FERTICAL U + 000B yn ogystal â'r holl nodau uchod, ond-o'r un fanyleb- mae [y rheol ddiofyn ar gyfer "field splitting" yn y Bourne shell][bfs] yn ystyried *yn unig* GOFOD, TAB HORIZONTAL, a BWYD ANIFEILIAID LLINELL fel whitespace.
    ///
    ///
    /// Os ydych chi'n ysgrifennu rhaglen a fydd yn prosesu fformat ffeil sy'n bodoli eisoes, gwiriwch beth yw diffiniad y fformat hwnnw o ofod gwyn cyn defnyddio'r swyddogaeth hon.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Yn gwirio a yw'r gwerth yn gymeriad rheoli ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, neu U + 007F DELETE.
    /// Sylwch fod y mwyafrif o gymeriadau gofod gwyn ASCII yn gymeriadau rheoli, ond nid yw SPACE.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Amgodio'r gwerth u32 amrwd fel UTF-8 mewn i'r byffer beit a ddarperir, ac yna dychwelyd y subslice y byffer sy'n cynnwys y cymeriad amgodio.
///
///
/// Yn wahanol i `char::encode_utf8`, y dull hwn hefyd yn ymdrin pwynt cod yn yr ystod benthyg.
/// (Creu `char` yn yr ystod dirprwyol yn UB.) Y canlyniad yw [generalized UTF-8] ddilys ond UTF-8 ddilys.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics os nad yw'r byffer yn ddigon mawr.
/// Mae byffer o hyd pedwar yn ddigon mawr i amgodio unrhyw `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Yn amgodio gwerth u32 amrwd fel UTF-16 i'r byffer `u16` a ddarperir, ac yna'n dychwelyd is-haen y byffer sy'n cynnwys y cymeriad wedi'i amgodio.
///
///
/// Yn wahanol i `char::encode_utf16`, y dull hwn hefyd yn ymdrin pwynt cod yn yr ystod benthyg.
/// (Creu `char` yn yr ystod dirprwyol yn UB.)
///
/// # Panics
///
/// Panics os nad yw'r byffer yn ddigon mawr.
/// Mae byffer o hyd 2 yn ddigon mawr i amgodio unrhyw `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // DIOGELWCH: mae pob braich yn gwirio a oes digon o ddarnau i ysgrifennu ynddynt
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Mae'r BMP yn cwympo drwodd
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // awyrennau Atodol torri i mewn surrogates.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}